// Arka plan (MV3 service worker): araç çubuğu simgesi ve sekme açma. Ağ isteği yok; veri işlemez.
const E_OKUL = /^https:\/\/(e-okul|eokul|[^/]+\.e-okul)\.meb\.gov\.tr\//i;
const SAYFALAR = { notoku: 'ice/ice.html', tarama: 'ice/ice.html', ice: 'ice/ice.html', iceOgren: 'ice/ice.html#ogrenilen' }; // 1.9.0 el yazısı okuma kaldırıldı; eski anahtarlar Excel sayfasına gider // 1.7.0 ice: Excel'den not girişi
chrome.action.onClicked.addListener(async (tab) => {
  if (tab && tab.id != null && E_OKUL.test(tab.url || '')) {
    try { await chrome.tabs.sendMessage(tab.id, { tip: 'nga-ac' }, { frameId: 0 }); return; } catch (e) { /* panel yüklenmemiş */ }
  }
  chrome.tabs.create({ url: chrome.runtime.getURL(SAYFALAR.notoku) });
});
// 1.6.23 Sesli not: e-Okul sayfası mikrofonu yasakladığı için dinleme küçük bir uzantı penceresinde yapılır
let sesPencere = null;
chrome.runtime.onMessage.addListener((m, gonderen) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'ses-ac') return;
  const ac = () => chrome.windows.create({ url: chrome.runtime.getURL('ses/ses.html'), type: 'popup', width: 440, height: 300, focused: true }, (w) => { sesPencere = w && w.id; });
  if (sesPencere != null) chrome.windows.get(sesPencere, () => { if (chrome.runtime.lastError) { sesPencere = null; ac(); } else chrome.windows.update(sesPencere, { focused: true }); }); else ac();
});
chrome.runtime.onMessage.addListener((m, gonderen) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'sekme-ac' || !SAYFALAR[m.hedef]) return;
  chrome.tabs.create({ url: chrome.runtime.getURL(SAYFALAR[m.hedef]) });
});

function dosyaAdiGuvenli(ad, yedek) {
  let s = String(ad || yedek || 'OYSS.xlsx');
  s = s.replace(/[\\/:*?"<>|]+/g, '_').replace(/[\u0000-\u001f]/g, '');
  s = s.replace(/^.*[\\/]/, '');
  const nokta = s.lastIndexOf('.');
  let taban = nokta > 0 ? s.slice(0, nokta) : s;
  let uzanti = nokta > 0 ? s.slice(nokta) : '.xlsx';
  taban = taban.replace(/[.\s]+$/g, '').replace(/^[.\s]+/g, '') || 'OYSS';
  uzanti = uzanti.replace(/[.\s]+$/g, '') || '.xlsx';
  if (uzanti.charAt(0) !== '.') uzanti = '.' + uzanti;
  return (taban + uzanti).slice(0, 150);
}
function u8b64(u8) {
  let s = '';
  const CH = 0x8000;
  for (let i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
  return btoa(s);
}
const indirGunluk = [];
function gunluk(kayit) {
  indirGunluk.push(Object.assign({ t: new Date().toISOString() }, kayit));
  if (indirGunluk.length > 40) indirGunluk.shift();
  try { chrome.storage.local.set({ ngaOyssIndirGunluk: indirGunluk.slice(-20) }); } catch (e) {}
}

// 1.9.9: şablon uzantı paketinden SW'de okunur. İçerik betimi sayfa kökeninden fetch ederse
// (web_accessible_resources yok) istek chrome-extension://invalid/ olur ve Failed to fetch düşer.
chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'oyss-sablon') return;
  (async () => {
    try {
      const r = await fetch(chrome.runtime.getURL('oyss/OYSS_Soru_Bazli_Not_Sablonu.xlsx'));
      if (!r.ok) throw new Error('şablon HTTP ' + r.status);
      const u8 = new Uint8Array(await r.arrayBuffer());
      gunluk({ adim: 'sablon', ok: true, bayt: u8.length });
      yanit({ ok: true, veri: u8b64(u8), bayt: u8.length });
    } catch (e) {
      const hata = String(e && e.message || e);
      gunluk({ adim: 'sablon', ok: false, hata });
      yanit({ ok: false, hata });
    }
  })();
  return true;
});

// 1.9.4: OYSS Excel/zip indirmesi (içerik betiğindeki a.click kullanıcı jesti bitince sessiz kalabilir)
chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'oyss-indir') return;
  try {
    const tur = String(m.tur || 'application/octet-stream').replace(/[^a-z0-9.+\/-]/gi, '') || 'application/octet-stream';
    const url = 'data:' + tur + ';base64,' + String(m.veri || '');
    const ad = dosyaAdiGuvenli(m.ad, 'OYSS.xlsx');
    if (!m.veri) {
      const hata = 'indirme verisi boş';
      gunluk({ adim: 'indir', ok: false, ad, hata });
      yanit({ ok: false, hata, ad });
      return true;
    }
    chrome.downloads.download({ url, filename: ad, saveAs: false, conflictAction: 'uniquify' }, (id) => {
      const err = chrome.runtime.lastError && chrome.runtime.lastError.message;
      const ok = !err && !!id;
      gunluk({ adim: 'indir', ok, ad, id: id || null, hata: err || (!id ? 'indirme başlamadı' : '') });
      yanit({ ok, hata: err || (!id ? 'indirme başlamadı' : ''), ad, id: id || null });
    });
  } catch (e) {
    const hata = String(e && e.message || e);
    gunluk({ adim: 'indir', ok: false, hata });
    yanit({ ok: false, hata });
  }
  return true;
});

chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'oyss-indir-gunluk') return;
  yanit({ ok: true, gunluk: indirGunluk.slice() });
  return true;
});
