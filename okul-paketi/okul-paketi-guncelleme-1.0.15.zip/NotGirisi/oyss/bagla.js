// 1.9.4: OYSS ayrı panel bağlacı. Ders notu kontrollerini (nga-ders, otomatik Listele, sütun) kullanmaz.
(function (kok) {
  'use strict';
  const oyssHTML = () => `<div id="nga-oyss-kok">
     <p style="color:#333;font-size:12px;margin:4px 0">Bu sekme yalnız <b>OYSS Not Girişi</b> (OOK10020) içindir; ders notu girişi ile karışmaz. Şubeleri seçin; her şube için sınıf listesi <b>bir kez</b> çekilir (dersler dolaşılmaz). Excel'de o düzeyin OYSS dersleri ayrı sayfa olarak, aynı öğrenci listesi ve 1–15. soru sütunlarıyla hazırlanır. Sınav: sayfada seçtiğiniz sınav (yoksa ilk <b>(OYSS Yazılı Sınav (Asıl))</b>). <b>Şube sınav durumu</b> ve <b>Kapat</b> düğmesine dokunulmaz. Güvenlik Koduna dokunulmaz.</p>
     <p style="font-size:12px;margin:4px 0"><b>1. Şube listesi</b> <button type="button" id="nga-oyss-sube-yenile">Sayfadan oku</button>
       <label><input type="checkbox" id="nga-oyss-sube-hepsi" checked> Tümü</label>
       <label title="2026-2027: ortaokul 5-6-7 ve lise 9-10-11; yalnız kılavuzdaki dersler. Kapsam dışı şube ve derslere gidilmez."><input type="checkbox" id="nga-oyss-kapsam" checked> Yalnız OYSS kapsamı</label></p>
     <p class="not" id="nga-oyss-kapsam-not" style="font-size:11px;margin:2px 0;color:#555"></p>
     <div id="nga-oyss-subeler" style="max-height:160px;overflow:auto;border:1px solid #ddd;padding:4px 6px;font-size:12px;background:#fff"></div>
     <p style="font-size:12px;margin:8px 0 4px"><b>2. Dersler Excel'de hazırlanır</b> — sayfadan ders seçmeniz gerekmez. Lise 9–11: TDE, Matematik, Fizik, Kimya, Biyoloji, Tarih, Coğrafya, Din Kültürü ve Ahlak Bilgisi, Felsefe, İngilizce. Ortaokul 5–7: Türkçe, Matematik, Fen Bilimleri, Sosyal Bilgiler, Din Kültürü ve Ahlak Bilgisi, İngilizce. Her ders sayfasında soru 1–15 ve Katılım (5 seçenek) hazırdır.</p>
     <p style="font-size:12px;margin:4px 0">3. Sınav: sayfada önceden seçtiğiniz sınav her şubede aynen seçilir. 4. Şube başına bir dersle Öğrenci Listesi Yükle (yalnız Okul No ve Ad Soyad alınır). 5. Excel.</p>
     <p style="font-size:12px;margin:4px 0">Çıktı
       <label><input type="radio" name="ngaOyssCikti" id="nga-oyss-cikti-zip" value="zip" checked> Ayrı dosyalar (zip)</label>
       <label><input type="radio" name="ngaOyssCikti" id="nga-oyss-cikti-kitap" value="kitap"> Tek çalışma kitabı</label>
     </p>
     <button type="button" id="nga-oyss-aktar">Bu ekrandaki listeyi Excel'e indir</button>
     <button type="button" id="nga-oyss-tum">Excel'e aktar (seçilen şubeler)</button>
     <button type="button" id="nga-oyss-iptal" hidden>İptal</button>
     <button type="button" id="nga-oyss-yukle">Excel yükle</button> <span style="font-size:11px;color:#555">(bir veya birden çok dosya)</span>
     <input id="nga-oyss-dosya" type="file" accept=".xlsx,.zip" multiple hidden>
     <button type="button" id="nga-oyss-yaz">e-Okul'a yaz ve Kaydet</button>
     <button type="button" id="nga-oyss-tani" title="Öğrenci verisi olmadan sayfa yapısını panoya kopyalar.">Tanı raporu</button>
     <button type="button" id="nga-oyss-testindir" title="Küçük bir deneme xlsx indirerek indirme yolunu sınar.">Test indirme</button>
     <p style="font-size:12px;margin:4px 0"><label>Hız <select id="nga-oyss-hiz"><option value="normal">Normal</option><option value="hizli" selected>Hızlı</option><option value="cokhizli">Çok hızlı</option></select></label></p>
     <p class="not" id="nga-oyss-durum" style="font-size:12px;margin:4px 0">Liste henüz çekilmedi.</p>
     <pre id="nga-oyss-rapor" style="white-space:pre-wrap;font:11px/1.35 sans-serif;background:#f7f7f7;border:1px solid #ddd;padding:6px;max-height:140px;overflow:auto"></pre>
  </div>`;
  function bagla(p, $) {
    if (!p || typeof OyssNot === 'undefined') return;
    const durum = $('nga-oyss-durum'), rapor = $('nga-oyss-rapor'), dosya = $('nga-oyss-dosya'), hizSel = $('nga-oyss-hiz');
    if (!durum || !dosya) return;
    let iceOzet = null;
    let gruplar = null, iptal = false;
    const yazDurum = (t, r, hata) => {
      durum.textContent = t;
      durum.style.color = hata ? '#b00020' : '';
      durum.style.fontWeight = hata ? '700' : '';
      if (rapor) {
        rapor.textContent = r || '';
        rapor.style.background = hata ? '#fdecea' : '#f7f7f7';
        rapor.style.borderColor = hata ? '#b00020' : '#ddd';
        rapor.style.color = hata ? '#7a1020' : '';
      }
    };
    async function sablonAl() {
      // 1.9.9: şablon SW'den okunur. Sayfadan fetch(chrome.runtime.getURL) → chrome-extension://invalid/ / Failed to fetch.
      if (!chrome.runtime || !chrome.runtime.sendMessage) throw new Error('chrome.runtime.sendMessage yok; şablon alınamadı.');
      const r = await chrome.runtime.sendMessage({ tip: 'oyss-sablon' });
      if (!r || !r.ok) throw new Error('OYSS şablonu alınamadı: ' + ((r && r.hata) || 'service worker yanıt vermedi'));
      const bin = Uint8Array.from(atob(r.veri), (c) => c.charCodeAt(0));
      return bin.buffer;
    }
    async function indir(ad, buf, tur) {
      const r = await OyssNot.dosyaIndir(ad, buf, tur);
      const ok = r === true || (r && r.ok);
      if (!ok) throw new Error((r && r.hata) || ('İndirme başlatılamadı: ' + ad));
      return r;
    }
    function ozetGruplar(g) {
      return (g || []).map((x) => (x.sube || '—') + ' / ' + (x.ders || '—') + ' · ' + (x.ogrenciler || []).length + ' öğrenci · ' + (x.soruSayisi || 0) + ' soru').join('\n');
    }
    function hataOzet(sonuc) {
      return (sonuc.hatalar || []).concat(sonuc.atlanan || []).map((x) => '• ' + x).join('\n');
    }
    const depo = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) || null;
    if (depo) depo.get('ngaOyssHiz', (v) => { if (hizSel) hizSel.value = v.ngaOyssHiz || 'hizli'; });
    if (hizSel) hizSel.onchange = () => { if (depo) depo.set({ ngaOyssHiz: hizSel.value }); };
    function kac(s) { return String(s || '').replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c])); }
    function listeDoldur() {
      const kutu = $('nga-oyss-subeler');
      if (!kutu) return;
      const once = [...kutu.querySelectorAll('input[data-oyss-sube]')].filter((c) => c.checked).map((c) => c.value);
      const hepsi = $('nga-oyss-sube-hepsi') && $('nga-oyss-sube-hepsi').checked;
      const kapsam = yalnizOyss();
      const tumSube = OyssNot.subeListesi(window);
      const subeler = kapsam ? tumSube.filter((s) => OyssNot.oyssSubeMi(s.text)) : tumSube;
      const notEl = $('nga-oyss-kapsam-not');
      if (notEl) notEl.textContent = kapsam ? ('OYSS kapsamı: ortaokul 5-6-7, lise 9-10-11 ve kılavuzdaki dersler.' + (tumSube.length > subeler.length ? ' Kapsam dışı ' + (tumSube.length - subeler.length) + ' şube gizlendi.' : '')) : '';
      if (!subeler.length) { kutu.textContent = tumSube.length ? 'Bu listede OYSS kapsamında şube yok (5-6-7 / 9-10-11).' : 'Şube listesi sayfada bulunamadı. OYSS Not Girişi (OOK10020) ekranında mısınız?'; return; }
      kutu.innerHTML = subeler.map((s) => {
        const v = String(s.index);
        const sec = hepsi || !once.length || once.includes(v);
        return '<label style="display:block"><input type="checkbox" data-oyss-sube="1" value="' + v + '"' + (sec ? ' checked' : '') + '> ' + kac(s.text) + '</label>';
      }).join('');
    }
    function yalnizOyss() { const c = $('nga-oyss-kapsam'); return !c || c.checked; }
    function secilenSubeler() {
      const kutu = $('nga-oyss-subeler');
      const isaret = [...(kutu ? kutu.querySelectorAll('input[data-oyss-sube]') : [])].filter((c) => c.checked).map((c) => +c.value);
      return OyssNot.subeListesi(window).filter((s) => isaret.includes(s.index));
    }
    async function kvkkOk() {
      if (!depo) return true;
      return new Promise((r) => depo.get('ngaKvkkOnay', (v) => r(!!v.ngaKvkkOnay)));
    }
    async function aktarGruplar(liste, tekAd) {
      if (!liste || !liste.length) throw new Error('Aktarılacak öğrenci listesi yok.');
      const sayfalar = OyssNot.gruplariDersSayfalarina(liste);
      if (!sayfalar.length) throw new Error('Aktarılacak ders sayfası yok.');
      const sablon = await sablonAl();
      const kitap = p.querySelector('#nga-oyss-cikti-kitap') && p.querySelector('#nga-oyss-cikti-kitap').checked;
      const subeSay = new Set(sayfalar.map((g) => OyssNot.katla(g.sube))).size;
      if (kitap) {
        const out = await OyssNot.sablonCokluKitap(sablon, sayfalar);
        await indir(tekAd || 'OYSS_Tum_Subeler.xlsx', out);
        return subeSay + ' şube, ' + sayfalar.length + ' ders sayfası tek çalışma kitabına yazıldı ve indirildi.';
      }
      if (subeSay === 1) {
        const out = await OyssNot.sablonCokluKitap(sablon, sayfalar);
        const ad = tekAd || OyssNot.dosyaAdiSube(sayfalar[0]);
        await indir(ad, out);
        return '1 şube, ' + sayfalar.length + ' ders sayfası indirildi: ' + ad;
      }
      const z = await OyssNot.sablonCokluZip(sablon, sayfalar);
      await indir('OYSS_Subeler.zip', z.zip, 'application/zip');
      return z.dosyalar.length + ' şube dosyası zip içinde indirildi: ' + z.dosyalar.join(', ');
    }
    const btnAktar = $('nga-oyss-aktar'), btnTum = $('nga-oyss-tum'), btnIptal = $('nga-oyss-iptal'), btnYukle = $('nga-oyss-yukle'), btnYaz = $('nga-oyss-yaz'), btnTani = $('nga-oyss-tani'), btnTest = $('nga-oyss-testindir');
    if ($('nga-oyss-sube-yenile')) $('nga-oyss-sube-yenile').onclick = () => { listeDoldur(); yazDurum('Şube listesi sayfadan okundu (' + OyssNot.subeListesi(window).length + ' şube).'); };
    if ($('nga-oyss-sube-hepsi')) $('nga-oyss-sube-hepsi').onchange = (e) => {
      const kutu = $('nga-oyss-subeler');
      if (kutu) kutu.querySelectorAll('input[data-oyss-sube]').forEach((c) => { c.checked = e.target.checked; });
    };
    if ($('nga-oyss-kapsam')) {
      if (depo) depo.get('ngaOyssKapsam', (v) => { if (v.ngaOyssKapsam === false) { $('nga-oyss-kapsam').checked = false; listeDoldur(); } });
      $('nga-oyss-kapsam').onchange = () => { if (depo) depo.set({ ngaOyssKapsam: $('nga-oyss-kapsam').checked }); listeDoldur(); };
    }
    listeDoldur();
    if (btnAktar) btnAktar.onclick = async () => {
      try {
        if (!(await kvkkOk())) return yazDurum('KVKK onayı olmadan çalışmaz.');
        const sayfa = OyssNot.sayfaOku(window);
        if (!sayfa || !sayfa.satirlar.length) return yazDurum('Bu şubede OYSS tablosu yok. Öğrenci Listesi Yükle\'ye basın veya seçilen şubeleri Excel\'e aktarın.');
        const g = [{
          sube: sayfa.sube, sinav: sayfa.sinav,
          ogrenciler: sayfa.satirlar.map((s) => ({ no: s.no, ad: s.ad })),
        }];
        const msg = await aktarGruplar(g, OyssNot.dosyaAdiSube(g[0]));
        yazDurum(msg, ozetGruplar(g));
      } catch (e) { yazDurum('Aktarılamadı: ' + (e && e.message || e), (OyssNot.indirGunluk || []).slice(-10).map((g) => (g.ok ? 'TAMAM ' : 'HATA ') + (g.adim || '') + ' ' + (g.ad || '') + ' ' + (g.hata || '')).join('\n'), true); }
    };
    if (btnTani) btnTani.onclick = async () => {
      try {
        const metin = OyssNot.taniRaporu(window);
        let kopyalandi = false;
        try { await navigator.clipboard.writeText(metin); kopyalandi = true; } catch (e) {
          try {
            const ta = document.createElement('textarea');
            ta.value = metin; ta.style.position = 'fixed'; ta.style.left = '-9999px';
            document.body.appendChild(ta); ta.select();
            kopyalandi = document.execCommand('copy');
            ta.remove();
          } catch (e2) {}
        }
        let ek = metin;
        try {
          const sw = await chrome.runtime.sendMessage({ tip: 'oyss-indir-gunluk' });
          if (sw && sw.gunluk && sw.gunluk.length) {
            ek += '\n\n— İndirme günlüğü (service worker) —\n' + sw.gunluk.map((g) => '  ' + JSON.stringify(g)).join('\n');
          }
        } catch (e3) { ek += '\n(SW günlüğü alınamadı: ' + (e3 && e3.message || e3) + ')'; }
        yazDurum(kopyalandi ? 'Tanı raporu panoya kopyalandı (öğrenci verisi yok). Yapıştırmayı bana gönderin.' : 'Panoya kopyalanamadı; metni aşağıdan alın.', ek);
      } catch (e) { yazDurum('Tanı raporu alınamadı: ' + (e && e.message || e), '', true); }
    };
    if (btnTest) btnTest.onclick = async () => {
      try {
        const r = await OyssNot.testIndir();
        const ok = r === true || (r && r.ok);
        const ad = (r && r.ad) || 'OYSS_test_indirme.xlsx';
        if (ok) yazDurum('Test indirme başladı: ' + ad);
        else yazDurum('Test indirme başarısız: ' + ((r && r.hata) || 'dosya inmedi. Tanı raporundaki indirme günlüğüne bakın.'), (r && r.hata) || '', true);
      } catch (e) { yazDurum('Test indirme hata: ' + (e && e.message || e), '', true); }
    };
    if (btnIptal) btnIptal.onclick = () => { iptal = true; };
    if (btnTum) btnTum.onclick = async () => {
      iptal = false;
      if (btnIptal) btnIptal.hidden = false;
      btnTum.disabled = true;
      window.__ngaOyssCalisiyor = true;
      try {
        if (!(await kvkkOk())) return yazDurum('KVKK onayı olmadan çalışmaz.');
        const sec = secilenSubeler();
        if (!sec.length) { yazDurum('Hiç şube seçilmedi. Listeden en az bir şube işaretleyin veya Sayfadan oku\'ya basın.'); return; }
        const sonuc = await OyssNot.tumSubeleriCek(window, {
          hiz: (hizSel && hizSel.value) || 'hizli',
          secilenSubeler: sec,
          yalnizOyss: yalnizOyss(),
          iptal: () => iptal,
          ilerleme: (q) => yazDurum('OYSS: ' + (q.mesaj || ''), ''),
        });
        const ek = hataOzet(sonuc);
        if (sonuc.gruplar.length) {
          const msg = await aktarGruplar(sonuc.gruplar);
          const bas = sonuc.hatalar && sonuc.hatalar.length ? ('Kısmen tamam. İlk hata: ' + sonuc.hatalar[0] + ' ') : '';
          yazDurum(bas + msg, ozetGruplar(sonuc.gruplar) + (ek ? '\n\n' + ek : ''));
        } else {
          yazDurum('Hiç öğrenci listesi alınamadı. ' + (sonuc.hatalar[0] || sonuc.atlanan[0] || 'Adımı kontrol edin.'), ek, true);
        }
      } catch (e) { yazDurum('Excel\'e aktarma durdu: ' + (e && e.message || e), (OyssNot.indirGunluk || []).slice(-10).map((g) => (g.ok ? 'TAMAM ' : 'HATA ') + (g.adim || '') + ' ' + (g.hata || '')).join('\n'), true); }
      finally {
        window.__ngaOyssCalisiyor = false;
        if (btnIptal) btnIptal.hidden = true;
        btnTum.disabled = false;
      }
    };
    if (btnYukle) btnYukle.onclick = () => dosya.click();
    dosya.onchange = async () => {
      const files = [...(dosya.files || [])]; dosya.value = '';
      if (!files.length) return;
      try {
        const aday = [];
        for (const f of files) aday.push({ ad: f.name, buf: await f.arrayBuffer() });
        iceOzet = await OyssNot.excelDosyalariOzet(aday);
        gruplar = iceOzet.gruplar;
        const dosyaHata = (iceOzet.dosyalar || []).filter((d) => d.hata);
        if (!gruplar.length && dosyaHata.length) throw new Error(dosyaHata.map((d) => d.ad + ': ' + d.hata).join('; '));
        if (!gruplar.length) throw new Error('Dosyalarda AYAR/NOTLAR veya şube-ders sayfası bulunamadı.');
        if (!iceOzet.coklu) {
          yazDurum(gruplar.length + ' grup yüklendi (yalnız bu oturum, depolanmaz). e-Okul\'a yaz, açık şube/ders ile eşleşeni kullanır.', ozetGruplar(gruplar));
        } else {
          const dolu = (iceOzet.dosyalar || []).reduce((n, d) => n + (d.dolu || []).length, 0);
          const bos = (iceOzet.dosyalar || []).reduce((n, d) => n + (d.bos || []).length, 0);
          const plan = OyssNot.icePlan(iceOzet);
          yazDurum(iceOzet.dosyalar.length + ' dosya yüklendi: ' + dolu + ' dolu ders işlenecek, ' + bos + ' boş ders atlanacak. e-Okul\'a yaz dosyaları sırayla işler.', OyssNot.iceOzetMetin(plan) + (dosyaHata.length ? '\n' + dosyaHata.map((d) => 'HATA ' + d.ad + ': ' + d.hata).join('\n') : ''));
        }
      } catch (e) { gruplar = null; iceOzet = null; yazDurum('Excel okunamadı: ' + (e && e.message || e), '', true); }
    };
    if (btnYaz) btnYaz.onclick = async () => {
      try {
        if (!(await kvkkOk())) return yazDurum('KVKK onayı olmadan çalışmaz.');
        if (!gruplar || !gruplar.length) return yazDurum('Önce doldurulmuş Excel\'i yükleyin (bir veya birden çok dosya, zip veya tek kitap).');
        const hiz = (hizSel && hizSel.value) || 'hizli';
        if (iceOzet && iceOzet.coklu) {
          const plan = OyssNot.icePlan(iceOzet);
          const sonuclar = plan.filter((p) => p.durum !== 'bekliyor').map((p) => ({ durum: p.durum, dosya: p.dosya, sube: p.sube, ders: p.ders, neden: p.neden }));
          const sira = plan.filter((p) => p.durum === 'bekliyor');
          if (!sira.length) {
            OyssNot.iceKaydet(sonuclar);
            return yazDurum('İşlenecek dolu ders sayfası yok.', OyssNot.iceOzetMetin(sonuclar), sonuclar.some((x) => x.durum === 'hata'));
          }
          window.__ngaOyssCalisiyor = true;
          if (btnIptal) btnIptal.hidden = false;
          try {
            for (let i = 0; i < sira.length; i++) {
              if (window.__ngaOyssIptal) {
                sonuclar.push({ durum: 'hata', dosya: sira[i].dosya, sube: sira[i].sube, ders: sira[i].ders, neden: 'İptal edildi' });
                for (let j = i + 1; j < sira.length; j++) sonuclar.push({ durum: 'atlandi', dosya: sira[j].dosya, sube: sira[j].sube, ders: sira[j].ders, neden: 'İptal' });
                break;
              }
              const g = sira[i].grup;
              yazDurum((i + 1) + '/' + sira.length + ' işleniyor: ' + (sira[i].dosya || '') + ' — ' + (g.sube || '') + ' / ' + (g.ders || ''), OyssNot.iceOzetMetin(sonuclar.concat([{ durum: 'bekliyor', dosya: sira[i].dosya, sube: g.sube, ders: g.ders, neden: 'yazılıyor' }])));
              try {
                const haz = await OyssNot.sayfaHazirla(window, g, { hiz });
                if (!haz.ok) { sonuclar.push({ durum: 'hata', dosya: sira[i].dosya, sube: g.sube || '', ders: g.ders || '', neden: haz.hata || 'Sayfa hazırlanamadı' }); continue; }
                const sayfa = haz.sayfa || OyssNot.sayfaOku(window);
                if (!sayfa || !sayfa.sorular || !sayfa.sorular.length) {
                  sonuclar.push({ durum: 'hata', dosya: sira[i].dosya, sube: g.sube || '', ders: g.ders || '', neden: 'OYSS soru tablosu yok' });
                  continue;
                }
                const r = await OyssNot.yazVeKaydet(window, g, { hiz });
                if (r.kaydedildi) sonuclar.push({ durum: 'islendi', dosya: sira[i].dosya, sube: g.sube || '', ders: g.ders || '', yazilan: r.yazilan, neden: 'Kaydet\'e basıldı' });
                else sonuclar.push({ durum: 'hata', dosya: sira[i].dosya, sube: g.sube || '', ders: g.ders || '', neden: (r.hatalar && r.hatalar[0]) || 'Kaydet\'e basılmadı.' });
              } catch (e) {
                sonuclar.push({ durum: 'hata', dosya: sira[i].dosya, sube: g.sube || '', ders: g.ders || '', neden: (e && e.message) || String(e) });
              }
            }
          } finally {
            window.__ngaOyssCalisiyor = false;
            window.__ngaOyssIptal = false;
            if (btnIptal) btnIptal.hidden = true;
          }
          OyssNot.iceKaydet(sonuclar);
          const ozet = OyssNot.iceOzetMetin(sonuclar);
          const nH = sonuclar.filter((x) => x.durum === 'hata').length;
          const nI = sonuclar.filter((x) => x.durum === 'islendi').length;
          yazDurum('Çoklu yazım bitti: ' + nI + ' işlendi, ' + sonuclar.filter((x) => x.durum === 'atlandi').length + ' atlandı, ' + nH + ' hata.', ozet, nH > 0);
          return;
        }
        let sayfa = OyssNot.sayfaOku(window);
        let g = OyssNot.grupSec(gruplar, sayfa);
        if (!g && sayfa && sayfa.sube) {
          const ayni = gruplar.filter((x) => OyssNot.katla(x.sube) === OyssNot.katla(sayfa.sube));
          if (ayni.length === 1) g = ayni[0];
        }
        if (!g) return yazDurum('Yüklenen Excel açık şube/ders ile eşleşmedi. Doğru dosyayı yükleyin veya o şubeyi e-Okul\'da açın.', ozetGruplar(gruplar) + '\nAçık: ' + ((sayfa && sayfa.sube) || '—') + ' / ' + ((sayfa && sayfa.ders) || '—'));
        const haz = await OyssNot.sayfaHazirla(window, g, { hiz });
        if (!haz.ok) return yazDurum('Sayfa hazırlanamadı: ' + (haz.hata || ''), ozetGruplar([g]));
        sayfa = haz.sayfa || OyssNot.sayfaOku(window);
        if (!sayfa || !sayfa.sorular || !sayfa.sorular.length) return yazDurum('OYSS soru tablosu yok. Ders ve sınav seçilip Öğrenci Listesi Yükle denendi; tablo gelmedi. Ders notu (OOK07003) sayfasında bu düğme Kaydet\'e basmaz.');
        const r = await OyssNot.yazVeKaydet(window, g, { hiz });
        yazDurum(r.kaydedildi ? ('Yazıldı ve Kaydet\'e basıldı (' + (g.sube || '') + ' / ' + (g.ders || '') + ').') : (r.ok === false ? 'Kaydet\'e basılmadı.' : 'Tamamlandı.'), OyssNot.raporMetin(r));
      } catch (e) { yazDurum('Yazılamadı: ' + (e && e.message || e), '', true); }
    };
  }
  kok.NGAOyssBagla = bagla;
  kok.NGAOyssHTML = oyssHTML;
})(typeof globalThis !== 'undefined' ? globalThis : this);
