// OYSS Soru Bazlı Not Girişi (v2.5.6).
// Excel yerelde okunur/yazılır; öğrenci verisi sunucuya veya yapay zekâya gitmez.
// KAYDET İSTİSNASI: Kullanıcı (13.11.2026) notlar girildikten sonra Kaydet'e basılmasını açıkça onayladı.
// Güvenlik kapıları (eşleşmeyen Okul No, puan hatası, soru sayısı uyuşmazlığı, boş Katılım) geçmeden Kaydet'e basılmaz.
// Güvenlik Koduna asla dokunulmaz. "Seçili Şubenin … Kapat" düğmesine basılmaz.
(function (kok) {
  "use strict";
  const SURUM = "2.5.7";
  const KATILIM = ["Sınava Girdi", "Kopya", "Muaf", "Sınava Girmedi", "Özel Eğitim İhtiyacı Olan Öğrenci"]; // 1.9.5: canlı ekranda 5. seçenek
  const MAX_SORU = 15;
  const SABLON_SATIR = 62; // şablondaki son veri satırı (3–62)
  const HIZ_BEKLE = { normal: 80, hizli: 15, cokhizli: 4 };
  const HIZ_KAYDET = { normal: 1000, hizli: 400, cokhizli: 200 };

  const norm = (s) => String(s == null ? "" : s).replace(/\s+/g, " ").trim();
  const kucuk = (s) => norm(s).toLocaleLowerCase("tr");
  const katla = (s) => kucuk(s).replace(/i̇/g, "i").replace(/[ıi]/g, "i").replace(/ş/g, "s").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ö/g, "o").replace(/ç/g, "c");
  const xmlKac = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "");
  const noNorm = (s) => {
    const t = String(s == null ? "" : s).trim().replace(/\s+/g, "");
    if (!t) return "";
    const d = t.replace(/^0+/, "");
    return d || "0";
  };
  const sayiOku = (v) => {
    const t = norm(v).replace(",", ".");
    if (t === "") return null;
    if (!/^-?\d+(\.\d+)?$/.test(t)) return NaN;
    return parseFloat(t);
  };
  const puanYaz = (v) => {
    const n = sayiOku(v);
    if (n == null || Number.isNaN(n)) return "";
    return Number.isInteger(n) ? String(n) : String(n).replace(".", ",");
  };
  function puanHata(v, max) {
    const t = norm(v);
    if (t === "") return null;
    const n = sayiOku(t);
    if (n == null || Number.isNaN(n)) return "sayı değil (" + t + ")";
    if (n < 0) return "negatif olamaz";
    if (max != null && !Number.isNaN(Number(max)) && n > Number(max)) return "azami " + max + " puanı aşıyor (" + t + ")";
    return null;
  }
  function soruBaslikOku(metin) {
    const t = katla(metin);
    const m = t.match(/(\d+)\s*\.\s*soru\s*\(\s*([\d]+(?:[.,]\d+)?)\s*puan\s*\)/);
    if (!m) return null;
    const no = parseInt(m[1], 10), max = sayiOku(m[2]);
    if (!no || no < 1 || no > MAX_SORU || Number.isNaN(max)) return null;
    return { no, max };
  }
  function katilimNorm(v) {
    const t = katla(v);
    if (!t || t === "seciniz" || t === "-") return "";
    for (const k of KATILIM) if (katla(k) === t) return k;
    return norm(v);
  }
  function puanVarMi(puan) {
    return (puan || []).some((v) => { const n = sayiOku(v); return n != null && !Number.isNaN(n); });
  }
  function katilimHesap(puan) { return puanVarMi(puan) ? "Sınava Girdi" : "Sınava Girmedi"; }
  // Önbellekli değer (Kopya/Muaf/elle) öncelikli; formülün v'si boşsa aynı kural yeniden hesaplanır.
  function katilimCoz(hucreDeger, puan) {
    const kat = katilimNorm(hucreDeger);
    return kat || katilimHesap(puan);
  }
  function girmediMi(kat) {
    const t = katla(katilimNorm(kat));
    return t === "sinava girmedi" || t === "muaf";
  }
  function sayfaAdi(sayfalar, ad) {
    if (!sayfalar) return null;
    const map = sayfalar.sayfalar || sayfalar;
    const hedef = katla(ad);
    for (const k of Object.keys(map)) if (katla(k) === hedef) return map[k];
    return null;
  }
  function hucre(sat, r, c) { // 1 tabanlı satır/sütun
    const row = sat && sat[r - 1];
    if (!row) return "";
    const v = row[c - 1];
    return v == null ? "" : String(v).trim();
  }

  function notlarSutunlari(notlar) {
    const baslik = {};
    for (let c = 1; c <= 30; c++) {
      const tx = katla(hucre(notlar, 2, c));
      if (!tx) continue;
      if (/^okul\s*no$|^okulno$/.test(tx)) baslik.no = c;
      if (/^adi soyadi$|^ad soyad$|^adi soyad$|^ad soyadi$/.test(tx)) baslik.ad = c;
      if (/^katilim$/.test(tx)) baslik.katilim = c;
      if (/^toplam$/.test(tx)) baslik.toplam = c;
      if (/^kontrol$/.test(tx)) baslik.kontrol = c;
    }
    const no = baslik.no || 2, ad = baslik.ad || 3;
    const katilim = baslik.katilim || (baslik.toplam ? baslik.toplam + 1 : 15);
    const ilk = ad + 1;
    const son = baslik.toplam ? baslik.toplam - 1 : (katilim - 1);
    const soruSutun = [];
    for (let c = ilk; c <= son && soruSutun.length < MAX_SORU; c++) soruSutun.push(c);
    return { no, ad, katilim, soruSutun };
  }
  function excelAyristir(sayfalar) {
    const ayar = sayfaAdi(sayfalar, "AYAR"), notlar = sayfaAdi(sayfalar, "NOTLAR");
    if (!ayar || !notlar) throw new Error("Excel'de AYAR ve NOTLAR sayfaları olmalı (OYSS şablonu).");
    const sut = notlarSutunlari(notlar);
    let soruSayisi = parseInt(hucre(ayar, 6, 2), 10);
    if (!soruSayisi || Number.isNaN(soruSayisi)) soruSayisi = sut.soruSutun.length;
    if (!soruSayisi || soruSayisi < 1 || soruSayisi > MAX_SORU) throw new Error("AYAR!B6 soru sayısı 1–15 arasında olmalı.");
    const puanlar = [];
    for (let i = 0; i < MAX_SORU; i++) {
      const n = sayiOku(hucre(ayar, 9 + i, 2));
      puanlar.push(n == null || Number.isNaN(n) ? 0 : n);
    }
    const nSoruOku = Math.max(soruSayisi, sut.soruSutun.length);
    const ogrenciler = [];
    for (let r = 3; r <= notlar.length; r++) {
      const no = hucre(notlar, r, sut.no), ad = hucre(notlar, r, sut.ad);
      if (!no && !ad) continue;
      if (!no) throw new Error("NOTLAR satır " + r + ": Okul No boş.");
      const puan = [];
      for (let i = 0; i < sut.soruSutun.length; i++) puan.push(hucre(notlar, r, sut.soruSutun[i]));
      while (puan.length < nSoruOku) puan.push("");
      const katHam = hucre(notlar, r, sut.katilim);
      ogrenciler.push({ no, ad, puan, katilim: katilimCoz(katHam, puan), katilimHam: katHam });
    }
    if (!ogrenciler.length) throw new Error("NOTLAR sayfasında öğrenci yok (Okul No boş).");
    return {
      sube: hucre(ayar, 3, 2), ders: hucre(ayar, 4, 2), sinav: hucre(ayar, 5, 2),
      soruSayisi: sut.soruSutun.length || soruSayisi, puanlar: puanlar.slice(0, Math.max(soruSayisi, sut.soruSutun.length)),
      puanlar10: puanlar, ogrenciler, sutun: sut,
    };
  }

  function grupKur(ayar, notlar, kaynak) {
    const gecici = { sira: ["AYAR", "NOTLAR"], sayfalar: { AYAR: ayar, NOTLAR: notlar } };
    const g = excelAyristir(gecici);
    if (kaynak) g.kaynak = kaynak;
    return g;
  }
  function excelAyristirCoklu(sayfalar) {
    const map = (sayfalar && sayfalar.sayfalar) || sayfalar || {};
    const sira = (sayfalar && sayfalar.sira) || Object.keys(map);
    const adBul = (hedef) => { const k = katla(hedef); return sira.find((ad) => katla(ad) === k); };
    const kullanilan = new Set(), gruplar = [];
    const ayarAd = adBul("AYAR"), notAd = adBul("NOTLAR");
    if (ayarAd && notAd && map[ayarAd] && map[notAd]) {
      gruplar.push(grupKur(map[ayarAd], map[notAd], notAd));
      kullanilan.add(ayarAd); kullanilan.add(notAd);
    }
    for (let i = 0; i < sira.length; i++) {
      const ad = sira[i];
      if (!/^AYAR_\d+$/i.test(ad) || kullanilan.has(ad)) continue;
      const sonraki = sira.slice(i + 1).find((n) => !kullanilan.has(n) && !/^AYAR(_\d+)?$/i.test(n) && katla(n) !== "notlar");
      if (!sonraki || !map[ad] || !map[sonraki]) continue;
      gruplar.push(grupKur(map[ad], map[sonraki], sonraki));
      kullanilan.add(ad); kullanilan.add(sonraki);
    }
    return gruplar;
  }
  function grupSec(gruplar, sayfa) {
    if (!gruplar || !gruplar.length) return null;
    if (gruplar.length === 1) return gruplar[0];
    const s = katla(sayfa && sayfa.sube), d = katla(sayfa && sayfa.ders);
    const tam = gruplar.filter((g) => katla(g.sube) === s && katla(g.ders) === d);
    if (tam.length === 1) return tam[0];
    const yalniz = s ? gruplar.filter((g) => katla(g.sube) === s) : [];
    if (yalniz.length === 1) return yalniz[0];
    return null;
  }
  function bufHazir(buf) {
    if (!buf) return buf;
    if (buf instanceof ArrayBuffer) return buf;
    if (buf.buffer instanceof ArrayBuffer) return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
    return buf;
  }
  async function excelBirDosyadan(f, api) {
    if (f && f.sayfalar) return excelAyristirCoklu(f.sayfalar);
    if (!api || !api.okuSayfalar) throw new Error("EvrakXlsx.okuSayfalar yok.");
    const ad = String((f && f.ad) || "");
    const buf = bufHazir(f && f.buf);
    const gruplar = [];
    if (/\.zip$/i.test(ad)) {
      const z = await api.ac(buf);
      const adlar = Object.keys(z).filter((k) => /\.xlsx$/i.test(k) && !/(^|\/)(__MACOSX|\.DS_Store)/.test(k));
      adlar.sort();
      for (const k of adlar) {
        const say = await api.okuSayfalar(bufHazir(z[k]));
        gruplar.push(...excelAyristirCoklu(say));
      }
    } else {
      const say = await api.okuSayfalar(buf);
      gruplar.push(...excelAyristirCoklu(say));
    }
    return gruplar;
  }
  async function excelDosyalarindan(dosyalar, xlsxApi) {
    const api = xlsxApi || kok.EvrakXlsx;
    const gruplar = [];
    for (const f of dosyalar || []) gruplar.push(...await excelBirDosyadan(f, api));
    return gruplar;
  }
  // Puan hücresi doluysa veya öğretmen Katılım'ı (Sınava Girmedi dışındaki bir seçenek) işlemişse sayfa doludur.
  // Boş şablondaki Katılım formülünün "Sınava Girmedi" önbelleği dolu sayılmaz.
  function grupDoluMu(g) {
    for (const o of (g && g.ogrenciler) || []) {
      if ((o.puan || []).some((v) => norm(v) !== "")) return true;
      const ham = o.katilimHam != null ? o.katilimHam : "";
      const kat = katilimNorm(ham);
      if (kat && katla(kat) !== "sinava girmedi") return true;
    }
    return false;
  }
  function dersSayfadaVarMi(ders, dersler) {
    if (!dersler || !dersler.length) return true;
    const hedef = katla(ders);
    return (dersler || []).some((d) => {
      const t = typeof d === "string" ? d : (d && (d.text || d.ad || d.ders)) || "";
      return katla(t) === hedef || dersCekirdek(t) === dersCekirdek(ders);
    });
  }
  async function excelDosyalariOzet(dosyalar, xlsxApi) {
    const api = xlsxApi || kok.EvrakXlsx;
    const liste = [], gruplar = [];
    for (const f of dosyalar || []) {
      const ad = String((f && f.ad) || "dosya.xlsx");
      const kayit = { ad, gruplar: [], dolu: [], bos: [], hata: null };
      try {
        const gs = await excelBirDosyadan(f, api);
        for (const g of gs) {
          g.kaynakDosya = ad;
          g.dolu = grupDoluMu(g);
          kayit.gruplar.push(g);
          gruplar.push(g);
          if (g.dolu) kayit.dolu.push(g);
          else kayit.bos.push(g);
        }
      } catch (e) {
        kayit.hata = (e && e.message) || String(e);
      }
      liste.push(kayit);
    }
    return { dosyalar: liste, gruplar, coklu: (dosyalar || []).length > 1 };
  }
  function iceSirasi(ozet) {
    const out = [];
    for (const d of (ozet && ozet.dosyalar) || []) {
      for (const g of d.dolu || []) out.push(g);
    }
    return out;
  }
  function icePlan(ozet, opts) {
    opts = opts || {};
    const dersler = opts.dersler || null;
    const plan = [];
    for (const d of (ozet && ozet.dosyalar) || []) {
      if (d.hata) {
        plan.push({ durum: "hata", dosya: d.ad, sube: "", ders: "", neden: d.hata });
        continue;
      }
      for (const g of d.bos || []) {
        plan.push({ durum: "atlandi", dosya: d.ad, sube: g.sube || "", ders: g.ders || "", neden: "Boş ders sayfası (puan/Katılım yok)" });
      }
      for (const g of d.dolu || []) {
        if (!dersSayfadaVarMi(g.ders, dersler)) {
          plan.push({ durum: "hata", dosya: d.ad, sube: g.sube || "", ders: g.ders || "", neden: "Ders sayfada yok: " + (g.ders || ""), grup: g });
        } else {
          plan.push({ durum: "bekliyor", dosya: d.ad, sube: g.sube || "", ders: g.ders || "", grup: g });
        }
      }
    }
    return plan;
  }
  function iceDurumEtiket(d) {
    if (d === "islendi") return "İŞLENDİ";
    if (d === "atlandi") return "ATLANDI";
    if (d === "bekliyor") return "İŞLENECEK";
    return "HATA";
  }
  function iceOzetMetin(kayitlar) {
    const liste = kayitlar || [];
    const n = (d) => liste.filter((x) => x.durum === d).length;
    const satir = ["Özet: " + n("islendi") + " işlendi, " + n("bekliyor") + " işlenecek, " + n("atlandi") + " atlandı, " + n("hata") + " hata."];
    for (const k of liste) {
      const bas = iceDurumEtiket(k.durum);
      const yer = [k.dosya, k.sube, k.ders].filter(Boolean).join(" / ");
      satir.push("• " + bas + (yer ? " — " + yer : "") + (k.neden ? " (" + k.neden + ")" : "") + (k.yazilan != null ? " yazılan=" + k.yazilan : ""));
    }
    return satir.join("\n");
  }
  const iceGunluk = [];
  function iceKaydet(kayitlar) {
    iceGunluk.length = 0;
    for (const k of kayitlar || []) iceGunluk.push(k);
    return iceGunluk;
  }

  function belgeler(win) {
    const out = [];
    const gez = (w) => {
      try { out.push(w.document); } catch (e) { return; }
      let n = 0;
      try { n = w.frames.length; } catch (e) { return; }
      for (let i = 0; i < n; i++) { try { gez(w.frames[i]); } catch (e) {} }
    };
    if (win && win.document) gez(win);
    else if (win && win.querySelector) out.push(win); // Document verildi
    return out;
  }
  function eklentiElemaniMi(el) {
    if (!el) return false;
    try {
      const kok = el.getRootNode && el.getRootNode();
      if (kok && kok !== el && kok.host && eklentiElemaniMi(kok.host)) return true;
    } catch (e) {}
    let n = el;
    while (n && n.nodeType === 1) {
      const id = String(n.id || "").toLowerCase();
      if (/^(nga-|eap-|eoa-)/.test(id) || id === "nga-panel" || id === "eoa-host" || id === "eap-host") return true;
      if (n.closest) {
        const k = n.closest("#nga-panel,#eoa-host,#eap-host,#eoa-panel,[data-nga],[data-eoa],[data-eap]");
        if (k) return true;
      }
      n = n.parentElement;
    }
    return false;
  }
  function hucreDizi(tr) {
    const out = [];
    for (const c of tr.children) {
      if (c.tagName !== "TD" && c.tagName !== "TH") continue;
      const span = Math.max(1, parseInt(c.getAttribute("colspan"), 10) || 1);
      for (let i = 0; i < span; i++) out.push(c);
    }
    return out;
  }
  function metinEl(e) {
    return norm([e && (e.value || ""), e && e.textContent, e && e.title, e && e.alt, e && e.getAttribute && e.getAttribute("aria-label")].filter(Boolean).join(" "));
  }
  function alanMetin(el) {
    if (!el) return "";
    return [el.id, el.name, el.className, el.placeholder, el.title, el.getAttribute && el.getAttribute("aria-label"), el.getAttribute && el.getAttribute("for"), metinEl(el)].join(" ");
  }
  function guvenlikAlaniMi(el) {
    if (!el) return false;
    const t = katla(alanMetin(el));
    return /guvenlik\s*kodu|guvenlikkodu|guvenlik_kod|txtguvenlik|captcha|security\s*code|securitycode/.test(t);
  }
  function kaydetBul(doc) {
    const adaylar = [...doc.querySelectorAll("input[type=submit],input[type=button],input[type=image],button,a")];
    const uygun = adaylar.filter((e) => {
      if (guvenlikAlaniMi(e)) return false;
      const t = katla(metinEl(e) || e.value || "");
      return t === "kaydet";
    });
    return uygun[0] || null;
  }
  function etiketDeger(doc, kabul, haric) {
    const sel = etiketSelect(doc, kabul, haric);
    if (!sel) return "";
    const op = sel.options[sel.selectedIndex];
    const txt = norm(op && (op.text || op.value));
    if (txt && !/^seciniz|^--|^secin/.test(katla(txt))) return txt;
    return "";
  }
  function tabloOku(doc) {
    const tablolar = [...doc.querySelectorAll("table")];
    let en = null, enSkor = 0;
    for (const t of tablolar) {
      const satirlar = [...t.querySelectorAll("tr")].filter((tr) => tr.closest("table") === t);
      let baslik = null, baslikIdx = -1, sorular = [];
      for (let i = 0; i < Math.min(4, satirlar.length); i++) {
        const huc = hucreDizi(satirlar[i]);
        const bulunan = [];
        let okulNoCol = -1, adCol = -1, katilimCol = -1;
        huc.forEach((c, j) => {
          const tx = norm(c.textContent);
          const s = soruBaslikOku(tx);
          if (s) bulunan.push({ ...s, col: j });
          const k = katla(tx);
          if (k === "okul no" || k === "okulno" || k === "ogrenci no" || k === "öğrenci no") okulNoCol = j;
          if (k === "adi soyadi" || k === "ad soyad" || k === "adi soyadi" || k === "ad soyadi") adCol = j;
          if (k === "katilim") katilimCol = j;
        });
        if (bulunan.length && okulNoCol >= 0) { baslik = { huc, okulNoCol, adCol, katilimCol, sorular: bulunan.sort((a, b) => a.no - b.no) }; baslikIdx = i; break; }
      }
      if (!baslik) continue;
      const skor = baslik.sorular.length * 10 + (satirlar.length - baslikIdx - 1);
      if (skor > enSkor) { enSkor = skor; en = { tablo: t, doc, ...baslik, baslikIdx, satirlar }; }
    }
    if (!en) return null;
    const ogr = [];
    for (let i = en.baslikIdx + 1; i < en.satirlar.length; i++) {
      const tr = en.satirlar[i];
      const huc = hucreDizi(tr);
      if (!huc.length) continue;
      const noH = huc[en.okulNoCol];
      if (!noH) continue;
      if (noH.querySelector("input,select")) continue; // başlık tekrarı / düzenleme satırı değil
      const no = noNorm(noH.textContent);
      if (!no) continue;
      const ad = en.adCol >= 0 && huc[en.adCol] ? norm(huc[en.adCol].textContent) : "";
      const girdiler = en.sorular.map((s) => {
        const c = huc[s.col];
        if (!c) return null;
        return c.querySelector("input:not([type=hidden]):not([disabled]), textarea") || null;
      });
      const katH = en.katilimCol >= 0 ? huc[en.katilimCol] : null;
      const select = (katH && katH.querySelector("select")) || tr.querySelector("select");
      ogr.push({ tr, no: norm(noH.textContent), ad, girdiler, select });
    }
    return { tablo: en.tablo, doc: en.doc, sorular: en.sorular, okulNoCol: en.okulNoCol, adCol: en.adCol, katilimCol: en.katilimCol, satirlar: ogr };
  }

  function sayfaOku(win) {
    const docs = belgeler(win);
    let tablo = null;
    for (const d of docs) {
      const t = tabloOku(d);
      if (t && (!tablo || t.sorular.length > tablo.sorular.length || t.satirlar.length > (tablo.satirlar || []).length)) tablo = t;
    }
    const metaDoc = tablo ? tablo.doc : docs[0];
    const k = kontroller(win);
    const secili = (sel) => {
      if (!sel || sel.selectedIndex < 0) return "";
      const op = sel.options[sel.selectedIndex];
      const txt = norm(op && (op.text || op.value));
      if (txt && !/^seciniz|^--|^secin/.test(katla(txt))) return txt;
      return "";
    };
    const sube = secili(k.subeSel);
    const ders = secili(k.dersSel);
    const sinav = secili(k.sinavSel);
    let kaydetEl = tablo ? kaydetBul(tablo.doc) : null;
    if (!kaydetEl) for (const d of docs) { kaydetEl = kaydetBul(d); if (kaydetEl) break; }
    if (!tablo) return { tablo: null, sorular: [], satirlar: [], sube, ders, sinav, kaydetEl, doc: metaDoc };
    return { ...tablo, sube, ders, sinav, kaydetEl };
  }

  function kapilar(excel, sayfa) {
    const hatalar = [], uyarilar = [], bulunamayan = [], sayfadaFazla = [];
    if (!sayfa || !sayfa.sorular || !sayfa.sorular.length) hatalar.push("OYSS soru tablosu bulunamadı. Öğrenci Listesi Yükle'ye basıldığından emin olun.");
    if (!excel || !excel.ogrenciler || !excel.ogrenciler.length) hatalar.push("Excel'de öğrenci satırı yok.");
    const sayfaSoru = (sayfa && sayfa.sorular) ? sayfa.sorular.length : 0;
    if (sayfa && sayfa.sorular && excel && excel.ogrenciler) {
      const fazlaDolu = [];
      for (const o of excel.ogrenciler) {
        const puan = o.puan || [];
        for (let i = sayfaSoru; i < puan.length; i++) {
          if (norm(puan[i]) !== "") { fazlaDolu.push(o.no); break; }
        }
      }
      if (fazlaDolu.length) uyarilar.push("Excel'de sayfadaki soru sayısından (" + sayfaSoru + ") fazla dolu sütun yok sayıldı. Örn. Okul No: " + fazlaDolu.slice(0, 5).join(", "));
    }
    if (sayfa && sayfa.sorular && excel && excel.puanlar) {
      const n = Math.min(sayfaSoru, excel.puanlar.length);
      for (let i = 0; i < n; i++) {
        const ex = Number(excel.puanlar[i]);
        if (!ex) continue; // dışa aktarımda azami puan boş/0 bırakılır; doğrulama sayfa başlığından yapılır
        if (ex !== Number(sayfa.sorular[i].max)) {
          uyarilar.push((i + 1) + ". soru puanı Excel'de " + excel.puanlar[i] + ", sayfada " + sayfa.sorular[i].max + " (sayfa esas alınır).");
        }
      }
    }
    const harita = new Map(), cift = [];
    if (sayfa && sayfa.satirlar) {
      for (const s of sayfa.satirlar) {
        const k = noNorm(s.no);
        if (!k) continue;
        if (harita.has(k)) cift.push(s.no);
        else harita.set(k, s);
      }
    }
    if (cift.length) hatalar.push("Sayfada tekrarlayan Okul No: " + [...new Set(cift)].join(", "));
    const eslesme = [], excelNos = new Set();
    if (excel && excel.ogrenciler) {
      for (const o of excel.ogrenciler) {
        const k = noNorm(o.no);
        excelNos.add(k);
        const s = harita.get(k);
        if (!s) { bulunamayan.push(o.no); continue; }
        const kat = katilimCoz(o.katilim, o.puan);
        eslesme.push({ excel: o, sayfa: s, katilim: kat });
        const bosGirdi = girmediMi(kat);
        const girdi = katla(kat) === "sinava girdi";
        const nSoru = sayfaSoru || (excel.soruSayisi || 0);
        for (let i = 0; i < nSoru; i++) {
          const v = (o.puan || [])[i];
          const max = (sayfa.sorular && sayfa.sorular[i] && sayfa.sorular[i].max != null) ? sayfa.sorular[i].max : (excel.puanlar && excel.puanlar[i]);
          if (bosGirdi) {
            if (norm(v) !== "") uyarilar.push("Okul No " + o.no + ": " + (i + 1) + ". soruda puan var ama Katılım " + kat + ". Puan yazılmayacak.");
            continue;
          }
          const h = puanHata(v, max);
          if (h) hatalar.push("Okul No " + o.no + ", " + (i + 1) + ". soru: " + h);
          if (girdi && norm(v) === "") hatalar.push("Okul No " + o.no + ", " + (i + 1) + ". soru: puan boş.");
        }
      }
    }
    if (bulunamayan.length) hatalar.push("Excel'deki Okul No sayfada yok: " + bulunamayan.join(", "));
    if (sayfa && sayfa.satirlar) {
      for (const s of sayfa.satirlar) if (!excelNos.has(noNorm(s.no))) sayfadaFazla.push(s.no);
    }
    if (sayfadaFazla.length) uyarilar.push("Sayfada olup Excel'de olmayan Okul No (dokunulmayacak): " + sayfadaFazla.join(", "));
    return { ok: hatalar.length === 0, hatalar, uyarilar, eslesme, bulunamayan, sayfadaFazla };
  }

  function degerYaz(el, v) {
    if (!el || guvenlikAlaniMi(el)) return false;
    if (el.disabled || el.readOnly) return false;
    const w = el.ownerDocument.defaultView || kok;
    const proto = el.tagName === "SELECT" ? w.HTMLSelectElement.prototype : (el.tagName === "TEXTAREA" ? w.HTMLTextAreaElement.prototype : w.HTMLInputElement.prototype);
    const d = Object.getOwnPropertyDescriptor(proto, "value");
    try { el.focus && el.focus(); } catch (e) {}
    if (d && d.set) d.set.call(el, v); else el.value = v;
    for (const t of ["input", "change", "blur"]) {
      try { el.dispatchEvent(new w.Event(t, { bubbles: true })); } catch (e) {}
    }
    if (el.tagName === "SELECT") jqueryTetikle(el);
    return true;
  }
  function secenekYaz(sel, metin) {
    if (!sel || guvenlikAlaniMi(sel)) return false;
    const hedef = katla(katilimNorm(metin) || metin);
    if (!hedef) return false;
    const op = [...sel.options].find((o) => katla(o.text) === hedef || katla(o.value) === hedef);
    if (!op) return false;
    return degerYaz(sel, op.value);
  }

  async function yazVeKaydet(win, excel, opts) {
    opts = opts || {};
    const sayfa = sayfaOku(win);
    const k = kapilar(excel, sayfa);
    const rapor = { kaydedildi: false, yazilan: 0, ...k, sayfaOzet: sayfa ? { soru: (sayfa.sorular || []).length, ogrenci: (sayfa.satirlar || []).length, sube: sayfa.sube, ders: sayfa.ders, sinav: sayfa.sinav } : null };
    if (!k.ok) return rapor;
    const bekle = opts.bekle || ((ms) => new Promise((r) => setTimeout(r, ms)));
    const hiz = (opts.hiz && HIZ_BEKLE[opts.hiz]) ? opts.hiz : "hizli";
    const araMs = opts.araMs != null ? opts.araMs : HIZ_BEKLE[hiz];
    const kaydetMs = opts.kaydetMs != null ? opts.kaydetMs : HIZ_KAYDET[hiz];
    for (const e of k.eslesme) {
      const o = e.excel, s = e.sayfa;
      const kat = e.katilim || katilimCoz(o.katilim, o.puan);
      const bosGirdi = girmediMi(kat);
      if (s.select) { secenekYaz(s.select, kat); if (araMs) await bekle(araMs); }
      if (!bosGirdi) {
        const nYaz = (s.girdiler && s.girdiler.length) || (sayfa.sorular || []).length;
        for (let i = 0; i < nYaz; i++) {
          const inp = s.girdiler[i];
          if (!inp || guvenlikAlaniMi(inp)) continue;
          degerYaz(inp, puanYaz((o.puan || [])[i]));
          if (araMs) await bekle(araMs);
        }
      }
      rapor.yazilan++;
    }
    const mesgul = (sayfa.doc && sayfa.doc.documentElement && sayfa.doc.documentElement.getAttribute("data-eokul-mesgul") === "1")
      || (win.document && win.document.documentElement && win.document.documentElement.getAttribute("data-eokul-mesgul") === "1");
    if (mesgul) {
      rapor.hatalar = (rapor.hatalar || []).concat(["Sayfa meşgul (postback); Kaydet'e basılmadı."]);
      rapor.ok = false;
      return rapor;
    }
    const btn = sayfa.kaydetEl;
    if (!btn) {
      rapor.hatalar = (rapor.hatalar || []).concat(["Kaydet düğmesi bulunamadı."]);
      rapor.ok = false;
      return rapor;
    }
    if (guvenlikAlaniMi(btn) || katla(metinEl(btn)) !== "kaydet") {
      rapor.hatalar = (rapor.hatalar || []).concat(["Kaydet düğmesi güvenlik kontrolünden geçmedi; basılmadı."]);
      rapor.ok = false;
      return rapor;
    }
    if (kaydetMs) await bekle(kaydetMs);
    try { btn.click(); rapor.kaydedildi = true; } catch (e) {
      rapor.hatalar = (rapor.hatalar || []).concat(["Kaydet tıklanamadı: " + (e && e.message || e)]);
      rapor.ok = false;
    }
    return rapor;
  }

  function sutunHarf(n) {
    let s = "", x = n;
    while (x > 0) { x--; s = String.fromCharCode(65 + (x % 26)) + s; x = Math.floor(x / 26); }
    return s;
  }
  function satirSablonu(r) {
    const d = "D", last = "R", kat = "T", top = "S", kon = "U";
    let c = '<row r="' + r + '">';
    c += '<c r="A' + r + '" s="3"><f>IF(C' + r + '="","",ROW()-2)</f><v /></c>';
    c += '<c r="B' + r + '" s="3" t="n" />';
    c += '<c r="C' + r + '" s="3" t="n" />';
    for (let i = 4; i <= 18; i++) c += '<c r="' + sutunHarf(i) + r + '" s="4" t="n" />';
    c += '<c r="' + top + r + '" s="5"><f>IF(C' + r + '="","",IF(OR(' + kat + r + '="Sınava Girmedi",' + kat + r + '="Muaf"),"",SUM(' + d + r + ':' + last + r + ')))</f><v /></c>';
    c += '<c r="' + kat + r + '" s="3"><f>IF(C' + r + '="","",IF(COUNT(' + d + r + ':' + last + r + ')&gt;0,"Sınava Girdi","Sınava Girmedi"))</f><v /></c>';
    c += '<c r="' + kon + r + '" s="3"><f>IF(C' + r + '="","",IF(AND(' + kat + r + '="Sınava Girdi",COUNT(' + d + r + ':' + last + r + ')&lt;AYAR!$B$6),"Eksik puan",""))</f><v /></c>';
    c += '</row>';
    return c;
  }
  function hucreYer(xml, ref, icerik, tip) {
    const re = new RegExp('<c(\\s[^>]*\\br="' + ref + '"[^>/]*)\\s*(?:/>|>([\\s\\S]*?)</c>)');
    const m = xml.match(re);
    if (!m) return xml;
    let attrs = m[1];
    attrs = attrs.replace(/\s+t="[^"]*"/, "").replace(/\s*\/\s*$/, "");
    if (tip) attrs += ' t="' + tip + '"';
    return xml.replace(re, '<c' + attrs + '>' + icerik + '</c>');
  }
  function inlineYer(xml, ref, metin) {
    return hucreYer(xml, ref, '<is><t xml:space="preserve">' + xmlKac(metin) + '</t></is>', "inlineStr");
  }
  function sayiYer(xml, ref, n) {
    return hucreYer(xml, ref, '<v>' + String(n) + '</v>', "n");
  }
  function hucreSatiraYaz(xml, ref, metin) {
    if (new RegExp('r="' + ref + '"').test(xml)) return inlineYer(xml, ref, metin);
    const mref = String(ref).match(/^([A-Z]+)(\d+)$/);
    if (!mref) return xml;
    const row = mref[2];
    const cell = '<c r="' + ref + '" s="8" t="inlineStr"><is><t xml:space="preserve">' + xmlKac(metin) + '</t></is></c>';
    const re = new RegExp('(<row r="' + row + '"[^>]*>)([\s\S]*?)(</row>)');
    if (!re.test(xml)) return xml;
    return xml.replace(re, (_, a, b, c) => a + b + cell + c);
  }
  function araliklariGenislet(xml, son) {
    xml = xml.replace(/ref="A1:[PU]\d+"/, 'ref="A1:U' + son + '"');
    xml = xml.replace(/sqref="([D-U])3:\1\d+"/g, (_, col) => 'sqref="' + col + '3:' + col + son + '"');
    xml = xml.replace(/sqref="T3:T\d+"/, 'sqref="T3:T' + son + '"');
    xml = xml.replace(/sqref="O3:O\d+"/, 'sqref="O3:O' + son + '"');
    return xml;
  }

  async function sablonDoldur(sablonBuf, meta, xlsxApi) {
    const api = xlsxApi || kok.EvrakXlsx;
    if (!api || !api.ac || !api.zip) throw new Error("EvrakXlsx.ac / zip yok.");
    const te = new TextEncoder(), td = new TextDecoder();
    const z = await api.ac(sablonBuf);
    let ayar = td.decode(z["xl/worksheets/sheet2.xml"]);
    let notlar = td.decode(z["xl/worksheets/sheet1.xml"]);
    ayar = inlineYer(ayar, "B3", meta.sube || "");
    ayar = inlineYer(ayar, "B4", meta.ders || "");
    ayar = inlineYer(ayar, "B5", meta.sinav || "");
    const soruSayisi = Math.max(1, Math.min(MAX_SORU, Number(meta.soruSayisi) || (meta.puanlar || []).length || MAX_SORU));
    ayar = sayiYer(ayar, "B6", soruSayisi);
    const puanlar = meta.puanlar || [];
    for (let i = 0; i < MAX_SORU; i++) ayar = sayiYer(ayar, "B" + (9 + i), i < soruSayisi ? (Number(puanlar[i]) || 0) : 0);
    const dersListe = meta.dersListesi || oyssDersAdlari(meta.sube);
    for (let i = 0; i < 10; i++) ayar = hucreSatiraYaz(ayar, "F" + (9 + i), dersListe[i] || "");
    const ogr = meta.ogrenciler || [];
    const son = Math.max(SABLON_SATIR, 2 + Math.max(ogr.length, 1));
    if (son > SABLON_SATIR) {
      let ek = "";
      for (let r = SABLON_SATIR + 1; r <= son; r++) ek += satirSablonu(r);
      if (!notlar.includes("</sheetData>")) throw new Error("Şablon sheetData kapanışı yok.");
      notlar = notlar.replace("</sheetData>", ek + "</sheetData>");
      notlar = araliklariGenislet(notlar, son);
    }
    for (let i = 0; i < ogr.length; i++) {
      const r = 3 + i;
      notlar = inlineYer(notlar, "B" + r, ogr[i].no || "");
      notlar = inlineYer(notlar, "C" + r, ogr[i].ad || "");
    }
    z["xl/worksheets/sheet2.xml"] = te.encode(ayar);
    z["xl/worksheets/sheet1.xml"] = te.encode(notlar);
    const dosyalar = Object.keys(z).filter((k) => z[k]).map((ad) => ({ ad, veri: z[ad] instanceof Uint8Array ? z[ad] : te.encode(String(z[ad])) }));
    return api.zip(dosyalar);
  }


  function dosyaGovenliParca(s) {
    return String(s || "").replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, "_").replace(/[._]+$/g, "").replace(/^_+|_+$/g, "").slice(0, 50);
  }
  function dosyaAdiGuvenli(ad, yedek) {
    let s = String(ad || yedek || "OYSS.xlsx");
    s = s.replace(/[\\/:*?"<>|]+/g, "_").replace(/[\u0000-\u001f]/g, "");
    s = s.replace(/^.*[\\/]/, "");
    const nokta = s.lastIndexOf(".");
    let taban = nokta > 0 ? s.slice(0, nokta) : s;
    let uzanti = nokta > 0 ? s.slice(nokta) : ".xlsx";
    taban = taban.replace(/[.\s]+$/g, "").replace(/^[.\s]+/g, "") || "OYSS";
    uzanti = uzanti.replace(/[.\s]+$/g, "") || ".xlsx";
    if (uzanti.charAt(0) !== ".") uzanti = "." + uzanti;
    return (taban + uzanti).slice(0, 150);
  }
  function alanAyir(subeMetin) {
    const ham = norm(subeMetin);
    const m = ham.match(/^(.*?)\s*\((.*)\)\s*$/);
    if (!m) return { sube: ham, alan: "" };
    const alan = norm(m[2]);
    const bosAlan = !alan || alan === "-" || alan === "—";
    return { sube: norm(m[1]), alan: bosAlan ? "" : alan };
  }
  function benzersizSayfaAdi(sube, ders, kullanilan) {
    const tem = (s) => String(s || "").replace(/[:\\/?*\[\]]+/g, " ").replace(/\s+/g, " ").trim();
    let base = [tem(sube), tem(ders)].filter(Boolean).join("_") || "Liste";
    if (base.length > 31) base = base.slice(0, 31);
    let ad = base, i = 2;
    const varMi = (a) => kullanilan.has(a) || kullanilan.has(katla(a));
    while (varMi(ad)) { const ek = "_" + i; ad = base.slice(0, 31 - ek.length) + ek; i++; }
    return ad;
  }
  function dosyaAdiGrup(g) {
    const a = alanAyir(g && g.sube);
    const par = [dosyaGovenliParca(a.sube) || "Sube", dosyaGovenliParca(a.alan), dosyaGovenliParca(g && g.ders) || "Ders"].filter(Boolean);
    return par.join("_") + ".xlsx";
  }
  function dosyaAdiSube(g) {
    const a = alanAyir(g && g.sube);
    const par = [dosyaGovenliParca(a.sube) || "Sube", dosyaGovenliParca(a.alan)].filter(Boolean);
    return par.join("_") + ".xlsx";
  }
  async function sablonCokluZip(sablonBuf, gruplar, xlsxApi) {
    const api = xlsxApi || kok.EvrakXlsx;
    const kume = new Map();
    for (const g of gruplar || []) {
      const k = katla(g && g.sube);
      if (!kume.has(k)) kume.set(k, []);
      kume.get(k).push(g);
    }
    const kullanilan = new Set(), dosyalar = [];
    for (const gs of kume.values()) {
      let ad = dosyaAdiSube(gs[0]), taban = ad.replace(/\.xlsx$/i, ""), n = 2;
      while (kullanilan.has(katla(ad))) { ad = taban + "_" + n + ".xlsx"; n++; }
      kullanilan.add(katla(ad));
      const buf = await sablonCokluKitap(sablonBuf, gs, api);
      dosyalar.push({ ad, veri: buf instanceof Uint8Array ? buf : new Uint8Array(buf) });
    }
    if (!dosyalar.length) throw new Error("Aktarılacak şube/ders yok.");
    return { zip: api.zip(dosyalar), dosyalar: dosyalar.map((d) => d.ad) };
  }
  async function sablonCokluKitap(sablonBuf, gruplar, xlsxApi) {
    const api = xlsxApi || kok.EvrakXlsx;
    if (!gruplar || !gruplar.length) throw new Error("Aktarılacak şube/ders yok.");
    if (gruplar.length === 1) return sablonDoldur(sablonBuf, gruplar[0], api);
    const te = new TextEncoder(), td = new TextDecoder();
    const z0 = await api.ac(sablonBuf);
    const dosya = {};
    for (const k of Object.keys(z0)) {
      if (/^xl\/worksheets\/sheet\d+\.xml$/.test(k)) continue;
      if (k === "xl/workbook.xml" || k === "xl/_rels/workbook.xml.rels" || k === "[Content_Types].xml") continue;
      dosya[k] = z0[k];
    }
    const sheets = [];
    let ridN = 1;
    const kullanilan = new Set();
    for (let i = 0; i < gruplar.length; i++) {
      const z = await api.ac(await sablonDoldur(sablonBuf, gruplar[i], api));
      const ayarAd = "AYAR_" + String(i + 1).padStart(2, "0");
      const notAd = benzersizSayfaAdi(gruplar[i].sube, gruplar[i].ders, kullanilan);
      kullanilan.add(ayarAd); kullanilan.add(notAd);
      const notlar = td.decode(z["xl/worksheets/sheet1.xml"]).replace(/AYAR!/g, "'" + ayarAd.replace(/'/g, "''") + "'!");
      const ayarPath = "xl/worksheets/ayar_" + (i + 1) + ".xml";
      const notPath = "xl/worksheets/not_" + (i + 1) + ".xml";
      dosya[ayarPath] = z["xl/worksheets/sheet2.xml"];
      dosya[notPath] = te.encode(notlar);
      const rAyar = "rId" + (ridN++), rNot = "rId" + (ridN++);
      sheets.push({ name: ayarAd, path: ayarPath, rid: rAyar, id: i * 2 + 1 });
      sheets.push({ name: notAd, path: notPath, rid: rNot, id: i * 2 + 2 });
    }
    const styleRid = "rId" + (ridN++), themeRid = "rId" + (ridN++);
    let wb = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><workbookPr/><bookViews><workbookView firstSheet="0" activeTab="1"/></bookViews><sheets>';
    for (const s of sheets) wb += '<sheet name="' + xmlKac(s.name) + '" sheetId="' + s.id + '" r:id="' + s.rid + '"/>';
    wb += '</sheets><definedNames/><calcPr calcId="124519" fullCalcOnLoad="1"/></workbook>';
    let rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
    for (const s of sheets) rels += '<Relationship Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="/' + s.path + '" Id="' + s.rid + '"/>';
    rels += '<Relationship Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml" Id="' + styleRid + '"/>';
    rels += '<Relationship Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml" Id="' + themeRid + '"/>';
    rels += "</Relationships>";
    let ct = td.decode(z0["[Content_Types].xml"]);
    ct = ct.replace(/<Override PartName="\/xl\/worksheets\/[^"]+"[^>]*\/>/g, "");
    ct = ct.replace("</Types>", sheets.map((s) => '<Override PartName="/' + s.path + '" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join("") + "</Types>");
    dosya["xl/workbook.xml"] = te.encode(wb);
    dosya["xl/_rels/workbook.xml.rels"] = te.encode(rels);
    dosya["[Content_Types].xml"] = te.encode(ct);
    return api.zip(Object.keys(dosya).filter((k) => dosya[k]).map((ad) => ({ ad, veri: dosya[ad] instanceof Uint8Array ? dosya[ad] : te.encode(String(dosya[ad])) })));
  }

  function yaziSade(s) {
    return katla(s).replace(/[:*]+/g, " ").replace(/[\/\\|,._-]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function etiketMetin(n) {
    if (!n) return "";
    const parca = [];
    const gez = (x) => {
      if (!x) return;
      if (x.nodeType === 3) { parca.push(x.textContent); return; }
      if (x.nodeType !== 1) return;
      const tag = x.tagName;
      if (/^(SCRIPT|STYLE|SELECT|OPTION|TEXTAREA|SVG|BUTTON|INPUT)$/.test(tag)) return;
      for (const c of x.childNodes) gez(c);
    };
    gez(n);
    return norm(parca.join(" "));
  }
  function yakinEtiket(sel) {
    if (!sel) return "";
    const doc = sel.ownerDocument;
    const bits = [];
    const ekle = (n) => { const t = typeof n === "string" ? norm(n) : etiketMetin(n); if (t) bits.push(t); };
    try { if (sel.labels) for (const l of sel.labels) ekle(l); } catch (e) {}
    if (sel.id && doc.getElementById) {
      try {
        const kac = (typeof CSS !== "undefined" && CSS.escape) ? CSS.escape(sel.id) : sel.id.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
        const l = doc.querySelector('label[for="' + kac + '"]');
        if (l) ekle(l);
      } catch (e) {}
    }
    const wrap = sel.closest && sel.closest("label");
    if (wrap) ekle(wrap);
    ekle(sel.getAttribute && (sel.getAttribute("aria-label") || sel.title || ""));
    const lid = sel.getAttribute && sel.getAttribute("aria-labelledby");
    if (lid && doc.getElementById) lid.split(/\s+/).forEach((id) => { const n = doc.getElementById(id); if (n) ekle(n); });
    let dugum = sel;
    for (let up = 0; up < 4 && dugum && dugum !== doc.body && dugum !== doc.documentElement; up++) {
      let p = dugum.previousElementSibling, adim = 0;
      while (p && adim < 4) {
        if (!p.querySelector || !p.querySelector("select")) ekle(p);
        else if (/^(LABEL|LEGEND|SPAN|B|STRONG|H2|H3|H4|H5)$/.test(p.tagName)) ekle(p);
        p = p.previousElementSibling; adim++;
      }
      const ust = dugum.parentElement;
      if (ust) {
        const et = [...(ust.children || [])].find((c) => /^(LABEL|LEGEND)$/.test(c.tagName) && !c.contains(sel));
        if (et) ekle(et);
      }
      dugum = ust;
      if (dugum && /^(FORM|BODY|HTML|TABLE)$/.test(dugum.tagName)) break;
    }
    return bits.join(" ");
  }
  function subeSecenekDeseni(text) {
    const t = yaziSade(text);
    if (!t || /^seciniz|^secin$|^--/.test(t)) return false;
    if (/\d+\s*sinif/.test(t) && /sube/.test(t)) return true;
    const k = katla(text).replace(/\s+/g, "");
    if (/^\d+[./-]?[a-z]$/.test(k)) return true;
    return false;
  }
  function katilimSelectMi(sel) {
    if (!sel || !sel.options) return false;
    const ops = [...sel.options].map((o) => katla(o.text));
    return ops.some((t) => t === "sinava girdi") && ops.some((t) => t === "sinava girmedi" || t === "kopya" || t === "muaf");
  }
  function selectKimlik(sel) {
    return katla([sel && sel.id, sel && sel.name, sel && sel.className].filter(Boolean).join(" "));
  }
  function selectSkor(sel, rol) {
    if (!sel || katilimSelectMi(sel) || guvenlikAlaniMi(sel) || eklentiElemaniMi(sel) || subeSinavDurumuMu(sel)) return -100;
    const idn = selectKimlik(sel);
    const yakin = yaziSade(yakinEtiket(sel));
    const ops = [...sel.options].map((o) => norm(o.text));
    let skor = 0;
    const idHas = (k) => idn.replace(/[^a-z0-9]/g, " ").split(/\s+/).includes(k) || idn.replace(/[^a-z0-9]/g, "").includes(k);
    if (rol === "sube") {
      if (idHas("sube") || idHas("sinifsube") || idHas("sinif") && idHas("sube")) skor += 8;
      else if (idHas("sinif")) skor += 5;
      if (idHas("sinav") && !idHas("sube")) skor -= 10;
      if (idHas("ders") && !idHas("sube") && !idHas("sinif")) skor -= 10;
      if (/\bsinif\b/.test(yakin) || /\bsube\b/.test(yakin)) skor += 7;
      if (ops.some(subeSecenekDeseni)) skor += 8;
      if (/\bsinav\b/.test(yakin) && !/\bsube\b/.test(yakin) && !/\bsinif\b/.test(yakin)) skor -= 6;
      if (/\bders\b/.test(yakin) && !/\bsube\b/.test(yakin) && !/\bsinif\b/.test(yakin)) skor -= 6;
    } else if (rol === "ders") {
      if (idHas("ders")) skor += 8;
      if (idHas("sube") || idHas("sinif")) skor -= 8;
      if (idHas("sinav")) skor -= 8;
      if (/\bders\b/.test(yakin)) skor += 7;
      if (/\bsinif\b/.test(yakin) && /\bsube\b/.test(yakin) && !/\bders\b/.test(yakin)) skor -= 6;
      if (ops.some(subeSecenekDeseni) && !/\bders\b/.test(yakin) && !idHas("ders")) skor -= 8;
    } else if (rol === "sinav") {
      if (idHas("sinav") && !idHas("getir")) skor += 8;
      if (idHas("sube") || idHas("sinif") || idHas("ders")) skor -= 8;
      if (/\bsinav\b/.test(yakin) && !/sinavlari getir/.test(yakin) && !/sube sinav durumu/.test(yakin)) skor += 7;
      if (ops.some((o) => /donem|ortak yazili|oturum|yazili sinav|performans/.test(yaziSade(o)))) skor += 4;
      if (ops.some((o) => /\d{4}\s*-\s*\d{4}/.test(o))) skor -= 12; // "2026-2027 I. Dönem" (Eğitim Öğretim Dönemi) sınav değildir
      if (/egitim ogretim donemi|okul turu/.test(yakin)) skor -= 12;
    }
    return skor;
  }
  function alSelectYakin(n, doc) {
    if (!n) return null;
    if (n.querySelector) {
      const ic = n.querySelector("select");
      if (ic && !guvenlikAlaniMi(ic) && !katilimSelectMi(ic)) return ic;
    }
    const forId = n.getAttribute && n.getAttribute("for");
    if (forId) {
      const hedef = doc.getElementById(forId);
      if (hedef && hedef.tagName === "SELECT" && !guvenlikAlaniMi(hedef)) return hedef;
    }
    const tr = n.closest && n.closest("tr");
    if (tr) {
      const hucreler = [...tr.children];
      const idx = hucreler.findIndex((c) => c === n || c.contains(n));
      if (idx >= 0) {
        for (let j = idx; j < hucreler.length; j++) {
          const s = hucreler[j].tagName === "SELECT" ? hucreler[j] : hucreler[j].querySelector && hucreler[j].querySelector("select");
          if (s && !guvenlikAlaniMi(s) && !katilimSelectMi(s)) return s;
        }
      }
    }
    let p = n.nextElementSibling, adim = 0;
    while (p && adim < 3) {
      const s = p.tagName === "SELECT" ? p : (p.querySelector && p.querySelector("select"));
      if (s && !guvenlikAlaniMi(s) && !katilimSelectMi(s)) return s;
      p = p.nextElementSibling; adim++;
    }
    const ust = n.parentElement;
    if (ust) {
      const sels = [...ust.querySelectorAll("select")].filter((s) => !guvenlikAlaniMi(s) && !katilimSelectMi(s));
      if (sels.length === 1) return sels[0];
    }
    return null;
  }
  function etiketUyarMi(sade, kabulK, haricK) {
    if (!sade || sade.length > 80) return false;
    const kelime = sade.split(" ");
    if (haricK.some((h) => {
      const hh = yaziSade(h);
      return hh && (sade === hh || sade.startsWith(hh + " ") || (hh.length > 5 && sade.includes(hh)));
    })) return false;
    return kabulK.some((k) => {
      const kk = yaziSade(k);
      if (!kk) return false;
      if (sade === kk || sade.startsWith(kk + " ") || sade.endsWith(" " + kk)) return true;
      if (kelime.length <= 3 && (" " + sade + " ").includes(" " + kk + " ")) return true;
      return false;
    });
  }
  function etiketSelect(doc, kabul, haric) {
    const kabulK = kabul.map(katla), haricK = (haric || []).map(katla);
    const adaylar = [...doc.querySelectorAll("label,td,th,span,div,b,strong,legend,p,h2,h3,h4,h5")];
    for (const n of adaylar) {
      if (eklentiElemaniMi(n)) continue;
      const sade = yaziSade(etiketMetin(n));
      if (!etiketUyarMi(sade, kabulK, haricK)) continue;
      const sel = alSelectYakin(n, doc);
      if (sel && !eklentiElemaniMi(sel)) return sel;
    }
    return null;
  }
  function jqueryTetikle(el) {
    if (!el) return;
    const w = (el.ownerDocument && el.ownerDocument.defaultView) || kok;
    try {
      const $ = w.jQuery || w.$;
      if ($ && $.fn) $(el).val(el.value).trigger("change");
    } catch (e) {}
    try {
      const tok = "oyss" + Date.now().toString(36) + Math.random().toString(16).slice(2, 8);
      el.setAttribute("data-eoa-oyss-sel", tok);
      w.postMessage({ kaynak: "eokul-eklenti-komut", islem: "select-change", token: tok, deger: el.value }, "*");
      setTimeout(() => { try { if (el.getAttribute("data-eoa-oyss-sel") === tok) el.removeAttribute("data-eoa-oyss-sel"); } catch (e) {} }, 800);
    } catch (e) {}
  }
  function dugmeBul(doc, metinler) {
    const hedefler = metinler.map((m) => yaziSade(m));
    const adaylar = [...doc.querySelectorAll("input[type=submit],input[type=button],input[type=image],button,a")];
    for (const e of adaylar) {
      if (guvenlikAlaniMi(e) || eklentiElemaniMi(e)) continue;
      const t = yaziSade(metinEl(e) || e.value || e.getAttribute && e.getAttribute("value") || "");
      if (!t) continue;
      if (/kaydet|kapat|imza|paraf|sil|iptal/.test(t) && !hedefler.some((h) => t === h)) continue;
      if (hedefler.some((h) => t === h || t.includes(h))) return e;
    }
    return null;
  }
  function secenekBosMu(text) {
    const k = katla(text);
    return !k || /^seciniz|^--|^secin$|^ders secin/.test(k);
  }
  function selectSecenekler(sel) {
    if (!sel) return [];
    return [...sel.options].map((o, index) => ({ value: o.value, text: norm(o.text), index }))
      .filter((o) => o.text && !secenekBosMu(o.text));
  }
  function selectSecenekBul(sel, hedef) {
    if (!sel || !hedef) return null;
    const ops = [...sel.options];
    if (typeof hedef === "object") {
      if (hedef.index != null && ops[hedef.index] && norm(ops[hedef.index].text) === norm(hedef.text || ops[hedef.index].text)) return ops[hedef.index];
      if (hedef.value != null && hedef.value !== "") {
        const ayni = ops.filter((o) => String(o.value) === String(hedef.value));
        if (ayni.length === 1) return ayni[0];
      }
      if (hedef.text) hedef = hedef.text;
      else return null;
    }
    const h = katla(hedef), hs = yaziSade(hedef);
    const tam = ops.find((o) => katla(o.text) === h || katla(o.value) === h) || ops.find((o) => yaziSade(o.text) === hs);
    if (tam) return tam;
    const ic = ops.filter((o) => !secenekBosMu(o.text) && (katla(o.text).includes(h) || h.includes(katla(o.text))));
    return ic.length === 1 ? ic[0] : null;
  }
  function selectRolSec(adaylar) {
    const kullanilan = new Set();
    const al = (rol, min) => {
      let best = null, sk = min - 1;
      for (const s of adaylar) {
        if (kullanilan.has(s)) continue;
        const v = selectSkor(s, rol);
        if (v > sk) { sk = v; best = s; }
      }
      if (best && sk >= min) { kullanilan.add(best); return best; }
      return null;
    };
    return { subeSel: al("sube", 3), dersSel: al("ders", 3), sinavSel: al("sinav", 3) };
  }
  function kontroller(win) {
    const docs = belgeler(win);
    const adaylar = [];
    for (const d of docs) {
      for (const s of d.querySelectorAll("select")) {
        if (!guvenlikAlaniMi(s) && !katilimSelectMi(s) && !eklentiElemaniMi(s)) adaylar.push(s);
      }
    }
    const roller = selectRolSec(adaylar);
    const bulSel = (kabul, haric) => {
      for (const d of docs) { const s = etiketSelect(d, kabul, haric); if (s && !katilimSelectMi(s)) return s; }
      return null;
    };
    const bulBtn = (metinler) => { for (const d of docs) { const b = dugmeBul(d, metinler); if (b) return b; } return null; };
    if (!roller.subeSel) roller.subeSel = bulSel(["şube", "sube", "sınıf / şube", "sinif / sube", "sınıf/şube", "sinif/sube", "şubesi", "subesi"], ["şube sınav", "sube sinav"]);
    if (!roller.dersSel) roller.dersSel = bulSel(["ders"], []);
    if (!roller.sinavSel) roller.sinavSel = bulSel(["sınav", "sinav"], ["sinavlari getir", "sınavları getir", "sube sinav durumu", "şube sınav durumu"]);
    return {
      docs,
      subeSel: roller.subeSel,
      dersSel: roller.dersSel,
      sinavSel: roller.sinavSel,
      getirBtn: bulBtn(["sınavları getir", "sinavlari getir"]),
      yukleBtn: bulBtn(["öğrenci listesi yükle", "ogrenci listesi yukle"]),
    };
  }
  function taniRaporu(win) {
    const docs = belgeler(win);
    const satir = [];
    const yol = () => { try { return (win && win.location && win.location.pathname) || (docs[0] && docs[0].location && docs[0].location.pathname) || ""; } catch (e) { return ""; } };
    const kimlik = (() => {
      try {
        if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getManifest) {
          const mf = chrome.runtime.getManifest();
          if (mf && mf.version) return ((mf.short_name || mf.name || "eklenti") + " " + mf.version).trim();
        }
      } catch (e) {}
      return "sürüm okunamadı";
    })();
    satir.push("OYSS tanı raporu — " + kimlik + " (öğrenci verisi yok) " + new Date().toISOString());
    satir.push("Sürüm (getManifest): " + kimlik);
    satir.push("Yol: " + yol());
    const k = kontroller(win);
    const kim = (sel, ad) => {
      if (!sel) return ad + ": (bulunamadı)";
      const ops = selectSecenekler(sel);
      const ilk = [...sel.options].slice(0, 3).map((o) => norm(o.text)).join(" | ");
      return ad + ": id=" + (sel.id || "—") + " name=" + (sel.name || "—") + " görünür=" + (sel.offsetParent !== null || (sel.offsetWidth + sel.offsetHeight) > 0 ? "evet" : "gizli/sifir") + " seçenek=" + sel.options.length + " (anlamlı " + ops.length + ") ilk3=[" + ilk + "]";
    };
    satir.push("Tespit:");
    satir.push("  " + kim(k.subeSel, "Şube"));
    satir.push("  " + kim(k.dersSel, "Ders"));
    satir.push("  " + kim(k.sinavSel, "Sınav"));
    satir.push("  Sınavları Getir: " + (k.getirBtn ? (k.getirBtn.id || "") + " / " + norm(metinEl(k.getirBtn) || k.getirBtn.value || "") : "(bulunamadı)"));
    satir.push("  Öğrenci Listesi Yükle: " + (k.yukleBtn ? (k.yukleBtn.id || "") + " / " + norm(metinEl(k.yukleBtn) || k.yukleBtn.value || "") : "(bulunamadı)"));
    const sayfa = sayfaOku(win);
    satir.push("OYSS tablosu: " + (sayfa && sayfa.satirlar && sayfa.satirlar.length ? ("var, satır=" + sayfa.satirlar.length + ", soru=" + (sayfa.sorular || []).length) : "yok"));
    let si = 0;
    for (const d of docs) {
      si++;
      satir.push("— belge " + si + " —");
      const etiketler = [...d.querySelectorAll("label,legend,.control-label")].map((n) => etiketMetin(n)).filter((x) => x && x.length <= 80).slice(0, 30);
      if (etiketler.length) satir.push("Etiketler: " + etiketler.join(" · "));
      const sels = [...d.querySelectorAll("select")];
      satir.push("Select sayısı: " + sels.length);
      sels.forEach((s, i) => {
        if (i >= 20) return;
        const ilk = [...s.options].slice(0, 3).map((o) => norm(o.text)).join(" | ");
        const yakin = yazinKisalt(yakinEtiket(s));
        const ek = eklentiElemaniMi(s) ? " [eklenti, yok sayılır] " : " ";
        satir.push("  select#" + i + ek + "id=" + (s.id || "—") + " name=" + (s.name || "—") + " class=" + norm(s.className || "").slice(0, 80) + " n=" + s.options.length + " ilk3=[" + ilk + "] yakın=[" + yakin + "]");
      });
      const dugmeler = [...d.querySelectorAll("input[type=submit],input[type=button],input[type=image],button,a")];
      const metinler = [];
      for (const e of dugmeler) {
        const tx = norm(metinEl(e) || e.value || "");
        if (!tx || tx.length > 80) continue;
        if (/okul no|adi soyadi|öğrenci no/i.test(tx)) continue;
        metinler.push(tx);
        if (metinler.length >= 25) break;
      }
      if (metinler.length) satir.push("Düğmeler: " + metinler.join(" · "));
    }
    satir.push("");
    satir.push("— İçe aktarma günlüğü —");
    if (!iceGunluk.length) satir.push("  (bu oturumda içe aktarma denemesi yok)");
    else iceGunluk.forEach((g) => {
      const bas = iceDurumEtiket(g.durum);
      satir.push("  " + bas + " " + [g.dosya, g.sube, g.ders].filter(Boolean).join(" / ") + (g.neden ? " — " + g.neden : ""));
    });
    satir.push("");
    satir.push("— İndirme günlüğü —");
    if (!indirGunluk.length) satir.push("  (bu oturumda indirme denemesi yok)");
    else indirGunluk.slice(-15).forEach((g) => {
      satir.push("  " + (g.t || "") + " " + (g.adim || "") + " " + (g.ok ? "TAMAM" : "HATA") + (g.ad ? " " + g.ad : "") + (g.bayt != null ? " " + g.bayt + " bayt" : "") + (g.id ? " id=" + g.id : "") + (g.hata ? " — " + g.hata : ""));
    });
    try {
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
        satir.push("  (SW günlüğü tanı anında ayrıca istenebilir)");
      }
    } catch (e) {}
    return satir.join("\n");
  }
  function yazinKisalt(s) {
    const t = norm(s);
    return t.length > 80 ? t.slice(0, 77) + "…" : t;
  }
  function mesgulMu(win) {
    for (const d of belgeler(win)) {
      if (d.documentElement && d.documentElement.getAttribute("data-eokul-mesgul") === "1") return true;
    }
    return false;
  }
  async function postbackBekle(win, bekle, opts) {
    opts = opts || {};
    const max = opts.maxMs || 15000, oturma = opts.oturma != null ? opts.oturma : 280;
    const t0 = Date.now();
    await bekle(40);
    let basladi = mesgulMu(win);
    const baslangicSon = Date.now() + (opts.baslangicMs != null ? opts.baslangicMs : 280);
    while (!basladi && Date.now() < baslangicSon && Date.now() - t0 < max) {
      await bekle(50);
      basladi = mesgulMu(win);
      if (!basladi && opts.bekleSelect) {
        const sel = opts.bekleSelect();
        const ops = selectSecenekler(sel);
        if (opts.oncekiFoto != null && fotoSelect(sel) !== opts.oncekiFoto && ops.length) { basladi = "foto"; break; }
      }
    }
    while (Date.now() - t0 < max) {
      if (!mesgulMu(win)) {
        if (opts.bekleSelect) {
          const ops = selectSecenekler(opts.bekleSelect());
          if (!ops.length && basladi && basladi !== "foto" && Date.now() - t0 < max) { await bekle(120); continue; }
        }
        await bekle(oturma);
        if (!mesgulMu(win)) return true;
      }
      await bekle(120);
    }
    return false;
  }
  function fotoSelect(sel) {
    if (!sel) return "";
    return [...sel.options].map((o) => (o.value || "") + "|" + norm(o.text)).join(";") + "#n=" + sel.options.length;
  }
  function optionYaz(sel, op) {
    if (!sel || !op || guvenlikAlaniMi(sel) || eklentiElemaniMi(sel)) return false;
    const w = (sel.ownerDocument && sel.ownerDocument.defaultView) || kok;
    const ops = [...sel.options];
    const idx = ops.indexOf(op);
    if (idx < 0) return false;
    if (sel.selectedIndex === idx && katla((ops[idx] && ops[idx].text) || "") === katla(op.text)) return true;
    try { sel.focus && sel.focus(); } catch (e) {}
    try {
      const d = Object.getOwnPropertyDescriptor(w.HTMLSelectElement.prototype, "selectedIndex");
      if (d && d.set) d.set.call(sel, idx); else sel.selectedIndex = idx;
    } catch (e) { sel.selectedIndex = idx; }
    if (op.value) {
      try {
        const dv = Object.getOwnPropertyDescriptor(w.HTMLSelectElement.prototype, "value");
        if (dv && dv.set) dv.set.call(sel, op.value);
      } catch (e) {}
    }
    for (const ev of ["input", "change", "blur"]) {
      try { sel.dispatchEvent(new w.Event(ev, { bubbles: true })); } catch (e) {}
    }
    jqueryTetikle(sel);
    return true;
  }
  async function secenekBekle(selFn, bekle, opts) {
    opts = opts || {};
    const max = opts.maxMs || 15000;
    const min = opts.minAnlamli != null ? opts.minAnlamli : 1;
    const onceki = opts.oncekiFoto;
    const t0 = Date.now();
    const uygun = () => {
      const sel = typeof selFn === "function" ? selFn() : selFn;
      if (!sel) return false;
      if (selectSecenekler(sel).length < min) return false;
      if (opts.degismeli && onceki != null && fotoSelect(sel) === onceki) return false;
      return true;
    };
    if (uygun() && !opts.degismeli) return true;
    let mo = null;
    const bagla = () => {
      try { if (mo) mo.disconnect(); } catch (e) {}
      const sel = typeof selFn === "function" ? selFn() : selFn;
      if (!sel || typeof MutationObserver === "undefined") return;
      mo = new MutationObserver(() => {});
      try {
        mo.observe(sel, { childList: true, subtree: true, characterData: true, attributes: true });
        if (sel.parentNode) mo.observe(sel.parentNode, { childList: true, subtree: true });
      } catch (e) {}
    };
    bagla();
    try {
      while (Date.now() - t0 < max) {
        if (uygun()) {
          // ders listesi aynı kalsa bile seçenekler durağanlaştıysa devam
          if (!opts.degismeli || fotoSelect(typeof selFn === "function" ? selFn() : selFn) !== onceki || Date.now() - t0 > 900) {
            await bekle(opts.oturma != null ? Math.min(200, opts.oturma) : 180);
            if (uygun() || (!opts.degismeli && selectSecenekler(typeof selFn === "function" ? selFn() : selFn).length >= min)) return true;
          }
        }
        await bekle(120);
        bagla();
      }
    } finally { try { if (mo) mo.disconnect(); } catch (e) {} }
    return uygun() || (selectSecenekler(typeof selFn === "function" ? selFn() : selFn).length >= min && !opts.zorunluDegisim);
  }
  // Canlı metin: "(OYSS Yazılı Sınav (Asıl)) 1. Dönem 1. Ortak Yazılı Sınavı - Sabah Oturumu"
  // 1.9.5: kullanıcının sayfada seçtiği sınav (aynı dönem/yazılı/oturum) önceliklidir.
  function sinavAsilBul(sel, tercihMetin) {
    if (!sel) return null;
    const ops = selectSecenekler(sel);
    if (tercihMetin) {
      const sade = (x) => katla(x).replace(/[^a-z0-9]+/g, " ").trim();
      const govde = (x) => sade(x).replace(/^oyss yazili sinav asil\s*/, "");
      const h = sade(tercihMetin);
      const ayni = ops.find((o) => sade(o.text) === h)
        || ops.find((o) => { const t = govde(o.text); return t && t === govde(tercihMetin); });
      if (ayni) return selectSecenekBul(sel, ayni);
    }
    const tercih = ops.find((o) => /oyss/.test(katla(o.text)) && /asil/.test(katla(o.text)))
      || ops.find((o) => /ortak yazili/.test(yaziSade(o.text)) && !/telafi|mazeret/.test(yaziSade(o.text)))
      || ops.find((o) => /oyss/.test(katla(o.text)))
      || ops[0];
    return tercih ? selectSecenekBul(sel, tercih) : null;
  }
  function subeSinavDurumuMu(el) {
    if (!el) return false;
    const t = yaziSade(yakinEtiket(el) + " " + alanMetin(el));
    return /sube sinav durumu/.test(t);
  }
  function kapatDugmesiMi(el) {
    const t = yaziSade(metinEl(el) || (el && el.value) || "");
    return /kapat/.test(t) && /subenin|soru bazli not girisini kapat|secili sube/.test(t);
  }
  function u8b64(u8) {
    let s = "";
    const CH = 0x8000;
    for (let i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
    return btoa(s);
  }
  const indirGunluk = [];
  function indirKaydet(kayit) {
    const row = Object.assign({ t: new Date().toISOString() }, kayit);
    indirGunluk.push(row);
    if (indirGunluk.length > 40) indirGunluk.shift();
    return row;
  }
  async function dosyaIndir(ad, buf, tur) {
    const mime = tur || "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    const blob = buf instanceof Blob ? buf : new Blob([buf], { type: mime });
    const guvenliAd = dosyaAdiGuvenli(ad, "OYSS.xlsx");
    let sonHata = "";
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
      try {
        const ab = buf instanceof Blob ? await buf.arrayBuffer() : (buf instanceof ArrayBuffer ? buf : (buf && buf.buffer ? buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) : buf));
        const u8 = ab instanceof Uint8Array ? ab : new Uint8Array(ab);
        const b64 = u8b64(u8);
        const r = await chrome.runtime.sendMessage({ tip: "oyss-indir", ad: guvenliAd, veri: b64, tur: mime });
        if (r && r.ok) {
          indirKaydet({ adim: "sw", ok: true, ad: r.ad || guvenliAd, id: r.id, bayt: u8.length });
          return { ok: true, ad: r.ad || guvenliAd, id: r.id };
        }
        sonHata = (r && r.hata) || (r == null ? "service worker yanıt vermedi" : "indirme reddedildi");
        indirKaydet({ adim: "sw", ok: false, ad: guvenliAd, hata: sonHata, yanit: r || null });
      } catch (e) {
        sonHata = "sendMessage: " + (e && e.message || e);
        indirKaydet({ adim: "sw", ok: false, ad: guvenliAd, hata: sonHata });
      }
    } else {
      sonHata = "chrome.runtime.sendMessage yok";
    }
    // yedek: a.click (kullanıcı jesti çoğu zaman bitmiştir; başarısız olabilir)
    try {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = guvenliAd;
      a.rel = "noopener";
      a.style.display = "none";
      (document.body || document.documentElement).appendChild(a);
      a.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
      a.click();
      setTimeout(() => { try { a.remove(); URL.revokeObjectURL(a.href); } catch (e) {} }, 4000);
      indirKaydet({ adim: "a.click", ok: false, ad: guvenliAd, hata: "yedek a.click denendi (jest bitmiş olabilir). Asıl hata: " + sonHata });
    } catch (e) {
      sonHata = (sonHata ? sonHata + " | " : "") + "a.click: " + (e && e.message || e);
    }
    return { ok: false, ad: guvenliAd, hata: sonHata || "indirme başlatılamadı" };
  }
  function crc32(u8) {
    let c = ~0 >>> 0;
    for (let i = 0; i < u8.length; i++) {
      c ^= u8[i];
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    return (~c) >>> 0;
  }
  function u8birlestir(parcalar) {
    const n = parcalar.reduce((a, p) => a + p.length, 0);
    const out = new Uint8Array(n);
    let o = 0;
    parcalar.forEach((p) => { out.set(p, o); o += p.length; });
    return out;
  }
  function u16le(n) { return new Uint8Array([n & 255, (n >>> 8) & 255]); }
  function u32le(n) { return new Uint8Array([n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255]); }
  function zipSakla(dosyalar) {
    const enc = (typeof TextEncoder !== "undefined") ? new TextEncoder() : { encode: (s) => Uint8Array.from(unescape(encodeURIComponent(s)), (ch) => ch.charCodeAt(0)) };
    const yerel = [], merkez = [];
    let offset = 0;
    dosyalar.forEach(([ad, icerik]) => {
      const adU = enc.encode(ad);
      const data = (typeof icerik === "string") ? enc.encode(icerik) : (icerik instanceof Uint8Array ? icerik : new Uint8Array(icerik));
      const crc = crc32(data);
      const lh = u8birlestir([new Uint8Array([0x50, 0x4b, 0x03, 0x04]), u16le(20), u16le(0), u16le(0), u16le(0), u16le(0), u32le(crc), u32le(data.length), u32le(data.length), u16le(adU.length), u16le(0), adU, data]);
      const cd = u8birlestir([new Uint8Array([0x50, 0x4b, 0x01, 0x02]), u16le(20), u16le(20), u16le(0), u16le(0), u16le(0), u16le(0), u32le(crc), u32le(data.length), u32le(data.length), u16le(adU.length), u16le(0), u16le(0), u16le(0), u16le(0), u32le(0), u32le(offset), adU]);
      yerel.push(lh); merkez.push(cd); offset += lh.length;
    });
    const mid = u8birlestir(merkez);
    const eocd = u8birlestir([new Uint8Array([0x50, 0x4b, 0x05, 0x06]), u16le(0), u16le(0), u16le(dosyalar.length), u16le(dosyalar.length), u32le(mid.length), u32le(offset), u16le(0)]);
    return u8birlestir(yerel.concat([mid, eocd]));
  }
  function testXlsxBuf() {
    const cts = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>';
    const rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    const wb = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="OYSS" sheetId="1" r:id="rId1"/></sheets></workbook>';
    const wbrels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>';
    const sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>OYSS test indirme</t></is></c></row></sheetData></worksheet>';
    return zipSakla([["[Content_Types].xml", cts], ["_rels/.rels", rels], ["xl/workbook.xml", wb], ["xl/_rels/workbook.xml.rels", wbrels], ["xl/worksheets/sheet1.xml", sheet]]);
  }
  async function testIndir() {
    return dosyaIndir("OYSS_test_indirme.xlsx", testXlsxBuf(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  }
  // ── 1.9.5 OYSS KAPSAMI (2026-2027 kılavuzu) ──
  // Ortaokul 5-6-7: Türkçe, Matematik, Fen Bilimleri, Sosyal Bilgiler, Din Kültürü ve Ahlak Bilgisi, İngilizce.
  // Lise 9-10-11: Türk Dili ve Edebiyatı, Matematik, Fizik, Kimya, Biyoloji, Tarih, Coğrafya,
  //               Din Kültürü ve Ahlak Bilgisi, Felsefe, İngilizce.
  // Kapsam dışı şube/ders taranmaz (8 ve 12. sınıf, meslek/seçmeli dersler vb.).
  const OYSS_SINIF = { ortaokul: [5, 6, 7], lise: [9, 10, 11] };
  const OYSS_DERS = {
    ortaokul: ["turkce", "matematik", "fen bilimleri", "sosyal bilgiler", "din kulturu ve ahlak bilgisi", "ingilizce"],
    lise: ["turk dili ve edebiyati", "matematik", "fizik", "kimya", "biyoloji", "tarih", "cografya", "din kulturu ve ahlak bilgisi", "felsefe", "ingilizce"],
  };
  const OYSS_DERS_AD = {
    ortaokul: ["Türkçe", "Matematik", "Fen Bilimleri", "Sosyal Bilgiler", "Din Kültürü ve Ahlak Bilgisi", "İngilizce"],
    lise: ["Türk Dili ve Edebiyatı", "Matematik", "Fizik", "Kimya", "Biyoloji", "Tarih", "Coğrafya", "Din Kültürü ve Ahlak Bilgisi", "Felsefe", "İngilizce"],
  };
  function oyssDersAdlari(subeMetin) {
    const kd = kademe(sinifDuzeyi(subeMetin));
    return kd ? OYSS_DERS_AD[kd].slice() : [];
  }
  function gruplariDersSayfalarina(cekilen) {
    const out = [];
    for (const g of cekilen || []) {
      const dersler = (g.dersler && g.dersler.length) ? g.dersler : oyssDersAdlari(g.sube);
      const liste = dersler.length ? dersler : [g.ders || "Ders"];
      for (const ders of liste) {
        out.push({
          sube: g.sube,
          ders,
          sinav: g.sinav || "",
          soruSayisi: MAX_SORU,
          puanlar: Array(MAX_SORU).fill(0),
          dersListesi: liste,
          ogrenciler: (g.ogrenciler || []).map((o) => ({ no: o.no, ad: o.ad })),
        });
      }
    }
    return out;
  }
  function sinifDuzeyi(subeMetin) {
    const t = yaziSade(subeMetin);
    let m = t.match(/(\d{1,2})\s*sinif/);
    if (!m && (/^(ana|haz)\b|^ana\s*\d|^haz\s*\d/.test(t) || /anasinif|hazirlik/.test(t))) return null;
    m = m || t.match(/^(\d{1,2})(?:\s|[a-z]\b|$)/) || katla(subeMetin).replace(/\s+/g, "").match(/^(\d{1,2})[./-]?[a-z]/);
    if (!m) return null;
    const n = parseInt(m[1], 10);
    return n >= 1 && n <= 12 ? n : null;
  }
  function kademe(duzey) {
    if (OYSS_SINIF.ortaokul.includes(duzey)) return "ortaokul";
    if (OYSS_SINIF.lise.includes(duzey)) return "lise";
    return null;
  }
  function oyssSubeMi(subeMetin) { return !!kademe(sinifDuzeyi(subeMetin)); }
  function dersCekirdek(ders) {
    const ham = katla(ders);
    const parantez = (ham.match(/\(([^)]*)\)/g) || []).join(" ");
    let t = yaziSade(ham.replace(/\([^)]*\)/g, " ")).replace(/[^a-z ]+/g, " ").replace(/\s+/g, " ").trim();
    t = t.replace(/\bdin kult(uru)?\b.*$/, "din kulturu ve ahlak bilgisi");
    if (/^yabanci dil\b/.test(t) && /ingilizce/.test(parantez + " " + t)) return "ingilizce";
    if (/^(ingilizce|yabanci dil ingilizce)\b/.test(t)) return "ingilizce";
    return t;
  }
  // duzey verilmezse iki kademeden biri uyarsa kabul (ders listesi şube seçilmeden okunduğunda)
  function oyssDersMi(ders, duzey) {
    const t = dersCekirdek(ders);
    if (!t || /\b(secmeli|mesleki|meslek|uygulama|uygulamali|atolye|laboratuvar|proje|beceri|temel|ileri|takviye)\b/.test(t)) return false;
    const kd = duzey != null ? kademe(duzey) : null;
    if (duzey != null && !kd) return false;
    const liste = kd ? OYSS_DERS[kd] : OYSS_DERS.ortaokul.concat(OYSS_DERS.lise);
    return liste.includes(t);
  }

  function subeListesi(win, opts) {
    const k = kontroller(win);
    const tum = selectSecenekler(k.subeSel);
    if (opts && opts.yalnizOyss) return tum.filter((s) => oyssSubeMi(s.text));
    return tum;
  }
  function dersListesi(win, opts) {
    const k = kontroller(win);
    const tum = selectSecenekler(k.dersSel);
    if (opts && opts.yalnizOyss) {
      const sub = k.subeSel && k.subeSel.selectedIndex >= 0 ? k.subeSel.options[k.subeSel.selectedIndex].text : "";
      const d = sinifDuzeyi(sub);
      return tum.filter((o) => oyssDersMi(o.text, d != null ? d : undefined));
    }
    return tum;
  }

  async function selectSec(sel, hedef, win, bekle, opts) {
    opts = opts || {};
    const op = selectSecenekBul(sel, hedef);
    if (!op) return false;
    if (sel.selectedIndex >= 0 && sel.options[sel.selectedIndex] === op) return true;
    const oncekiFoto = opts.bekleSelect ? fotoSelect(opts.bekleSelect()) : null;
    if (!optionYaz(sel, op)) return false;
    if (opts.bekleSelect) {
      const doldu = await secenekBekle(opts.bekleSelect, bekle, Object.assign({}, opts, { oncekiFoto, degismeli: !!oncekiFoto, minAnlamli: opts.minAnlamli || 1 }));
      if (!doldu && opts.bekleSelectZorunlu) return false;
    } else {
      await postbackBekle(win, bekle, Object.assign({}, opts, { oncekiFoto }));
    }
    return true;
  }
  async function sinavYenidenSec(win, sinavMetin, bekle, opts) {
    const k = kontroller(win);
    if (k.sinavSel && subeSinavDurumuMu(k.sinavSel)) return false;
    if (sinavMetin && k.sinavSel && await selectSec(k.sinavSel, sinavMetin, win, bekle, opts)) return true;
    if (k.sinavSel) {
      const op = sinavAsilBul(k.sinavSel);
      if (op && optionYaz(k.sinavSel, op)) { await postbackBekle(win, bekle, opts); return true; }
    }
    return false;
  }

  async function tumSubeleriCek(win, opts) {
    opts = opts || {};
    const bekle = opts.bekle || ((ms) => new Promise((r) => setTimeout(r, ms)));
    const hiz = (opts.hiz && HIZ_BEKLE[opts.hiz]) ? opts.hiz : "hizli";
    const oturma = HIZ_KAYDET[hiz] || 400;
    const bekOpts = { maxMs: opts.maxMs || 15000, oturma };
    const ilerleme = opts.ilerleme || (() => {});
    const iptal = () => opts.iptal && opts.iptal();
    const adimYaz = (adim, is, ek) => {
      const bas = (is && is.sube && is.sube.text) ? is.sube.text : (is && is.sube) || "";
      const ders = (is && is.ders) || "";
      ilerleme({ i: is && is._i, n: is && is._n, adim, sube: bas, ders, mesaj: (adim ? adim + ": " : "") + (is && is._sira ? is._sira + " " : "") + bas + (ders ? " / " + ders : "") + (ek ? " — " + ek : "") });
    };
    let k = kontroller(win);
    if (!k.subeSel) throw new Error("Şube listesi bulunamadı. OYSS Not Girişi (OOK10020) ekranında olduğunuzdan emin olun. Tanı raporu ile sayfa yapısını iletebilirsiniz.");
    const tumSubeler = selectSecenekler(k.subeSel);
    let subeler = tumSubeler;
    if (opts.secilenSubeler && opts.secilenSubeler.length) {
      subeler = opts.secilenSubeler.map((s) => {
        const op = selectSecenekBul(k.subeSel, s);
        return op ? { value: op.value, text: norm(op.text), index: [...k.subeSel.options].indexOf(op) } : null;
      }).filter(Boolean);
      if (!subeler.length) subeler = tumSubeler;
    }
    if (!subeler.length) throw new Error("Şube açılır listesinde seçenek yok (yalnızca Seçiniz görünüyor olabilir). Sınıf/şube listesinin yüklenmesini bekleyin veya Tanı raporu alın.");
    const yalnizOyss = opts.yalnizOyss !== false;
    const kapsamDisiSube = [];
    if (yalnizOyss) {
      subeler = subeler.filter((s) => { const ok = oyssSubeMi(s.text); if (!ok) kapsamDisiSube.push(s.text); return ok; });
      if (!subeler.length) throw new Error("Seçilen şubelerin hiçbiri OYSS kapsamında değil (ortaokul 5-6-7, lise 9-10-11).");
    }
    const sinavTercih = opts.sinav || (k.sinavSel && k.sinavSel.selectedIndex >= 0 && !secenekBosMu(k.sinavSel.options[k.sinavSel.selectedIndex].text) ? norm(k.sinavSel.options[k.sinavSel.selectedIndex].text) : "");
    const dersSimdiki = k.dersSel && k.dersSel.selectedIndex >= 0 ? norm(k.dersSel.options[k.dersSel.selectedIndex].text) : "";
    const gruplar = [], atlanan = [], hatalar = [];
    kapsamDisiSube.forEach((t) => atlanan.push("kapsam dışı şube (OYSS uygulanmaz): " + t));
    // Şube başına öğrenci listesi bir kez çekilir (dersler dolaşılmaz). Excel'de kılavuz dersleri sayfa olarak çoğaltılır.
    const isler = [];
    for (const su of subeler) isler.push({ sube: su });
    let gidilen = 0;
    for (let i = 0; i < isler.length; i++) {
      if (iptal()) throw new Error("İşlem iptal edildi.");
      const is = isler[i];
      is._i = i; is._n = isler.length; is._sira = (i + 1) + "/" + isler.length;
      const etiket = is.sube.text;
      adimYaz("şube", is, "seçiliyor");
      k = kontroller(win);
      if (!k.subeSel) { hatalar.push("şube: " + etiket + " — şube listesi kayboldu"); continue; }
      const dersFoto = k.dersSel ? fotoSelect(k.dersSel) : "";
      const subeOp = selectSecenekBul(k.subeSel, is.sube);
      const zatenSecili = !!(subeOp && k.subeSel.selectedIndex >= 0 && k.subeSel.options[k.subeSel.selectedIndex] === subeOp && k.dersSel && selectSecenekler(k.dersSel).length);
      if (!zatenSecili) {
        if (!(await selectSec(k.subeSel, is.sube, win, bekle, Object.assign({}, bekOpts, { bekleSelect: () => kontroller(win).dersSel, minAnlamli: 1 })))) {
          hatalar.push("şube: " + etiket + " seçilemedi"); continue;
        }
        adimYaz("ders", is, "seçenekler bekleniyor");
        await secenekBekle(() => kontroller(win).dersSel, bekle, Object.assign({}, bekOpts, { oncekiFoto: dersFoto, degismeli: !!dersFoto, minAnlamli: 1 }));
      }
      k = kontroller(win);
      const duzey = sinifDuzeyi(is.sube.text);
      const tum = k.dersSel ? selectSecenekler(k.dersSel).map((o) => o.text) : [];
      const uygun = (yalnizOyss ? tum.filter((d) => oyssDersMi(d, duzey)) : tum).filter((d) => d && !secenekBosMu(d));
      if (!uygun.length) { atlanan.push("şube: " + is.sube.text + " — OYSS kapsamında ders yok"); continue; }
      const denenen = uygun.slice();
      if (dersSimdiki) {
        const hs = katla(dersSimdiki);
        const ix = denenen.findIndex((d) => katla(d) === hs || katla(d).includes(hs) || hs.includes(katla(d)));
        if (ix > 0) { const [al] = denenen.splice(ix, 1); denenen.unshift(al); }
      }
      let alindi = null, sonHata = "";
      for (const dersAd of denenen) {
        if (iptal()) throw new Error("İşlem iptal edildi.");
        is.ders = dersAd;
        adimYaz("ders", is, "liste için seçiliyor");
        k = kontroller(win);
        if (k.dersSel && !selectSecenekBul(k.dersSel, dersAd)) { sonHata = "ders yok: " + dersAd; continue; }
        if (k.dersSel && !(await selectSec(k.dersSel, dersAd, win, bekle, Object.assign({}, bekOpts, { bekleSelect: () => kontroller(win).sinavSel, minAnlamli: 0 })))) {
          sonHata = "ders seçilemedi: " + dersAd; continue;
        }
        const liste = await oyssListeYukle(win, bekle, bekOpts, oturma, sinavTercih, (adim, ek) => adimYaz(adim, is, ek));
        if (!liste.ok) { sonHata = liste.hata || (dersAd + " listesi alınamadı"); continue; }
        alindi = liste;
        break;
      }
      if (!alindi) { hatalar.push("liste: " + etiket + " — " + (sonHata || "Öğrenci Listesi Yükle sonrası tablo yok")); continue; }
      gidilen++;
      const sayfa = alindi.sayfa;
      gruplar.push({
        sube: sayfa.sube || is.sube.text,
        ders: sayfa.ders || is.ders,
        sinav: sayfa.sinav || (alindi.sinavOp && alindi.sinavOp.text) || sinavTercih || "",
        soruSayisi: MAX_SORU,
        puanlar: Array(MAX_SORU).fill(0),
        dersler: oyssDersAdlari(sayfa.sube || is.sube.text),
        ogrenciler: sayfa.satirlar.map((s) => ({ no: s.no, ad: s.ad })),
      });
    }
    ilerleme({ i: isler.length, n: isler.length, adim: "tamam", mesaj: "Tamam: " + gruplar.length + "/" + isler.length + " şube listesi" + (hatalar.length ? " · " + hatalar.length + " adım hata" : "") + (atlanan.length ? " · " + atlanan.length + " kapsam dışı/atlandı" : "") });
    return { gruplar, atlanan, hatalar, toplam: isler.length, gidilen };
  }

  async function oyssListeYukle(win, bekle, bekOpts, oturma, sinavTercih, adimYaz) {
    adimYaz = adimYaz || (() => {});
    let k = kontroller(win);
    adimYaz("sınav", "Sınavları Getir");
    if (k.getirBtn && !guvenlikAlaniMi(k.getirBtn) && !eklentiElemaniMi(k.getirBtn) && !kapatDugmesiMi(k.getirBtn) && !subeSinavDurumuMu(k.getirBtn)) {
      k.getirBtn.click();
    }
    const sinavGeldi = await secenekBekle(() => {
      const s = kontroller(win).sinavSel;
      return (s && !subeSinavDurumuMu(s)) ? s : null;
    }, bekle, Object.assign({}, bekOpts, { minAnlamli: 1, degismeli: false }));
    if (!sinavGeldi) return { ok: false, hata: "Sınavları Getir sonrası seçenek gelmedi" };
    k = kontroller(win);
    if (k.sinavSel && subeSinavDurumuMu(k.sinavSel)) return { ok: false, hata: "Şube sınav durumu kutusu yok sayıldı" };
    const sinavOp = sinavAsilBul(k.sinavSel, sinavTercih);
    if (!sinavOp || !optionYaz(k.sinavSel, sinavOp)) return { ok: false, hata: "OYSS/Asıl (veya istenen sınav) seçilemedi" };
    await bekle(Math.min(oturma || 400, 300));
    k = kontroller(win);
    adimYaz("liste", "Öğrenci Listesi Yükle");
    if (k.yukleBtn && !guvenlikAlaniMi(k.yukleBtn) && !eklentiElemaniMi(k.yukleBtn) && !kapatDugmesiMi(k.yukleBtn) && katla(metinEl(k.yukleBtn) || k.yukleBtn.value || "") !== "kaydet") {
      k.yukleBtn.click();
    }
    const t1 = Date.now();
    let sayfa = sayfaOku(win);
    const tabloVar = (s) => s && s.satirlar && s.satirlar.length;
    while (Date.now() - t1 < ((bekOpts && bekOpts.maxMs) || 15000) && !tabloVar(sayfa)) {
      await bekle(150);
      sayfa = sayfaOku(win);
    }
    if (!tabloVar(sayfa)) return { ok: false, hata: "Öğrenci Listesi Yükle sonrası tablo yok (Okul No)" };
    return { ok: true, sayfa, sinavOp };
  }

  async function sayfaHazirla(win, grup, opts) {
    opts = opts || {};
    const bekle = opts.bekle || ((ms) => new Promise((r) => setTimeout(r, ms)));
    const hiz = (opts.hiz && HIZ_BEKLE[opts.hiz]) ? opts.hiz : "hizli";
    const oturma = HIZ_KAYDET[hiz] || 400;
    const bekOpts = { maxMs: opts.maxMs || 15000, oturma };
    const k0 = kontroller(win);
    const acik = sayfaOku(win);
    const ayniSube = !!(grup && grup.sube && acik && acik.sube && katla(acik.sube) === katla(grup.sube));
    const ayniDers = !!(grup && grup.ders && acik && acik.ders && katla(acik.ders) === katla(grup.ders));
    const ayniSinav = !grup.sinav || !!(acik && acik.sinav && (katla(acik.sinav) === katla(grup.sinav) || katla(acik.sinav).indexOf(katla(grup.sinav)) >= 0 || katla(grup.sinav).indexOf(katla(acik.sinav)) >= 0));
    if (ayniSube && ayniDers && ayniSinav && acik && acik.satirlar && acik.satirlar.length && acik.sorular && acik.sorular.length) {
      return { ok: true, sayfa: acik, zatenAcik: true };
    }
    if (grup.sube && k0.subeSel && !ayniSube) {
      const dersFoto = k0.dersSel ? fotoSelect(k0.dersSel) : "";
      if (!(await selectSec(k0.subeSel, grup.sube, win, bekle, Object.assign({}, bekOpts, { bekleSelect: () => kontroller(win).dersSel, minAnlamli: 1 })))) {
        return { ok: false, hata: "Şube seçilemedi: " + grup.sube };
      }
      await secenekBekle(() => kontroller(win).dersSel, bekle, Object.assign({}, bekOpts, { oncekiFoto: dersFoto, degismeli: !!dersFoto, minAnlamli: 1 }));
    }
    const k1 = kontroller(win);
    if (grup.ders && k1.dersSel) {
      if (!selectSecenekBul(k1.dersSel, grup.ders)) return { ok: false, hata: "Ders sayfada yok: " + grup.ders };
      if (!(await selectSec(k1.dersSel, grup.ders, win, bekle, Object.assign({}, bekOpts, { bekleSelect: () => kontroller(win).sinavSel, minAnlamli: 0 })))) {
        return { ok: false, hata: "Ders seçilemedi: " + grup.ders };
      }
    }
    const liste = await oyssListeYukle(win, bekle, bekOpts, oturma, grup.sinav || "", () => {});
    if (!liste.ok) return { ok: false, hata: liste.hata };
    return { ok: true, sayfa: liste.sayfa, zatenAcik: false };
  }

  function dosyaAdi(sayfa) {
    const par = [dosyaGovenliParca(sayfa && sayfa.sube), dosyaGovenliParca(sayfa && sayfa.ders)].filter(Boolean).join("_");
    return "OYSS_Soru_Bazli_Not" + (par ? "_" + par : "") + ".xlsx";
  }
  function raporMetin(r) {
    const satir = [];
    if (r.kaydedildi) satir.push("Kaydet'e basıldı. Yazılan öğrenci: " + (r.yazilan || 0) + ".");
    else if (r.yazilan) satir.push("Puanlar yazıldı (" + r.yazilan + ") ama Kaydet'e basılmadı.");
    if (r.hatalar && r.hatalar.length) { satir.push("Kayıt yapılmadı. Hatalar:"); r.hatalar.forEach((h) => satir.push("• " + h)); }
    if (r.uyarilar && r.uyarilar.length) { satir.push("Uyarılar:"); r.uyarilar.forEach((h) => satir.push("• " + h)); }
    return satir.join("\n") || "İşlem tamam.";
  }

  const OyssNot = {
    SURUM, KATILIM, MAX_SORU, HIZ_BEKLE, HIZ_KAYDET,
    norm, katla, noNorm, sayiOku, puanHata, puanYaz, soruBaslikOku, katilimNorm, katilimHesap, katilimCoz, puanVarMi, girmediMi,
    excelAyristir, excelAyristirCoklu, excelDosyalarindan, excelDosyalariOzet, grupDoluMu, dersSayfadaVarMi, iceSirasi, icePlan, iceOzetMetin, iceGunluk, iceKaydet, grupSec, notlarSutunlari,
    sayfaOku, kapilar, degerYaz, secenekYaz, yazVeKaydet, sablonDoldur, sablonCokluZip, sablonCokluKitap,
    dosyaAdi, dosyaAdiGrup, dosyaAdiSube, dosyaAdiGuvenli, dosyaGovenliParca, alanAyir, raporMetin, guvenlikAlaniMi, kaydetBul, kontroller, tumSubeleriCek, taniRaporu,
    subeListesi, dersListesi, dosyaIndir, testIndir, testXlsxBuf, eklentiElemaniMi, indirGunluk, indirKaydet,
    sinifDuzeyi, oyssSubeMi, oyssDersMi, dersCekirdek, oyssDersAdlari, gruplariDersSayfalarina, sayfaHazirla, oyssListeYukle,
    OYSS_SINIF, OYSS_DERS, OYSS_DERS_AD,
  };
  kok.OyssNot = OyssNot;
  if (typeof module !== "undefined" && module.exports) module.exports = OyssNot;
})(typeof globalThis !== "undefined" ? globalThis : this);
