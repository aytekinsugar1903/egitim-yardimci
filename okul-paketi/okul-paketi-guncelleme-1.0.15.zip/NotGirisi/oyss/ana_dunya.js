// Sayfa dünyası (world: MAIN). Yalnız OYSS: jQuery change tetikleme + UpdatePanel meşgul işareti.
// alert/confirm kancası yok (ders notu / OOK07003 davranışına dokunulmaz).
(() => {
  const isaretle = (v) => document.documentElement && document.documentElement.setAttribute("data-eokul-mesgul", v ? "1" : "0");
  setInterval(() => {
    try {
      const prm = window.Sys && Sys.WebForms && Sys.WebForms.PageRequestManager && Sys.WebForms.PageRequestManager.getInstance();
      const pf = window.PrimeFaces && PrimeFaces.ajax && PrimeFaces.ajax.Queue;
      const pfMesgul = !!(pf && ((pf.isEmpty && !pf.isEmpty()) || (pf.requests && pf.requests.length)));
      const jq = !!(window.jQuery && jQuery.active > 0);
      isaretle(!!(prm && prm.get_isInAsyncPostBack()) || pfMesgul || jq);
    } catch (e) { isaretle(false); }
  }, 200);
  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data.kaynak !== "eokul-eklenti-komut" || e.data.islem !== "select-change") return;
    const tok = e.data.token;
    const el = tok
      ? document.querySelector('[data-eoa-oyss-sel="' + String(tok).replace(/"/g, "") + '"]')
      : document.querySelector("[data-eoa-oyss-sel]");
    if (!el) return;
    el.removeAttribute("data-eoa-oyss-sel");
    if (e.data.deger != null) { try { el.value = e.data.deger; } catch (x) {} }
    const $ = window.jQuery || window.$;
    try { if ($ && $.fn) $(el).val(el.value).trigger("change"); } catch (x) {}
    try { if ($ && $.fn && $.fn.select2) $(el).trigger("change.select2"); } catch (x) {}
    try { if ($ && $(el).data && $(el).data("chosen")) $(el).trigger("chosen:updated").trigger("change"); } catch (x) {}
  });
})();
