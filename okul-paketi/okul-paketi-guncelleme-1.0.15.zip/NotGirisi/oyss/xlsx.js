// v2.3.27: Küçük, yerel .xlsx yazıcı/okuyucu (kütüphane yok; dışarı veri gitmez). Yazma: sıkıştırmasız zip. Okuma: Excel'in deflate'i DecompressionStream ile.
(function (kok) {
  "use strict";
  const te = new TextEncoder(), td = new TextDecoder();
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = (b) => { let c = 0xffffffff; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  function zip(dosyalar) { // [{ad, veri:Uint8Array}] -> Uint8Array (STORE)
    const par = [], mer = []; let ofs = 0;
    for (const f of dosyalar) { const ad = te.encode(f.ad), c = crc32(f.veri), h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint32(14, c, true); h.setUint32(18, f.veri.length, true); h.setUint32(22, f.veri.length, true); h.setUint16(26, ad.length, true);
      par.push(new Uint8Array(h.buffer), ad, f.veri);
      const m = new DataView(new ArrayBuffer(46)); m.setUint32(0, 0x02014b50, true); m.setUint16(4, 20, true); m.setUint16(6, 20, true); m.setUint16(8, 0x0800, true); m.setUint32(16, c, true); m.setUint32(20, f.veri.length, true); m.setUint32(24, f.veri.length, true); m.setUint16(28, ad.length, true); m.setUint32(42, ofs, true);
      mer.push(new Uint8Array(m.buffer), ad); ofs += 30 + ad.length + f.veri.length; }
    const mb = mer.reduce((s, x) => s + x.length, 0), e = new DataView(new ArrayBuffer(22));
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, dosyalar.length, true); e.setUint16(10, dosyalar.length, true); e.setUint32(12, mb, true); e.setUint32(16, ofs, true);
    const t = [...par, ...mer, new Uint8Array(e.buffer)], o = new Uint8Array(t.reduce((s, x) => s + x.length, 0)); let p = 0; for (const x of t) { o.set(x, p); p += x.length; } return o;
  }
  const kac = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "");
  const sutun = (i) => { let s = ""; i++; while (i) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = (i - m - 1) / 26; } return s; };
  // satirlar: [[...hücre metinleri]], sari: Set(satır no, 0 tabanlı veri satırı), genislik: [sütun genişlikleri]
  function yaz({ sayfa = "Sayfa1", basliklar, satirlar, sari = new Set(), genislik = [] }) {
    const satir = (h, r, st) => `<row r="${r}">` + h.map((v, i) => `<c r="${sutun(i)}${r}" t="inlineStr"${st ? ` s="${st}"` : ""}><is><t xml:space="preserve">${kac(v)}</t></is></c>`).join("") + "</row>";
    const sh = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>`
      + (genislik.length ? "<cols>" + genislik.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join("") + "</cols>" : "")
      + "<sheetData>" + satir(basliklar, 1, 2) + satirlar.map((h, i) => satir(h, i + 2, sari.has(i) ? 1 : 0)).join("") + `</sheetData><autoFilter ref="A1:${sutun(basliklar.length - 1)}${satirlar.length + 1}"/></worksheet>`;
    const st = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>`
      + `<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFFF00"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFD9D9D9"/><bgColor indexed="64"/></patternFill></fill></fills>`
      + `<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>`
      + `<cellXfs count="3"><xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="49" fontId="0" fillId="2" borderId="0" xfId="0" applyFill="1" applyNumberFormat="1"/><xf numFmtId="49" fontId="1" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
    const d = (ad, s) => ({ ad, veri: te.encode(s) });
    return new Blob([zip([
      d("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`),
      d("_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`),
      d("xl/workbook.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${kac(sayfa).slice(0, 31)}" sheetId="1" r:id="rId1"/></sheets><definedNames><definedName name="_xlnm._FilterDatabase" localSheetId="0" hidden="1">'${kac(sayfa).slice(0, 31)}'!$A$1:$${sutun(basliklar.length - 1)}$${satirlar.length + 1}</definedName></definedNames></workbook>`),
      d("xl/_rels/workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`),
      d("xl/worksheets/sheet1.xml", sh), d("xl/styles.xml", st)])], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  }
  async function acZip(buf) {
    const raw = buf instanceof ArrayBuffer ? buf : (buf && buf.buffer instanceof ArrayBuffer ? (buf.byteOffset === 0 && buf.byteLength === buf.buffer.byteLength ? buf.buffer : buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength)) : new Uint8Array(buf).buffer);
    const u = new Uint8Array(raw), v = new DataView(raw); let e = -1; for (let i = u.length - 22; i >= Math.max(0, u.length - 66000); i--) if (v.getUint32(i, true) === 0x06054b50) { e = i; break; }
    if (e < 0) throw new Error("Geçerli bir .xlsx dosyası değil");
    const n = v.getUint16(e + 10, true); let p = v.getUint32(e + 16, true); const out = {};
    for (let k = 0; k < n; k++) { const yon = v.getUint16(p + 10, true), bs = v.getUint32(p + 20, true), al = v.getUint16(p + 28, true), xl = v.getUint16(p + 30, true), cl = v.getUint16(p + 32, true), lo = v.getUint32(p + 42, true);
      const ad = td.decode(u.subarray(p + 46, p + 46 + al)); p += 46 + al + xl + cl;
      const la = v.getUint16(lo + 26, true), lx = v.getUint16(lo + 28, true), ham = u.subarray(lo + 30 + la + lx, lo + 30 + la + lx + bs);
      out[ad] = yon === 0 ? ham : yon === 8 ? new Uint8Array(await new Response(new Blob([ham]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).arrayBuffer()) : null; }
    return out;
  }
  // -> [[metin...]] (ilk sayfa). Sayı hücreleri metne çevrilir; tarih biçimli sayılar "gg/aa/yyyy" olur.
  async function oku(buf) {
    const z = await acZip(buf), X = (ad) => z[ad] ? new DOMParser().parseFromString(td.decode(z[ad]), "application/xml") : null;
    const ss = X("xl/sharedStrings.xml"), paylasim = ss ? [...ss.getElementsByTagName("si")].map((si) => [...si.getElementsByTagName("t")].map((t) => t.textContent).join("")) : [];
    const stl = X("xl/styles.xml"), tarihStil = new Set();
    if (stl) { const ozel = new Map([...stl.getElementsByTagName("numFmt")].map((f) => [f.getAttribute("numFmtId"), f.getAttribute("formatCode") || ""]));
      const xfs = stl.getElementsByTagName("cellXfs")[0]; if (xfs) [...xfs.getElementsByTagName("xf")].forEach((x, i) => { const id = +x.getAttribute("numFmtId"); if ((id >= 14 && id <= 22) || (ozel.has(String(id)) && /[dmy]/i.test(ozel.get(String(id)).replace(/"[^"]*"/g, "")))) tarihStil.add(i); }); }
    const ad = Object.keys(z).filter((k) => /^xl\/worksheets\/sheet\d+\.xml$/.test(k)).sort()[0]; if (!ad) throw new Error("Çalışma sayfası bulunamadı");
    const sh = X(ad), sat = [];
    for (const r of sh.getElementsByTagName("row")) { const h = [];
      for (const c of r.getElementsByTagName("c")) { const ref = c.getAttribute("r") || "", m = ref.match(/^([A-Z]+)/); let col = h.length; if (m) { col = 0; for (const ch of m[1]) col = col * 26 + ch.charCodeAt(0) - 64; col--; }
        const t = c.getAttribute("t"), vv = c.getElementsByTagName("v")[0], v = vv ? vv.textContent : ""; let s;
        if (t === "s") s = paylasim[+v] ?? ""; else if (t === "inlineStr") s = [...c.getElementsByTagName("t")].map((x) => x.textContent).join(""); else if (t === "b") s = v === "1" ? "DOĞRU" : "YANLIŞ";
        else if (!t || t === "n") { s = v; if (v && tarihStil.has(+c.getAttribute("s"))) { const d = new Date(Date.UTC(1899, 11, 30) + Math.round(+v * 86400000)); s = `${String(d.getUTCDate()).padStart(2, "0")}/${String(d.getUTCMonth() + 1).padStart(2, "0")}/${d.getUTCFullYear()}`; } }
        else s = v;
        h[col] = s; }
      sat[(+r.getAttribute("r") || sat.length + 1) - 1] = Array.from(h, (x) => x ?? ""); }
    return Array.from(sat, (x) => x || []);
  }
// v2.5.4: tüm çalışma sayfalarını adlarıyla oku. oku() davranışı değişmez (yalnız ilk sayfa).
  async function okuSayfalar(buf) {
    const z = await acZip(buf), X = (ad) => z[ad] ? new DOMParser().parseFromString(td.decode(z[ad]), "application/xml") : null;
    const ss = X("xl/sharedStrings.xml"), paylasim = ss ? [...ss.getElementsByTagName("si")].map((si) => [...si.getElementsByTagName("t")].map((t) => t.textContent).join("")) : [];
    const stl = X("xl/styles.xml"), tarihStil = new Set();
    if (stl) { const ozel = new Map([...stl.getElementsByTagName("numFmt")].map((f) => [f.getAttribute("numFmtId"), f.getAttribute("formatCode") || ""]));
      const xfs = stl.getElementsByTagName("cellXfs")[0]; if (xfs) [...xfs.getElementsByTagName("xf")].forEach((x, i) => { const id = +x.getAttribute("numFmtId"); if ((id >= 14 && id <= 22) || (ozel.has(String(id)) && /[dmy]/i.test(ozel.get(String(id)).replace(/"[^"]*"/g, "")))) tarihStil.add(i); }); }
    function satirlar(sh) {
      const sat = [];
      for (const r of sh.getElementsByTagName("row")) { const h = [];
        for (const c of r.getElementsByTagName("c")) { const ref = c.getAttribute("r") || "", m = ref.match(/^([A-Z]+)/); let col = h.length; if (m) { col = 0; for (const ch of m[1]) col = col * 26 + ch.charCodeAt(0) - 64; col--; }
          const t = c.getAttribute("t"), vv = c.getElementsByTagName("v")[0], v = vv ? vv.textContent : ""; let s;
          if (t === "s") s = paylasim[+v] ?? ""; else if (t === "inlineStr") s = [...c.getElementsByTagName("t")].map((x) => x.textContent).join(""); else if (t === "b") s = v === "1" ? "DOĞRU" : "YANLIŞ";
          else if (!t || t === "n") { s = v; if (v && tarihStil.has(+c.getAttribute("s"))) { const d = new Date(Date.UTC(1899, 11, 30) + Math.round(+v * 86400000)); s = `${String(d.getUTCDate()).padStart(2, "0")}/${String(d.getUTCMonth() + 1).padStart(2, "0")}/${d.getUTCFullYear()}`; } }
          else s = v;
          h[col] = s; }
        sat[(+r.getAttribute("r") || sat.length + 1) - 1] = Array.from(h, (x) => x ?? ""); }
      return Array.from(sat, (x) => x || []);
    }
    const wb = X("xl/workbook.xml"), rels = X("xl/_rels/workbook.xml.rels"), idYol = {};
    const ns = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    if (rels) for (const r of rels.getElementsByTagName("Relationship")) {
      let t = r.getAttribute("Target") || ""; t = t.replace(/^\//, ""); if (t.startsWith("../")) t = t.replace(/^(\.\.\/)+/, "");
      if (!t.startsWith("xl/")) t = "xl/" + t.replace(/^\.\//, "");
      idYol[r.getAttribute("Id")] = t;
    }
    const sira = [], sayfalar = {};
    const sheets = wb ? [...wb.getElementsByTagName("sheet")] : [];
    for (const s of sheets) {
      const ad = s.getAttribute("name") || "";
      const rid = s.getAttributeNS(ns, "id") || s.getAttribute("r:id") || "";
      const yol = idYol[rid]; if (!yol || !z[yol]) continue;
      const sh = X(yol); if (!sh) continue;
      sira.push(ad); sayfalar[ad] = satirlar(sh);
    }
    if (!sira.length) throw new Error("Çalışma sayfası bulunamadı");
    return { sira, sayfalar };
  }
  kok.EvrakXlsx = { yaz, oku, okuSayfalar, zip, ac: acZip };

})(globalThis);
