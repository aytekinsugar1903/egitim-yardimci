// 1.7.0 Yerleşik ders listesi (yedek): e-Okul sayfasından okunan liste HER ZAMAN önceliklidir; bu liste yalnız açılır liste boş kalmasın diye.
// Kaynaklar (yalnız resmî çizelgelerdeki adlar, aynen):
//  ilk/orta: TTKB 23/05/2024 tarih 21 sayılı karar, İlköğretim Kurumları (İlkokul ve Ortaokul) Haftalık Ders Çizelgesi (zorunlu dersler)
//            https://ttkb.meb.gov.tr/meb_iys_dosyalar/2025_02/10103210_ilkogretimkurumlari_hdc_2024_21.pdf
//  lise:     TTKB 2025 Anadolu Lisesi Haftalık Ders Çizelgesi (ortak dersler + seçmeli)  https://ttkb.meb.gov.tr/meb_iys_dosyalar/2025_05/20144001_202505.pdf
// Meslek lisesi alan dersleri, İHL meslek dersleri ve Hazırlık sınıfı dersleri doğrulanamadığı için EKLENMEDİ (e-Okul sayfasından okunur).
(function (kok) {
  'use strict';
  const ILK_ORTA = ['Türkçe', 'Matematik', 'Hayat Bilgisi', 'Fen Bilimleri', 'Sosyal Bilgiler', 'T.C. İnkılap Tarihi ve Atatürkçülük', 'Yabancı Dil', 'Din Kültürü ve Ahlak Bilgisi', 'Görsel Sanatlar', 'Müzik', 'Beden Eğitimi ve Oyun', 'Beden Eğitimi ve Spor', 'Teknoloji ve Tasarım', 'Trafik Güvenliği', 'Bilişim Teknolojileri ve Yazılım', 'Rehberlik ve Kariyer Planlama', 'İnsan Hakları, Vatandaşlık ve Demokrasi'];
  const LISE = ['TÜRK DİLİ VE EDEBİYATI', 'DİN KÜLTÜRÜ VE AHLAK BİLGİSİ', 'TARİH', 'T.C. İNKILAP TARİHİ VE ATATÜRKÇÜLÜK', 'COĞRAFYA', 'MATEMATİK', 'FİZİK', 'KİMYA', 'BİYOLOJİ', 'FELSEFE', 'BİRİNCİ YABANCI DİL', 'BEDEN EĞİTİMİ VE SPOR', 'GÖRSEL SANATLAR/MÜZİK', 'SAĞLIK BİLGİSİ VE TRAFİK KÜLTÜRÜ', 'SEÇMELİ MATEMATİK', 'TEMEL MATEMATİK', 'SEÇMELİ FİZİK', 'SEÇMELİ KİMYA', 'SEÇMELİ BİYOLOJİ', 'SEÇMELİ TÜRK DİLİ VE EDEBİYATI', 'SEÇMELİ TARİH', 'SEÇMELİ COĞRAFYA', 'PSİKOLOJİ', 'SOSYOLOJİ', 'MANTIK', 'SEÇMELİ BİRİNCİ YABANCI DİL', 'SEÇMELİ İKİNCİ YABANCI DİL', 'OSMANLI TÜRKÇESİ', 'KUR’AN-I KERİM', 'PEYGAMBERİMİZİN HAYATI', 'TEMEL DİNÎ BİLGİLER', 'BİLİŞİM TEKNOLOJİLERİ VE YAZILIM', 'PROJE TASARIMI VE UYGULAMALARI', 'TEMEL HUKUK BİLGİSİ', 'GİRİŞİMCİLİK'];
  // Sınıf adı e-Okul'daki gibi: "11. Sınıf / F Şubesi" (e-Okul Sınıf Listesi dışa aktarımında görüldü)
  const sinifAdi = (s) => { const m = /^(\d{1,2})-(.+)$/.exec(String(s || '')); return m ? m[1] + '. Sınıf / ' + m[2] + ' Şubesi' : String(s || ''); };
  const dersler = (sinif) => { const d = +String(sinif || '').split('-')[0]; return d >= 1 && d <= 8 ? ILK_ORTA.slice() : d >= 9 ? LISE.slice() : ILK_ORTA.concat(LISE); };
  const api = { ILK_ORTA, LISE, dersler, sinifAdi };
  if (typeof module !== 'undefined') module.exports = api; else kok.NGADersler = api;
})(typeof window !== 'undefined' ? window : globalThis);
