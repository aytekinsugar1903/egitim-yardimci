/* Excel (.xlsx) okuma/yazma — harici kütüphane YOK, tamamen yerel (Not Girişi Asistanı). Tarayıcıdaki DecompressionStream ve DOMParser kullanılır.
   ExcelNot.yaz([{ad:'12-M', satirlar:[[...],...], genislik:[..], notSutunu:[4,5]}]) -> Blob (.xlsx)
   ExcelNot.oku(ArrayBuffer) -> Promise<[{ad, satirlar:[[...]]}]> */
(function (kok) {
  'use strict';
  var enc = new TextEncoder(), dec = new TextDecoder('utf-8');
  var CRC = (function () { var t = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(b) { var c = 0xFFFFFFFF; for (var i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function zipYaz(dosyalar) { // dosyalar: [[ad, Uint8Array]] — sıkıştırmasız (store)
    var parcalar = [], merkez = [], ofs = 0, u16 = function (v) { return [v & 255, (v >> 8) & 255]; }, u32 = function (v) { return [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255]; };
    dosyalar.forEach(function (d) { var ad = enc.encode(d[0]), v = d[1], crc = crc32(v);
      var lh = [].concat(u32(0x04034b50), u16(20), u16(0x0800), u16(0), u16(0), u16(0x21), u32(crc), u32(v.length), u32(v.length), u16(ad.length), u16(0));
      parcalar.push(new Uint8Array(lh), ad, v);
      merkez.push([].concat(u32(0x02014b50), u16(20), u16(20), u16(0x0800), u16(0), u16(0), u16(0x21), u32(crc), u32(v.length), u32(v.length), u16(ad.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(ofs)), Array.prototype.slice.call(ad));
      ofs += lh.length + ad.length + v.length; });
    var mb = []; merkez.forEach(function (m) { mb = mb.concat(m); });
    var son = [].concat(u32(0x06054b50), u16(0), u16(0), u16(dosyalar.length), u16(dosyalar.length), u32(mb.length), u32(ofs), u16(0));
    parcalar.push(new Uint8Array(mb), new Uint8Array(son)); return new Blob(parcalar, { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }
  var esc = function (s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, ''); };
  var kol = function (i) { var s = ''; i++; while (i > 0) { var m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
  function sayfaXml(sf) {
    // 1.7.0: basSatir = başlık satırı (0 tabanlı, varsayılan 0: önceki davranış aynen); sariHucre = [[satır, sütun]] doldurulacak hücreler
    var satirlar = sf.satirlar, g = sf.genislik || [], nk = sf.notSutunu || [], bs = sf.basSatir || 0, sh = (sf.sariHucre || []).map(function (x) { return x[0] + ':' + x[1]; }), o = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="' + (bs + 1) + '" topLeftCell="A' + (bs + 2) + '" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>'];
    for (var c = 0; c < (satirlar[bs] || satirlar[0] || []).length; c++) o.push('<col min="' + (c + 1) + '" max="' + (c + 1) + '" width="' + (g[c] || 14) + '" customWidth="1"/>'); o.push('</cols><sheetData>');
    satirlar.forEach(function (r, i) { o.push('<row r="' + (i + 1) + '">'); r.forEach(function (v, c) { var sari = sh.indexOf(i + ':' + c) >= 0 || (nk.indexOf(c) >= 0 && i > bs); if (v === '' || v == null) { if (sari) o.push('<c r="' + kol(c) + (i + 1) + '" s="2"/>'); return; }
        var ref = kol(c) + (i + 1), st = i === bs ? ' s="1"' : (sari ? ' s="2"' : '');
        o.push('<c r="' + ref + '"' + st + ' t="inlineStr"><is><t xml:space="preserve">' + esc(v) + '</t></is></c>'); }); o.push('</row>'); });
    o.push('</sheetData>');
    var ls = sf.liste || []; // 1.7.0: [{hucre:[satır,sütun], kaynak:"'Dersler'!$A$1:$A$40"}] açılır liste
    if ((nk.length && satirlar.length > bs + 1) || ls.length) { var ilk = bs + 2, nkv = satirlar.length > bs + 1 ? nk : []; o.push('<dataValidations count="' + (nkv.length + ls.length) + '">');
      ls.forEach(function (l) { o.push('<dataValidation type="list" allowBlank="1" showErrorMessage="0" sqref="' + kol(l.hucre[1]) + (l.hucre[0] + 1) + '"><formula1>' + esc(l.kaynak) + '</formula1></dataValidation>'); }); nk = nkv; nk.forEach(function (c) { var son = satirlar.length, ref = kol(c) + ilk + ':' + kol(c) + son;
        o.push('<dataValidation type="custom" allowBlank="1" showErrorMessage="1" errorTitle="Geçersiz not" error="0-100 arası tam sayı ya da G (girmedi) yazın." sqref="' + ref + '"><formula1>OR(AND(ISNUMBER(' + kol(c) + ilk + '),' + kol(c) + ilk + '&gt;=0,' + kol(c) + ilk + '&lt;=100),UPPER(' + kol(c) + ilk + ')="G")</formula1></dataValidation>'); }); o.push('</dataValidations>'); }
    o.push('</worksheet>'); return o.join('');
  }
  function yaz(sayfalar) {
    var ad = sayfalar.map(function (s, i) { return (String(s.ad || 'Sayfa' + (i + 1)).replace(/[\[\]:*?\/\\]/g, '-').slice(0, 31)) || 'Sayfa' + (i + 1); });
    var d = [['[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + ad.map(function (_, i) { return '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'; }).join('') + '</Types>'],
      ['_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
      ['xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + ad.map(function (a, i) { return '<sheet name="' + esc(a) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>'; }).join('') + '</sheets></workbook>'],
      ['xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + ad.map(function (_, i) { return '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>'; }).join('') + '<Relationship Id="rId' + (ad.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'],
      ['xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="0" fillId="2" borderId="0" xfId="0" applyFill="1"/></cellXfs></styleSheet>']];
    sayfalar.forEach(function (s, i) { d.push(['xl/worksheets/sheet' + (i + 1) + '.xml', sayfaXml(s)]); });
    return zipYaz(d.map(function (x) { return [x[0], enc.encode(x[1])]; }));
  }
  async function zipOku(buf) {
    var b = new Uint8Array(buf), dv = new DataView(buf), i = b.length - 22; while (i >= 0 && dv.getUint32(i, true) !== 0x06054b50) i--; if (i < 0) throw new Error('Geçerli bir .xlsx değil');
    var n = dv.getUint16(i + 10, true), p = dv.getUint32(i + 16, true), out = {};
    for (var k = 0; k < n; k++) { var yontem = dv.getUint16(p + 10, true), csz = dv.getUint32(p + 20, true), nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), lo = dv.getUint32(p + 42, true), ad = dec.decode(b.subarray(p + 46, p + 46 + nl));
      var ln = dv.getUint16(lo + 26, true), le = dv.getUint16(lo + 28, true), bas = lo + 30 + ln + le, veri = b.subarray(bas, bas + csz);
      if (/\.xml$|\.rels$/.test(ad)) { if (yontem === 0) out[ad] = dec.decode(veri); else if (yontem === 8) out[ad] = dec.decode(await new Response(new Blob([veri]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer()); }
      p += 46 + nl + el + cl; }
    return out;
  }
  var kolNo = function (ref) { var m = /^([A-Z]+)/.exec(ref), s = m ? m[1] : 'A', n = 0; for (var i = 0; i < s.length; i++) n = n * 26 + (s.charCodeAt(i) - 64); return n - 1; };
  async function oku(buf) {
    var z = await zipOku(buf), P = new DOMParser(), xml = function (s) { return P.parseFromString(s, 'application/xml'); };
    var metin = function (el) { var t = ''; el.querySelectorAll('t').forEach(function (x) { t += x.textContent; }); return t; };
    var ss = []; if (z['xl/sharedStrings.xml']) xml(z['xl/sharedStrings.xml']).querySelectorAll('si').forEach(function (si) { ss.push(metin(si)); });
    var wb = xml(z['xl/workbook.xml']), rels = xml(z['xl/_rels/workbook.xml.rels']), hedef = {}; rels.querySelectorAll('Relationship').forEach(function (r) { hedef[r.getAttribute('Id')] = r.getAttribute('Target').replace(/^\/?(xl\/)?/, 'xl/'); });
    var out = []; wb.querySelectorAll('sheet').forEach(function (s) { var rid = s.getAttribute('r:id') || s.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id'), yol = hedef[rid]; if (!yol || !z[yol]) return;
      var sat = []; xml(z[yol]).querySelectorAll('row').forEach(function (r) { var ri = (+r.getAttribute('r') || sat.length + 1) - 1, satir = []; r.querySelectorAll('c').forEach(function (c) { var ci = kolNo(c.getAttribute('r') || ''), t = c.getAttribute('t'), v = c.querySelector('v'), d;
          if (t === 's') d = v ? ss[+v.textContent] : ''; else if (t === 'inlineStr') d = metin(c); else d = v ? v.textContent : ''; satir[ci] = d == null ? '' : String(d); });
        for (var q = 0; q < satir.length; q++) if (satir[q] === undefined) satir[q] = ''; sat[ri] = satir; });
      for (var q = 0; q < sat.length; q++) if (!sat[q]) sat[q] = []; out.push({ ad: s.getAttribute('name'), satirlar: sat }); });
    return out;
  }
  kok.ExcelNot = { yaz: yaz, oku: oku };
})(typeof globalThis !== 'undefined' ? globalThis : this);
