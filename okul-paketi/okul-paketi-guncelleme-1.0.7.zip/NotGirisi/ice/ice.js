// 1.7.0 Excel'den not girişi sayfası. Yerel ayrıştırma (SheetJS pakette). Sonuç yalnız chrome.storage.local'a (ng_ice_aktar) yazılır; ağ isteği yok.
(function () {
  'use strict';
  const I = window.NGAIce, $ = (id) => document.getElementById(id), st = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) || null;
  const esc = (x) => String(x == null ? '' : x).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const maskAd = (a) => String(a || '').trim().split(/\s+/).filter(Boolean).map((w) => w.slice(0, 1) + '…').join(' ');
  const TURAD = { sinav: 'Sınav', perf: 'Perf.', uyg: 'Uyg.', proje: 'Proje' };
  const sinifSira = (a, b) => { const sv = (z) => { const m = /^(\d+|ANA|HAZ)-(.+)$/.exec(z); return m ? [0, m[1] === 'ANA' ? 0 : m[1] === 'HAZ' ? 8.5 : +m[1], m[2]] : [0, 99, z]; }, x = sv(a), y = sv(b); return (+x[1] - +y[1]) || String(x[2]).localeCompare(String(y[2]), 'tr'); };
  const msg = (id, t, uy) => { const m = $(id); m.hidden = false; m.textContent = t; m.className = 'm ' + (uy ? 'uy' : 'ok'); };
  // Dosya -> [{ad, t}] (sayfa başına satır dizisi). CSV: UTF-8, değilse Windows-1254
  async function dosyaOku(f) { const buf = new Uint8Array(await f.arrayBuffer()); let kitap;
    if (/\.(csv|txt)$/i.test(f.name)) { let t; try { t = new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch (x) { t = new TextDecoder('windows-1254').decode(buf); } kitap = XLSX.read(t.replace(/^\ufeff/, ''), { type: 'string', raw: true }); }
    else kitap = XLSX.read(buf, { type: 'array', codepage: 1254 });
    return kitap.SheetNames.map((ad) => ({ ad, dosya: f.name, t: XLSX.utils.sheet_to_json(kitap.Sheets[ad], { header: 1, raw: true, defval: '' }) })).filter((s) => s.t.length); }
  const dropBagla = (zon, giris, isle) => { zon.onclick = () => giris.click(); giris.onchange = () => { if (giris.files.length) isle([...giris.files]); giris.value = ''; };
    zon.ondragover = (e) => { e.preventDefault(); zon.style.background = '#ffeb3b'; }; zon.ondragleave = () => { zon.style.background = ''; };
    zon.ondrop = (e) => { e.preventDefault(); zon.style.background = ''; if (e.dataTransfer.files.length) isle([...e.dataTransfer.files]); }; };

  // ---- 1) Şablon ----
  let listeler = [];
  dropBagla($('s-drop'), $('s-dosya'), async (fs) => { listeler = []; const hata = [];
    for (const f of fs) { try { for (const s of await dosyaOku(f)) { const L = I.listeOku(s.t, s.ad); if (!L || !L.ogrenciler.length) { hata.push(f.name + ' / ' + s.ad + ': Okul No sütunu bulunamadı'); continue; }
          const sinif = L.b.varsayilanSinif || (L.ogrenciler[0] && L.ogrenciler[0].sinif) || ''; const var_ = listeler.find((x) => x.sinif && x.sinif === sinif);
          if (var_) L.ogrenciler.forEach((o) => { if (!var_.ogrenciler.some((x) => x.no === o.no)) var_.ogrenciler.push(o); }); else listeler.push({ sinif, ogrenciler: L.ogrenciler }); } } catch (x) { hata.push(f.name + ': okunamadı (' + (x && x.message || x) + ')'); } }
    listeler.sort((a, b) => sinifSira(a.sinif, b.sinif)); sCiz(hata); });
  function sCiz(hata) { if (!listeler.length) { msg('s-m', 'Sınıf listesi bulunamadı. ' + (hata || []).join(' · '), true); $('s-ayar').hidden = true; return; }
    $('s-m').hidden = false; $('s-m').className = 'm ' + (listeler.some((l) => !l.sinif) || (hata && hata.length) ? 'uy' : 'ok');
    $('s-m').innerHTML = listeler.length + ' sınıf: ' + listeler.map((l, i) => l.sinif ? '<b>' + esc(l.sinif) + '</b> (' + l.ogrenciler.length + ' öğrenci)' : '<input data-i="' + i + '" class="eksik" size="5" placeholder="11-F"> (' + l.ogrenciler.length + ' öğrenci, sınıf bulunamadı: yazın)').join(' · ') + (hata && hata.length ? '<br>' + esc(hata.join(' · ')) : '');
    $('s-m').querySelectorAll('input[data-i]').forEach((x) => { x.onchange = () => { const v = I.sinifCoz(x.value); if (v) { listeler[+x.dataset.i].sinif = v; sCiz(); } }; }); $('s-ayar').hidden = false; }
  $('s-indir').onclick = async () => { if (listeler.some((l) => !l.sinif)) { msg('s-m', 'Sınıfı bulunamayan liste var; önce sınıfını yazın (ör. 11-F).', true); return; }
    const soru = Math.max(0, Math.min(30, +$('s-soru').value || 0)), sut = soru ? Array.from({ length: soru }, (_, i) => (i + 1) + '. Soru') : $('s-sutun').value.split(',').map((x) => x.trim()).filter(Boolean);
    const ogr = listeler.map((l) => ({ sinif: l.sinif, ogrenciler: l.ogrenciler.map((o) => ({ no: o.no, ad: $('s-ad').checked ? o.ad : '' })) }));
    let sf = I.sablonSayfalari(ogr, $('s-ders').value.trim(), sut);
    const v = await new Promise((r) => st ? st.get(['ngaDersSecenek', 'ngaDersSecenekS'], r) : r({})), son = (v.ngaDersSecenek && v.ngaDersSecenek.ad) || [], S = {};
    Object.entries(v.ngaDersSecenekS || {}).forEach(([k, x]) => { const c = I.sinifCoz(k) || k; if (x && x.ad && x.ad.length) S[c] = x.ad; });
    /* 1.8.4 sınıf başına: o sınıf için e-Okul'dan okunan tam liste; yoksa son okunan liste; yoksa yerleşik liste */
    const ders = listeler.map((l) => S[l.sinif] || (son.length ? son : window.NGADersler.dersler(l.sinif))); console.log('[NGA] şablon ders listeleri', listeler.map((l, i) => l.sinif + ':' + ders[i].length + (S[l.sinif] ? ' (e-Okul)' : son.length ? ' (son okunan)' : ' (yerleşik)')));
    if (!$('s-ad').checked) sf = sf.map((s) => Object.assign(s, { satirlar: s.satirlar.map((r) => r.filter((_, c) => c !== 1)), genislik: s.genislik.filter((_, c) => c !== 1), notSutunu: s.notSutunu.map((c) => c - 1) }));
    sf = I.sablonDersListesi(sf, ders); const blob = window.ExcelNot.yaz(sf), a = document.createElement('a'); a.href = URL.createObjectURL(blob); if (st) st.set({ ngaSablonIndi: Date.now() }); a.download = 'not-sablonu-' + listeler.map((l) => l.sinif).join('_') + '.xlsx'; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    msg('s-m', 'Şablon indirildi (İndirilenler klasörü): ' + sf.length + ' sayfa. Excel\'de açıp Ders hücresini ve notları doldurun, kaydedin, sonra 2. adıma bırakın.', false); };

  const dlDoldur = () => { if (!st) return; st.get('ngaDersSecenek', (v) => { const a = (v.ngaDersSecenek && v.ngaDersSecenek.ad) || [], d = a.length ? a : window.NGADersler.dersler(''); $('ders-liste').innerHTML = d.map((x) => '<option value="' + esc(x) + '">').join(''); }); }; dlDoldur();
  // Panelde "Not şablonunu indir (Excel)": öğrenilmiş sınıf listelerinden (ng_sinif_listeleri, yalnız bu bilgisayarda)
  if (/ogrenilen/.test(location.hash) && st) st.get('ng_sinif_listeleri', (v) => { const L = v.ng_sinif_listeleri || {};
    listeler = Object.keys(L).map((k) => ({ sinif: I.sinifCoz(k) || k, ogrenciler: (L[k].ogrenciler || []).filter((o) => o.no).map((o) => ({ no: String(o.no), ad: o.ad || '' })) })).filter((l) => l.ogrenciler.length).sort((a, b) => sinifSira(a.sinif, b.sinif));
    if (listeler.length) sCiz([]); else msg('s-m', 'Öğrenilmiş sınıf listesi yok: panelde "Sınıf listelerini otomatik öğren"e basın ya da e-Okul listesini bırakın.', true); });
  // 1.8.7 Adım rehberi (panel ile aynı adımlar)
  const ADIM = [['e-Okul\'a girin', 'Kullanıcı adı ve şifrenizle e-Okul\'a giriş yapın.'], ['Sınıf listelerini otomatik öğren', 'e-Okul panelinde (Toplu / otomatik işlemler); yalnız okulunuzun e-Okul\'daki şubeleri.'], ['Not şablonunu indir (Excel)', 'Tüm sınıflar tek Excel\'de, her sınıf ayrı sayfada.'], ['Excel\'i doldurun', 'Yalnız girdiğiniz sınıflarda Ders\'i seçip notları yazın; boş sınıflar atlanır.'], ['Excel\'i buraya bırakın', 'Aşağıdaki "Notlu Excel\'i bırak" kutusuna.'], ['Çalıştır', 'Notlu sınıflar e-Okul\'da sırayla açılır, notlar yazılır.'], ['Güvenlik Kodu + Kaydet', 'Her sınıfta kodu siz yazıp Kaydet\'e basın; eklenti sıradakine geçer.']];
  window.__adimSu = /ogrenilen/.test(location.hash) ? 3 : 5; const adimCiz = () => { const d = $('i-adim'); if (!d) return; const su = window.__adimSu; d.querySelector('ol').innerHTML = ADIM.map((a, i) => '<li class="' + (i + 1 < su ? 'gecti' : i + 1 === su ? 'su' : '') + '"><b>' + esc(a[0]) + '</b> — <small>' + esc(a[1]) + '</small></li>').join(''); d.querySelector('summary').textContent = 'Adım adım (şimdi: ' + su + ')'; }; adimCiz();
  // ---- 2) İçe aktar ----
  let sayfalar = [], sat = [], dersler = {};
  dropBagla($('i-drop'), $('i-dosya'), async (fs) => { sayfalar = []; dersler = {}; const hata = [];
    for (const f of fs) { try { (await dosyaOku(f)).forEach((s) => { if (s.ad === 'Dersler') return; const b = I.baslikBul(s.t, s.ad); if (b.esle.no < 0) { hata.push(f.name + ' / ' + s.ad + ': Okul No sütunu yok'); return; } sayfalar.push(Object.assign(s, { b })); }); } catch (x) { hata.push(f.name + ': okunamadı (' + (x && x.message || x) + ')'); } }
    if (!sayfalar.length) { msg('i-m', 'Okunabilir tablo yok. ' + hata.join(' · '), true); $('i-ayar').hidden = true; return; }
    // not sütunu seçenekleri: adına göre birleşik; varsayılan: içinde not olan ilk sütun
    const ad = new Map(); sayfalar.forEach((s) => I.puanSecenekleri(s.b).forEach((o) => { const k = o.i === -2 ? '__soru' : I.sade(o.ad); const dolu = s.t.slice(s.b.baslikSatir + 1).filter((r) => o.i === -2 ? s.b.esle.soru.some((c) => String(r[c] == null ? '' : r[c]).trim()) : String(r[o.i] == null ? '' : r[o.i]).trim() !== '').length;
      const e = ad.get(k) || { k, ad: o.ad, dolu: 0 }; e.dolu += dolu; ad.set(k, e); }));
    const ops = [...ad.values()]; window.__iceUyari = hata;
    if (!ops.length) { msg('i-m', 'Dosyada not sütunu bulunamadı (ör. "1. Yazılı"). e-Okul listesiyse önce 1. adımda şablon oluşturup notları yazın.', true); $('i-ayar').hidden = true; return; }
    $('i-puan').innerHTML = ops.map((o) => '<option value="' + esc(o.k) + '">' + esc(o.ad) + ' — ' + o.dolu + ' not</option>').join(''); const ilk = ops.find((o) => o.dolu) || ops[0]; $('i-puan').value = ilk.k; turAyarla(); $('i-ayar').hidden = false; hesapla();
    /* 1.8.4: dolu şablon/Excel yüklenince ek seçim yok: sınıf sayfa başlığından, ders sayfadan, not sütunu otomatik; ders eksik değilse doğrudan başlar */
    const d = window.__iceDurum || {}, doluSut = ops.filter((o) => o.dolu).length; console.log('[NGA] dosya yüklendi', { sayfa: sayfalar.length, hazir: d.hazir, dersiz: d.dersiz, doluSutun: doluSut });
    if (d.dersiz && d.dersiz.length) { msg('i-m', $('i-m').textContent + '\n⚠ Excel\'de Ders boş: ' + d.dersiz.join(', ') + '. Çalıştır\'ın yanındaki listeden dersi seçip (önceden seçili olabilir) Çalıştır\'a basın.', true); return; }
    if (d.hazir && d.hazir.length) setTimeout(() => { $('calistir').click(); if (doluSut > 1) setTimeout(() => msg('i-m', $('i-m').textContent + '\nNot: birden çok sütunda not var; şimdi "' + ilk.ad + '" giriliyor. Diğer sütun için listeden seçip yeniden Çalıştır\'a basın.', false), 300); }, 400); });
  function turAyarla() { const o = $('i-puan').selectedOptions[0]; if (!o) return; const t = $('i-puan').value === '__soru' ? { tur: 'sinav', n: 1 } : I.sutunTuru(o.textContent.replace(/ — \d+ not$/, '')); $('i-tur').value = t.tur; $('i-n').value = t.n; }
  $('i-puan').onchange = () => { turAyarla(); hesapla(); };
  $('i-tur').onchange = () => { $('i-n').max = { sinav: 6, perf: 3, uyg: 3, proje: 1 }[$('i-tur').value]; if (+$('i-n').value > +$('i-n').max) $('i-n').value = $('i-n').max; };
  // 1.8.5 Ders eksikse Çalıştır yanında tek ortak Ders listesi (e-Okul'dan okunan dersler; paneldeki seçili ders önceden seçili). Sınıf başına değişiklik tablodaki Ders kutusundan.
  let ortakK = ''; function ortakDoldur(sinifs) { if (!st) return; st.get(['ngaDersSecenek', 'ngaDersSecenekS', 'ngaSeciliDers'], (v) => {
    const S = v.ngaDersSecenekS || {}, a = [].concat(...Object.values(S).map((x) => (x && x.ad) || []), (v.ngaDersSecenek && v.ngaDersSecenek.ad) || []), sec = (v.ngaSeciliDers && v.ngaSeciliDers.ad) || '';
    let L = [...new Set(a)]; if (!L.length) L = [...new Set(sinifs.filter((x) => x !== '?').flatMap((x) => window.NGADersler.dersler(x)))]; if (sec && !L.includes(sec)) L.unshift(sec);
    const k = L.join('|') + '#' + sec; if (k === ortakK) return; ortakK = k; const e = $('i-ortak').value || sec;
    $('i-ortak').innerHTML = '<option value="">— Ders seçin —</option>' + L.map((x) => '<option>' + esc(x) + '</option>').join(''); if (e && L.includes(e)) $('i-ortak').value = e; console.log('[NGA] ortak ders listesi', L.length, 'seçili:', $('i-ortak').value); }); }
  const ortakUygula = () => { const v = $('i-ortak').value, dz = (window.__iceDurum || {}).dersiz || []; if (!v || !dz.length) return false; dz.forEach((x) => { dersler[x] = v; }); console.log('[NGA] ortak ders uygulandı', v, dz); ciz(); return true; };
  $('i-ortak').onchange = () => { ortakUygula(); };
  function hesapla() { const k = $('i-puan').value; sat = [];
    sayfalar.forEach((s) => { const o = I.puanSecenekleri(s.b).find((x) => (x.i === -2 ? '__soru' : I.sade(x.ad)) === k); const ps = o ? o.i : -9;
      I.satirlar(s.t, s.b, ps).forEach((r) => { if (ps === -9) r.puan = ''; sat.push(r); }); });
    I.ciftleriIsaretle(sat); sat.forEach((r) => { if (r.sinif && dersler[r.sinif] == null) dersler[r.sinif] = r.ders || ''; }); ciz(); }
  function ciz() { const g = {}; sat.forEach((r) => { (g[r.sinif || '?'] = g[r.sinif || '?'] || []).push(r); });
    /* 1.8.6: hiç notu olmayan sayfa/sınıf = öğretmen o sınıfa girmiyor → sessizce atlanır (ders sorulmaz, sorun sayılmaz, gidilmez) */
    const tumu = Object.keys(g).sort(sinifSira), atla = tumu.filter((x) => !g[x].some((r) => String(r.puan == null ? '' : r.puan).trim() !== '')), sinifs = tumu.filter((x) => !atla.includes(x)); window.__iceAtla = atla; if (atla.length) console.log('[NGA] notsuz sınıflar atlandı', atla);
    let h = '<table><tr><th>Sıra</th><th>Sınıf</th><th>Ders</th><th>Öğrenci</th><th>Notlu</th><th>Boş (yazılmaz)</th><th>Sorunlu</th><th>Ayrıntı</th></tr>';
    sinifs.forEach((s, i) => { const L = g[s], notlu = L.filter((r) => !r.sorun && r.puan !== ''), bos = L.filter((r) => !r.sorun && r.puan === ''), sor = L.filter((r) => r.sorun), d = dersler[s] || '';
      h += '<tr' + (sor.length || !d || s === '?' ? ' class="sorun"' : '') + '><td>' + (i + 1) + '</td><td>' + (s === '?' ? '<input data-sinif="?" size="5" class="eksik" placeholder="11-F">' : '<b>' + esc(s) + '</b>') + '</td><td><input data-ders="' + esc(s) + '" size="26" value="' + esc(d) + '"' + (d ? '' : ' class="eksik" placeholder="Ders adını yazın"') + '></td><td>' + L.length + '</td><td>' + notlu.length + '</td><td>' + bos.length + '</td><td>' + sor.length + '</td>' +
        '<td><details><summary>göster</summary>' + L.map((r) => esc(r.no) + ' ' + esc(maskAd(r.ad)) + ' → ' + esc(r.puan === '' ? '(boş)' : r.puan) + (r.sorun ? ' <b>⚠ ' + esc(r.sorun) + '</b>' : '')).join('<br>') + '</details></td></tr>'; });
    $('i-onizle').innerHTML = h + '</table>';
    $('i-onizle').querySelectorAll('input[data-ders]').forEach((x) => { x.onchange = () => { dersler[x.dataset.ders] = x.value.trim(); ciz(); }; });
    $('i-onizle').querySelectorAll('input[data-sinif]').forEach((x) => { x.onchange = () => { const v = I.sinifCoz(x.value); if (!v) return; sat.forEach((r) => { if (!r.sinif) { r.sinif = v; r.sorun = I.sorunlar(r); } }); I.ciftleriIsaretle(sat); if (dersler[v] == null) dersler[v] = ''; ciz(); }; });
    const hazir = sinifs.filter((s) => s !== '?' && dersler[s] && g[s].some((r) => !r.sorun && r.puan !== '')), dersiz = sinifs.filter((s) => s !== '?' && !dersler[s]), sorun = sat.filter((r) => r.sorun && sinifs.includes(r.sinif || '?')).length, uy = window.__iceUyari || [];
    if (sat.length && window.__adimSu < 6) { window.__adimSu = 6; adimCiz(); } $('calistir').disabled = !sat.length; /* 1.8.4: devre dışı bırakılmaz; basınca neden yazılır */ window.__iceDurum = { hazir, dersiz }; $('i-ortak-k').hidden = !dersiz.length; if (dersiz.length) ortakDoldur(sinifs);
    msg('i-m', sinifs.length + ' sınıf (notlu), ' + sat.filter((r) => sinifs.includes(r.sinif || '?')).length + ' öğrenci satırı. Sütun: ' + ($('i-puan').selectedOptions[0] || {}).textContent + ' → e-Okul ' + TURAD[$('i-tur').value] + ' ' + $('i-n').value + '.' +
      (dersiz.length ? '\n⚠ Dersi yazılmamış sınıf: ' + dersiz.join(', ') + ' (tabloda yazın).' : '') + (sorun ? '\n⚠ ' + sorun + ' sorunlu satır gönderilmez (ayrıntıya bakın).' : '') + (atla.length ? '\nNot yazılmamış ' + atla.length + ' sınıf atlandı.' : '') + (sinifs.includes('?') ? '\n⚠ Sınıfı bulunamayan ' + g['?'].length + ' satır: sınıfı yazın.' : '') + (uy.length ? '\n' + uy.join(' · ') : '') +
      (hazir.length ? '\nHazır: ' + hazir.join(', ') + '.' : '\nHenüz gönderilecek not yok.'), !!(dersiz.length || sorun || sinifs.includes('?') || !hazir.length)); }
  $('calistir').onclick = () => { window.__adimSu = 7; adimCiz(); const L = (...a) => console.log('[NGA]', ...a); if (ortakUygula()) L('eksik dersler ortak listeden dolduruldu'); const dz = (window.__iceDurum || {}).dersiz || []; L('Çalıştır basıldı', { satir: sat.length, dersler });
    if (!sat.length) { msg('i-m', 'Önce notlu Excel dosyasını seçin.', true); L('dosya yok'); return; }
    if (dz.length) { msg('i-m', '⚠ Ders seçilmedi → ' + dz.join(', ') + '. Çalıştır\'ın yanındaki "Ders (tüm sınıflar)" listesinden seçip yeniden Çalıştır\'a basın (sınıf başına farklıysa tablodaki Ders kutusu).', true); L('ders eksik', dz); return; }
    const iyi = sat.filter((r) => !r.sorun && r.puan !== '' && r.sinif && dersler[r.sinif]);
    if (!iyi.length) { msg('i-m', '⚠ Başlamadı: gönderilecek geçerli not yok (sınıf, Okul No ya da not sütununu kontrol edin).', true); L('geçerli not yok'); return; }
    const plan = { z: Date.now(), baslat: Date.now(), tur: $('i-tur').value, sinav: Math.max(1, +$('i-n').value || 1), g: $('i-g').checked, sutun: ($('i-puan').selectedOptions[0] || {}).textContent || '',
      siniflar: [...new Set(iyi.map((r) => r.sinif))].sort(sinifSira).map((s) => ({ sinif: s, ders: dersler[s], n: iyi.filter((r) => r.sinif === s).length })), satirlar: iyi.map((r) => ({ sinif: r.sinif, no: r.no, ders: dersler[r.sinif], puan: r.puan })) };
    if (!st) { msg('i-m', 'Eklenti deposu yok (sayfayı eklentiden açın).', true); return; }
    st.set({ ng_ice_aktar: plan }, async () => { let sekme = null;
      try { const t = await chrome.tabs.query({ url: ['*://e-okul.meb.gov.tr/*', '*://*.e-okul.meb.gov.tr/*', '*://eokul.meb.gov.tr/*', '*://*.eokul.meb.gov.tr/*'] }); sekme = t.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0]; L('e-Okul sekmeleri', t.length, sekme && sekme.url); } catch (x) { L('sekme listesi alınamadı', x && x.message); }
      msg('i-m', iyi.length + ' not, ' + plan.siniflar.length + ' sınıf hazır (' + plan.siniflar.map((s) => s.sinif + ': ' + s.n).join(', ') + ').' + ((window.__iceAtla || []).length ? ' Not yazılmamış ' + window.__iceAtla.length + ' sınıf atlandı.' : '') + '\n' + (sekme ? 'e-Okul sekmesine geçiliyor; Ders Notu Girişi kendiliğinden açılır.' : 'e-Okul sekmesi bulunamadı, açılıyor…; giriş yaptıktan sonra Ders Notu Girişi kendiliğinden açılır.'), false);
      if (sekme) { try { await chrome.tabs.update(sekme.id, { active: true }); await chrome.windows.update(sekme.windowId, { focused: true }); } catch (x) { L('sekmeye geçilemedi', x && x.message); } setTimeout(() => chrome.tabs.sendMessage(sekme.id, { tip: 'nga-ice' }).then(() => L('başlat iletisi gönderildi')).catch((x) => L('ileti ulaşmadı (sayfa yenileniyor olabilir; panel yüklenince kendisi başlar)', x && x.message)), 700); } else { L('e-Okul sekmesi bulunamadı, açılıyor'); try { await chrome.tabs.create({ url: 'https://e-okul.meb.gov.tr/', active: true }); } catch (x) { L('sekme açılamadı', x && x.message); msg('i-m', 'e-Okul sekmesi açılamadı; e-Okul\'u kendiniz açın, panel kendiliğinden başlar.', true); } } /* 1.8.4 e-Okul sekmesi yoksa açılır; panel kendiliğinden Ders Notu Girişi'ne gider */ }); };
})();
