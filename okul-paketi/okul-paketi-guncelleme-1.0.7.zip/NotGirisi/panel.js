// e-Okul Not Girişi Asistanı 1.1.0 — bağımsız panel. Açılır pencere yok, yüksek kontrast, veri yerelde.
// Pro ile çakışmaz: panel id "nga-panel", kısayol Alt+G, anahtarlar "nga*". Pro paneli (#ng-panel) açıksa çekilir.
(function () {
  'use strict';
  // 1.6.12: tüm e-Okul sayfalarında (ana sayfa dahil) tek çekmece: üst çerçevede; üst çerçeve frameset ise en büyük alt çerçevede
  const yerimMi = () => { if (window.top === window) return !!document.body && document.body.tagName !== 'FRAMESET';
    try { const td = window.top.document; if (!td.querySelector('frameset') || window.parent !== window.top) return false;
      const fs = [...window.parent.frames].map((f, i) => { let a = 0; try { a = f.innerWidth * f.innerHeight; } catch (e) {} return [i, a]; }).sort((x, y) => y[1] - x[1]);
      return fs.length && window.parent.frames[fs[0][0]] === window; } catch (e) { return false; } };
  if (!yerimMi() || document.getElementById('nga-panel')) return;
  const A = window.NGAAkis; if (!A) return;
  const ANAHTAR = 'ngaBekleyen', ONAY = 'ngaKvkkOnay', PRO_ID = 'ng-panel';
  const depo = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) || null;
  const onayOku = () => new Promise(r => depo ? depo.get(ONAY, v => r(!!v[ONAY])) : r(localStorage.getItem(ONAY) === '1'));
  const onayYaz = () => depo ? depo.set({ [ONAY]: true }) : localStorage.setItem(ONAY, '1');
  const p = document.createElement('div'); p.id = 'nga-panel';
  p.style.cssText = 'position:fixed;left:40px;top:56px;max-height:calc(100vh - 24px);overflow:auto;overscroll-behavior:contain;z-index:2147483001;background:#fff;color:#000;border:3px solid #000;font:14px sans-serif;padding:8px;width:300px';
  const $ = id => p.querySelector('#' + id);
  // 1.6.17: tıklanabilir öğelerde el imleci
  if (!document.getElementById('nga-imlec')) { const st = document.createElement('style'); st.id = 'nga-imlec'; st.textContent = '#nga-panel{cursor:default}#nga-panel button,#nga-panel select,#nga-panel summary,#nga-panel a,#nga-panel label,#nga-panel input[type=checkbox],#nga-panel input[type=radio],#nga-panel input[type=file],#nga-panel input[type=button],#nga-panel input[type=submit],#nga-panel [onclick],#nga-panel [role=button],#nga-panel tr[data-tik],#nga-dil{cursor:pointer!important}#nga-panel button:disabled{cursor:not-allowed!important}#nga-panel input[type=text],#nga-panel input:not([type]),#nga-panel input[type=number],#nga-panel textarea{cursor:text}'; (document.head || document.documentElement).appendChild(st); }
  // 1.8.2 Görünüm (Evrak Asistanı kartı) — yalnız CSS; tüm id'ler ve işleyiciler aynı
  if (!document.getElementById('nga-stil')) { const st = document.createElement('style'); st.id = 'nga-stil'; st.textContent = `
#nga-panel{width:330px!important;box-sizing:border-box;background:#fff!important;color:#1b2430!important;border:1px solid #d5dbe3!important;border-radius:14px!important;box-shadow:0 10px 30px rgba(16,24,40,.22)!important;font:13px/1.35 'Segoe UI',system-ui,sans-serif!important;padding:0 0 10px!important;scrollbar-width:thin}
#nga-panel>*:not(#nga-ust){margin-left:12px!important;margin-right:12px!important}
#nga-ust{position:sticky;top:0;z-index:2;display:flex;align-items:center;gap:8px;padding:9px 10px 9px 12px;margin:0 0 8px;background:linear-gradient(135deg,#0b5cad,#1786d8);color:#fff;border-radius:13px 13px 0 0;cursor:move!important;user-select:none;touch-action:none}
#nga-ust b{font-size:15px;flex:1;min-width:0}#nga-ust small{font-size:11px;opacity:.85;display:block;font-weight:400}
#nga-ust .nga-logo{width:28px;height:28px;border-radius:50%;background:#fff;color:#0b5cad;display:inline-flex;align-items:center;justify-content:center;font:800 12px sans-serif;flex:none}
#nga-ust button{background:rgba(255,255,255,.18)!important;color:#fff!important;border:0!important;border-radius:8px!important;width:28px;height:28px;padding:0!important;font-size:15px!important;cursor:pointer!important;flex:none}#nga-ust button:hover{background:rgba(255,255,255,.32)!important}
#nga-panel .nga-bolum{display:flex;align-items:center;gap:8px;margin-top:12px!important;margin-bottom:6px!important;font-weight:700;font-size:13px;color:#0b3d6e;border-bottom:1px solid #e6ebf1;padding-bottom:4px}
.nga-rozet{width:22px;height:22px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:#fff;font-size:12px;flex:none;background:#0b5cad}
.nga-rozet.y{background:#0a7d2c}.nga-rozet.t{background:#7a3fc2}.nga-rozet.s{background:#d97706}.nga-rozet.k{background:#64748b}
#nga-panel button{border-radius:9px!important;font-family:inherit!important;cursor:pointer}
#nga-panel button[id]{display:flex;align-items:center;justify-content:center;gap:8px;margin:4px 0!important;border:0!important;font-weight:600!important;padding:7px 10px!important;width:100%;background:#eef3f8!important;color:#1b2430!important;font-size:13px!important}
#nga-panel button[id]:hover{filter:brightness(.95)}
#nga-panel [hidden]{display:none!important}#nga-panel>button[id],#nga-panel details>button[id]{width:calc(100% - 24px)!important}#nga-panel details>button[id]{width:100%!important}#nga-panel button[id]{box-sizing:border-box!important;max-width:100%}
#nga-panel #nga-ust button{display:inline-flex!important;width:28px!important;height:28px;padding:0!important;margin:0!important;background:rgba(255,255,255,.18)!important;color:#fff!important;font-size:15px!important}#nga-panel #nga-ust button::before{display:none}
#nga-panel button[id]::before{width:20px;height:20px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:11px;color:#fff;background:#64748b;flex:none}
#nga-panel #nga-ice,#nga-panel #nga-ice-gir,#nga-panel #nga-tamoto{background:linear-gradient(135deg,#0a7d2c,#14a44d)!important;color:#fff!important;font-size:14px!important;padding:10px!important;box-shadow:0 3px 8px rgba(10,125,44,.3)}
#nga-panel #nga-ice::before,#nga-panel #nga-ice-gir::before,#nga-panel #nga-tamoto::before{content:'▶';background:rgba(255,255,255,.28)}
#nga-panel #nga-yaz{background:#0b5cad!important;color:#fff!important}#nga-panel #nga-yaz::before{content:'✔';background:rgba(255,255,255,.28)}
#nga-panel #nga-git::before{content:'➜';background:#0b5cad}#nga-panel #nga-tarama::before{content:'✎';background:#7a3fc2}#nga-panel #nga-ogren::before{content:'⟳';background:#d97706}
#nga-panel #nga-sablon::before{content:'⬇';background:#0a7d2c}#nga-panel #nga-ses::before{content:'●';background:#dc2626}#nga-panel #nga-tani::before{content:'i';background:#64748b}
#nga-panel #nga-sonraki{background:#fde68a!important}#nga-panel #nga-sonraki::before{content:'⏭';background:#d97706}
#nga-panel #nga-ogren,#nga-panel #nga-sablon,#nga-panel #nga-tani,#nga-panel #nga-ses,#nga-panel #nga-tarama{font-size:12px!important;padding:5px 8px!important}
#nga-panel #nga-ice-dur,#nga-panel #nga-ice-atla,#nga-panel #nga-ice-iptal,#nga-panel #nga-satir-arti,#nga-panel #nga-tur,#nga-panel #nga-eksi,#nga-panel #nga-arti,#nga-panel #nga-alan,#nga-panel #nga-onayla{display:inline-flex;width:auto;font-size:12px!important;padding:4px 9px!important;margin:2px 3px 2px 0!important}
#nga-panel #nga-ice-dur::before,#nga-panel #nga-ice-atla::before,#nga-panel #nga-ice-iptal::before,#nga-panel #nga-satir-arti::before,#nga-panel #nga-tur::before,#nga-panel #nga-eksi::before,#nga-panel #nga-arti::before,#nga-panel #nga-alan::before,#nga-panel #nga-onayla::before{display:none}
#nga-panel #nga-ice-iptal{color:#b00020!important;background:#fdecee!important}
#nga-panel input[type=text],#nga-panel input:not([type]),#nga-panel select{border:1px solid #c7d0db;border-radius:7px;padding:3px 6px;font:inherit;background:#fff;color:#1b2430}
#nga-panel #nga-tablo{border:1px solid #d5dbe3!important;border-radius:9px;background:#fbfcfe}
#nga-panel #nga-icebox>div{border:1px solid #b7d3f2!important;border-radius:10px;padding:7px!important;background:#f2f7fd!important}
#nga-panel #nga-durum{background:#f6f8fb;border-radius:9px;padding:6px 8px 6px 22px!important;font-size:12px}#nga-panel #nga-durum:empty{display:none}
#nga-panel details.nga-kat{border:1px solid #e1e6ed;border-radius:10px;padding:2px 8px;margin-top:8px!important;background:#fafbfc}#nga-panel details.nga-kat>summary{font-weight:700;color:#0b3d6e;padding:5px 0;list-style:none;display:flex;align-items:center;gap:8px}
#nga-panel details.nga-kat>summary::-webkit-details-marker{display:none}#nga-panel details.nga-kat>summary::after{content:'▾';margin-left:auto;color:#64748b}#nga-panel details.nga-kat[open]>summary::after{content:'▴'}
#nga-panel details.nga-adim ol{margin:6px 0 4px;padding-left:22px}#nga-panel details.nga-adim li{margin:3px 0;padding:3px 6px;border-radius:7px;color:#1b2430}#nga-panel details.nga-adim li small{color:#4a5565}#nga-panel details.nga-adim li.gecti{color:#6b7280}#nga-panel details.nga-adim li.su{background:#e8f0fe;border-left:4px solid #1565c0;font-weight:600}
#nga-kenar-sol::after,#nga-kenar-sag::after{content:'';position:absolute;left:5px;top:50%;width:4px;height:44px;margin-top:-22px;border-radius:3px;background:#1565c0;opacity:.55}#nga-kenar-sol:hover::after,#nga-kenar-sag:hover::after{opacity:1}
#nga-panel input,#nga-panel select,#nga-panel table{max-width:100%;box-sizing:border-box}#nga-panel #nga-tablo{overflow-x:auto}#nga-panel.nga-dar{font-size:12px!important}#nga-panel.nga-dar #nga-ust small{display:none}#nga-panel.nga-dar details.nga-adim li small{display:none}
#nga-dil{background:linear-gradient(180deg,#0b5cad,#1786d8)!important;border:0!important;border-radius:0 10px 10px 0!important;box-shadow:0 4px 12px rgba(16,24,40,.25)}
/* 1.8.3 kural: tıklanan her şey düz mavi #1565c0 + beyaz yazı; tıklanmayanlar beyaz/sade */
#nga-panel button:not(#nga-z):not(#nga-z),#nga-panel button[id]:not(#nga-z):not(#nga-z){background:#1565c0!important;color:#fff!important;border:0!important;box-shadow:none!important;filter:none!important}
#nga-panel button:not(#nga-z):not(#nga-z):hover{background:#0d47a1!important}
#nga-panel button:not(#nga-z):not(#nga-z)::before{background:rgba(255,255,255,.25)!important;color:#fff!important}
#nga-panel #nga-ust button:not(#nga-z):not(#nga-z):not(#nga-z):not(#nga-z){background:rgba(255,255,255,.18)!important}#nga-panel #nga-ust button:not(#nga-z):not(#nga-z):not(#nga-z):not(#nga-z):hover{background:rgba(255,255,255,.32)!important}
#nga-panel .nga-bolum{color:#1b2430!important}#nga-panel .nga-bolum .nga-rozet{display:none!important}
#nga-panel details.nga-kat{background:#fff!important;padding:0!important;border:0!important}
#nga-panel details.nga-kat>summary{background:#1565c0!important;color:#fff!important;border-radius:9px;padding:7px 10px!important;cursor:pointer}#nga-panel details.nga-kat>summary:hover{background:#0d47a1!important}
#nga-panel details.nga-kat>summary::after{color:#fff!important}#nga-panel details.nga-kat>summary .nga-rozet{background:rgba(255,255,255,.25)!important}
#nga-panel details.nga-kat[open]{border:1px solid #d5dbe3!important;border-radius:10px}#nga-panel details.nga-kat[open]>*:not(summary){margin-left:8px;margin-right:8px}
#nga-panel select{background:#1565c0!important;color:#fff!important;border:0!important;cursor:pointer}#nga-panel select:hover{background:#0d47a1!important}#nga-panel select option{background:#fff;color:#1b2430}
#nga-panel #nga-tablo,#nga-panel #nga-durum,#nga-panel #nga-icebox>div{background:#fff!important}
`; (document.head || document.documentElement).appendChild(st); }
  // 1.8.2 Konum: başlıktan sürüklenir (yukarı/aşağı/yana), ekranda kalır, chrome.storage.local'da saklanır
  const ILR_ADIM = 'ngaDosyaIlerleme';
  let konum = null; const KONUM = 'ngaPanelKonum2'; /* 1.8.5: sola yaslı varsayılan; eski ngaPanelKonum bir kez geçersiz */ if (depo) depo.remove('ngaPanelKonum');
  function konumUygula() { if (!konum) { p.style.right = ''; p.style.left = '40px'; p.style.top = '56px'; return; }
    const w = p.offsetWidth || 330, h = Math.min(p.offsetHeight || 200, window.innerHeight - 24); const x = Math.max(0, Math.min(window.innerWidth - w, konum.x)), y = Math.max(0, Math.min(window.innerHeight - Math.min(h, 80), konum.y));
    p.style.right = 'auto'; p.style.left = x + 'px'; p.style.top = y + 'px'; p.style.maxHeight = Math.max(160, window.innerHeight - y - 12) + 'px'; }
  if (depo) depo.get(KONUM, v => { const k = v[KONUM]; if (k && typeof k.x === 'number') { konum = k; konumUygula(); } });
  window.addEventListener('resize', () => konumUygula());
  let tasi = null;
  p.addEventListener('pointerdown', e => { const u = e.target.closest && e.target.closest('#nga-ust'); if (!u || e.target.closest('button,input,select,a')) return; const r = p.getBoundingClientRect(); tasi = { dx: e.clientX - r.left, dy: e.clientY - r.top }; u.setPointerCapture && u.setPointerCapture(e.pointerId); e.preventDefault(); });
  p.addEventListener('pointermove', e => { if (!tasi) return; konum = { x: e.clientX - tasi.dx, y: e.clientY - tasi.dy }; konumUygula(); });
  p.addEventListener('pointerup', () => { if (!tasi) return; tasi = null; const r = p.getBoundingClientRect(); konum = { x: Math.round(r.left), y: Math.round(r.top) }; if (depo) depo.set({ [KONUM]: konum }); });
  // 1.8.7 Adım rehberi (1→7); şimdiki adım vurgulu; katlanabilir (ngaAdimKapali)
  const ADIMLAR = [['e-Okul\'a girin', 'Kullanıcı adı ve şifrenizle e-Okul\'a giriş yapın.'], ['Sınıf listelerini otomatik öğren', 'Toplu / otomatik işlemler altında; yalnız okulunuzun e-Okul\'daki şubeleri okunur, öğrenci listeleri bu bilgisayara kaydedilir.'], ['Not şablonunu indir (Excel)', 'Tüm sınıflar tek Excel\'de, her sınıf ayrı sayfada.'], ['Excel\'i doldurun', 'Yalnız girdiğiniz sınıflarda Ders\'i seçip notları yazın; boş sınıflar atlanır.'], ['Excel\'i eklentiye bırakın', '"Excel\'den not gir" sayfasına dosyayı bırakın.'], ['Çalıştır', 'Notlu sınıflar sırayla açılır, notlar yazılır.'], ['Güvenlik Kodu + Kaydet', 'Her sınıfta kodu siz yazıp Kaydet\'e basın; eklenti sıradakine geçer.']];
  let adimKapali = false, adimSablon = false, adimIce = false; if (depo) depo.get(['ngaAdimKapali', 'ngaSablonIndi', ILR_ADIM], v => { adimKapali = !!v.ngaAdimKapali; adimSablon = !!v.ngaSablonIndi; adimIce = !!v[ILR_ADIM]; adimGuncelle(); });
  function adimSu() { if (adimIce || /OOK07003|NotGiris/i.test(location.href) && document.querySelector('#nga-icebox div')) return 7; if (!Object.keys(listeler).length) return 2; if (!adimSablon) return 3; return 4; }
  function adimHTML() { const su = adimSu(); return '<details id="nga-adim" class="nga-kat nga-adim"' + (adimKapali ? '' : ' open') + '><summary><span class="nga-rozet">☰</span>Adım adım (şimdi: ' + su + ')</summary><ol>' + ADIMLAR.map((a, i) => '<li class="' + (i + 1 < su ? 'gecti' : i + 1 === su ? 'su' : '') + '"><b>' + a[0] + '</b><br><small>' + a[1] + '</small></li>').join('') + '</ol></details>'; }
  function adimGuncelle() { const d = $('nga-adim'); if (!d) return; const y = document.createElement('div'); y.innerHTML = adimHTML(); d.replaceWith(y.firstChild); }
  p.addEventListener('toggle', e => { if (e.target && e.target.id === 'nga-adim') { adimKapali = !e.target.open; if (depo) depo.set({ ngaAdimKapali: adimKapali }); } }, true);
  if (depo && chrome.storage.onChanged) chrome.storage.onChanged.addListener((d, a) => { if (a !== 'local') return; if (d.ngaSablonIndi) adimSablon = !!d.ngaSablonIndi.newValue; if (d[ILR_ADIM]) adimIce = !!d[ILR_ADIM].newValue; if (d.ngaSablonIndi || d[ILR_ADIM] || d.ng_sinif_listeleri) setTimeout(adimGuncelle, 50); });
  // 1.8.7 Sol/sağ kenardan genişlik (fare + dokunmatik, pointer olayları); ngaPanelGenislik; ⟲ ile sıfırlanır
  const GEN = 'ngaPanelGenislik', genMin = 260, genMax = () => Math.max(genMin, Math.min(720, window.innerWidth - 8)); let genislik = null;
  const genUygula = () => { if (genislik) p.style.setProperty('width', Math.max(genMin, Math.min(genMax(), genislik)) + 'px', 'important'); else p.style.removeProperty('width'); p.classList.toggle('nga-dar', (p.offsetWidth || 330) < 300); kenarYerles(); };
  const kenar = ['sol', 'sag'].map(y => { const k = document.createElement('div'); k.id = 'nga-kenar-' + y; k.title = 'Genişletmek/daraltmak için sürükleyin'; k.style.cssText = 'position:fixed;width:14px;z-index:2147483003;cursor:ew-resize;touch-action:none;display:none'; return k; });
  function kenarYerles() { const r = p.getBoundingClientRect(), gor = p.isConnected && p.style.display !== 'none' && r.width > 0; kenar.forEach((k, i) => { if (!k.isConnected && document.body) document.body.appendChild(k); k.style.display = gor ? 'block' : 'none'; if (!gor) return; k.style.top = (r.top + 48) + 'px'; k.style.height = Math.max(40, r.height - 56) + 'px'; k.style.left = (i ? r.right - 7 : r.left - 7) + 'px'; }); }
  kenar.forEach((k, i) => { let b = null;
    k.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); const r = p.getBoundingClientRect(); b = { x: e.clientX, l: r.left, w: r.width, t: r.top }; k.setPointerCapture && k.setPointerCapture(e.pointerId); });
    k.addEventListener('pointermove', e => { if (!b) return; const d = e.clientX - b.x; let w = i ? b.w + d : b.w - d; w = Math.max(genMin, Math.min(genMax(), w)); let x = i ? b.l : b.l + b.w - w; x = Math.max(0, Math.min(window.innerWidth - w, x)); genislik = w; konum = { x, y: b.t }; genUygula(); konumUygula(); kenarYerles(); });
    const bit = () => { if (!b) return; b = null; if (depo) depo.set({ [GEN]: Math.round(genislik), [KONUM]: { x: Math.round(p.getBoundingClientRect().left), y: Math.round(p.getBoundingClientRect().top) } }); };
    k.addEventListener('pointerup', bit); k.addEventListener('pointercancel', bit); });
  if (depo) depo.get(GEN, v => { if (typeof v[GEN] === 'number') { genislik = v[GEN]; genUygula(); } });
  window.addEventListener('resize', () => genUygula()); window.addEventListener('scroll', kenarYerles, true); if (window.ResizeObserver) new ResizeObserver(kenarYerles).observe(p); setInterval(kenarYerles, 1000);
  const konumSifirla = () => { konum = null; if (depo) depo.remove([KONUM, GEN]); genislik = null; genUygula(); p.style.maxHeight = 'calc(100vh - 24px)'; konumUygula(); };
  // 1.8.2 Kayma düzeltmesi: panel içeriği yeniden çizilince (tablo/durum güncellemesi) iç kaydırma başa atlamasın; yalnız kullanıcı kaydırınca konum değişir
  let kayTop = 0, kullanici = 0; const kulAn = () => { kullanici = Date.now(); };
  ['wheel', 'pointerdown', 'keydown', 'touchstart'].forEach(t => p.addEventListener(t, kulAn, { passive: true }));
  p.addEventListener('scroll', () => { if (Date.now() - kullanici < 800) kayTop = p.scrollTop; else if (Math.abs(p.scrollTop - kayTop) > 1) p.scrollTop = kayTop; }, { passive: true });
  new MutationObserver(() => { if (Date.now() - kullanici > 800 && Math.abs(p.scrollTop - kayTop) > 1) p.scrollTop = kayTop; }).observe(p, { childList: true, subtree: true });
  const proAcik = () => !!document.getElementById(PRO_ID);
  // 1.6.9: sağ alt kenarda çekmece. Dile tıklayınca panel kayar; dil yukarı/aşağı sürüklenir; açık/kapalı ve yer hatırlanır.
  const dil = document.createElement('div'); dil.id = 'nga-dil'; dil.textContent = '⠿ Not'; dil.title = 'Not Girişi paneli (sürükleyip yukarı/aşağı taşıyın)';
  dil.style.cssText = 'position:fixed;left:0;bottom:120px;z-index:2147483002;background:#000;color:#fff;border:2px solid #fff;border-left:0;font:bold 14px sans-serif;padding:8px 6px;cursor:pointer;writing-mode:vertical-rl;user-select:none;touch-action:none';
  let cekAcik = true;
  const cekCiz = () => { p.style.display = cekAcik ? '' : 'none'; dil.style.left = '0'; dil.style.right = ''; konumUygula(); if (typeof kenarYerles === 'function') setTimeout(kenarYerles, 0); };
  const cekYaz = () => { if (depo) depo.set({ ngaCekmece: { acik: cekAcik, alt: dil.style.bottom } }); };
  if (depo) depo.get('ngaCekmece', v => { const c = v.ngaCekmece; if (c) { cekAcik = c.acik !== false; if (c.alt) { dil.style.bottom = c.alt; } } cekCiz(); });
  let surukle = null;
  dil.addEventListener('pointerdown', e => { surukle = { y: e.clientY, alt: parseInt(dil.style.bottom) || 0, oynadi: false }; dil.setPointerCapture && dil.setPointerCapture(e.pointerId); });
  dil.addEventListener('pointermove', e => { if (!surukle) return; const d = surukle.y - e.clientY; if (Math.abs(d) > 4) surukle.oynadi = true;
    if (surukle.oynadi) { const a = Math.max(0, Math.min(window.innerHeight - 60, surukle.alt + d)) + 'px'; dil.style.bottom = a; } });
  dil.addEventListener('pointerup', () => { if (!surukle) return; const o = surukle.oynadi; surukle = null; if (!o) { cekAcik = !cekAcik; cekCiz(); } cekYaz(); });
  const ekle = () => { if (document.body && !p.isConnected) document.body.appendChild(p); if (document.body && !dil.isConnected) document.body.appendChild(dil); cekCiz(); };
  const durumlar = {};
  const durum = (k, tur, metin) => { durumlar[k] = (tur === 'tamam' ? '✓ ' : tur === 'bekle' ? '⏳ ' : '✗ ') + metin;
    const u = $('nga-durum'); if (u) u.innerHTML = Object.values(durumlar).map(t => `<li>${t.replace(/</g, '&lt;')}</li>`).join(''); };
  let sinav = 1, tur = 'sinav', otoListele = true, alan = 'Y'; // alan: Yabancı Dil gibi derslerde Y yazılı, D dinleme, K konuşma kutusu
  if (depo) depo.get('ngaAlan', v => { if (['Y', 'D', 'K'].includes(v.ngaAlan)) { alan = v.ngaAlan; const b = $('nga-alan'); if (b) b.textContent = alan; } });
  // 1.6.17 Şube başına öğrenci listeleri (e-Okul Sınıf Listesi görüldükçe): { '10-M': { zaman, ogrenciler: [{no, ad}] } }
  let listeler = {};
  if (depo) depo.get('ng_sinif_listeleri', v => { listeler = v.ng_sinif_listeleri || {}; });
  // 1.6.28 Tam otomatik mod: sarı grupta da ilerler; her grupta e-Okul sınıf listesiyle doğrulama yapılır (güven yoksa yazmaz)
  let tamOto = true; const OGREN = 'ngaOgren', ARTIK = 'ngaArtik';
  if (depo) depo.get('ngaTamOto', v => { if (v.ngaTamOto === false) { tamOto = false; const c = $('nga-oto'); if (c) c.checked = false; } });
  const artikEkle = m => { const a = JSON.parse(sessionStorage.getItem(ARTIK) || '[]'); a.push(m); sessionStorage.setItem(ARTIK, JSON.stringify(a)); };
  const artikOzet = () => { const a = JSON.parse(sessionStorage.getItem(ARTIK) || '[]'); return a.length ? ' Dikkat: ' + a.join(' · ') : ''; };
  const sk = A.sinifAnahtar;
  const listeNolari = k => { const e = Object.keys(listeler).find(x => sk(x) === sk(k)); return e ? listeler[e].ogrenciler.map(o => o.no) : null; };
  const tumNolar = () => [...new Set(Object.values(listeler).flatMap(l => l.ogrenciler.map(o => o.no)))];
  function listedenSinif(no) { const b = Object.keys(listeler).filter(k => listeler[k].ogrenciler.some(o => o.no === no)); return b.length === 1 ? { durum: 'tek', sinif: b[0] } : { durum: b.length ? 'cok' : 'yok' }; }
  const listeAd = no => { for (const k of Object.keys(listeler)) { const o = listeler[k].ogrenciler.find(x => x.no === no); if (o) return o.ad; } return ''; };
  const maskAd = a => String(a || '').trim().split(/\s+/).filter(Boolean).map(w => w.slice(0, 1) + '…').join(' '); // ad yalnız baş harflerle gösterilir
  // Sınıfı okunamamış satıra Okul No'dan listedeki şubeyi verir (sarı kalır; ✓ ile onaylanır). Elle onaylı satıra dokunmaz.
  function sinifDoldur() { let d = 0; tablo.forEach(r => { if (r.sinif || r.basKesin || !r.no || r.kaynak) return; const b = listedenSinif(r.no); if (b.durum === 'tek') { r.sinif = b.sinif; d++; } }); return d; }
  if (depo) depo.get('ngaOtoListele', v => { if (v.ngaOtoListele === false) { otoListele = false; const k = $('nga-oto'); if (k) k.checked = false; } });
  const TURAD = { sinav: 'Sınav', perf: 'Perf.', uyg: 'Uyg.', proje: 'Proje' }, TURMAX = { sinav: 6, perf: 3, uyg: 3, proje: 1 }, TURLAR = Object.keys(TURAD);
  // 1.6.28 Sınıf listeleri bilinen şubeler için: numara listede aynen varsa sınıf el yazısı şube harfinden değil LİSTEDEN alınır;
  // numara hiçbir listede yoksa yalnız tek net yakın numaraya oturur. Düzeltilen satır sarı olur, okunan değer satırın üstünde ipucu kalır.
  let tumSubeler = []; if (depo) depo.get('ngaSubeler', v => { tumSubeler = v.ngaSubeler || []; });
  const subelerTamam = sv => { const k = tumSubeler.filter(x => String(x).split('-')[0] === String(sv)); return k.length > 0 && k.every(x => listeNolari(x)); };
  function listedenDuzelt() { if (!Object.keys(listeler).length) return 0; let d = 0;
    tablo.forEach(r => { if (!r.no || r.eksik || r.kaynak) return; const b = listedenSinif(r.no); // 1.7.0 Excel satırının sınıfı/numarası öğretmenindir, değiştirilmez
      if (b.durum === 'tek') { if (!r.sinif || sk(r.sinif) !== sk(b.sinif)) { r.os = r.os || r.sinif || ''; r.sinif = b.sinif; r.basKesin = false; d++; } return; }
      if (b.durum === 'cok' || r.kesin === true) return;
      const sv = (sinifAyir(r.sinif) || {}).sinif || r.seviye; if (!subelerTamam(sv)) return; // 1.6.28 o seviyenin bütün şubelerinin listesi bilinmiyorsa numara başka şubeninkine uydurulmaz
      const kume = tumNolar(), ad = A.noAdaylar(r.no, kume.filter(n => !tablo.some(x => x !== r && x.no === n)), 1.0, 2);
      if (ad.length && (ad.length === 1 || ad[1][1] - ad[0][1] >= 0.4)) { r.on = r.on || r.no; r.no = ad[0][0]; r.kesin = false; const bb = listedenSinif(r.no); if (bb.durum === 'tek') { r.os = r.os || r.sinif || ''; r.sinif = bb.sinif; r.basKesin = false; } d++; } });
    return d; }
  const duzelt = () => listedenDuzelt() + sinifDoldur();
  function kvkkCiz() {
    p.innerHTML = `<b>e-Okul Not Girişi Asistanı</b> <button id="nga-kapat" style="float:right">×</button>
     <p id="nga-kvkk" style="margin:6px 0">KVKK: Bu uzantı öğrenci adı, numarası ve puanlarını yalnızca bu bilgisayarda, bu sayfada işler. Hiçbir sunucuya veri göndermez. Not kaydını her zaman siz yaparsınız.</p>
     <button id="nga-onayla" style="background:#000;color:#fff;font-weight:bold">Okudum, onaylıyorum</button>`;
    $('nga-kapat').onclick = () => { cekAcik = false; cekCiz(); cekYaz(); };
    $('nga-onayla').onclick = () => { onayYaz(); anaCiz(); };
  }
  function anaCiz() {
    const ip = 'style="color:#333;font-size:12px;margin:2px 0 6px"', bb = 'style="background:#000;color:#fff;font-weight:bold;width:100%;padding:6px"';
    p.innerHTML = `<div id="nga-ust" title="Sürükleyerek taşıyın"><span class="nga-logo">EA</span><b>Not Girişi<small>Evrak Asistanı · Eyüp ŞEKER</small></b><button id="nga-konum" type="button" title="Konumu sıfırla">⟲</button><button id="nga-kapat" title="Gizle">×</button></div>
     ${adimHTML()}
     <div id="nga-pro" style="display:none;background:#ffeb3b;color:#000;border:2px solid #000;padding:4px;margin:4px 0">e-Okul Asistanı Pro'nun Not Girişi paneli de açık. Aynı anda yalnız birini kullanın.</div>
     <div class="nga-bolum"><span class="nga-rozet y">▦</span>Excel'den not gir</div>
     <button id="nga-ice" style="background:#0a7d2c;color:#fff;border:2px solid #000;font-weight:bold;width:100%;padding:6px">📄 Excel'den not gir (şablon · Çalıştır)</button>
     <div id="nga-icebox" style="font-size:12px"></div>
     <div class="nga-bolum"><span class="nga-rozet">☰</span>Not tablosu</div>
     <div id="nga-tablo" style="max-height:220px;overflow:auto;border:2px solid #000"></div>
     <div><button id="nga-satir-arti" title="Satır ekle">+</button> <span id="nga-ozet"></span></div>
     <div ${ip}>Excel'den gelen notlar burada görünür; düzeltebilir, satır ekleyebilirsiniz. Boş bırakılan öğrenciye dokunulmaz.</div>
     <div class="nga-bolum"><span class="nga-rozet s">◆</span>Sınıf · Ders · Sütun</div>
     <div id="nga-grup" style="font-weight:bold"></div>
     <div>Sınıf <input id="nga-sinif" size="4" value="9" title="9 ya da 12-A"> Şube <input id="nga-sube" size="2" value="A"></div>
     <div>Ders <select id="nga-ders" style="max-width:220px"><option value="">(sınıf seçilince dolar)</option></select></div>
     <div>Sütun <button id="nga-tur">${TURAD[tur]}</button> <button id="nga-eksi">−</button> <span id="nga-sinav">${sinav}</span> <button id="nga-arti">+</button></div>
     <div>Alan <button id="nga-alan" title="Yabancı Dil gibi Y/D/K kutulu derslerde notun yazılacağı kutu (yalnız Sınav sütununda)">${alan}</button> <span style="font-size:12px">Y yazılı · D dinleme · K konuşma</span></div>
     <details class="nga-kat"><summary><span class="nga-rozet k">⚙</span>Toplu / otomatik işlemler</summary>
     <label style="display:block;font-size:12px"><input type="checkbox" id="nga-oto" ${tamOto ? 'checked' : ''}> Tam otomatik: sarı grupta da ilerle (her grup e-Okul listesiyle doğrulanır), Kaydet sonrası sonraki grup kendiliğinden başlar</label>
     <button id="nga-tamoto" style="background:#0a7d2c;color:#fff;border:2px solid #000;font-weight:bold;width:100%;padding:6px">▶ Tam otomatik başlat (listeleri öğren + tüm grupları sınıf sırasıyla)</button>
     <button id="nga-ogren" ${bb}>Sınıf listelerini otomatik öğren</button>
     <button id="nga-sablon" style="background:#fff;color:#000;border:2px solid #000;font-weight:bold;width:100%;padding:4px" title="Öğrenilmiş sınıf listelerinden: her sınıf bir sayfa, Okul No (+Ad Soyad), Ders açılır listesi">Not şablonunu indir (Excel)</button>
     </details>
     <button id="nga-git" ${bb}>Ders Notu Girişi'ni aç ve hazırla</button>
     <div ${ip}>e-Okul'un herhangi bir sayfasından başlar. Güvenlik Kodu'nu siz yazın; liste gelir, notlar yazılır.</div>
     <button id="nga-sonraki" hidden style="background:#ffeb3b;color:#000;border:2px solid #000;font-weight:bold;width:100%;padding:6px">Sonraki grup ▶</button>
     <div class="nga-bolum"><span class="nga-rozet y">✔</span>e-Okul'a yaz</div>
     <button id="nga-yaz" style="background:#0b5;color:#000;border:2px solid #000;font-weight:bold;width:100%;padding:6px">e-Okul'a yaz</button>
     <button id="nga-ses" title="Seçili sütuna sesle not yazar: &quot;12 numara 85&quot;, &quot;Ad Soyad 85&quot;, &quot;12 numara girmedi&quot;" style="background:#000;color:#fff;border:2px solid #000;font-weight:bold;width:100%;padding:6px;margin-top:4px">🎤 Sesli not: Başlat</button>
     <div id="nga-ses-d" style="font-size:12px;font-weight:bold;padding:2px 4px;min-height:14px"></div>
     <div ${ip}>Yazılanları kontrol edip Kaydet'e siz basın.</div>
     <ul id="nga-durum" style="padding-left:16px;margin:6px 0"></ul>
     <div class="nga-bas"><button class="nga-ac" data-b="diger">+</button> <span style="font-size:12px">Ayarlar</span></div><div data-bolum="diger" hidden style="font-size:12px">
     <div><label><input type="checkbox" id="nga-oto" ${otoListele ? 'checked' : ''}> Seçimden sonra otomatik Listele</label></div>
     <div><label><input type="checkbox" id="nga-oturum" checked> e-Okul oturumunu açık tut</label> <small id="nga-oturum-d" style="color:#555"></small></div>
     <button id="nga-tani">Tanı raporu</button></div>`;
    $('nga-eksi').onclick = () => { sinav = Math.max(1, sinav - 1); $('nga-sinav').textContent = sinav; };
    $('nga-arti').onclick = () => { sinav = Math.min(TURMAX[tur], sinav + 1); $('nga-sinav').textContent = sinav; };
    $('nga-tur').onclick = () => { tur = TURLAR[(TURLAR.indexOf(tur) + 1) % TURLAR.length]; sinav = Math.min(sinav, TURMAX[tur]); $('nga-tur').textContent = TURAD[tur]; $('nga-sinav').textContent = sinav; };
    $('nga-alan').onclick = () => { alan = alan === 'Y' ? 'D' : alan === 'D' ? 'K' : 'Y'; $('nga-alan').textContent = alan; if (depo) depo.set({ ngaAlan: alan }); };
    $('nga-yaz').onclick = puanlariYaz;
    if (window.NGASes && window.NGASes.bagla) window.NGASes.bagla($('nga-ses'), $('nga-ses-d'), () => ({ tur, sinav, alan })); // 1.6.17 sesli not girişi
    p.querySelectorAll('.nga-ac').forEach(b => { const bl = p.querySelector('[data-bolum="' + b.dataset.b + '"]');
      b.onclick = () => { const kapa = !bl.hidden; bl.hidden = kapa; b.textContent = kapa ? '+' : '−'; if (depo) depo.set({ ['ngaKapali_' + b.dataset.b]: kapa }); };
      if (depo) depo.get('ngaKapali_' + b.dataset.b, v => { const k = v['ngaKapali_' + b.dataset.b]; if (k === false) { bl.hidden = false; b.textContent = '−'; } }); });
    $('nga-sablon').onclick = () => { if (!Object.keys(listeler).length) { durum('dosya', 'hata', 'Öğrenilmiş sınıf listesi yok: önce "Sınıf listelerini otomatik öğren".'); return; } if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) chrome.runtime.sendMessage({ tip: 'sekme-ac', hedef: 'iceOgren' }); };
    $('nga-ice').onclick = () => { if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) chrome.runtime.sendMessage({ tip: 'sekme-ac', hedef: 'ice' }); }; iceCiz(); // 1.7.0
    if (depo) depo.get('ng_oturum_acik', v => { $('nga-oturum').checked = v.ng_oturum_acik !== false; });
    const otDurum = () => { if (!depo || !$('nga-oturum-d')) return; depo.get(['ng_oturum_durum', 'ng_oturum_acik'], v => { const d = v.ng_oturum_durum || {}, el = $('nga-oturum-d'); if (!el) return;
      if (v.ng_oturum_acik === false) { el.textContent = ''; return; } const sa = d.nabiz ? new Date(d.nabiz).toTimeString().slice(0, 5) : '';
      el.textContent = d.dustu ? '● düştü' : sa ? '● açık (' + sa + ')' : '● açık'; el.style.color = d.dustu ? '#c00' : '#080'; }); };
    otDurum(); if (depo && chrome.storage.onChanged && !window.__ngaOtDin) { window.__ngaOtDin = true; chrome.storage.onChanged.addListener(ch => { if (ch.ng_oturum_durum || ch.ng_oturum_acik) otDurum(); }); }
    $('nga-oturum').onchange = e => { if (depo) depo.set({ ng_oturum_acik: e.target.checked }); if (e.target.checked && window.__NGOturum) window.__NGOturum.nabiz(); };
    $('nga-oto').onchange = e => { otoListele = e.target.checked; if (depo) depo.set({ ngaOtoListele: otoListele }); };
    $('nga-tani').onclick = async () => { let t = A.taniRaporu(document);
      try { const d = A.dersSelect(document), gs = gruplar(); t += '\n-- PANEL (1.6.24): ders=' + ($('nga-ders') ? $('nga-ders').value : '?') + ' sinif=' + ($('nga-sinif') ? $('nga-sinif').value : '?') + '/' + ($('nga-sube') ? $('nga-sube').value : '?') + ' sinav=' + sinav + ' tur=' + tur + ' alan=' + alan + ' aktif=' + aktif;
        gs.forEach((g, i) => { const r = tablo.find(x => anahtar(x) === g.k) || {}, e = d && g.ders ? A.dersEsle(d, g.ders) : null; t += '\n  grup ' + (i + 1) + ': sinif="' + g.sinif + '" ders="' + g.ders + '" seviye=' + (r.seviye || '-') + ' sinavNo=' + (r.sinavNo || '-') + ' n=' + g.n + ' kesin=' + g.kesin + ' eşleşme=' + (e ? (e.op ? e.op.textContent.trim() + ' %' + Math.round((e.puan || 0) * 100) : 'YOK adaylar=' + (e.adaylar || []).join('/')) : '-'); });
        if (!gs.length) t += '\n  tablo boş (tarama okuması panele gelmedi)'; } catch (e) { t += '\n-- PANEL hata: ' + e.message; }
      try { await navigator.clipboard.writeText(t); durum('tani', 'tamam', 'Tanı raporu panoya kopyalandı (ad/TC yok). Bana yapıştırıp gönderin.'); }
      catch (e) { const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'width:100%;height:80px'; p.appendChild(ta); ta.select(); durum('tani', 'tamam', 'Rapor aşağıda seçili; Ctrl+C ile kopyalayın.'); } };
    $('nga-konum').onclick = konumSifirla; $('nga-kapat').onclick = () => { cekAcik = false; cekCiz(); cekYaz(); }; /* 1.6.22: × paneli kapatmaz, sağ kenara kaydırır; '⠿ Not' diliyle geri açılır */
    $('nga-oto').onchange = e => { tamOto = e.target.checked; if (depo) depo.set({ ngaTamOto: tamOto }); };
    $('nga-tamoto').onclick = () => tamOtoBaslat();
    $('nga-ogren').onclick = async () => { if (sessionStorage.getItem(OGREN)) { sessionStorage.removeItem(OGREN); $('nga-ogren').textContent = 'Sınıf listelerini otomatik öğren'; durum('ogren', 'hata', 'Öğrenme durduruldu.'); return; } await tabloYukleP(); $('nga-ogren').textContent = 'Öğrenmeyi durdur'; ogrenBaslat(false); };
    $('nga-git').onclick = async () => {
      if (proAcik()) { $('nga-pro').style.display = 'block'; durum('cakisma', 'hata', 'Pro paneli açık; önce onu kapatın.'); return; }
      await tabloYukleP(); // 1.6.15 grup tablosu yüklenmeden eski/varsayılan sınıfla başlanmasın
      const g = gruplar()[aktif];
      if (g && g.sinif) { if (!g.kesin && !tamOto) { durum('grup', 'hata', 'Grup ' + (aktif + 1) + ' sınıf/ders sarı: tabloda grup başlığını kâğıtla karşılaştırıp düzeltin ya da ✓ ile onaylayın.'); return; }
        if (!g.kesin) durum('grup', 'bekle', 'Grup ' + (aktif + 1) + ' sarı (kâğıttan okundu): e-Okul sınıf listesiyle doğrulanacak.');
        const a = sinifAyir(g.sinif) || { sinif: g.sinif, sube: '' }; calis({ sinif: a.sinif, sube: a.sube, ders: g.ders || $('nga-ders').value.trim(), sinav, tur, grup: aktif }); return; }
      if (!$('nga-sinif').value.trim() || !$('nga-sube').value.trim()) { durum('grup', 'hata', 'Sınıf/şube yok: kâğıtları okutun ya da 3. adımda yazın.'); return; }
      calis({ sinif: $('nga-sinif').value.trim(), sube: $('nga-sube').value.trim(), ders: $('nga-ders').value.trim(), sinav, tur });
    };
    $('nga-sonraki').onclick = () => { const gs = gruplar(); if (aktif + 1 >= gs.length) return; aktif++; grupYaz(); tabloCiz(); $('nga-sonraki').hidden = true; delete durumlar.yaz; $('nga-git').click(); };
    // e-Okul'daki ders listesinden seçilen ders aktif grubun dersi olur (asistan emin olamadığında)
    $('nga-ders').onchange = e => { const g = gruplar()[aktif], v = e.target.value; if (!g || !v) return; tablo.forEach(r => { if (anahtar(r) === g.k) { r.ders = v; r.basKesin = true; } }); tabloKaydet(); };
    $('nga-pro').style.display = proAcik() ? 'block' : 'none';
    sonDoldur(); tabloYukle();
    $('nga-satir-arti').onclick = () => { tablo.push({ no: '', not: '', kesin: false }); tabloKaydet(); };
    $('nga-tablo').addEventListener('paste', e => { const t = (e.clipboardData || window.clipboardData).getData('text'); if (!t || !/[\t\n]/.test(t)) return; e.preventDefault();
      // Sütunlar: Okul No, (Sınıf: 10-M / 10/M / 10 M), (Ad), Not (son sayı ya da G). Sınıf sütunu varsa satır o gruba girer.
      t.split(/\r?\n/).map(l => l.split('\t').map(x => x.trim())).forEach(c => { const ni = c.findIndex(x => /^\d{1,6}$/.test(x)); if (ni < 0) return;
        const si = c.findIndex((x, i) => i !== ni && /^\d{1,2}\s*[-/. ]?\s*[A-Za-zÇĞİÖŞÜçğıöşü]$/.test(x)), ay = si >= 0 ? sinifAyir(c[si]) : null;
        let pi = -1; c.forEach((x, i) => { if (i !== ni && i !== si && /^(\d{1,3}|G)$/i.test(x)) pi = i; });
        tablo.push({ no: c[ni], not: pi >= 0 ? c[pi].toUpperCase() : '', kesin: true, sinif: ay ? ay.sinif + '-' + ay.sube : '', basKesin: !!ay }); }); duzelt(); tabloKaydet(); });
  }
  // 1.6.9 Panel tablosu (Okul No | Not): ng_not_tablosu; yoksa son okumadan kurulur. Düzeltilen/✓ satır kesin; tekrarlanan no ya da geçersiz not sarı.
  let tablo = [], aktif = 0;
  // 1.6.11 Gruplar: karışık kâğıtlar sınıf+ders'e göre gruplanır; her grup sırayla işlenir
  const anahtar = r => (r.sinif || '') + '|' + (r.ders ? A.dersKanon(r.ders) : ''); // 1.6.36 "Tarih" ve "T.C. İnkılap Tarihi…" aynı grup
  function gruplar() { const m = []; tablo.forEach(r => { const k = anahtar(r); let g = m.find(x => x.k === k); if (!g) { g = { k, sinif: r.sinif || '', ders: r.ders || '', kesin: true, n: 0 }; m.push(g); } g.n++; if (!r.basKesin || !r.sinif || !/^\d{1,2}-[A-ZÇĞİÖŞÜ]$/i.test(r.sinif) || !r.ders) g.kesin = false; });
    // 1.6.28 sınıflara göre sırayla: 9-A, 10-M, 11-D, 11-F, 12-A…; şubesi okunamayan gruplar en sonda
    m.sort((a, b) => { const x = sinifAyir(a.sinif), y = sinifAyir(b.sinif); if (!x !== !y) return x ? -1 : 1; if (x && y) return (+x.sinif - +y.sinif) || x.sube.localeCompare(y.sube, 'tr') || String(a.ders).localeCompare(String(b.ders), 'tr'); return String(a.ders).localeCompare(String(b.ders), 'tr'); });
    return m; }
  function grupYaz() { if (depo) depo.set({ ngaAktifGrup: aktif }); }
  if (depo) depo.get('ngaAktifGrup', v => { if (typeof v.ngaAktifGrup === 'number') aktif = v.ngaAktifGrup; });
  const notOk = v => { v = String(v).trim().toUpperCase(); return v === 'G' || (/^\d{1,3}$/.test(v) && +v <= 100); };
  let kosuSon = 0;
  function tabloKaydet() { if (depo) depo.set({ ng_not_tablosu: { zaman: Date.now(), kosu: kosuSon, satirlar: tablo.map(satirK) } }); tabloCiz(); }
  const satirK = r => ({ no: r.no, not: r.not, kesin: !!r.kesin, eksik: !!r.eksik, sinif: r.sinif || '', ders: r.ders || '', alan: r.alan || '', basKesin: !!r.basKesin, seviye: r.seviye || '', sinavNo: r.sinavNo || 0, on: r.on || '', os: r.os || '', kaynak: r.kaynak || '' }); // 1.7.0 kaynak: 'dosya' (Excel, eksiklere G yok) / 'dosyaG'
  const tabloYukleP = () => new Promise(r => { if (!depo) return r(); depo.get('ngaAktifGrup', v => { if (typeof v.ngaAktifGrup === 'number') aktif = v.ngaAktifGrup; tabloYukle(r); }); });
  function tabloYukle(bitti) { if (!depo) return bitti && bitti(); depo.get(['ng_not_tablosu', 'tarama_taslak'], v => { const nt = v.ng_not_tablosu, tk = v.tarama_taslak;
    // 1.6.25: panel düzeltmeleri yalnız aynı okumaya (kosu) aitse kullanılır; yeni okuma her zaman eskisinin yerine geçer
    kosuSon = tk && tk.kosu || 0;
    if (nt && nt.satirlar && (tk && tk.kosu ? nt.kosu === tk.kosu : (!tk || !tk.zaman || nt.zaman >= tk.zaman - 10000))) tablo = nt.satirlar.map(r => Object.assign({}, r, String(r.not || '').trim() === '' ? { not: 'G', kesin: false } : {}));
    else if (tk && tk.sonuc) tablo = tk.sonuc.filter(r => r.no && r.no.deger).map(r => { const pu = toplam(r); const bs = r.bas || {}; return { no: r.no.deger, not: pu === '' ? 'G' : pu, kesin: r.sari === false && pu !== '' && notOk(pu), sinif: bs.sinif || '', ders: bs.ders || '', alan: bs.alan || '', basKesin: !!bs.kesin, seviye: bs.seviye || '', sinavNo: bs.sinavNo || 0 }; });
    if (duzelt()) tabloKaydet(); else tabloCiz(); bitti && bitti(); }); }
  if (depo && chrome.storage.onChanged) chrome.storage.onChanged.addListener((d, a) => { if (a === 'local' && (d.ng_not_tablosu || d.tarama_taslak) && $('nga-tablo') && !(d.ng_not_tablosu && d.ng_not_tablosu.newValue && JSON.stringify(d.ng_not_tablosu.newValue.satirlar) === JSON.stringify(tablo.map(satirK)))) tabloYukle(); });
  if (depo && chrome.storage.onChanged) chrome.storage.onChanged.addListener((d, a) => { if (a === 'local' && d.ng_sinif_listeleri) { listeler = d.ng_sinif_listeleri.newValue || {}; if ($('nga-tablo')) { if (duzelt()) tabloKaydet(); else tabloCiz(); } } });
  function tabloCiz() { const k = $('nga-tablo'); if (!k) return; const nolar = tablo.map(r => r.no), gs = gruplar(); if (aktif >= gs.length) aktif = Math.max(0, gs.length - 1);
    k.innerHTML = '<table style="border-collapse:collapse;width:100%"><tr><th>Okul No</th><th>Not</th><th></th></tr></table>'; const tb = k.firstChild;
    let sari = 0; const cok = gs.length > 1 || (gs[0] && gs[0].sinif);
    gs.forEach((g, gi) => {
      if (cok) { const tr = tb.insertRow(), c = tr.insertCell(); c.colSpan = 3; tr.style.background = g.kesin ? '#000' : '#ffeb3b'; tr.style.color = g.kesin ? '#fff' : '#000'; c.style.cssText = 'padding:3px;font-weight:bold;border-top:3px solid #000';
        const et = document.createElement('span'); et.textContent = (gi === aktif ? '▶ ' : '') + 'Grup ' + (gi + 1) + ' (' + g.n + ') '; c.appendChild(et);
        [['sinif', 4, 'Sınıf (ör. 10-M)'], ['ders', 12, 'Ders']].forEach(([a, sz, t]) => { const x = document.createElement('input'); x.value = g[a]; x.size = sz; x.title = t; x.placeholder = t;
          x.onchange = () => { const v = a === 'sinif' ? x.value.trim().toUpperCase().replace(/\s*[/.]\s*|\s+/g, '-') : x.value.trim(); tablo.forEach(r => { if (anahtar(r) === g.k) { r[a] = v; r.basKesin = true; } }); tabloKaydet(); }; c.appendChild(x); });
        if (!g.kesin && /^\d{1,2}-[A-ZÇĞİÖŞÜ]$/i.test(g.sinif) && g.ders) { const o = document.createElement('button'); o.textContent = '✓'; o.title = 'Sınıf ve dersi kâğıtla karşılaştırdım'; o.onclick = () => { tablo.forEach(r => { if (anahtar(r) === g.k) r.basKesin = true; }); tabloKaydet(); }; c.appendChild(o); }
        const sec = document.createElement('button'); sec.textContent = '▶'; sec.title = 'Bu grubu işle'; sec.onclick = () => { aktif = gi; grupYaz(); tabloCiz(); }; c.appendChild(sec);
        const m = document.createElement('button'); m.textContent = '−'; m.title = 'Grubu sil'; m.onclick = () => { tablo = tablo.filter(r => anahtar(r) !== g.k); tabloKaydet(); }; c.appendChild(m);
        const ar = document.createElement('button'); ar.textContent = '+'; ar.title = 'Bu gruba satır ekle'; ar.onclick = () => { tablo.push({ no: '', not: '', kesin: false, sinif: g.sinif, ders: g.ders, basKesin: true }); tabloKaydet(); }; c.appendChild(ar); }
      tablo.forEach((r, i) => { if (anahtar(r) !== g.k) return; const cift = nolar.indexOf(r.no) !== nolar.lastIndexOf(r.no);
        const lb = r.no ? listedenSinif(r.no) : { durum: 'yok' }, cel = !!(r.sinif && lb.durum === 'tek' && sk(lb.sinif) !== sk(r.sinif)); // kâğıttaki şube ile listedeki şube farklı
        const sr = !r.kesin || cift || !r.no || !notOk(r.not) || cel; if (sr) sari++;
        const tr = tb.insertRow(); tr.style.background = sr ? '#ffeb3b' : '#c8f7c5';
        ['no', 'not'].forEach(a => { const x = document.createElement('input'); x.value = r[a]; x.size = a === 'no' ? 6 : 3; if (a === 'no' && r.on) x.title = 'Kâğıttan okunan: ' + r.on; x.onchange = () => { r[a] = x.value.trim().toUpperCase(); r.kesin = true; tabloKaydet(); }; tr.insertCell().appendChild(x); });
        const ad = r.no ? listeAd(r.no) : ''; if (ad) { const sp = document.createElement('small'); sp.textContent = ' ' + maskAd(ad); sp.title = 'e-Okul listesindeki ad (baş harfler): kâğıttaki adla karşılaştırın'; tr.cells[0].appendChild(sp); }
        const c = tr.insertCell();
        if (cel) { const o = document.createElement('button'); o.textContent = '→' + lb.sinif; o.title = 'Numara e-Okul listesinde ' + lb.sinif + ' şubesinde; satırı oraya al'; o.onclick = () => { r.sinif = lb.sinif; r.basKesin = false; tabloKaydet(); }; c.appendChild(o); }
        { const gn = r.sinif ? listeNolari(r.sinif) : null, kume = gn || (Object.keys(listeler).length ? tumNolar() : null); // numara listede yoksa en yakın birkaç numara önerilir
          if (kume && r.no && !kume.includes(r.no)) A.noAdaylar(r.no, kume.filter(n => !nolar.includes(n)), 1.5, 3).forEach(([n]) => { const o = document.createElement('button'); o.textContent = n + '?'; o.title = 'Listede yakın numara: ' + (maskAd(listeAd(n)) || n) + ' — kâğıttaki adla karşılaştırıp seçin'; o.onclick = () => { r.no = n; r.kesin = false; tabloKaydet(); }; c.appendChild(o); }); }
        if (sr && r.no && notOk(r.not) && !cift && !cel) { const o = document.createElement('button'); o.textContent = '✓'; o.title = 'Kâğıtla karşılaştırdım'; o.onclick = () => { r.kesin = true; tabloKaydet(); }; c.appendChild(o); }
        const m = document.createElement('button'); m.textContent = '−'; m.title = 'Satırı sil'; m.onclick = () => { tablo.splice(i, 1); tabloKaydet(); }; c.appendChild(m); }); });
    const oz = $('nga-ozet'); if (oz) oz.textContent = tablo.length ? tablo.length + ' satır, ' + sari + ' sarı' + (gs.length > 1 ? ', ' + gs.length + ' grup' : '') : 'Henüz okunmuş kâğıt yok.';
    const gk = $('nga-grup'), g = gs[aktif]; if (gk) gk.textContent = g && g.sinif ? 'Grup ' + (aktif + 1) + '/' + gs.length + ': ' + g.sinif + ' · ' + (g.ders || '?') + (g.kesin ? '' : ' (sarı, kontrol edin)') : '';
    if (gk) gk.style.background = g && g.sinif && !g.kesin ? '#ffeb3b' : '';
    adim3Doldur(g); if (dosyaKip()) iceCiz(); }
  // 1.6.12 Grup başlığı tek kaynak: aktif grubun sınıfı (10-M -> Sınıf 10, Şube M) ve dersi 3. adıma yazılır
  const sinifAyir = s => { const m = String(s || '').trim().match(/^(\d{1,2}|ANA|HAZ)\s*[-/. ]?\s*([A-Za-zÇĞİÖŞÜçğıöşü]+)$/); /* 1.8.6 ANA/HAZ: anasınıfı/hazırlık */ return m ? { sinif: m[1], sube: m[2].toLocaleUpperCase('tr-TR') } : null; };
  function adim3Doldur(g) { if (!g) return; { const ra = tablo.find(r => anahtar(r) === g.k && /^[DK]$/.test(r.alan || '')); /* 1.6.17: başlıkta DİNLEME/KONUŞMA okunduysa Alan kendiliğinden */ if (ra && $('nga-alan')) { alan = ra.alan; $('nga-alan').textContent = alan; if (depo) depo.set({ ngaAlan: alan }); } }
    // 1.6.22 basılı başlıktaki "1. SINAV" -> Sınav sütunu; "11. SINIF" -> sınıf seviyesi; ders, şube el yazısı okunamasa da seçilir
    { const rs = tablo.find(r => anahtar(r) === g.k && r.sinavNo); if (rs && tur === 'sinav' && rs.sinavNo <= TURMAX[tur]) { sinav = rs.sinavNo; if ($('nga-sinav')) $('nga-sinav').textContent = sinav; } }
    if (!g.sinif) { const rv = tablo.find(r => anahtar(r) === g.k && r.seviye); if (rv && $('nga-sinif')) $('nga-sinif').value = rv.seviye; if (g.ders) dersSecenek(g.ders); return; } const a = sinifAyir(g.sinif);
    if (a && $('nga-sinif')) { $('nga-sinif').value = a.sinif; $('nga-sube').value = a.sube; }
    if (g.ders) dersSecenek(g.ders); }
  // 1.6.5: tarama ekranındaki son okuma (tarama_taslak) Okul No ile eşleştirilip seçili sütuna yazılır. Kaydet'e siz basarsınız.
  const toplam = r => { const d = (r.puanlar || []).map(x => String(x.deger == null ? '' : x.deger).replace(',', '.'));
    if (d.some(v => v.toUpperCase() === 'G')) return 'G'; if (!d.length || d.some(v => v === '')) return '';
    const t = d.reduce((a, v) => a + Number(v), 0); return isNaN(t) ? '' : String(Math.round(t)); };
  let yaziyor = false;
  function puanlariYaz() {
    durum('yaz', 'bekle', 'Notlar tek tek yazılıyor…');
    if (!depo) { durum('yaz', 'hata', 'Depolama yok'); return; }
    depo.get(['tarama_taslak', 'ng_not_tablosu'], async v => { const tk = v.tarama_taslak; if (yaziyor) return; yaziyor = true; try {
      // 1.6.28 Panelde grupları görünen tablo (sınıf/ders/numara düzeltmeleri dahil) her zaman yazılan kaynaktır; önceden kosu uyuşmazlığında gruplamasız, sınıf doğrulamasız yedek yola düşülebiliyordu
      const nt = tablo.length ? { zaman: Date.now(), kosu: kosuSon, satirlar: tablo.map(satirK) } : v.ng_not_tablosu;
      // 1.6.8: tarama ekranındaki "Not tablosu"ndan verilen satırlar (kontrol edilmiş) önceliklidir
      if (nt && nt.satirlar && nt.satirlar.length && (tk && tk.kosu ? nt.kosu === tk.kosu : (!tk || !tk.zaman || nt.zaman >= tk.zaman - 10000))) { // 1.6.25 yalnız aynı okumanın düzeltmeleri
        const gs = gruplar(), g = gs[aktif];
        // 1.6.28 Doğrulama: grubun kâğıt numaralarının en az %60'ı e-Okul'daki bu sınıf listesinde değilse şube/ders yanlış okunmuştur; HİÇBİR ŞEY yazılmaz
        if (g && g.sinif) { const T0 = A.ogrenciTablosu(document); if (T0) { const pn = new Set(T0.satirlar.map(tr => tr.cells[0].textContent.replace(/\D/g, ''))), kn = nt.satirlar.filter(r => anahtar(r) === g.k && !r.eksik && r.no), es = kn.filter(r => pn.has(String(r.no))).length;
            if (kn.length >= 3 && es / kn.length < 0.6) { const m = 'Grup ' + (aktif + 1) + ' (' + g.sinif + ' · ' + (g.ders || '?') + '): kâğıt numaralarının yalnız ' + es + '/' + kn.length + ' kadarı bu sınıf listesinde; şube ya da ders yanlış okunmuş olabilir, hiçbir şey yazılmadı.';
              durum('yaz', 'hata', m); artikEkle(m); A.adimLog(document, 'yaz:atlandı ' + m);
              if (tamOto && aktif + 1 < gs.length) { durum('sonraki', 'bekle', 'Sonraki gruba geçiliyor…'); setTimeout(() => { if ($('nga-sonraki')) $('nga-sonraki').click(); }, 1500); } return; } } }
        // 1.6.11 Listede olup kâğıdı okunmamış öğrenciler tabloya "G" (sarı) olarak eklenir; e-Okul'da değeri varsa dokunulmaz
        const T = A.ogrenciTablosu(document), dk = (g ? nt.satirlar.filter(r => anahtar(r) === g.k) : nt.satirlar).find(r => r.kaynak), gYok = dk && dk.kaynak === 'dosya';
        if (T && gYok) { const var_ = new Set(nt.satirlar.filter(r => anahtar(r) === g.k).map(r => String(r.no))), yok = T.satirlar.map(tr => tr.cells[0].textContent.replace(/\D/g, '')).filter(no => no && !var_.has(no)); // 1.7.0 Excel: dosyada notu olmayana dokunulmaz, bildirilir
          if (yok.length) { durum('eksik', 'bekle', yok.length + ' öğrencinin Excel\'de notu yok, dokunulmadı: ' + yok.join(', ')); artikEkle((g ? g.sinif : '') + ': Excel\'de notu olmayan ' + yok.join(', ')); } else delete durumlar.eksik; }
        if (T && !gYok) { const var_ = new Set(nt.satirlar.map(r => String(r.no))), yeni = [];
          T.satirlar.forEach(tr => { const no = tr.cells[0].textContent.replace(/\D/g, ''); if (no && !var_.has(no)) yeni.push({ no, not: 'G', kesin: false, eksik: true, sinif: g ? g.sinif : '', ders: g ? g.ders : '', basKesin: true, kaynak: dk ? dk.kaynak : '' }); });
          if (yeni.length) { tablo = tablo.concat(yeni); nt.satirlar = nt.satirlar.concat(yeni); tabloKaydet(); durum('eksik', 'bekle', yeni.length + ' öğrencinin kâğıdı yok: tabloya G (sarı) eklendi, e-Okul\'da boş olanlara G yazılıyor. Kontrol edin.'); } }
        // 1.6.17 Güvenlik: sayfada seçili şube/ders grupla uyuşmuyorsa HİÇBİR ŞEY yazılmaz (eksik öğrencilere G yazılırken yanlış şube bozulmasın)
        const pk = A.sayfaSinifi(document), pd = A.sayfaDersi(document);
        if (g && g.sinif && pk && sk(pk) !== sk(g.sinif)) { durum('yaz', 'hata', 'Sayfada ' + pk + ' seçili ama grup ' + g.sinif + ': hiçbir şey yazılmadı. Şubeyi ya da grubu düzeltip yeniden yazın.'); return; }
        if (g && g.ders && pd && A.dersPuan(g.ders, pd) < 0.6) { durum('yaz', 'hata', 'Sayfada "' + pd + '" seçili ama grup dersi "' + g.ders + '": hiçbir şey yazılmadı. Dersi düzeltin.'); return; }
        const sat = g && g.sinif ? nt.satirlar.filter(r => anahtar(r) === g.k) : nt.satirlar;
        const excelGrup = sat.length > 0 && sat.every(r => /^dosya/.test(r.kaynak || '')); // 1.9.0 Excel notları: bekleme yok (hızlı), yakın numara uydurma yok
        const s = await A.puanYazYavas(document, tur, sinav, sat.map(r => ({ no: r.no, puan: r.not, kesin: r.kesin === true, eksik: !!r.eksik })), excelGrup ? { alan, hiz: 0, yakinYok: true } : { alan });
        if (!s.ok) { durum('yaz', 'hata', s.neden); return; }
        durum('yaz', s.yazilan ? 'tamam' : 'hata', 'Not tablosundan ' + s.yazilan + '/' + s.satir + ' satıra yazıldı' + (tur === 'sinav' && alan !== 'Y' ? ' (' + (alan === 'D' ? 'Dinleme' : 'Konuşma') + ' kutusu)' : '') + (s.ustune ? ', ' + s.ustune + ' kutuda eski değerin üzerine yazıldı' : '') + ', ' + s.sari + ' sarı' + (s.kutusuz ? ', ' + s.kutusuz + ' satırda kutu yok' : '') + (s.eslesmeyen.length ? ', listede olmayan ' + s.eslesmeyen.length : '') + '. Kaydet\'e siz basın.' + (g && g.sinif ? ' (Grup ' + (aktif + 1) + '/' + gs.length + ')' : ''));
        if ($('nga-sonraki')) $('nga-sonraki').hidden = !(g && aktif + 1 < gs.length); if (s.eslesmeyen.length) artikEkle('Grup ' + (aktif + 1) + (g && g.sinif ? ' (' + g.sinif + ')' : '') + ': listede olmayan numara ' + s.eslesmeyen.join(', '));
        if (g && aktif + 1 < gs.length) { durum('sonraki', 'bekle', 'Güvenlik Kodu\'nu yazıp Kaydet\'e siz basın; kayıt başarılı olunca sonraki grup kendiliğinden başlar (olmazsa "Sonraki grup").'); kaydetBekle(aktif); } else { delete durumlar.sonraki; if (g && g.sinif) { durum('sonraki', 'bekle', 'Son grup: Güvenlik Kodu\'nu yazıp Kaydet\'e siz basın.'); kaydetBekle(aktif); } } return; }
      if (!tk || !tk.sonuc || !tk.sonuc.length) { durum('yaz', 'hata', 'Yazılacak not yok. Önce "Excel\'den not gir" ile notları yükleyin.'); return; }
      const sn = tk.sonuc.filter(r => r.no && r.no.deger).map(r => { const pu = toplam(r); return { no: r.no.deger, puan: pu, kesin: r.sari === false && pu !== '' && (pu === 'G' || +pu <= 100) }; });
      { const T = A.ogrenciTablosu(document), var_ = new Set(sn.map(r => String(r.no))); let ek = 0; // 1.6.27 kâğıdı okunmayan öğrenciye G (e-Okul'da değeri varsa dokunulmaz)
        if (T) T.satirlar.forEach(tr => { const no = tr.cells[0].textContent.replace(/\D/g, ''); if (no && !var_.has(no)) { sn.push({ no, puan: 'G', kesin: false, eksik: true }); ek++; } });
        if (ek) durum('eksik', 'bekle', ek + ' öğrencinin kâğıdı okunmadı: e-Okul\'da boş olanlara G (girmedi) yazılıyor, sarı. Kontrol edin.'); }
      const s = await A.puanYazYavas(document, tur, sinav, sn, { alan });
      if (!s.ok) { durum('yaz', 'hata', s.neden); return; }
      durum('yaz', s.yazilan ? 'tamam' : 'hata', s.yazilan + '/' + s.satir + ' satıra yazıldı, ' + s.sari + ' sarı satır kontrol bekliyor' + (s.kutusuz ? ', ' + s.kutusuz + ' satırda kutu yok (sütun işaretli mi?)' : '') + (s.eslesmeyen.length ? ', listede olmayan ' + s.eslesmeyen.length + ' okuma' : '') + '. Kaydet\'e siz basın.'); } finally { yaziyor = false; } });
  }
  // 1.6.6: Güvenlik Kodu'nu asistan OKUMAZ/YAZMAZ. Siz 4 rakamı yazınca (sütun kutusu işaretliyse) ~400 ms sonra Listele'ye basılır;
  // liste gelince okunmuş kâğıt varsa puanlar yazılır. Kaydet'e asla basılmaz.
  const OTO = 'ngaOtoYaz';
  // 1.6.15 Güvenlik Kodu yalnız Kaydet içindir; asistan kod kutusuna hiç dokunmaz/bakmaz. Listele'ye seçimden sonra bir kez basılır.
  const listeleDugmesi = () => document.getElementById('btnListele') || [...document.querySelectorAll('input[type=submit],input[type=button],button,a')].find(b => A.norm(b.value || b.textContent) === 'listele');
  function listeBekleYaz() { let i = 0; const t = setInterval(() => { const T = A.ogrenciTablosu(document);
      if (T && T.satirlar.length) { clearInterval(t); (sessionStorage.getItem(DOSYA) ? sabitBekle() : Promise.resolve()).then(() => { A.adimLog(document, 'liste:tamam ' + A.ogrenciTablosu(document).satirlar.length + ' satır; yazma başlıyor'); const f = JSON.parse(sessionStorage.getItem(OTO) || 'null'); sessionStorage.removeItem(OTO); if (!f) return;
        tur = f.tur; sinav = f.sinav; if ($('nga-tur')) { $('nga-tur').textContent = TURAD[tur]; $('nga-sinav').textContent = sinav; }
        if (depo) depo.get(['tarama_taslak', 'ng_not_tablosu'], v => { if ((v.tarama_taslak && v.tarama_taslak.sonuc && v.tarama_taslak.sonuc.length) || (v.ng_not_tablosu && v.ng_not_tablosu.satirlar && v.ng_not_tablosu.satirlar.length)) puanlariYaz(); else durum('yaz', 'bekle', 'Liste geldi; okunmuş kâğıt yok.'); }); }); }
      else if (++i > 1200) { clearInterval(t); } }, 500); }
  // 1.7.0 Excel akışı (yavaş internet): liste satır sayısı 2 sn değişmeyene dek beklenir, sonra 1,5 sn daha
  const DOSYA = 'ngaDosyaKip';
  const sabitBekle = () => new Promise(res => { let son = -1, ayni = 0, n = 0; const iv = setInterval(() => { const T = A.ogrenciTablosu(document), c = T ? T.satirlar.length : 0;
    if (c && c === son) ayni++; else ayni = 0; son = c; if (ayni >= 2 || ++n > 40) { clearInterval(iv); setTimeout(res, 1500); } }, 1000); });
  let listeleBasildi = false;
  const otoListeleBas = () => setTimeout(() => { if (listeleBasildi || !otoListele || A.ogrenciTablosu(document)) return;
      const k = A.kolonKutusu(document, tur, sinav), b = listeleDugmesi();
      if (!k || !k.checked) { durum('listele', 'hata', A.kolonAdi(tur, sinav) + ' kutusu işaretli değil; Listele yapılmadı.'); return; }
      if (!b) { durum('listele', 'hata', 'Listele düğmesi bulunamadı'); return; }
      listeleBasildi = true; sessionStorage.setItem(OTO, JSON.stringify({ tur, sinav }));
      A.adimLog(document, 'listele:tamam Listele basıldı (bir kez)'); durum('listele', 'tamam', 'Listele basıldı; liste bekleniyor'); b.click(); listeBekleYaz(); }, 800);
  if (sessionStorage.getItem(OTO)) setTimeout(listeBekleYaz, 300); // sayfa yeniden yüklendiyse
  // 1.6.9: Sınıf Listesi tablosu görülünce Okul No + Ad yalnız bu bilgisayarda saklanır (tarama ekranında ad/no doğrulaması için)
  function rosterKaydet(zorla) { return new Promise(res => { if (!depo || !A.IDARE_SAYFA.test(location.href)) return res(false); const T = A.ogrenciTablosu(document); if (!T || !T.satirlar.length) return res(false);
    const ai = T.bas.findIndex(b => b.startsWith('adisoyadi')); const og = T.satirlar.map(tr => ({ no: tr.cells[0].textContent.replace(/\D/g, ''), ad: ai >= 0 && tr.cells[ai] ? tr.cells[ai].textContent.trim() : '' })).filter(o => o.no);
    const kb = A.sayfaSinifi(document), j = (kb || '') + JSON.stringify(og); if (j === window.__ngaSinifSon && !zorla) return res(false); window.__ngaSinifSon = j;
    if (!kb) { depo.set({ ng_sinif_listesi: { zaman: Date.now(), ogrenciler: og } }, () => res(true)); return; }
    // 1.6.17 şube başına saklanır (aynı şubenin farklı ders listeleri birleşir); tarama için birleşik liste de güncellenir
    depo.get('ng_sinif_listeleri', v => { const L = v.ng_sinif_listeleri || {}, eski = Object.keys(L).find(x => sk(x) === sk(kb)), harita = new Map(((eski && L[eski].ogrenciler) || []).map(o => [o.no, o]));
      og.forEach(o => harita.set(o.no, o)); if (eski) delete L[eski]; L[kb] = { zaman: Date.now(), ogrenciler: [...harita.values()] };
      const gor = new Set(), bir = []; Object.keys(L).forEach(k => L[k].ogrenciler.forEach(o => { if (!gor.has(o.no)) { gor.add(o.no); bir.push({ no: o.no, ad: o.ad, sinif: k }); } }));
      listeler = L; depo.set({ ng_sinif_listeleri: L, ng_sinif_listesi: { zaman: Date.now(), ogrenciler: bir } }, () => res(true)); }); }); }
  setInterval(() => { rosterKaydet(false); }, 3000);

  // 1.6.28 Sınıf listelerini kendiliğinden öğrenme: her şube için (Listele güvenlik kodu istemez) sırayla seç → Listele → öğrenci numaraları saklanır.
  // Durum sessionStorage'da tutulur; şube değişimi sayfayı yenilese de kalınan yerden sürer.
  const listeImza = () => { const T = A.ogrenciTablosu(document); return T ? T.satirlar.map(tr => tr.cells[0].textContent.replace(/\D/g, '')).join(',') : ''; };
  async function ogrenBaslat(sonra) {
    // 1.6.32 Yalnız kâğıtlardaki sınıf düzeylerinin şubeleri öğrenilir (ör. 12. sınıf ortak sınavı → yalnız 12-A…12-Z). Düzey okunamadıysa sorulur; boş bırakılırsa tüm şubeler (75 şube, birkaç dakika)
    let sev = [...new Set(tablo.map(r => { const a = sinifAyir(r.sinif), m = String(r.sinif || '').match(/^\s*(\d{1,2})\s*(?:[-\/.]|$)/); return a ? a.sinif : m ? m[1] : (r.seviye || ''); }).filter(Boolean))];
    if (!sonra) { sev = []; durum('ogren', 'bekle', 'Tüm sınıf düzeylerinin (9–12 vb.) şube listeleri öğreniliyor; şablon hepsini tek Excel\'de içerir. Birkaç dakika sürebilir.'); } // 1.8.6 düğmeden: tek şablon için TÜM düzeyler
    else if (!sev.length) { const c = window.prompt('Hangi sınıf düzeyinin listeleri öğrenilsin? (örn. 12  ya da  11,12)\nBoş bırakırsanız e-Okul\'daki TÜM şubeler öğrenilir (birkaç dakika sürer).', ''); if (c === null) { durum('ogren', 'hata', 'Öğrenme iptal edildi.'); return; } sev = [...new Set((c.match(/\d{1,2}/g) || []))]; }
    sessionStorage.setItem(OGREN, JSON.stringify({ kuyruk: null, i: 0, sayac: 0, seviyeler: sev, sonra: !!sonra }));
    durum('ogren', 'bekle', 'Sınıf listeleri öğreniliyor' + (sev.length ? ' (' + sev.join(', ') + '. sınıflar)' : '') + '…');
    if (A.IDARE_SAYFA.test(location.href)) return ogrenSur();
    const r = await A.idareListele(document, { sinif: '0', sube: '0', ders: '', herhangi: true, sinav: 1, tur: 'sinav' }, durum, { kaydet: x => { sessionStorage.setItem(ANAHTAR, JSON.stringify(x)); } });
    if (!r || r.ok === false) { sessionStorage.removeItem(OGREN); durum('ogren', 'hata', 'Not İşlemleri > Ders Notu Girişi açılamadı; sayfayı elle açıp yeniden deneyin.'); }
  }
  async function ogrenSur() {
    let st = JSON.parse(sessionStorage.getItem(OGREN) || 'null'); if (!st || !A.IDARE_SAYFA.test(location.href)) return; { const b0 = $('nga-ogren'); if (b0) b0.textContent = 'Öğrenmeyi durdur'; }
    const yaz = () => sessionStorage.setItem(OGREN, JSON.stringify(st));
    if (!st.kuyruk) { let sec = A.sinifSecenekleri(document); if (st.seviyeler.length && sec.some(x => st.seviyeler.includes(x.sinif))) sec = sec.filter(x => st.seviyeler.includes(x.sinif));
      if (depo) { const tum = A.sinifSecenekleri(document).map(x => x.sinif + '-' + x.sube); tumSubeler = tum; depo.set({ ngaSubeler: tum }); }
      st.kuyruk = sec.map(x => ({ sinif: x.sinif, sube: x.sube })); st.i = 0; yaz(); A.adimLog(document, 'ogren: ' + st.kuyruk.length + ' şube sıraya alındı'); }
    while (st.i < st.kuyruk.length) {
      if (!sessionStorage.getItem(OGREN)) { const b0 = $('nga-ogren'); if (b0) b0.textContent = 'Sınıf listelerini otomatik öğren'; return; } // 1.6.32 durduruldu
      const h = st.kuyruk[st.i], ad = h.sinif + '-' + h.sube; durum('ogren', 'bekle', 'Sınıf listesi ' + (st.i + 1) + '/' + st.kuyruk.length + ': ' + ad);
      if (st.bekle !== ad && listeNolari(ad)) { st.i++; yaz(); continue; }
      if (st.bekle !== ad) {
        const r = await A.idareListele(document, { sinif: h.sinif, sube: h.sube, ders: '', herhangi: true, sinav: 1, tur: 'sinav' }, durum, { kaydet: x => { sessionStorage.setItem(ANAHTAR, JSON.stringify(x)); } });
        if (!r || !r.ok || r.adim !== 'listele') { A.adimLog(document, 'ogren: ' + ad + ' hazırlanamadı (' + (r && r.adim) + ')'); st.i++; st.bekle = null; yaz(); continue; }
        const b = listeleDugmesi(); if (!b) { durum('ogren', 'hata', 'Listele düğmesi bulunamadı'); st.i++; yaz(); continue; }
        st.bekle = ad; st.imza = listeImza(); yaz(); b.click();
      }
      // Listele sonrası (sayfa yenilenmiş olabilir): bu şubenin listesi görünene dek bekle
      const ok = await new Promise(res => { const t0 = Date.now(), iv = setInterval(() => { const im = listeImza(); if (im && A.sayfaSinifi(document) && sk(A.sayfaSinifi(document)) === sk(ad) && im !== st.imza) { clearInterval(iv); res(true); } else if (Date.now() - t0 > 25000) { clearInterval(iv); res(false); } }, 400); });
      if (ok) { await rosterKaydet(true); st.sayac++; } else { A.adimLog(document, 'ogren: ' + ad + ' listesi gelmedi'); }
      st.bekle = null; st.i++; yaz();
    }
    sessionStorage.removeItem(OGREN); { const b0 = $('nga-ogren'); if (b0) b0.textContent = 'Sınıf listelerini otomatik öğren'; }
    durum('ogren', 'tamam', st.sayac + ' sınıfın listesi öğrenildi.'); A.adimLog(document, 'ogren: bitti, ' + st.sayac + ' liste');
    if (st.sonra) { await tabloYukleP(); if (duzelt()) tabloKaydet(); aktif = 0; grupYaz(); tabloCiz(); setTimeout(() => $('nga-git') && $('nga-git').click(), 600); }
  }
  // Tam otomatik: tablo → (gerekirse listeleri öğren) → sınıflara göre sırayla tüm gruplar. Güvenlik Kodu ve Kaydet yalnız sizde.
  let tamOtoCalisiyor = false;
  async function tamOtoBaslat() {
    if (tamOtoCalisiyor) return; tamOtoCalisiyor = true; setTimeout(() => { tamOtoCalisiyor = false; }, 60000); // 1.6.36 art arda tetiklenip aynı hatayı tekrarlamasın
    sessionStorage.removeItem(ARTIK); await tabloYukleP();
    if (!tablo.length) { durum('oto', 'hata', 'Yazılacak not yok: önce "Excel\'den not gir" ile notları yükleyin.'); return; }
    if (duzelt()) tabloKaydet();
    const gs = gruplar(), eksik = !Object.keys(listeler).length || gs.some(g => g.sinif && !listeNolari(g.sinif));
    A.adimLog(document, 'tam otomatik: ' + gs.length + ' grup, listeler ' + (eksik ? 'eksik → öğrenilecek' : 'tamam'));
    if (eksik) { await ogrenBaslat(true); return; }
    aktif = 0; grupYaz(); tabloCiz(); durum('oto', 'bekle', 'Tam otomatik: ' + gs.length + ' grup sınıf sırasıyla işlenecek.'); $('nga-git').click();
  }
  // Tarama ekranı "e-Okul'a ver" derken bayrak bırakır; bu sekme görünürken ve panel boştayken kendiliğinden başlar (30 dk içinde)
  async function otoKontrol() {
    if (!depo || !p.isConnected || !$('nga-git') || document.visibilityState !== 'visible') return;
    if ([OGREN, ANAHTAR, OTO, KB].some(k => sessionStorage.getItem(k)) || proAcik()) return;
    const ob = await new Promise(r => depo.get('ngaOtoBasla', v => r(v.ngaOtoBasla)));
    if (!ob || Date.now() - ob.zaman > 30 * 60 * 1000) return;
    if (sessionStorage.getItem('ngaOtoKilit') === String(ob.zaman)) return; sessionStorage.setItem('ngaOtoKilit', String(ob.zaman)); // 1.6.36 aynı bayrak yalnız bir kez işlenir (üç tetikleyici aynı anda okuyordu)
    depo.remove('ngaOtoBasla'); A.adimLog(document, 'tam otomatik: tarama ekranından başlatıldı'); setTimeout(tamOtoBaslat, 700); }
  document.addEventListener('visibilitychange', otoKontrol);
  if (depo && chrome.storage.onChanged) chrome.storage.onChanged.addListener((d, a) => { if (a === 'local' && d.ngaOtoBasla && d.ngaOtoBasla.newValue) otoKontrol(); });
  // 1.6.10 Ders listesi: e-Okul'daki #ddlDersler (sınıf seçilip postback sonrası) panele aktarılır
  function dersSecenek(v) { const s = $('nga-ders'); if (!s || !v) return;
    { const d = A.dersSelect && A.dersSelect(document); if (d && d.options.length > 1) { const o = [...d.options].find(x => x.value && A.norm(x.textContent) === A.norm(v)) || (A.dersEsle(d, v) || {}).op; if (o) v = o.textContent.trim(); } } /* 1.6.22 e-Okul seçeneğine benzerlikle */
    if (![...s.options].some(o => o.value === v)) s.add(new Option(v, v)); s.value = v; }
  // 1.7.0 yedek: sayfada ders listesi yokken açılır liste boş kalmasın (yerleşik resmî liste; sayfadan okunan gelince yerine geçer)
  const YEDEK = { ilk: ['Türkçe', 'Matematik', 'Hayat Bilgisi', 'Fen Bilimleri', 'Sosyal Bilgiler', 'T.C. İnkılap Tarihi ve Atatürkçülük', 'Yabancı Dil', 'Din Kültürü ve Ahlak Bilgisi', 'Görsel Sanatlar', 'Müzik', 'Beden Eğitimi ve Oyun', 'Beden Eğitimi ve Spor', 'Teknoloji ve Tasarım', 'Trafik Güvenliği', 'Bilişim Teknolojileri ve Yazılım', 'Rehberlik ve Kariyer Planlama', 'İnsan Hakları, Vatandaşlık ve Demokrasi'],
    lise: ['TÜRK DİLİ VE EDEBİYATI', 'DİN KÜLTÜRÜ VE AHLAK BİLGİSİ', 'TARİH', 'T.C. İNKILAP TARİHİ VE ATATÜRKÇÜLÜK', 'COĞRAFYA', 'MATEMATİK', 'FİZİK', 'KİMYA', 'BİYOLOJİ', 'FELSEFE', 'BİRİNCİ YABANCI DİL', 'BEDEN EĞİTİMİ VE SPOR', 'GÖRSEL SANATLAR/MÜZİK', 'SAĞLIK BİLGİSİ VE TRAFİK KÜLTÜRÜ', 'SEÇMELİ MATEMATİK', 'TEMEL MATEMATİK', 'SEÇMELİ FİZİK', 'SEÇMELİ KİMYA', 'SEÇMELİ BİYOLOJİ', 'SEÇMELİ TÜRK DİLİ VE EDEBİYATI', 'SEÇMELİ TARİH', 'SEÇMELİ COĞRAFYA', 'PSİKOLOJİ', 'SOSYOLOJİ', 'MANTIK', 'SEÇMELİ BİRİNCİ YABANCI DİL', 'SEÇMELİ İKİNCİ YABANCI DİL', 'OSMANLI TÜRKÇESİ', 'KUR’AN-I KERİM', 'PEYGAMBERİMİZİN HAYATI', 'TEMEL DİNÎ BİLGİLER', 'BİLİŞİM TEKNOLOJİLERİ VE YAZILIM', 'PROJE TASARIMI VE UYGULAMALARI', 'TEMEL HUKUK BİLGİSİ', 'GİRİŞİMCİLİK'] }; // kaynak: ice/dersler.js
  setInterval(() => { const s = $('nga-ders'), d = A.dersSelect && A.dersSelect(document); if (s && (!d || d.options.length < 2) && s.options.length <= 1 && !s.dataset.yedek) { const sv = +(($('nga-sinif') || {}).value || 0), ad = sv >= 1 && sv <= 8 ? YEDEK.ilk : sv >= 9 ? YEDEK.lise : YEDEK.ilk.concat(YEDEK.lise);
      s.dataset.yedek = '1'; const e = s.value; s.innerHTML = ''; s.add(new Option('Ders seçin (yerleşik liste)', '')); ad.forEach(a => s.add(new Option(a, a))); if (e) dersSecenek(e); } }, 1500);
  setInterval(() => { const s = $('nga-ders'), d = A.dersSelect && A.dersSelect(document); if (!s || !d || d.options.length < 2) return;
    const ad = [...d.options].filter(o => o.value).map(o => o.textContent.trim()), k = ad.join('|'); if (s.dataset.k === k) return;
    if (depo) { const sk = ((($('nga-sinif') || {}).value || '').trim() + '-' + ((($('nga-sube') || {}).value || '').trim())).toUpperCase(); depo.get('ngaDersSecenekS', (v) => { const m = v.ngaDersSecenekS || {}; if (/^\d+-[A-ZÇĞİÖŞÜ]/.test(sk)) m[sk] = { z: Date.now(), ad }; depo.set({ ngaDersSecenek: { z: Date.now(), ad }, ngaDersSecenekS: m }); }); } /* 1.8.4 sınıf başına: e-Okul Ders listesinin tüm seçenekleri (meslek, İHL, seçmeli dahil) */ // 1.7.0 şablondaki Ders açılır listesi için (yalnız bu bilgisayarda)
    const eski = s.value; s.dataset.k = k; s.innerHTML = ''; s.add(new Option('Ders seçin', '')); ad.forEach(a => s.add(new Option(a, a)));
    const e = A.norm(eski), m = ad.find(a => A.norm(a) === e) || (e && ad.find(a => A.norm(a).includes(e))) || (e && ((A.dersEsle(d, eski) || {}).op || { textContent: '' }).textContent.trim()) || ''; s.value = m || (d.value ? d.options[d.selectedIndex].textContent.trim() : ''); }, 1000);
  const SON = 'ngaSon';
  const calis = async h => {
    if (depo) depo.set({ [SON]: h });
    if (typeof h.grup === 'number') { aktif = h.grup; grupYaz(); }
    if (TURAD[h.tur]) tur = h.tur; if (h.sinav) sinav = Math.min(h.sinav, TURMAX[tur]); if ($('nga-tur')) { $('nga-tur').textContent = TURAD[tur]; $('nga-sinav').textContent = sinav; } // 1.6.10 sütun panelle eşit
    try { const r = await A.idareListele(document, h, durum, { zaman: sessionStorage.getItem(DOSYA) ? 30000 : undefined, kaydet: x => { sessionStorage.setItem(ANAHTAR, JSON.stringify(x)); if (depo) depo.set({ [ANAHTAR]: { h: x, zaman: Date.now() } }); } });
      if (r && r.ok && r.adim === 'listele') { sessionStorage.setItem(OTO, JSON.stringify({ tur, sinav })); A.adimLog(document, 'iş bekliyor: liste gelince yazma otomatik'); listeleBasildi = false; /* 1.6.28 şube değişimi sayfayı yenilemiyorsa (AJAX) önceki grubun işareti sıradaki Listele'yi engellemesin */ otoListeleBas(); }
      if (r && r.adim === 'ders' && r.emin === false && $('nga-ders')) { $('nga-ders').style.background = '#ffeb3b'; $('nga-ders').focus({ preventScroll: true }); } }
    catch (e) { durum('hata', 'hata', 'Beklenmeyen hata: ' + (e && e.message || e)); }
  };
  function sonDoldur() { if (!depo) return; depo.get(SON, v => { const h = v[SON]; if (!h || !$('nga-sinif')) return;
    if (gruplar().some(g => g.sinif)) { sinav = h.sinav || 1; tur = TURAD[h.tur] ? h.tur : 'sinav'; $('nga-sinav').textContent = sinav; $('nga-tur').textContent = TURAD[tur]; adim3Doldur(gruplar()[aktif]); return; } // 1.6.12 grup varsa eski seçim üstüne yazmaz
    $('nga-sinif').value = h.sinif || '9'; $('nga-sube').value = h.sube || 'A'; dersSecenek(h.ders || ''); sinav = h.sinav || 1; tur = TURAD[h.tur] ? h.tur : 'sinav'; $('nga-sinav').textContent = sinav; $('nga-tur').textContent = TURAD[tur];
    if (gruplar().some(g => g.ders)) adim3Doldur(gruplar()[aktif]); /* 1.6.22 kâğıttan okunan ders/sınav, son kullanılanın önüne geçer */ }); }
  async function ac(otomatik) {
    if (p.isConnected && $('nga-git') && !otomatik) { if (!cekAcik) { cekAcik = true; cekCiz(); } $('nga-ders').focus({ preventScroll: true }); return; } // açıksa yeniden çizip girdileri silme
    const onay = await onayOku();
    if (!onay) { kvkkCiz(); ekle(); return; }
    anaCiz(); ekle();
    const bek = sessionStorage.getItem(ANAHTAR), dp = await new Promise(r => depo ? depo.get(ANAHTAR, v => r(v[ANAHTAR])) : r(null));
    const h = bek ? JSON.parse(bek) : dp && Date.now() - dp.zaman < 3 * 60 * 1000 ? dp.h : null; // 1.6.8: menü adımları arasında tam sayfa yüklemesi
    if (otomatik && sessionStorage.getItem(OGREN)) { sessionStorage.removeItem(ANAHTAR); if (depo) depo.remove(ANAHTAR); setTimeout(ogrenSur, 700); return; } // 1.6.28 sınıf listesi öğrenme sayfa yenilemesinden sonra sürer
    setTimeout(otoKontrol, 1000); setTimeout(() => iceOto(), 1200);
    if (otomatik && h && proAcik()) { A.adimLog(document, 'devam edilemedi: e-Okul Pro paneli açık'); durum('cakisma', 'hata', 'Pro paneli açık; kapatıp düğmeye yeniden basın.'); }
    if (otomatik && h && sessionStorage.getItem(OTO) && A.ogrenciTablosu(document)) { sessionStorage.removeItem(ANAHTAR); if (depo) depo.remove(ANAHTAR); A.adimLog(document, 'liste mevcut, yeniden başlatılmadı'); return; }
    if (otomatik && h && !proAcik()) { sessionStorage.removeItem(ANAHTAR); if (depo) depo.remove(ANAHTAR); calis(h); }
  }
  // 1.6.16 Çok sınıflı toplu giriş: siz Kaydet'e basıp kayıt başarılı mesajı görününce sonraki grup kendiliğinden başlar. Asistan Kaydet'e ve Güvenlik Kodu'na dokunmaz.
  const KB = 'ngaKaydetBekle', asc = s => String(s || '').toLocaleLowerCase('tr-TR').replace(/[ıi̇]/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c').replace(/\s+/g, ' ');
  function kaydetBekle(g) { sessionStorage.setItem(KB, JSON.stringify({ grup: g, z: Date.now(), basildi: false })); A.adimLog(document, 'kaydet:bekle grup ' + (g + 1) + ' yazıldı; kullanıcının Kaydet\'e basması bekleniyor'); }
  const kaydetMi = el => { const b = el && el.closest && el.closest('input[type=submit],input[type=button],input[type=image],button,a'); return b && !b.closest('#nga-panel') && !String(b.id || '').startsWith('nga-') && /kaydet/.test(asc(b.value || b.textContent || b.title || b.id || '')); };
  document.addEventListener('click', e => { const k = JSON.parse(sessionStorage.getItem(KB) || 'null'); if (!k || !kaydetMi(e.target)) return;
    k.basildi = true; k.bz = Date.now(); sessionStorage.setItem(KB, JSON.stringify(k)); A.adimLog(document, 'kaydet:basıldı (kullanıcı)'); setTimeout(kaydetKontrol, 1500); }, true);
  const BASARI = /basar[i]?yla|kaydedildi|kayit (islemi )?(tamamland|yapild|basarili)|guncellendi|islem tamamland/, HATA = /hatal|basarisiz|hata olustu|yanlis|gecersiz|giriniz|kaydedilemedi/;
  function kaydetKontrol() { const k = JSON.parse(sessionStorage.getItem(KB) || 'null'); if (!k || !k.basildi) return;
    const panel = document.getElementById('nga-panel'), t = asc([...document.querySelectorAll('span,div,td,p,label,font,b,strong,li')].filter(e => !(panel && panel.contains(e)) && !e.closest('[id^=nga-]') && e.children.length < 3 && e.offsetParent !== null).map(e => e.textContent).join(' | '));
    const ok = BASARI.test(t), kotu = HATA.test(t);
    if (ok && !kotu) { sessionStorage.removeItem(KB); A.adimLog(document, 'kaydet:tamam kayıt başarılı; sonraki gruba geçiliyor'); durum('sonraki', 'tamam', 'Grup ' + (k.grup + 1) + ' kaydedildi; sonraki grup başlıyor…');
      setTimeout(async () => { await tabloYukleP(); aktif = k.grup; const gs = gruplar(); const il = await bitenEkle(gs[aktif]); // 1.7.0 Excel ilerlemesi
        if (il && il.durak) { durum('sonraki', 'tamam', 'Grup ' + (aktif + 1) + ' kaydedildi. Duraklatıldı: sıradaki sınıf için "Devam ▶".'); iceCiz(); return; }
        if (aktif + 1 < gs.length && $('nga-sonraki')) $('nga-sonraki').click(); else { durum('sonraki', 'tamam', 'Tüm gruplar kaydedildi (' + gs.length + ' grup).' + artikOzet()); A.adimLog(document, 'bitti: tüm gruplar kaydedildi.' + artikOzet()); sessionStorage.removeItem(DOSYA); } iceCiz(); }, sessionStorage.getItem(DOSYA) ? 2500 : 1200); return; }
    if (Date.now() - (k.bz || 0) < 20000 && !kotu) { setTimeout(kaydetKontrol, 1000); return; }
    k.basildi = false; sessionStorage.setItem(KB, JSON.stringify(k)); A.adimLog(document, 'kaydet:belirsiz ' + (kotu ? 'hata mesajı görüldü' : 'başarı mesajı görülmedi') + '; ilerlenmedi');
    durum('sonraki', 'hata', (kotu ? 'Kayıt hatası görünüyor (Güvenlik Kodu?)' : 'Kayıt başarılı mesajı görülmedi') + '; sonraki gruba geçilmedi. Düzeltip yeniden Kaydet\'e basın ya da "Sonraki grup"a elle basın.');
    if ($('nga-sonraki')) $('nga-sonraki').hidden = false; }
  setTimeout(kaydetKontrol, 1500); // Kaydet sonrası sayfa yeniden yüklendiyse
  // 1.7.0 Excel'den not girişi: ice/ice.html dosyayı yerelde ayrıştırıp ng_ice_aktar'a yazar; burada sınıf sınıf giriş başlar.
  // Her sınıf: sınıf+ders+sütun seçilir, Listele'ye basılır, notlar Okul No'ya göre yazılır. Güvenlik Kodu ve Kaydet öğretmende; kayıt başarılı görülünce sıradaki sınıf.
  const ILR = 'ngaDosyaIlerleme', sesc = x => String(x == null ? '' : x).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const ilrOku = () => new Promise(r => depo ? depo.get(ILR, v => r(v[ILR] || null)) : r(null));
  const dosyaKip = () => tablo.some(r => r.kaynak);
  async function bitenEkle(g) { const il = await ilrOku(); if (!il || !g || !dosyaKip()) return null; if (!il.k.includes(g.k)) il.k.push(g.k); await new Promise(r => depo.set({ [ILR]: il }, r)); return il; }
  function iceCiz() { const k = $('nga-icebox'); if (!k || !depo) return; depo.get(['ng_ice_aktar', ILR], async v => { const x = v.ng_ice_aktar, il = v[ILR];
    const bb = 'style="border:2px solid #000;font-weight:bold;padding:3px 6px;margin:2px 2px 0 0"';
    if (x && x.satirlar && x.satirlar.length) {
      k.innerHTML = '<div style="border:2px solid #000;padding:3px;margin:3px 0;background:#e8f0ff"><b>Excel: ' + x.satirlar.length + ' not, ' + x.siniflar.length + ' sınıf</b><br>' + x.siniflar.map(s => sesc(s.sinif) + ' · ' + sesc(s.ders) + ' (' + s.n + ')').join('<br>') + '<br>e-Okul sütunu: ' + sesc(TURAD[x.tur] || x.tur) + ' ' + sesc(x.sinav) + (x.g ? ' · eksiklere G' : ' · dosyada olmayana dokunulmaz') +
        '<br><button id="nga-ice-gir" style="background:#0a7d2c;color:#fff;border:2px solid #000;font-weight:bold;width:100%;padding:5px;margin-top:3px">Çalıştır ▶</button> <a href="#" id="nga-ice-sil" style="color:#b00020">Vazgeç (sil)</a></div>';
      $('nga-ice-sil').onclick = e => { e.preventDefault(); depo.remove('ng_ice_aktar'); }; $('nga-ice-gir').onclick = () => iceGir(); return; }
    if (!il || !dosyaKip()) { k.innerHTML = ''; return; }
    const gs = gruplar(), bit = gs.filter(g => il.k.includes(g.k)).length, son = bit >= gs.length;
    k.innerHTML = '<div style="border:2px solid #000;padding:3px;margin:3px 0;background:' + (son ? '#c8f7c5' : '#e8f0ff') + '"><b>Excel: ' + bit + '/' + gs.length + ' sınıf kaydedildi</b>' + (il.durak ? ' · <b style="background:#ffeb3b">DURAKLATILDI</b>' : '') + '<br>' +
      gs.map((g, i) => (il.k.includes(g.k) ? '✓ ' : i === aktif ? '▶ ' : '· ') + sesc(g.sinif) + ' ' + sesc(g.ders) + ' (' + g.n + ')').join('<br>') + '<br>' +
      (son ? '' : '<button id="nga-ice-dur" ' + bb + '>' + (il.durak ? 'Devam ▶' : 'Duraklat ⏸') + '</button><button id="nga-ice-atla" ' + bb + ' title="Kayıt başarılı mesajı algılanmazsa: bu sınıfı kaydettiyseniz sıradakine geçer">Sonraki sınıfa geç ▶</button>') + '<button id="nga-ice-iptal" style="border:2px solid #b00020;color:#b00020;font-weight:bold;padding:3px 6px;margin:2px 2px 0 0">' + (son ? 'Temizle' : 'İptal ✗') + '</button></div>';
    if ($('nga-ice-dur')) $('nga-ice-dur').onclick = async () => { const s = await ilrOku(); if (!s) return; s.durak = !s.durak; depo.set({ [ILR]: s }, () => { iceCiz(); if (!s.durak) { const g = gruplar()[aktif]; sessionStorage.setItem(DOSYA, '1');
        if (g && s.k.includes(g.k)) { if (aktif + 1 < gruplar().length) { sessionStorage.removeItem(KB); $('nga-sonraki').click(); } } else if (!sessionStorage.getItem(KB)) $('nga-git').click(); } else durum('dosya', 'bekle', 'Duraklatıldı: kayıttan sonra sıradaki sınıfa geçilmez. Devam ▶ ile sürer.'); }); };
    if ($('nga-ice-atla')) $('nga-ice-atla').onclick = async () => { const gs2 = gruplar(); await bitenEkle(gs2[aktif]); sessionStorage.removeItem(KB); sessionStorage.setItem(DOSYA, '1'); A.adimLog(document, 'dosya: elle sonraki sınıf');
      if (aktif + 1 < gs2.length) $('nga-sonraki').click(); else durum('sonraki', 'tamam', 'Son sınıftı; tüm sınıflar işaretlendi.'); iceCiz(); };
    $('nga-ice-iptal').onclick = () => { [KB, OTO, ANAHTAR, DOSYA].forEach(x => sessionStorage.removeItem(x)); depo.remove([ANAHTAR, ILR]); tablo = tablo.filter(r => !r.kaynak); aktif = 0; grupYaz(); tabloKaydet(); delete durumlar.sonraki; durum('dosya', 'hata', son ? 'Excel girişi temizlendi.' : 'Excel girişi iptal edildi; sıradaki sınıflara geçilmeyecek. (Yazılmış ama kaydedilmemiş notlar sayfada durur; Kaydet\'e basmazsanız kaydolmaz.)'); A.adimLog(document, 'dosya: iptal'); iceCiz(); }; }); }
  function iceGir() { if (!depo) return; depo.get(['ng_ice_aktar', 'tarama_taslak'], w => { const x = w.ng_ice_aktar; if (!x || !x.satirlar) { ngaLog('iceGir: plan yok'); return; } const pd = $('nga-ders') ? $('nga-ders').value.trim() : '', al = [], kal = [];
    x.satirlar.forEach(r => { const a = sinifAyir(r.sinif), ders = r.ders || pd; if (!a || !r.no || !ders || !notOk(r.puan)) { kal.push(r); return; }
      al.push({ no: String(r.no), not: String(r.puan).toUpperCase(), kesin: true, sinif: a.sinif + '-' + a.sube, ders, basKesin: true, kaynak: x.g ? 'dosyaG' : 'dosya', sinavNo: x.tur === 'sinav' ? x.sinav : 0 }); });
    if (!al.length) { ngaLog('iceGir: gönderilecek satır yok', kal.length); durum('dosya', 'hata', 'Excel satırlarında ders yok ya da not geçersiz: Excel sayfasında Ders\'i yazın ya da 3. adımda dersi seçip yeniden Çalıştır\'a basın.'); return; }
    if (TURAD[x.tur]) { tur = x.tur; sinav = Math.min(x.sinav || 1, TURMAX[tur]); if ($('nga-tur')) { $('nga-tur').textContent = TURAD[tur]; $('nga-sinav').textContent = sinav; } }
    const tk = w.tarama_taslak, kosu = (tk && tk.kosu) || 0; kosuSon = kosu; tablo = al; [KB, ARTIK].forEach(y => sessionStorage.removeItem(y)); sessionStorage.setItem(DOSYA, '1');
    depo.set({ ng_not_tablosu: { zaman: Date.now(), kosu, satirlar: tablo.map(satirK) }, [ILR]: { id: x.z, k: [], durak: false } }, () => { depo.remove('ng_ice_aktar');
      const gs = gruplar(); durum('dosya', 'tamam', al.length + ' not, ' + gs.length + ' sınıf: ' + gs.map(g => g.sinif).join(', ') + ' (' + TURAD[tur] + ' ' + sinav + ')' + (kal.length ? '; ' + kal.length + ' satır atlandı (ders/not eksik)' : '') + '. Sınıf sınıf giriş başlıyor.');
      A.adimLog(document, 'dosya: ' + gs.length + ' sınıf, ' + al.length + ' not'); aktif = 0; grupYaz(); tabloCiz(); iceCiz(); setTimeout(() => $('nga-git') && $('nga-git').click(), 2000); }); }); }
  // "Çalıştır ▶" Excel sayfasından basılınca: görünür e-Okul sekmesindeki panel kendiliğinden başlar (30 dk içinde, bir kez)
  // 1.8.4: sessiz çıkış yok — her engel [NGA] günlüğüne ve panele yazılır; Excel sayfasından gelen ileti (zorla) görünürlük beklemez
  let seciliSon = ''; setInterval(() => { const d = $('nga-ders'); const t = d && d.value ? ((d.selectedOptions && d.selectedOptions[0] && d.selectedOptions[0].textContent) || d.value).trim() : ''; if (!depo || !t || t === seciliSon || /seçin/i.test(t)) return; seciliSon = t; depo.set({ ngaSeciliDers: { z: Date.now(), ad: t } }); }, 2000); // 1.8.5 Excel sayfasındaki ortak Ders listesi bunu önceden seçer
  const ngaLog = (...a) => { try { console.log('[NGA]', ...a); } catch (e) {} };
  function iceOto(zorla) { zorla = zorla === true;
    if (!depo) { ngaLog('iceOto: chrome.storage yok'); return; }
    depo.get('ng_ice_aktar', v => { const x = v.ng_ice_aktar;
      if (!x || !x.baslat) { if (zorla) ngaLog('iceOto: bekleyen Excel planı yok'); return; }
      if (Date.now() - x.baslat > 30 * 60 * 1000) { ngaLog('iceOto: plan 30 dk\'dan eski'); if (zorla) durum('dosya', 'hata', 'Excel planı 30 dakikadan eski: Excel sayfasında yeniden Çalıştır\'a basın.'); return; }
      if (sessionStorage.getItem('ngaIceKilit') === String(x.baslat)) { ngaLog('iceOto: bu plan zaten başlatıldı'); return; }
      if (!zorla && document.visibilityState !== 'visible') { ngaLog('iceOto: sekme görünür değil, bekleniyor'); return; }
      if (!p.isConnected || !$('nga-git')) { ngaLog('iceOto: panel hazır değil (KVKK onayı?)'); ac(false).then(() => { if ($('nga-git')) setTimeout(() => iceOto(true), 300); else ngaLog('iceOto: önce paneldeki KVKK onayını verin'); }); return; }
      if (!cekAcik) { cekAcik = true; cekCiz(); }
      if (proAcik()) { ngaLog('iceOto: Pro paneli açık'); durum('dosya', 'hata', 'Excel girişi başlamadı: Pro paneli açık; önce onu kapatın.'); return; }
      const eski = [OGREN, ANAHTAR, OTO].filter(k => sessionStorage.getItem(k)); if (eski.length) { ngaLog('iceOto: eski oturum işaretleri temizlendi', eski); eski.forEach(k => sessionStorage.removeItem(k)); }
      sessionStorage.setItem('ngaIceKilit', String(x.baslat)); ngaLog('iceOto: başlıyor', x.siniflar && x.siniflar.map(c => c.sinif + ':' + c.ders)); durum('dosya', 'bekle', 'Excel planı alındı; Ders Notu Girişi açılıyor…'); A.adimLog(document, 'dosya: Excel sayfasından Çalıştır'); iceGir(); }); }
  document.addEventListener('visibilitychange', () => iceOto());
  if (depo && chrome.storage.onChanged) chrome.storage.onChanged.addListener((d, a) => { if (a !== 'local') return; if (d.ng_ice_aktar || d[ILR]) iceCiz(); if (d.ng_ice_aktar && d.ng_ice_aktar.newValue && d.ng_ice_aktar.newValue.baslat) iceOto(); });
  window.__NGA = { ac };
  if (sessionStorage.getItem(ANAHTAR) || A.IDARE_SAYFA.test(location.href)) ac(true);
  else if (depo) depo.get(ANAHTAR, v => { const d = v[ANAHTAR]; if (d && Date.now() - d.zaman < 3 * 60 * 1000) ac(true); else ac(false); });
  else ac(false); // 1.6.14 çekmece her e-Okul sayfasında (ana sayfa dahil) görünür
  window.addEventListener('keydown', e => { if (e.altKey && !e.ctrlKey && !e.metaKey && e.key.toLowerCase() === 'g') ac(false); }); // AltGr (Ctrl+Alt) ile karışmasın
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) chrome.runtime.onMessage.addListener(m => { if (m && m.tip === 'nga-ac') ac(false); if (m && m.tip === 'nga-ice') { ngaLog('Excel sayfasından başlat iletisi geldi'); iceOto(true); } }); // araç çubuğu simgesi
})();
