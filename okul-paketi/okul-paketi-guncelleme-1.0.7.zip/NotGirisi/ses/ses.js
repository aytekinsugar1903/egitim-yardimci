// 1.6.23 Sesli not penceresi (uzantı sayfası). e-Okul sayfası "Permissions-Policy: microphone=()" gönderdiği için
// mikrofon orada hiç açılamaz; burada açılır. Tanınan metin yalnız chrome.storage.local ile panele iletilir (ağa veri göndermez).
const d = document.getElementById('d'), st = chrome.storage.local;
const durum = (t, hata) => { d.textContent = t; d.style.background = hata ? '#ffeb3b' : '#c8f7c5'; st.set({ ngaSesDurum: { t, hata: !!hata, z: Date.now() } }); };
const HATA = { 'not-allowed': 'Mikrofon izni verilmedi. Adres çubuğundaki/pencere üstündeki mikrofon simgesine tıklayıp İzin ver seçin, sonra Sesli not\'u yeniden başlatın. Olmazsa Windows Ayarlar > Gizlilik ve güvenlik > Mikrofon\'da "Uygulamaların mikrofona erişmesine izin ver" ve Chrome açık olmalı.',
  'service-not-allowed': 'Chrome ses tanımaya izin vermedi. Chrome\'u güncelleyip yeniden deneyin.', 'audio-capture': 'Mikrofon bulunamadı. Mikrofonun takılı ve Windows Ses ayarlarında seçili olduğunu kontrol edin.',
  network: 'Ses tanıma için internet bağlantısı gerekiyor (Chrome sesi Google\'da metne çevirir). Bağlantıyı kontrol edin.', 'language-not-supported': 'Bu Chrome Türkçe ses tanımayı desteklemiyor; Chrome\'u güncelleyin.' };
let acik = true, tan = null;
const bitir = () => { acik = false; try { tan && tan.stop(); } catch (e) {} st.set({ ngaSesDurum: { t: 'Sesli not durduruldu.', hata: false, z: Date.now(), bitti: true } }, () => window.close()); };
document.getElementById('b').onclick = bitir;
chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.ngaSesKomut && c.ngaSesKomut.newValue && c.ngaSesKomut.newValue.k === 'dur') bitir(); });
window.addEventListener('beforeunload', () => { if (acik) st.set({ ngaSesDurum: { t: 'Sesli not penceresi kapandı.', hata: false, z: Date.now(), bitti: true } }); });
(async () => {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR) return durum('Bu tarayıcıda ses tanıma yok.', true);
  try { const s = await navigator.mediaDevices.getUserMedia({ audio: true }); s.getTracks().forEach((t) => t.stop()); } // tek seferlik izin sorusu (uzantı için)
  catch (e) { return durum(e && e.name === 'NotFoundError' ? HATA['audio-capture'] : HATA['not-allowed'], true); }
  tan = new SR(); tan.lang = 'tr-TR'; tan.continuous = true; tan.interimResults = false;
  tan.onresult = (e) => { for (let i = e.resultIndex; i < e.results.length; i++) { if (!e.results[i].isFinal) continue; const t = e.results[i][0].transcript; st.set({ ngaSesMetin: { t, z: Date.now() + Math.random() } }); d.textContent = 'Duyuldu: "' + t.slice(0, 60) + '"'; } };
  tan.onerror = (e) => { if (e.error === 'no-speech' || e.error === 'aborted') return; durum(HATA[e.error] || 'Sesli not çalışmadı (' + e.error + ').', true); if (/allowed|capture/.test(e.error)) acik = false; };
  tan.onend = () => { if (acik) { try { tan.start(); } catch (e) { } } };
  tan.start(); durum('Dinliyorum… "12 numara 85" ya da "Ad Soyad 85" deyin.', false);
})();
