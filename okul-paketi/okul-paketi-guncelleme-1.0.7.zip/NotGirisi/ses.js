// 1.6.17 Sesli not girişi (e-Okul Pro sesli devamsızlık yaklaşımı). Web Speech API (tr-TR); veri bu bilgisayarda kalır (ses tanımayı Chrome'un kendi hizmeti yapar).
// "12 numara 85", "on iki numara seksen beş", "Ayşe Yılmaz 85", "12 numara girmedi" -> satır bulunur, puan seçili sütuna daktilo gibi yazılır, satır vurgulanır.
// Kaydet'e ve Güvenlik Kodu'na ASLA dokunmaz.
(function (kok) {
  'use strict';
  const BIR = { sifir: 0, bir: 1, iki: 2, uc: 3, dort: 4, bes: 5, alti: 6, yedi: 7, sekiz: 8, dokuz: 9 };
  const ON = { on: 10, yirmi: 20, otuz: 30, kirk: 40, elli: 50, altmis: 60, yetmis: 70, seksen: 80, doksan: 90 };
  const sade = s => String(s || '').replace(/I/g, 'ı').replace(/İ/g, 'i').toLowerCase().replace(/ı/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c').replace(/i̇/g, 'i');
  // sözcükle sayılar -> rakam; "on iki seksen beş" iki ayrı sayı (12, 85) olur
  function sayilar(metin) {
    const t = sade(metin).replace(/[.,;:!?]+/g, ' ').replace(/(\d)\s*-\s*(\d)/g, '$1 $2').split(/\s+/).filter(Boolean), cik = [];
    let ara = 0, top = 0, var_ = false, son = '';
    const bitir = () => { if (var_) cik.push(String(top + ara)); ara = 0; top = 0; var_ = false; son = ''; };
    for (const w of t) {
      if (w in BIR) { if (var_ && (ara % 10) !== 0) bitir(); ara += BIR[w]; var_ = true; son = 'bir'; }
      else if (w in ON) { if (var_ && (ara % 100) !== 0) bitir(); ara += ON[w]; var_ = true; son = 'on'; }
      else if (w === 'yuz') { if (var_ && ara >= 100) bitir(); ara = (ara || 1) * 100; var_ = true; son = 'yuz'; }
      else if (w === 'bin') { if (top) bitir(); top = (ara || 1) * 1000; ara = 0; var_ = true; son = 'bin'; }
      else { bitir(); cik.push(w); }
    }
    bitir(); return cik;
  }
  const GIRMEDI = /^(girmedi|gelmedi|yok|g|gir)$/;
  // komut -> [{no?, ad?, puan}] ; hatalar: anlaşılmayan parçalar
  function ayristir(metin) {
    const w = sayilar(metin), cikti = [], hatalar = []; let ref = [], noMu = false;
    const ekle = (puan) => { const r = { puan };
      if (noMu || (ref.length === 1 && /^\d+$/.test(ref[0]))) r.no = ref.find(x => /^\d+$/.test(x)) || ''; else r.ad = ref.filter(x => !/^\d+$/.test(x)).join(' ');
      if (!r.no && !r.ad) hatalar.push('öğrenci yok (' + puan + ')'); else cikti.push(r); ref = []; noMu = false; };
    for (let i = 0; i < w.length; i++) { const x = w[i];
      if (/^(numara|numarali|no|nolu|numarasi)$/.test(x)) { noMu = true; continue; }
      if (/^(puan|not|notu|aldi|ve|virgul|sonraki|tamam)$/.test(x)) continue;
      if (GIRMEDI.test(x) && ref.length) { ekle('G'); continue; }
      if (/^\d+$/.test(x)) {
        if (!ref.length) { ref.push(x); continue; }          // ilk sayı öğrenci numarası
        if (ref.length === 1 && /^\d+$/.test(ref[0]) && !noMu && i + 1 < w.length && /^(numara|numarali|no|nolu)$/.test(w[i + 1])) { hatalar.push(ref[0]); ref = [x]; continue; }
        ekle(x); continue; }
      ref.push(x);
    }
    if (ref.length) hatalar.push(ref.join(' ') + ' (puan yok)');
    return { satirlar: cikti, hatalar };
  }
  const gecerli = p => p === 'G' || (/^\d{1,3}$/.test(String(p)) && +p >= 0 && +p <= 100);
  function adBenzer(a, b) { a = sade(a).replace(/[^a-z ]/g, '').trim(); b = sade(b).replace(/[^a-z ]/g, '').trim(); if (!a || !b) return 0;
    const lev = (x, y) => { let p = [...Array(y.length + 1).keys()]; for (let i = 1; i <= x.length; i++) { const c = [i]; for (let j = 1; j <= y.length; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1)); p = c; } return p[y.length]; };
    const ta = a.split(/\s+/), tb = b.split(/\s+/); let top = 0; ta.forEach(q => { let en = 0; tb.forEach(v => { en = Math.max(en, 1 - lev(q, v) / Math.max(q.length, v.length)); }); top += en; });
    return top / ta.length * (ta.length >= 2 ? 1 : 0.9); }
  // ogrenciler: [{no, ad}] -> {o, neden}
  function bul(ogrenciler, s) {
    if (s.no) { const o = ogrenciler.find(x => String(x.no) === String(+s.no)) || ogrenciler.find(x => String(x.no) === s.no); return o ? { o } : { neden: s.no + ' numara listede yok' }; }
    const sk = ogrenciler.map(o => ({ o, p: adBenzer(s.ad, o.ad) })).sort((a, b) => b.p - a.p);
    if (!sk.length || sk[0].p < 0.75) return { neden: 'ad listede bulunamadı' };
    if (sk[1] && sk[0].p - sk[1].p < 0.1) return { neden: 'ad birden çok öğrenciye benziyor; numarayla söyleyin' };
    return { o: sk[0].o };
  }
  const api = { sayilar, ayristir, gecerli, bul, adBenzer };
  if (typeof module !== 'undefined') { module.exports = api; return; }
  kok.NGASes = api;
  // ---- Sayfa: e-Okul not tablosu ----
  const A = kok.NGAAkis; if (!A) return;
  const mask = a => String(a || '').split(/\s+/).map(k => k ? k[0] + '.' : '').join(' ');
  async function yaz(doc, ayar, s, durum) {
    const T = A.ogrenciTablosu(doc); if (!T) return durum('Not tablosu yok. Önce Listele\'ye basın.', true);
    const og = T.satirlar.map(tr => ({ no: (tr.cells[0] ? tr.cells[0].textContent : '').replace(/\D/g, ''), ad: (tr.cells[1] ? tr.cells[1].textContent : '').trim(), tr })).filter(x => x.no);
    if (!gecerli(s.puan)) return durum('"' + s.puan + '" geçersiz puan (0-100 ya da G). Yazılmadı.', true);
    const b = bul(og, s); if (!b.o) return durum(b.neden + '. Yazılmadı.', true);
    const x = A.hucreGirdisi(b.o.tr, T.bas, ayar.tur, ayar.sinav, ayar.alan); if (!x) return durum(b.o.no + ' numarada seçili sütunun kutusu yok. Yazılmadı.', true);
    const W = doc.defaultView, ev = t => x.dispatchEvent(new W.Event(t, { bubbles: true })), v = String(s.puan);
    x.focus && x.focus(); x.value = ''; ev('input');
    for (const ch of v) { x.value += ch; ev('input'); await new Promise(r => setTimeout(r, 20 + Math.random() * 30)); }
    ev('change'); x.blur && x.blur(); ev('blur');
    og.forEach(q => { if (q.tr.style.outline.indexOf('255') >= 0 || q.tr.dataset.ngaSes) { q.tr.style.outline = ''; delete q.tr.dataset.ngaSes; } });
    b.o.tr.dataset.ngaSes = '1'; b.o.tr.style.outline = '3px solid #ffd400'; x.style.background = '#c8f7c5'; b.o.tr.scrollIntoView && b.o.tr.scrollIntoView({ block: 'center' });
    const m = b.o.no + ' numara (' + mask(b.o.ad) + '): ' + v;
    durum('✓ ' + m, false);
    try { if (ayar.konus !== false && W.speechSynthesis) { const u = new W.SpeechSynthesisUtterance(b.o.no + ' numara ' + (v === 'G' ? 'girmedi' : v)); u.lang = 'tr-TR'; u.rate = 1.2; W.speechSynthesis.speak(u); } } catch (e) {}
    return true;
  }
  // panel.js çağırır: dugme (🎤), durum alanı ve o anki sütun ayarını veren işlev
  function bagla(dugme, durumEl, ayarAl) {
    const SR = kok.SpeechRecognition || kok.webkitSpeechRecognition;
    const durum = (t, hata) => { durumEl.textContent = t; durumEl.style.background = hata ? '#ffeb3b' : '#c8f7c5'; };
    if (!SR) { dugme.disabled = true; dugme.textContent = '🎤 Bu tarayıcıda ses tanıma yok'; return; }
    let tan = null, acik = false;
    const kapa = () => { acik = false; dugme.textContent = '🎤 Sesli not: Başlat'; dugme.style.background = '#000'; };
    // 1.6.23: e-Okul sayfası "Permissions-Policy: microphone=()" gönderir; sayfada mikrofon hiç açılamaz (izin verseniz de not-allowed).
    // Dinleme küçük bir uzantı penceresinde yapılır; tanınan metin chrome.storage.local ile buraya gelir ve aynı ayrıştırma/yazma kullanılır.
    const st = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
    if (!st || !chrome.runtime || !chrome.runtime.sendMessage) { dugme.disabled = true; dugme.textContent = '🎤 Sesli not kullanılamıyor'; return; }
    let sira = Promise.resolve();
    chrome.storage.onChanged.addListener((c, a) => { if (a !== 'local') return;
      if (c.ngaSesDurum && c.ngaSesDurum.newValue) { const v = c.ngaSesDurum.newValue; if (acik) durum(v.t, v.hata); if (v.bitti || (v.hata && /izni|bulunamad/.test(v.t))) kapa(); }
      if (acik && c.ngaSesMetin && c.ngaSesMetin.newValue) { const t = String(c.ngaSesMetin.newValue.t || ''); sira = sira.then(async () => { const r = ayristir(t);
          if (!r.satirlar.length) { durum('Anlaşılmadı: "' + t.slice(0, 40) + '". Örnek: "12 numara 85"', true); return; }
          for (const s of r.satirlar) await yaz(document, ayarAl(), s, durum); if (r.hatalar.length) durum('Kısmen anlaşıldı; atlanan: ' + r.hatalar.join(' | '), true); }).catch(() => {}); } });
    dugme.onclick = () => {
      if (acik) { kapa(); st.set({ ngaSesKomut: { k: 'dur', z: Date.now() } }); durum('Durduruldu.', false); return; }
      acik = true; dugme.textContent = '⏹ Sesli not: Durdur'; dugme.style.background = '#b00020';
      durum('Sesli not penceresi açılıyor. İlk seferde pencerede "Mikrofon kullanılsın mı?" sorusuna İzin ver deyin; pencere açık kalsın.', false);
      try { chrome.runtime.sendMessage({ tip: 'ses-ac' }); } catch (e) { kapa(); durum('Sesli not penceresi açılamadı. Sayfayı yenileyip yeniden deneyin.', true); } };
  }
  kok.NGASes.yaz = yaz; kok.NGASes.bagla = bagla;
})(typeof window !== 'undefined' ? window : globalThis);
