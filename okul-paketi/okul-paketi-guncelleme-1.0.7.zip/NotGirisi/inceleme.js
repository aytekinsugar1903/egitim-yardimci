// Puan inceleme listesi: +/−, düşük güven kırmızı, açılır pencere yok. OCR bağlantısı sonra.
(function (root) {
  'use strict';
  const ESIK = 0.7;
  const kac = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function sinirla(p) { return p === 'G' ? 'G' : Math.max(0, Math.min(100, Math.round(+p || 0))); }
  function olustur(doc, satirlar, kok) {
    // satirlar: [{no, ad, puan, guven}]  (veriler yalnız bu sayfada)
    const st = satirlar.map(s => ({ ...s, puan: sinirla(s.puan), onay: (s.guven ?? 0) >= ESIK }));
    kok.innerHTML = '';
    const tablo = doc.createElement('table'); tablo.className = 'ng-liste';
    const ciz = () => {
      tablo.innerHTML = '<tr><th>No</th><th>Öğrenci</th><th>Puan</th><th></th><th>Onay</th></tr>';
      st.forEach((s, i) => {
        const tr = doc.createElement('tr');
        const dusuk = (s.guven ?? 0) < ESIK && !s.onay; // guven yoksa da onaysız satır kırmızı
        tr.className = dusuk ? 'ng-dusuk' : '';
        tr.style.cssText = dusuk ? 'background:#b00020;color:#fff' : 'background:#fff;color:#000';
        tr.innerHTML = `<td>${kac(s.no)}</td><td>${kac(s.ad)}</td><td class="ng-puan">${s.puan}</td>
          <td><button data-i="${i}" data-d="-1">−</button><button data-i="${i}" data-d="1">+</button><button data-i="${i}" data-g="1">G</button></td>
          <td><input type="checkbox" data-i="${i}" ${s.onay ? 'checked' : ''}></td>`;
        tablo.appendChild(tr);
      });
    };
    tablo.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      const s = st[+b.dataset.i];
      if (b.dataset.g) s.puan = s.puan === 'G' ? 0 : 'G';
      else s.puan = sinirla((s.puan === 'G' ? 0 : s.puan) + (+b.dataset.d));
      s.onay = true; ciz();
    });
    tablo.addEventListener('change', e => { const s = st[+e.target.dataset.i]; if (s) { s.onay = e.target.checked; ciz(); } });
    ciz(); kok.appendChild(tablo);
    return { durum: () => st.map(s => ({ ...s })), hazir: () => st.every(s => s.onay), onayli: () => st.filter(s => s.onay) };
  }
  const api = { olustur, sinirla, ESIK };
  if (typeof module !== 'undefined') module.exports = api; else root.NGAInceleme = api;
})(typeof window !== 'undefined' ? window : globalThis);
