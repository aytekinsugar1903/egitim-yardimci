/* 1.5.0 Oturum açık tutma (e-Okul Asistanı Pro 2.3.38'deki yöntem): yalnız üst pencerede, araç açıkken, 4 dakikada bir
   bulunduğunuz sayfayı arka planda ister (sayfa değişmez). 2 saat işlem yoksa durur. Oturum düşerse işaretler; verileriniz silinmez. */
(function () {
  'use strict';
  // 1.6.17: çerçevelerdeki tuş/tıklama da üst penceredeki "son işlem" süresini yeniler (aynı kaynak)
  if (window !== window.top) { try { ['keydown', 'pointerdown', 'input'].forEach(function (t) { window.addEventListener(t, function () { try { window.top.__NGOturum && window.top.__NGOturum.dokun(); } catch (e) {} }, true); }); } catch (e) {} return; }
  if (window.__NGOturum || typeof chrome === 'undefined' || !chrome.storage) return;
  var ARALIK = 4 * 60 * 1000, BOSTA = 2 * 60 * 60 * 1000, ANAHTAR = 'ng_oturum_acik', depo = chrome.storage.local, son = Date.now(), sonNabiz = 0;
  function giris(doc) { doc = doc || document; return /giris|login/i.test(doc.location ? doc.location.pathname : '') || !!doc.querySelector('input[type=password]'); }
  ['keydown', 'pointerdown', 'input'].forEach(function (t) { window.addEventListener(t, function () { son = Date.now(); }, true); });
  function aracAcik(cb) { var ac = (function () { var q = document.getElementById('nga-panel'); return !!(q && q.isConnected && q.getClientRects().length); })();
    depo.get(['ng_tarama_aktif', 'ng_sorular_aktif'], function (s) { var t = Math.max(s.ng_tarama_aktif || 0, s.ng_sorular_aktif || 0); cb(true || ac, Math.max(son, t)); }); } /* 1.6.17: e-Okul'un her sayfasında (panel çerçevede olsa da) çalışır; 2 saat işlem yoksa durur */
  function durumYaz(d) { depo.set({ ng_oturum_durum: Object.assign({ zaman: Date.now() }, d) }); }
  function nabiz(zorla) {
    depo.get(ANAHTAR, function (o) {
      if (o[ANAHTAR] === false && !zorla) return;
      aracAcik(function (acik, sonIs) {
        if (!zorla && (!acik || Date.now() - sonIs > BOSTA)) return;
        fetch(location.href, { method: 'GET', credentials: 'same-origin', cache: 'no-store' }).then(function (r) {
          return r.text().then(function (t) { sonNabiz = Date.now(); var dus = /giris|login/i.test(r.url) || /type=["']?password/i.test(t);
            durumYaz({ dustu: dus, nabiz: sonNabiz }); }); }).catch(function () { durumYaz({ dustu: false, ag: 'yok', nabiz: sonNabiz }); });
      });
    });
  }
  // Sayfa açılınca: giriş ekranındaysak düştü say; değilsek ve önceden düşmüşse "yeniden açıldı" işaretle
  depo.get('ng_oturum_durum', function (s) { var d = s.ng_oturum_durum || {};
    if (giris()) durumYaz({ dustu: true }); else if (d.dustu) durumYaz({ dustu: false, yenidenAcildi: true }); });
  setInterval(nabiz, ARALIK); setTimeout(function () { if (!giris()) nabiz(); }, 5000);
  window.__NGOturum = { dokun: function () { son = Date.now(); }, nabiz: nabiz, giris: giris, test: { ARALIK: ARALIK, BOSTA: BOSTA } };
})();
