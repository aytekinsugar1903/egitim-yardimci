/* Evrak Asistanı · Eyüp ŞEKER — Tema: Otomatik / Açık / Koyu (chrome.storage.local 'ea_tema'; yazdırma her zaman açık) */
(function () {
  'use strict';
  var EXT = !/^https?:$/.test(location.protocol);
  var SC = EXT ? 'html[data-tema=koyu]' : '#nga-panel[data-tema=koyu]';
  var css = '@media screen{' + SC + '{background:#111418!important;color:#e8eaed!important;color-scheme:dark}' + (EXT ? SC + ' body{background:#111418!important;color:#e8eaed!important}' : '') +
    SC + ' input,' + SC + ' select,' + SC + ' textarea{background:#1e232b!important;color:#e8eaed!important;border-color:#46505e!important}' +
    SC + ' button{background:#8ab4f8!important;color:#0b1220!important}' + SC + ' button.a,' + SC + ' button.sec{background:#1c2533!important;color:#e8eaed!important;border:1px solid #46505e!important}' +
    SC + ' table,' + SC + ' th,' + SC + ' td{border-color:#46505e!important;color:#e8eaed}' + SC + ' a{color:#8ab4f8}' + SC + ' div,' + SC + ' section,' + SC + ' fieldset{border-color:#46505e}' +
    SC + ' [style*="background:#fff"],' + SC + ' [style*="background: #fff"],' + SC + ' [style*="background:white"]{background:#181c22!important}' +
    SC + ' .sari,' + SC + ' tr.sari td,' + SC + ' td.s,' + SC + ' td.s input{background:#5a4a00!important;color:#fff!important}' +
    // 1.7.4 koyu temada okunmayan yerler: açıklama metni (.k), grup satırı (.grp), çubuk (.bar), devre dışı düğme
    SC + ' .k,' + SC + ' small{color:#b8c0cc!important}' + SC + ' .grp,' + SC + ' .grp td,' + SC + ' tr.grp td{background:#2a313b!important;color:#e8eaed!important}' + SC + ' .bar{background:#8ab4f8!important}' + SC + ' button:disabled{opacity:.45;cursor:not-allowed}' + SC + ' td.ok{background:transparent!important}' + SC + ' [style*="#ffeb3b"]{color:#000!important}' +
    '}:focus-visible{outline:3px solid #f2a900!important;outline-offset:2px}.ea-tema{font:13px sans-serif;margin:4px}' +
    '@media print{*{background:#fff!important;color:#000!important}.ea-tema{display:none!important}}';
  var YK = SC.replace(/koyu/g, 'yk'), EO = SC.replace(/koyu/g, 'eokul');
  css += '@media screen{' + YK + '{background:#000!important;color:#fff!important;color-scheme:dark}' + (EXT ? YK + ' body{background:#000!important;color:#fff!important}' : '') +
    YK + ' *{background-color:#000!important;color:#fff!important;border-color:#fff!important}' + YK + ' a,' + YK + ' h1,' + YK + ' h2,' + YK + ' h3,' + YK + ' b{color:#ffff00!important}' +
    YK + ' button{background:#000!important;color:#ffff00!important;border:2px solid #ffff00!important}' + YK + ' input,' + YK + ' select,' + YK + ' textarea{border:2px solid #fff!important}' + YK + ' :focus-visible{outline:4px solid #00ffff!important;outline-offset:3px}' +
    EO + '{background:#eef1f5!important;color:#1f2d3d!important}' + (EXT ? EO + ' body{background:#eef1f5!important;color:#1f2d3d!important}' : '') +
    EO + ' button{background:#337ab7!important;color:#fff!important;border:0!important}' + EO + ' button.a,' + EO + ' button.sec{background:#117a8b!important;color:#fff!important}' +
    EO + ' button[id*=kaydet],' + EO + ' button[id*=Kaydet],' + EO + ' button.ok{background:#8bc34a!important;color:#14210a!important}' + EO + ' button[id*=sil],' + EO + ' button.sil{background:#c62828!important;color:#fff!important}' +
    EO + ' h1,' + EO + ' h2,' + EO + ' h3{color:#23527c!important}' + EO + ' input,' + EO + ' select,' + EO + ' textarea{background:#fff!important;color:#1f2d3d!important;border:1px solid #b8c4d1!important}' + EO + ' table,' + EO + ' th,' + EO + ' td{border-color:#b8c4d1!important}' + EO + ' th{background:#337ab7!important;color:#fff!important}}' +
    '@media print{*{background:#fff!important;color:#000!important}.ea-tema{display:none!important}}';
  function hedef() { return EXT ? document.documentElement : document.getElementById('nga-panel'); }
  var mq = window.matchMedia ? matchMedia('(prefers-color-scheme: dark)') : null, deger = 'oto';
  function uygula() { var h = hedef(); if (!h) return; h.setAttribute('data-tema', deger === 'oto' ? (mq && mq.matches ? 'koyu' : 'acik') : deger); }
  function oku(cb) { try { chrome.storage.local.get('ea_tema', function (o) { deger = (o && o.ea_tema) || 'oto'; cb(); }); } catch (e) { deger = localStorage.getItem('ea_tema') || 'oto'; cb(); } }
  function kaydet(v) { deger = v; try { chrome.storage.local.set({ ea_tema: v }); } catch (e) { localStorage.setItem('ea_tema', v); } uygula(); }
  function secici() { var s = document.createElement('select'); s.setAttribute('aria-label', 'Tema'); s.id = 'eaTema'; [['oto', 'Otomatik'], ['acik', 'Açık'], ['koyu', 'Koyu'], ['yk', 'Yüksek karşıtlık'], ['eokul', 'e-Okul renkleri']].forEach(function (x) { var o = document.createElement('option'); o.value = x[0]; o.textContent = x[1]; if (x[0] === deger) o.selected = true; s.appendChild(o); }); s.onchange = function () { kaydet(s.value); }; var l = document.createElement('label'); l.className = 'ea-tema'; l.appendChild(document.createTextNode('🌓 Tema ')); l.appendChild(s); return l; }
  var st = document.createElement('style'); st.textContent = css; (document.head || document.documentElement).appendChild(st);
  window.EATema = { kaydet: kaydet, uygula: uygula, secici: secici };
  // 1.7.4 Sürüm etiketi (id=surum) elle yazılmaz; manifest.json'dan okunur
  try { var se = document.getElementById('surum'), sv = EXT && chrome.runtime.getManifest().version; if (se && sv) se.textContent = 'Not Girişi ' + sv + ' · Evrak Asistanı'; } catch (e) { }
  oku(function () {
    uygula(); if (mq && mq.addEventListener) mq.addEventListener('change', uygula);
    if (EXT) { var b = document.body; if (b) { b.insertBefore(secici(), b.firstChild); var li = document.createElement('img'); li.className = 'ea-logo'; li.alt = 'Evrak Asistanı'; li.src = '../icons/icon48.png'; li.style.cssText = 'width:28px;height:28px;border-radius:6px;background:#fff;padding:2px;border:2px solid #fff;box-shadow:0 0 0 1px #000;vertical-align:middle;margin:4px'; b.insertBefore(li, b.firstChild); } }
    else { var t = 0, iv = setInterval(function () { var p = hedef(); if (p) { uygula(); if (!p.querySelector('#eaTema')) p.appendChild(secici()); if (!p.querySelector('.ea-logo')) { try { var im = document.createElement('img'); im.className = 'ea-logo'; im.alt = 'Evrak Asistanı'; im.src = chrome.runtime.getURL('icons/icon48.png'); im.style.cssText = 'width:28px;height:28px;border-radius:6px;background:#fff;padding:2px;border:2px solid #fff;box-shadow:0 0 0 1px #000;vertical-align:middle;margin:2px 6px 2px 0;float:left'; p.insertBefore(im, p.firstChild); } catch (e) {} } clearInterval(iv); } if (++t > 60) clearInterval(iv); }, 500); }
    try { chrome.storage.onChanged.addListener(function (c) { if (c.ea_tema) { deger = c.ea_tema.newValue || 'oto'; uygula(); } }); } catch (e) {}
  });
})();
