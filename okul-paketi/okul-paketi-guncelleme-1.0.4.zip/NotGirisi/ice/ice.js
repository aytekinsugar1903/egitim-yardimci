// 1.6.28 Excel/CSV içe aktarma sayfası. Yerel ayrıştırma (SheetJS, pakette); sonuç yalnız chrome.storage.local'a (ng_ice_aktar) yazılır.
const I = window.NGAIce, $ = (id) => document.getElementById(id), st = chrome.storage.local;
const esc = (x) => String(x == null ? '' : x).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
let kitap = null, sayfalar = [], sat = [];
const msg = (t, h) => { $('m').textContent = t; $('m').style.background = h ? '#ffeb3b' : '#c8f7c5'; };
$('dosya').onchange = async (e) => { const f = e.target.files[0]; if (!f) return; try { const buf = new Uint8Array(await f.arrayBuffer());
    if (/\.(csv|txt)$/i.test(f.name)) { let t; try { t = new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch (x) { t = new TextDecoder('windows-1254').decode(buf); } kitap = XLSX.read(t.replace(/^\ufeff/, ''), { type: 'string', raw: true }); }
    else kitap = XLSX.read(buf, { type: 'array', codepage: 1254 });
    sayfalar = kitap.SheetNames.map((ad) => { const t = XLSX.utils.sheet_to_json(kitap.Sheets[ad], { header: 1, raw: true, defval: '' }); return { ad, t, b: I.baslikBul(t, ad) }; }).filter((s) => s.t.length);
    if (!sayfalar.length) return msg('Dosyada veri yok.', true);
    $('sayfa').innerHTML = (sayfalar.length > 1 ? '<option value="*">Tüm sayfalar</option>' : '') + sayfalar.map((s, i) => '<option value="' + i + '">' + esc(s.ad) + '</option>').join('');
    seciciler(sayfalar[0]); $('esle').hidden = false; hesapla(); } catch (x) { msg('Dosya okunamadı: ' + (x && x.message || x), true); } };
function seciciler(s) { const ops = '<option value="-1">—</option>' + s.b.sutunlar.map((c) => '<option value="' + c.i + '">' + esc(c.ad) + '</option>').join('');
  document.querySelectorAll('#esle select[data-a]').forEach((x) => { x.innerHTML = ops; x.value = String(s.b.esle[x.dataset.a]); });
  const pc = s.b.esle.puan.length ? s.b.esle.puan : s.b.sutunlar.map((c) => c.i); $('puan').innerHTML = pc.map((i) => '<option value="' + i + '">' + esc((s.b.sutunlar[i] || {}).ad || 'Sütun ' + (i + 1)) + '</option>').join('');
  turAyarla(); $('emin').textContent = s.b.emin ? '✓ başlıklar tanındı' : '⚠ emin değilim: sütunları seçin'; $('emin').style.background = s.b.emin ? '#c8f7c5' : '#ffeb3b'; }
function turAyarla() { const s = sayfalar[0], c = s && s.b.sutunlar[+$('puan').value]; if (!c) return; const t = I.sutunTuru(c.ad); $('tur').value = t.tur; $('n').value = t.n; }
$('puan').onchange = () => { turAyarla(); hesapla(); };
$('sayfa').onchange = () => { const v = $('sayfa').value; seciciler(sayfalar[v === '*' ? 0 : +v]); hesapla(); };
document.querySelectorAll('#esle select[data-a], #vsinif').forEach((x) => { x.onchange = hesapla; });
function hesapla() { const v = $('sayfa').value, sec = v === '*' ? sayfalar : [sayfalar[+v]], el = {}; document.querySelectorAll('#esle select[data-a]').forEach((x) => { el[x.dataset.a] = +x.value; });
  const pi = +$('puan').value, vs = I.sinifCoz($('vsinif').value) || '';
  sat = []; sec.forEach((s, k) => { const b = Object.assign({}, s.b, { esle: k === 0 || v !== '*' ? Object.assign({}, s.b.esle, el) : s.b.esle }); const p = k === 0 || v !== '*' ? pi : (s.b.esle.puan[sayfalar[0].b.esle.puan.indexOf(pi)] ?? s.b.esle.puan[0]); sat.push(...I.satirlar(s.t, b, p, vs || s.b.varsayilanSinif)); });
  ciz(); }
function ciz() { const g = {}; sat.forEach((r, i) => { (g[r.sinif || '?'] = g[r.sinif || '?'] || []).push(i); });
  const sorun = sat.filter((r) => r.sorun).length;
  $('onizle').innerHTML = sat.length ? '<table><tr><th>Sınıf-Şube</th><th>Okul No</th><th>Ad</th><th>Ders</th><th>Puan</th><th></th></tr>' + Object.keys(g).map((k) => '<tr><td class="grp" colspan="6">' + esc(k) + ' — ' + g[k].length + ' satır</td></tr>' + g[k].map((i) => { const r = sat[i];
    return '<tr data-i="' + i + '"' + (r.sorun ? ' class="sorun" title="' + esc(r.sorun) + '"' : '') + '><td><input class="h" data-k="sinif" value="' + esc(r.sinif) + '"></td><td><input class="h" data-k="no" value="' + esc(r.no) + '"></td><td>' + esc(r.ad) + '</td><td><input data-k="ders" value="' + esc(r.ders) + '"></td><td><input class="h" data-k="puan" value="' + esc(r.puan) + '"></td><td><button data-sil="1" style="padding:1px 6px">✗</button></td></tr>'; }).join('')).join('') + '</table>' : '';
  $('onizle').querySelectorAll('input').forEach((x) => { x.onchange = () => { const r = sat[+x.closest('tr').dataset.i], v = x.value.trim(); if (x.dataset.k === 'sinif') r.sinif = I.sinifCoz(v) || v; else if (x.dataset.k === 'puan') r.puan = I.puanCoz(v); else if (x.dataset.k === 'no') r.no = v.replace(/\D/g, ''); else r.ders = v;
    r.sorun = [!I.sinifCoz(r.sinif) && 'şube yok', r.puan === '?' && 'geçersiz puan', r.puan === '' && 'puan boş'].filter(Boolean).join(', '); ciz(); }; });
  $('onizle').querySelectorAll('button[data-sil]').forEach((b) => { b.onclick = () => { sat.splice(+b.closest('tr').dataset.i, 1); ciz(); }; });
  const iyi = sat.filter((r) => !r.sorun).length; $('gonder').disabled = !iyi;
  msg(sat.length ? sat.length + ' satır, ' + Object.keys(g).length + ' şube (' + Object.keys(g).map((k) => k + ': ' + g[k].length).join(', ') + '). ' + (sorun ? sorun + ' satır sarı (şube/puan eksik) gönderilmez; düzeltin ya da silin.' : 'Hepsi hazır.') : 'Okul No sütununda numara bulunamadı; sütunları seçin.', !sat.length || !!sorun); }
$('gonder').onclick = () => { const iyi = sat.filter((r) => !r.sorun);
  st.set({ ng_ice_aktar: { z: Date.now(), tur: $('tur').value, sinav: Math.max(1, +$('n').value || 1), g: $('g').checked, ders: $('vders').value.trim(), satirlar: iyi.map((r) => ({ sinif: r.sinif, no: r.no, ders: r.ders, puan: r.puan })) } },
    () => msg(iyi.length + ' not gönderildi. e-Okul sekmesindeki panelde "Dosyadaki notları şube şube gir ▶" düğmesine basın (panel kapalıysa Alt+G).', false)); };
