// 1.6.28 Excel/CSV'den not alma: başlık sütunlarını tanıma ve satırları ayrıştırma (yalnız bu bilgisayarda; ağ yok).
(function (kok) {
  'use strict';
  const sade = (s) => String(s == null ? '' : s).replace(/I/g, 'ı').replace(/İ/g, 'i').toLowerCase().replace(/ı/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c').replace(/i̇/g, 'i').replace(/\s+/g, ' ').trim();
  // başlık -> alan
  function alanTuru(h) { const s = sade(h).replace(/[._:]/g, ' ').replace(/\s+/g, ' ').trim(); if (!s) return null;
    if (/^(s ?no|sira( no)?|#)$/.test(s)) return null;
    if (/(okul ?no|ogrenci ?no|okul numarasi|^numara(si)?$|^no$|^numara$)/.test(s)) return 'no';
    if (/(ad(i)? ?soyad|^ad$|^adi$|^isim|ogrenci ad|^ad soyad)/.test(s)) return 'ad';
    if (/^(sinif ?\/ ?sube|sinif ?- ?sube|sinif sube|sinifi|sinif)$/.test(s) || /sinif.*sube/.test(s)) return 'sinif';
    if (/^sube(si)?$/.test(s)) return 'sube';
    if (/^ders(in adi| adi)?$/.test(s)) return 'ders';
    if (/(sinav|yazili|puan|^not$|notu|perf|proje|uygulama|^uyg)/.test(s)) return 'puan';
    return null; }
  // "2. Sınav" -> {tur:'sinav', n:2}; "1. Perf." -> perf 1; "Proje" -> proje 1
  function sutunTuru(h) { const s = sade(h), n = +((s.match(/(\d)/) || [])[1] || 1);
    if (/proje/.test(s)) return { tur: 'proje', n: 1 }; if (/perf/.test(s)) return { tur: 'perf', n: Math.min(n, 3) }; if (/uyg/.test(s)) return { tur: 'uyg', n: Math.min(n, 3) };
    return { tur: 'sinav', n: Math.min(n, 6) }; }
  const SINIF_RE = /(\d{1,2})\s*\.?\s*(?:s[ıi]n[ıi]f[ıi]?)?\s*[-/ .]\s*([A-ZÇĞİÖŞÜa-zçğıöşü])(?:\s*[şs]ube(?:si)?)?(?![a-zçğıöşü])/i;
  function sinifCoz(v, sube) { const t = String(v == null ? '' : v).trim(); if (!t) return '';
    if (sube != null && String(sube).trim() && /^\d{1,2}\.?$/.test(t.replace(/\s*s[ıi]n[ıi]f[ıi]?/i, '').trim())) return +t.match(/\d+/)[0] + '-' + String(sube).trim().toLocaleUpperCase('tr-TR').replace(/\s*[ŞS]UBE(S[İI])?$/, '').slice(0, 1);
    const m = t.match(SINIF_RE); return m && +m[1] >= 1 && +m[1] <= 12 ? +m[1] + '-' + m[2].toLocaleUpperCase('tr-TR') : ''; }
  function puanCoz(v) { if (v == null) return ''; if (typeof v === 'number') return v >= 0 && v <= 100 ? String(Math.round(v)) : '?';
    const s = sade(v); if (!s) return ''; if (/^(g|girmedi|gelmedi|katilmadi)$/.test(s)) return 'G';
    const x = Number(s.replace(',', '.')); return isFinite(x) && x >= 0 && x <= 100 ? String(Math.round(x)) : '?'; }
  // tablo: [[hücre…]…] (bir sayfa). Dönüş: {baslikSatir, sutunlar:[{i,ad,alan}], esle:{no,ad,sinif,sube,ders,puan:[i…]}, varsayilanSinif, emin}
  function baslikBul(tablo, sayfaAdi) { let en = { skor: 0, i: -1 };
    for (let i = 0; i < Math.min(tablo.length, 20); i++) { const r = tablo[i] || [], al = r.map(alanTuru), sk = new Set(al.filter(Boolean)).size + (al.includes('no') ? 1 : 0); if (sk > en.skor) en = { skor: sk, i }; }
    const bi = en.i, gen = Math.max(0, ...tablo.slice(0, 40).map((r) => (r || []).length)), bas = bi >= 0 ? (tablo[bi] || []) : Array(gen).fill(''), sutunlar = Array.from({ length: Math.max(bas.length, gen) }, (_, i) => ({ i, ad: String(bas[i] == null ? '' : bas[i]).trim() || 'Sütun ' + (i + 1), alan: alanTuru(bas[i]) }));
    const esle = { no: -1, ad: -1, sinif: -1, sube: -1, ders: -1, puan: [] }; sutunlar.forEach((c) => { if (!c.alan) return; if (c.alan === 'puan') esle.puan.push(c.i); else if (esle[c.alan] < 0) esle[c.alan] = c.i; });
    let vs = sinifCoz(sayfaAdi); for (let i = 0; i < Math.max(bi, 0) && !vs; i++) (tablo[i] || []).forEach((h) => { if (!vs) vs = sinifCoz(h); });
    if (esle.no < 0) { // başlıksız no sütunu: en çok 3-6 haneli tamsayı içeren
      let enc = { n: 0, i: -1 }; for (let c = 0; c < sutunlar.length; c++) { const n = tablo.slice(bi + 1, bi + 40).filter((r) => /^\d{3,6}$/.test(String(r && r[c] != null ? r[c] : '').trim())).length; if (n > enc.n) enc = { n, i: c }; } if (enc.n >= 2) esle.no = enc.i; }
    const emin = bi >= 0 && esle.no >= 0 && esle.puan.length >= 1 && (esle.sinif >= 0 || !!vs);
    return { baslikSatir: bi, sutunlar, esle, varsayilanSinif: vs, emin }; }
  // satırlar -> [{sinif, no, ad, ders, puan, sorun}]
  function satirlar(tablo, b, puanSutun, varsayilanSinif) { const e = b.esle, cik = [], ps = puanSutun != null ? puanSutun : e.puan[0];
    for (let i = b.baslikSatir + 1; i < tablo.length; i++) { const r = tablo[i] || []; const no = String(r[e.no] == null ? '' : r[e.no]).replace(/\.0+$/, '').replace(/\D/g, '');
      if (!no) continue; const sinif = e.sinif >= 0 ? sinifCoz(r[e.sinif], e.sube >= 0 ? r[e.sube] : null) : (varsayilanSinif || b.varsayilanSinif || ''), puan = ps >= 0 ? puanCoz(r[ps]) : '';
      const sorun = [!sinif && 'şube yok', puan === '?' && 'geçersiz puan', puan === '' && 'puan boş'].filter(Boolean).join(', ');
      cik.push({ sinif, no, ad: e.ad >= 0 ? String(r[e.ad] == null ? '' : r[e.ad]).trim() : '', ders: e.ders >= 0 ? String(r[e.ders] == null ? '' : r[e.ders]).trim() : '', puan, sorun }); }
    return cik; }
  const api = { sade, alanTuru, sutunTuru, sinifCoz, puanCoz, baslikBul, satirlar };
  if (typeof module !== 'undefined') module.exports = api; else kok.NGAIce = api;
})(typeof window !== 'undefined' ? window : globalThis);
