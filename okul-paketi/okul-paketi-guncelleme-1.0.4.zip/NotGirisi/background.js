// Arka plan (MV3 service worker): araç çubuğu simgesi ve sekme açma. Ağ isteği yok; veri işlemez.
const E_OKUL = /^https:\/\/(e-okul|eokul|[^/]+\.e-okul)\.meb\.gov\.tr\//i;
const SAYFALAR = { tarama: 'tarama/tarama.html', notoku: 'tarama/tarama.html?basit=1', ice: 'ice/ice.html', soru: 'tarama/soru.html' };
chrome.action.onClicked.addListener(async (tab) => {
  if (tab && tab.id != null && E_OKUL.test(tab.url || '')) {
    try { await chrome.tabs.sendMessage(tab.id, { tip: 'nga-ac' }, { frameId: 0 }); return; } catch (e) { /* panel yüklenmemiş */ }
  }
  chrome.tabs.create({ url: chrome.runtime.getURL(SAYFALAR.notoku) });
});
// 1.6.23 Sesli not: e-Okul sayfası mikrofonu yasakladığı için dinleme küçük bir uzantı penceresinde yapılır
let sesPencere = null;
chrome.runtime.onMessage.addListener((m, gonderen) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'ses-ac') return;
  const ac = () => chrome.windows.create({ url: chrome.runtime.getURL('ses/ses.html'), type: 'popup', width: 480, height: 600, focused: true }, (w) => { sesPencere = w && w.id; });
  if (sesPencere != null) chrome.windows.get(sesPencere, () => { if (chrome.runtime.lastError) { sesPencere = null; ac(); } else chrome.windows.update(sesPencere, { focused: true }); }); else ac();
});
chrome.runtime.onMessage.addListener((m, gonderen) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'sekme-ac' || !SAYFALAR[m.hedef]) return;
  chrome.tabs.create({ url: chrome.runtime.getURL(SAYFALAR[m.hedef]) });
});
