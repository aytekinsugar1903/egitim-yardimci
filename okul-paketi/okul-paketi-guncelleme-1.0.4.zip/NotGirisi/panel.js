// e-Okul Not Girişi Asistanı 1.1.0 — bağımsız panel. Açılır pencere yok, yüksek kontrast, veri yerelde.
// Pro ile çakışmaz: panel id "nga-panel", kısayol Alt+G, anahtarlar "nga*". Pro paneli (#ng-panel) açıksa çekilir.
(function () {
  'use strict';
  // 1.6.12: tüm e-Okul sayfalarında (ana sayfa dahil) tek çekmece: üst çerçevede; üst çerçeve frameset ise en büyük alt çerçevede
  const yerimMi = () => { if (window.top === window) return !!document.body && document.body.tagName !== 'FRAMESET';
    try { const td = window.top.document; if (!td.querySelector('frameset') || window.parent !== window.top) return false;
      const fs = [...window.parent.frames].map((f, i) => { let a = 0; try { a = f.innerWidth * f.innerHeight; } catch (e) {} return [i, a]; }).sort((x, y) => y[1] - x[1]);
      return fs.length && window.parent.frames[fs[0][0]] === window; } catch (e) { return false; } };
  if (!yerimMi() || document.getElementById('nga-panel')) return;
  const A = window.NGAAkis; if (!A) return;
  const ANAHTAR = 'ngaBekleyen', ONAY = 'ngaKvkkOnay', PRO_ID = 'ng-panel';
  const depo = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) || null;
  const onayOku = () => new Promise(r => depo ? depo.get(ONAY, v => r(!!v[ONAY])) : r(localStorage.getItem(ONAY) === '1'));
  const onayYaz = () => depo ? depo.set({ [ONAY]: true }) : localStorage.setItem(ONAY, '1');
  const p = document.createElement('div'); p.id = 'nga-panel';
  p.style.cssText = 'position:fixed;right:0;bottom:8px;transition:transform .25s;max-height:90vh;overflow:auto;z-index:2147483001;background:#fff;color:#000;border:3px solid #000;font:14px sans-serif;padding:8px;width:300px';
  const $ = id => p.querySelector('#' + id);
  // 1.6.17: tıklanabilir öğelerde el imleci
  if (!document.getElementById('nga-imlec')) { const st = document.createElement('style'); st.id = 'nga-imlec'; st.textContent = '#nga-panel{cursor:default}#nga-panel button,#nga-panel select,#nga-panel summary,#nga-panel a,#nga-panel label,#nga-panel input[type=checkbox],#nga-panel input[type=radio],#nga-panel input[type=file],#nga-panel input[type=button],#nga-panel input[type=submit],#nga-panel [onclick],#nga-panel [role=button],#nga-panel tr[data-tik],#nga-dil{cursor:pointer!important}#nga-panel button:disabled{cursor:not-allowed!important}#nga-panel input[type=text],#nga-panel input:not([type]),#nga-panel input[type=number],#nga-panel textarea{cursor:text}'; (document.head || document.documentElement).appendChild(st); }
  const proAcik = () => !!document.getElementById(PRO_ID);
  // 1.6.9: sağ alt kenarda çekmece. Dile tıklayınca panel kayar; dil yukarı/aşağı sürüklenir; açık/kapalı ve yer hatırlanır.
  const dil = document.createElement('div'); dil.id = 'nga-dil'; dil.textContent = '⠿ Not'; dil.title = 'Not Girişi paneli (sürükleyip yukarı/aşağı taşıyın)';
  dil.style.cssText = 'position:fixed;right:0;bottom:120px;z-index:2147483002;background:#000;color:#fff;border:2px solid #fff;border-right:0;font:bold 14px sans-serif;padding:8px 6px;cursor:pointer;writing-mode:vertical-rl;user-select:none;touch-action:none';
  let cekAcik = true;
  const cekCiz = () => { p.style.transform = cekAcik ? 'none' : 'translateX(105%)'; dil.style.right = cekAcik ? (p.offsetWidth || 316) + 'px' : '0'; };
  const cekYaz = () => { if (depo) depo.set({ ngaCekmece: { acik: cekAcik, alt: dil.style.bottom } }); };
  if (depo) depo.get('ngaCekmece', v => { const c = v.ngaCekmece; if (c) { cekAcik = c.acik !== false; if (c.alt) { dil.style.bottom = c.alt; p.style.bottom = c.alt; } } cekCiz(); });
  let surukle = null;
  dil.addEventListener('pointerdown', e => { surukle = { y: e.clientY, alt: parseInt(dil.style.bottom) || 0, oynadi: false }; dil.setPointerCapture && dil.setPointerCapture(e.pointerId); });
  dil.addEventListener('pointermove', e => { if (!surukle) return; const d = surukle.y - e.clientY; if (Math.abs(d) > 4) surukle.oynadi = true;
    if (surukle.oynadi) { const a = Math.max(0, Math.min(window.innerHeight - 60, surukle.alt + d)) + 'px'; dil.style.bottom = a; p.style.bottom = a; } });
  dil.addEventListener('pointerup', () => { if (!surukle) return; const o = surukle.oynadi; surukle = null; if (!o) { cekAcik = !cekAcik; cekCiz(); } cekYaz(); });
  const ekle = () => { if (document.body && !p.isConnected) document.body.appendChild(p); if (document.body && !dil.isConnected) document.body.appendChild(dil); cekCiz(); };
  const durumlar = {};
  const durum = (k, tur, metin) => { durumlar[k] = (tur === 'tamam' ? '✓ ' : tur === 'bekle' ? '⏳ ' : '✗ ') + metin;
    const u = $('nga-durum'); if (u) u.innerHTML = Object.values(durumlar).map(t => `<li>${t.replace(/</g, '&lt;')}</li>`).join(''); };
  let sinav = 1, tur = 'sinav', otoListele = true, alan = 'Y'; // alan: Yabancı Dil gibi derslerde Y yazılı, D dinleme, K konuşma kutusu
  if (depo) depo.get('ngaAlan', v => { if (['Y', 'D', 'K'].includes(v.ngaAlan)) { alan = v.ngaAlan; const b = $('nga-alan'); if (b) b.textContent = alan; } });
  // 1.6.17 Şube başına öğrenci listeleri (e-Okul Sınıf Listesi görüldükçe): { '10-M': { zaman, ogrenciler: [{no, ad}] } }
  let listeler = {};
  if (depo) depo.get('ng_sinif_listeleri', v => { listeler = v.ng_sinif_listeleri || {}; });
  const sk = A.sinifAnahtar;
  const listeNolari = k => { const e = Object.keys(listeler).find(x => sk(x) === sk(k)); return e ? listeler[e].ogrenciler.map(o => o.no) : null; };
  const tumNolar = () => [...new Set(Object.values(listeler).flatMap(l => l.ogrenciler.map(o => o.no)))];
  function listedenSinif(no) { const b = Object.keys(listeler).filter(k => listeler[k].ogrenciler.some(o => o.no === no)); return b.length === 1 ? { durum: 'tek', sinif: b[0] } : { durum: b.length ? 'cok' : 'yok' }; }
  const listeAd = no => { for (const k of Object.keys(listeler)) { const o = listeler[k].ogrenciler.find(x => x.no === no); if (o) return o.ad; } return ''; };
  const maskAd = a => String(a || '').trim().split(/\s+/).filter(Boolean).map(w => w.slice(0, 1) + '…').join(' '); // ad yalnız baş harflerle gösterilir
  // Sınıfı okunamamış satıra Okul No'dan listedeki şubeyi verir (sarı kalır; ✓ ile onaylanır). Elle onaylı satıra dokunmaz.
  function sinifDoldur() { let d = 0; tablo.forEach(r => { if (r.sinif || r.basKesin || !r.no) return; const b = listedenSinif(r.no); if (b.durum === 'tek') { r.sinif = b.sinif; d++; } }); return d; }
  if (depo) depo.get('ngaOtoListele', v => { if (v.ngaOtoListele === false) { otoListele = false; const k = $('nga-oto'); if (k) k.checked = false; } });
  const TURAD = { sinav: 'Sınav', perf: 'Perf.', uyg: 'Uyg.', proje: 'Proje' }, TURMAX = { sinav: 6, perf: 3, uyg: 3, proje: 1 }, TURLAR = Object.keys(TURAD);
  function kvkkCiz() {
    p.innerHTML = `<b>e-Okul Not Girişi Asistanı</b> <button id="nga-kapat" style="float:right">×</button>
     <p id="nga-kvkk" style="margin:6px 0">KVKK: Bu uzantı öğrenci adı, numarası ve puanlarını yalnızca bu bilgisayarda, bu sayfada işler. Hiçbir sunucuya veri göndermez. Not kaydını her zaman siz yaparsınız.</p>
     <button id="nga-onayla" style="background:#000;color:#fff;font-weight:bold">Okudum, onaylıyorum</button>`;
    $('nga-kapat').onclick = () => { cekAcik = false; cekCiz(); cekYaz(); };
    $('nga-onayla').onclick = () => { onayYaz(); anaCiz(); };
  }
  function anaCiz() {
    const ip = 'style="color:#333;font-size:12px;margin:2px 0 6px"', bb = 'style="background:#000;color:#fff;font-weight:bold;width:100%;padding:6px"';
    p.innerHTML = `<b>Not Girişi</b> <button id="nga-kapat" title="Gizle" style="float:right">×</button>
     <div id="nga-pro" style="display:none;background:#ffeb3b;color:#000;border:2px solid #000;padding:4px;margin:4px 0">e-Okul Asistanı Pro'nun Not Girişi paneli de açık. Aynı anda yalnız birini kullanın.</div>
     <div style="margin-top:6px"><b>1) Kâğıtları seç</b></div>
     <button id="nga-tarama" ${bb}>Kâğıtları seç ve oku (PDF / fotoğraf)</button>
     <div ${ip}>Açılan sekmede dosyaları seçin; ilk sayfada Okul No, Ad Soyad ve puanın çevresine kutu çizip Oku'ya basın.</div>
     <div><b>2) Tabloyu kontrol et</b></div>
     <div id="nga-tablo" style="max-height:220px;overflow:auto;border:2px solid #000"></div>
     <div><button id="nga-satir-arti" title="Satır ekle">+</button> <span id="nga-ozet"></span></div>
     <div ${ip}>Sarı satırları kâğıtla karşılaştırın; düzeltin ya da ✓ ile onaylayın. Excel'den yapıştırabilirsiniz.</div>
     <div><b>3) Grup / Ders / Sütun</b></div>
     <div id="nga-grup" style="font-weight:bold"></div>
     <div>Sınıf <input id="nga-sinif" size="4" value="9" title="9 ya da 12-A"> Şube <input id="nga-sube" size="2" value="A"></div>
     <div>Ders <select id="nga-ders" style="max-width:220px"><option value="">(sınıf seçilince dolar)</option></select></div>
     <div>Sütun <button id="nga-tur">${TURAD[tur]}</button> <button id="nga-eksi">−</button> <span id="nga-sinav">${sinav}</span> <button id="nga-arti">+</button></div>
     <div>Alan <button id="nga-alan" title="Yabancı Dil gibi Y/D/K kutulu derslerde notun yazılacağı kutu (yalnız Sınav sütununda)">${alan}</button> <span style="font-size:12px">Y yazılı · D dinleme · K konuşma</span></div>
     <button id="nga-git" ${bb}>Ders Notu Girişi'ni aç ve hazırla</button>
     <div ${ip}>e-Okul'un herhangi bir sayfasından başlar. Güvenlik Kodu'nu siz yazın; liste gelir, notlar yazılır.</div>
     <button id="nga-sonraki" hidden style="background:#ffeb3b;color:#000;border:2px solid #000;font-weight:bold;width:100%;padding:6px">Sonraki grup ▶</button>
     <div><b>4) e-Okul'a yaz</b></div>
     <button id="nga-yaz" style="background:#0b5;color:#000;border:2px solid #000;font-weight:bold;width:100%;padding:6px">e-Okul'a yaz</button>
     <button id="nga-ses" title="Seçili sütuna sesle not yazar: &quot;12 numara 85&quot;, &quot;Ad Soyad 85&quot;, &quot;12 numara girmedi&quot;" style="background:#000;color:#fff;border:2px solid #000;font-weight:bold;width:100%;padding:6px;margin-top:4px">🎤 Sesli not: Başlat</button>
     <div id="nga-ses-d" style="font-size:12px;font-weight:bold;padding:2px 4px;min-height:14px"></div>
     <div id="nga-tampon" style="font-size:12px"></div>
     <button id="nga-ice" style="background:#fff;color:#000;border:2px solid #000;font-weight:bold;width:100%;padding:4px;margin-top:4px">📄 Excel/CSV'den not al</button><button id="nga-soru" style="background:#fff;color:#000;border:2px solid #000;font-weight:bold;width:100%;padding:4px;margin-top:4px">🧮 Soru bazlı oku (tüm sayfa) + analiz</button>
     <div id="nga-icebox" style="font-size:12px"></div>
     <div ${ip}>Yazılanları kontrol edip Kaydet'e siz basın.</div>
     <ul id="nga-durum" style="padding-left:16px;margin:6px 0"></ul>
     <div class="nga-bas"><button class="nga-ac" data-b="diger">+</button> <span style="font-size:12px">Ayarlar</span></div><div data-bolum="diger" hidden style="font-size:12px">
     <div><label><input type="checkbox" id="nga-oto" ${otoListele ? 'checked' : ''}> Seçimden sonra otomatik Listele</label></div>
     <div><label><input type="checkbox" id="nga-oturum" checked> e-Okul oturumunu açık tut</label> <small id="nga-oturum-d" style="color:#555"></small></div>
     <button id="nga-tani">Tanı raporu</button></div>`;
    $('nga-eksi').onclick = () => { sinav = Math.max(1, sinav - 1); $('nga-sinav').textContent = sinav; };
    $('nga-arti').onclick = () => { sinav = Math.min(TURMAX[tur], sinav + 1); $('nga-sinav').textContent = sinav; };
    $('nga-tur').onclick = () => { tur = TURLAR[(TURLAR.indexOf(tur) + 1) % TURLAR.length]; sinav = Math.min(sinav, TURMAX[tur]); $('nga-tur').textContent = TURAD[tur]; $('nga-sinav').textContent = sinav; };
    $('nga-alan').onclick = () => { alan = alan === 'Y' ? 'D' : alan === 'D' ? 'K' : 'Y'; $('nga-alan').textContent = alan; if (depo) depo.set({ ngaAlan: alan }); };
    $('nga-yaz').onclick = puanlariYaz;
    tamponCiz(); iceCiz(); if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.ng_ses_tampon) tamponCiz(); if (a === 'local' && c.ng_ice_aktar) iceCiz(); });
    if ($('nga-soru')) $('nga-soru').onclick = () => { if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) chrome.runtime.sendMessage({ tip: 'sekme-ac', hedef: 'soru' }); };
    $('nga-ice').onclick = () => { if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) chrome.runtime.sendMessage({ tip: 'sekme-ac', hedef: 'ice' }); };
    if (window.NGASes && window.NGASes.bagla) window.NGASes.bagla($('nga-ses'), $('nga-ses-d'), () => ({ tur, sinav, alan })); // 1.6.17 sesli not girişi
    p.querySelectorAll('.nga-ac').forEach(b => { const bl = p.querySelector('[data-bolum="' + b.dataset.b + '"]');
      b.onclick = () => { const kapa = !bl.hidden; bl.hidden = kapa; b.textContent = kapa ? '+' : '−'; if (depo) depo.set({ ['ngaKapali_' + b.dataset.b]: kapa }); };
      if (depo) depo.get('ngaKapali_' + b.dataset.b, v => { const k = v['ngaKapali_' + b.dataset.b]; if (k === false) { bl.hidden = false; b.textContent = '−'; } }); });
    $('nga-tarama').onclick = () => { if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) chrome.runtime.sendMessage({ tip: 'sekme-ac', hedef: 'notoku' }); };
    if (depo) depo.get('ng_oturum_acik', v => { $('nga-oturum').checked = v.ng_oturum_acik !== false; });
    const otDurum = () => { if (!depo || !$('nga-oturum-d')) return; depo.get(['ng_oturum_durum', 'ng_oturum_acik'], v => { const d = v.ng_oturum_durum || {}, el = $('nga-oturum-d'); if (!el) return;
      if (v.ng_oturum_acik === false) { el.textContent = ''; return; } const sa = d.nabiz ? new Date(d.nabiz).toTimeString().slice(0, 5) : '';
      el.textContent = d.dustu ? '● düştü' : sa ? '● açık (' + sa + ')' : '● açık'; el.style.color = d.dustu ? '#c00' : '#080'; }); };
    otDurum(); if (depo && chrome.storage.onChanged && !window.__ngaOtDin) { window.__ngaOtDin = true; chrome.storage.onChanged.addListener(ch => { if (ch.ng_oturum_durum || ch.ng_oturum_acik) otDurum(); }); }
    $('nga-oturum').onchange = e => { if (depo) depo.set({ ng_oturum_acik: e.target.checked }); if (e.target.checked && window.__NGOturum) window.__NGOturum.nabiz(); };
    $('nga-oto').onchange = e => { otoListele = e.target.checked; if (depo) depo.set({ ngaOtoListele: otoListele }); };
    $('nga-tani').onclick = async () => { let t = A.taniRaporu(document);
      try { const d = A.dersSelect(document), gs = gruplar(); t += '\n-- PANEL (1.6.24): ders=' + ($('nga-ders') ? $('nga-ders').value : '?') + ' sinif=' + ($('nga-sinif') ? $('nga-sinif').value : '?') + '/' + ($('nga-sube') ? $('nga-sube').value : '?') + ' sinav=' + sinav + ' tur=' + tur + ' alan=' + alan + ' aktif=' + aktif;
        gs.forEach((g, i) => { const r = tablo.find(x => anahtar(x) === g.k) || {}, e = d && g.ders ? A.dersEsle(d, g.ders) : null; t += '\n  grup ' + (i + 1) + ': sinif="' + g.sinif + '" ders="' + g.ders + '" seviye=' + (r.seviye || '-') + ' sinavNo=' + (r.sinavNo || '-') + ' n=' + g.n + ' kesin=' + g.kesin + ' eşleşme=' + (e ? (e.op ? e.op.textContent.trim() + ' %' + Math.round((e.puan || 0) * 100) : 'YOK adaylar=' + (e.adaylar || []).join('/')) : '-'); });
        if (!gs.length) t += '\n  tablo boş (tarama okuması panele gelmedi)'; } catch (e) { t += '\n-- PANEL hata: ' + e.message; }
      try { await navigator.clipboard.writeText(t); durum('tani', 'tamam', 'Tanı raporu panoya kopyalandı (ad/TC yok). Bana yapıştırıp gönderin.'); }
      catch (e) { const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'width:100%;height:80px'; p.appendChild(ta); ta.select(); durum('tani', 'tamam', 'Rapor aşağıda seçili; Ctrl+C ile kopyalayın.'); } };
    $('nga-kapat').onclick = () => { cekAcik = false; cekCiz(); cekYaz(); }; /* 1.6.22: × paneli kapatmaz, sağ kenara kaydırır; '⠿ Not' diliyle geri açılır */
    $('nga-git').onclick = async () => {
      if (proAcik()) { $('nga-pro').style.display = 'block'; durum('cakisma', 'hata', 'Pro paneli açık; önce onu kapatın.'); return; }
      await tabloYukleP(); // 1.6.15 grup tablosu yüklenmeden eski/varsayılan sınıfla başlanmasın
      const g = gruplar()[aktif];
      if (g && g.sinif) { if (!g.kesin && !(sinifAyir(g.sinif) && g.ders)) { durum('grup', 'hata', 'Grup ' + (aktif + 1) + ' sınıf/ders sarı: tabloda grup başlığını kâğıtla karşılaştırıp düzeltin ya da ✓ ile onaylayın.'); return; }
        const a = sinifAyir(g.sinif) || { sinif: g.sinif, sube: '' }; calis({ sinif: a.sinif, sube: a.sube, ders: g.ders || $('nga-ders').value.trim(), sinav, tur, grup: aktif }); return; }
      if (!$('nga-sinif').value.trim() || !$('nga-sube').value.trim()) { durum('grup', 'hata', 'Sınıf/şube yok: kâğıtları okutun ya da 3. adımda yazın.'); return; }
      calis({ sinif: $('nga-sinif').value.trim(), sube: $('nga-sube').value.trim(), ders: $('nga-ders').value.trim(), sinav, tur });
    };
    $('nga-sonraki').onclick = () => { const gs = gruplar(); if (aktif + 1 >= gs.length) return; aktif++; grupYaz(); tabloCiz(); $('nga-sonraki').hidden = true; delete durumlar.yaz; $('nga-git').click(); };
    // e-Okul'daki ders listesinden seçilen ders aktif grubun dersi olur (asistan emin olamadığında)
    $('nga-ders').onchange = e => { const g = gruplar()[aktif], v = e.target.value; if (!g || !v) return; tablo.forEach(r => { if (anahtar(r) === g.k) { r.ders = v; r.basKesin = true; } }); tabloKaydet(); };
    $('nga-pro').style.display = proAcik() ? 'block' : 'none';
    sonDoldur(); tabloYukle();
    $('nga-satir-arti').onclick = () => { tablo.push({ no: '', not: '', kesin: false }); tabloKaydet(); };
    $('nga-tablo').addEventListener('paste', e => { const t = (e.clipboardData || window.clipboardData).getData('text'); if (!t || !/[\t\n]/.test(t)) return; e.preventDefault();
      // Sütunlar: Okul No, (Sınıf: 10-M / 10/M / 10 M), (Ad), Not (son sayı ya da G). Sınıf sütunu varsa satır o gruba girer.
      t.split(/\r?\n/).map(l => l.split('\t').map(x => x.trim())).forEach(c => { const ni = c.findIndex(x => /^\d{1,6}$/.test(x)); if (ni < 0) return;
        const si = c.findIndex((x, i) => i !== ni && /^\d{1,2}\s*[-/. ]?\s*[A-Za-zÇĞİÖŞÜçğıöşü]$/.test(x)), ay = si >= 0 ? sinifAyir(c[si]) : null;
        let pi = -1; c.forEach((x, i) => { if (i !== ni && i !== si && /^(\d{1,3}|G)$/i.test(x)) pi = i; });
        tablo.push({ no: c[ni], not: pi >= 0 ? c[pi].toUpperCase() : '', kesin: true, sinif: ay ? ay.sinif + '-' + ay.sube : '', basKesin: !!ay }); }); sinifDoldur(); tabloKaydet(); });
  }
  // 1.6.9 Panel tablosu (Okul No | Not): ng_not_tablosu; yoksa son okumadan kurulur. Düzeltilen/✓ satır kesin; tekrarlanan no ya da geçersiz not sarı.
  let tablo = [], aktif = 0;
  // 1.6.11 Gruplar: karışık kâğıtlar sınıf+ders'e göre gruplanır; her grup sırayla işlenir
  const anahtar = r => (r.sinif || '') + '|' + (r.ders || '');
  // 1.6.28 Listele sonrası grubun Okul No'ları o şubenin e-Okul listesine yeniden oturtulur: listede olmayan okuma, boşta kalan tek yakın numaraya (1 rakam farkı) taşınır, sarı.
  // 1.6.28 Sesli not tamponu: şube başına özet + "Sesli notları şube şube gir" (aynı otomatik akış; sesli gruplarda söylenmeyene G yazılmaz)
  const sesc = x => String(x == null ? '' : x).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function tamponCiz() { const k = $('nga-tampon'); if (!k || !depo || !window.NGASes) return; depo.get('ng_ses_tampon', v => { const t = (v.ng_ses_tampon && v.ng_ses_tampon.satirlar) || [];
    if (!t.length) { k.innerHTML = ''; return; } const g = window.NGASes.tamponGrupla(t);
    k.innerHTML = '<div style="border:2px solid #000;padding:3px;margin:3px 0;background:#fff8d6"><b>Sesli not tamponu: ' + t.length + ' not</b><br>' + Object.keys(g).map(s => '<b>' + sesc(s) + '</b>: ' + g[s].map(r => sesc((r.no || r.ad) + '→' + r.puan) + ' <a href="#" data-sil="' + sesc(r.id) + '" title="Sil" style="color:#b00020">✗</a>').join(', ')).join('<br>') + '<br><button id="nga-tampon-gir" style="background:#0b5;color:#000;border:2px solid #000;font-weight:bold;width:100%;padding:4px;margin-top:3px">Sesli notları şube şube gir ▶</button><span style="font-size:11px">Düzenleme: Sesli not penceresindeki listede.</span></div>';
    k.querySelectorAll('a[data-sil]').forEach(a => { a.onclick = e => { e.preventDefault(); depo.get('ng_ses_tampon', w => { const tt = ((w.ng_ses_tampon && w.ng_ses_tampon.satirlar) || []).filter(r => r.id !== a.dataset.sil); depo.set({ ng_ses_tampon: { z: Date.now(), satirlar: tt } }); }); }; });
    $('nga-tampon-gir').onclick = tamponGir; }); }
  function tamponGir() { const ders = $('nga-ders') ? $('nga-ders').value.trim() : ''; if (!ders) { durum('ses', 'hata', 'Önce 3. adımda dersi seçin; sesli notlar o derse yazılır.'); return; }
    depo.get(['ng_ses_tampon', 'ng_sinif_listeleri', 'ng_not_tablosu', 'tarama_taslak'], v => { const t = (v.ng_ses_tampon && v.ng_ses_tampon.satirlar) || [], L = v.ng_sinif_listeleri || {}, al = [], kal = [];
      t.forEach(r => { const a = sinifAyir(r.sinif); if (!a || !window.NGASes.gecerli(r.puan)) { kal.push(r); return; } const sn = a.sinif + '-' + a.sube; let no = r.no;
        if (!no && r.ad) { const lk = Object.keys(L).find(x => sk(x) === sk(sn)), b = lk ? window.NGASes.bul(L[lk].ogrenciler || [], { ad: r.ad }) : null; if (b && b.o) no = b.o.no; }
        if (!no) { kal.push(r); return; } al.push({ no: String(no), not: String(r.puan), kesin: true, sinif: sn, ders, basKesin: true, ses: true }); });
      if (!al.length) { durum('ses', 'hata', 'Tamponda şubesi ve numarası belli not yok (' + kal.length + ' satır şube/numara/puan eksik; ses penceresinde düzeltin).'); return; }
      aktar(al, kal, v, { ng_ses_tampon: { z: Date.now(), satirlar: kal } }, 'sesli not'); }); }
  // 1.6.28 ortak: hazır satırları (şube+no+not+ders) Not tablosuna alır ve şube şube otomatik girişi başlatır
  function aktar(al, kal, v, ek, kaynak, degistir) {
      const tk = v.tarama_taslak, nt = v.ng_not_tablosu, kosu = (tk && tk.kosu) || 0; let eski = !degistir && nt && nt.satirlar && nt.kosu === kosu ? nt.satirlar : []; // dosya: tablo dosyadan yeniden kurulur; ses: eskiye eklenir
      eski = eski.filter(r => !al.some(x => sk(x.sinif) === sk(r.sinif || '') && x.no === String(r.no)));
      kosuSon = kosu; tablo = eski.concat(al); const sira = [...new Set(tablo.map(r => r.sinif || ''))]; tablo = sira.flatMap(s => tablo.filter(r => (r.sinif || '') === s));
      depo.set(Object.assign({ ng_not_tablosu: { zaman: Date.now(), kosu, satirlar: tablo.map(satirK) }, ngaBitenGruplar: { kosu, k: [] } }, ek), () => {
        durum('ses', 'tamam', al.length + ' ' + kaynak + ' ' + [...new Set(al.map(r => r.sinif))].join(', ') + ' gruplarına alındı' + (kal.length ? '; ' + kal.length + ' eksik satır bekletiliyor' : '') + '. Şube şube giriş başlıyor.');
        aktif = 0; grupYaz(); tabloCiz(); $('nga-git').click(); }); }
  function iceCiz() { const k = $('nga-icebox'); if (!k || !depo) return; depo.get('ng_ice_aktar', v => { const x = v.ng_ice_aktar; if (!x || !x.satirlar || !x.satirlar.length) { k.innerHTML = ''; return; }
    const g = {}; x.satirlar.forEach(r => { g[r.sinif] = (g[r.sinif] || 0) + 1; });
    k.innerHTML = '<div style="border:2px solid #000;padding:3px;margin:3px 0;background:#e8f0ff"><b>Dosyadan: ' + x.satirlar.length + ' not</b> (' + sesc(Object.keys(g).map(s => s + ': ' + g[s]).join(', ')) + ') · ' + sesc(TURAD[x.tur] || x.tur) + ' ' + sesc(x.sinav) + (x.g ? ' · eksiklere G' : ' · G yazılmaz') + '<br><button id="nga-ice-gir" style="background:#0b5;color:#000;border:2px solid #000;font-weight:bold;width:100%;padding:4px;margin-top:3px">Dosyadaki notları şube şube gir ▶</button> <a href="#" id="nga-ice-sil" style="color:#b00020">Vazgeç (sil)</a></div>';
    $('nga-ice-sil').onclick = e => { e.preventDefault(); depo.remove('ng_ice_aktar'); };
    $('nga-ice-gir').onclick = () => depo.get(['ng_ice_aktar', 'ng_not_tablosu', 'tarama_taslak'], w => { const x = w.ng_ice_aktar; if (!x) return; const pd = $('nga-ders') ? $('nga-ders').value.trim() : '', al = [], kal = [];
      x.satirlar.forEach(r => { const a = sinifAyir(r.sinif), ders = r.ders || x.ders || pd; if (!a || !r.no || !ders || !(r.puan === 'G' || /^\d{1,3}$/.test(r.puan))) { kal.push(r); return; } al.push({ no: String(r.no), not: String(r.puan), kesin: true, sinif: a.sinif + '-' + a.sube, ders, basKesin: true, ses: !x.g }); });
      if (!al.length) { durum('ses', 'hata', 'Dosyadaki satırlarda ders yok: 3. adımda dersi seçin ya da içe aktarma sayfasında "Ders yoksa" alanını doldurun.'); return; }
      if (TURAD[x.tur]) { tur = x.tur; sinav = Math.min(x.sinav || 1, TURMAX[tur]); if ($('nga-tur')) { $('nga-tur').textContent = TURAD[tur]; $('nga-sinav').textContent = sinav; } }
      aktar(al, kal, w, kal.length ? { ng_ice_aktar: Object.assign({}, x, { satirlar: kal }) } : {}, 'dosya notu', true); if (!kal.length) depo.remove('ng_ice_aktar'); }); }); }
  function grupEsle(sat, tn) { const L = new Set(tn), kul = new Set(sat.map(r => String(r.no)).filter(n => L.has(n))); let tam = kul.size, degisen = 0;
    sat.forEach(r => { const n = String(r.no || ''); if (!n || L.has(n)) return; const bos = tn.filter(x => !kul.has(x)), ad = A.noAdaylar(n, bos, 1.0, 2), net = ad.length === 1 || (ad.length === 2 && ad[1][1] - ad[0][1] >= 0.4);
      if (ad.length && net) { r.okunan = r.okunan || n; r.no = ad[0][0]; r.kesin = false; kul.add(ad[0][0]); degisen++; } });
    return { tam, degisen, toplam: sat.filter(r => r.no).length }; }
  function gruplar() { const m = []; tablo.forEach(r => { const k = anahtar(r); let g = m.find(x => x.k === k); if (!g) { g = { k, sinif: r.sinif || '', ders: r.ders || '', kesin: true, n: 0 }; m.push(g); } g.n++; if (!r.basKesin || !r.sinif || !/^\d{1,2}-[A-ZÇĞİÖŞÜ]$/i.test(r.sinif) || !r.ders) g.kesin = false; }); return m; }
  function grupYaz() { if (depo) depo.set({ ngaAktifGrup: aktif }); }
  if (depo) depo.get('ngaAktifGrup', v => { if (typeof v.ngaAktifGrup === 'number') aktif = v.ngaAktifGrup; });
  const notOk = v => { v = String(v).trim().toUpperCase(); return v === 'G' || (/^\d{1,3}$/.test(v) && +v <= 100); };
  let kosuSon = 0;
  function tabloKaydet() { if (depo) depo.set({ ng_not_tablosu: { zaman: Date.now(), kosu: kosuSon, satirlar: tablo.map(satirK) } }); tabloCiz(); }
  const satirK = r => ({ no: r.no, not: r.not, kesin: !!r.kesin, eksik: !!r.eksik, sinif: r.sinif || '', ders: r.ders || '', alan: r.alan || '', basKesin: !!r.basKesin, seviye: r.seviye || '', sinavNo: r.sinavNo || 0, okunan: r.okunan || '', ses: !!r.ses });
  const tabloYukleP = () => new Promise(r => { if (!depo) return r(); depo.get('ngaAktifGrup', v => { if (typeof v.ngaAktifGrup === 'number') aktif = v.ngaAktifGrup; tabloYukle(r); }); });
  function tabloYukle(bitti) { if (!depo) return bitti && bitti(); depo.get(['ng_not_tablosu', 'tarama_taslak'], v => { const nt = v.ng_not_tablosu, tk = v.tarama_taslak;
    // 1.6.25: panel düzeltmeleri yalnız aynı okumaya (kosu) aitse kullanılır; yeni okuma her zaman eskisinin yerine geçer
    kosuSon = tk && tk.kosu || 0;
    if (nt && nt.satirlar && (tk && tk.kosu ? nt.kosu === tk.kosu : (!tk || !tk.zaman || nt.zaman >= tk.zaman - 10000))) tablo = nt.satirlar.map(r => Object.assign({}, r, String(r.not || '').trim() === '' ? { not: 'G', kesin: false } : {}));
    else if (tk && tk.sonuc) tablo = tk.sonuc.filter(r => r.no && r.no.deger).map(r => { const pu = toplam(r); const bs = r.bas || {}; return { no: r.no.deger, not: pu === '' ? 'G' : pu, kesin: r.sari === false && pu !== '' && notOk(pu), sinif: bs.sinif || '', ders: bs.ders || '', alan: bs.alan || '', basKesin: !!bs.kesin, seviye: bs.seviye || '', sinavNo: bs.sinavNo || 0 }; });
    if (sinifDoldur()) tabloKaydet(); else tabloCiz(); bitti && bitti(); }); }
  if (depo && chrome.storage.onChanged) chrome.storage.onChanged.addListener((d, a) => { if (a === 'local' && (d.ng_not_tablosu || d.tarama_taslak) && $('nga-tablo') && !(d.ng_not_tablosu && d.ng_not_tablosu.newValue && JSON.stringify(d.ng_not_tablosu.newValue.satirlar) === JSON.stringify(tablo.map(satirK)))) tabloYukle(); });
  if (depo && chrome.storage.onChanged) chrome.storage.onChanged.addListener((d, a) => { if (a === 'local' && d.ng_sinif_listeleri) { listeler = d.ng_sinif_listeleri.newValue || {}; if ($('nga-tablo')) { if (sinifDoldur()) tabloKaydet(); else tabloCiz(); } } });
  function tabloCiz() { const k = $('nga-tablo'); if (!k) return; const nolar = tablo.map(r => r.no), gs = gruplar(); if (aktif >= gs.length) aktif = Math.max(0, gs.length - 1);
    k.innerHTML = '<table style="border-collapse:collapse;width:100%"><tr><th>Okul No</th><th>Not</th><th></th></tr></table>'; const tb = k.firstChild;
    let sari = 0; const cok = gs.length > 1 || (gs[0] && gs[0].sinif);
    gs.forEach((g, gi) => {
      if (cok) { const tr = tb.insertRow(), c = tr.insertCell(); c.colSpan = 3; tr.style.background = g.kesin ? '#000' : '#ffeb3b'; tr.style.color = g.kesin ? '#fff' : '#000'; c.style.cssText = 'padding:3px;font-weight:bold;border-top:3px solid #000';
        const et = document.createElement('span'); et.textContent = (gi === aktif ? '▶ ' : '') + 'Grup ' + (gi + 1) + ' (' + g.n + ') '; c.appendChild(et);
        [['sinif', 4, 'Sınıf (ör. 10-M)'], ['ders', 12, 'Ders']].forEach(([a, sz, t]) => { const x = document.createElement('input'); x.value = g[a]; x.size = sz; x.title = t; x.placeholder = t;
          x.onchange = () => { const v = a === 'sinif' ? x.value.trim().toUpperCase().replace(/\s*[/.]\s*|\s+/g, '-') : x.value.trim(); tablo.forEach(r => { if (anahtar(r) === g.k) { r[a] = v; r.basKesin = true; } }); tabloKaydet(); }; c.appendChild(x); });
        if (!g.kesin && /^\d{1,2}-[A-ZÇĞİÖŞÜ]$/i.test(g.sinif) && g.ders) { const o = document.createElement('button'); o.textContent = '✓'; o.title = 'Sınıf ve dersi kâğıtla karşılaştırdım'; o.onclick = () => { tablo.forEach(r => { if (anahtar(r) === g.k) r.basKesin = true; }); tabloKaydet(); }; c.appendChild(o); }
        const sec = document.createElement('button'); sec.textContent = '▶'; sec.title = 'Bu grubu işle'; sec.onclick = () => { aktif = gi; grupYaz(); tabloCiz(); }; c.appendChild(sec);
        const m = document.createElement('button'); m.textContent = '−'; m.title = 'Grubu sil'; m.onclick = () => { tablo = tablo.filter(r => anahtar(r) !== g.k); tabloKaydet(); }; c.appendChild(m);
        const ar = document.createElement('button'); ar.textContent = '+'; ar.title = 'Bu gruba satır ekle'; ar.onclick = () => { tablo.push({ no: '', not: '', kesin: false, sinif: g.sinif, ders: g.ders, basKesin: true }); tabloKaydet(); }; c.appendChild(ar); }
      tablo.forEach((r, i) => { if (anahtar(r) !== g.k) return; const cift = nolar.indexOf(r.no) !== nolar.lastIndexOf(r.no);
        const lb = r.no ? listedenSinif(r.no) : { durum: 'yok' }, cel = !!(r.sinif && lb.durum === 'tek' && sk(lb.sinif) !== sk(r.sinif)); // kâğıttaki şube ile listedeki şube farklı
        const sr = !r.kesin || cift || !r.no || !notOk(r.not) || cel; if (sr) sari++;
        const tr = tb.insertRow(); tr.style.background = sr ? '#ffeb3b' : '#c8f7c5';
        ['no', 'not'].forEach(a => { const x = document.createElement('input'); x.value = r[a]; x.size = a === 'no' ? 6 : 3; x.onchange = () => { r[a] = x.value.trim().toUpperCase(); r.kesin = true; tabloKaydet(); }; tr.insertCell().appendChild(x); });
        const ad = r.no ? listeAd(r.no) : ''; if (ad) { const sp = document.createElement('small'); sp.textContent = ' ' + maskAd(ad); sp.title = 'e-Okul listesindeki ad (baş harfler): kâğıttaki adla karşılaştırın'; tr.cells[0].appendChild(sp); }
        const c = tr.insertCell();
        if (cel) { const o = document.createElement('button'); o.textContent = '→' + lb.sinif; o.title = 'Numara e-Okul listesinde ' + lb.sinif + ' şubesinde; satırı oraya al'; o.onclick = () => { r.sinif = lb.sinif; r.basKesin = false; tabloKaydet(); }; c.appendChild(o); }
        { const gn = r.sinif ? listeNolari(r.sinif) : null, kume = gn || (Object.keys(listeler).length ? tumNolar() : null); // numara listede yoksa en yakın birkaç numara önerilir
          if (kume && r.no && !kume.includes(r.no)) A.noAdaylar(r.no, kume.filter(n => !nolar.includes(n)), 1.5, 3).forEach(([n]) => { const o = document.createElement('button'); o.textContent = n + '?'; o.title = 'Listede yakın numara: ' + (maskAd(listeAd(n)) || n) + ' — kâğıttaki adla karşılaştırıp seçin'; o.onclick = () => { r.no = n; r.kesin = false; tabloKaydet(); }; c.appendChild(o); }); }
        if (sr && r.no && notOk(r.not) && !cift && !cel) { const o = document.createElement('button'); o.textContent = '✓'; o.title = 'Kâğıtla karşılaştırdım'; o.onclick = () => { r.kesin = true; tabloKaydet(); }; c.appendChild(o); }
        const m = document.createElement('button'); m.textContent = '−'; m.title = 'Satırı sil'; m.onclick = () => { tablo.splice(i, 1); tabloKaydet(); }; c.appendChild(m); }); });
    const oz = $('nga-ozet'); if (oz) oz.textContent = tablo.length ? tablo.length + ' satır, ' + sari + ' sarı' + (gs.length > 1 ? ', ' + gs.length + ' grup' : '') : 'Henüz okunmuş kâğıt yok.';
    const gk = $('nga-grup'), g = gs[aktif]; if (gk) gk.textContent = g && g.sinif ? 'Grup ' + (aktif + 1) + '/' + gs.length + ': ' + g.sinif + ' · ' + (g.ders || '?') + (g.kesin ? '' : ' (sarı, kontrol edin)') : '';
    if (gk) gk.style.background = g && g.sinif && !g.kesin ? '#ffeb3b' : '';
    adim3Doldur(g); }
  // 1.6.12 Grup başlığı tek kaynak: aktif grubun sınıfı (10-M -> Sınıf 10, Şube M) ve dersi 3. adıma yazılır
  const sinifAyir = s => { const m = String(s || '').trim().match(/^(\d{1,2})\s*[-/. ]?\s*([A-Za-zÇĞİÖŞÜçğıöşü]+)$/); return m ? { sinif: m[1], sube: m[2].toLocaleUpperCase('tr-TR') } : null; };
  function adim3Doldur(g) { if (!g) return; { const ra = tablo.find(r => anahtar(r) === g.k && /^[DK]$/.test(r.alan || '')); /* 1.6.17: başlıkta DİNLEME/KONUŞMA okunduysa Alan kendiliğinden */ if (ra && $('nga-alan')) { alan = ra.alan; $('nga-alan').textContent = alan; if (depo) depo.set({ ngaAlan: alan }); } }
    // 1.6.22 basılı başlıktaki "1. SINAV" -> Sınav sütunu; "11. SINIF" -> sınıf seviyesi; ders, şube el yazısı okunamasa da seçilir
    { const rs = tablo.find(r => anahtar(r) === g.k && r.sinavNo); if (rs && tur === 'sinav' && rs.sinavNo <= TURMAX[tur]) { sinav = rs.sinavNo; if ($('nga-sinav')) $('nga-sinav').textContent = sinav; } }
    if (!g.sinif) { const rv = tablo.find(r => anahtar(r) === g.k && r.seviye); if (rv && $('nga-sinif')) $('nga-sinif').value = rv.seviye; if (g.ders) dersSecenek(g.ders); return; } const a = sinifAyir(g.sinif);
    if (a && $('nga-sinif')) { $('nga-sinif').value = a.sinif; $('nga-sube').value = a.sube; }
    if (g.ders) dersSecenek(g.ders); }
  // 1.6.5: tarama ekranındaki son okuma (tarama_taslak) Okul No ile eşleştirilip seçili sütuna yazılır. Kaydet'e siz basarsınız.
  const toplam = r => { const d = (r.puanlar || []).map(x => String(x.deger == null ? '' : x.deger).replace(',', '.'));
    if (d.some(v => v.toUpperCase() === 'G')) return 'G'; if (!d.length || d.some(v => v === '')) return '';
    const t = d.reduce((a, v) => a + Number(v), 0); return isNaN(t) ? '' : String(Math.round(t)); };
  let yaziyor = false;
  function puanlariYaz() {
    durum('yaz', 'bekle', 'Notlar tek tek yazılıyor…');
    if (!depo) { durum('yaz', 'hata', 'Depolama yok'); return; }
    depo.get(['tarama_taslak', 'ng_not_tablosu'], async v => { const tk = v.tarama_taslak, nt = v.ng_not_tablosu; if (yaziyor) return; yaziyor = true; try {
      // 1.6.8: tarama ekranındaki "Not tablosu"ndan verilen satırlar (kontrol edilmiş) önceliklidir
      if (nt && nt.satirlar && nt.satirlar.length && (tk && tk.kosu ? nt.kosu === tk.kosu : (!tk || !tk.zaman || nt.zaman >= tk.zaman - 10000))) { // 1.6.25 yalnız aynı okumanın düzeltmeleri
        const gs = gruplar(), g = gs[aktif];
        { const T0 = A.ogrenciTablosu(document); if (T0 && g && g.sinif) { const tn = T0.satirlar.map(tr => tr.cells[0].textContent.replace(/\D/g, '')).filter(Boolean), r = grupEsle(nt.satirlar.filter(x => anahtar(x) === g.k && !x.eksik), tn);
          if (r.degisen) { tablo = nt.satirlar.map(x => Object.assign({}, x)); tabloKaydet(); durum('esle', 'bekle', g.sinif + ': ' + r.degisen + ' Okul No e-Okul listesine yakın numaraya oturtuldu (sarı, kontrol edin).'); }
          // sarı (emin olunmayan) grup: numaraların en az yarısı bu listede değilse yanlış şube olabilir — hiçbir şey yazılmaz
          if (!g.kesin && r.toplam && r.tam + r.degisen < Math.max(1, Math.ceil(r.toplam * 0.5))) { durum('yaz', 'hata', g.sinif + ' listesinde bu grubun numaralarının çoğu yok (' + (r.tam + r.degisen) + '/' + r.toplam + '): şube yanlış okunmuş olabilir, hiçbir şey yazılmadı. Grup başlığını düzeltip yeniden başlatın.'); return; } } }
        // 1.6.11 Listede olup kâğıdı okunmamış öğrenciler tabloya "G" (sarı) olarak eklenir; e-Okul'da değeri varsa dokunulmaz
        const T = A.ogrenciTablosu(document), sesGrup = nt.satirlar.filter(r => !g || anahtar(r) === g.k).every(r => r.ses); if (T && !sesGrup) { const var_ = new Set(nt.satirlar.map(r => String(r.no))), yeni = [];
          T.satirlar.forEach(tr => { const no = tr.cells[0].textContent.replace(/\D/g, ''); if (no && !var_.has(no)) yeni.push({ no, not: 'G', kesin: false, eksik: true, sinif: g ? g.sinif : '', ders: g ? g.ders : '', basKesin: true }); });
          if (yeni.length) { tablo = tablo.concat(yeni); nt.satirlar = nt.satirlar.concat(yeni); tabloKaydet(); durum('eksik', 'bekle', yeni.length + ' öğrencinin kâğıdı yok: tabloya G (sarı) eklendi, e-Okul\'da boş olanlara G yazılıyor. Kontrol edin.'); } }
        // 1.6.17 Güvenlik: sayfada seçili şube/ders grupla uyuşmuyorsa HİÇBİR ŞEY yazılmaz (eksik öğrencilere G yazılırken yanlış şube bozulmasın)
        const pk = A.sayfaSinifi(document), pd = A.sayfaDersi(document);
        if (g && g.sinif && pk && sk(pk) !== sk(g.sinif)) { durum('yaz', 'hata', 'Sayfada ' + pk + ' seçili ama grup ' + g.sinif + ': hiçbir şey yazılmadı. Şubeyi ya da grubu düzeltip yeniden yazın.'); return; }
        if (g && g.ders && pd && A.dersPuan(g.ders, pd) < 0.6) { durum('yaz', 'hata', 'Sayfada "' + pd + '" seçili ama grup dersi "' + g.ders + '": hiçbir şey yazılmadı. Dersi düzeltin.'); return; }
        const sat = g && g.sinif ? nt.satirlar.filter(r => anahtar(r) === g.k) : nt.satirlar;
        const s = await A.puanYazYavas(document, tur, sinav, sat.map(r => ({ no: r.no, puan: r.not, kesin: r.kesin === true, eksik: !!r.eksik })), { alan });
        if (!s.ok) { durum('yaz', 'hata', s.neden); return; }
        durum('yaz', s.yazilan ? 'tamam' : 'hata', 'Not tablosundan ' + s.yazilan + '/' + s.satir + ' satıra yazıldı' + (tur === 'sinav' && alan !== 'Y' ? ' (' + (alan === 'D' ? 'Dinleme' : 'Konuşma') + ' kutusu)' : '') + (s.ustune ? ', ' + s.ustune + ' kutuda eski değerin üzerine yazıldı' : '') + ', ' + s.sari + ' sarı' + (s.kutusuz ? ', ' + s.kutusuz + ' satırda kutu yok' : '') + (s.eslesmeyen.length ? ', listede olmayan ' + s.eslesmeyen.length : '') + '. Kaydet\'e siz basın.' + (g && g.sinif ? ' (Grup ' + (aktif + 1) + '/' + gs.length + ')' : ''));
        if ($('nga-sonraki')) $('nga-sonraki').hidden = !(g && aktif + 1 < gs.length); if (g && aktif + 1 < gs.length) { durum('sonraki', 'bekle', (g.sinif || '') + ' yazıldı. Güvenlik Kodu\'nu yazıp Kaydet\'e siz basın; kayıt başarılı olunca ' + (gs[aktif + 1].sinif || 'sonraki grup') + ' kendiliğinden başlar (sınıf+ders seçimi, Listele, eşleştirme, yazma).'); kaydetBekle(aktif); } else if (g && g.sinif) { durum('sonraki', 'bekle', 'Son grup yazıldı: Güvenlik Kodu\'nu yazıp Kaydet\'e siz basın.'); kaydetBekle(aktif); } else delete durumlar.sonraki; ilerleme(); return; }
      if (!tk || !tk.sonuc || !tk.sonuc.length) { durum('yaz', 'hata', 'Okunmuş kâğıt yok. Önce "Kâğıtları oku" ile kâğıtları okuyun.'); return; }
      const sn = tk.sonuc.filter(r => r.no && r.no.deger).map(r => { const pu = toplam(r); return { no: r.no.deger, puan: pu, kesin: r.sari === false && pu !== '' && (pu === 'G' || +pu <= 100) }; });
      { const T = A.ogrenciTablosu(document), var_ = new Set(sn.map(r => String(r.no))); let ek = 0; // 1.6.27 kâğıdı okunmayan öğrenciye G (e-Okul'da değeri varsa dokunulmaz)
        if (T) T.satirlar.forEach(tr => { const no = tr.cells[0].textContent.replace(/\D/g, ''); if (no && !var_.has(no)) { sn.push({ no, puan: 'G', kesin: false, eksik: true }); ek++; } });
        if (ek) durum('eksik', 'bekle', ek + ' öğrencinin kâğıdı okunmadı: e-Okul\'da boş olanlara G (girmedi) yazılıyor, sarı. Kontrol edin.'); }
      const s = await A.puanYazYavas(document, tur, sinav, sn, { alan });
      if (!s.ok) { durum('yaz', 'hata', s.neden); return; }
      durum('yaz', s.yazilan ? 'tamam' : 'hata', s.yazilan + '/' + s.satir + ' satıra yazıldı, ' + s.sari + ' sarı satır kontrol bekliyor' + (s.kutusuz ? ', ' + s.kutusuz + ' satırda kutu yok (sütun işaretli mi?)' : '') + (s.eslesmeyen.length ? ', listede olmayan ' + s.eslesmeyen.length + ' okuma' : '') + '. Kaydet\'e siz basın.'); } finally { yaziyor = false; } });
  }
  // 1.6.6: Güvenlik Kodu'nu asistan OKUMAZ/YAZMAZ. Siz 4 rakamı yazınca (sütun kutusu işaretliyse) ~400 ms sonra Listele'ye basılır;
  // liste gelince okunmuş kâğıt varsa puanlar yazılır. Kaydet'e asla basılmaz.
  const OTO = 'ngaOtoYaz';
  // 1.6.15 Güvenlik Kodu yalnız Kaydet içindir; asistan kod kutusuna hiç dokunmaz/bakmaz. Listele'ye seçimden sonra bir kez basılır.
  const listeleDugmesi = () => document.getElementById('btnListele') || [...document.querySelectorAll('input[type=submit],input[type=button],button,a')].find(b => A.norm(b.value || b.textContent) === 'listele');
  function listeBekleYaz() { let i = 0; const t = setInterval(() => { const T = A.ogrenciTablosu(document);
      if (T && T.satirlar.length) { clearInterval(t); A.adimLog(document, 'liste:tamam ' + T.satirlar.length + ' satır; yazma başlıyor'); const f = JSON.parse(sessionStorage.getItem(OTO) || 'null'); sessionStorage.removeItem(OTO); if (!f) return;
        tur = f.tur; sinav = f.sinav; if ($('nga-tur')) { $('nga-tur').textContent = TURAD[tur]; $('nga-sinav').textContent = sinav; }
        if (depo) depo.get(['tarama_taslak', 'ng_not_tablosu'], v => { if ((v.tarama_taslak && v.tarama_taslak.sonuc && v.tarama_taslak.sonuc.length) || (v.ng_not_tablosu && v.ng_not_tablosu.satirlar && v.ng_not_tablosu.satirlar.length)) puanlariYaz(); else durum('yaz', 'bekle', 'Liste geldi; okunmuş kâğıt yok.'); }); }
      else if (++i > 1200) { clearInterval(t); } }, 500); }
  let listeleBasildi = false;
  const otoListeleBas = () => setTimeout(() => { if (listeleBasildi || !otoListele || A.ogrenciTablosu(document)) return;
      const k = A.kolonKutusu(document, tur, sinav), b = listeleDugmesi();
      if (!k || !k.checked) { durum('listele', 'hata', A.kolonAdi(tur, sinav) + ' kutusu işaretli değil; Listele yapılmadı.'); return; }
      if (!b) { durum('listele', 'hata', 'Listele düğmesi bulunamadı'); return; }
      listeleBasildi = true; sessionStorage.setItem(OTO, JSON.stringify({ tur, sinav }));
      A.adimLog(document, 'listele:tamam Listele basıldı (bir kez)'); durum('listele', 'tamam', 'Listele basıldı; liste bekleniyor'); b.click(); listeBekleYaz(); }, 800);
  if (sessionStorage.getItem(OTO)) setTimeout(listeBekleYaz, 300); // sayfa yeniden yüklendiyse
  // 1.6.9: Sınıf Listesi tablosu görülünce Okul No + Ad yalnız bu bilgisayarda saklanır (tarama ekranında ad/no doğrulaması için)
  setInterval(() => { if (!depo || !A.IDARE_SAYFA.test(location.href)) return; const T = A.ogrenciTablosu(document); if (!T || !T.satirlar.length) return;
    const ai = T.bas.findIndex(b => b.startsWith('adisoyadi')); const og = T.satirlar.map(tr => ({ no: tr.cells[0].textContent.replace(/\D/g, ''), ad: ai >= 0 && tr.cells[ai] ? tr.cells[ai].textContent.trim() : '' })).filter(o => o.no);
    const kb = A.sayfaSinifi(document), j = (kb || '') + JSON.stringify(og); if (j === window.__ngaSinifSon) return; window.__ngaSinifSon = j;
    if (!kb) { depo.set({ ng_sinif_listesi: { zaman: Date.now(), ogrenciler: og } }); return; }
    // 1.6.17 önceki sürüm her listede öncekini eziyordu; artık şube başına saklanır (aynı şubenin farklı ders listeleri birleşir), tarama için birleşik liste de güncellenir
    depo.get('ng_sinif_listeleri', v => { const L = v.ng_sinif_listeleri || {}, eski = Object.keys(L).find(x => sk(x) === sk(kb)), harita = new Map(((eski && L[eski].ogrenciler) || []).map(o => [o.no, o]));
      og.forEach(o => harita.set(o.no, o)); if (eski) delete L[eski]; L[kb] = { zaman: Date.now(), ogrenciler: [...harita.values()] };
      const gor = new Set(), bir = []; Object.keys(L).forEach(k => L[k].ogrenciler.forEach(o => { if (!gor.has(o.no)) { gor.add(o.no); bir.push({ no: o.no, ad: o.ad, sinif: k }); } }));
      listeler = L; depo.set({ ng_sinif_listeleri: L, ng_sinif_listesi: { zaman: Date.now(), ogrenciler: bir } }); }); }, 3000);
  // 1.6.10 Ders listesi: e-Okul'daki #ddlDersler (sınıf seçilip postback sonrası) panele aktarılır
  function dersSecenek(v) { const s = $('nga-ders'); if (!s || !v) return;
    { const d = A.dersSelect && A.dersSelect(document); if (d && d.options.length > 1) { const o = [...d.options].find(x => x.value && A.norm(x.textContent) === A.norm(v)) || (A.dersEsle(d, v) || {}).op; if (o) v = o.textContent.trim(); } } /* 1.6.22 e-Okul seçeneğine benzerlikle */
    if (![...s.options].some(o => o.value === v)) s.add(new Option(v, v)); s.value = v; }
  setInterval(() => { const s = $('nga-ders'), d = A.dersSelect && A.dersSelect(document); if (!s || !d || d.options.length < 2) return;
    const ad = [...d.options].filter(o => o.value).map(o => o.textContent.trim()), k = ad.join('|'); if (s.dataset.k === k) return;
    const eski = s.value; s.dataset.k = k; s.innerHTML = ''; s.add(new Option('Ders seçin', '')); ad.forEach(a => s.add(new Option(a, a)));
    const e = A.norm(eski), m = ad.find(a => A.norm(a) === e) || (e && ad.find(a => A.norm(a).includes(e))) || (e && ((A.dersEsle(d, eski) || {}).op || { textContent: '' }).textContent.trim()) || ''; s.value = m || (d.value ? d.options[d.selectedIndex].textContent.trim() : ''); }, 1000);
  const SON = 'ngaSon';
  const calis = async h => {
    if (depo) depo.set({ [SON]: h });
    if (typeof h.grup === 'number') { aktif = h.grup; grupYaz(); ilerleme(); }
    if (typeof h.grup === 'number') ['esle', 'eksik', 'yaz', 'listele', 'sonraki'].forEach(k => delete durumlar[k]); // önceki grubun mesajları karışmasın
    listeleBasildi = false; // 1.6.28 sonraki grup sayfa yenilenmeden (AJAX) başlarsa da Listele bir kez basılabilsin
    if (TURAD[h.tur]) tur = h.tur; if (h.sinav) sinav = Math.min(h.sinav, TURMAX[tur]); if ($('nga-tur')) { $('nga-tur').textContent = TURAD[tur]; $('nga-sinav').textContent = sinav; } // 1.6.10 sütun panelle eşit
    try { const r = await A.idareListele(document, h, durum, { kaydet: x => { sessionStorage.setItem(ANAHTAR, JSON.stringify(x)); if (depo) depo.set({ [ANAHTAR]: { h: x, zaman: Date.now() } }); } });
      if (r && r.ok && r.adim === 'listele') { sessionStorage.setItem(OTO, JSON.stringify({ tur, sinav })); A.adimLog(document, 'iş bekliyor: liste gelince yazma otomatik'); otoListeleBas(); }
      if (r && r.adim === 'ders' && r.emin === false && $('nga-ders')) { $('nga-ders').style.background = '#ffeb3b'; $('nga-ders').focus(); } }
    catch (e) { durum('hata', 'hata', 'Beklenmeyen hata: ' + (e && e.message || e)); }
  };
  function sonDoldur() { if (!depo) return; depo.get(SON, v => { const h = v[SON]; if (!h || !$('nga-sinif')) return;
    if (gruplar().some(g => g.sinif)) { sinav = h.sinav || 1; tur = TURAD[h.tur] ? h.tur : 'sinav'; $('nga-sinav').textContent = sinav; $('nga-tur').textContent = TURAD[tur]; adim3Doldur(gruplar()[aktif]); return; } // 1.6.12 grup varsa eski seçim üstüne yazmaz
    $('nga-sinif').value = h.sinif || '9'; $('nga-sube').value = h.sube || 'A'; dersSecenek(h.ders || ''); sinav = h.sinav || 1; tur = TURAD[h.tur] ? h.tur : 'sinav'; $('nga-sinav').textContent = sinav; $('nga-tur').textContent = TURAD[tur];
    if (gruplar().some(g => g.ders)) adim3Doldur(gruplar()[aktif]); /* 1.6.22 kâğıttan okunan ders/sınav, son kullanılanın önüne geçer */ }); }
  async function ac(otomatik) {
    if (p.isConnected && $('nga-git') && !otomatik) { if (!cekAcik) { cekAcik = true; cekCiz(); } $('nga-ders').focus(); return; } // açıksa yeniden çizip girdileri silme
    const onay = await onayOku();
    if (!onay) { kvkkCiz(); ekle(); return; }
    anaCiz(); ekle();
    const bek = sessionStorage.getItem(ANAHTAR), dp = await new Promise(r => depo ? depo.get(ANAHTAR, v => r(v[ANAHTAR])) : r(null));
    const h = bek ? JSON.parse(bek) : dp && Date.now() - dp.zaman < 3 * 60 * 1000 ? dp.h : null; // 1.6.8: menü adımları arasında tam sayfa yüklemesi
    if (otomatik && h && proAcik()) { A.adimLog(document, 'devam edilemedi: e-Okul Pro paneli açık'); durum('cakisma', 'hata', 'Pro paneli açık; kapatıp düğmeye yeniden basın.'); }
    if (otomatik && h && sessionStorage.getItem(OTO) && A.ogrenciTablosu(document)) { sessionStorage.removeItem(ANAHTAR); if (depo) depo.remove(ANAHTAR); A.adimLog(document, 'liste mevcut, yeniden başlatılmadı'); return; }
    if (otomatik && h && !proAcik()) { sessionStorage.removeItem(ANAHTAR); if (depo) depo.remove(ANAHTAR); calis(h); }
  }
  // 1.6.16 Çok sınıflı toplu giriş: siz Kaydet'e basıp kayıt başarılı mesajı görününce sonraki grup kendiliğinden başlar. Asistan Kaydet'e ve Güvenlik Kodu'na dokunmaz.
  const KB = 'ngaKaydetBekle', asc = s => String(s || '').toLocaleLowerCase('tr-TR').replace(/[ıi̇]/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c').replace(/\s+/g, ' ');
  // 1.6.28 Şube şube otomatik giriş: ilerleme (ör. "11-F ✓ · 11-D ▶ — 1/2 tamam"); biten gruplar bu okumaya (kosu) bağlı saklanır
  const BIT = 'ngaBitenGruplar';
  const bitenAl = () => new Promise(r => depo ? depo.get(BIT, v => { const b = v[BIT]; r(b && b.kosu === kosuSon ? b.k : []); }) : r([]));
  async function ilerleme(son) { const gs = gruplar(); if (gs.length < 2 && !son) return; const b = await bitenAl();
    const t = gs.map((g, i) => (g.sinif || '?') + (b.includes(g.k) ? ' ✓' : i === aktif ? ' ▶' : '')).join(' · ') + ' — ' + b.filter(k => gs.some(g => g.k === k)).length + '/' + gs.length + ' grup kaydedildi';
    durum('ilerleme', gs.every(g => b.includes(g.k)) ? 'tamam' : 'bekle', t); }
  async function bitir(gi) { const g = gruplar()[gi]; if (!g || !depo) return; const b = await bitenAl(); if (!b.includes(g.k)) b.push(g.k); await new Promise(r => depo.set({ [BIT]: { kosu: kosuSon, k: b } }, r)); }
  function kaydetBekle(g) { sessionStorage.setItem(KB, JSON.stringify({ grup: g, z: Date.now(), basildi: false })); A.adimLog(document, 'kaydet:bekle grup ' + (g + 1) + ' yazıldı; kullanıcının Kaydet\'e basması bekleniyor'); }
  const kaydetMi = el => { const b = el && el.closest && el.closest('input[type=submit],input[type=button],input[type=image],button,a'); return b && !b.closest('#nga-panel') && !String(b.id || '').startsWith('nga-') && /kaydet/.test(asc(b.value || b.textContent || b.title || b.id || '')); };
  document.addEventListener('click', e => { const k = JSON.parse(sessionStorage.getItem(KB) || 'null'); if (!k || !kaydetMi(e.target)) return;
    k.basildi = true; k.bz = Date.now(); sessionStorage.setItem(KB, JSON.stringify(k)); A.adimLog(document, 'kaydet:basıldı (kullanıcı)'); setTimeout(kaydetKontrol, 1500); }, true);
  const BASARI = /basar[i]?yla|kaydedildi|kayit (islemi )?(tamamland|yapild|basarili)|guncellendi|islem tamamland/, HATA = /hatal|basarisiz|hata olustu|yanlis|gecersiz|giriniz|kaydedilemedi/;
  function kaydetKontrol() { const k = JSON.parse(sessionStorage.getItem(KB) || 'null'); if (!k || !k.basildi) return;
    const panel = document.getElementById('nga-panel'), t = asc([...document.querySelectorAll('span,div,td,p,label,font,b,strong,li')].filter(e => !(panel && panel.contains(e)) && !e.closest('[id^=nga-]') && e.children.length < 3 && e.offsetParent !== null).map(e => e.textContent).join(' | '));
    const ok = BASARI.test(t), kotu = HATA.test(t);
    if (ok && !kotu) { sessionStorage.removeItem(KB); A.adimLog(document, 'kaydet:tamam kayıt başarılı; sonraki gruba geçiliyor'); durum('sonraki', 'tamam', 'Grup ' + (k.grup + 1) + ' kaydedildi; sonraki grup başlıyor…');
      setTimeout(async () => { await tabloYukleP(); aktif = k.grup; await bitir(k.grup); const gs = gruplar(); await ilerleme(true);
        if (aktif + 1 < gs.length && $('nga-sonraki')) $('nga-sonraki').click(); else { delete durumlar.sonraki; durum('ilerleme', 'tamam', 'Tüm gruplar kaydedildi (' + gs.length + '/' + gs.length + ').'); } }, 1200); return; }
    if (Date.now() - (k.bz || 0) < 20000 && !kotu) { setTimeout(kaydetKontrol, 1000); return; }
    k.basildi = false; sessionStorage.setItem(KB, JSON.stringify(k)); A.adimLog(document, 'kaydet:belirsiz ' + (kotu ? 'hata mesajı görüldü' : 'başarı mesajı görülmedi') + '; ilerlenmedi');
    durum('sonraki', 'hata', (kotu ? 'Kayıt hatası görünüyor (Güvenlik Kodu?)' : 'Kayıt başarılı mesajı görülmedi') + '; sonraki gruba geçilmedi. Düzeltip yeniden Kaydet\'e basın ya da "Sonraki grup"a elle basın.');
    if ($('nga-sonraki')) $('nga-sonraki').hidden = false; }
  setTimeout(kaydetKontrol, 1500); // Kaydet sonrası sayfa yeniden yüklendiyse
  window.__NGA = { ac };
  if (sessionStorage.getItem(ANAHTAR) || A.IDARE_SAYFA.test(location.href)) ac(true);
  else if (depo) depo.get(ANAHTAR, v => { const d = v[ANAHTAR]; if (d && Date.now() - d.zaman < 3 * 60 * 1000) ac(true); else ac(false); });
  else ac(false); // 1.6.14 çekmece her e-Okul sayfasında (ana sayfa dahil) görünür
  window.addEventListener('keydown', e => { if (e.altKey && !e.ctrlKey && !e.metaKey && e.key.toLowerCase() === 'g') ac(false); }); // AltGr (Ctrl+Alt) ile karışmasın
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) chrome.runtime.onMessage.addListener(m => { if (m && m.tip === 'nga-ac') ac(false); }); // araç çubuğu simgesi
})();
