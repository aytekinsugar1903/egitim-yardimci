// 1.6.23 Sesli not penceresi (uzantı sayfası). e-Okul sayfası "Permissions-Policy: microphone=()" gönderdiği için
// mikrofon orada hiç açılamaz; burada açılır. Tanınan metin yalnız chrome.storage.local ile panele iletilir (ağa veri göndermez).
const d = document.getElementById('d'), st = chrome.storage.local, S = window.NGASes;
// 1.6.28 Söylenen her satır hemen burada gösterilir; e-Okul paneli işlemezse (tablo/panel yok) 1,5 sn sonra tampona alınır.
let sinifSon = '';
const esc = (x) => String(x == null ? '' : x).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function isle(t) { const once = sinifSon, r = S.ayristir(t, once); if (r.sinif) sinifSon = r.sinif; document.getElementById('sb').textContent = sinifSon ? 'Şube: ' + sinifSon : '';
  const z = Date.now() + Math.random(), sat = r.satirlar.map((s) => (s.sinif || 'şube?') + ' · ' + (s.no ? s.no + ' numara' : s.ad) + ' → ' + (s.puan === 'G' ? 'G (girmedi)' : s.puan) + (S.gecerli(s.puan) ? '' : ' ✗ geçersiz'));
  document.getElementById('son').innerHTML = '<div style="background:' + (sat.length ? '#c8f7c5' : '#ffeb3b') + ';border:2px solid #000;padding:4px">Duyuldu: "' + esc(t.slice(0, 80)) + '"<br>' + (sat.length ? '✓ ' + sat.map(esc).join('<br>✓ ') : 'Anlaşılmadı. Örnek: "11 F 412 numara 85"') + (r.hatalar.length ? '<br>Atlanan: ' + esc(r.hatalar.join(' | ')) : '') + '</div>';
  st.set({ ngaSesMetin: { t, z, sinif: once } });
  setTimeout(() => st.get('ngaSesAck', (v) => { if (v.ngaSesAck && v.ngaSesAck.z === z) return; const iyi = r.satirlar.filter((s) => S.gecerli(s.puan)); if (iyi.length) S.tamponEkle(st, iyi, ciz); }), 1500); }
function ciz() { st.get(S.TAMPON, (v) => { const t = (v[S.TAMPON] && v[S.TAMPON].satirlar) || [], g = S.tamponGrupla(t), k = document.getElementById('tampon');
  k.innerHTML = t.length ? Object.keys(g).map((s) => '<div style="margin-top:4px"><b>' + esc(s) + '</b> (' + g[s].length + ')</div>' + g[s].map((r) => '<div data-id="' + esc(r.id) + '"><input data-k="sinif" size="4" value="' + esc(r.sinif) + '"> <input data-k="no" size="6" value="' + esc(r.no || r.ad) + '"> <input data-k="puan" size="3" value="' + esc(r.puan) + '"> <button data-sil="1" title="Sil">✗</button></div>').join('')).join('') : '<i>Boş</i>';
  k.querySelectorAll('input').forEach((x) => { x.onchange = () => duzelt(x.parentNode.dataset.id, x.dataset.k, x.value.trim()); });
  k.querySelectorAll('button[data-sil]').forEach((b) => { b.onclick = () => duzelt(b.parentNode.dataset.id, null); }); }); }
function duzelt(id, alan, deger) { st.get(S.TAMPON, (v) => { const t = (v[S.TAMPON] && v[S.TAMPON].satirlar) || [], i = t.findIndex((r) => r.id === id); if (i < 0) return;
  if (alan === null) t.splice(i, 1); else if (alan === 'sinif') { const m = deger.toLocaleUpperCase('tr-TR').match(/^(\d{1,2})\s*[-/. ]?\s*([A-ZÇĞİÖŞÜ])$/); t[i].sinif = m ? +m[1] + '-' + m[2] : deger; }
  else if (alan === 'no') { if (/^\d+$/.test(deger)) { t[i].no = deger; t[i].ad = ''; } else { t[i].ad = deger; t[i].no = ''; } } else t[i].puan = /^g$/i.test(deger) ? 'G' : deger;
  st.set({ [S.TAMPON]: { z: Date.now(), satirlar: t } }); }); }
document.getElementById('tbos').onclick = () => { if (confirm('Tampondaki tüm sesli notlar silinsin mi?')) st.set({ [S.TAMPON]: { z: Date.now(), satirlar: [] } }); };
chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c[S.TAMPON]) ciz(); }); ciz();
const durum = (t, hata) => { d.textContent = t; d.style.background = hata ? '#ffeb3b' : '#c8f7c5'; st.set({ ngaSesDurum: { t, hata: !!hata, z: Date.now() } }); };
const HATA = { 'not-allowed': 'Mikrofon izni verilmedi. Adres çubuğundaki/pencere üstündeki mikrofon simgesine tıklayıp İzin ver seçin, sonra Sesli not\'u yeniden başlatın. Olmazsa Windows Ayarlar > Gizlilik ve güvenlik > Mikrofon\'da "Uygulamaların mikrofona erişmesine izin ver" ve Chrome açık olmalı.',
  'service-not-allowed': 'Chrome ses tanımaya izin vermedi. Chrome\'u güncelleyip yeniden deneyin.', 'audio-capture': 'Mikrofon bulunamadı. Mikrofonun takılı ve Windows Ses ayarlarında seçili olduğunu kontrol edin.',
  network: 'Ses tanıma için internet bağlantısı gerekiyor (Chrome sesi Google\'da metne çevirir). Bağlantıyı kontrol edin.', 'language-not-supported': 'Bu Chrome Türkçe ses tanımayı desteklemiyor; Chrome\'u güncelleyin.' };
let acik = true, tan = null;
const bitir = () => { acik = false; try { tan && tan.stop(); } catch (e) {} st.set({ ngaSesDurum: { t: 'Sesli not durduruldu.', hata: false, z: Date.now(), bitti: true } }, () => window.close()); };
document.getElementById('b').onclick = bitir;
chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.ngaSesKomut && c.ngaSesKomut.newValue && c.ngaSesKomut.newValue.k === 'dur') bitir(); });
window.addEventListener('beforeunload', () => { if (acik) st.set({ ngaSesDurum: { t: 'Sesli not penceresi kapandı.', hata: false, z: Date.now(), bitti: true } }); });
(async () => {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR) return durum('Bu tarayıcıda ses tanıma yok.', true);
  try { const s = await navigator.mediaDevices.getUserMedia({ audio: true }); s.getTracks().forEach((t) => t.stop()); } // tek seferlik izin sorusu (uzantı için)
  catch (e) { return durum(e && e.name === 'NotFoundError' ? HATA['audio-capture'] : HATA['not-allowed'], true); }
  tan = new SR(); tan.lang = 'tr-TR'; tan.continuous = true; tan.interimResults = false;
  tan.onresult = (e) => { for (let i = e.resultIndex; i < e.results.length; i++) { if (!e.results[i].isFinal) continue; isle(e.results[i][0].transcript); } };
  tan.onerror = (e) => { if (e.error === 'no-speech' || e.error === 'aborted') return; durum(HATA[e.error] || 'Sesli not çalışmadı (' + e.error + ').', true); if (/allowed|capture/.test(e.error)) acik = false; };
  tan.onend = () => { if (acik) { try { tan.start(); } catch (e) { } } };
  tan.start(); durum('Dinliyorum… "11 F 412 numara 85", "12 numara 85" ya da "Ad Soyad 85" deyin.', false);
})();
