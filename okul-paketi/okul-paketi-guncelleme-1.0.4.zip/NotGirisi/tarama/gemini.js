// İsteğe bağlı ikinci okuyucu: Gemini ile oku (varsayılan KAPALI). Yalnız kırpılmış sarı hücre (Okul No rakamları, puan, tarih/gün)
// gönderilir; tam sayfa, Ad Soyad, telefon, TC asla gönderilmez. Anahtar yalnız bu bilgisayarda (chrome.storage.local) durur, loglara yazılmaz.
// OYSS de kullanabilir: GeminiOku.hucreOku / karar / ayarAl / ayarYaz.
(function (kok) {
  'use strict';
  var MODEL = 'gemini-flash-latest', ANAHTAR_DEPO = 'gemini_ayar', ZAMAN = 15000, TURLER = { no: 1, puan: 1, tarih: 1 };
  var SEMA = { type: 'OBJECT', properties: { deger: { type: 'STRING' }, okunabilir: { type: 'BOOLEAN' } }, required: ['deger', 'okunabilir'] };
  var IPUCU = {
    no: 'Görüntü el yazısıyla yazılmış bir okul numarası hücresidir. Yalnızca rakamları yaz (boşluksuz). Emin değilsen okunabilir=false.',
    puan: 'Görüntü el yazısıyla yazılmış bir sınav puanı hücresidir (0-100, ondalık olabilir). Yalnızca sayıyı yaz. Emin değilsen okunabilir=false.',
    tarih: 'Görüntü el yazısıyla yazılmış bir tarih ya da gün hücresidir. GG.AA.YYYY ya da yalnız sayı olarak yaz. Emin değilsen okunabilir=false.'
  };
  function temizle(tur, s) {
    s = String(s == null ? '' : s).trim();
    if (tur === 'no') return /^\d{1,6}$/.test(s.replace(/\s/g, '')) ? s.replace(/\s/g, '') : '';
    if (tur === 'puan') { s = s.replace(',', '.'); var n = Number(s); return /^\d{1,3}(\.\d{1,2})?$/.test(s) && n >= 0 && n <= 100 ? s : ''; }
    return /^[\d.\/ -]{1,10}$/.test(s) ? s.replace(/\s/g, '') : '';
  }
  function maskeleAnahtar(k) { return k ? k.slice(0, 4) + '…' : ''; }
  // png: base64 (data: öneki olmadan). Dönen: { deger, okunabilir } — hata olursa { deger:'', okunabilir:false, hata }
  async function hucreOku(png, tur, anahtar, opt) {
    opt = opt || {}; if (!TURLER[tur]) throw new Error('tür yok: ' + tur); if (!anahtar) return { deger: '', okunabilir: false, hata: 'anahtar yok' };
    var f = opt.fetch || kok.fetch, ac = typeof AbortController !== 'undefined' ? new AbortController() : null, t = ac && setTimeout(function () { ac.abort(); }, opt.zaman || ZAMAN);
    var govde = { contents: [{ role: 'user', parts: [{ text: IPUCU[tur] }, { inline_data: { mime_type: 'image/png', data: png } }] }],
      generationConfig: { temperature: 0, topP: 0.1, maxOutputTokens: 1024, responseMimeType: 'application/json', responseSchema: SEMA } };
    try {
      var y = await f('https://generativelanguage.googleapis.com/v1beta/models/' + (opt.model || MODEL) + ':generateContent', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': anahtar }, body: JSON.stringify(govde), signal: ac ? ac.signal : undefined });
      if (!y.ok) return { deger: '', okunabilir: false, hata: 'HTTP ' + y.status };
      var j = await y.json(), m = j && j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts && j.candidates[0].content.parts[0] && j.candidates[0].content.parts[0].text;
      var o = JSON.parse(m || '{}'), d = temizle(tur, o.deger);
      return { deger: d, okunabilir: !!o.okunabilir && !!d };
    } catch (e) { return { deger: '', okunabilir: false, hata: e && e.name === 'AbortError' ? 'zaman aşımı' : 'yanıt okunamadı' }; }
    finally { if (t) clearTimeout(t); }
  }
  // Yeşil kuralı: Gemini ve yerel aynıysa YA DA (Okul No için) Gemini sonucu sınıf listesinde varsa. Aksi hâlde sarı kalır, Gemini önerisi aday olur.
  function karar(tur, yerel, gem, sinifNolari) {
    yerel = String(yerel == null ? '' : yerel);
    if (!gem || !gem.okunabilir || !gem.deger) return { deger: yerel, yesil: false, aday: '', neden: 'Gemini okuyamadı' };
    var g = tur === 'puan' ? String(Number(gem.deger)) : gem.deger, yl = tur === 'puan' && yerel !== '' ? String(Number(String(yerel).replace(',', '.'))) : yerel;
    if (g === yl) return { deger: yerel, yesil: true, aday: '', neden: 'yerel + Gemini aynı' };
    if (tur === 'no' && sinifNolari && sinifNolari.indexOf(g) >= 0 && (!yl || !(sinifNolari.indexOf(yl) >= 0))) return { deger: g, yesil: true, aday: yerel, neden: 'Gemini + sınıf listesi' };
    return { deger: yerel, yesil: false, aday: g, neden: 'Gemini farklı okudu: ' + g };
  }
  // {w,h,g} gri görüntü ya da canvas → base64 PNG (yalnız tarayıcıda)
  function pngYap(im) {
    var c = im && im.getContext ? im : null;
    if (!c) { c = document.createElement('canvas'); c.width = im.w; c.height = im.h; var x = c.getContext('2d'), d = x.createImageData(im.w, im.h);
      for (var i = 0; i < im.w * im.h; i++) { d.data[4 * i] = d.data[4 * i + 1] = d.data[4 * i + 2] = im.g[i]; d.data[4 * i + 3] = 255; } x.putImageData(d, 0, 0); }
    return c.toDataURL('image/png').split(',')[1];
  }
  function depo() { return kok.chrome && kok.chrome.storage && kok.chrome.storage.local; }
  function ayarAl() { return new Promise(function (ok) { var d = depo(); if (!d) return ok({ acik: false, anahtar: '' }); d.get([ANAHTAR_DEPO], function (s) { var a = s[ANAHTAR_DEPO] || {}; ok({ acik: !!a.acik, anahtar: a.anahtar || '' }); }); }); }
  function ayarYaz(a) { return new Promise(function (ok) { var d = depo(); if (!d) return ok(); var v = {}; v[ANAHTAR_DEPO] = { acik: !!a.acik, anahtar: String(a.anahtar || '').trim() }; d.set(v, ok); }); }
  var api = { MODEL: MODEL, SEMA: SEMA, hucreOku: hucreOku, karar: karar, temizle: temizle, pngYap: pngYap, ayarAl: ayarAl, ayarYaz: ayarYaz, maskeleAnahtar: maskeleAnahtar };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  kok.GeminiOku = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
