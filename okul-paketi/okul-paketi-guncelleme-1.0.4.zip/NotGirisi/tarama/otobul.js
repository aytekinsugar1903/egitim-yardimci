/* Puan yerini kendisi bulma + el yazısı Okul No / Ad Soyad (Not Girişi Asistanı 1.6.0). Tamamen yerel; görüntü ve isimler bu bilgisayardan çıkmaz.
   Puan çoğunlukla sayfanın üst bandında (orta/sağ üst) ya da en altında yazılır; kırmızı kalem de olabilir. Kareli/çizgili kâğıt çizgileri silinir. */
(function (kok) {
  'use strict';
  var AYAR = { FARK: 25, YOG: 0.3, TEK: 0.4, MINH: 0.014 };
  var R = kok.ElRakam || (typeof require !== 'undefined' ? require('./rakam.js') : null);
  var P = kok.PuanOku || (typeof require !== 'undefined' ? require('./okuyucu.js') : null);
  // Kırmızı/pembe kalemi koyulaştır (gri çevrimde silik kalmasın). Yalnız belirgin kırmızı pikseller değişir.
  function kirmiziKoyu(img) {
    var d = img.data, n = img.width * img.height, say = 0, o = new Uint8ClampedArray(d);
    for (var i = 0; i < n; i++) { var r = d[4 * i], g = d[4 * i + 1], b = d[4 * i + 2];
      if (r > 90 && r - g > 45 && r - b > 30) { o[4 * i] = o[4 * i + 1] = o[4 * i + 2] = Math.max(0, Math.min(70, g)); say++; } }
    return { width: img.width, height: img.height, data: o, kirmizi: say / n };
  }
  // renkli kalem (mavi/kırmızı) için: en koyu kanal; beyaz kâğıt tüm kanallarda açıktır
  function enKoyu(img) { var n = img.width * img.height, g = new Float32Array(n), d = img.data; for (var i = 0; i < n; i++) g[i] = Math.min(d[4 * i], d[4 * i + 1], d[4 * i + 2]); return g; }
  function gri(img) { var n = img.width * img.height, g = new Float32Array(n), d = img.data; for (var i = 0; i < n; i++) g[i] = 0.299 * d[4 * i] + 0.587 * d[4 * i + 1] + 0.114 * d[4 * i + 2]; return g; }
  // Küçült + uyarlamalı eşik + uzun yatay/dikey çizgileri (kareli kâğıt, satır çizgisi, kenar) sil
  // 1.6.17 kalem kipi (telefon fotoğrafı, kareli kâğıt): yalnız belirgin koyu ya da renkli (mavi/kırmızı) kalem izi mürekkep sayılır; soluk kılavuz çizgileri alınmaz
  function renkAl(img) { var n = img.width * img.height, g = new Float32Array(n), d = img.data; for (var i = 0; i < n; i++) { var r = d[4 * i], gg = d[4 * i + 1], b = d[4 * i + 2]; g[i] = Math.max(0, Math.max(b - r - 10, r - gg - 30)); } return g; }
  function murekkep(img, W0, renk, kalem, opt) {
    opt = opt || {};
    var k = Math.min(1, W0 / img.width), w = Math.max(1, Math.round(img.width * k)), h = Math.max(1, Math.round(img.height * k)), g0 = renk ? enKoyu(img) : gri(img), g = new Float32Array(w * h), x, y, c0 = kalem ? renkAl(img) : null, cr = kalem ? new Float32Array(w * h) : null;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) { // kutu ortalaması ile küçült
      var x0 = Math.floor(x / k), y0 = Math.floor(y / k), x1 = Math.min(img.width, Math.max(x0 + 1, Math.floor((x + 1) / k))), y1 = Math.min(img.height, Math.max(y0 + 1, Math.floor((y + 1) / k))), s = 0, c = 0, mn = 255;
      for (var yy = y0; yy < y1; yy++) for (var xx = x0; xx < x1; xx++) { var v = g0[yy * img.width + xx]; s += v; c++; if (v < mn) mn = v; if (c0 && c0[yy * img.width + xx] > cr[y * w + x]) cr[y * w + x] = c0[yy * img.width + xx]; }
      g[y * w + x] = 0.5 * (s / c) + 0.5 * mn; }
    var I = new Float64Array((w + 1) * (h + 1));
    for (y = 0; y < h; y++) { var t = 0; for (x = 0; x < w; x++) { t += g[y * w + x]; I[(y + 1) * (w + 1) + x + 1] = I[y * (w + 1) + x + 1] + t; } }
    var m = new Uint8Array(w * h), r = Math.max(6, Math.round(w / 40));
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) { var a0 = Math.max(0, x - r), b0 = Math.max(0, y - r), a1 = Math.min(w, x + r + 1), b1 = Math.min(h, y + r + 1);
      var ort = (I[b1 * (w + 1) + a1] - I[b0 * (w + 1) + a1] - I[b1 * (w + 1) + a0] + I[b0 * (w + 1) + a0]) / ((a1 - a0) * (b1 - b0));
      if (kalem) { m[y * w + x] = (g[y * w + x] < ort - 55 && g[y * w + x] < 150) || (cr[y * w + x] > 22 && g[y * w + x] < ort - 18) ? 1 : 0; continue; }
      m[y * w + x] = renk ? (g[y * w + x] < 165 && g[y * w + x] < ort - 12 ? 1 : 0) : (g[y * w + x] < ort - AYAR.FARK && g[y * w + x] < 175 ? 1 : 0); }
    // çizgi silme: kareli/çizgili kâğıt. Satır (sütun) boyunca geniş pencerede yoğun ve ince olan mürekkep çizgidir; kesik çizgi de yakalanır.
    var L = Math.max(20, Math.round(w * (renk ? 0.45 : 0.12))), sil = new Uint8Array(w * h), S = new Int32Array(Math.max(w, h) + 1), q;
    for (y = 0; y < h; y++) { S[0] = 0; for (x = 0; x < w; x++) S[x + 1] = S[x] + m[y * w + x];
      for (x = 0; x < w; x++) { if (!m[y * w + x]) continue; var p0 = Math.max(0, x - (L >> 1)), p1 = Math.min(w, x + (L >> 1)); if ((S[p1] - S[p0]) / (p1 - p0) < (renk ? 0.6 : AYAR.YOG)) continue;
        var kal = 1; for (q = y - 1; q >= 0 && m[q * w + x] && kal < 9; q--) kal++; for (q = y + 1; q < h && m[q * w + x] && kal < 9; q++) kal++; if (kal <= 4) sil[y * w + x] = 1; } }
    for (x = 0; x < w; x++) { S[0] = 0; for (y = 0; y < h; y++) S[y + 1] = S[y] + m[y * w + x];
      for (y = 0; y < h; y++) { if (!m[y * w + x]) continue; p0 = Math.max(0, y - (L >> 1)); p1 = Math.min(h, y + (L >> 1)); if ((S[p1] - S[p0]) / (p1 - p0) < (renk ? 0.6 : AYAR.YOG)) continue;
        kal = 1; for (q = x - 1; q >= 0 && m[y * w + q] && kal < 9; q--) kal++; for (q = x + 1; q < w && m[y * w + q] && kal < 9; q++) kal++; if (kal <= 4) sil[y * w + x] = 1; } }
    // 1.6.18: uzun ince çizgi renkli olsa da silinir (mavi kareli kâğıt). Kısa renkli kalem izi kalır; rakamın çizgiyle kesiştiği kalın yer silinmez.
    var sonuc = { w: w, h: h, d: m, k: k };
    if (opt.griDon) sonuc.g = g;
    if (opt.silDon) sonuc.sil = sil;
    if (!opt.cizgiBirak) { for (var i = 0; i < m.length; i++) if (sil[i]) m[i] = 0; }
    return sonuc;
  }
  // Rakam grubu adayları: 1-3 büyük parça, çevresi boş (yazı satırı değil)
  function adaylar(M, bolgeler) {
    var b = R.bilesenler(M), cs = b.cs.filter(function (c) { return c.h >= M.h * 0.012 && c.h <= M.h * 0.14 && c.w <= M.w * 0.2 && c.a >= 12; });
    cs.sort(function (a, c) { return a.x - c.x; });
    var gr = [], kul = new Uint8Array(cs.length);
    for (var i = 0; i < cs.length; i++) { if (kul[i]) continue; var g = { x: cs[i].x, y: cs[i].y, x2: cs[i].x + cs[i].w, y2: cs[i].y + cs[i].h, p: [cs[i]] }; kul[i] = 1;
      for (var j = i + 1; j < cs.length; j++) { if (kul[j]) continue; var c = cs[j], s0 = g.p[g.p.length - 1], ust = Math.max(s0.y, c.y), alt = Math.min(s0.y + s0.h, c.y + c.h);
        if (c.x - (s0.x + s0.w) > Math.max(s0.h, c.h) * 0.7) continue; if (alt - ust < 0.35 * Math.min(s0.h, c.h)) continue;
        g.p.push(c); kul[j] = 1; g.x2 = Math.max(g.x2, c.x + c.w); g.y = Math.min(g.y, c.y); g.y2 = Math.max(g.y2, c.y + c.h); }
      gr.push(g); }
    if (kok.OTO_DEBUG) kok.OTO_DEBUG(gr);
    return gr.filter(function (g) { var cy = (g.y + g.y2) / 2 / M.h, cx = (g.x + g.x2) / 2 / M.w; if (!bolgeler.some(function (z) { return cy >= z.y0 && cy <= z.y1 && cx >= z.x0 && cx <= z.x1; })) return false;
      var H = g.y2 - g.y, buyuk = g.p.filter(function (c) { return c.h >= 0.5 * H; }).length; g.buyuk = buyuk;
      if (H < M.h * (AYAR.MINH || 0.018) || buyuk < 1 || buyuk > 4 || (g.x2 - g.x) / H > 3.6) return false;
      // komşuluk: aynı satırda yakın başka mürekkep varsa yazı satırıdır
      var kom = 0; cs.forEach(function (c) { if (g.p.indexOf(c) >= 0 || c.h < 0.4 * H || c.a < 0.15 * H * H * 0.3) return; var cyc = c.y + c.h / 2; if (cyc < g.y - H * 0.3 || cyc > g.y2 + H * 0.3) return; var dx = c.x > g.x2 ? c.x - g.x2 : g.x - (c.x + c.w); if (dx >= 0 && dx < H * 1.6) kom++; });
      g.kom = kom; g.ince = g.p.filter(function (c) { return c.h >= 0.5 * H; }).every(function (c) { return c.w < 0.3 * c.h; }); return true; });
  }
  var BOLGE = [{ y0: 0.03, y1: 0.36, x0: 0.25, x1: 0.96, ad: 'üst' }, { y0: 0.80, y1: 0.97, x0: 0.08, x1: 0.95, ad: 'alt' }];
  // Puanı kendisi bul: {deger, guven, kontrol, neden, kutu:{x,y,w,h}, adaylar}
  // 1.6.17: puanın çevresindeki daire/kutu (rakamlara değse de) silinir: halka biçimli büyük bileşende her açıdaki en dış mürekkep şeridi kaldırılır
  function halkaSil(M) { var b = R.bilesenler(M), d = M.d, deg = false;
    b.cs.forEach(function (c) { if (c.h < M.h * 0.03 || c.w < M.h * 0.03 || c.h > M.h * 0.2 || c.w > M.w * 0.35 || c.a / (c.w * c.h) > 0.3) return;
      var cx = c.x + c.w / 2, cy = c.y + c.h / 2, rx = c.w / 2, ry = c.h / 2, A = 48, rm = new Float32Array(A), el = new Uint8Array(A), x, y, i;
      for (y = c.y; y < c.y + c.h; y++) for (x = c.x; x < c.x + c.w; x++) { i = y * M.w + x; if (b.lab[i] !== c.i) continue; var u = (x - cx) / rx, v = (y - cy) / ry, r = Math.sqrt(u * u + v * v), k = Math.floor((Math.atan2(v, u) + Math.PI) / (2 * Math.PI) * A) % A; if (r > rm[k]) rm[k] = r; if (r > 0.82 && r < 1.12) el[k] = 1; }
      // elips biçimi: açıların çoğunda mürekkep sınır elipsinin üstünde olmalı (iki rakamın birleşik bileşeni, ör. "80", elips değildir)
      var dolu = 0; for (i = 0; i < A; i++) if (el[i]) dolu++; if (dolu < A * 0.6) return;
      // içi boş halka (ör. büyük yazılmış 0) silinmez: içinde mürekkep olmalı
      var ic = 0, ia = 0; for (y = c.y; y < c.y + c.h; y++) for (x = c.x; x < c.x + c.w; x++) { var u0 = (x - cx) / rx, v0 = (y - cy) / ry; if (u0 * u0 + v0 * v0 < 0.36) { ia++; if (d[y * M.w + x]) ic++; } } if (ic < 15 || ic < ia * 0.03) return;
      for (y = c.y; y < c.y + c.h; y++) for (x = c.x; x < c.x + c.w; x++) { i = y * M.w + x; if (b.lab[i] !== c.i) continue; var u2 = (x - cx) / rx, v2 = (y - cy) / ry, r2 = Math.sqrt(u2 * u2 + v2 * v2), k2 = Math.floor((Math.atan2(v2, u2) + Math.PI) / (2 * Math.PI) * A) % A;
        if (r2 >= rm[k2] - Math.max(0.1, 3 / Math.min(rx, ry))) { d[i] = 0; deg = true; } } });
    return M; }
  function yenidenOku(img, kutu, max) { var W = img.width, H = img.height, x0 = Math.max(0, Math.floor(kutu.x * W)), y0 = Math.max(0, Math.floor(kutu.y * H)), x1 = Math.min(W, Math.ceil((kutu.x + kutu.w) * W)), y1 = Math.min(H, Math.ceil((kutu.y + kutu.h) * H));
    var cw = x1 - x0, ch = y1 - y0; if (cw < 8 || ch < 8) return null; var k = Math.min(1, 90 / ch), w = Math.max(1, Math.round(cw * k)), h = Math.max(1, Math.round(ch * k)), g = new Float32Array(w * h), cr = new Float32Array(w * h), d = img.data, x, y;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) { var ax = x0 + Math.floor(x / k), ay = y0 + Math.floor(y / k), bx = Math.min(x1, x0 + Math.max(Math.floor(x / k) + 1, Math.floor((x + 1) / k))), by = Math.min(y1, y0 + Math.max(Math.floor(y / k) + 1, Math.floor((y + 1) / k))), mn = 255, c = 0;
      for (var yy = ay; yy < by; yy++) for (var xx = ax; xx < bx; xx++) { var i = 4 * (yy * W + xx), r = d[i], gg = d[i + 1], b = d[i + 2], v = 0.299 * r + 0.587 * gg + 0.114 * b; if (v < mn) mn = v; c = Math.max(c, b - r - 10, r - gg - 30); }
      g[y * w + x] = mn; cr[y * w + x] = c; }
    var srt = Array.prototype.slice.call(g).sort(function (a, b) { return a - b; }), arka = srt[Math.floor(srt.length * 0.7)], m = new Uint8Array(w * h), say = 0, koyu = srt[Math.floor(srt.length * 0.01)], esk = Math.min(arka - 40, koyu + 0.4 * (arka - koyu));
    for (var i2 = 0; i2 < w * h; i2++) if (g[i2] < esk || (cr[i2] > 35 && g[i2] < arka - 30)) { m[i2] = 1; say++; }
    if (say < 20 || say > w * h * 0.5) return null;
    // ince çizgiyi kalınlaştır (rakam modeli kalın kalemle eğitildi)
    var m2 = new Uint8Array(m); for (y = 1; y < h - 1; y++) for (x = 1; x < w - 1; x++) if (!m[y * w + x] && (m[y * w + x - 1] || m[y * w + x + 1] || m[(y - 1) * w + x] || m[(y + 1) * w + x])) m2[y * w + x] = 1;
    // uzun yatay alt çizgi (altı çizili puan) silinir
    for (y = 0; y < h; y++) { var run = 0; for (x = 0; x <= w; x++) { if (x < w && m2[y * w + x]) { run++; continue; } if (run > w * 0.7) for (var q = x - run; q < x; q++) { var ust = y > 2 && m2[(y - 3) * w + q], alt = y < h - 3 && m2[(y + 3) * w + q]; if (!(ust && alt)) m2[y * w + q] = 0; } run = 0; } }
    if (kok.YO_DEBUG) kok.YO_DEBUG({ w: w, h: h, d: m2 });
    var e = P.enIyiSayi({ w: w, h: h, d: m2 }, 3, max); if (!e) return null; return { deger: String(parseInt(e.s, 10)), guven: Math.round(100 * e.p) }; }
  function puanBul(img, max, esik) {
    if (!R || !R.hazir()) throw new Error('Rakam modeli yüklenmedi');
    esik = esik || P.ESIK; max = max == null ? 100 : max;
    var oku = [], kk = kirmiziKoyu(img);
    [halkaSil(murekkep(kk, 1000)), halkaSil(murekkep(img, 1000, false, true))].forEach(function (M, mi) { var gs = adaylar(M, BOLGE);
    // 1.6.17: toplam puan çoğunlukla sayfanın en üstünde ve soru yanı puanlardan büyük yazılır
    var Hmax = gs.reduce(function (m, g) { return g.kom || (g.x2 - g.x) / (g.y2 - g.y) > 3.6 ? m : Math.max(m, g.y2 - g.y); }, 1);
    // hız: en umut verici 12 aday okunur (yalnız, büyük)
    gs.sort(function (a, b) { return (a.kom - b.kom) || ((b.y2 - b.y) - (a.y2 - a.y)); }); gs = gs.slice(0, 12);
    gs.forEach(function (g) { var H = g.y2 - g.y, pad = H * 0.25, kutu = { x: Math.max(0, (g.x - pad) / M.w), y: Math.max(0, (g.y - pad) / M.h), w: (g.x2 - g.x + 2 * pad) / M.w, h: (g.y2 - g.y + 2 * pad) / M.h };
      var x0 = Math.max(0, Math.floor(g.x - pad)), y0 = Math.max(0, Math.floor(g.y - pad)), x1 = Math.min(M.w, Math.ceil(g.x2 + pad)), y1 = Math.min(M.h, Math.ceil(g.y2 + pad)), cw = x1 - x0, ch = y1 - y0, d = new Uint8Array(cw * ch), gg = new Float32Array(cw * ch);
      for (var yy = 0; yy < ch; yy++) for (var xx = 0; xx < cw; xx++) { d[yy * cw + xx] = M.d[(yy + y0) * M.w + xx + x0]; gg[yy * cw + xx] = d[yy * cw + xx] ? 0 : 255; }
      var e = P.enIyiSayi({ w: cw, h: ch, d: d }, 3, max); if (!e) return; var r = { deger: String(parseInt(e.s, 10)), guven: Math.round(100 * e.p), img: { w: cw, h: ch, g: gg } };
      var v = Number(r.deger), puan = r.guven * (g.kom ? Math.pow(0.55, Math.min(3, g.kom)) : 1) * (v > max ? 0.2 : 1) * Math.min(1, 0.4 + H / (M.h * 0.05)) * (g.ince ? 0.3 : 1) * ((g.y + g.y2) / 2 > M.h * 0.7 ? 0.85 : 1) * (r.deger.length < 2 ? AYAR.TEK : 1) * ((g.y + g.y2) / 2 < M.h * 0.25 ? 1 : (g.y + g.y2) / 2 > M.h * 0.8 ? 0.7 : 0.6) * (/^[17]+$/.test(r.deger) ? 0.5 : 1) * Math.min(1, 0.35 + 0.65 * H / Hmax);
      if (!oku.some(function (o) { return o.deger === r.deger && Math.abs(o.kutu.x - kutu.x) < 0.03 && Math.abs(o.kutu.y - kutu.y) < 0.03 && o.puan >= puan; })) oku.push({ deger: r.deger, deger0: r.deger, guven: r.guven, puan: puan, kutu: kutu, img: r.img, kom: g.kom, m: mi }); }); });
    oku.sort(function (a, b) { return b.puan - a.puan; });
    // 1.6.17: ilk adaylar tam çözünürlükte yeniden okunur (ince/büyük el yazısı küçültmede kopar); daha güvenli okuma alınır
    oku.slice(0, 6).forEach(function (o) { var y = yenidenOku(img, o.kutu, max); if (!y || y.guven <= o.guven + 5) return; var f = o.puan / Math.max(1, o.guven), v = Number(y.deger);
      o.puan = y.guven * f * (v > max ? 0.2 : 1) * (y.deger.length < 2 ? AYAR.TEK : 1) / ((o.deger0 || o.deger).length < 2 ? AYAR.TEK : 1) * (/^[17]+$/.test(y.deger) ? 0.5 : 1) / (/^[17]+$/.test(o.deger0 || o.deger) ? 0.5 : 1); o.deger = y.deger; o.guven = y.guven; o.yeniden = true; });
    oku.sort(function (a, b) { return b.puan - a.puan; });
    if (!oku.length) return { deger: '', guven: 0, bos: true, kontrol: true, neden: 'puan bulunamadı', max: max, adaylar: [] };
    var en = oku[0], iki = oku.filter(function (o) { return o.deger !== en.deger; })[0], out = { deger: en.deger, guven: Math.round(Math.min(en.guven, en.puan)), kutu: en.kutu, img: en.img, max: max, adaylar: oku.slice(0, 4).map(function (o) { return o.deger + ' %' + Math.round(o.puan); }), tum: oku.slice(0, 10).map(function (o) { return [o.deger, Math.round(o.guven), Math.round(o.puan), o.m, o.kom, o.kutu.x.toFixed(2), o.kutu.y.toFixed(2), o.kutu.w.toFixed(2), o.kutu.h.toFixed(2)].join(','); }) };
    var cakisma = iki && iki.puan > en.puan * 0.8;
    out.kontrol = cakisma || out.guven < esik || Number(out.deger) > max; out.neden = cakisma ? 'birden çok aday (' + iki.deger + '?)' : Number(out.deger) > max ? 'azamiden büyük' : out.guven < esik ? 'düşük güven' : '';
    return out;
  }
  // ---- Ad Soyad / Okul No ----
  function tr(s) { return String(s || '').toLocaleUpperCase('tr-TR').replace(/[^A-ZÇĞİIÖŞÜ ]/g, ' ').replace(/\s+/g, ' ').trim(); }
  // 1.6.17: el yazısı OCR'ında harf yerine rakam/işaret (0→O, 1/|→I, 5→S, 8→B, 2→Z, 6→G) ve "Adı Soyadı:" etiketi ayıklanır
  function trOn(s) { return String(s || '').replace(/ad[ıi]\s*soyad[ıi]\s*[:.]?/ig, ' ').replace(/(^|[^0-9])[0-9|]+(?=[A-Za-zÇĞİÖŞÜçğıöşü])|([A-Za-zÇĞİÖŞÜçğıöşü])[0-9|]+/g, function (m) { return m.replace(/0/g, 'O').replace(/[1|]/g, 'I').replace(/5/g, 'S').replace(/8/g, 'B').replace(/2/g, 'Z').replace(/6/g, 'G'); }); }
  function sade(s) { return tr(trOn(s)).replace(/Ç/g, 'C').replace(/Ğ/g, 'G').replace(/[İI]/g, 'I').replace(/Ö/g, 'O').replace(/Ş/g, 'S').replace(/Ü/g, 'U'); }
  function lev(a, b) { var m = a.length, n = b.length, d = []; for (var i = 0; i <= m; i++) { d[i] = [i]; } for (var j = 0; j <= n; j++) d[0][j] = j;
    for (i = 1; i <= m; i++) for (j = 1; j <= n; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[m][n]; }
  function benzer(a, b) { a = sade(a); b = sade(b); if (!a || !b) return 0; var t = 1 - lev(a, b) / Math.max(a.length, b.length);
    // kelime sırası farklı yazılmış olabilir (Soyad Ad)
    var ka = a.split(' ').sort().join(' '), kb = b.split(' ').sort().join(' '); t = Math.max(t, 1 - lev(ka, kb) / Math.max(ka.length, kb.length));
    // 1.6.4: kelime kelime en iyi eşleşme ortalaması (el yazısında bir harf düşse/eklense de)
    var ta = a.split(' '), tb = b.split(' '); if (ta.length && tb.length) { var top = 0; tb.forEach(function (w) { var en = 0; ta.forEach(function (q) { en = Math.max(en, 1 - lev(q, w) / Math.max(q.length, w.length)); }); top += en; }); t = Math.max(t, 0.95 * top / tb.length); }
    return Math.max(0, t); }
  // liste: [{no:'123', ad:'...'}]; okunan: {no:{deger,guven}, ad:{metin,guven}} -> {no, ad, kontrol, neden, oneriler}
  // 1.6.17 Okul No için el yazısı rakam karışıklığına göre ağırlıklı mesafe (akis.js noMesafe ile aynı)
  var KAR = {}; ['17', '06', '38', '56', '49', '27', '08', '35', '14', '69', '57', '13'].forEach(function (p) { KAR[p] = KAR[p[1] + p[0]] = 1; });
  function noMesafe(x, y) { x = String(x); y = String(y); var n = x.length, m = y.length, d = [], i, j, ind = function (c) { return c === '1' ? 0.6 : 1; };
    for (i = 0; i <= n; i++) d[i] = [i ? d[i - 1][0] + ind(x[i - 1]) : 0];
    for (j = 1; j <= m; j++) d[0][j] = d[0][j - 1] + ind(y[j - 1]);
    for (i = 1; i <= n; i++) for (j = 1; j <= m; j++) d[i][j] = Math.min(d[i - 1][j] + ind(x[i - 1]), d[i][j - 1] + ind(y[j - 1]), d[i - 1][j - 1] + (x[i - 1] === y[j - 1] ? 0 : KAR[x[i - 1] + y[j - 1]] ? 0.5 : 1));
    return d[n][m]; }
  // liste: [{no:'123', ad:'...'}]; okunan: {no:{deger,guven}, ad:{metin,guven}} -> {no, ad, kontrol, neden, oneriler}
  // 1.6.17: numara ve ad birlikte değerlendirilir (iki bağımsız kanıt). Yalnız ikisi aynı öğrenciyi açık farkla gösterirse yeşil; düzeltilen her şey sarı.
  function ogrenciEsle(liste, no, adMetin) {
    var sonuc = { no: no && no.deger || '', kontrol: true, neden: '', oneri: null };
    if (!liste || !liste.length) { sonuc.neden = 'sınıf listesi yok'; sonuc.kontrol = !no || !no.deger || no.guven < P.ESIK; return sonuc; }
    var nd = no && no.deger ? String(no.deger) : '';
    var noE = nd ? liste.filter(function (o) { return String(o.no) === nd; })[0] : null;
    var adS = adMetin && sade(adMetin).replace(/ /g, '').length >= 3 ? liste.map(function (o) { return { o: o, s: benzer(adMetin, o.ad) }; }).sort(function (a, b) { return b.s - a.s; }) : [];
    var adE = adS.length && adS[0].s >= 0.55 && (!adS[1] || adS[0].s - adS[1].s >= 0.08) ? adS[0].o : null;
    var adPuan = function (o) { for (var i = 0; i < adS.length; i++) if (adS[i].o === o) return adS[i].s; return 0; };
    if (noE && adE && noE === adE) { sonuc.oneri = noE; sonuc.kontrol = no.guven < P.ESIK && adS[0].s < 0.8; sonuc.neden = sonuc.kontrol ? 'düşük güven' : ''; sonuc.uyum = 'no+ad'; return sonuc; }
    // 1.6.17: okunan numara listede başka öğrencinin ama ad açıkça bir öğrenciyi gösteriyor ve onun numarası rakam karışıklığıyla açıklanabiliyorsa ada geçilir (SARI)
    if (noE && adE && noE !== adE && noMesafe(nd, adE.no) <= 1 && adS[0].s >= 0.75 && adPuan(noE) < 0.5) { sonuc.oneri = adE; sonuc.no = String(adE.no); sonuc.alternatif = noE; sonuc.neden = 'okunan ' + nd + ' başka öğrencinin; ad ve yakın numara ' + adE.no + ' gösteriyor'; return sonuc; }
    if (noE && adE && noE !== adE) { sonuc.oneri = noE; sonuc.neden = 'no ile ad farklı öğrenci (' + adE.no + '?)'; sonuc.alternatif = adE; return sonuc; }
    // 1.6.17: ad tek başına kesin seçemese de numaranın öğrencisi adla en iyi (ya da çok yakın) uyan öğrenciyse ve benzerlik yeterliyse iki kanıt uyuşur
    if (noE && adS.length) { var sp = adPuan(noE); if (sp >= 0.6 && sp >= adS[0].s - 0.02) { sonuc.oneri = noE; sonuc.kontrol = no.guven < P.ESIK && sp < 0.8; sonuc.neden = sonuc.kontrol ? 'düşük güven' : ''; sonuc.uyum = 'no+ad'; return sonuc; } }
    if (noE && !adS.length) { sonuc.oneri = noE; sonuc.kontrol = no.guven < P.ESIK || !!adMetin; sonuc.neden = sonuc.kontrol ? (adMetin ? 'ad okunamadı' : 'düşük güven') : ''; sonuc.uyum = 'no'; return sonuc; }
    if (noE) { sonuc.oneri = noE; sonuc.neden = 'ad okunamadı/eşleşmedi'; return sonuc; }
    // numara listede yok: rakam karışıklığına göre yakın numaralar; ad varsa adla birlikte puanlanır (her durumda SARI)
    var yak = nd ? liste.map(function (o) { return { o: o, d: noMesafe(nd, o.no) }; }).filter(function (a) { return a.d <= 1.5; }) : [];
    if (adS.length && yak.length) { yak.forEach(function (a) { a.t = adPuan(a.o) - 0.25 * a.d; }); yak.sort(function (a, b) { return b.t - a.t; });
      if (adPuan(yak[0].o) >= 0.5 && (!yak[1] || yak[0].t - yak[1].t >= 0.1) && (!adE || adE === yak[0].o)) { sonuc.oneri = yak[0].o; sonuc.no = String(yak[0].o.no); sonuc.neden = 'numara listede yok; yakın numara + ad: ' + yak[0].o.no; return sonuc; } }
    if (adE) { sonuc.oneri = adE; sonuc.no = String(adE.no); sonuc.neden = 'numara listede yok; adla bulundu'; return sonuc; }
    var y1 = yak.filter(function (a) { return a.d <= 1; }).sort(function (a, b) { return a.d - b.d; });
    if (y1.length === 1 || (y1.length > 1 && y1[1].d - y1[0].d >= 0.5)) { sonuc.oneri = y1[0].o; sonuc.no = String(y1[0].o.no); sonuc.neden = 'numara listede yok; en yakın ' + y1[0].o.no; return sonuc; }
    sonuc.neden = 'listede bulunamadı'; return sonuc;
  }
  // Ad maskeleme (günlük/rapor için): "Ayşe Yılmaz" -> "A*** Y*****"
  function maskele(s) { return String(s || '').split(/\s+/).map(function (k) { return k ? k[0] + k.slice(1).replace(/./g, '*') : k; }).join(' '); }

  // ---- 1.6.0 Form kâğıdı (dilekçe, form): basılı "Adı soyadı" ve "Numarası" etiketlerini yazı tanımayla bulur, el yazısı hücreyi etiketin altından/yanından okur.
  // Taranmış sayfa kaysa da etiket yeri bulunduğu için çalışır. Yalnız tarayıcıda (Tesseract). Emin olunmayan her şey sarı kalır.

  // Hücredeki el yazısı numara: tablo çizgileri silinir, en sağdaki 3-6 parçalık rakam grubu okunur (soldaki "9/N" sınıf yazısı atlanır)

  // Bitişik yazılmış rakamlar: tipik rakam genişliğinin belirgin katı olan parça, dikey izdüşümün en ince yerlerinden kesilir
  function bitisikBol(M, AY) {
    var b = R.bilesenler(M), cs = b.cs.filter(function (c) { return c.h >= M.h * 0.25 && c.a >= 15; }); if (cs.length < 2) return M;
    var H = cs.map(function (c) { return c.h; }).sort(function (a, c) { return a - c; })[cs.length >> 1], Wd = Math.max(4, 0.72 * H), d = M.d.slice ? M.d.slice() : new Uint8Array(M.d);
    cs.forEach(function (c) { if (c.h > AY.ayrac * H) return; var n = Math.round(c.w / Wd); if (c.w < AY.genis * Wd || n < 2) return; n = Math.min(n, 4);
      var pr = []; for (var x = 0; x < c.w; x++) { var t = 0; for (var y = c.y; y < c.y + c.h; y++) if (b.lab[y * M.w + c.x + x] === c.i) t++; pr.push(t); }
      for (var k = 1; k < n; k++) { var mrk = Math.round(c.w * k / n), r0 = Math.max(1, mrk - Math.round(Wd * 0.35)), r1 = Math.min(c.w - 2, mrk + Math.round(Wd * 0.35)), en = mrk;
        for (x = r0; x <= r1; x++) if (pr[x] < pr[en]) en = x;
        for (y = c.y; y < c.y + c.h; y++) d[y * M.w + c.x + en] = 0; } });
    return { w: M.w, h: M.h, d: d, k: M.k, aci: M.aci };
  }

  // Eğitim/inceleme için: maskedeki her rakam parçasının 28x28 görüntüsü (tekTekOku ile aynı kesim)
  function parcalar(m) {
    var b = R.bilesenler(m), cs = b.cs; if (!cs.length) return []; var H = Math.max.apply(null, cs.map(function (c) { return c.h; }));
    return cs.filter(function (c) { return c.h >= 0.5 * H; }).sort(function (a, c) { return a.x - c.x; }).map(function (c) {
      var ids = [c.i].concat(cs.filter(function (q) { return q.h < 0.5 * H && q.x >= c.x - 2 && q.x + q.w <= c.x + c.w + 2; }).map(function (q) { return q.i; }));
      var d = new Uint8Array(c.w * m.h); for (var y = 0; y < m.h; y++) for (var x = 0; x < c.w; x++) if (ids.indexOf(b.lab[y * m.w + x + c.x]) >= 0) d[y * c.w + x] = 1;
      return R.mnist({ w: c.w, h: m.h, d: d }); }); }
  var NOAYAR = { ayrac: 1.45, bosluk: 0.9, yakin: 0.6, once: 0.8, genis: 1.7 };
  // 1.6.0 okuması (yedek/oylama için): eğiklik ve bölme yok, en sağdaki en az 3 parçalı grup
  function noHucreEski(img) {
    var M = murekkep(img, img.width, true), b = R.bilesenler(M), cs = b.cs.filter(function (c) { return c.h >= M.h * 0.25 && c.a >= 15; }).sort(function (a, c) { return a.x - c.x; });
    if (!cs.length) return { s: '', guven: 0 };
    var H = cs.map(function (c) { return c.h; }).sort(function (a, c) { return a - c; })[cs.length >> 1], gr = [[cs[0]]];
    for (var i = 1; i < cs.length; i++) { var s0 = gr[gr.length - 1][gr[gr.length - 1].length - 1]; if (cs[i].x - (s0.x + s0.w) > H * 0.9) gr.push([cs[i]]); else gr[gr.length - 1].push(cs[i]); }
    var g = gr.filter(function (q) { return q.length >= 3; }).pop() || gr[gr.length - 1];
    var x0 = Math.max(0, g[0].x - 3), x1 = Math.min(M.w, g[g.length - 1].x + g[g.length - 1].w + 3), w = x1 - x0, d = new Uint8Array(w * M.h), ids = {};
    g.forEach(function (c) { ids[c.i] = 1; }); b.cs.forEach(function (c) { if (c.x >= x0 && c.x + c.w <= x1 && c.h < M.h * 0.25) ids[c.i] = 1; });
    for (var y = 0; y < M.h; y++) for (var x = 0; x < w; x++) if (ids[b.lab[y * M.w + x + x0]]) d[y * w + x] = 1;
    var m = { w: w, h: M.h, d: d }, t = P.tekTekOku(m), e = P.enIyiSayi(m, 6), r = t && (!e || t.p >= e.p) ? t : e;
    return r ? { s: r.s, guven: Math.round(100 * r.p) } : { s: '', guven: 0 };
  }
  // Oylama: birkaç dikey kaydırma × (eğiklik, bölme) okuması; en çok tekrarlanan 4 hane. Beraberlikte dış okuma (yazı tanıma) ve 1.6.0 okuması tercih edilir.
  function noOyla(okumalar, dis, eski) {
    var v = {}; okumalar.forEach(function (o) { if (o.s && o.s.length === 4 && o.s[0] !== '0') { v[o.s] = v[o.s] || { n: 0, g: 0 }; v[o.s].n++; v[o.s].g += o.guven; } });
    var c = Object.keys(v).sort(function (a, b) { return (v[b].n - v[a].n) || ((b === dis) - (a === dis)) || ((b === eski) - (a === eski)) || (v[b].g - v[a].g); });
    if (!c.length) return { s: eski || '', guven: 0, neden: 'okunamadı', oylar: '' };
    var s = c[0], yesil = s === dis && v[s].n >= 2, ada = c.filter(function (k) { return v[k].n >= Math.max(2, v[s].n * 0.5); }).slice(0, 3), belirsiz = ada.length > 1;
    // 1.6.4: ikinci aday ilkine yakın oy aldıysa (ör. 6113/1113) belirsiz; dış okuma (yazı tanıma) ilk adayı doğrulasa da en fazla sarı-yeşil sınırı
    return { s: s, adaylar: ada, belirsiz: belirsiz, guven: yesil && !belirsiz ? 95 : Math.min(70, Math.round(v[s].g / v[s].n)), neden: yesil && !belirsiz ? '' : belirsiz ? 'iki aday: ' + ada.join(' / ') : 'doğrulanmadı', oylar: c.slice(0, 3).map(function (k) { return k + '×' + v[k].n; }).join(' ') };
  }
  function noHucre(img, opt) {
    var M0 = murekkep(img, img.width, true); if (!opt || opt.egik !== false) M0 = egikDuz(M0); if (!opt || opt.bol !== false) M0 = bitisikBol(M0, (opt && opt.ayar) || NOAYAR);
    var M = M0, b = R.bilesenler(M), cs = b.cs.filter(function (c) { return c.h >= M.h * 0.25 && c.a >= 15; }).sort(function (a, c) { return a.x - c.x; });
    if (!cs.length) return { s: '', guven: 0, neden: 'boş' };
    var H = cs.map(function (c) { return c.h; }).sort(function (a, c) { return a - c; })[cs.length >> 1], AY = (opt && opt.ayar) || NOAYAR;
    // ayraç: "/" ya da dikey çizgi gibi rakamdan belirgin uzun parça; grupları böler
    // 1.6.17: uzun parça "1" de olabilir (eğik/uzun yazılmış bir): gruplar hem ayraçlı hem ayraçsız kurulur, hane sayısı tutan seçilir
    var grup = function (ayracVar) { var gr = [[]];
      cs.forEach(function (c) { var son = gr[gr.length - 1], s0 = son[son.length - 1];
        if (ayracVar && c.h > AY.ayrac * H) { if (son.length) gr.push([]); return; }
        if (s0 && c.x - (s0.x + s0.w) > H * AY.bosluk) gr.push([c]); else son.push(c); });
      return gr.filter(function (g) { return g.length; }); };
    if (kok.NH_DEBUG) kok.NH_DEBUG({ M: M, H: H, Mh: M.h, cs: cs.map(function (c) { return [c.x, c.y, c.w, c.h].join(','); }), g1: grup(true).map(function (g) { return g.length; }) });
    var hedef = (opt && opt.uzunluk) || 4, en = null, gr1 = grup(true), gr2 = cs.some(function (c) { return c.h > AY.ayrac * H; }) ? grup(false) : [];
    [[gr1, 1], [gr2, 0.9]].forEach(function (GG) { var gr = GG[0], kat = GG[1];
    gr.forEach(function (G, gi) { for (var bas = Math.max(0, G.length - 7); bas < G.length; bas++) { var g = G.slice(bas); if (g.length < 2) continue;
      var x0 = Math.max(0, g[0].x - 2), x1 = Math.min(M.w, g[g.length - 1].x + g[g.length - 1].w + 2), w = x1 - x0, d = new Uint8Array(w * M.h);
      var ids = {}, gy0 = Math.min.apply(null, g.map(function (c) { return c.y; })), gy1 = Math.max.apply(null, g.map(function (c) { return c.y + c.h; })); g.forEach(function (c) { ids[c.i] = 1; }); b.cs.forEach(function (c) { if (c.x >= x0 && c.x + c.w <= x1 && c.h < M.h * 0.25 && c.h > H * 0.15 && c.y + c.h > gy0 + 2 && c.y < gy1 - 2) ids[c.i] = 1; });
      for (var y = 0; y < M.h; y++) for (var x = 0; x < w; x++) if (ids[b.lab[y * M.w + x + x0]]) d[y * w + x] = 1;
      var m = { w: w, h: M.h, d: d }, t = P.tekTekOku(m), e = P.enIyiSayi(m, 7), r = t && (!e || t.p >= e.p) ? t : e; if (!r) continue;
      var puan = kat * r.p * (r.s.length === hedef ? 1 : Math.abs(r.s.length - hedef) === 1 ? AY.yakin : 0.15) * (gi === gr.length - 1 ? 1 : AY.once);
      if (!en || puan > en.puan) en = { s: r.s, p: r.p, puan: puan, m: m }; } }); });
    var r = en;
    if (!r) return { s: '', guven: 0, neden: 'okunamadı' };
    if (opt && opt.parca) r.parca = parcalar(r.m);
    if (r.s.length !== hedef) return { s: r.s, guven: Math.min(60, Math.round(100 * r.p)), neden: 'hane sayısı ' + r.s.length, parca: r.parca };
    return { s: r.s, guven: Math.round(100 * r.p), neden: r.s.length < 3 ? 'kısa' : '', parca: r.parca };
  }

  // Hafif eğik taramada tablo çizgisi tek satırda değildir: en keskin satır izdüşümünü veren kaydırma açısı bulunur (-4°..4°), sonra uzun yatay çizgiler silinir
  function egikDuz(M) {
    var w = M.w, h = M.h, en = 0, enP = -1;
    for (var a = -4; a <= 4.01; a += 0.25) { var t = Math.tan(a * Math.PI / 180), sat = new Float64Array(h + 2 * h), x, y;
      for (y = 0; y < h; y++) for (x = 0; x < w; x++) if (M.d[y * w + x]) { var yy = Math.round(y - x * t) + h; if (yy >= 0 && yy < 3 * h) sat[yy]++; }
      var p = 0; for (y = 0; y < 3 * h; y++) p += sat[y] * sat[y]; if (p > enP) { enP = p; en = t; } }
    var d = new Uint8Array(w * h);
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) { var ys = Math.round(y + x * en); if (ys >= 0 && ys < h) d[y * w + x] = M.d[ys * w + x]; }
    // yatay çizgi: satırın yarısından fazlası dolu, ince
    for (y = 0; y < h; y++) { var say = 0; for (x = 0; x < w; x++) say += d[y * w + x]; if (say < w * 0.35) continue;
      for (x = 0; x < w; x++) { if (!d[y * w + x]) continue; var kal = 0, q; for (q = y - 1; q >= 0 && d[q * w + x]; q--) kal++; for (q = y + 1; q < h && d[q * w + x]; q++) kal++; if (kal <= 3) d[y * w + x] = 2; } }
    for (var i = 0; i < d.length; i++) if (d[i] === 2) d[i] = 0;
    return { w: w, h: h, d: d, k: M.k, aci: Math.atan(en) * 180 / Math.PI };
  }
  var formIsci = null;
  async function isciAl() {
    if (formIsci) return formIsci; var url = function (y) { return kok.chrome && chrome.runtime && chrome.runtime.getURL ? chrome.runtime.getURL('tarama/' + y) : new URL(y, location.href).href; };
    formIsci = await Tesseract.createWorker('tur', 1, { workerPath: url('lib/worker.min.js'), corePath: url('lib/tess-core/'), langPath: url('lib/lang'), workerBlobURL: false, cacheMethod: 'none' }); return formIsci; }
  function kirp(c, x0, y0, x1, y1, olcek) { var k = document.createElement('canvas'), w = Math.max(1, Math.round((x1 - x0) * olcek)), h = Math.max(1, Math.round((y1 - y0) * olcek)); k.width = w; k.height = h;
    var g = k.getContext('2d', { willReadFrequently: true }); g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); g.drawImage(c, x0, y0, x1 - x0, y1 - y0, 0, 0, w, h); return k; }
  function kelimeler(d) { var o = []; (d.blocks || []).forEach(function (b) { (b.paragraphs || []).forEach(function (p) { (p.lines || []).forEach(function (l) { (l.words || []).forEach(function (w) { o.push({ t: w.text, b: w.bbox, c: w.confidence }); }); }); }); }); return o; }
  function hucreSinir(c, xm, y0, y1) { var bx0 = Math.max(0, Math.round(xm - c.width * 0.2)), bx1 = Math.min(c.width, Math.round(xm + c.width * 0.2)), Y0 = Math.max(0, Math.round(y0)), Y1 = Math.min(c.height, Math.round(y1)), w = bx1 - bx0, h = Y1 - Y0; if (w < 10 || h < 10) return null;
    var d = c.getContext('2d').getImageData(bx0, Y0, w, h).data, kol = [], x, y;
    for (x = 0; x < w; x++) { var say = 0; for (y = 0; y < h; y++) { var i = 4 * (y * w + x); if (Math.min(d[i], d[i + 1], d[i + 2]) < 110) say++; } kol.push(say / h); }
    var sol = -1, sag = -1, xc = Math.round(xm - bx0); for (x = xc; x >= 0; x--) if (kol[x] > 0.85) { sol = x; break; } for (x = xc; x < w; x++) if (kol[x] > 0.85) { sag = x; break; }
    if (sol < 0 || sag < 0 || sag - sol < 30) return null; return [bx0 + sol + 4, bx0 + sag - 3]; }
  async function formKimlik(c, opt) {
    var is = await isciAl(), k = Math.min(1, 1600 / c.width), sayfa = kirp(c, 0, 0, c.width, c.height, k);
    await is.setParameters({ tessedit_pageseg_mode: '3' });
    var ws = kelimeler((await is.recognize(sayfa, {}, { blocks: true })).data).map(function (w) { return { t: w.t, c: w.c, x0: w.b.x0 / k, y0: w.b.y0 / k, x1: w.b.x1 / k, y1: w.b.y1 / k }; });
    var bul = function (re) { return ws.filter(function (w) { return re.test(w.t); }).sort(function (a, b) { return a.y0 - b.y0; })[0]; };
    var adE = bul(/soyad/i), noE = bul(/numara/i), ayniSatir = function (e, re) { return e && ws.filter(function (w) { return re.test(w.t) && Math.abs(w.y0 - e.y0) < (e.y1 - e.y0) * 1.2; }).sort(function (a, b) { return a.x0 - b.x0; }); };
    var izL = ayniSatir(noE, /^[İIi]zin|sebeb|iste[gğ]|puan|ald[ıi1]|^not\b|tarih|imza/i) || [], izE = izL.filter(function (w) { return w.x0 > noE.x0; })[0];
    var snL = (ayniSatir(noE, /s[ıi1l]n[ıi1l]f/i) || []).filter(function (w) { return w.x1 <= noE.x0 + 5 && noE.x0 - w.x0 < c.width * 0.2 && noE.x0 - w.x1 < (noE.y1 - noE.y0) * 2.5; }); if (noE && snL.length) noE = { t: noE.t, x0: snL[0].x0, y0: noE.y0, x1: noE.x1, y1: noE.y1 };
    var adL = (ayniSatir(adE, /^ad/i) || []).filter(function (w) { return w.x1 <= adE.x0 + 5 && adE.x0 - w.x0 < c.width * 0.12; }); if (adE && adL.length) adE = { t: adE.t, x0: adL[0].x0, y0: adE.y0, x1: adE.x1, y1: adE.y1 };
    var out = { etiket: { ad: !!adE, no: !!noE }, adayEtiket: ws.filter(function (w) { return /numara|soyad|s[ıi]n[ıi]f|telefon/i.test(w.t); }).map(function (w) { return w.t + '@' + Math.round(w.x0) + ',' + Math.round(w.y0); }) };
    if (!adE && !noE) { out.neden = 'form etiketleri bulunamadı'; return out; }
    var lh = ((adE || noE).y1 - (adE || noE).y0) || 20, ref = noE || adE, yy0 = ref.y1 + lh * 0.25, yy1 = ref.y1 + lh * 2.6, ay0 = (adE || ref).y1 + lh * 0.25, ay1 = (adE || ref).y1 + lh * 2.6;
    out.kutu = { yy0: yy0, yy1: yy1 };
    await is.setParameters({ tessedit_pageseg_mode: '7' });
    if (adE) { var ax0 = Math.max(0, adE.x0 - lh * 0.5), ax1 = noE ? noE.x0 - lh * 0.4 : adE.x0 + c.width * 0.3, kr = kirp(c, ax0, ay0, ax1, ay1, Math.min(2, 60 / lh));
      var t = (await is.recognize(kr)).data.text || ''; out.ad = t.replace(/[^A-Za-zÇĞİIÖŞÜçğıiöşü .]/g, ' ').replace(/\s+/g, ' ').trim(); out.adKutu = [ax0, ax1]; }
    if (noE) { var nx0 = noE.x0 - lh * 0.4, nx1 = izE ? izE.x0 - lh * 0.4 : noE.x0 + c.width * 0.22;
      // 1.6.17 tablo başlığı ("Numarası" sütunu): etiketin altındaki hücrenin dikey çizgileri bulunursa hücre sınırları kullanılır
      var hc = hucreSinir(c, (noE.x0 + noE.x1) / 2, yy0, yy1); if (hc) { nx0 = hc[0]; nx1 = hc[1]; out.tabloHucre = true; }
      var kn = kirp(c, nx0, yy0, nx1, yy1, 1); out.noKutu = [nx0, nx1];
      // 1.6.2: oylama — hücre 9 dikey kaydırmayla × (eğiklik, bölme açık/kapalı) okunur, en çok tekrarlanan 4 hane alınır
      var rx0 = Math.round(nx0), rx1 = Math.round(nx1), gy0 = Math.round(yy0) - 25, gh = Math.round(yy1 - yy0), genis = kirp(c, rx0, gy0, rx1, gy0 + 25 + gh + 10, 1), G = genis.getContext('2d').getImageData(0, 0, genis.width, genis.height), okumalar = [];
      [-20, -17, -14, -10, -7, -3, 0, 3, 6].forEach(function (dy) { var y0 = 25 + dy, data = new Uint8ClampedArray(G.width * gh * 4);
        for (var y = 0; y < gh && y0 + y < G.height; y++) data.set(G.data.subarray((y0 + y) * G.width * 4, (y0 + y + 1) * G.width * 4), y * G.width * 4);
        for (y = Math.max(0, G.height - y0); y < gh; y++) data.fill(255, y * G.width * 4, (y + 1) * G.width * 4);
        var im = { width: G.width, height: gh, data: data };
        [[true, true], [true, false], [false, true], [false, false]].forEach(function (v) { okumalar.push(noHucre(im, { egik: v[0], bol: v[1] })); }); });
      var tn = ((await is.recognize(kirp(c, nx0, yy0, nx1, yy1, Math.min(2, 60 / lh)))).data.text || ''), m4 = tn.match(/\d{4}/g); out.noOcr = m4 ? m4[m4.length - 1] : '';
      out.noEski = noHucreEski(kn.getContext('2d').getImageData(0, 0, kn.width, kn.height)).s; var r = noOyla(okumalar, (opt && opt.dis) || out.noOcr, out.noEski); out.no = r.s; out.noGuven = r.guven; out.noNeden = r.neden; out.oylar = r.oylar; out.noAdaylar = r.adaylar; out.noBelirsiz = r.belirsiz; }
    return out;
  }
  // 1.6.16 Etiket yanından Okul No / Sınıf: basılı "Sınıf-Numara:", "Number:", "Okul No:", "Numarası:" etiketi yazı tanımayla bulunur;
  // etiketin sağındaki (bir sonraki etikete kadar) alan, çizgi üstü dahil, el yazısı olarak okunur. Kurşun kalem (gri, silik) için gri + kontrast germe; renge bağlı değil.
  function germe(im, q) { q = q || 0.35; var n = im.width * im.height, d = im.data, g = new Float32Array(n), h = new Uint32Array(256), i;
    for (i = 0; i < n; i++) { var v = Math.min(d[4 * i], d[4 * i + 1], d[4 * i + 2]); g[i] = v; h[v | 0]++; }
    var t = 0, lo = 0, hi = 255; for (i = 0; i < 256; i++) { t += h[i]; if (t >= n * 0.01) { lo = i; break; } } t = 0; for (i = 255; i >= 0; i--) { t += h[i]; if (t >= n * q) { hi = i; break; } }
    if (hi - lo < 20) hi = lo + 20; var o = new Uint8ClampedArray(n * 4);
    for (i = 0; i < n; i++) { var u = Math.max(0, Math.min(255, (g[i] - lo) * 255 / (hi - lo))); u = u > 235 ? 255 : u; o[4 * i] = o[4 * i + 1] = o[4 * i + 2] = u; o[4 * i + 3] = 255; }
    return { width: im.width, height: im.height, data: o }; }
  // Alanda üstteki satırın (Ad Soyad) el yazısı ve basılı başlık da olabilir: koyu parçalar etiketlenir, merkezi etiket hizası [lo,hi] dışında kalan parça beyazlanır; sonra dikeyde kırpılır
  function satirSec(im, lo, hi) { var W = im.width, H = im.height, d = im.data, n = W * H, lab = new Int32Array(n).fill(-1), st = new Int32Array(n), o = new Uint8ClampedArray(d), a0 = H, z0 = -1, i;
    for (i = 0; i < n; i++) { if (lab[i] >= 0 || d[4 * i] >= 160) continue; var sp = 0, ymn = H, ymx = 0, uye = []; st[sp++] = i; lab[i] = i;
      while (sp) { var q = st[--sp], x = q % W, y = (q / W) | 0; uye.push(q); if (y < ymn) ymn = y; if (y > ymx) ymx = y;
        for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { var xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue; var t = yy * W + xx; if (lab[t] < 0 && d[4 * t] < 160) { lab[t] = i; st[sp++] = t; } } }
      var cy = (ymn + ymx) / 2 / H, tut = cy >= lo && cy <= hi;
      if (!tut) uye.forEach(function (q) { o[4 * q] = o[4 * q + 1] = o[4 * q + 2] = 255; }); else if (ymx - ymn > 2) { if (ymn < a0) a0 = ymn; if (ymx > z0) z0 = ymx; } }
    if (z0 < 0) return { width: W, height: H, data: o };
    var pd = Math.round((z0 - a0) * 0.15), a = Math.max(0, a0 - pd), z = Math.min(H - 1, z0 + pd);
    return { width: W, height: z - a + 1, data: o.slice(a * W * 4, (z + 1) * W * 4) }; }
  function nrm(t) { return String(t || '').toLocaleLowerCase('tr-TR').replace(/[ıi̇]/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c'); }
  async function etiketNo(c, opt) {
    opt = opt || {}; var is = await isciAl(), H0 = Math.round(c.height * 0.4), k = Math.min(5, 1800 / c.width), sayfa = kirp(c, 0, 0, c.width, c.height < 400 ? c.height : H0, k);
    await is.setParameters({ tessedit_pageseg_mode: '11' });
    var ws = kelimeler((await is.recognize(sayfa, {}, { blocks: true })).data).map(function (w) { return { t: w.t, n: nrm(w.t), c: w.c, x0: w.b.x0 / k, y0: w.b.y0 / k, x1: w.b.x1 / k, y1: w.b.y1 / k }; });
    // 1.6.17: küçük/silik etiket: bulunamazsa sayfa üstü kontrast gerilip büyütülerek yeniden aranır
    var etkRe = function (w) { return /number|numara|s[i1l]n[i1l]f-?num/.test(w.n); };
    if (!ws.some(etkRe)) { var k2 = Math.min(8, k * 1.8), s2 = kirp(c, 0, 0, c.width, c.height < 400 ? c.height : H0, k2), g2 = s2.getContext('2d'), gi = germe(g2.getImageData(0, 0, s2.width, s2.height), 0.5); g2.putImageData(new ImageData(gi.data, gi.width, gi.height), 0, 0);
      ws = ws.concat(kelimeler((await is.recognize(s2, {}, { blocks: true })).data).map(function (w) { return { t: w.t, n: nrm(w.t), c: w.c, x0: w.b.x0 / k2, y0: w.b.y0 / k2, x1: w.b.x1 / k2, y1: w.b.y1 / k2 }; })); }
    var ayni = function (a, b) { var h = Math.max(a.y1 - a.y0, 8); return Math.abs((a.y0 + a.y1) / 2 - (b.y0 + b.y1) / 2) < h * 0.8; };
    var formSatir = function (w) { return ws.some(function (q) { return q !== w && /^(s[i1l]n[i1l]f|ad|adi|soyad|soyadi|not|class|name)[:.]?$/.test(q.n) && ayni(q, w); }); };
    var etk = ws.filter(function (w) { return /^(number|numara|numaras|no)\b/.test(w.n.replace(/^.*-/, '')) && /[:.]$|number|numara/.test(w.n) || /s[i1l]n[i1l]f-?numara/.test(w.n) || /^no$/.test(w.n) && formSatir(w); });
    etk = etk.filter(function (w) { return !/^no$/.test(w.n.replace(/[:.]/g, '')) || ws.some(function (q) { return /^okul/.test(q.n) && ayni(q, w) && q.x1 <= w.x0 + 4; }) || formSatir(w); });
    var out = { etiket: etk.map(function (w) { return w.t; }) };
    if (!etk.length) { out.neden = 'Okul No etiketi bulunamadı'; return out; }
    var e = etk.sort(function (a, b) { return a.y0 - b.y0; })[0], lh = Math.max(10, e.y1 - e.y0), birlesik = /numara/.test(e.n) && !ws.some(function (q) { return /^okul/.test(q.n) && ayni(q, e) && q.x1 <= e.x0 + 4 && e.x0 - q.x1 < lh * 2; });
    // 1.6.21: "Sınıf / No:" etiketi (sınıf ve numara aynı alanda, ör. "11-F - 4623"): birleşik sayılır; alan sayfa sağına kadar uzar, baştaki sınıf yazısı atlanır
    var sinifNo = !birlesik && /^no\b/.test(e.n) && ws.some(function (q) { return /^s[i1l]n[i1l]f/.test(q.n) && ayni(q, e) && q.x1 <= e.x0 + 4 && e.x0 - q.x1 < lh * 2; }); if (sinifNo) { birlesik = true; var sq = ws.filter(function (q) { return /^s[i1l]n[i1l]f/.test(q.n) && ayni(q, e) && q.x1 <= e.x0 + 4; }).map(function (q) { return q.y1 - q.y0; }).sort(function (a, b) { return a - b; })[0]; if (sq && sq >= 8 && sq < lh * 0.8) lh = sq; }
    // sağdaki bir sonraki basılı etiket (Class:, Sınıf:, Tarih: ...) alanı sınırlar
    var son = ws.filter(function (w) { return ayni(w, e) && w.x0 > e.x1 + lh && /:$/.test(w.t) && /^[a-z]{3,}/.test(w.n) && w.c > 60; }).sort(function (a, b) { return a.x0 - b.x0; })[0];
    var x0 = e.x1 + lh * 0.2, x1 = son ? son.x0 - lh * 0.3 : sinifNo ? c.width * 0.98 : Math.min(c.width * 0.98, e.x1 + Math.max(lh * (birlesik ? 24 : 12), c.width * (birlesik ? 0.3 : 0))), y0 = Math.max(0, e.y0 - lh * (birlesik ? 1.5 : 1.0)), y1 = Math.min(c.height, e.y1 + lh * (birlesik ? 1.3 : 0.45)), lo = ((e.y0 + e.y1) / 2 - lh * 0.7 - y0) / (y1 - y0), hi = (e.y1 + lh * 0.9 - y0) / (y1 - y0);
    // 1.6.21: "Sınıf / No" satırında el yazısı noktalı çizginin üstünde, etiketten yukarı taşar; alttaki "Aldığı puan" satırı alınmaz
    if (sinifNo) { var cy = (e.y0 + e.y1) / 2; y0 = Math.max(0, cy - lh * 2.8); y1 = Math.min(c.height, cy + lh * 0.85); lo = -1; hi = 2; }
    var kr = kirp(c, x0, y0, x1, y1, Math.min(3, Math.max(1, 70 / (y1 - y0)))), g = kr.getContext('2d'), ham = g.getImageData(0, 0, kr.width, kr.height), im = germe(ham);
    if (birlesik) im = satirSec(im, lo, hi);
    // 1.6.17: kurşun kalem için farklı kontrast eşikleriyle ek oylar
    var ekIm = (kok.NO_Q || [0.2, 0.55]).map(function (q) { var m = germe(ham, q); return birlesik ? satirSec(m, lo, hi) : m; });
    // 1.6.17: silik/ince kalem: orta griler koyulaştırılır (u^2.5) ve ek oy olarak okunur
    var koyu = germe(ham); for (var kq = 0; kq < koyu.data.length; kq += 4) { var kv = 255 * Math.pow(koyu.data[kq] / 255, 2.5); koyu.data[kq] = koyu.data[kq + 1] = koyu.data[kq + 2] = kv > 225 ? 255 : kv; }
    ekIm.push(birlesik ? satirSec(koyu, lo, hi) : koyu);
    if (kok.ETK_DEBUG) kok.ETK_DEBUG(germeCanvas(im));
    out.dbg = [Math.round(e.x0), Math.round(e.y0), Math.round(e.x1), Math.round(e.y1), Math.round(y0), Math.round(y1), lo.toFixed(2), hi.toFixed(2), c.width, c.height].join(",");
    out.kutu = { x: x0 / c.width, y: y0 / c.height, w: (x1 - x0) / c.width, h: (y1 - y0) / c.height };
    var okumalar = [], uz = opt.uzunluk || 4, W = im.width, Hh = im.height;
    [im].concat(ekIm).forEach(function (im, ii) { var W = im.width, Hh = im.height;
    (ii ? [0, -0.08] : [0, -0.08, 0.08, -0.15]).forEach(function (dy) { var s = Math.round(dy * Hh), d = new Uint8ClampedArray(W * Hh * 4).fill(255);
      for (var y = 0; y < Hh; y++) { var sy = y + s; if (sy < 0 || sy >= Hh) continue; d.set(im.data.subarray(sy * W * 4, (sy + 1) * W * 4), y * W * 4); }
      var m = { width: W, height: Hh, data: d };
      [[true, true], [true, false], [false, true], [false, false]].forEach(function (v) { var r = noHucre(m, { egik: v[0], bol: v[1], uzunluk: uz }); if (r.s && birlesik && r.s.length > uz) r.s = r.s.slice(-uz); okumalar.push(r); }); }); });
    // yazı tanıma (dış oy)
    var ps = germeCanvas(im); await is.setParameters({ tessedit_pageseg_mode: '7', tessedit_char_whitelist: '' });
    var tx = (await is.recognize(ps)).data.text || ''; out.ham = tx.trim();
    var t2 = tx.replace(/[oO]/g, '0').replace(/[lI|]/g, '1'), dz = (birlesik ? t2.replace(/^\D*\d{1,2}\s*[-\/.,_~]?\s*[A-Za-zÇĞİÖŞÜçğıöşü]\b/, ' ') : t2).match(/\d{3,6}/g), dis = dz ? dz[dz.length - 1] : '';
    var r = noOyla(okumalar, dis, ''); if (!r.s && dis && dis.length === uz) r = { s: dis, guven: 50, neden: 'yalnız yazı tanıma', oylar: '', adaylar: [dis], belirsiz: false }; out.no = r.s; out.noGuven = r.guven; out.noNeden = r.neden; out.oylar = r.oylar; out.noAdaylar = r.adaylar; out.noBelirsiz = r.belirsiz;
    if (birlesik) { var m = nrm(tx).replace(/[o]/g, '0').replace(/[il|]/g, '1').replace(/(^|\s)1z/g, '$112').match(/\b(9|10|11|12)\s*[-\/.,_~ ]?\s*([a-z])\b/); if (m) out.sinif = m[1] + '-' + m[2].toLocaleUpperCase('tr-TR'); }
    return out;
  }
  function germeCanvas(im) { var k = document.createElement('canvas'); k.width = im.width; k.height = im.height; k.getContext('2d').putImageData(new ImageData(im.data, im.width, im.height), 0, 0); return k; }
  // 1.6.3: işaretli Okul No alanı için 36 oylu okuma (tarama ekranı kağıt akışı). img: ImageData sayfa, a: {x,y,w,h} oran
  function noOku(img, a, dis) {
    var W = img.width, H = img.height, x0 = Math.max(0, Math.round(a.x * W)), x1 = Math.min(W, Math.round((a.x + a.w) * W)), y0 = Math.round(a.y * H), gh = Math.max(4, Math.round(a.h * H)), w = x1 - x0, okumalar = [];
    if (w < 8) return { s: '', guven: 0, neden: 'boş', oylar: '' };
    [-20, -17, -14, -10, -7, -3, 0, 3, 6].forEach(function (dy) { var k = Math.round(dy * gh / 54), d = new Uint8ClampedArray(w * gh * 4).fill(255);
      for (var y = 0; y < gh; y++) { var sy = y0 + k + y; if (sy < 0 || sy >= H) continue; d.set(img.data.subarray((sy * W + x0) * 4, (sy * W + x1) * 4), y * w * 4); }
      var im = { width: w, height: gh, data: d };
      [[true, true], [true, false], [false, true], [false, false]].forEach(function (v) { okumalar.push(noHucre(im, { egik: v[0], bol: v[1] })); }); });
    var eski = noHucreEski({ width: w, height: gh, data: (function () { var d = new Uint8ClampedArray(w * gh * 4); for (var y = 0; y < gh && y0 + y < H; y++) d.set(img.data.subarray(((y0 + y) * W + x0) * 4, ((y0 + y) * W + x1) * 4), y * w * 4); return d; })() }).s;
    return noOyla(okumalar, dis || '', eski);
  }
  // 1.6.17: yan çevrilmiş (90°) taranmış kâğıt/dilekçe: etiket bulunamazsa sayfa iki yöne döndürülüp etiket (yan) ve form (alt hücre) okuması denenir
  function dondurC(c, yon) { var k = document.createElement('canvas'); k.width = c.height; k.height = c.width; var x = k.getContext('2d', { willReadFrequently: true });
    if (yon < 0) { x.translate(0, k.height); x.rotate(-Math.PI / 2); } else { x.translate(k.width, 0); x.rotate(Math.PI / 2); } x.drawImage(c, 0, 0); return k; }
  async function noBul(c, opt) { opt = opt || {}; var son = null, adim = [[0, 'e'], [0, 'f'], [-1, 'f'], [-1, 'e'], [1, 'f'], [1, 'e']];
    for (var i = 0; i < adim.length; i++) { var a = adim[i], cc = a[0] ? dondurC(c, a[0]) : c, f;
      try { f = a[1] === 'e' ? await etiketNo(cc, opt) : await formKimlik(cc, opt); } catch (e) { f = { neden: e.message }; }
      if (f && f.no && f.no.length === (opt.uzunluk || 4)) { f.yon = a[0]; f.tur = a[1]; return f; } if (!son && f && f.no) son = f; }
    return son || { neden: 'Okul No etiketi bulunamadı' }; }
  var api = { yenidenOku: yenidenOku, murekkep: murekkep, kirmiziKoyu: kirmiziKoyu, halkaSil: halkaSil, noMesafe: noMesafe, noBul: noBul, dondurC: dondurC, etiketNo: etiketNo, germe: germe, noOku: noOku, noHucreEski: noHucreEski, noOyla: noOyla, NOAYAR: NOAYAR, formKimlik: formKimlik, noHucre: noHucre, egikDuz: egikDuz, kirmiziKoyu: kirmiziKoyu, murekkep: murekkep, puanBul: puanBul, ogrenciEsle: ogrenciEsle, benzer: benzer, maskele: maskele, BOLGE: BOLGE, AYAR: AYAR, adaylar: adaylar };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  kok.OtoBul = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
