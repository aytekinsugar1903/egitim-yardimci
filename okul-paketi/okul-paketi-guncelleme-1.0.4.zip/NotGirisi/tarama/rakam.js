// v2.3.15: El yazısı rakam tanıyıcı (tamamen yerel; küçük CNN, MNIST ile eğitilmiş, ağırlıklar lib/rakam.bin).
// Renkli mürekkep maskesinden rakamları ayırır (bağlı bileşenler, bitişik rakamı genişlikten bölme), her rakamı sınıflandırır,
// gün/ay adaylarını okul takvimine göre puanlar. Hiçbir veri dışarı gönderilmez.
(function (kok) {
  let W = null;
  const BOY = [288, 32, 9216, 32, 18432, 64, 36864, 64, 401408, 128, 1280, 10];
  function yukle(buf) { const f = new Float32Array(buf); let o = 0; W = BOY.map((n) => { const a = f.subarray(o, o + n); o += n; return a; }); return true; }
  const hazir = () => !!W;
  function conv(x, C, H, w, b, K) { // 3x3, pad 1, relu (v2.3.21: dolgulu giriş + 9 dokunuş tek geçişte; ~3 kat hızlı, sonuç aynı)
    const P = H + 2, xp = new Float32Array(C * P * P);
    for (let c = 0; c < C; c++) for (let y = 0; y < H; y++) xp.set(x.subarray(c * H * H + y * H, c * H * H + y * H + H), c * P * P + (y + 1) * P + 1);
    const o = new Float32Array(K * H * H);
    for (let k = 0; k < K; k++) { const ob = k * H * H; o.fill(b[k], ob, ob + H * H);
      for (let c = 0; c < C; c++) { const wb = (k * C + c) * 9, w0 = w[wb], w1 = w[wb + 1], w2 = w[wb + 2], w3 = w[wb + 3], w4 = w[wb + 4], w5 = w[wb + 5], w6 = w[wb + 6], w7 = w[wb + 7], w8 = w[wb + 8], xb = c * P * P;
        for (let y = 0; y < H; y++) { const r0 = xb + y * P, r1 = r0 + P, r2 = r1 + P, oo = ob + y * H;
          for (let xx = 0; xx < H; xx++) o[oo + xx] += w0 * xp[r0 + xx] + w1 * xp[r0 + xx + 1] + w2 * xp[r0 + xx + 2] + w3 * xp[r1 + xx] + w4 * xp[r1 + xx + 1] + w5 * xp[r1 + xx + 2] + w6 * xp[r2 + xx] + w7 * xp[r2 + xx + 1] + w8 * xp[r2 + xx + 2]; } } }
    for (let i = 0; i < o.length; i++) if (o[i] < 0) o[i] = 0; return o;
  }
  function havuz(x, C, H) { const h = H >> 1, o = new Float32Array(C * h * h);
    for (let c = 0; c < C; c++) for (let y = 0; y < h; y++) for (let xx = 0; xx < h; xx++) { const b = c * H * H + 2 * y * H + 2 * xx;
      o[c * h * h + y * h + xx] = Math.max(x[b], x[b + 1], x[b + H], x[b + H + 1]); } return o; }
  const ONB = new Map(); // v2.3.21: aynı 28x28 görüntü tekrar sınıflandırılmaz
  function siniflandir(img28) {
    let h = 2166136261; for (let i = 0; i < 784; i++) { h ^= Math.round(img28[i] * 255); h = Math.imul(h, 16777619); }
    const k = h >>> 0, o = ONB.get(k); if (o) return o; const r = siniflandir0(img28); if (ONB.size > 5000) ONB.clear(); ONB.set(k, r); return r; }
  function siniflandir0(img28) {
    let x = conv(img28, 1, 28, W[0], W[1], 32); x = havuz(conv(x, 32, 28, W[2], W[3], 32), 32, 28);
    x = conv(x, 32, 14, W[4], W[5], 64); x = havuz(conv(x, 64, 14, W[6], W[7], 64), 64, 14);
    const h = new Float32Array(128); for (let j = 0; j < 128; j++) { let s = W[9][j]; const r = j * 3136; for (let i = 0; i < 3136; i++) s += W[8][r + i] * x[i]; h[j] = s > 0 ? s : 0; }
    const z = new Float32Array(10); let mx = -1e9; for (let j = 0; j < 10; j++) { let s = W[11][j]; for (let i = 0; i < 128; i++) s += W[10][j * 128 + i] * h[i]; z[j] = s; mx = Math.max(mx, s); }
    let t = 0; for (let j = 0; j < 10; j++) { z[j] = Math.exp(z[j] - mx); t += z[j]; } for (let j = 0; j < 10; j++) z[j] /= t; return z;
  }
  // m: {w,h,d:Uint8Array} ikili maske -> 28x28 MNIST biçimi
  function mnist(m) {
    let x0 = m.w, y0 = m.h, x1 = -1, y1 = -1;
    for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) if (m.d[y * m.w + x]) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 < 0) return null;
    let w = x1 - x0 + 1, h = y1 - y0 + 1, k = Math.max(1, Math.round(Math.max(w, h) / 28));
    let a = new Float32Array(w * h); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) a[y * w + x] = m.d[(y + y0) * m.w + x + x0];
    if (k > 1) { const b = new Float32Array(w * h); // genişlet (kalem kalınlığı ~ MNIST); cv2.dilate kxk, çapa merkezde
      const r0 = Math.floor(k / 2); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { let v = 0; for (let dy = -r0; dy < k - r0 && !v; dy++) for (let dx = -r0; dx < k - r0; dx++) { const yy = y + dy, xx = x + dx; if (yy >= 0 && yy < h && xx >= 0 && xx < w && a[yy * w + xx]) { v = 1; break; } } b[y * w + x] = v; } a = b; }
    const s = 20 / Math.max(w, h), nw = Math.max(1, Math.round(w * s)), nh = Math.max(1, Math.round(h * s)), r = new Float32Array(nw * nh);
    for (let y = 0; y < nh; y++) for (let x = 0; x < nw; x++) { // alan ortalaması
      const sx0 = x * w / nw, sx1 = (x + 1) * w / nw, sy0 = y * h / nh, sy1 = (y + 1) * h / nh; let t = 0, n = 0;
      for (let yy = Math.floor(sy0); yy < Math.ceil(sy1); yy++) for (let xx = Math.floor(sx0); xx < Math.ceil(sx1); xx++) { const f = (Math.min(xx + 1, sx1) - Math.max(xx, sx0)) * (Math.min(yy + 1, sy1) - Math.max(yy, sy0)); t += a[yy * w + xx] * f; n += f; }
      r[y * nw + x] = n ? t / n : 0; }
    const t = new Float32Array(784), oy = (28 - nh) >> 1, ox = (28 - nw) >> 1; let sm = 0, cx = 0, cy = 0;
    for (let y = 0; y < nh; y++) for (let x = 0; x < nw; x++) { const v = r[y * nw + x]; t[(y + oy) * 28 + x + ox] = v; if (v > 0) { sm++; cx += x + ox; cy += y + oy; } }
    const kx = sm ? 14 - cx / sm : 0, ky = sm ? 14 - cy / sm : 0, u = new Float32Array(784);
    for (let y = 0; y < 28; y++) for (let x = 0; x < 28; x++) { // kütle merkezini ortala (bilinear)
      const sx = x - kx, sy = y - ky, ix = Math.floor(sx), iy = Math.floor(sy), fx = sx - ix, fy = sy - iy, g = (xx, yy) => (xx >= 0 && xx < 28 && yy >= 0 && yy < 28 ? t[yy * 28 + xx] : 0);
      u[y * 28 + x] = g(ix, iy) * (1 - fx) * (1 - fy) + g(ix + 1, iy) * fx * (1 - fy) + g(ix, iy + 1) * (1 - fx) * fy + g(ix + 1, iy + 1) * fx * fy; }
    const G = [0.1065, 0.7870, 0.1065], o = new Float32Array(784), q = new Float32Array(784); // GaussianBlur 3x3 sigma .5
    for (let y = 0; y < 28; y++) for (let x = 0; x < 28; x++) { let s2 = 0; for (let d = -1; d <= 1; d++) { const xx = Math.min(27, Math.max(0, x + d)); s2 += G[d + 1] * u[y * 28 + xx]; } q[y * 28 + x] = s2; }
    for (let y = 0; y < 28; y++) for (let x = 0; x < 28; x++) { let s2 = 0; for (let d = -1; d <= 1; d++) { const yy = Math.min(27, Math.max(0, y + d)); s2 += G[d + 1] * q[yy * 28 + x]; } o[y * 28 + x] = Math.min(1, s2 * 1.3); }
    return o;
  }
  // 7x7 kapama: tablo çizgisinin kestiği kalem izini etiketlemede birleştirir (pikseller yine gerçek mürekkep)
  function kapat(m, k = 7) {
    const r = k >> 1, gec = (src, yatay, maxMi) => { const o = new Uint8Array(src.length);
      for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) { let v = maxMi ? 0 : 1;
        for (let d = -r; d <= r; d++) { const xx = yatay ? x + d : x, yy = yatay ? y : y + d; const q = xx < 0 || yy < 0 || xx >= m.w || yy >= m.h ? (maxMi ? 0 : 1) : src[yy * m.w + xx]; if (maxMi ? q : !q) { v = maxMi ? 1 : 0; break; } }
        o[y * m.w + x] = v; } return o; };
    return gec(gec(gec(gec(m.d, true, true), false, true), true, false), false, false);
  }
  // bağlı bileşenler (8-komşu)
  function bilesenler(m, kopru) {
    if (kopru) { const k = kapat(m), r = bilesenler({ w: m.w, h: m.h, d: k }); for (let i = 0; i < r.lab.length; i++) if (!m.d[i]) r.lab[i] = 0;
      const a = new Map(); for (let i = 0; i < r.lab.length; i++) if (r.lab[i]) a.set(r.lab[i], (a.get(r.lab[i]) || 0) + 1);
      r.cs = r.cs.map((c) => ({ ...c, a: a.get(c.i) || 0 })).filter((c) => c.a >= 6); return r; }
    const lab = new Int32Array(m.w * m.h), out = []; let n = 0; const st = [];
    for (let i = 0; i < lab.length; i++) if (m.d[i] && !lab[i]) {
      n++; let x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1, a = 0; st.push(i); lab[i] = n;
      while (st.length) { const p = st.pop(), x = p % m.w, y = (p / m.w) | 0; a++; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= m.w || yy >= m.h) continue; const q = yy * m.w + xx; if (m.d[q] && !lab[q]) { lab[q] = n; st.push(q); } } }
      out.push({ i: n, x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1, a });
    }
    return { cs: out.filter((c) => c.a >= 6), lab };
  }
  function parcaMaske(m, lab, ids, x0, x1) { // ids bileşenlerinin [x0,x1) kesiti, dikey kırpılmış
    const w = x1 - x0, d = new Uint8Array(w * m.h); let ya = m.h, yb = -1;
    for (let y = 0; y < m.h; y++) for (let x = 0; x < w; x++) if (ids.includes(lab[y * m.w + x + x0])) { d[y * w + x] = 1; if (y < ya) ya = y; if (y > yb) yb = y; }
    if (yb < 0) return { w, h: 1, d: new Uint8Array(w) };
    return { w, h: yb - ya + 1, d: d.slice(ya * w, (yb + 1) * w) };
  }
  // Bir sayı grubundaki rakamlar -> [{olas:Float32Array(10)}...] (bitişik geniş parça en iyi kesimden bölünür)
  function grupOku(m, lab, comps) {
    if (!comps.length) return [];
    const H = Math.max(...comps.map((c) => c.h));
    let pr = comps.filter((c) => !(c.a < 8 || (c.h < 0.3 * H && c.w < 0.3 * H))).map((c) => ({ x: c.x, xe: c.x + c.w, ids: [c.i], h: c.h, w: c.w, y: c.y }));
    { const bk = pr.filter((p) => p.h >= 0.45 * H), alt = Math.max(...bk.map((p) => p.y + p.h)); pr = pr.filter((p) => !(p.h < 0.35 * H && p.w > 4 * p.h && p.y >= alt - 0.08 * H)); } // 1.5.1: altı çizili puan: rakamların altındaki ince yatay çizgi rakam değildir
    const buyuk = pr.filter((p) => p.h >= 0.45 * H);
    pr = pr.filter((p) => !(p.w > 2 * p.h && p.h < 0.35 * H && !buyuk.some((b) => Math.min(b.xe, p.xe) - Math.max(b.x, p.x) > 2))).sort((a, b) => a.x - b.x);
    const gr = [];
    for (const p of pr) { const s = gr[gr.length - 1];
      if (s) { const ort = Math.min(s.xe, p.xe) - Math.max(s.x, p.x);
        if (ort > 0.5 * Math.min(p.xe - p.x, s.xe - s.x) || (ort > 2 && (p.h < 0.45 * H || s.h < 0.45 * H))) { s.xe = Math.max(s.xe, p.xe); s.ids.push(...p.ids); s.h = Math.max(s.h, p.h); continue; } }
      gr.push({ ...p, ids: [...p.ids] }); }
    // Hipotezler: bölmesiz + geniş parçaların en iyi kesimden bölündüğü alternatifler (karar tarih puanlamasında verilir)
    const rak = [];
    for (const g of gr) {
      const r = parcaMaske(m, lab, g.ids, g.x, g.xe), tek = mnist(r); if (!tek) continue;
      const it = { olas: siniflandir(tek), img: tek };
      if (r.w > 0.75 * r.h && r.w > 10) {
        let en = null;
        for (let f = 0.3; f <= 0.71; f += 0.1) { const c = Math.round(r.w * f);
          const ma = mnist(parcaMaske(m, lab, g.ids, g.x, g.x + c)), mb = mnist(parcaMaske(m, lab, g.ids, g.x + c, g.xe)); if (!ma || !mb) continue;
          const pa = siniflandir(ma), pb = siniflandir(mb), sk = Math.max(...pa) * Math.max(...pb); if (!en || sk > en.sk) en = { sk, pa, pb, ma, mb }; }
        if (en) { it.bol = [{ olas: en.pa, img: en.ma }, { olas: en.pb, img: en.mb }]; it.bolW = r.w > 1.15 * r.h ? 0.9 : 0.5; }
        if (r.w > 1.9 * r.h) { // v2.3.16: üç bitişik rakam (el yazısı "705" gibi)
          let e3 = null;
          for (let f1 = 0.25; f1 <= 0.45; f1 += 0.1) for (let f2 = f1 + 0.25; f2 <= 0.78; f2 += 0.1) { const c1 = Math.round(r.w * f1), c2 = Math.round(r.w * f2);
            const P = [[g.x, g.x + c1], [g.x + c1, g.x + c2], [g.x + c2, g.xe]].map(([u, v]) => mnist(parcaMaske(m, lab, g.ids, u, v))); if (P.some((q) => !q)) continue;
            const O = P.map(siniflandir), sk = O.reduce((t, o) => t * Math.max(...o), 1); if (!e3 || sk > e3.sk) e3 = { sk, O, P }; }
          if (e3) it.bol3 = e3.O.map((o, k) => ({ olas: o, img: e3.P[k] }));
        }
      }
      rak.push(it);
    }
    const bolunebilir = rak.map((r, i) => (r.bol ? i : -1)).filter((i) => i >= 0), hip = [];
    for (let mask = 0; mask < 1 << Math.min(2, bolunebilir.length); mask++) {
      let w = 1; const L = [];
      rak.forEach((r, i) => { const k = bolunebilir.indexOf(i); if (k >= 0 && k < 2 && mask & (1 << k)) { L.push(...r.bol); w *= r.bolW; } else { L.push({ olas: r.olas, img: r.img }); if (r.bol) w *= r.bolW > 0.8 && rak.length < 2 ? 0.5 : 1; } });
      hip.push({ w, rak: L });
    }
    rak.forEach((r, i) => { if (r.bol3) hip.push({ w: 0.9, rak: [...rak.slice(0, i).map((q) => ({ olas: q.olas, img: q.img })), ...r.bol3, ...rak.slice(i + 1).map((q) => ({ olas: q.olas, img: q.img }))] }); });
    // Ayrı yazılmış ama x'te örtüşen rakamlar (ör. "2"nin kuyruğu "9"un altına giriyor): her büyük bileşen ayrı rakam
    const bb = pr.filter((p) => p.h >= 0.45 * H).sort((a, b) => a.x - b.x);
    if (bb.length >= 2 && bb.length !== hip[0].rak.length) {
      const L = [];
      for (const p of bb) { const ids = [p.i ?? p.ids[0], ...pr.filter((q) => q.h < 0.45 * H && Math.min(q.xe, p.xe) - Math.max(q.x, p.x) > 0 && bb.filter((z) => Math.min(q.xe, z.xe) - Math.max(q.x, z.x) > 0)[0] === p).map((q) => q.ids[0])];
        const t = mnist(parcaMaske(m, lab, ids, p.x, p.xe)); if (t) L.push({ olas: siniflandir(t), img: t }); }
      if (L.length === bb.length) hip.push({ w: 0.9, rak: L });
    }
    return hip;
  }
  // Sayı adayları {s, p}: hipotez ağırlığı x rakam olasılıkları; uzunluk 1..enCok
  function adaylar(hip, enCok = 2) {
    const out = [];
    for (const h of hip) {
      if (!h.rak.length || h.rak.length > enCok) continue;
      let L = [{ s: "", p: h.w }];
      for (const r of h.rak) { const top = [...r.olas].map((p, d) => ({ d, p })); // 1-2 haneli: tüm olasılıklar (takvim önceliği seçer)
        L = L.flatMap((x) => top.map((t) => ({ s: x.s + t.d, p: x.p * t.p }))); }
      out.push(...L);
    }
    return out;
  }
  const enIyi = (hip) => { const h = [...hip].sort((a, b) => b.w - a.w)[0]; return h ? h.rak.map((r) => r.olas.indexOf(Math.max(...r.olas))).join("") : ""; };
  function _eski(rakamlar, enCok = 2) { // (kullanılmıyor)
    let L = [{ s: "", p: 1 }];
    for (const r of rakamlar.slice(-enCok)) { const top = [...r.olas].map((p, d) => ({ d, p })).sort((a, b) => b.p - a.p).slice(0, 3);
      L = L.flatMap((x) => top.map((t) => ({ s: x.s + t.d, p: x.p * t.p }))).sort((a, b) => b.p - a.p).slice(0, 12); }
    return L.filter((x) => x.s);
  }
  // Tarih hücresi (yalnız renkli mürekkep maskesi) -> {gun, ay, guven, ham} | null
  // Boş hücreyi iptal eden eğik çizgi: ince, uzun, eğik bileşen ("1" dik olduğu için etkilenmez)
  const capraz = (c, rowH) => c.h > 0.7 * rowH && c.w > 0.45 * c.h && c.a / (c.w * c.h) < 0.12;
  // m: satırın üstünü/altını da kapsayan maske; oy0..oy1 satır bandı (m içinde)
  function tarihOku(m, rowH, opt = {}) {
    const { cs, lab } = bilesenler(m, true), oy0 = opt.oy0 ?? 0, oy1 = opt.oy1 ?? m.h;
    const ic = cs.filter((c) => c.h > rowH * 0.18 && c.y + c.h / 2 >= oy0 - 3 && c.y + c.h / 2 <= oy1 + 3 && c.h < 1.6 * rowH && !capraz(c, rowH));
    if (!ic.length) return null;
    if (ic.some((c) => c.w > 1.8 * rowH && c.a / (c.w * c.h) > 0.22)) return { iptal: true };
    const s = [...ic].sort((a, b) => a.x - b.x); if (s.length < 2) return null;
    let bi = 0, bg = -1; for (let i = 0; i < s.length - 1; i++) { const g = s[i + 1].x - Math.max(...s.slice(0, i + 1).map((c) => c.x + c.w)); if (g > bg) { bg = g; bi = i; } }
    const g1 = s.slice(0, bi + 1), g2 = s.slice(bi + 1);
    const R1 = grupOku(m, lab, g1), R2 = grupOku(m, lab, g2); if (!R1.length || !R2.length) return null;
    const A = adaylar(R1), B = adaylar(R2), yil = opt.yil || new Date().getFullYear(), bugun = opt.bugun || new Date();
    const okul0 = new Date(bugun.getMonth() >= 7 ? bugun.getFullYear() : bugun.getFullYear() - 1, 8, 1), okul1 = new Date(okul0.getFullYear() + 1, 5, 30);
    const L = [];
    for (const a of A) for (const b of B) { const g = +a.s, ay = +b.s; if (!(g >= 1 && g <= 31 && ay >= 1 && ay <= 12)) continue;
      const t = new Date(ay >= 8 ? okul0.getFullYear() : okul0.getFullYear() + 1, ay - 1, g); if (t.getDate() !== g) continue;
      let p = a.p * b.p; if (t < okul0 || t > okul1) p *= 0.02; if (t.getDay() % 6 === 0) p *= 0.3;
      if (t > new Date(+bugun + 10 * 864e5) || t < new Date(+bugun - 75 * 864e5)) p *= 0.01;
      L.push({ p, g, ay, y: t.getFullYear() }); }
    if (!L.length) return null;
    L.sort((a, b) => b.p - a.p); const top = L.reduce((s2, x) => s2 + x.p, 0), e = L[0];
    const ham = enIyi(R1) + "/" + enIyi(R2);
    const et = new Date(e.y, e.ay - 1, e.g), pencere = et >= okul0 && et <= okul1 && et <= new Date(+bugun + 10 * 864e5) && et >= new Date(+bugun - 75 * 864e5);
    return { gun: e.g, ay: e.ay, yil: e.y || yil, guven: Math.round(100 * Math.min(1, e.p / top) * Math.min(1, Math.sqrt(e.p) / 0.7) * (pencere ? 1 : 0.1)), ham };
  }
  // Numara alanı: rakam benzeri en uzun ardışık grup (3-5 rakam)
  function numaraOku(m) {
    const { cs, lab } = bilesenler(m); if (!cs.length) return null;
    const H = Math.max(...cs.map((c) => c.h)), s = cs.filter((c) => c.h > 0.4 * H).sort((a, b) => a.x - b.x);
    const gruplar = []; let g = [];
    for (const c of s) { const son = g[g.length - 1]; if (son && c.x - (son.x + son.w) > 0.9 * H) { gruplar.push(g); g = []; } g.push(c); }
    if (g.length) gruplar.push(g);
    let en = null;
    for (const gr of gruplar) { const R = grupOku(m, lab, gr.concat(cs.filter((c) => c.h <= 0.4 * H && c.x >= gr[0].x && c.x <= gr[gr.length - 1].x + gr[gr.length - 1].w)));
      for (const h of R) { if (h.rak.length < 3 || h.rak.length > 5) continue;
        const no = h.rak.map((r) => r.olas.indexOf(Math.max(...r.olas))).join(""), p = h.w * h.rak.reduce((t, r) => t * Math.max(...r.olas), 1) ** (1 / h.rak.length);
        if (!en || p > en.guven / 100) en = { no, guven: Math.round(100 * p) }; } }
    return en;
  }
  // canvas bölgesinden renkli mürekkep maskesi (veli_tarama.js murekkep() ile aynı renk kuralı)
  function maskeAl(src, x0, y0, x1, y1) {
    x0 = Math.max(0, Math.round(x0)); y0 = Math.max(0, Math.round(y0)); x1 = Math.min(src.width, Math.round(x1)); y1 = Math.min(src.height, Math.round(y1));
    const w = x1 - x0, h = y1 - y0; if (w < 4 || h < 4) return null;
    const v = src.getContext("2d").getImageData(x0, y0, w, h).data, d = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) { const r = v[4 * i], g = v[4 * i + 1], b = v[4 * i + 2], mx = Math.max(r, g, b), mn = Math.min(r, g, b); d[i] = mx - mn > 45 && mn < 200 ? 1 : 0; }
    return { w, h, d };
  }
  const api = { yukle, hazir, siniflandir, mnist, bilesenler, grupOku, tarihOku, numaraOku, maskeAl };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  kok.ElRakam = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
