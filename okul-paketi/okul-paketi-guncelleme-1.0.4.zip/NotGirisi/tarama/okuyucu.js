/* El yazısı puan okuyucu (Not Girişi Asistanı 1.2.0). Tamamen yerel: görüntü bu bilgisayarda işlenir, hiçbir yere gönderilmez.
   Rakam tanıma: e-Okul Asistanı Pro'daki el yazısı rakam modeli (rakam.js + rakam.bin). */
(function (kok) {
  'use strict';
  var R = kok.ElRakam || (typeof require !== 'undefined' ? require('./rakam.js') : null);
  // Şablon ölçüleri (mm, A4 dikey). Puan tablosu sayfanın üst bandındadır; altı sınav metnine ayrılabilir.
  var S = { gen: 210, yuk: 297, isaret: [[12, 12], [198, 12], [12, 120], [198, 120]], isaretBoy: 8,
    no: { x: 60, y: 27, w: 12, h: 14, ara: 1, adet: 6 },
    soru: { x: 18, y0: 56, satirAra: 32, w: 16, h: 16, adim: 17.6, satirda: 10 } };
  function soruKutusu(j) { var s = S.soru, r = Math.floor(j / s.satirda), c = j % s.satirda; return { x: s.x + c * s.adim, y: s.y0 + r * s.satirAra, w: s.w, h: s.h }; }
  function noKutusu(k) { var n = S.no; return { x: n.x + k * (n.w + n.ara), y: n.y, w: n.w, h: n.h }; }
  function gri(img) { var n = img.width * img.height, g = new Float32Array(n), d = img.data; for (var i = 0; i < n; i++) g[i] = 0.299 * d[4 * i] + 0.587 * d[4 * i + 1] + 0.114 * d[4 * i + 2]; return g; }
  // Uyarlamalı eşik (gölgeli telefon fotoğrafı için): yerel ortalamadan belirgin koyu olan piksel mürekkep
  function esikle(g, w, h, pen, fark) {
    var I = new Float64Array((w + 1) * (h + 1));
    for (var y = 0; y < h; y++) { var s = 0; for (var x = 0; x < w; x++) { s += g[y * w + x]; I[(y + 1) * (w + 1) + x + 1] = I[y * (w + 1) + x + 1] + s; } }
    var m = new Uint8Array(w * h), r = pen >> 1;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) { var x0 = Math.max(0, x - r), y0 = Math.max(0, y - r), x1 = Math.min(w, x + r + 1), y1 = Math.min(h, y + r + 1);
      var ort = (I[y1 * (w + 1) + x1] - I[y0 * (w + 1) + x1] - I[y1 * (w + 1) + x0] + I[y0 * (w + 1) + x0]) / ((x1 - x0) * (y1 - y0));
      m[y * w + x] = g[y * w + x] < ort - fark && g[y * w + x] < 170 ? 1 : 0; }
    return m;
  }
  // Köşe işaretleri: dolu, kareye yakın koyu bileşenler
  function isaretBul(img) {
    var k = Math.min(1, 900 / Math.max(img.width, img.height)), w = Math.max(1, Math.round(img.width * k)), h = Math.max(1, Math.round(img.height * k));
    var g0 = gri(img), g = new Float32Array(w * h);
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) g[y * w + x] = g0[Math.min(img.height - 1, Math.floor(y / k)) * img.width + Math.min(img.width - 1, Math.floor(x / k))];
    var m = new Uint8Array(w * h); for (var i = 0; i < m.length; i++) m[i] = g[i] < 110 ? 1 : 0;
    var b = R.bilesenler({ w: w, h: h, d: m }), ad = [];
    b.cs.forEach(function (c) { var oran = c.w / c.h, dol = c.a / (c.w * c.h);
      if (oran > 0.6 && oran < 1.6 && dol > 0.75 && c.w > w * 0.015 && c.w < w * 0.12) ad.push({ x: (c.x + c.w / 2) / k, y: (c.y + c.h / 2) / k, a: c.a / (k * k), s: c.w / k }); });
    if (ad.length < 4) return null;
    // Aynı boyda 4 işaret seç (en büyük kümeden), sonra köşelere ata
    ad.sort(function (a, b) { return b.a - a.a; });
    var en = null;
    for (var i0 = 0; i0 < Math.min(ad.length, 12); i0++) { var ref = ad[i0].a, grup = ad.filter(function (q) { return q.a > ref * 0.55 && q.a < ref * 1.8; }); if (grup.length >= 4 && (!en || grup.length < en.length || (grup.length === en.length && ref > en[0].a))) en = grup; }
    if (!en) return null;
    var tl = en.reduce(function (a, b) { return a.x + a.y < b.x + b.y ? a : b; }), br = en.reduce(function (a, b) { return a.x + a.y > b.x + b.y ? a : b; }),
        tr = en.reduce(function (a, b) { return a.x - a.y > b.x - b.y ? a : b; }), bl = en.reduce(function (a, b) { return a.x - a.y < b.x - b.y ? a : b; });
    if (new Set([tl, tr, bl, br]).size < 4) return null;
    // Oran kontrolü: şablonda genişlik/yükseklik = 186/108
    var gen = Math.hypot(tr.x - tl.x, tr.y - tl.y), yk = Math.hypot(bl.x - tl.x, bl.y - tl.y); if (!yk || gen / yk < 1.1 || gen / yk > 2.6) return null;
    return [tl, tr, bl, br];
  }
  function homografi(src, dst) { // src (mm) -> dst (piksel), 4 nokta
    var A = [], b = [];
    for (var i = 0; i < 4; i++) { var x = src[i][0], y = src[i][1], u = dst[i][0], v = dst[i][1];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u); A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v); }
    for (var c = 0; c < 8; c++) { var p = c; for (var r = c + 1; r < 8; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
      var t = A[c]; A[c] = A[p]; A[p] = t; t = b[c]; b[c] = b[p]; b[p] = t;
      for (r = 0; r < 8; r++) if (r !== c) { var f = A[r][c] / A[c][c]; for (var k = c; k < 8; k++) A[r][k] -= f * A[c][k]; b[r] -= f * b[c]; } }
    var H = b.map(function (v, i) { return v / A[i][i]; }); H.push(1);
    return function (x, y) { var z = H[6] * x + H[7] * y + 1; return [(H[0] * x + H[1] * y + H[2]) / z, (H[3] * x + H[4] * y + H[5]) / z]; };
  }
  // Bir kutunun içini (kenar çizgisi hariç) düz yamaya örnekle
  function yamaAl(img, g, esle, kutu, ic, pxmm) {
    var x0 = kutu.x + kutu.w * ic, y0 = kutu.y + kutu.h * ic, ww = kutu.w * (1 - 2 * ic), hh = kutu.h * (1 - 2 * ic);
    var w = Math.max(8, Math.round(ww * pxmm)), h = Math.max(8, Math.round(hh * pxmm)), o = new Float32Array(w * h);
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) { var p = esle(x0 + (x + 0.5) * ww / w, y0 + (y + 0.5) * hh / h), px = p[0], py = p[1];
      var ix = Math.floor(px), iy = Math.floor(py);
      if (ix < 0 || iy < 0 || ix >= img.width - 1 || iy >= img.height - 1) { o[y * w + x] = 255; continue; }
      var fx = px - ix, fy = py - iy, W = img.width;
      o[y * w + x] = g[iy * W + ix] * (1 - fx) * (1 - fy) + g[iy * W + ix + 1] * fx * (1 - fy) + g[(iy + 1) * W + ix] * (1 - fx) * fy + g[(iy + 1) * W + ix + 1] * fx * fy; }
    return { w: w, h: h, g: o };
  }
  function yamaMaske(y) {
    var s = Array.prototype.slice.call(y.g).sort(function (a, b) { return a - b; }), zemin = s[Math.floor(s.length * 0.7)], esik = Math.min(zemin - 45, zemin * 0.72);
    var d = new Uint8Array(y.w * y.h), n = 0; for (var i = 0; i < d.length; i++) if (y.g[i] < esik) { d[i] = 1; n++; }
    var m = { w: y.w, h: y.h, d: d };
    // kenara değen ince uzun çizgileri (kutu kenarı, cetvel izi) sil
    var b = R.bilesenler(m);
    b.cs.forEach(function (c) { var kenar = c.x <= 1 || c.y <= 1 || c.x + c.w >= y.w - 1 || c.y + c.h >= y.h - 1, ince = Math.min(c.w, c.h) < Math.max(3, 0.12 * Math.max(c.w, c.h));
      if ((kenar && ince) || c.a < 0.004 * y.w * y.h) for (var i = 0; i < b.lab.length; i++) if (b.lab[i] === c.i) { d[i] = 0; n--; } });
    m.oran = Math.max(0, n) / d.length; return m;
  }
  function enIyiSayi(m, enCok, max) {
    var b = R.bilesenler(m), cs = b.cs; if (!cs.length) return null;
    var hip = R.grupOku(m, b.lab, cs), en = null, H = Math.max.apply(null, cs.map(function (c) { return c.h; })),
        parca = cs.filter(function (c) { return c.h >= 0.45 * H; }).length;
    hip.forEach(function (h) { if (!h.rak.length || h.rak.length > enCok) return;
      // her hane için en olası 3 rakam; azami puandan büyük sayılar ve gereksiz bölmeler cezalı
      var L = [{ s: '', p: 1 }];
      h.rak.forEach(function (r) { var o = Array.prototype.map.call(r.olas, function (p, d) { return { d: d, p: p }; }).sort(function (a, b) { return b.p - a.p; }).slice(0, 3);
        L = [].concat.apply([], L.map(function (x) { return o.map(function (t) { return { s: x.s + t.d, p: x.p * t.p }; }); })); });
      var cez = (h.rak.length > parca ? 0.55 : 1) * h.w;
      L.forEach(function (x) { var p = Math.pow(x.p, 1 / h.rak.length) * cez, v = parseInt(x.s, 10);
        if (max != null && v > Number(max)) p *= 0.35; if (x.s.length > 1 && x.s[0] === '0') p *= 0.3;
        if (!en || p > en.p) en = { s: x.s, p: Math.min(1, p) }; }); });
    return en;
  }
  // Ayrı yazılmış rakamlar: her büyük bileşen bir rakam (okul no için)
  function tekTekOku(m) {
    var b = R.bilesenler(m), cs = b.cs; if (!cs.length) return null; var H = Math.max.apply(null, cs.map(function (c) { return c.h; }));
    var bb = cs.filter(function (c) { return c.h >= 0.5 * H; }).sort(function (a, c) { return a.x - c.x; }), s = '', p = 1;
    bb.forEach(function (c) { var ids = [c.i].concat(cs.filter(function (q) { return q.h < 0.5 * H && q.x >= c.x - 2 && q.x + q.w <= c.x + c.w + 2; }).map(function (q) { return q.i; }));
      var d = new Uint8Array(c.w * m.h); for (var y = 0; y < m.h; y++) for (var x = 0; x < c.w; x++) if (ids.indexOf(b.lab[y * m.w + x + c.x]) >= 0) d[y * c.w + x] = 1;
      var t = R.mnist({ w: c.w, h: m.h, d: d }); if (!t) return; var o = R.siniflandir(t), mx = Math.max.apply(null, o); s += o.indexOf(mx); p *= mx; });
    return s ? { s: s, p: Math.pow(p, 1 / s.length) } : null;
  }
  // Tek kutu: puan (1-3 hane) veya tek rakam
  function kutuOku(m, enCok, max) {
    if (m.oran < 0.006) return { deger: '', guven: 100, bos: true };
    var r = enIyiSayi(m, enCok || 3, max); if (!r) return { deger: '', guven: 0, bos: true };
    return { deger: String(parseInt(r.s, 10)), guven: Math.round(100 * r.p) };
  }
  function onizleme(y) { return { w: y.w, h: y.h, g: y.g }; }
  // Şablonlu sayfa: {no:{deger,guven}, puanlar:[{deger,guven,max,kontrol}], hizali:true}
  function sablonOku(img, maxlar) {
    if (!R || !R.hazir()) throw new Error('Rakam modeli yüklenmedi');
    var is = isaretBul(img); if (!is) return { hizali: false, hata: 'Köşe işaretleri bulunamadı. Dört siyah kare görünecek şekilde yeniden çekin ya da "Serbest kâğıt" ile alanları işaretleyin.' };
    var esle = homografi(S.isaret, is.map(function (p) { return [p.x, p.y]; })), g = gri(img);
    var pxmm = Math.max(3, Math.min(8, Math.hypot(is[1].x - is[0].x, is[1].y - is[0].y) / 186));
    var noH = [], noG = [], noImg = [];
    for (var k = 0; k < S.no.adet; k++) { var y = yamaAl(img, g, esle, noKutusu(k), 0.12, 6), m = yamaMaske(y);
      if (m.oran < 0.006) continue; var t = R.mnist(m); if (!t) continue; var o = R.siniflandir(t), mx = Math.max.apply(null, o); noH.push(o.indexOf(mx)); noG.push(mx); noImg.push(onizleme(y)); }
    var no = { deger: noH.join(''), guven: noG.length ? Math.round(100 * Math.min.apply(null, noG)) : 0 };
    var puanlar = maxlar.map(function (mx, j) { var y = yamaAl(img, g, esle, soruKutusu(j), 0.1, 6), r = kutuOku(yamaMaske(y), 3, mx); r.max = mx; r.img = onizleme(y); return r; });
    return { hizali: true, no: no, puanlar: kontrolEt(puanlar), pxmm: pxmm };
  }
  // Serbest kâğıt: alanlar sayfa oranı (0..1) olarak; [{tur:'no'|'soru', j, x,y,w,h}]
  function alanOku(img, alanlar, maxlar) {
    if (!R || !R.hazir()) throw new Error('Rakam modeli yüklenmedi');
    var g = gri(img), esle = function (x, y) { return [x * img.width, y * img.height]; }, no = { deger: '', guven: 0 }, puanlar = maxlar.map(function (mx) { return { deger: '', guven: 0, bos: true, max: mx, alanYok: true }; });
    alanlar.forEach(function (a) {
      var pxmm = Math.max(1, Math.min(6, 60 / (a.h * img.height))) * img.height; // alan yüksekliği ~60 px
      var y = yamaAl(img, g, esle, a, 0.04, pxmm), m = yamaMaske(y);
      if (a.tur === 'no') { var r = enIyiSayi(m, 8), t = tekTekOku(m); if (t && (!r || t.p > r.p)) r = t; if (r) no = { deger: r.s, guven: Math.min(api.ESIK - 1, Math.round(100 * r.p)) }; no.img = onizleme(y); } // 1.6.4: işaretli alan okuyucusu tek başına yeşil veremez
      else if (puanlar[a.j]) { var q = kutuOku(m, 3, maxlar[a.j]); q.max = maxlar[a.j]; q.img = onizleme(y); puanlar[a.j] = q; }
    });
    return { hizali: true, no: no, puanlar: kontrolEt(puanlar) };
  }
  function kontrolEt(p) { var esik = api.ESIK; p.forEach(function (r) { var v = r.deger === '' ? null : Number(String(r.deger).replace(',', '.')), asar = v != null && r.max != null && !(v >= 0 && v <= Number(r.max));
    if (r.duzeltildi) { r.kontrol = asar; r.neden = asar ? 'azamiden büyük' : ''; return; }
    r.kontrol = !!(r.alanYok || r.guven < esik || r.bos || asar); r.neden = r.alanYok ? 'alan yok' : r.bos ? 'boş' : asar ? 'azamiden büyük' : r.guven < esik ? 'düşük güven' : ''; }); return p; }
  var api = { enIyiSayi: enIyiSayi, tekTekOku: tekTekOku, yamaMaske: yamaMaske, yamaAl: yamaAl, gri: gri, S: S, soruKutusu: soruKutusu, noKutusu: noKutusu, isaretBul: isaretBul, sablonOku: sablonOku, alanOku: alanOku, kontrolEt: kontrolEt, ESIK: 80, yukle: function (buf) { return R.yukle(buf); }, hazir: function () { return R && R.hazir(); } };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  kok.PuanOku = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
