/* 1.7.0 Soru bazlı (tüm sayfa) çekirdeği. Tamamen yerel; görüntü bu bilgisayardan çıkmaz.
   Girdi: basılı satırlar [{t,x0,y0,x1,y1}] (PDF metin katmanı / Yerel Okuma PaddleOCR / Tesseract) + renkli mürekkep maskesi {w,h,d}.
   Çıktı: sorular [{no,max,y0,y1,puan,guven,kontrol,neden}], toplam okuma, sağlama. Kaydet'e basmaz, hiçbir şey göndermez. */
(function (kok) {
  'use strict';
  var P = function () { return kok.PuanOku || (typeof require !== 'undefined' ? require('./okuyucu.js') : null); };
  var R = function () { return kok.ElRakam || (typeof require !== 'undefined' ? require('./rakam.js') : null); };
  function fold(s) { return String(s || '').toLowerCase().replace(/[ıİi̇]/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c'); }
  // aynı yükseklikteki parçaları tek satır yap
  function satirla(ls) {
    var a = (ls || []).filter(function (l) { return l && String(l.t || '').trim(); }).slice().sort(function (p, q) { return p.y0 - q.y0; }), out = [];
    a.forEach(function (l) { var h = Math.max(4, l.y1 - l.y0), s = out.find(function (o) { return Math.abs((o.y0 + o.y1) / 2 - (l.y0 + l.y1) / 2) < 0.6 * Math.min(h, o.y1 - o.y0 || h); });
      if (s) { s.p.push(l); s.x0 = Math.min(s.x0, l.x0); s.x1 = Math.max(s.x1, l.x1); s.y0 = Math.min(s.y0, l.y0); s.y1 = Math.max(s.y1, l.y1); } else out.push({ p: [l], x0: l.x0, x1: l.x1, y0: l.y0, y1: l.y1 }); });
    out.forEach(function (o) { o.p.sort(function (p, q) { return p.x0 - q.x0; }); o.t = o.p.map(function (p) { return p.t; }).join(' '); o.ilk = o.p[0]; });
    return out.sort(function (p, q) { return p.y0 - q.y0; });
  }
  var MAXRE = /\(\s*(\d{1,3})\s*[Pp](?:uan|\.|\b|\))/;
  // Soru başlıkları: sol kenarda "N." ile başlayan satır; azami puan "(20 P)" (yoksa "Her soru N puan"/"5 × 20 puan")
  function sorulariBul(ls, W, H) {
    var S = satirla(ls), qs = [], ortak = null, son = H;
    S.forEach(function (s) { var f = fold(s.t), m = f.match(/her soru\s*(\d{1,3})\s*puan/) || f.match(/soru\s*:?\s*\d+\s*[x×]\s*(\d{1,3})\s*puan/); if (m) ortak = +m[1];
      if (/zumre|zümre/.test(f) && s.y0 > H * 0.85) son = Math.min(son, s.y0); });
    S.forEach(function (s) { var m = String(s.ilk.t).match(/^\s*(\d{1,2})\s*[.)]\s*\S?/); if (!m || s.ilk.x0 > W * 0.2 || s.y0 < H * 0.12) return;
      var mx = s.t.match(MAXRE); if (!mx && !ortak && !/[?:]\s*$|yaz[iı]n[iı]z|a[cç][iı]klay/i.test(s.t)) return;
      qs.push({ no: +m[1], max: mx ? +mx[1] : ortak, maxKaynak: mx ? 'soru' : (ortak ? 'yönerge' : ''), y0: s.y0, ty1: s.y1, metin: s.t, _s: s }); });
    // sıra denetimi: artan numara; tekrar edenden ilki
    var g = []; qs.forEach(function (q) { if (!g.length || q.no > g[g.length - 1].no) g.push(q); });
    g.forEach(function (q, i) { q.y1 = i + 1 < g.length ? g[i + 1].y0 : son;
      // 1.7.1 soru metni: soru satırı + bant içinde, noktalı cevap satırlarından önceki basılı devam satırları
      var dev = S.filter(function (s) { return s !== q._s && s.y0 > q.y0 && s.y0 < q.y1 && s.x0 < W * 0.25; }), ek = [];
      for (var k = 0; k < dev.length; k++) { var t = dev[k].t, harf = (t.match(/[A-Za-zÇĞİÖŞÜçğıöşü]/g) || []).length; if (harf < 0.6 * t.replace(/\s/g, '').length || dev[k].y0 - (k ? dev[k - 1].y1 : q.ty1) > 2.5 * (q.ty1 - q.y0 + 4)) break; ek.push(t); }
      q.metin = [q.metin].concat(ek).join(' ').replace(/\s+/g, ' ').trim(); delete q._s; });
    var ust = S.filter(function (s) { return s.y0 < H * 0.25; }).map(function (s) { return s.t; }).join('\n'), KO = kok.KagitOku || (typeof require !== 'undefined' ? require('./kagit.js') : null), dz = null;
    try { dz = KO && KO.dersBul ? KO.dersBul(ust) : null; } catch (e) { dz = null; }
    return { sorular: g, ortak: ortak, satirlar: S, ders: dz ? { ad: dz.ders, kesin: !!dz.kesin, alan: dz.alan || '' } : null };
  }
  function kes(M, x0, y0, x1, y1) { x0 = Math.max(0, Math.round(x0)); y0 = Math.max(0, Math.round(y0)); x1 = Math.min(M.w, Math.round(x1)); y1 = Math.min(M.h, Math.round(y1));
    var w = Math.max(0, x1 - x0), h = Math.max(0, y1 - y0), d = new Uint8Array(w * h), n = 0;
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) { var v = M.d[(y + y0) * M.w + x + x0]; d[y * w + x] = v; n += v; }
    return { w: w, h: h, d: d, n: n, x0: x0, y0: y0 }; }
  // mürekkebi sıkıca saran kutuya indir
  function sik(m) { var x0 = m.w, y0 = m.h, x1 = -1, y1 = -1; for (var y = 0; y < m.h; y++) for (var x = 0; x < m.w; x++) if (m.d[y * m.w + x]) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 < 0) return null; var p = 3; return kes(m, x0 - p, y0 - p, x1 + p + 1, y1 + p + 1); }
  // X / çizgi (-) = 0: tek büyük bileşen; çizgi yatay ince, X iki köşegende mürekkep
  function sifirIsareti(m) {
    var b = R().bilesenler(m), cs = b.cs.filter(function (c) { return c.a >= 12; }); if (!cs.length) return null;
    var big = cs.slice().sort(function (p, q) { return q.a - p.a; })[0], H = big.h, Wd = big.w;
    if (Wd > 2.4 * H && H < 0.5 * m.h) return 'cizgi';
    if (Wd < 0.55 * H || Wd > 1.45 * H || big.a / (Wd * H) > 0.165) return null; // bitişik yazılmış 20 geniştir; X kareye yakın
    var kosegen = function (ters) { var say = 0, top = 0; for (var k = 0.12; k <= 0.88; k += 0.04) { top++; var cx = big.x + Math.round(k * (Wd - 1)), cy = big.y + Math.round((ters ? 1 - k : k) * (H - 1)), var1 = false;
        var tol = Math.max(3, Math.round(0.14 * Math.max(Wd, H)));
        for (var dy = -tol; dy <= tol && !var1; dy++) for (var dx = -tol; dx <= tol && !var1; dx++) { var yy = cy + dy, xx = cx + dx; if (yy >= 0 && xx >= 0 && yy < m.h && xx < m.w && b.lab[yy * m.w + xx] === big.i) var1 = true; } if (var1) say++; } return say / top; };
    var a = kosegen(false), c = kosegen(true), orta = 0; // merkezde kesişme
    if (cs.filter(function (q) { return q.a > 0.25 * big.a; }).length > 1) return null; var t2 = Math.max(2, Math.round(0.15 * Math.max(Wd, H))); for (var dy = -t2; dy <= t2; dy++) for (var dx = -t2; dx <= t2; dx++) { var yy = big.y + (H >> 1) + dy, xx = big.x + (Wd >> 1) + dx; if (yy >= 0 && xx >= 0 && yy < m.h && xx < m.w && b.lab[yy * m.w + xx] === big.i) orta = 1; }
    if (!(a > 0.75 && c > 0.75 && orta)) return null;
    // rakam değil mi? (ör. 4, 8 köşegene benzeyebilir) — rakam okuyucu çok eminse X sayılmaz
    var e = P().enIyiSayi(m, 2, 100); return e && e.p > 0.97 && !/^[x]$/.test(e.s) && b.cs.filter(function (q) { return q.a > 0.3 * big.a; }).length > 1 ? null : 'x';
  }
  // 7,5 / 2,5 gibi ondalık: iki rakam grubu arasında tabanda küçük virgül/nokta
  function ondalik(m, max) {
    var b = R().bilesenler(m), cs = b.cs.filter(function (c) { return c.a >= 6; }); if (cs.length < 3) return null;
    var H = Math.max.apply(null, cs.map(function (c) { return c.h; }));
    var v = cs.filter(function (c) { return c.h < 0.42 * H && c.w < 0.42 * H && c.y + c.h > m.h * 0.55; }).find(function (c) {
      var sol = cs.some(function (q) { return q.h >= 0.6 * H && q.x + q.w <= c.x + 2; }), sag = cs.some(function (q) { return q.h >= 0.6 * H && q.x >= c.x + c.w - 2; }); return sol && sag; });
    if (!v) return null;
    var L = sik(kes(m, 0, 0, v.x, m.h)), Rr = sik(kes(m, v.x + v.w, 0, m.w, m.h)); if (!L || !Rr) return null;
    var a = P().enIyiSayi(L, 2, max), c = P().enIyiSayi(Rr, 2, 99); if (!a || !c) return null;
    var s = String(+a.s) + '.' + c.s; if (max != null && +s > max) return null;
    return { s: s, p: Math.min(a.p, c.p) * 0.9 };
  }
  // en olası birkaç değer (toplam sağlaması için); öğretmen puanı çoğunlukla 5'in katı → hafif ön bilgi
  function adaylarAl(m, max, e) {
    var o = {}; try { var b = R().bilesenler(m), hip = R().grupOku(m, b.lab, b.cs.filter(function (c) { return c.a >= 6; }));
      var L = []; hip.forEach(function (h) { if (!h.rak.length || h.rak.length > 2) return; var A = [{ s: '', p: h.w }];
        h.rak.forEach(function (r) { var t = Array.prototype.map.call(r.olas, function (p, d) { return { d: d, p: p }; }).sort(function (a, b) { return b.p - a.p; }).slice(0, 3);
          A = [].concat.apply([], A.map(function (x) { return t.map(function (y) { return { s: x.s + y.d, p: x.p * y.p }; }); })); }); L = L.concat(A); });
      L.forEach(function (x) { var v = +x.s; if (max != null && v > max) return; if (x.s.length > 1 && x.s[0] === '0') return; var p = Math.pow(x.p, 1 / x.s.length) * (v % 5 === 0 ? 1 : 0.5); if (!o[v] || o[v] < p) o[v] = p; }); } catch (er) { }
    if (e && !(max != null && +e.s > max)) o[+e.s] = Math.max(o[+e.s] || 0, e.p);
    var z = sifirIsareti(m); o[0] = Math.max(o[0] || 0, z ? 0.9 : 0.12);
    return Object.keys(o).map(function (k) { return { v: +k, p: o[k] }; }).sort(function (a, b) { return b.p - a.p; }).slice(0, 5);
  }
  // Toplam sağlaması: kâğıttaki toplam okunduysa ve sorular tutmuyorsa, adaylardan toplamı tutan en olası birleşim aranır.
  // En çok 2 soru değişir; değişen sorular SARI kalır ("toplama göre seçildi"), öğretmen onaylar.
  function toplamaUydur(sor, T) {
    var idx = sor.map(function (q, i) { return i; }), best = null, n = sor.length;
    var ad = sor.map(function (q) { var a = (q.adaylar || []).slice(); if (q.puan != null && !a.some(function (x) { return x.v === q.puan; })) a.unshift({ v: q.puan, p: q.guven || 0.5 }); return a; });
    var cur = sor.map(function (q) { return q.puan || 0; }), top = cur.reduce(function (a, b) { return a + b; }, 0);
    for (var i = 0; i < n; i++) for (var j = i; j < n; j++) {
      (ad[i] || []).forEach(function (ai) { var kalan = T - (top - cur[i]) ; if (i === j) { if (Math.abs(ai.v - kalan) < 1e-6 && ai.v !== cur[i]) { var p = ai.p; if (!best || p > best.p) best = { p: p, d: [[i, ai.v]] }; } return; }
        (ad[j] || []).forEach(function (aj) { if (Math.abs(top - cur[i] - cur[j] + ai.v + aj.v - T) < 1e-6 && (ai.v !== cur[i] || aj.v !== cur[j])) { var p = ai.p * aj.p; if (!best || p > best.p) best = { p: p, d: [[i, ai.v], [j, aj.v]] }; } }); }); }
    return best && best.p > 0.05 ? best : null;
  }
  // bir soru bandının sağ kenarındaki el yazısı puanı
  function bantPuan(M, q, W, opt) {
    opt = opt || {}; var x0 = W * (opt.kenar || 0.8), m = kes(M, x0, q.y0 - 4, M.w - 4, q.y1 - 2);
    if (m.n < 25) return { deger: '', guven: 0, bos: true };
    var s = sik(m); if (!s) return { deger: '', guven: 0, bos: true };
    s.gx = m.x0 + s.x0; s.gy = m.y0 + s.y0;
    var z = sifirIsareti(s); if (z) return { deger: '0', guven: 0.9, isaret: z, kutu: [s.gx, s.gy, s.w, s.h] };
    var e = ondalik(s, q.max) || P().enIyiSayi(s, 3, q.max); if (!e) return { deger: '', guven: 0, kutu: [s.gx, s.gy, s.w, s.h], adaylar: adaylarAl(s, q.max) };
    return { deger: e.s.replace(/^0+(?=\d)/, ''), guven: e.p, kutu: [s.gx, s.gy, s.w, s.h], adaylar: adaylarAl(s, q.max, e) };
  }
  function etiket(S, re) { return S.find(function (s) { return re.test(fold(s.t)); }); }
  // Taban çizgisi yakınında biten renkli bileşenleri al (başka satırın el yazısı karışmasın)
  function tabandaki(M, x0, x1, taban, H) {
    var m = kes(M, x0, taban - 0.06 * H, x1, taban + 0.025 * H); if (m.n < 25) return null;
    var b = R().bilesenler(m), al = b.cs.filter(function (c) { var alt = m.y0 + c.y + c.h; return c.a > 10 && c.h > 0.011 * H && alt > taban - 0.016 * H && alt < taban + 0.022 * H; });
    if (!al.length) return null; var d = new Uint8Array(m.w * m.h), ids = {}; al.forEach(function (c) { ids[c.i] = 1; });
    for (var i = 0; i < d.length; i++) if (ids[b.lab[i]]) d[i] = 1;
    var s = sik({ w: m.w, h: m.h, d: d }); if (s) { s.gx = m.x0 + s.x0; s.gy = m.y0 + s.y0; } return s;
  }
  // üst bilgi: Aldığı puan (toplam), Sınıf/No (okul no rakamları), basılı sınıf düzeyi. Satır tabanı aynı satırdaki
  // basılı sol etiketten (Adı Soyadı / Süre) alınır; kutusu el yazısıyla şişen etikete güvenilmez.
  function ustBilgi(M0, S, W, H, Mk) {
    var M = M0, ikinci = Mk || null; // renkli mürekkep yoksa (kurşun kalem/siyah) koyu maske
    var o = { toplam: null, no: '', duzey: '' }, parca = [].concat.apply([], S.filter(function (s) { return s.y0 < H * 0.3; }).map(function (s) { return s.p; }));
    // etiket uzun bir satırın içindeyse (Tesseract tüm satırı tek kutu verir) yeri harf oranıyla kestirilir
    var bul = function (re) { var l = parca.find(function (x) { return re.test(fold(x.t)); }); if (!l) return null; var f = fold(l.t), m = f.match(re);
      if (!m || m.index === 0 || f.length < 4) return l; var k = (l.x1 - l.x0) / f.length; return { t: l.t.slice(m.index), x0: l.x0 + k * m.index, x1: l.x1, y0: l.y0, y1: l.y1 }; };
    var d = S.find(function (s) { return s.y0 < H * 0.2 && /(\d{1,2})\s*\.?\s*sinif/.test(fold(s.t)); }); if (d) { var dm = fold(d.t).match(/(\d{1,2})\s*\.?\s*sinif/); if (dm && +dm[1] >= 1 && +dm[1] <= 12) o.duzey = dm[1]; }
    var a = bul(/ald[iı1]?g/), sure = bul(/^s[uü]?i?re\s*:|^sure|dakika/), adi = bul(/^ad[iı1]\s*soyad|soyad/), sn = bul(/s[iı1]n[iı1]?f\s*\/?\s*n[o0]|^s[iı1]n[iı1]?f/);
    if (a) { var tb = sure && Math.abs(sure.y1 - a.y1) < 0.03 * H ? sure.y1 : a.y1 - 0.004 * H, s = tabandaki(M, a.x0 + 0.1 * W, a.x0 + 0.33 * W, tb, H) || (ikinci && tabandaki(ikinci, a.x0 + 0.1 * W, a.x0 + 0.33 * W, tb, H));
      if (s) { var e = ondalik(s, 100) || P().enIyiSayi(s, 3, 100); if (e) o.toplam = { deger: e.s.replace(/^0+(?=\d)/, ''), guven: e.p, kutu: [s.gx, s.gy, s.w, s.h] }; } }
    if (sn) { var tb2 = adi && Math.abs(adi.y1 - sn.y1) < 0.03 * H ? adi.y1 : sn.y1 - 0.004 * H, ss = tabandaki(M, sn.x0 + 0.085 * W, W - 4, tb2, H) || (ikinci && tabandaki(ikinci, sn.x0 + 0.085 * W, W - 4, tb2, H));
      if (ss) { var b = R().bilesenler(ss), cs = b.cs.filter(function (c) { return c.a > 15; }).sort(function (x, y) { return x.x - y.x; });
        var en = -1, ix = -1; for (var i = 1; i < cs.length; i++) { var gap = cs[i].x - (cs[i - 1].x + cs[i - 1].w); if (gap > en) { en = gap; ix = i; } }
        if (ix > 0) { var sag = sik(kes(ss, cs[ix].x - 2, 0, ss.w, ss.h)), r = sag && (R().numaraOku(sag) || P().tekTekOku(sag)), v = r && (r.no || r.s);
          if (v && /^\d{3,6}$/.test(v)) o.no = { deger: v, guven: r.guven != null ? r.guven / 100 : r.p };
          o.sinifKutu = [ss.gx, ss.gy, cs[ix].x, ss.h]; o.noKutu = [ss.gx + cs[ix].x, ss.gy, ss.w - cs[ix].x, ss.h]; } } }
    // metin okuyucunun (PaddleOCR/Tesseract) üst bilgide gördüğü 4-6 haneli sayı: ElRakam ile aynıysa emin, değilse metin okuyucu tercih edilir (sarı)
    var tok = []; if (sn) parca.forEach(function (l) { if (Math.abs((l.y0 + l.y1) / 2 - (sn.y0 + sn.y1) / 2) > 0.035 * H || l.x1 < sn.x0 || /\d{4}\s*[-–]\s*\d{4}/.test(l.t)) return; (String(l.t).slice(l === sn || /n[o0]\s*:/i.test(fold(l.t)) ? Math.max(0, fold(l.t).search(/n[o0]\s*:/) + 3) : 0).match(/\d{4,6}/g) || []).forEach(function (x) { tok.push(x); }); });
    o.noAday = tok; if (tok.length) { var t0 = tok[tok.length - 1]; if (o.no && o.no.deger === t0) o.no.guven = Math.max(o.no.guven, 0.95); else o.no = { deger: t0, guven: 0.6, kaynak: 'metin' }; }
    return o;
  }
  // tüm sayfa: satırlar + maske → sonuç
  function sayfaOku(ls, M, W, H, opt) {
    var B = sorulariBul(ls, W, H); opt = opt || {}; var ham = B.sorular.slice(); if (opt.sablon) B.sorular = tamamla(B.sorular, opt.sablon, H);
    var sor = B.sorular.map(function (q) { var r = bantPuan(M, q, W, opt), v = r.deger === '' ? null : +r.deger, esik = (opt && opt.esik) || 0.8;
      if (v != null && q.max != null && v > q.max) { var uy = (r.adaylar || []).filter(function (x) { return x.v <= q.max; })[0]; r.okunan = v; v = uy ? uy.v : null; r.guven = Math.min(r.guven || 0, 0.4); }
      var k = r.okunan != null ? 'azamiden büyük okundu (' + r.okunan + ')' : r.bos ? 'boş (puan yazılmamış)' : v == null ? 'okunamadı' : (q.max != null && v > q.max) ? 'azamiden büyük' : r.guven < esik ? 'düşük güven' : !q.max ? 'azami puan okunamadı' : (q.max % 5 === 0 && v % 5 !== 0 && !opt.besKatiSerbest) ? 'alışılmadık değer (5\'in katı değil)' : '';
      if (q.sablondan && !k) k = 'soru satırı diğer sayfalardan tahmin edildi';
      return Object.assign({}, q, { adaylar: r.adaylar, puan: r.bos ? 0 : v, guven: r.guven, isaret: r.isaret || '', kutu: r.kutu, kontrol: !!k, neden: k }); });
    var u = ustBilgi(M, B.satirlar, W, H, opt.koyu), top = sor.reduce(function (t, q) { return t + (q.puan || 0); }, 0);
    var sag = { toplam: u.toplam ? +u.toplam.deger : null, soruToplam: top, tutuyor: u.toplam ? +u.toplam.deger === top : null };
    if (sag.tutuyor === false && u.toplam && u.toplam.guven >= 0.5) { var uy = toplamaUydur(sor, sag.toplam); if (uy) { uy.d.forEach(function (x) { var q = sor[x[0]]; q.okunan = q.puan; q.puan = x[1]; q.kontrol = true; q.neden = 'toplama göre seçildi (okunan ' + q.okunan + ', kâğıttaki toplam ' + sag.toplam + ')'; });
        top = sor.reduce(function (t, q) { return t + (q.puan || 0); }, 0); sag.soruToplam = top; sag.tutuyor = top === sag.toplam; sag.uyduruldu = true; } }
    if (sag.tutuyor === false) sor.forEach(function (q) { if (!q.kontrol) { q.kontrol = true; q.neden = 'toplam tutmuyor (kâğıtta ' + sag.toplam + ', sorular ' + top + ')'; } });
    var maxTop = sor.reduce(function (t, q) { return t + (q.max || 0); }, 0);
    return { sorular: sor, toplam: top, maxToplam: maxTop, saglama: sag, ust: u, ortak: B.ortak, soruYok: !sor.length, bulunan: ham, ders: B.ders };
  }
  // Aynı sınavın sayfaları aynı düzende: bir sayfada bulunamayan soru satırı, tam bulunan sayfalardaki konumdan
  // (eşleşen sorularla kaydırılarak) tamamlanır ve SARI işaretlenir. sonuçlar: sayfaOku çıktıları (sorular + _B)
  function sablonCikar(bulunanlar) { var en = null; (bulunanlar || []).forEach(function (b) { if (b && (!en || b.length > en.length)) en = b; }); return en; }
  function tamamla(sor, sablon, H) {
    if (!sablon || !sablon.length || sor.length >= sablon.length) return sor;
    var es = sor.map(function (q) { var t = sablon.find(function (x) { return x.no === q.no; }); return t ? q.y0 - t.y0 : null; }).filter(function (x) { return x != null; }).sort(function (a, b) { return a - b; });
    var kay = es.length ? es[es.length >> 1] : 0, out = sablon.map(function (t) { var q = sor.find(function (x) { return x.no === t.no; });
      return q ? Object.assign({}, q) : { no: t.no, max: t.max, maxKaynak: t.maxKaynak, y0: t.y0 + kay, metin: t.metin, sablondan: true }; });
    out.forEach(function (q, i) { q.y1 = i + 1 < out.length ? out[i + 1].y0 : Math.min(H, (sablon[i].y1 || H) + kay); }); return out;
  }
  // 1.7.1 Aynı dosyadaki sayfalar aynı sınav: ders çoğunluk oyuyla, her sorunun metni diğer okumalara en yakın (medoid) okumayla birleştirilir
  function lev(a, b) { var d = []; for (var j = 0; j <= b.length; j++) d[j] = j; for (var i = 1; i <= a.length; i++) { var p = d[0]; d[0] = i; for (j = 1; j <= b.length; j++) { var t = d[j]; d[j] = Math.min(d[j] + 1, d[j - 1] + 1, p + (a[i - 1] === b[j - 1] ? 0 : 1)); p = t; } } return d[b.length]; }
  function konsensus(sayfalar) { // sayfalar: [{ders:{ad,kesin}|null, sorular:[{no, metin}]}]
    var oy = {}, met = {}; sayfalar.forEach(function (s) { if (s.ders && s.ders.ad) oy[s.ders.ad] = (oy[s.ders.ad] || 0) + (s.ders.kesin ? 2 : 1); (s.sorular || []).forEach(function (q) { if (q.metin && !q.sablondan) (met[q.no] = met[q.no] || []).push(q.metin); }); });
    var ders = Object.keys(oy).sort(function (a, b) { return oy[b] - oy[a]; })[0] || '', metin = {};
    Object.keys(met).forEach(function (n) { var L = met[n].slice(0, 15), en = null, ek = Infinity; L.forEach(function (a) { var t = L.reduce(function (s, b) { return s + lev(a, b) / Math.max(1, a.length, b.length); }, 0); if (t < ek) { ek = t; en = a; } }); metin[n] = en; });
    return { ders: ders, dersOy: oy, metin: metin };
  }
  // ---- Analiz: sınıf bazında öğrenci × soru, ortalama, başarı %, dağılım
  function analiz(kayitlar) {
    var g = {}; (kayitlar || []).forEach(function (k) { (g[k.sinif || '?'] = g[k.sinif || '?'] || []).push(k); });
    var sinif = Object.keys(g).sort().map(function (s) { var L = g[s], n = Math.max.apply(null, L.map(function (k) { return k.sorular.length; }).concat(0)), sorular = [];
      for (var j = 0; j < n; j++) { var v = L.map(function (k) { return k.sorular[j]; }).filter(Boolean), mx = v.map(function (q) { return q.max; }).filter(function (x) { return x != null; })[0] || null,
          p = v.map(function (q) { return +q.puan || 0; }), ort = p.length ? p.reduce(function (a, b) { return a + b; }, 0) / p.length : 0;
        var dag = { tam: 0, kismi: 0, sifir: 0 }; p.forEach(function (x) { if (mx && x >= mx) dag.tam++; else if (x > 0) dag.kismi++; else dag.sifir++; });
        sorular.push({ no: (v[0] && v[0].no) || j + 1, metin: (v.find(function (q) { return q.metin; }) || {}).metin || '', max: mx, ort: Math.round(ort * 100) / 100, basari: mx ? Math.round(1000 * ort / mx) / 10 : null, dag: dag, n: p.length }); }
      var tops = L.map(function (k) { return k.toplam; }), ort = tops.reduce(function (a, b) { return a + b; }, 0) / (tops.length || 1);
      return { sinif: s, ders: (L.find(function (k) { return k.ders; }) || {}).ders || '', ogrenci: L.length, sorular: sorular, ortalama: Math.round(ort * 100) / 100, enYuksek: Math.max.apply(null, tops), enDusuk: Math.min.apply(null, tops), kontrol: L.filter(function (k) { return k.kontrol; }).length }; });
    var hep = [].concat.apply([], Object.keys(g).map(function (s) { return g[s]; })), T = hep.map(function (k) { return k.toplam; });
    return { sinif: sinif, genel: { ogrenci: hep.length, ortalama: T.length ? Math.round(100 * T.reduce(function (a, b) { return a + b; }, 0) / T.length) / 100 : 0 } };
  }
  // e-Okul akışına besleme: mevcut ng_ice_aktar biçimi (sınıf sınıf yazar, listede olup kâğıdı olmayana G — panel ayarı)
  function eokulSatirlari(kayitlar, ders) { return (kayitlar || []).filter(function (k) { return k.no; }).map(function (k) { return { sinif: k.sinif || '', no: String(k.no), ders: ders || k.ders || '', puan: String(Math.round(Number(k.toplam) || 0)) }; }); }
  // Hedef bağdaştırıcıları: ileride OYSS/EBA eklenir (aynı satırları alır)
  var HEDEFLER = { eokul: { ad: 'e-Okul', anahtar: 'ng_ice_aktar', satirlar: eokulSatirlari } };
  var api = { satirla: satirla, sorulariBul: sorulariBul, bantPuan: bantPuan, sifirIsareti: sifirIsareti, ustBilgi: ustBilgi, sayfaOku: sayfaOku, sablonCikar: sablonCikar, konsensus: konsensus, toplamaUydur: toplamaUydur, adaylarAl: adaylarAl, tamamla: tamamla, ondalik: ondalik, analiz: analiz, eokulSatirlari: eokulSatirlari, HEDEFLER: HEDEFLER, kes: kes };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  kok.SoruBazli = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
