// 1.7.0 Soru bazlı (tüm sayfa) arayüzü. Tamamen yerel: görüntüler bellekte işlenir; yalnız isteğe bağlı Yerel Okuma servisine (127.0.0.1) gider.
// Hiçbir yere yüklenmez, Kaydet'e basılmaz. Hedef bağdaştırıcısı: SoruBazli.HEDEFLER (şimdilik e-Okul; OYSS/EBA sonra eklenir).
const $ = (id) => document.getElementById(id), S = globalThis.SoruBazli, I = globalThis.NGAIce || null;
const depo = (globalThis.chrome && chrome.storage && chrome.storage.local) || { get: (k, f) => f({}), set: (o, f) => f && f() };
const msg = (t) => { $('m').textContent = t; }, esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
let dosyalar = [], kayit = [], geri = [], SL = {}, pdfMod = null, tess = null;
const HEDEF_GEN = 1240; // ~150 dpi A4
fetch('rakam.bin').then((r) => r.arrayBuffer()).then((b) => { PuanOku.yukle(b); msg('Hazır. Sınav kâğıdı PDF/fotoğraflarını seçin (birden çok dosya, karışık şube olabilir).'); });
depo.get(['ng_sinif_listeleri', 'ng_sinif_listesi'], (s) => { const L = s.ng_sinif_listeleri || {};
  Object.keys(L).forEach((k) => ((L[k] && L[k].ogrenciler) || []).forEach((o) => { if (o.no) SL[String(o.no)] = { sinif: k, ad: o.ad || '' }; }));
  ((s.ng_sinif_listesi && s.ng_sinif_listesi.ogrenciler) || []).forEach((o) => { if (o.no && o.sinif) SL[String(o.no)] = { sinif: o.sinif, ad: o.ad || '' }; }); });
const sinifCoz = (v) => { const t = String(v || '').trim(); if (!t) return ''; if (I && I.sinifCoz) return I.sinifCoz(t) || ''; const m = t.match(/^(\d{1,2})\s*[-/. ]?\s*([A-Za-zÇĞİÖŞÜçğıöşü])$/); return m ? m[1] + '-' + m[2].toLocaleUpperCase('tr') : ''; };
const adTahmin = (ad) => { const m = String(ad).replace(/\.[^.]+$/, '').match(/(?:^|[^0-9])(9|1[0-2]|[1-8])\s*[-_ ]?\s*([a-zçğıöşü])(?![a-zçğıöşü])/i); return m ? m[1] + '-' + m[2].toLocaleUpperCase('tr') : ''; };
$('dosya').onchange = () => { dosyalar = [...$('dosya').files].map((f) => ({ f, sube: adTahmin(f.name) }));
  $('dosyalar').innerHTML = dosyalar.map((d, i) => `<div class="dosya">${esc(d.f.name)} → şube <input data-i="${i}" size="5" value="${esc(d.sube)}" placeholder="11-F"></div>`).join('');
  $('dosyalar').querySelectorAll('input').forEach((x) => { x.onchange = () => { dosyalar[+x.dataset.i].sube = sinifCoz(x.value) || x.value.trim(); }; }); $('oku').disabled = !dosyalar.length; };
async function sayfalar(f) { // → [{c, metin:[{t,x0,y0,x1,y1}]|null}]
  if (/pdf$/i.test(f.type) || /\.pdf$/i.test(f.name)) {
    const pdfjs = pdfMod || (pdfMod = await import('./pdf.min.mjs')); pdfjs.GlobalWorkerOptions.workerSrc = 'pdf.worker.min.mjs';
    const doc = await pdfjs.getDocument({ data: await f.arrayBuffer(), isEvalSupported: false }).promise, out = [];
    for (let i = 1; i <= doc.numPages; i++) { const p = await doc.getPage(i), v0 = p.getViewport({ scale: 1 }), v = p.getViewport({ scale: HEDEF_GEN / v0.width }), c = document.createElement('canvas'); c.width = Math.round(v.width); c.height = Math.round(v.height);
      await p.render({ canvasContext: c.getContext('2d'), viewport: v }).promise; let metin = null;
      try { const tc = await p.getTextContent(); const it = tc.items.filter((x) => x.str && x.str.trim()); if (it.length > 5) metin = it.map((x) => { const [a, , , d, e, ff] = pdfjs.Util.transform(v.transform, x.transform), h = Math.hypot(a, d) || Math.abs(d); return { t: x.str, x0: e, y0: ff - h, x1: e + x.width * v.scale, y1: ff }; }); } catch (e) { metin = null; }
      out.push({ c, metin }); }
    return out; }
  const b = await createImageBitmap(f), k = HEDEF_GEN / b.width, c = document.createElement('canvas'); c.width = HEDEF_GEN; c.height = Math.round(b.height * k); c.getContext('2d').drawImage(b, 0, 0, c.width, c.height); return [{ c, metin: null }];
}
async function basili(c) { // basılı satırlar: Yerel Okuma (PaddleOCR) → Tesseract
  try { if (globalThis.YerelOkuma && (await YerelOkuma.metinHazir())) { const r = await YerelOkuma.metin(YerelOkuma.png(c)); if (r && r.satirlar.length) return r.satirlar.map((s) => ({ t: s.t, x0: s.k[0], y0: s.k[1], x1: s.k[2], y1: s.k[3] })); } } catch (e) { }
  if (!globalThis.Tesseract) return [];
  const u = (p) => (globalThis.chrome && chrome.runtime && chrome.runtime.getURL) ? chrome.runtime.getURL('tarama/' + p) : new URL(p, location.href).href;
  tess = tess || await Tesseract.createWorker('tur', 1, { workerPath: u('lib/worker.min.js'), corePath: u('lib/tess-core/'), langPath: u('lib/lang'), workerBlobURL: false, cacheMethod: 'none' });
  const d = (await tess.recognize(c, {}, { blocks: true })).data, out = [];
  (d.blocks || []).forEach((b) => (b.paragraphs || []).forEach((p) => (p.lines || []).forEach((l) => out.push({ t: l.text.trim(), x0: l.bbox.x0, y0: l.bbox.y0, x1: l.bbox.x1, y1: l.bbox.y1 }))));
  return out;
}
function maskeler(c) { const W = c.width, H = c.height, v = c.getContext('2d').getImageData(0, 0, W, H).data, r = new Uint8Array(W * H), k = new Uint8Array(W * H);
  for (let i = 0; i < W * H; i++) { const R = v[4 * i], G = v[4 * i + 1], B = v[4 * i + 2], mx = Math.max(R, G, B), mn = Math.min(R, G, B); r[i] = mx - mn > 45 && mn < 200 ? 1 : 0; k[i] = 0.299 * R + 0.587 * G + 0.114 * B < 150 ? 1 : 0; }
  return { renkli: { w: W, h: H, d: r }, koyu: { w: W, h: H, d: k } }; }
async function servisIle(c, r) { // isteğe bağlı: Yerel Okuma servisi (Qwen+TrOCR) ile soru puanlarını uzlaştır
  try { if (!(globalThis.YerelOkuma && (await YerelOkuma.hazir()))) return; } catch (e) { return; }
  const al = r.sorular.filter((q) => q.kutu && !q.isaret), kir = (k) => { const p = 6, x = Math.max(0, k[0] - p), y = Math.max(0, k[1] - p), w = Math.min(c.width - x, k[2] + 2 * p), h = Math.min(c.height - y, k[3] + 2 * p), d = document.createElement('canvas'); d.width = w; d.height = h; d.getContext('2d').drawImage(c, x, y, w, h, 0, 0, w, h); return YerelOkuma.png(d); };
  const sn = await YerelOkuma.oku(al.map((q) => ({ tur: 'puan', png: kir(q.kutu) }))); if (!sn) return;
  al.forEach((q, i) => { const b = YerelOkuma.rakamBirlestir(q.puan == null ? '' : String(q.puan), q.guven || 0, sn[i]); if (!b) return; const v = b.deger === '' ? null : Number(String(b.deger).replace(',', '.'));
    if (b.emin && v != null && (q.max == null || v <= q.max)) { q.puan = v; if (/düşük güven|okunamadı|5'in katı/.test(q.neden)) { q.kontrol = false; q.neden = ''; } } else if (!b.emin) { q.kontrol = true; q.neden = b.not || q.neden; } });
}
$('oku').onclick = async () => { $('oku').disabled = true; kayit = []; geri = []; const t0 = Date.now(); let sy = 0;
  try { if (globalThis.YerelOkuma) await YerelOkuma.otoEslestir(); } catch (e) { }
  for (const d of dosyalar) { const sp = await sayfalar(d.f), oku = [];
    for (let i = 0; i < sp.length; i++) { $('ilerleme').textContent = d.f.name + ': basılı metin ' + (i + 1) + '/' + sp.length; sp[i].metin = sp[i].metin || await basili(sp[i].c); }
    let sablon = null; sp.forEach((s) => { const b = S.sorulariBul(s.metin, s.c.width, s.c.height).sorular; if (!sablon || b.length > sablon.length) sablon = b; });
    const ilk = kayit.length, ham = [];
    for (let i = 0; i < sp.length; i++) { $('ilerleme').textContent = d.f.name + ': puanlar ' + (i + 1) + '/' + sp.length; await new Promise((z) => setTimeout(z, 0));
      const s = sp[i], M = maskeler(s.c), r = S.sayfaOku(s.metin, M.renkli, s.c.width, s.c.height, { sablon, koyu: M.koyu });
      ham.push({ ders: r.ders, sorular: r.sorular }); await servisIle(s.c, r); r.toplam = r.sorular.reduce((t, q) => t + (Number(q.puan) || 0), 0);
      let no = r.ust.no ? r.ust.no.deger : ''; { const ad = (r.ust.noAday || []).find((x) => SL[x]); if (!SL[no] && ad) { no = ad; r.ust.no = { deger: ad, guven: 0.9 }; } } const L = SL[no], sinif = (L && sinifCoz(L.sinif)) || d.sube || (r.ust.duzey ? r.ust.duzey + '-?' : '?');
      const dersAd = r.ders ? r.ders.ad : ''; kayit.push({ ders: dersAd, dersKesin: !!(r.ders && r.ders.kesin), dosya: d.f.name, sayfa: i + 1, no, noKontrol: !r.ust.no || r.ust.no.guven < 0.8 || (Object.keys(SL).length && !L), ad: L ? L.ad : '', sinif, sorular: r.sorular.map((q) => ({ no: q.no, metin: q.metin || '', max: q.max, puan: q.puan, kontrol: q.kontrol, neden: q.neden })), kagit: r.saglama.toplam, toplam: r.toplam });
      sy++; }
    const K = S.konsensus(ham); kayit.slice(ilk).forEach((k) => { if (K.ders) k.ders = K.ders; k.sorular.forEach((q) => { if (K.metin[q.no]) q.metin = K.metin[q.no]; }); }); }
  kayit.forEach(hesap); { const dd = kayit.map((k) => k.ders).filter(Boolean); if (dd.length && !$('ders').value.trim()) $('ders').value = dd.sort((a, b) => dd.filter((x) => x === b).length - dd.filter((x) => x === a).length)[0]; } ciz(); $('islem').hidden = false; $('oku').disabled = false; $('ilerleme').textContent = '';
  const sar = kayit.filter((k) => k.kontrol).length; msg(`${sy} sayfa ${Math.round((Date.now() - t0) / 1000)} sn'de okundu. ${sar ? sar + ' kâğıtta sarı hücre var; kontrol edip düzeltin (+/−, Ctrl+Z geri alır).' : 'Hepsi tutarlı.'}`);
};
function hesap(k) { k.toplam = Math.round(100 * k.sorular.reduce((t, q) => t + (Number(q.puan) || 0), 0)) / 100; k.tutmuyor = k.kagit != null && k.kagit !== k.toplam;
  k.kontrol = k.sorular.some((q) => q.kontrol) || k.tutmuyor || !k.no || !/^\d{1,2}-[A-ZÇĞİÖŞÜ]$/.test(k.sinif); }
function degistir(i, j, v, onay) { const k = kayit[i]; geri.push(JSON.stringify(kayit)); if (geri.length > 200) geri.shift();
  if (j === 'no') { k.no = String(v).replace(/\D/g, ''); const L = SL[k.no]; if (L) { k.sinif = sinifCoz(L.sinif) || k.sinif; k.ad = L.ad; } k.noKontrol = false; }
  else if (j === 'sinif') k.sinif = sinifCoz(v) || String(v).trim();
  else if (j === 'kagit') k.kagit = v === '' ? null : Number(String(v).replace(',', '.'));
  else { const q = k.sorular[j]; let x = Number(String(v).replace(',', '.')); if (!isFinite(x)) x = 0; x = Math.max(0, q.max != null ? Math.min(q.max, x) : x); q.puan = x; if (onay !== false) { q.kontrol = false; q.neden = ''; } }
  hesap(k); ciz(); }
$('geri').onclick = () => { if (!geri.length) return; kayit = JSON.parse(geri.pop()); ciz(); };
document.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !/INPUT/.test((document.activeElement || {}).tagName || '')) { e.preventDefault(); $('geri').click(); } });
function gruplar() { const g = {}; kayit.forEach((k, i) => { (g[k.sinif] = g[k.sinif] || []).push(i); }); return g; }
function ciz() { const g = gruplar(), A = S.analiz(kayit.map((k) => ({ sinif: k.sinif, sorular: k.sorular, toplam: k.toplam, kontrol: k.kontrol })));
  $('tablolar').innerHTML = Object.keys(g).sort().map((s) => { const L = g[s], n = Math.max(...L.map((i) => kayit[i].sorular.length));
    const bas = '<tr><th>Okul No</th><th>Ad</th><th>Şube</th>' + Array.from({ length: n }, (_, j) => { const q = kayit[L[0]].sorular[j] || {}; return `<th title="${esc(q.metin)}">S${q.no || j + 1}<br><span class="k">/${q.max ?? '?'}</span></th>`; }).join('') + '<th>Toplam</th><th>Kâğıtta</th><th class="np">Kaynak</th></tr>';
    const dl = [...new Set(L.map((i) => kayit[i].ders).filter(Boolean))]; return `<h3>${esc(s)} — ${esc(dl.join(' / ') || 'ders okunamadı')} — ${L.length} kâğıt</h3><table>${bas}` + L.map((i) => { const k = kayit[i];
      return `<tr data-i="${i}"><td class="${k.noKontrol || !k.no ? 's' : ''}"><input data-j="no" value="${esc(k.no)}" style="width:60px"></td><td>${esc(k.ad)}</td><td class="${/^\d{1,2}-[A-ZÇĞİÖŞÜ]$/.test(k.sinif) ? '' : 's'}"><input data-j="sinif" value="${esc(k.sinif)}" style="width:48px"></td>` +
        k.sorular.map((q, j) => `<td class="${q.kontrol ? 's' : ''}" title="${esc(q.neden)}"><button data-j="${j}" data-d="-1">−</button><input data-j="${j}" value="${q.puan ?? ''}"><button data-j="${j}" data-d="1">+</button>${q.kontrol ? `<button data-j="${j}" data-ok="1" title="Doğru, onayla">✓</button>` : ''}</td>`).join('') +
        `<td><b>${k.toplam}</b></td><td class="${k.tutmuyor ? 's' : ''}" title="${k.tutmuyor ? 'Soru toplamı kâğıttaki toplamla tutmuyor' : ''}"><input data-j="kagit" value="${k.kagit ?? ''}"></td><td class="np k">${esc(k.dosya)} s.${k.sayfa}</td></tr>`; }).join('') + '</table>'; }).join('');
  $('tablolar').querySelectorAll('tr[data-i]').forEach((tr) => { const i = +tr.dataset.i;
    tr.querySelectorAll('input').forEach((x) => { x.onchange = () => degistir(i, isNaN(+x.dataset.j) ? x.dataset.j : +x.dataset.j, x.value); });
    tr.querySelectorAll('button[data-d]').forEach((b) => { b.onclick = () => { const q = kayit[i].sorular[+b.dataset.j], adim = (q.max || 100) >= 10 ? 5 : 1; degistir(i, +b.dataset.j, (Number(q.puan) || 0) + adim * +b.dataset.d); }; });
    tr.querySelectorAll('button[data-ok]').forEach((b) => { b.onclick = () => { const q = kayit[i].sorular[+b.dataset.j]; degistir(i, +b.dataset.j, q.puan ?? 0); }; }); });
  $('analiz').innerHTML = '<h2>Soru bazlı analiz</h2>' + A.sinif.map((c) => `<h3>${esc(c.sinif)} — ${c.ogrenci} öğrenci, ortalama ${c.ortalama} (en yüksek ${c.enYuksek}, en düşük ${c.enDusuk})${c.kontrol ? ', ' + c.kontrol + ' kâğıt kontrol bekliyor' : ''}</h3>
    ${c.ders ? '<p><b>Ders:</b> ' + esc(c.ders) + '</p>' : ''}<table><tr><th>Soru</th><th style="text-align:left">Soru metni</th><th>Azami</th><th>Ortalama</th><th>Başarı %</th><th></th><th>Tam puan</th><th>Kısmi</th><th>Sıfır</th></tr>${c.sorular.map((q) => `<tr><td>S${q.no}</td><td style="text-align:left;max-width:420px;font-size:13px">${esc(q.metin)}</td><td>${q.max ?? '?'}</td><td>${q.ort}</td><td><b>${q.basari ?? '–'}</b></td><td style="text-align:left;width:110px"><span class="bar" style="width:${Math.round(q.basari || 0)}px"></span></td><td>${q.dag.tam} (%${Math.round(100 * q.dag.tam / (q.n || 1))})</td><td>${q.dag.kismi} (%${Math.round(100 * q.dag.kismi / (q.n || 1))})</td><td>${q.dag.sifir} (%${Math.round(100 * q.dag.sifir / (q.n || 1))})</td></tr>`).join('')}</table>`).join('') +
    `<p><b>Genel:</b> ${A.genel.ogrenci} öğrenci, ortalama ${A.genel.ortalama}. En zor soru(lar): ${enZor(A)}</p>`; }
function enZor(A) { return A.sinif.map((c) => { const z = c.sorular.filter((q) => q.basari != null).sort((a, b) => a.basari - b.basari)[0]; return z ? `${c.sinif}: S${z.no} (%${z.basari})` : ''; }).filter(Boolean).join(', ') || '–'; }
$('excel').onclick = () => { const wb = XLSX.utils.book_new(), g = gruplar(), A = S.analiz(kayit);
  Object.keys(g).sort().forEach((s) => { const L = g[s].map((i) => kayit[i]), n = Math.max(...L.map((k) => k.sorular.length)), b = ['Okul No', 'Ad Soyad', 'Şube', 'Ders', ...Array.from({ length: n }, (_, j) => 'S' + ((L[0].sorular[j] || {}).no || j + 1) + ' (' + ((L[0].sorular[j] || {}).max ?? '?') + ')'), 'Toplam', 'Kâğıttaki toplam', 'Kontrol'];
    const c = A.sinif.find((x) => x.sinif === s), rows = [b, ...L.map((k) => [k.no, k.ad, k.sinif, k.ders, ...k.sorular.map((q) => q.puan), k.toplam, k.kagit, k.kontrol ? 'evet' : '']), [], ['Ortalama', '', '', '', ...c.sorular.map((q) => q.ort)], ['Başarı %', '', '', '', ...c.sorular.map((q) => q.basari)], ['Tam puan', '', '', '', ...c.sorular.map((q) => q.dag.tam)], ['Kısmi', '', '', '', ...c.sorular.map((q) => q.dag.kismi)], ['Sıfır', '', '', '', ...c.sorular.map((q) => q.dag.sifir)]];
    rows.push([], ['Soru', 'Azami', 'Soru metni'], ...c.sorular.map((q) => ['S' + q.no, q.max, q.metin])); XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), String(s).replace(/[\\/?*[\]:]/g, '_').slice(0, 31)); });
  XLSX.writeFile(wb, 'soru-analizi.xlsx'); };
$('yazdir').onclick = () => window.print();
$('gonder').onclick = () => { const sar = kayit.filter((k) => k.kontrol); if (sar.length && !confirm(sar.length + ' kâğıtta onaylanmamış sarı hücre var. Bunlar GÖNDERİLMEYECEK. Diğerleri gönderilsin mi?')) return;
  const iyi = kayit.filter((k) => !k.kontrol), H = S.HEDEFLER.eokul, sat = H.satirlar(iyi, $('ders').value.trim());
  depo.set({ [H.anahtar]: { z: Date.now(), tur: $('tur').value, sinav: Math.max(1, +$('n').value || 1), g: $('g').checked, ders: $('ders').value.trim(), kaynak: 'soru-bazli', satirlar: sat } },
    () => msg(sat.length + ' not gönderildi. e-Okul sekmesindeki panelde "Dosyadaki notları şube şube gir ▶" düğmesine basın (panel kapalıysa Alt+G). Kaydet\'e siz basarsınız.')); };
globalThis.__soruKayit = () => kayit.map((k) => ({ ders: k.ders, kesin: k.dersKesin, sorular: k.sorular.map((q) => q.metin) })); // test/inceleme: yalnız bu sekmede okunur
