/* Toplu yükle (1.4.0): telefonla çekilmiş fotoğrafları ve PDF'leri sıraya alır, düzeltir, mevcut okumaya gönderir. Hiçbir dosya bilgisayardan çıkmaz. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); }, sira = [], sayac = 0, isleniyor = false, bekleyen = [];
  var UZ = /\.(jpe?g|png|pdf|heic|heif)$/i;

  // ---- 1.5.0: sıra bu bilgisayarda (IndexedDB) saklanır; sayfa yenilense de kaybolmaz
  var DB = null;
  function db() { if (DB) return DB; DB = new Promise(function (ok) { try { var q = indexedDB.open('ng-toplu', 1); q.onupgradeneeded = function () { q.result.createObjectStore('sayfa', { keyPath: 'id' }); }; q.onsuccess = function () { ok(q.result); }; q.onerror = function () { ok(null); }; } catch (e) { ok(null); } }); return DB; }
  function islem(tur, f) { return db().then(function (d) { if (!d) return null; return new Promise(function (ok) { try { var t = d.transaction('sayfa', tur), st = t.objectStore('sayfa'), r = f(st); t.oncomplete = function () { ok(r && r.result); }; t.onerror = function () { ok(null); }; } catch (e) { ok(null); } }); }); }
  function saklaSayfa(s) { s.c.toBlob(function (b) { if (b) islem('readwrite', function (st) { st.put({ id: s.id, ad: s.ad, zaman: s.zaman, not: s.not, sira: sira.indexOf(s), blob: b, kucuk: s.kucuk }); }); }, 'image/jpeg', 0.9); }
  function siraSakla() { islem('readwrite', function (st) { sira.forEach(function (s, i) { if (!s.c) return; var q = st.get(s.id); q.onsuccess = function () { if (q.result) { q.result.sira = i; st.put(q.result); } }; }); }); }
  function silSayfa(id) { islem('readwrite', function (st) { st.delete(id); }); }
  async function geriYukle() {
    var hep = await islem('readonly', function (st) { return st.getAll(); }); if (!hep || !hep.length) return;
    hep.sort(function (a, b) { return a.sira - b.sira; });
    for (var i = 0; i < hep.length; i++) { var x = hep[i], b = await createImageBitmap(x.blob), c = document.createElement('canvas'); c.width = b.width; c.height = b.height; c.getContext('2d').drawImage(b, 0, 0); if (b.close) b.close();
      sayac = Math.max(sayac, x.id); sira.push({ id: x.id, ad: x.ad, zaman: x.zaman, not: x.not, c: c, kucuk: x.kucuk, durum: 'hazır (geri yüklendi)' }); }
    ciz(); mesaj(hep.length + ' sayfa önceki oturumdan geri yüklendi. İsterseniz "Sırayı boşalt" ile temizleyin.');
  }
  function mesaj(t) { $('tMesaj').textContent = t; }
  function heicMi(f) { return /\.(heic|heif)$/i.test(f.name) || /hei[cf]/i.test(f.type); }
  function pdfMi(f) { return /pdf$/i.test(f.type) || /\.pdf$/i.test(f.name); }
  function ekle(dosyalar) {
    var fs = [].slice.call(dosyalar).filter(function (f) { return UZ.test(f.name) || /^image\//.test(f.type) || pdfMi(f); }), atlanan = dosyalar.length - fs.length;
    var once = fs.length; fs = fs.filter(function (f) { return !sira.some(function (s) { return s.ad === yolAd(f) && s.zaman === (f.lastModified || 0); }) && !bekleyen.some(function (b) { return yolAd(b) === yolAd(f) && b.lastModified === f.lastModified; }); });
    var tekrar = once - fs.length; fs.forEach(function (f) { bekleyen.push(f); });
    mesaj(fs.length + ' dosya sıraya alındı.' + (tekrar ? ' ' + tekrar + ' dosya zaten sırada olduğu için atlandı.' : '') + (atlanan ? ' ' + atlanan + ' dosya resim/PDF olmadığı için atlandı.' : ''));
    isle();
  }
  function yolAd(f) { return f.webkitRelativePath || f.yol || f.name; }
  function kucukResim(c) { var k = 90 / c.height, t = document.createElement('canvas'); t.width = Math.max(1, Math.round(c.width * k)); t.height = 90; t.getContext('2d').drawImage(c, 0, 0, t.width, t.height); return t.toDataURL('image/jpeg', 0.7); }
  function duzeltCanvas(c) {
    if (!$('tDuzelt').checked) return { c: c, notlar: ['düzeltme kapalı'] };
    var x = c.getContext('2d'), im = x.getImageData(0, 0, c.width, c.height), o = FotoOnisle.onisle(globalThis.OtoBul ? OtoBul.kirmiziKoyu(im) : im, { enCok: 1800, isaretBul: globalThis.PuanOku && PuanOku.isaretBul }), y = document.createElement('canvas');
    y.width = o.width; y.height = o.height; y.getContext('2d').putImageData(new ImageData(o.data, o.width, o.height), 0, 0); return { c: y, notlar: o.notlar };
  }
  async function resimAc(f) {
    var b; try { b = await createImageBitmap(f, { imageOrientation: 'from-image' }); }
    catch (e) { if (heicMi(f)) throw new Error('HEIC biçimi bu tarayıcıda açılamıyor. iPhone\'da Ayarlar › Kamera › Biçimler › "En Uyumlu" seçin ya da fotoğrafı JPG olarak gönderin.'); throw new Error('resim açılamadı'); }
    var k = Math.min(1, 2600 / Math.max(b.width, b.height)), c = document.createElement('canvas'); c.width = Math.round(b.width * k); c.height = Math.round(b.height * k);
    c.getContext('2d').drawImage(b, 0, 0, c.width, c.height); if (b.close) b.close(); return [{ ad: yolAd(f), c: c }];
  }
  async function isle() {
    if (isleniyor) return; isleniyor = true;
    while (bekleyen.length) {
      var f = bekleyen.shift(), kayit = { id: ++sayac, ad: yolAd(f), zaman: f.lastModified || 0, durum: 'açılıyor…', hata: false };
      sira.push(kayit); ciz(); await new Promise(function (r) { setTimeout(r, 0); });
      try {
        var sayfalar = pdfMi(f) ? await globalThis.TaramaPdfSayfalar(f) : await resimAc(f);
        sira.splice(sira.indexOf(kayit), 1);
        for (var i = 0; i < sayfalar.length; i++) {
          var s = { id: ++sayac, ad: sayfalar.length > 1 ? (yolAd(f) + ' s.' + (i + 1)) : yolAd(f), zaman: (f.lastModified || 0) + i, durum: 'düzeltiliyor…', hata: false };
          sira.push(s); ciz(); await new Promise(function (r) { setTimeout(r, 0); });
          var d; try { d = duzeltCanvas(sayfalar[i].c); } catch (e2) { d = { c: sayfalar[i].c, notlar: ['düzeltilemedi, olduğu gibi kullanıldı'] }; } s.c = d.c; s.kucuk = kucukResim(d.c); s.durum = 'hazır'; s.not = d.notlar.join(', '); sayfalar[i].c = null; saklaSayfa(s); ciz();
        }
      } catch (e) { kayit.durum = e.message; kayit.hata = true; ciz(); }
    }
    isleniyor = false; ciz(); var h = sira.filter(function (s) { return s.c; }).length; mesaj(h + ' sayfa hazır. Sırayı kontrol edip "Okumaya gönder"e basın.');
  }
  function tasi(i, d) { var j = i + d; if (j < 0 || j >= sira.length) return; var t = sira[i]; sira[i] = sira[j]; sira[j] = t; ciz(); siraSakla(); }
  function ciz() {
    var L = $('tListe'); L.innerHTML = '';
    sira.forEach(function (s, i) {
      var r = document.createElement('div'); r.className = 'tSatir' + (s.hata ? ' tHata' : '');
      var n = document.createElement('b'); n.textContent = (i + 1) + '.'; r.appendChild(n);
      if (s.kucuk) { var im = document.createElement('img'); im.src = s.kucuk; im.alt = s.ad; im.title = 'Büyütmek/küçültmek için tıklayın'; im.onclick = function () { im.classList.toggle('tBuyuk'); if (im.classList.contains('tBuyuk')) im.src = s.c.toDataURL('image/jpeg', 0.8); else im.src = s.kucuk; }; r.appendChild(im); }
      var a = document.createElement('span'); a.className = 'tAd'; a.textContent = s.ad + ' — ' + s.durum + (s.not ? ' (' + s.not + ')' : ''); r.appendChild(a);
      [['▲', 'Yukarı taşı', function () { tasi(i, -1); }], ['▼', 'Aşağı taşı', function () { tasi(i, 1); }], ['−', 'Sıradan çıkar', function () { if (s.id) silSayfa(s.id); sira.splice(i, 1); ciz(); siraSakla(); }]].forEach(function (b) {
        var x = document.createElement('button'); x.className = 'btn'; x.textContent = b[0]; x.title = b[1]; x.setAttribute('aria-label', b[1]); x.onclick = b[2]; if (s.durum === 'açılıyor…' || s.durum === 'düzeltiliyor…') x.disabled = true; r.appendChild(x); });
      L.appendChild(r);
    });
    $('tSay').textContent = sira.filter(function (s) { return s.c; }).length + ' sayfa';
    $('tGonder').disabled = isleniyor || !sira.some(function (s) { return s.c; });
  }
  var ka = function (a, b) { return a.ad.localeCompare(b.ad, 'tr', { numeric: true }); };
  $('tAdSirala').onclick = function () { sira.sort(ka); ciz(); siraSakla(); };
  $('tZamanSirala').onclick = function () { sira.sort(function (a, b) { return a.zaman - b.zaman || ka(a, b); }); ciz(); siraSakla(); };
  $('tTemizle').onclick = function () { if (isleniyor) return; sira = []; islem('readwrite', function (st) { st.clear(); }); ciz(); mesaj('Sıra boşaltıldı.'); };
  $('tDosya').onchange = function () { ekle(this.files); this.value = ''; };
  $('tKlasor').onchange = function () { ekle(this.files); this.value = ''; };
  $('tGonder').onclick = function () {
    var s = sira.filter(function (x) { return x.c; }).map(function (x) { return { ad: x.ad, c: x.c }; });
    if (!s.length || !globalThis.TopluSayfaAyarla) return; globalThis.TopluSayfaAyarla(s);
    mesaj(s.length + ' sayfa okumaya gönderildi. Aşağıdaki "Kontrol edin" tablosunda sarı hücreleri kâğıtla karşılaştırın.'); $('oku').click();
  };
  // Sürükle-bırak (klasör de olur)
  var z = $('tBirak');
  async function girdiOku(g, yol, out) {
    if (g.isFile) { await new Promise(function (r) { g.file(function (f) { try { f.yol = yol + f.name; } catch (e) {} out.push(f); r(); }, r); }); }
    else if (g.isDirectory) { var rd = g.createReader(), parca; do { parca = await new Promise(function (r) { rd.readEntries(r, function () { r([]); }); }); for (var i = 0; i < parca.length; i++) await girdiOku(parca[i], yol + g.name + '/', out); } while (parca.length); }
  }
  z.ondragover = function (e) { e.preventDefault(); z.classList.add('tUstte'); };
  z.ondragleave = function () { z.classList.remove('tUstte'); };
  z.ondrop = async function (e) { e.preventDefault(); z.classList.remove('tUstte'); var it = e.dataTransfer.items, out = [];
    if (it && it.length && it[0].webkitGetAsEntry) { var gs = [].slice.call(it).map(function (x) { return x.webkitGetAsEntry(); }).filter(Boolean); for (var i = 0; i < gs.length; i++) await girdiOku(gs[i], '', out); }
    else out = [].slice.call(e.dataTransfer.files); ekle(out); };
  ciz(); geriYukle();
  // Okunmuş sonuç taslağı (tarama.js otomatik kaydı)
  var dp = globalThis.chrome && chrome.storage && chrome.storage.local;
  function taslakSor() { if (!dp) return; dp.get('tarama_taslak', function (o) { var t = o.tarama_taslak; if (!t || !t.sonuc || !t.sonuc.length) return;
    var k = $('tTaslak'); k.hidden = false; $('tTaslakBilgi').textContent = 'Kaydedilmiş okuma bulundu: ' + t.sonuc.length + ' sayfa (' + new Date(t.zaman).toLocaleString('tr-TR') + ').';
    $('tTaslakYukle').onclick = function () { var n = globalThis.TaramaTaslakYukle && TaramaTaslakYukle(t); k.hidden = true; mesaj(n ? n + ' sayfanın okuma sonucu ve düzeltmeleriniz geri yüklendi (küçük resimler yok).' : 'Geri yüklenemedi.'); };
    $('tTaslakSil').onclick = function () { dp.remove('tarama_taslak'); k.hidden = true; }; }); }
  setTimeout(taslakSor, 800);
  // Etkinlik nabzı: bu sayfa kullanılırken e-Okul sekmesi oturumu açık tutar (oturum.js)
  var sonIs = Date.now(); ['pointerdown', 'keydown', 'input'].forEach(function (t) { window.addEventListener(t, function () { sonIs = Date.now(); }, true); });
  function nabiz() { if (dp && (isleniyor || Date.now() - sonIs < 10 * 60 * 1000)) dp.set({ ng_tarama_aktif: Date.now() }); }
  setInterval(nabiz, 60000); nabiz();
  if (dp) { var obil = function (d) { $('tOturum').textContent = d && d.dustu ? 'e-Okul oturumu kapanmış görünüyor. Burada çalışmaya devam edebilirsiniz, hiçbir şey kaybolmaz; aktarmadan önce e-Okul\'a yeniden giriş yapın.' : ''; };
    dp.get('ng_oturum_durum', function (o) { obil(o.ng_oturum_durum); }); chrome.storage.onChanged.addListener(function (d, a) { if (a === 'local' && d.ng_oturum_durum) obil(d.ng_oturum_durum.newValue); }); }
  window.addEventListener('error', function (e) { mesaj('Beklenmeyen hata (verileriniz saklı): ' + (e.message || '') + '. Sayfayı yenileyebilirsiniz; sıra geri gelir.'); });
})();
