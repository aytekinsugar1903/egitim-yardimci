/* Kâğıttan alan okuma (Not Girişi Asistanı 1.6.18). Tamamen yerel: puan, Okul No, ders, ad soyad, sınıf.
   Yazı tanıma bu bilgisayarda kalır. Emin olunmayan alan sarıdır; uydurma yeşil verilmez. */
(function (kok) {
  'use strict';
  function OB() { return kok.OtoBul || (typeof require !== 'undefined' ? require('./otobul.js') : null); }
  function FO() { return kok.FotoOnisle || (typeof require !== 'undefined' ? require('./onisle.js') : null); }
  // İ/ı uzunluğunu bozmadan katlar (etiket araması orijinal metinle aynı indiste kalır)
  function fold(s) {
    var o = '', i, ch;
    for (i = 0; i < String(s || '').length; i++) {
      ch = String(s)[i];
      if (ch === 'İ' || ch === 'I' || ch === 'ı' || ch === 'i' || ch === 'İ') o += 'i';
      else if (ch === 'Ş' || ch === 'ş') o += 's';
      else if (ch === 'Ğ' || ch === 'ğ') o += 'g';
      else if (ch === 'Ü' || ch === 'ü') o += 'u';
      else if (ch === 'Ö' || ch === 'ö') o += 'o';
      else if (ch === 'Ç' || ch === 'ç') o += 'c';
      else o += ch.toLowerCase();
    }
    return o;
  }
  function sade(s) { return fold(s).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(); }
  function lev(a, b) {
    var m = a.length, n = b.length, d = [], i, j;
    for (i = 0; i <= m; i++) d[i] = [i];
    for (j = 1; j <= n; j++) d[0][j] = j;
    for (i = 1; i <= m; i++) for (j = 1; j <= n; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return m || n ? d[m][n] : 0;
  }
  // e-Okul ders adları. Kısa takma ad yalnız birebir; uzun ad yazım hatasına açıktır. Beceriler (listening) kesin sayılmaz.
  var DERS = [
    ['T.C. İnkılap Tarihi ve Atatürkçülük', ['tc inkilap tarihi ve ataturkculuk', 'inkilap tarihi ve ataturkculuk', 'inkilap tarihi', 'inkilap'], 0],
    ['Türk Dili ve Edebiyatı', ['turk dili ve edebiyati', 'edebiyat', 'edebiyati'], 0],
    ['Din Kültürü ve Ahlak Bilgisi', ['din kulturu ve ahlak bilgisi', 'din kulturu'], 0],
    ['Sağlık Bilgisi ve Trafik Kültürü', ['saglik bilgisi ve trafik kulturu', 'trafik kulturu'], 0],
    ['Beden Eğitimi ve Spor', ['beden egitimi ve spor', 'beden egitimi'], 0],
    ['Peygamberimizin Hayatı', ['peygamberimizin hayati'], 0],
    ['Görsel Sanatlar', ['gorsel sanatlar', 'gorsel sanat'], 0],
    ['Fen Bilimleri', ['fen bilimleri'], 0],
    ['Sosyal Bilgiler', ['sosyal bilgiler'], 0],
    ['İkinci Yabancı Dil', ['ikinci yabanci dil', 'almanca', 'fransizca', 'arapca', 'rusca', 'ispanyolca'], 0],
    ['Yabancı Dil', ['yabanci dil', 'ingilizce', 'english'], 0],
    ['Yabancı Dil', ['listening', 'speaking', 'reading', 'writing'], 1],
    ['Matematik', ['matematik'], 0],
    ['Geometri', ['geometri'], 0],
    ['Fizik', ['fizik'], 0],
    ['Kimya', ['kimya'], 0],
    ['Biyoloji', ['biyoloji'], 0],
    ['Tarih', ['tarih'], 0],
    ['Coğrafya', ['cografya'], 0],
    ['Felsefe', ['felsefe'], 0],
    ['Psikoloji', ['psikoloji'], 0],
    ['Sosyoloji', ['sosyoloji'], 0],
    ['Mantık', ['mantik'], 0],
    ['Müzik', ['muzik'], 0],
    ['Türkçe', ['turkce'], 0]
  ];
  function dersBul(metin) {
    var satir = String(metin || '').split(/\n/).map(function (l) { return l.replace(/\s+/g, ' ').trim(); }).filter(Boolean);
    // 1.6.27 Ders adı iki satıra bölünmüş olabilir ("... T.C. İNKILAP" / "TARİHİ VE ATATÜRKÇÜLÜK DERSİ"): komşu satırlar birleştirilip de denenir; uzun (tam) ad puanca öne geçer
    satir = satir.concat(satir.slice(0, -1).map(function (l, i) { return l + ' ' + satir[i + 1]; }));
    var en = [], i, j, k;
    satir.forEach(function (orig) {
      var l = sade(orig);
      if (!l) return;
      if (/\b(lisesi|lise|ortaokulu|ilkokulu|okulu|mudurlugu|koleji)\b/.test(l) && !/\bders/.test(l)) return;
      if (/\begitim ogretim yili|ogretim yili\b/.test(l) && !/\bders/.test(l)) return;
      var w = l.split(' ').filter(Boolean), dersli = /\bders[a-z]*\b/.test(l);
      DERS.forEach(function (row) {
        var ad = row[0], es = row[1], yumusak = row[2];
        es.forEach(function (e) {
          var n = e.split(' ').length, maxH = e.length <= 4 ? 0 : e.length <= 6 ? 1 / e.length : e.length < 9 ? 0.26 : 0.34;
          for (i = 0; i + n <= w.length; i++) {
            var parca = w.slice(i, i + n).join(' ');
            if (e === 'tarih' && /\d/.test(parca + ' ' + (w[i + n] || ''))) continue;
            if (e === 'not' ) continue;
            var hata = lev(parca, e) / Math.max(e.length, 1);
            if (hata > maxH) continue;
            var secmeli = i > 0 && lev(w[i - 1], 'secmeli') <= 1;
            var puan = e.length * (1 - hata) + (dersli ? 5 : 0) + (hata === 0 ? 2 : 0) + (n > 1 ? 2 : 0);
            en.push({ puan: puan, hata: hata, ders: (secmeli ? 'Seçmeli ' : '') + ad, yumusak: yumusak, e: e, dersli: dersli });
          }
        });
      });
    });
    if (!en.length) {
      var ft = sade(metin);
      if (/\b(exam|quiz|sinav)\b/.test(ft) && /\b(listening|speaking|reading|writing|grades?|class|name)\b/.test(ft)) return { ders: 'Yabancı Dil', kesin: false, puan: 6, alan: /listening|dinleme/.test(ft) ? 'D' : /speaking|konusma/.test(ft) ? 'K' : '' };
      return null;
    }
    en.sort(function (a, b) { return b.puan - a.puan; });
    var a = en[0], b = en.filter(function (x) { return x.ders !== a.ders; })[0];
    var fark = b ? a.puan - b.puan : 99;
    if (a.hata > 0 && fark < 1.5 && a.e.length < 8) return null;
    var alan = '';
    var ft2 = sade(metin);
    if (/dinleme|listening/.test(ft2)) alan = 'D'; else if (/konusma|speaking/.test(ft2)) alan = 'K';
    var kesin = (a.hata === 0 || (a.e.length >= 20 && a.hata <= 0.05)) && !a.yumusak && (a.dersli || a.e.length >= 8 || a.e.split(' ').length > 1) && !/^İkinci Yabancı/.test(a.ders) && !/^Seçmeli /.test(a.ders) && fark >= 1.5;
    if (a.yumusak) kesin = false;
    return { ders: a.ders, kesin: kesin, puan: a.puan, hata: a.hata, alan: alan };
  }
  function harfDuz(ch) { return /[a-z]/.test(ch) ? ch.toUpperCase() : ''; }
  function sinifKur(num, harf, kesin) { harf = harfDuz(fold(harf)); if (!harf || !/^(9|10|11|12)$/.test(num)) return null; return { sinif: num + '-' + harf, kesin: !!kesin }; }
  var RAKAM_HARF = { '0': 'O', '1': 'L', '2': 'Z', '5': 'S', '6': 'G', '8': 'B' };
  function sinifBul(t) {
    var f = fold(t).replace(/[^a-z0-9/.\-\s]/g, ' ').replace(/\s+/g, ' ').trim();
    f = f.replace(/\b1\s+([012])\b/g, '1$1');
    var m, r;
    m = f.match(/\b(9|10|11|12)\s*(?:\.?\s*sinif[a-z]*)\s*([a-z])\s*sube/);
    if (m && (r = sinifKur(m[1], m[2], true))) return r;
    m = f.match(/(?:sinif(?:i|\s*[-\/]\s*sube)?|sube|class|grade)\s*[:.;]?\s*(9|10|11|12)\s*[-\/.]\s*([a-z])\b/);
    if (m && (r = sinifKur(m[1], m[2], true))) return r;
    m = f.match(/(?:sinif(?:i|\s*[-\/]\s*sube)?|sube|class|grade)\s*[:.;]?\s*(9|10|11|12)\s*([a-z])\b/);
    if (m && (r = sinifKur(m[1], m[2], false))) return r;
    m = f.match(/\b(9|10|11|12)\s*[-\/]\s*([a-z])\b/);
    if (m && (r = sinifKur(m[1], m[2], true))) return r;
    m = f.match(/\b(9|10|11|12)\s*\.\s*([a-z])\b/);
    if (m && (r = sinifKur(m[1], m[2], false))) return r;
    // El yazısı harfi rakama dönmüşse (6→G, 8→B) düzeltilir ama sarı kalır; birden çok harfe uyan 0/1 uydurulmaz
    m = f.match(/\b(9|10|11|12)\s*[-\/]\s*([012568])\b/) || f.match(/(?:sinif|class|grade|sube)\s*[:.;]?\s*(9|10|11|12)\s*[-\/]?\s*([012568])\b/);
    if (m && RAKAM_HARF[m[2]] && (r = sinifKur(m[1], RAKAM_HARF[m[2]], false))) return r;
    m = f.match(/\b(10|11|12)\d\s*[-\/]\s*([a-z])\b/);
    if (m && (r = sinifKur(m[1], m[2], false))) return r;
    m = f.match(/\b16\s*[-\/]\s*([a-z])\b/);
    if (m && (r = sinifKur('10', m[1], false))) return r;
    m = f.match(/\b(9|10|11|12)\s*[0-9]\s*([a-z])\b/);
    if (m && (r = sinifKur(m[1], m[2], false))) return r;
    m = f.match(/(?:sinif|class|grade|sube)\s*[:.;]?\s*ş\s*([a-z])\b/);
    if (m && (r = sinifKur('9', m[1], false))) return r;
    // 1/l ve 0/o karışması yalnız rakam tarafında düzeltilir; harf uydurulmaz, sonuç sarı kalır
    m = f.match(/(?:sinif|class|grade|sube)\s*[:.;]?\s*([0-9ilo]{1,2})\s*[-\/]?\s*([a-z])/);
    if (m) {
      var num = m[1].replace(/[il]/g, '1').replace(/o/g, '0');
      if ((r = sinifKur(num, m[2], false))) return r;
    }
    return null;
  }
  function degerTemiz(s) {
    return String(s || '').replace(/\s+/g, ' ').replace(/^[:.\-]+/, '').trim();
  }
  function adTemiz(s) {
    s = degerTemiz(s).replace(/\b(sinif|sınıf|okul|puan|class|number|score|not)\b.*$/i, '').replace(/[^A-Za-zÇĞİIÖŞÜçğıöşüİıŞşĞğÜüÖöÇç .'-]/g, ' ').replace(/([a-zçğıöşü])([A-ZÇĞİÖŞÜ])/g, '$1 $2').replace(/\s+/g, ' ').trim();
    var par = s.split(' ').filter(Boolean);
    while (par.length > 1 && par[0].length === 1) par.shift();
    s = par.join(' ');
    if (sade(s).replace(/ /g, '').length < 3) return '';
    return s;
  }
  function puanCoz(chunk) {
    var f = fold(chunk);
    var m = f.match(/(?:puani?|score|notu?)\s*[:.;]?\s*([^\n]{1,12})/);
    if (!m) return null;
    var tok = m[1].trim().split(/\s+/).filter(Boolean);
    if (!tok.length) return null;
    if (/^[o]$/.test(tok[0])) return { v: '0', spaced: false, dirty: false };
    if (/^\d{1,3}[^0-9]?$/.test(tok[0]) && !(tok[1] && /^\d$/.test(tok[1]))) {
      var v1 = tok[0].replace(/\D/g, '');
      if (!v1 || +v1 > 100) return null;
      return { v: String(+v1), spaced: false, dirty: /[^0-9]/.test(tok[0]) };
    }
    var tek = [];
    for (var i = 0; i < tok.length && i < 3; i++) { if (/^\d$/.test(tok[i])) tek.push(tok[i]); else break; }
    if (tek.length >= 2) { var v2 = tek.join(''); if (+v2 <= 100) return { v: String(+v2), spaced: true, dirty: false }; }
    return null;
  }
  function noCoz(chunk) {
    var f = sade(chunk);
    var m = f.match(/\b(\d{3,6})\b/);
    return m ? m[1] : '';
  }
  // Bir satırdaki etiketlerin değerini, bir sonraki etikete kadar olan parçadan alır
  function satirAlan(orig) {
    var f = fold(orig), bul = [], re = [
      ['ad', /(?:adi\s*s[aeo]y\w{0,5}|ad\s*s[aeo]y\w{0,5}|s[aeo]yad\w{0,3}|name)\s*[:.;]?/g],
      ['sinifno', /sinif\s*[-\/]\s*numara\s*[:.;]?/g],
      ['no', /(?:okul\s*no|ogrenci\s*no|numarasi|number)\s*[:.;]?/g],
      ['no', /\bno\s*[:.;]/g],
      ['sinif', /(?:sinifi|sinif|sube|class|grade)\s*[:.;]?/g],
      ['puan', /(?:puani?|score|notu?)\s*[:.;]?/g]
    ];
    re.forEach(function (p) {
      var m; p[1].lastIndex = 0;
      while ((m = p[1].exec(f))) bul.push({ k: p[0], i: m.index, j: m.index + m[0].length });
    });
    bul.sort(function (a, b) { return a.i - b.i; });
    var temiz = [];
    bul.forEach(function (b) { if (!temiz.some(function (t) { return !(b.j <= t.i || b.i >= t.j); })) temiz.push(b); });
    var out = {};
    temiz.forEach(function (b, ix) {
      var son = temiz[ix + 1] ? temiz[ix + 1].i : orig.length;
      var parca = orig.slice(b.j, son);
      if (b.k === 'sinifno') {
        var sf = sade(parca), mm = sf.match(/\b(9|10|11|12)\s*[-\/]?\s*([a-z])\b\s*(\d{3,6})/);
        if (mm) { var sc = sinifKur(mm[1], mm[2], false); if (sc) { out.sinif = sc.sinif; out.sinifKesin = false; } out.no = mm[3]; out.noKaynak = 'sinif-numara'; }
        return;
      }
      if (b.k === 'ad') { out.adEtiket = true; var ad = adTemiz(parca); if (ad) out.ad = ad; }
      if (b.k === 'no') { var no = noCoz(parca); if (no) { out.no = no; out.noKaynak = 'etiket'; } }
      if (b.k === 'sinif') { var s = sinifBul(parca) || sinifBul(sade(parca)); if (s) { out.sinif = s.sinif; out.sinifKesin = s.kesin; } }
      if (b.k === 'puan') { out.puanEtiket = true; var p = puanCoz(fold(b.k + ' ' + parca)) || puanCoz('puan ' + parca); if (p) { out.puan = p.v; out.puanSpaced = p.spaced; out.puanDirty = p.dirty; } }
    });
    return out;
  }
  function adSatirMi(s) {
    var a = adTemiz(s); if (!a) return '';
    var w = a.split(' '); if (w.length < 2 || w.length > 4) return '';
    if (/\b(dersi|bakanligi|egitim|sinavi|exam|listening|puan|okul|sinif)\b/.test(sade(a))) return '';
    if (w.some(function (x) { return x.length > 16; })) return '';
    return a;
  }
  function cozumle(metin) {
    var out = { puan: '', no: '', ad: '', sinif: '', ders: '', alan: '', puanKesin: false, noKesin: false, adKesin: false, sinifKesin: false, dersKesin: false, puanSpaced: false, puanGuven: 0, noGuven: 0, pdf: false };
    var satir = String(metin || '').split(/\n/);
    satir.forEach(function (ln, idx) {
      if (!ln.trim()) return;
      var f0 = fold(ln), iki = f0.split(/[:.;]/);
      var etiket = /(?:adi\s*soy|okul\s*no|\bnumber\b|\bsinif\b|\bclass\b|\bpuani?\b|\bscore\b|\bname\b)/.test(f0);
      var bos = iki.length > 1 && !/[a-z0-9]/.test(iki.slice(1).join(''));
      var son = satir[idx + 1] || '';
      var sonEt = /(?:soy|okul\s*no|\bnumber\b|\bsinif\b|\bclass\b|\bpuan|\bscore\b|\bname\b)/.test(fold(son));
      var a = satirAlan((etiket && bos && son && !sonEt) ? ln + ' ' + son : ln);
      if (a.ad && !out.ad) out.ad = a.ad;
      else if (a.adEtiket && !out.ad && idx > 0) { var ust = adSatirMi(satir[idx - 1]); if (ust) out.ad = ust; }
      if (a.no && !out.no) { out.no = a.no; out.noKaynak = a.noKaynak || ''; out.noKesin = a.noKaynak === 'etiket' && /^\d{3,6}$/.test(a.no); out.noGuven = out.noKesin ? 86 : 74; }
      if (a.sinif && !out.sinif) { out.sinif = a.sinif; out.sinifKesin = !!a.sinifKesin; }
      if (a.puan && !out.puan) { out.puan = a.puan; out.puanSpaced = !!a.puanSpaced; out.puanDirty = !!a.puanDirty; out.puanKesin = !a.puanSpaced && !a.puanDirty; out.puanGuven = a.puanSpaced || a.puanDirty ? 72 : 86; }
      else if (a.puanEtiket && !out.puan && idx > 0 && /^\s*\d{1,3}\s*$/.test(satir[idx - 1])) { out.puan = String(+satir[idx - 1]); out.puanGuven = 78; out.puanKesin = false; }
    });
    if (!out.sinif) { var sb = sinifBul(metin); if (sb) { out.sinif = sb.sinif; out.sinifKesin = sb.kesin; } }
    var dz = dersBul(metin);
    if (dz) { out.ders = dz.ders; out.dersKesin = dz.kesin; out.dersPuan = dz.puan; if (dz.alan) out.alan = dz.alan; }
    if (!out.alan) { var ft = sade(metin); if (/dinleme|listening/.test(ft)) out.alan = 'D'; else if (/konusma|speaking/.test(ft)) out.alan = 'K'; }
    // 1.6.22 basılı başlık: "11. SINIF" -> seviye 11, "1. DÖNEM 1. SINAV" -> dönem 1, sınav 1
    Object.assign(out, basBilgi(metin));
    return out;
  }
  function birlestirAlan(pdf, ocr) {
    var o = ocr || cozumle('');
    if (!pdf) return o;
    ['ders', 'sinif', 'no', 'ad', 'puan', 'alan'].forEach(function (k) { if (pdf[k]) o[k] = pdf[k]; });
    if (pdf.ders) { o.dersKesin = pdf.dersKesin; o.dersPuan = pdf.dersPuan; }
    if (pdf.sinif) o.sinifKesin = pdf.sinifKesin;
    if (pdf.no) { o.noKesin = true; o.noGuven = 96; o.noKaynak = 'pdf'; }
    if (pdf.ad) { o.adKesin = true; o.adGuven = 96; }
    if (pdf.puan) { o.puanKesin = true; o.puanGuven = 96; o.puanSpaced = false; o.puanPdf = true; }
    o.pdf = true;
    return o;
  }
  function renkKoyu(img) {
    var n = img.width * img.height, d = img.data, o = new Uint8ClampedArray(d.length), i, r, g, b, mx, mn;
    for (i = 0; i < n; i++) {
      r = d[4 * i]; g = d[4 * i + 1]; b = d[4 * i + 2]; mx = Math.max(r, g, b); mn = Math.min(r, g, b);
      if (mx - mn > 32 && mn < 125) { var v = Math.min(mn, 55); o[4 * i] = o[4 * i + 1] = o[4 * i + 2] = v; }
      else { o[4 * i] = r; o[4 * i + 1] = g; o[4 * i + 2] = b; }
      o[4 * i + 3] = 255;
    }
    return { width: img.width, height: img.height, data: o };
  }
  function griResim(s) {
    var d = new Uint8ClampedArray(s.w * s.h * 4), i, v;
    for (i = 0; i < s.w * s.h; i++) { v = Math.max(0, Math.min(255, s.g[i] | 0)); d[4 * i] = d[4 * i + 1] = d[4 * i + 2] = v; d[4 * i + 3] = 255; }
    return { width: s.w, height: s.h, data: d };
  }
  function ger(s) {
    var n = s.g.length, or = [], i, ad = Math.max(1, (n / 4000) | 0);
    for (i = 0; i < n; i += ad) or.push(s.g[i]);
    or.sort(function (a, b) { return a - b; });
    var lo = or[Math.floor(or.length * 0.02)] || 0, hi = or[Math.floor(or.length * 0.98)] || 255;
    if (hi - lo < 25) return s;
    var o = new Float32Array(n);
    for (i = 0; i < n; i++) o[i] = Math.max(0, Math.min(255, (s.g[i] - lo) * 255 / (hi - lo)));
    return { g: o, w: s.w, h: s.h };
  }
  function buyut(s, hedef) {
    var k = hedef / s.w; if (k <= 1.05) return s;
    var W = Math.round(s.w * k), H = Math.round(s.h * k), o = new Float32Array(W * H), y, x;
    for (y = 0; y < H; y++) for (x = 0; x < W; x++) o[y * W + x] = s.g[Math.min(s.h - 1, (y / k) | 0) * s.w + Math.min(s.w - 1, (x / k) | 0)];
    return { g: o, w: W, h: H };
  }
  function cizgiTemiz(img) {
    var M = OB().murekkep(img, Math.min(img.width, 1700), true, true, { cizgiBirak: true, griDon: true, silDon: true });
    var o = new Float32Array(M.w * M.h), i;
    for (i = 0; i < o.length; i++) o[i] = M.sil[i] ? 255 : M.g[i];
    return ger({ g: o, w: M.w, h: M.h });
  }
  function hazirla(img) {
    var k = renkKoyu(img), o = k;
    try { var f = FO() && FO().onisle(k, { enCok: 1700 }); if (f && f.data) o = f; } catch (e) { o = k; }
    var t = cizgiTemiz(o);
    if (t.w < 1500) t = buyut(t, 1600);
    return griResim(t);
  }
  function grupla(words) {
    var w = (words || []).filter(function (q) { return q && q.t && String(q.t).trim(); }).slice().sort(function (a, b) { return (a.y0 - b.y0) || (a.x0 - b.x0); });
    var lines = [];
    w.forEach(function (q) {
      var ln = lines[lines.length - 1], h = Math.max(8, (q.y1 || 0) - (q.y0 || 0));
      if (!ln) { lines.push([q]); return; }
      var cy = ((q.y0 || 0) + (q.y1 || 0)) / 2, ly = (ln[0].y0 + ln[0].y1) / 2, lh = Math.max(8, ln[0].y1 - ln[0].y0);
      if (Math.abs(cy - ly) < Math.max(h, lh) * 0.65) ln.push(q); else lines.push([q]);
    });
    lines.forEach(function (ln) { ln.sort(function (a, b) { return a.x0 - b.x0; }); });
    return lines;
  }
  function metinYap(words) { return grupla(words).map(function (ln) { return ln.map(function (w) { return w.t; }).join(' '); }).join('\n'); }
  function etiketKonum(words) {
    var out = {}, lines = grupla(words);
    lines.forEach(function (ln) {
      ln.forEach(function (w, i) {
        var f = fold(w.t).replace(/[:.;]+$/g, '');
        if (!out.puan && /^(puan[i]?|score|notu?)$/.test(f)) { out.puan = w; out.puanSatir = ln; }
        if (!out.no && (/^(number|numara|numarasi)$/.test(f) || f === 'no' || /^okul$/.test(f) && ln[i + 1] && fold(ln[i + 1].t).replace(/[:.;]+$/g, '') === 'no')) { out.no = /^okul$/.test(f) && ln[i + 1] ? ln[i + 1] : w; out.noSatir = ln; }
        if (!out.sinif && /^(sinif[i]?|class|grade|sube)$/.test(f)) { out.sinif = w; out.sinifSatir = ln; }
        if (!out.ad && (f === 'name' || /soyad/.test(f))) { out.ad = w; out.adSatir = ln; }
        if (!out.ad && /^ad[i]?$/.test(f) && ln[i + 1] && /soyad/.test(fold(ln[i + 1].t))) { out.ad = ln[i + 1]; out.adSatir = ln; }
      });
    });
    return out;
  }
  function etiketMi(w) { var f = fold(w.t).replace(/[:.;]+$/g, ''); return /^(puan[i]?|score|notu?|number|numara|numarasi|no|okul|sinif[i]?|class|grade|sube|name|adi?|soyadi?)$/.test(f); }
  function degerKutu(label, satir, W, katW, katH) {
    var h = Math.max(12, label.y1 - label.y0);
    var sag = (satir || []).filter(function (w) { return w !== label && w.x0 >= label.x1 - h * 0.3 && !etiketMi(w); });
    if (sag.length) {
      var x0 = Math.max(0, Math.min.apply(null, sag.map(function (w) { return w.x0; })) - h * 0.35);
      var y0 = Math.min.apply(null, sag.map(function (w) { return w.y0; })) - h * 0.55;
      var x1 = Math.max.apply(null, sag.map(function (w) { return w.x1; })) + h * 0.45;
      var y1 = Math.max.apply(null, sag.map(function (w) { return w.y1; })) + h * 0.55;
      return { x: x0, y: y0, w: Math.max(h * 2, x1 - x0), h: Math.max(h * 2, y1 - y0) };
    }
    return sagKutu(label, W, katW || 14, katH || 3.8);
  }
  function sagKutu(w, W, katW, katH) {
    var h = Math.max(12, w.y1 - w.y0), x = w.x1 + h * 0.15, y = w.y0 - h * 0.85;
    return { x: x, y: y, w: Math.max(16, Math.min(W - x, h * (katW || 8))), h: h * (katH || 3.4) };
  }
  function altKutu(w, W) {
    var h = Math.max(12, w.y1 - w.y0);
    return { x: Math.max(0, w.x0 - h * 0.2), y: w.y1 + h * 0.05, w: Math.min(W, h * 9), h: h * 3 };
  }
  function kirp(img, k) {
    if (!k) return null;
    var x0 = Math.max(0, Math.floor(k.x)), y0 = Math.max(0, Math.floor(k.y));
    var x1 = Math.min(img.width, Math.ceil(k.x + k.w)), y1 = Math.min(img.height, Math.ceil(k.y + k.h));
    var w = x1 - x0, h = y1 - y0;
    if (w < 8 || h < 8) return null;
    var d = new Uint8ClampedArray(w * h * 4), y;
    for (y = 0; y < h; y++) d.set(img.data.subarray(((y0 + y) * img.width + x0) * 4, ((y0 + y) * img.width + x1) * 4), y * w * 4);
    return { width: w, height: h, data: d };
  }
  function koyu(img) {
    var n = 0, d = img.data, i, N = img.width * img.height;
    for (i = 0; i < N; i += 2) if (d[4 * i] < 145) n++;
    return n * 2;
  }
  function puanKarar(alan, cnn) {
    var t = alan.puan, c = cnn && cnn.deger ? String(+cnn.deger) : '', cg = cnn ? cnn.guven : 0;
    if (alan.puanPdf && t) { alan.puanGuven = 96; alan.puanKesin = true; return alan; }
    if (t && c && String(+t) === c) { alan.puan = c; alan.puanGuven = Math.max(90, cg); alan.puanKesin = true; alan.puanNeden = ''; return alan; }
    if (t && c && String(+t) !== c) {
      // Temiz basılı rakam (80) yazı tanımada durur; kirli/aralıklı el yazısı (10), o) rakam modeline bırakılır
      alan.puan = (!alan.puanSpaced && !alan.puanDirty) ? String(+t) : (cg >= 50 ? c : String(+t));
      alan.puanKesin = false; alan.puanGuven = 64; alan.puanNeden = 'yazı ' + t + ' / rakam ' + c; return alan;
    }
    if (t && !c) { alan.puanGuven = alan.puanSpaced ? 70 : 88; alan.puanKesin = false; alan.puanNeden = alan.puanNeden || 'yazı tek başına'; return alan; }
    if (!t && c && +c <= 100 && cg >= 48) { alan.puan = c; alan.puanGuven = Math.min(cg, 76); alan.puanKesin = false; alan.puanNeden = 'yalnız rakam modeli'; }
    return alan;
  }
  // 1.6.19: 4 haneli Okul No, 3 haneli yeni okumadan üstündür. Aynı uzunlukta tek hane ayrılığı eskiyi ancak açık güven farkıyla ezer.
  function noBirlestir(eski, eg, yeni, yg) {
    eski = eski ? String(eski) : ''; yeni = yeni ? String(yeni) : '';
    eg = +eg || 0; yg = +yg || 0;
    if (!yeni) return { deger: eski, guven: eg, neden: '' };
    if (!eski) return { deger: yeni, guven: yg, neden: '' };
    if (eski === yeni) return { deger: eski, guven: Math.max(eg, yg), neden: '' };
    var e4 = eski.length === 4, y4 = yeni.length === 4, fark = 0, i;
    if (e4 && !y4) return { deger: eski, guven: eg, neden: '4 hane korundu (' + yeni + ')' };
    if (y4 && !e4 && yg + 5 >= eg) return { deger: yeni, guven: yg, neden: '4 hane alındı' };
    if (eski.length === yeni.length) for (i = 0; i < eski.length; i++) if (eski[i] !== yeni[i]) fark++;
    if (fark === 1 && yg < eg + 20) return { deger: eski, guven: eg, neden: 'tek hane ayrılığı, eski korundu (' + yeni + ')' };
    if (yg > eg) return { deger: yeni, guven: yg, neden: '' };
    return { deger: eski, guven: eg, neden: '' };
  }
  function noKarar(alan, oy) {
    var t = alan.no || '', s = oy && oy.s ? oy.s : '';
    if (alan.noKaynak === 'pdf' && t) { alan.noKesin = true; alan.noGuven = 96; return alan; }
    if (t && s && t === s) { alan.no = s; alan.noGuven = Math.max(90, oy.guven || 0); alan.noKesin = !oy.belirsiz; alan.noNeden = oy.belirsiz ? 'iki aday' : ''; return alan; }
    if (t && s && t !== s) {
      var b = noBirlestir(t, alan.noGuven || 70, s, oy.guven || 0);
      alan.no = b.deger;
      alan.noKesin = false; alan.noGuven = Math.min(b.guven || 66, 74); alan.noNeden = b.neden || ('yazı ' + t + ' / rakam ' + s); alan.noAdaylar = oy.adaylar; return alan;
    }
    if (t && !s) { alan.noGuven = Math.max(alan.noGuven || 0, 80); return alan; }
    if (!t && s) { alan.no = s; alan.noGuven = Math.min(oy.guven || 60, 74); alan.noKesin = false; alan.noNeden = oy.neden || 'yalnız rakam modeli'; alan.noAdaylar = oy.adaylar; }
    return alan;
  }
  async function tamamla(img, orij, words, alan, opt) {
    var lab = etiketKonum(words), B = OB();
    if (lab.puan && !alan.puanPdf) {
      var pc = kirp(img, degerKutu(lab.puan, lab.puanSatir, img.width, 14, 3.8));
      if (!pc || koyu(pc) < 15) pc = kirp(img, altKutu(lab.puan, img.width));
      var cnn = pc ? B.yenidenOku(pc, { x: 0, y: 0, w: 1, h: 1 }, 100) : null;
      alan = puanKarar(alan, cnn);
      if (!alan.puan) {
        try {
          var pb0 = B.puanBul(orij, 100, (kok.PuanOku && kok.PuanOku.ESIK) || 80);
          if (pb0 && pb0.deger !== '' && +pb0.deger <= 100) { alan.puan = String(+pb0.deger); alan.puanGuven = Math.min(pb0.guven || 60, 74); alan.puanKesin = false; alan.puanNeden = pb0.neden || 'sayfada arandı'; }
        } catch (e) { /* rakam modeli yok */ }
      }
    } else if (!alan.puan) {
      try {
        var pb = B.puanBul(orij, 100, (kok.PuanOku && kok.PuanOku.ESIK) || 80);
        if (pb && pb.deger !== '' && +pb.deger <= 100) { alan.puan = String(+pb.deger); alan.puanGuven = Math.min(pb.guven || 60, 74); alan.puanKesin = false; alan.puanNeden = pb.neden || 'sayfada arandı'; }
      } catch (e) { /* model yoksa boş kalır */ }
    }
    if (lab.no && alan.noKaynak !== 'pdf') {
      var nc = kirp(img, degerKutu(lab.no, lab.noSatir, img.width, 14, 3.4));
      if (!nc || koyu(nc) < 15) nc = kirp(img, altKutu(lab.no, img.width));
      if (nc && B.noOku) { var oy = B.noOku(nc, { x: 0, y: 0, w: 1, h: 1 }, alan.no || ''); alan = noKarar(alan, oy); }
    }
    if (opt.ocr && lab.sinif && (!alan.sinif || !alan.sinifKesin)) {
      var sc = kirp(img, sagKutu(lab.sinif, img.width, 6, 3.2));
      if (sc && koyu(sc) > 10) {
        var so = await opt.ocr(sc, { psm: '7', whitelist: '0123456789ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ/-. ' });
        var sb = sinifBul((so && so.text) || '');
        if (sb && sb.sinif) {
          if (!alan.sinif) { alan.sinif = sb.sinif; alan.sinifKesin = false; }
          else if (alan.sinif === sb.sinif) alan.sinifKesin = alan.sinifKesin || sb.kesin;
          else { alan.sinifKesin = false; if (!alan.sinif) alan.sinif = sb.sinif; }
        }
      }
    }
    if (opt.ocr && lab.ad && (!alan.ad || sade(alan.ad).length < 4)) {
      var ac = kirp(img, sagKutu(lab.ad, img.width, 12, 3.2));
      if (ac && koyu(ac) > 12) {
        var ao = await opt.ocr(ac, { psm: '7' });
        var ad = adTemiz((ao && ao.text) || '');
        if (ad && sade(ad).length >= sade(alan.ad || '').length) alan.ad = ad;
      }
    }
    if (opt.ocr && !alan.ders) {
      var d2 = dersBul((await opt.ocr(img, { psm: '11' })).text || '');
      if (d2) { alan.ders = d2.ders; alan.dersKesin = false; if (d2.alan && !alan.alan) alan.alan = d2.alan; }
    }
    return alan;
  }
  async function workerOcr(worker, im, opts) {
    var c = kok.document.createElement('canvas'); c.width = im.width; c.height = im.height;
    c.getContext('2d').putImageData(new kok.ImageData(im.data, im.width, im.height), 0, 0);
    var psm = String((opts && opts.psm) || '6'), wl = (opts && opts.whitelist) || '';
    await worker.setParameters({ tessedit_pageseg_mode: psm, tessedit_char_whitelist: wl });
    var r = await worker.recognize(c), data = r.data || {};
    await worker.setParameters({ tessedit_pageseg_mode: '3', tessedit_char_whitelist: '' });
    var words = (data.words || []).map(function (w) {
      var b = w.bbox || { x0: 0, y0: 0, x1: 0, y1: 0 };
      return { t: w.text, x0: b.x0, y0: b.y0, x1: b.x1, y1: b.y1, c: w.confidence || 0 };
    }).filter(function (w) { return w.t && String(w.t).trim(); });
    return { text: data.text || '', words: words };
  }
  async function oku(img, opt) {
    opt = opt || {};
    var haz = hazirla(img);
    var pdfMetin = String(opt.pdfMetin || '');
    var pdfAlan = sade(pdfMetin).length >= 20 ? cozumle(pdfMetin) : null;
    var ocr = opt.ocr ? await opt.ocr(haz, { psm: '6' }) : { text: '', words: [] };
    var metin = (ocr.words && ocr.words.length) ? metinYap(ocr.words) : (ocr.text || '');
    if (opt.ocr && (!ocr.words || ocr.words.length < 4) && sade(metin).length < 12) {
      var o2 = await opt.ocr(haz, { psm: '11' });
      if ((o2.words || []).length > (ocr.words || []).length || sade(o2.text).length > sade(metin).length) { ocr = o2; metin = (o2.words && o2.words.length) ? metinYap(o2.words) : (o2.text || ''); }
    }
    var alan = birlestirAlan(pdfAlan, cozumle(metin));
    if (!alan.ders) { var d0 = dersBul(pdfMetin + '\n' + metin); if (d0) { alan.ders = d0.ders; alan.dersKesin = !!d0.kesin && !!pdfAlan; if (d0.alan) alan.alan = d0.alan; } }
    alan = await tamamla(haz, img, ocr.words || [], alan, opt);
    alan.ham = (metin || '').slice(0, 600);
    return alan;
  }
  async function okuCanvas(c, opt) {
    opt = opt || {};
    var ctx = c.getContext('2d', { willReadFrequently: true });
    var img = ctx.getImageData(0, 0, c.width, c.height);
    if (!opt.ocr && opt.worker) { var w = opt.worker; opt.ocr = function (im, o) { return workerOcr(w, im, o); }; }
    return oku(img, opt);
  }
  // Yeni okuma dersi boşsa eski başlık okuması doldurur. Yeni ders varsa eski ezilmez.
  function dersYedek(alan, eski) {
    if (!alan) return eski || { ders: '' };
    if (!alan.ders && eski && eski.ders) { alan.ders = eski.ders; alan.dersKesin = !!eski.dersKesin; alan.dersYedek = true; if (eski.alan && !alan.alan) alan.alan = eski.alan; }
    return alan;
  }
  function basBilgi(metin) { var t = sade(metin), o = {}, sv = t.match(/\b(9|10|11|12)\s*(?:sinif|siniflar|grade)\b/), sn = t.match(/\b([12])\s*donem\s*([1-4])\s*(?:sinav|sinavi|yazili|ortak sinav)\b/);
    if (sv) o.seviye = sv[1]; if (sn) { o.donem = +sn[1]; o.sinavNo = +sn[2]; } return o; }
  function basYap(a) {
    a = a || {};
    return { seviye: a.seviye || '', donem: a.donem || 0, sinavNo: a.sinavNo || 0, sinif: a.sinif || '', ders: a.ders || '', sinifKesin: !!a.sinifKesin, dersKesin: !!a.dersKesin, kesin: !!(a.sinifKesin && a.dersKesin), alan: a.alan || '', elYazisi: !!(a.sinif && !a.sinifKesin), elYaziDers: !!(a.ders && !a.dersKesin), _alan: a };
  }
  function adAday(raw, liste) {
    if (!raw || !liste || !liste.length || !OB()) return { ad: raw || '', kesin: false };
    var s = liste.map(function (o) { return { o: o, s: OB().benzer(raw, o.ad || '') }; }).sort(function (a, b) { return b.s - a.s; });
    if (s[0] && s[0].s >= 0.86 && (!s[1] || s[0].s - s[1].s >= 0.07)) return { ad: s[0].o.ad, kesin: s[0].s >= 0.95, no: String(s[0].o.no) };
    return { ad: raw, kesin: false };
  }
  // Okunan alanları sayfa sonucuna yazar. Şablon kutusunun güçlü okumasını bozmaz. Çelişki sarı kalır.
  function uygula(r, alan, liste, opts) {
    if (!r || !alan) return r;
    opts = opts || {}; liste = liste || [];
    r.bas = r.bas || { sinif: '', ders: '', sinifKesin: false, dersKesin: false, kesin: false, alan: '' };
    if (alan.ders) { r.bas.ders = alan.ders; r.bas.dersKesin = !!alan.dersKesin; }
    if (alan.sinif) { r.bas.sinif = alan.sinif; r.bas.sinifKesin = !!alan.sinifKesin; if (!alan.sinifKesin) r.bas.elYazisi = true; }
    if (alan.alan) r.bas.alan = alan.alan;
    r.bas.kesin = !!(r.bas.sinifKesin && r.bas.dersKesin);
    if (!opts.sablon && alan.puan && r.puanlar && r.puanlar.length === 1) {
      var p = r.puanlar[0], eski = p.deger == null ? '' : String(p.deger);
      if (!eski || p.kontrol || p.bos) { p.deger = alan.puan; p.guven = alan.puanGuven || 70; p.bos = false; p.kontrol = !alan.puanKesin; p.neden = alan.puanKesin ? '' : (alan.puanNeden || 'düşük güven'); }
      else if (eski === String(alan.puan)) { p.guven = Math.max(p.guven || 0, alan.puanGuven || 0); if (alan.puanKesin || p.guven >= 80) { p.kontrol = false; p.neden = ''; } }
      else if (alan.puanKesin) { p.deger = alan.puan; p.guven = alan.puanGuven || 90; p.kontrol = false; p.neden = ''; p.bos = false; }
      else { p.kontrol = true; p.neden = 'iki okuma (' + eski + ' / ' + alan.puan + ')'; if ((/rakam/.test(alan.puanNeden || '') && (alan.puanGuven || 0) >= 50) || (!alan.puanSpaced && !alan.puanDirty && alan.puan)) { p.deger = alan.puan; p.guven = 72; } }
    }
    if (!opts.sablon && alan.no) {
      if (liste.length && alan.no.length > 4) { var hits = []; for (var ni = 0; ni < alan.no.length; ni++) { var ks = alan.no.slice(0, ni) + alan.no.slice(ni + 1); if (ks.length >= 3 && liste.some(function (o) { return String(o.no) === ks; })) hits.push(ks); } hits = hits.filter(function (s, i) { return hits.indexOf(s) === i; }); if (hits.length === 1) { alan = Object.assign({}, alan, { no: hits[0], noKesin: false, noGuven: 68, noNeden: 'fazla hane' }); } }
      r.no = r.no || { deger: '', guven: 0 };
      var nb = noBirlestir(r.no.deger, r.no.guven, alan.no, alan.noGuven || 0);
      if (!r.no.deger || nb.deger !== String(r.no.deger)) { if (r.no.deger && nb.deger !== String(r.no.deger)) r.no.okunan = r.no.deger; r.no.deger = nb.deger; r.no.guven = nb.guven || alan.noGuven || 70; r.no.neden = nb.neden || (alan.noKesin ? '' : (alan.noNeden || 'düşük güven')); r.no.adaylar = alan.noAdaylar; r.no.belirsiz = false; }
      else if (String(r.no.deger) === String(alan.no)) { r.no.guven = Math.max(r.no.guven || 0, alan.noGuven || 0); if (alan.noKesin) r.no.neden = ''; }
      else if (nb.neden) r.no.neden = nb.neden;
    }
    if (alan.ad && !r.adSoyad) r.adSoyad = alan.ad;
    if (r.adSoyad && liste.length) {
      var ad = adAday(r.adSoyad, liste);
      if (ad.ad && ad.ad !== r.adSoyad && OB().benzer(r.adSoyad, ad.ad) >= 0.86) { r.adKagit = r.adSoyad; r.adSoyad = ad.ad; if (!ad.kesin) r.adSari = true; }
    }
    if (liste.length && OB()) {
      r.ogr = OB().ogrenciEsle(liste, r.no || { deger: '', guven: 0 }, r.adSoyad || '');
      if (r.ogr && r.ogr.no && r.no && r.ogr.no !== r.no.deger) { r.no.okunan = r.no.deger; r.no.deger = r.ogr.no; }
      if (r.adSari && r.ogr) r.ogr.kontrol = true;
      if (alan.noKesin && r.ogr && r.ogr.uyum === 'no+ad' && !r.no.okunan && OB().benzer(r.adSoyad || '', (r.ogr.oneri && r.ogr.oneri.ad) || '') >= 0.92) { r.ogr.kontrol = false; r.no.guven = Math.max(r.no.guven || 0, 90); }
      else if (r.ogr && r.adSoyad && OB().benzer(r.adSoyad, (r.ogr.oneri && r.ogr.oneri.ad) || r.adSoyad) < 0.92) r.ogr.kontrol = true;
    }
    return r;
  }
  var api = { basBilgi: basBilgi, oku: oku, okuCanvas: okuCanvas, uygula: uygula, basYap: basYap, noBirlestir: noBirlestir, dersYedek: dersYedek, dersBul: dersBul, sinifBul: sinifBul, cozumle: cozumle, hazirla: hazirla, fold: fold, sade: sade, adTemiz: adTemiz };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  kok.KagitOku = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
