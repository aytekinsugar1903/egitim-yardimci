/* El yazısı tarama sayfası. Görüntüler bu bilgisayarda işlenir; ağa hiçbir şey gönderilmez. */
const P = globalThis.PuanOku, $ = (id) => document.getElementById(id);
const depo = (globalThis.chrome && chrome.storage && chrome.storage.local) || {
  get: (k, f) => f(JSON.parse(localStorage.getItem('depo') || '{}')),
  set: (o, f) => { const d = JSON.parse(localStorage.getItem('depo') || '{}'); Object.assign(d, o); localStorage.setItem('depo', JSON.stringify(d)); f && f(); } };
let UST = 25; // 1.6.24: yazılı kâğıdında yalnız sayfanın üst %UST kısmı okunur (başlık, Okul No, puan); 100 = tüm sayfa
let maxlar = [10, 10, 10, 10, 10, 10, 10, 10, 10, 10], sayfalar = [], sonuc = [], alanlar = [], alanSira = 0, kopya = 1, alanYeni = false, dosyaImza = '', alanImza = null; // 1.6.23 alanYeni: kutu bu oturumda çizildi
const bildir = (t) => { $('mesaj').textContent = t; };
const tur = () => document.querySelector('input[name=tur]:checked').value;
const alanAd = (i) => (i === 0 ? 'Okul No' : i === 1 ? 'Ad Soyad' : 'S' + (i - 1));
const B = globalThis.OtoBul; let sinif = []; // 1.6.0 sınıf listesi (e-Okul tablosundan; yalnız bu bilgisayarda)
function soruBilgi() { $('soruBilgi').textContent = maxlar.length + ' soru · azami puanlar: ' + maxlar.join(', ') + ' (soru sayısını ve azami puanları e-Okul sayfasındaki tablodan değiştirin)'; $('esDeger').textContent = ' %' + P.ESIK + ' '; }
// 1.6.28 Sınıf listeleri şube başına tutulur (SL). Bir sayfa yalnız kendi başlığındaki sınıf-şubeye ait listeyle eşleştirilir; şubesiz (eski) liste
// yalnız okunan numaraların en az %40'ı onda birebir varsa kullanılır. Başka şubenin listesi ASLA kullanılmaz. sinif = o an işlenen grubun listesi.
let SL = {}, KEYSIZ = []; const LST = new Map(), skT = (v) => String(v || '').toLocaleLowerCase('tr-TR').replace(/[^0-9a-zçğıöşü]/g, '');
const listeAl = (r) => (r && r.lst && LST.get(r.lst)) || [];
function listeYukle(s) { SL = {}; KEYSIZ = []; const oo = (o) => ({ no: String(o.no), ad: o.ad || '' }), L = s.ng_sinif_listeleri || {};
  Object.keys(L).forEach((k) => { const a = ((L[k] && L[k].ogrenciler) || []).filter((o) => o.no).map(oo); if (a.length) SL[skT(k)] = { ad: k, liste: a }; });
  ((s.ng_sinif_listesi && s.ng_sinif_listesi.ogrenciler) || []).forEach((o) => { if (!o.no) return; if (o.sinif) { const k = skT(o.sinif); SL[k] = SL[k] || { ad: o.sinif, liste: [] }; if (!SL[k].liste.some((q) => q.no === String(o.no))) SL[k].liste.push(oo(o)); } else if (!KEYSIZ.some((q) => q.no === String(o.no))) KEYSIZ.push(oo(o)); }); }
const listeSay = () => Object.values(SL).reduce((t, x) => t + x.liste.length, 0) + KEYSIZ.length;
function grupListeSec(rows, g) { const k = skT(g);
  const ham = rows.map((r) => [r.no && r.no.deger, r.no && r.no.okunan, ...((r.no && r.no.adaylar) || [])].filter(Boolean).map(String));
  const isabet = (L) => { const S = new Set(L.map((o) => o.no)); return ham.filter((h) => h.some((v) => S.has(v))).length; };
  if (k && SL[k]) { // şube okuması yanlışsa (ör. el yazısı F→D): numaralar bu listede yok ama başka bir şubenin listesinde çoğunlukla varsa o şube (sarı)
    const hk = isabet(SL[k].liste), ob = Object.values(SL).filter((x) => x !== SL[k]).map((x) => ({ x, h: isabet(x.liste) })).sort((a, b) => b.h - a.h)[0];
    if (rows.length && hk < Math.ceil(rows.length * 0.3) && ob && ob.h >= Math.max(1, Math.ceil(rows.length * 0.5))) { rows.forEach((r) => { if (r.bas) { r.bas.sinifOkunan = r.bas.sinif; r.bas.sinif = ob.x.ad; r.bas.kesin = false; r.bas.sinifKesin = false; } });
      return { anahtar: ob.x.ad, liste: ob.x.liste, neden: g + ' okundu ama numaralar ' + ob.x.ad + ' listesinde — şubeyi kontrol edin' }; }
    return { anahtar: SL[k].ad, liste: SL[k].liste, neden: g + ' listesi' }; }
  if (k && rows.length) { // bu şubenin listesi yok: numaraların çoğu aynı seviyedeki başka bir şubenin listesinde birebir varsa şube yanlış okunmuştur (sarı)
    const sev = (String(g).match(/^\d{1,2}/) || [''])[0], ob = Object.values(SL).filter((x) => sev && (String(x.ad).match(/^\d{1,2}/) || [''])[0] === sev).map((x) => ({ x, h: rows.filter((r, i) => x.liste.some((o) => ham[i].includes(o.no))).length })).sort((a, b) => b.h - a.h)[0];
    if (ob && ob.h >= Math.max(1, Math.ceil(rows.length * 0.5))) { rows.forEach((r) => { if (r.bas) { r.bas.sinifOkunan = r.bas.sinif; r.bas.sinif = ob.x.ad; r.bas.kesin = false; r.bas.sinifKesin = false; } });
      return { anahtar: ob.x.ad, liste: ob.x.liste, neden: g + ' okundu ama numaralar ' + ob.x.ad + ' listesinde — şubeyi kontrol edin' }; } }
  const ad = [...(k ? [] : Object.values(SL).map((x) => ({ anahtar: x.ad, liste: x.liste }))), ...(KEYSIZ.length ? [{ anahtar: 'liste', liste: KEYSIZ }] : [])]; let en = null;
  ad.forEach((a) => { const h = isabet(a.liste); if (h >= Math.max(2, Math.ceil(rows.length * 0.4)) && (!en || h > en.h)) en = Object.assign({ h }, a); });
  return en ? { anahtar: en.anahtar, liste: en.liste, neden: 'numaraların ' + en.h + '/' + rows.length + ' listede' } : null; }
let GRUPLAR = [];
depo.get(['ng_sinif_listesi', 'ng_sinif_listeleri', 'tarama_ayar'], (s) => { listeYukle(s); if (s.tarama_ayar) { if (s.tarama_ayar.esik) P.ESIK = s.tarama_ayar.esik; if (s.tarama_ayar.alanlar) alanlar = s.tarama_ayar.alanlar; if (s.tarama_ayar.tur) setTimeout(() => kipSec(s.tarama_ayar.tur), 0); } soruBilgi(); alanCiz(); });
if (globalThis.chrome && chrome.storage && chrome.storage.onChanged) chrome.storage.onChanged.addListener((d, a) => { if (a === 'local' && (d.ng_sinif_listesi || d.ng_sinif_listeleri)) depo.get(['ng_sinif_listesi', 'ng_sinif_listeleri'], listeYukle); });
fetch('rakam.bin').then((r) => r.arrayBuffer()).then((b) => { P.yukle(b); bildir('Hazır. Kâğıtların fotoğraf/tarama dosyalarını seçin (JPEG, PNG, PDF; birden çok dosya olur).'); }).catch((e) => bildir('Rakam modeli yüklenemedi: ' + e.message));
function esik(d) { P.ESIK = Math.max(50, Math.min(99, P.ESIK + d)); ayarYaz(); soruBilgi(); if (sonuc.length) { sonuc.forEach((r) => P.kontrolEt(r.puanlar)); tabloCiz(); } }
$('esEksi').onclick = () => esik(-5); $('esArti').onclick = () => esik(5);
$('kEksi').onclick = () => { kopya = Math.max(1, kopya - 1); $('kDeger').textContent = kopya; };
$('kArti').onclick = () => { kopya = Math.min(60, kopya + 1); $('kDeger').textContent = kopya; };
// Basılabilir şablon (PDF ile aynı ölçüler, azami puanlar yazılı)
function sablonSvg() {
  const S = P.S, r = (x, y, w, h, ek) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" ${ek}/>`, t = (x, y, s, ek) => `<text x="${x}" y="${y}" ${ek}>${s}</text>`;
  let g = S.isaret.map(([x, y]) => r(x - 4, y - 4, 8, 8, 'fill="#000"')).join('');
  g += t(20, 20, 'ORTAK SINAV PUAN TABLOSU', 'font-size="4.2" font-weight="bold"') + t(190, 20, 'Evrak Asistanı · köşe karelerini kapatmayın', 'font-size="2.6" text-anchor="end"');
  g += t(20, 36, 'Okul No:', 'font-size="3.5" font-weight="bold"') + t(20, 40, 'her kutuya bir rakam', 'font-size="2.4"') + t(140, 30, 'Ad Soyad: ......................', 'font-size="2.5"') + t(140, 38, 'Sınıf/Şube: ...........', 'font-size="2.5"');
  for (let k = 0; k < S.no.adet; k++) { const b = P.noKutusu(k); g += r(b.x, b.y, b.w, b.h, 'fill="none" stroke="#999" stroke-width="0.25"'); }
  maxlar.forEach((m, j) => { const b = P.soruKutusu(j); g += r(b.x, b.y, b.w, b.h, 'fill="none" stroke="#999" stroke-width="0.25"') + t(b.x + 8, b.y - 2, 'S' + (j + 1) + ' (' + m + ')', 'font-size="2.8" font-weight="bold" text-anchor="middle"'); });
  g += t(18, 113, 'Puanı kutunun ortasına, kenarlara değdirmeden, koyu kalemle yazın. Yarım puan (,5) okunmaz; tabloda elle düzeltin. Boş kutu = puan yok.', 'font-size="2.4"');
  g += '<line x1="10" y1="127" x2="200" y2="127" stroke="#aaa" stroke-width="0.25" stroke-dasharray="2 2"/>';
  return `<div class="sayfa"><svg xmlns="http://www.w3.org/2000/svg" width="210mm" height="297mm" viewBox="0 0 210 297" font-family="Arial">${g}</svg></div>`;
}
$('yazdir').onclick = () => { if (maxlar.length > 20) return bildir('Şablon en çok 20 soru alır. Soru sayısını azaltın ya da serbest kâğıt kullanın.'); $('baski').innerHTML = sablonSvg().repeat(kopya); window.print(); };
// Dosyaları sayfa görüntülerine çevir
let pdfMod = null; // 1.6.0: pdf.js bir kez yüklenir
function pdfSatirlar(tc) {
  const items = ((tc && tc.items) || []).filter((it) => it.str && String(it.str).trim());
  items.sort((a, b) => (b.transform[5] - a.transform[5]) || (a.transform[4] - b.transform[4]));
  const lines = []; let cur = '', last = null;
  items.forEach((it) => { const y = it.transform[5]; if (last != null && Math.abs(y - last) > 5) { lines.push(cur.trim()); cur = ''; } else if (cur && !/\s$/.test(cur) && !/^\s/.test(it.str)) cur += ' '; cur += it.str; last = y; });
  if (cur.trim()) lines.push(cur.trim()); return lines.join('\n');
}
async function pdfSayfalar(f) {
  const pdfjs = pdfMod || (pdfMod = await import('./pdf.min.mjs')); pdfjs.GlobalWorkerOptions.workerSrc = 'pdf.worker.min.mjs';
  const doc = await pdfjs.getDocument({ data: await f.arrayBuffer(), isEvalSupported: false }).promise, out = [];
  for (let i = 1; i <= doc.numPages; i++) { const p = await doc.getPage(i), v = p.getViewport({ scale: 1 }), k = Math.min(3, 1800 / Math.max(v.width, v.height)), vp = p.getViewport({ scale: k });
    const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height; const x = c.getContext('2d', { willReadFrequently: true }); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
    await p.render({ canvasContext: x, viewport: vp, intent: 'print' }).promise;
    let metin = ''; try { metin = pdfSatirlar(await p.getTextContent()); } catch (e) { metin = ''; }
    out.push({ ad: f.name + ' s.' + i, c, metin }); p.cleanup(); }
  doc.destroy(); return out;
}
async function resimSayfa(f) {
  const b = await createImageBitmap(f, { imageOrientation: 'from-image' }), k = Math.min(1, 2400 / Math.max(b.width, b.height)), c = document.createElement('canvas');
  c.width = Math.round(b.width * k); c.height = Math.round(b.height * k); c.getContext('2d').drawImage(b, 0, 0, c.width, c.height); return [{ ad: f.name, c }];
}
$('dosya').onchange = async () => {
  sayfalar = []; const fs = [...$('dosya').files]; dosyaImza = fs.map((f) => f.name + ':' + f.size).join('|'); bildir('Dosyalar açılıyor…');
  for (const f of fs) { try { sayfalar.push(...(/pdf$/i.test(f.type) || /\.pdf$/i.test(f.name) ? await pdfSayfalar(f) : await resimSayfa(f))); } catch (e) { bildir(f.name + ' açılamadı: ' + e.message); } }
  $('sayfaBilgi').textContent = sayfalar.length + ' sayfa'; $('oku').disabled = !sayfalar.length; ilkCiz();
  bildir(sayfalar.length + ' sayfa hazır. ' + (tur() === 'serbest' ? 'Alanları işaretleyip "Oku"ya basın.' : '"Oku"ya basın.') + (alanlar.length ? ' Kayıtlı kutular kullanılacak: ' + alanlar.map((a) => (a.tur === 'no' ? 'Okul No' : a.tur === 'ad' ? 'Ad Soyad' : 'S' + (a.j + 1))).join(', ') + ' (değiştirmek için ilk sayfada yeniden çizin, silmek için ×).' : ''));
};
document.querySelectorAll('input[name=tur]').forEach((r) => (r.onchange = () => { ayarYaz(); $('serbest').hidden = tur() === 'sablon'; $('otoBilgi').hidden = tur() !== 'oto'; ilkCiz(); }));
// Serbest kâğıt: alan işaretleme
function alanCiz() {
  $('aDeger').textContent = alanAd(alanSira); const L = $('alanListe'); L.innerHTML = '';
  alanlar.forEach((a, i) => { const d = document.createElement('div'), b = document.createElement('button'); b.className = 'btn'; b.textContent = '−'; b.title = 'Alanı sil';
    b.onclick = () => { alanlar.splice(i, 1); kaydetAlan(); }; d.append(b, (a.tur === 'no' ? 'Okul No' : a.tur === 'ad' ? 'Ad Soyad' : 'S' + (a.j + 1)) + ' alanı'); L.appendChild(d); });
  ilkCiz();
}
function kaydetAlan() { ayarYaz(); alanCiz(); }
// 1.6.8: seçilen kip de hatırlanır (ilk kullanımdan sonra Serbest kâğıt varsayılan olur)
function ayarYaz() { depo.set({ tarama_ayar: { esik: P.ESIK, alanlar, tur: tur() } }); }
function kipSec(k) { const r = document.querySelector('input[name=tur][value=' + k + ']'); if (r && !r.checked) { r.checked = true; r.onchange && r.onchange(); } }
const alanSay = () => (tur() === 'oto' ? 2 : maxlar.length + 2);
$('aEksi').onclick = () => { alanSira = (alanSira + alanSay() - 1) % alanSay(); alanCiz(); };
$('aArti').onclick = () => { alanSira = (alanSira + 1) % alanSay(); alanCiz(); };
function ilkCiz() {
  const c = $('ilk'); if (tur() === 'sablon' || !sayfalar[0]) return; const s = sayfalar[0].c, k = Math.min(1, 900 / s.width);
  c.width = s.width * k; c.height = s.height * k; const x = c.getContext('2d'); x.drawImage(s, 0, 0, c.width, c.height);
  x.lineWidth = 3; x.font = 'bold 16px Arial';
  alanlar.forEach((a) => { x.strokeStyle = a.tur === 'no' ? '#0050ff' : a.tur === 'ad' ? '#007a00' : '#d00000'; x.strokeRect(a.x * c.width, a.y * c.height, a.w * c.width, a.h * c.height); x.fillStyle = x.strokeStyle; x.fillText(a.tur === 'no' ? 'No' : a.tur === 'ad' ? 'Ad' : 'S' + (a.j + 1), a.x * c.width + 3, a.y * c.height + 16); });
}
(() => { const c = $('ilk'); let b = null;
  const nokta = (e) => { const r = c.getBoundingClientRect(); return [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]; };
  c.onpointerdown = (e) => { b = nokta(e); c.setPointerCapture(e.pointerId); };
  c.onpointermove = (e) => { if (!b) return; ilkCiz(); const [x, y] = nokta(e), g = c.getContext('2d'); g.strokeStyle = '#000'; g.setLineDash([6, 4]); g.strokeRect(b[0] * c.width, b[1] * c.height, (x - b[0]) * c.width, (y - b[1]) * c.height); g.setLineDash([]); };
  c.onpointerup = (e) => { if (!b) return; const [x, y] = nokta(e), a = { x: Math.min(b[0], x), y: Math.min(b[1], y), w: Math.abs(x - b[0]), h: Math.abs(y - b[1]) }; b = null;
    if (a.w < 0.01 || a.h < 0.01) return ilkCiz();
    a.tur = alanSira === 0 ? 'no' : alanSira === 1 ? 'ad' : 'soru'; a.j = alanSira === 0 || alanSira === 1 ? -1 : alanSira - 2;
    alanlar = alanlar.filter((q) => !(q.tur === a.tur && q.j === a.j)); alanlar.push(a); alanYeni = true; alanImza = dosyaImza; alanSira = (alanSira === 0 && alanSay() > 2 && !alanlar.some((q) => q.tur === 'soru')) ? 2 : (alanSira + 1) % alanSay(); kaydetAlan(); }; // 1.6.24: Okul No'dan sonra doğrudan puan (S1); Ad Soyad isteğe bağlı (◀ ile)
})();
// Okuma
$('oku').onclick = async () => {
  if (!P.hazir()) return bildir('Model henüz yüklenmedi.');
  // 1.6.8: köşe işaretleri yoksa Serbest kâğıda geçilir; alan yoksa ilk sayfa gösterilip alan çizmeniz istenir
  if (tur() === 'sablon' && sayfalar[0]) { const s0 = sayfalar[0].c, r0 = P.sablonOku(s0.getContext('2d').getImageData(0, 0, s0.width, s0.height), maxlar);
    if (!r0.hizali) { kipSec('serbest'); bildir('Köşe işaretleri bulunamadı; "Serbest kâğıt" kipine geçildi.'); } }
  // 1.6.23: önceki bir oturumda (başka kâğıt düzeni için) çizilip kaydedilmiş kutular sessizce uygulanırsa numara/puan bozuk çıkar (puan G).
  // Bu oturumda kutu çizilmediyse ve kâğıtta Okul No etiketi kendiliğinden bulunuyorsa eski kutular bırakılır.
  // 1.6.24: kayıtlı Okul No kutusu ilk sayfada anlamlı bir numara okuyorsa kutular her zaman korunur (elle işaretlenen kutular hatırlanır)
  let kutuIyi = false; { const nA = alanlar.find((a) => a.tur === 'no'); if (nA && sayfalar[0]) { try { const s0 = sayfalar[0].c, v0 = B.noOku(s0.getContext('2d').getImageData(0, 0, s0.width, s0.height), nA, ''); kutuIyi = !!(v0 && /^\d{3,6}$/.test(v0.s || '')); } catch (e) { kutuIyi = false; } } }
  // 1.6.28 Düzen değişikliği: kutular bu dosyada çizilmediyse ve kâğıtta Okul No etiketi bulunuyorsa, kayıtlı Okul No kutusu etiketin
  // üstüne düşmüyorsa (başka düzen) bütün eski kutular atılır; Okul No / puan kâğıttan kendiliğinden bulunur
  const buDosya = alanYeni && alanImza === dosyaImza;
  if (tur() === 'serbest' && alanlar.length && !buDosya && sayfalar[0] && B.etiketNo) { let f0 = null; try { f0 = await (B.noBul || B.etiketNo)(sayfalar[0].c); } catch (e) { f0 = null; }
    const nA = alanlar.find((a) => a.tur === 'no'), ust = (a, k) => { if (!a || !k) return 0; const p = 0.02, x0 = Math.max(a.x, k.x - p), y0 = Math.max(a.y, k.y - p), x1 = Math.min(a.x + a.w, k.x + k.w + p), y1 = Math.min(a.y + a.h, k.y + k.h + p); return x1 > x0 && y1 > y0 ? ((x1 - x0) * (y1 - y0)) / Math.max(1e-6, a.w * a.h) : 0; };
    const uyar = f0 && f0.no && f0.kutu ? ust(nA, f0.kutu) >= 0.3 : kutuIyi;
    if (f0 && f0.no && !uyar) { alanlar = []; ayarYaz(); try { ilkCiz(); } catch (e) { } alanYeni = false; bildir('Kâğıt düzeni değişmiş: önceki kutular bu kâğıda uymadığı için bırakıldı; Okul No ve puan kâğıttan kendiliğinden bulunuyor. Kutu kullanmak isterseniz ilk sayfada yeniden çizin.'); } }
  let etkVar = false; if (tur() === 'serbest' && !alanlar.some((a) => a.tur === 'no') && sayfalar[0] && B.etiketNo) { try { etkVar = !!(await (B.noBul || B.etiketNo)(sayfalar[0].c)).no; } catch (e) { etkVar = false; } }
  if (tur() === 'serbest' && !alanlar.some((a) => a.tur === 'no') && !etkVar) { kipSec('serbest'); alanSira = 0; alanCiz(); $('ilk').scrollIntoView({ block: 'center' });
    return bildir('İlk sayfada sırayla fareyle sıkı çerçeve çizin: Okul No, Ad Soyad, sonra puan (toplam puan için S1). Puan alanını çizmezseniz toplam puanı asistan kendisi arar. Sonra "Oku"ya basın; aynı alanlar bütün sayfalara uygulanır.'); }
  $('oku').disabled = true; sonuc = []; TANI.sayfalar = []; const t0 = Date.now(); sinif = []; LST.clear(); GRUPLAR = []; // 1.6.28 sayfalar önce listesiz okunur
  kosu = t0; sonTaslak = ''; depo.set({ tarama_taslak: { zaman: t0, kosu, bitti: false, maxlar, sonuc: [] }, ng_not_tablosu: null }); // 1.6.25: yeni okuma eski sonuçları siler; panel yalnız bu okumayı gösterir
  try { if (globalThis.YerelOkuma) await YerelOkuma.otoEslestir(); } catch (e) { } // 1.6.26 servis açıksa kendiliğinden bağlan
  let yerelAcik = false; try { yerelAcik = !!(globalThis.YerelOkuma && (await YerelOkuma.hazir())); } catch (e) { yerelAcik = false; } // 1.6.20
  try { yerelMetin = !!(globalThis.YerelOkuma && YerelOkuma.metinHazir && (await YerelOkuma.metinHazir())); } catch (e) { yerelMetin = false; } // 1.6.26 PaddleOCR başlık
  for (let i = 0; i < sayfalar.length; i++) { $('ilerleme').textContent = 'Okunuyor: ' + (i + 1) + '/' + sayfalar.length; await new Promise((r) => setTimeout(r, 0));
    const s0 = sayfalar[i], s = ustAcik() ? Object.assign({}, s0, { c: ustMaske(s0.c) }) : s0, img = s.c.getContext('2d').getImageData(0, 0, s.c.width, s.c.height); // 1.6.24 yalnız üst bölge
    let r; try { r = tur() === 'serbest' ? serbestOku(img) : tur() === 'oto' ? otoOku(img) : P.sablonOku(img, maxlar); } catch (e) { r = { hizali: false, hata: e.message }; }
    // 1.6.17 Puan sağlaması: soru puanları okunduysa kâğıttaki toplam puanla karşılaştırılır; tutmazsa hepsi sarı
    if (r.hizali && r.puanlar && r.puanlar.length > 1 && B.puanBul) { try { const tp = B.puanBul(img, 100, P.ESIK), top = r.puanlar.reduce((t, p) => t + (Number(p.deger) || 0), 0);
      r.saglama = { toplam: tp && tp.deger !== '' ? Number(tp.deger) : null, soruToplam: top };
      if (tp && tp.deger !== '' && !tp.kontrol && Number(tp.deger) !== top) r.puanlar.forEach((p) => { p.kontrol = true; p.neden = 'toplam tutmuyor (kâğıtta ' + tp.deger + ', sorular ' + top + ')'; }); } catch (e) { } }
    if (r.hizali && tur() !== 'sablon') { try { await noYeni(r, img, s.c); } catch (e) { console.log('Okul No oylama atlandı'); } }
    r.ad = s.ad; if (r.hizali) { try { await kimlik(r, s.c); } catch (e) { r.ogr = { kontrol: true, neden: 'ad okunamadı' }; } }
    if (r.hizali) { try { yerelKirp(r, s.c); } catch (e) { /* kırpılamazsa servis bu sayfayı atlar */ } } // 1.6.27 elle kutu dahil her yol
    try { r.bas = await basOku(s.c, s.metin || ''); } catch (e) { r.bas = { sinif: '', ders: '', kesin: false }; }
    if (r.bas && r.bas._alan && globalThis.KagitOku) { try { KagitOku.uygula(r, r.bas._alan, sinif, { sablon: tur() === 'sablon' }); } catch (e) { /* alan birleştirilemezse eski okuma durur */ } }
    if (r.etiket && r.etiket.sinif && r.bas && !r.bas.sinifKesin) { r.bas.sinif = r.etiket.sinif; r.bas.elYazisi = true; r.bas.kesin = false; } basDevir(r, sonuc[sonuc.length - 1]); try { taniSayfa(r, s); } catch (e) { TANI.hatalar.push('tani: ' + e.message); } sonuc.push(r); }
  for (let i = sonuc.length - 2; i >= 0; i--) basDevir(sonuc[i], sonuc[i + 1], true); // 1.6.26 geriye yalnız boşları doldurur
  try { subeOy(sonuc, true); } catch (e) { }
  if (sonuc.length) console.log('Not Girişi tarama: ' + sonuc.length + ' sayfa, ' + Math.round((Date.now() - t0) / sonuc.length) + ' ms/sayfa');
  // 1.6.28 Sınıf-şube grupları: her grup kendi listesiyle (varsa) işlenir; servis her grupta birincil okuyucu
  const gm = new Map(); sonuc.forEach((r) => { const g = (r.bas && r.bas.sinif) || ''; if (!gm.has(g)) gm.set(g, []); gm.get(g).push(r); });
  for (const [g, rows] of gm) { const ls = grupListeSec(rows.filter((r) => r.hizali), g); sinif = ls ? ls.liste : []; const an = ls ? ls.anahtar : '';
    if (an) LST.set(an, sinif); rows.forEach((r) => { r.lst = an; r.grup = g; if (r.hizali && r.no) { try { kimlikListe(r); } catch (e) { } } });
    try { haneDuzelt(rows); } catch (e) { console.log('İlk hane düzeltmesi atlandı'); } // 1.6.25
    if (yerelAcik) { try { await yerelTur(rows); } catch (e) { console.log('Yerel okuma servisi turu atlandı'); } } // 1.6.20: servis kapalı/hata → yerel okuma aynen
    try { const n = listeOtur(rows); if (n) console.log('Sınıf listesine oturtulan Okul No: ' + n); } catch (e) { console.log('Liste eşlemesi atlandı'); } // 1.6.26
    GRUPLAR.push({ sinif: g, sayfa: rows.length, liste: an, listeNeden: ls ? ls.neden : '' }); }
  sinif = [];
  KIRP.clear(); sonuc.forEach((r, i) => { if (r._yerel) KIRP.set(i, r._yerel); delete r._yerel; }); // 1.6.27 ölçüm verisi için yalnız bellekte
  try { await geminiTur(); } catch (e) { console.log('Gemini turu atlandı'); }
  $('ilerleme').textContent = ''; $('oku').disabled = false; taslakYaz(true); tabloCiz(); notlarKur(); if (BASIT && $('notYaz')) $('notYaz').click();
  const hz = sonuc.filter((r) => !r.hizali).length, sari = sonuc.reduce((t, r) => t + (r.puanlar ? r.puanlar.filter((p) => p.kontrol).length : 0) + (r.hizali && noSari(r) ? 1 : 0), 0);
  const gOz = GRUPLAR.map((g) => (g.sinif || 'şube ?') + ': ' + g.sayfa + ' kâğıt' + (g.liste ? ' (liste ' + g.liste + ')' : ' (liste yok)')).join(', '), listeVar = GRUPLAR.some((g) => g.liste);
  bildir(sonuc.length + ' sayfa okundu. ' + sari + ' sarı hücre kontrol bekliyor.' + (GRUPLAR.length ? '\nGruplar: ' + gOz + (GRUPLAR.length > 1 ? '. Not tablosunda şubeler ayrı; panel e-Okul\'da şubeleri sırayla yazar (her şubede Listele, Güvenlik Kodu ve Kaydet sizde).' : '') : '') + (hz ? '\n' + hz + ' sayfa okunamadı (listede kırmızı); yeniden çekin veya serbest kâğıt ile deneyin.' : '') + (listeVar ? '' : '\n⚠ Bu kâğıtların şubesine ait sınıf listesi yok (başka şubenin listesi kullanılmaz): numaralar yerel servis/tarayıcı okumasıyla, sarı. e-Okul\'da bu sınıfın Ders Notu Girişi sayfasında Listele\'ye bir kez basın (liste bu bilgisayarda saklanır), sonra yeniden Oku\'ya basın.'));
};
// 1.6.8 Serbest kâğıt: yalnız S1 çizildiyse toplam puan (100 üzerinden) sayılır; puan alanı yoksa toplam puan kendisi aranır
function serbestOku(img) {
  const sor = alanlar.filter((a) => a.tur === 'soru');
  if (!sor.length) return otoOku(img);
  if (sor.length === 1 && sor[0].j === 0) { const r = P.alanOku(img, alanlar.filter((a) => a.tur !== 'ad'), [100]); r.oto = true; return r; }
  return P.alanOku(img, alanlar.filter((a) => a.tur !== 'ad'), maxlar);
}
// 1.6.0 Otomatik kip: kâğıttaki toplam puanı kendisi bulur; Okul No alanı işaretliyse okur
function otoOku(img) {
  const top = maxlar.length === 1 ? maxlar[0] : 100, pu = B.puanBul(img, top, P.ESIK), noA = alanlar.find((a) => a.tur === 'no');
  const no = noA ? P.alanOku(img, [noA], []).no : { deger: '', guven: 0 };
  return { hizali: true, oto: true, no, puanlar: [Object.assign(pu, { max: top })] };
}
// Ad Soyad (el yazısı): yerel yazı tanıma + sınıf listesine en yakın ad. Okul No ile çelişirse satır sarı kalır.
let isci = null;
async function adMetni(c, a) { const t = await adMetinleri(c, a); return t[0] || ''; }
// 1.6.4: Ad alanı iki biçimde okunur: (1) olduğu gibi, (2) yalnız renkli kalem (mavi/kırmızı) bırakılıp mürekkebin çevresine sıkı kırpılarak (basılı yazı, çizgi ve karalama payı azalır)
async function adMetinleri(c, a) {
  if (!globalThis.Tesseract) return [];
  const k = document.createElement('canvas'), w = Math.round(a.w * c.width), h = Math.round(a.h * c.height); if (w < 10 || h < 6) return [];
  const o = Math.min(3, Math.max(1, 64 / h)); k.width = Math.round(w * o); k.height = Math.round(h * o); const x = k.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, k.width, k.height); x.drawImage(c, a.x * c.width, a.y * c.height, w, h, 0, 0, k.width, k.height);
  if (!isci) { const url = (y) => (globalThis.chrome && chrome.runtime && chrome.runtime.getURL ? chrome.runtime.getURL('tarama/' + y) : new URL(y, location.href).href);
    isci = await Tesseract.createWorker('tur', 1, { workerPath: url('lib/worker.min.js'), corePath: url('lib/tess-core/'), langPath: url('lib/lang'), workerBlobURL: false, cacheMethod: 'none' });
    await isci.setParameters({ tessedit_pageseg_mode: '7' }); }
  const out = [], ekle = (t) => { t = (t || '').trim(); if (t && out.indexOf(t) < 0) out.push(t); };
  ekle((await isci.recognize(k)).data.text);
  const d = x.getImageData(0, 0, k.width, k.height), p = d.data; let x0 = k.width, y0 = k.height, x1 = -1, y1 = -1, say = 0;
  for (let i = 0; i < k.width * k.height; i++) { const r = p[4 * i], g = p[4 * i + 1], b = p[4 * i + 2], renk = (b - r > 15 && b > g - 10 && r < 200) || (r - g > 45 && r - b > 30);
    const v = renk ? 0 : 255; p[4 * i] = p[4 * i + 1] = p[4 * i + 2] = v; if (renk) { say++; const xx = i % k.width, yy = (i / k.width) | 0; if (xx < x0) x0 = xx; if (xx > x1) x1 = xx; if (yy < y0) y0 = yy; if (yy > y1) y1 = yy; } }
  if (say > 40 && x1 > x0 && y1 > y0) { x.putImageData(d, 0, 0); const pd = 8, cw = x1 - x0 + 2 * pd, ch = y1 - y0 + 2 * pd, s2 = Math.min(3, Math.max(0.5, 64 / ch)), k2 = document.createElement('canvas');
    k2.width = Math.round(cw * s2); k2.height = Math.round(ch * s2); const x2 = k2.getContext('2d'); x2.fillStyle = '#fff'; x2.fillRect(0, 0, k2.width, k2.height); x2.drawImage(k, x0 - pd, y0 - pd, cw, ch, 0, 0, k2.width, k2.height);
    ekle((await isci.recognize(k2)).data.text); }
  return out;
}
async function kimlik(r, c) {
  const adA = alanlar.find((a) => a.tur === 'ad') && tur() !== 'sablon' ? alanlar.find((a) => a.tur === 'ad') : null;
  const metinler = adA ? await adMetinleri(c, adA) : [];
  Object.defineProperty(r, '_adlar', { value: metinler, enumerable: false, configurable: true, writable: true }); r.adSoyad = metinler[0] || ''; }
// 1.6.28 Listeye bağlı kimlik adımı: sayfanın şubesine uyan liste seçildikten sonra çalışır (sinif = o grubun listesi)
function kimlikListe(r) { const metinler = r._adlar || (r.adSoyad ? [r.adSoyad] : []);
  // sınıf listesi varsa listedeki bir ada en çok benzeyen okuma seçilir
  r.adSoyad = metinler.length > 1 && sinif.length ? metinler.map((t) => [t, Math.max(...sinif.map((o) => B.benzer(t, o.ad || '')))]).sort((p, q) => q[1] - p[1])[0][0] : metinler[0] || '';
  if (!sinif.length && !r.adSoyad) return;
  r.ogr = B.ogrenciEsle(sinif, r.no, r.adSoyad);
  if (r.ogr.no && r.ogr.no !== r.no.deger) { r.no.okunan = r.no.deger; r.no.deger = r.ogr.no; }
  // 1.6.4: oylu okuma listede yoksa ama ikinci aday listedeyse ona geçilir; yine sarı kalır (ad doğrulamazsa)
  if (r.no.adaylar && !sinif.some((o) => o.no === r.no.deger)) { const al = r.no.adaylar.find((s) => sinif.some((o) => o.no === s)); if (al) { r.no.okunan = r.no.deger; r.no.deger = al; r.ogr = B.ogrenciEsle(sinif, { deger: al, guven: r.no.guven }, r.adSoyad); r.ogr.kontrol = r.ogr.uyum !== 'no+ad'; r.ogr.neden = (r.ogr.neden ? r.ogr.neden + ' · ' : '') + 'ikinci aday listede (' + r.no.okunan + ' okundu)'; } }
  // 1.6.3: oylu okuma sınıf listesinde birebir varsa doğrulanmış sayılır — 1.6.4: yalnız ad da aynı öğrenciyi gösteriyorsa
  // 1.6.7: oylu okunan numara listede birebir var ve ayrı okunan ad da aynı öğrenciyi açık farkla gösteriyorsa (iki bağımsız kanıt) doğrulanmış sayılır
  if (r.no.oylu && !r.no.okunan && !r.no.belirsiz && r.ogr && r.ogr.uyum === 'no+ad' && r.ogr.no === r.no.deger && sinif.some((o) => o.no === r.no.deger)) { r.ogr.kontrol = false; r.ogr.neden = ''; }
  if (r.no.oylu && sinif.some((o) => o.no === r.no.deger) && r.ogr && r.ogr.uyum === 'no+ad' && !r.ogr.kontrol) { r.no.guven = Math.max(r.no.guven, 90); r.no.neden = 'sınıf listesinde var'; }
}
// 1.6.11 Kâğıt başlığı: basılı (Word) üst kısımdan Sınıf/Şube (10-M, 12/A, 10. Sınıf M) ve Ders adı okunur. Emin olunmayan alan kesin=false (sarı).
let basIsci = null;
const BAS_DERS = [[/ingilizce|english|listening|reading|speaking|writing|yabanci dil/, 'Yabancı Dil'], [/almanca|deutsch/, 'Yabancı Dil'], [/turk dili ve edebiyat|edebiyat/, 'Türk Dili ve Edebiyatı'], [/matematik/, 'Matematik'], [/fizik/, 'Fizik'], [/kimya/, 'Kimya'], [/biyoloji/, 'Biyoloji'], [/tarih/, 'Tarih'], [/cografya/, 'Coğrafya'], [/din kulturu/, 'Din Kültürü ve Ahlak Bilgisi'], [/felsefe/, 'Felsefe']];
const trn = (t) => (t || '').toLocaleLowerCase('tr-TR').replace(/[ıi̇]/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c');
const DERS_SOZ = [['T.C. İnkılap Tarihi ve Atatürkçülük', ['tc inkilap tarihi ve ataturkculuk', 'inkilap tarihi ve ataturkculuk', 'inkilap tarihi']], ['Türk Dili ve Edebiyatı', ['turk dili ve edebiyati', 'edebiyat', 'tde']],
  ['Din Kültürü ve Ahlak Bilgisi', ['din kulturu ve ahlak bilgisi', 'din kulturu']], ['Sağlık Bilgisi ve Trafik Kültürü', ['saglik bilgisi ve trafik kulturu', 'trafik kulturu']], ['Beden Eğitimi ve Spor', ['beden egitimi ve spor', 'beden egitimi']],
  ['Peygamberimizin Hayatı', ['peygamberimizin hayati']], ['Görsel Sanatlar', ['gorsel sanatlar']], ['Fen Bilimleri', ['fen bilimleri']], ['Sosyal Bilgiler', ['sosyal bilgiler']], ['İkinci Yabancı Dil', ['ikinci yabanci dil', 'almanca', 'fransizca', 'arapca', 'rusca', 'ispanyolca']],
  ['Yabancı Dil', ['yabanci dil', 'ingilizce', 'english']], ['Matematik', ['matematik']], ['Geometri', ['geometri']], ['Fizik', ['fizik']], ['Kimya', ['kimya']], ['Biyoloji', ['biyoloji']], ['Tarih', ['tarih']], ['Coğrafya', ['cografya']], ['Felsefe', ['felsefe']],
  ['Psikoloji', ['psikoloji']], ['Sosyoloji', ['sosyoloji']], ['Mantık', ['mantik']], ['Müzik', ['muzik']], ['Türkçe', ['turkce']]];
function dersBul(metin) { const satir = trn(metin).replace(/[^a-z0-9\n ]/g, ' ').split('\n').map((x) => x.replace(/\s+/g, ' ').trim()).filter(Boolean)
    .map((l) => l.replace(/\b[a-z ]*(lisesi|lise|ortaokulu|okulu|mudurlugu|kolej[a-z]*)\b/g, ' ').replace(/egitim ogretim yili|ogretim yili|egitim ogretim/g, ' ').replace(/\s+/g, ' ').trim()).filter(Boolean);
  let en = null;
  satir.forEach((l, li) => { const w = l.split(' '), dersli = /\bders[a-z]?\b/.test(l);
    DERS_SOZ.forEach(([ad, es]) => es.forEach((e) => { const n = e.split(' ').length;
      for (let i = 0; i + n <= w.length; i++) { const parca = w.slice(i, i + n).join(' '), hata = basLev(parca, e) / e.length; if (hata > (e.length < 6 ? 0 : e.length < 9 ? 0.15 : 0.25)) continue;
        const secmeli = i > 0 && basLev(w[i - 1], 'secmeli') <= 2, sonra = w[i + n] || '', dsn = /^ders/.test(sonra);
        const puan = e.length * (1 - hata) + (dersli ? 6 : 0) + (dsn ? 6 : 0);
        if (!en || puan > en.puan) en = { puan, ders: (secmeli ? 'Seçmeli ' : '') + ad, kesin: hata <= 0.12 && (dersli || dsn || e.length >= 9) && !/ikinci yabanci/.test(trn(ad)) || (hata === 0 && /ikinci yabanci dil/.test(e)) }; } })); });
  return en; }
globalThis.__dersBul = dersBul;
// 1.6.17 Sınıf/Şube biçimleri: 9-A, 9/A, 9A, 9 A, 9.A, "9. Sınıf A Şubesi", "Class: 11/C"; OCR'ın 1 yerine l/I, 0 yerine O okuması etiket yanında düzeltilir (o zaman SARI)
function sinifBul(t) { const ET = /(?:sinif(?:i|\s*[-\/]\s*sube)?|sube|class|grade)\s*[:.]?\s*/g; let e, en = null;
  const coz = (parca, etiketli) => { let duz = false; const p2 = parca.replace(/^([0-9ilo|]{1,2})(?=\s*(?:\.|-|\/|\s|sinif|[a-z]\b|[a-z]$))/, (x) => { const y = x.replace(/[il|]/g, '1').replace(/o/g, '0'); if (y !== x) duz = true; return y; });
    const m = p2.match(/^(9|10|11|12)\s*(?:\.\s*)?(?:sinif[a-z]*\s*)?(?:[-\/.]\s*)?([a-z])(?:\s*subesi|\s*sinifi|(?![a-z]))/);
    if (!m) return null; const sep = /^(9|10|11|12)\s*([-\/.]|\.?\s*sinif)/.test(p2); return { sinif: m[1] + '-' + m[2].toLocaleUpperCase('tr-TR'), kesin: etiketli && !duz && (sep || /subesi/.test(p2)) }; };
  while ((e = ET.exec(t))) { const r = coz(t.slice(e.index + e[0].length, e.index + e[0].length + 24), true); if (r) { en = r; if (r.kesin) break; } }
  if (!en) { const m2 = t.match(/(?:^|\s)((?:9|10|11|12)\s*(?:[-\/.]|\.?\s*sinif\s*[-\/]?)\s*[a-z](?:\s*subesi)?)(?![a-z])/); if (m2) { const r = coz(m2[1], false); if (r) en = { sinif: r.sinif, kesin: /subesi/.test(m2[1]) }; } }
  return en; }
function basCoz(metin) {
  const t = trn(metin).replace(/\s+/g, ' '), b = { sinif: '', ders: '', sinifKesin: false, dersKesin: false };
  const m = t.match(/(?:sinif|sinifi|class|sube)[^0-9\n]{0,12}\b(9|10|11|12)\s*(?:\.\s*sinif)?\s*[-\/.]\s*([a-z])\b/) || t.match(/\b(9|10|11|12)\s*[-\/]\s*([a-z])\b(?![a-z])/) || t.match(/\b(9|10|11|12)\s*\.?\s*sinif\s*[-\/]?\s*([a-z])\s*subesi/);
  if (m) { b.sinif = m[1] + '-' + m[2].toLocaleUpperCase('tr-TR'); b.sinifKesin = true; }
  else { const sb = sinifBul(t); if (sb) { b.sinif = sb.sinif; b.sinifKesin = sb.kesin; } }
  if (!b.sinif) { const sv = t.match(/\b(9|10|11|12)\s*(?:\.|th|st|nd)?\s*(?:sinif|grade|siniflar)/); if (sv) b.sinif = sv[1] + '-'; }
  // 1.6.17 Ders adı: e-Okul ders adları sözlüğünde en uzun (en belirgin) bulanık eşleşme; okul adı/yıl satırları atlanır; "Seçmeli", "İnkılap", "İkinci" ayrımı korunur
  const dz = dersBul(metin); if (dz) { b.ders = dz.ders; b.dersKesin = dz.kesin; }
  else { const dm = t.match(/([a-z][a-z ]{2,40}?)\s+dersi\b/); const d = dm ? dm[1].trim() : ''; if (d) { b.ders = d.replace(/(^| )\S/g, (x) => x.toLocaleUpperCase('tr-TR')); b.dersKesin = false; } }
  // 1.6.17 İngilizce yazılmış sınav kâğıdı (Listening/Speaking ... Exam, Name/Number/Class): ders adı yazmasa da Yabancı Dil (SARI)
  if (!b.ders && /\b(exam|quiz)\b/.test(t) && /\b(listening|speaking|reading|writing|grades?|term|name|number|class)\b/.test(t)) { b.ders = 'Yabancı Dil'; b.dersKesin = false; }
  // 1.6.17 Yabancı Dil sınav türü: başlıkta DİNLEME/LISTENING -> D, KONUŞMA/SPEAKING -> K kutusu
  b.alan = /dinleme|listening/.test(t) ? 'D' : /konusma|speaking/.test(t) ? 'K' : '';
  if (globalThis.KagitOku && KagitOku.basBilgi) Object.assign(b, KagitOku.basBilgi(metin)); // 1.6.22 seviye, dönem, sınav no
  return b;
}
let yerelMetin = false;
// 1.6.26 Basılı başlık (sınıf/ders/sınav) için yerel servisteki PaddleOCR birincil: metni PDF metni gibi önceliklidir, Tesseract yedektir.
// Okul No / Ad Soyad / Aldığı puan satırları gönderilmez (onlar el yazısı okuyucularda). Metin yalnız bellekte; tanıya yazılmaz.
const BAS_ATLA = /(\bno\b|numara|ad[ıi]?\s*soyad|soyad[ıi]?|ald[ıi][gğ][ıi]|puan\s*:)/i;
async function basPaddle(c) { const YO = globalThis.YerelOkuma; if (!yerelMetin || !YO || !YO.metin) return '';
  const h0 = Math.round(c.height * (ustAcik() ? UST : 30) / 100), o = Math.min(1, 1400 / c.width), k = document.createElement('canvas'); k.width = Math.round(c.width * o); k.height = Math.max(8, Math.round(h0 * o));
  const x = k.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, k.width, k.height); x.drawImage(c, 0, 0, c.width, h0, 0, 0, k.width, k.height);
  const t0 = Date.now(), m = await YO.metin(YO.png(k)); if (!m || !m.metin) return '';
  const sat = m.metin.split('\n').map((l) => l.trim()).filter((l) => l && !BAS_ATLA.test(l) && !/^[\d\s.,/-]+$/.test(l));
  TANI.paddle = (TANI.paddle || 0) + 1; TANI.paddleMs = Date.now() - t0; return sat.join('\n'); }
async function basOku(c, pdfMetin) {
  try { const pm = await basPaddle(c); if (pm) pdfMetin = (pdfMetin ? pdfMetin + '\n' : '') + pm; } catch (e) { /* servis yok → Tesseract */ }
  // 1.6.19: yeni okuma dersi boş bıraktıysa 1.6.17 başlık okumasına düşülür. Yeni okuma ancak dersi doldurmuşsa eski başlığı atlar.
  let alan = null;
  if (globalThis.KagitOku) {
    try {
      if (globalThis.Tesseract && !basIsci) { const url = (y) => (globalThis.chrome && chrome.runtime && chrome.runtime.getURL ? chrome.runtime.getURL('tarama/' + y) : new URL(y, location.href).href);
        basIsci = await Tesseract.createWorker('tur', 1, { workerPath: url('lib/worker.min.js'), corePath: url('lib/tess-core/'), langPath: url('lib/lang'), workerBlobURL: false, cacheMethod: 'none' });
        await basIsci.setParameters({ tessedit_pageseg_mode: '3' }); }
      taniSar(basIsci); if (basIsci || (pdfMetin && String(pdfMetin).replace(/\s/g, '').length > 20)) alan = await KagitOku.okuCanvas(c, { pdfMetin: pdfMetin || '', liste: sinif, worker: basIsci });
    } catch (e) { console.log('Kâğıt okuma yedeğe düştü'); alan = null; }
  }
  if (alan && alan.ders) return KagitOku.basYap(alan);
  if (!globalThis.Tesseract) return alan ? KagitOku.basYap(alan) : { sinif: '', ders: '', kesin: false };
  const k = document.createElement('canvas'), h0 = Math.round(c.height * 0.3), o = Math.min(2, 1800 / c.width); k.width = Math.round(c.width * o); k.height = Math.round(h0 * o);
  const x = k.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, k.width, k.height); x.drawImage(c, 0, 0, c.width, h0, 0, 0, k.width, k.height);
  if (!basIsci) { const url = (y) => (globalThis.chrome && chrome.runtime && chrome.runtime.getURL ? chrome.runtime.getURL('tarama/' + y) : new URL(y, location.href).href);
    basIsci = await Tesseract.createWorker('tur', 1, { workerPath: url('lib/worker.min.js'), corePath: url('lib/tess-core/'), langPath: url('lib/lang'), workerBlobURL: false, cacheMethod: 'none' });
    await basIsci.setParameters({ tessedit_pageseg_mode: '3' }); }
  taniSar(basIsci); const sn = await basIsci.recognize(k), b = basCoz(sn.data.text);
  // 1.6.17 Sınıf harfi el yazısıysa (OCR güveni düşük) kesin sayılmaz, sarı kalır
  if (b.sinifKesin) { const ws = sn.data.words || [], [sn1, sh1] = b.sinif.split('-'), hk = trn(sh1 || '');
    for (let i = 0; i < ws.length; i++) { const w = trn(ws[i].text).replace(/[^a-z0-9\/.-]/g, '');
      const tek = new RegExp('^' + sn1 + '[-/.]?' + hk + '$').test(w), ayri = new RegExp('^' + sn1 + '[-/.]?$').test(w) && ws[i + 1] && trn(ws[i + 1].text).replace(/[^a-z]/g, '') === hk;
      if (tek || ayri) { const g = Math.min(ws[i].confidence, ayri ? ws[i + 1].confidence : 100); if (g < 85) b.sinifKesin = false; break; } } }
  // 1.6.13 Ders başlığı okunamadıysa: üst %25, eğiklik düzeltme (±7°), farklı eşiklerle yeniden dene; bulanık ders adı eşleşmesi
  if (!b.dersKesin && !/^İkinci Yabancı/.test(b.ders)) { const dz = await basDersDene(c); if (dz) { b.ders = dz; b.dersKesin = true; } }
  // El yazısı sınıf: "Class:" / "Sınıfı" / "Sınıf-Numara" etiketinin sağındaki alan ayrıca tek satır okunur
  if (!b.sinifKesin) { const ws = (sn.data.words || []).filter((w) => /^(class|sinif|sinifi|sinif-numara|sinif-numarasi|sinifi\/no)\W*$/.test(trn(w.text).replace(/[:;.]+$/, '')) || /^(class|sinif)/.test(trn(w.text)) && /[:]/.test(w.text));
    for (const w of ws) { const bb = w.bbox, hh = bb.y1 - bb.y0, x0 = bb.x1 + 2, y0 = Math.max(0, bb.y0 - hh * 0.8), cw = Math.min(k.width - x0, hh * 9), ch = hh * 2.6; if (cw < 10) continue;
      const k2 = document.createElement('canvas'), s2 = Math.min(3, 80 / ch); k2.width = Math.round(cw * s2); k2.height = Math.round(ch * s2); const x2 = k2.getContext('2d'); x2.fillStyle = '#fff'; x2.fillRect(0, 0, k2.width, k2.height); x2.drawImage(k, x0, y0, cw, ch, 0, 0, k2.width, k2.height);
      await basIsci.setParameters({ tessedit_pageseg_mode: '7' }); const tx = (await basIsci.recognize(k2)).data.text; await basIsci.setParameters({ tessedit_pageseg_mode: '3' });
      const m = trn(tx).replace(/[o]/g, '0').replace(/[il|]/g, '1').match(/(9|10|11|12)\s*[-\/.,_ ]?\s*([a-z])/i) || trn(tx).match(/(9|10|11|12)\s*[-\/.,_ ]\s*([a-z])/);
      if (m) { b.sinif = m[1] + '-' + m[2].toLocaleUpperCase('tr-TR'); b.sinifKesin = false; b.elYazisi = true; break; } } }
  // 1.6.17 El yazısı ders adı (kareli/çizgili kâğıt): çizgiler ayıklanmış mürekkep görüntüsü ayrıca okunur; bulanık eşleşme yalnız uzun ders adlarıyla, her zaman SARI
  if (!b.ders && globalThis.OtoBul && OtoBul.murekkep) { try { const I = x.getImageData(0, 0, k.width, k.height), M = OtoBul.murekkep(I, k.width, false, true), km = document.createElement('canvas'); km.width = M.w; km.height = M.h;
      const gm = km.getContext('2d'), id = gm.createImageData(M.w, M.h); for (let i = 0; i < M.w * M.h; i++) { const v = M.d[i] ? 0 : 255; id.data[4 * i] = id.data[4 * i + 1] = id.data[4 * i + 2] = v; id.data[4 * i + 3] = 255; } gm.putImageData(id, 0, 0);
      await basIsci.setParameters({ tessedit_pageseg_mode: '6' }); const tx = (await basIsci.recognize(km)).data.text; await basIsci.setParameters({ tessedit_pageseg_mode: '3' });
      const d = elYazisiDers(tx); if (d) { b.ders = d; b.dersKesin = false; b.elYaziDers = true; } } catch (e) { /* okunamadı: boş kalır */ } }
  if (alan) { KagitOku.dersYedek(alan, b); return KagitOku.basYap(alan); }
  b.kesin = b.sinifKesin && b.dersKesin; return b;
}
const EL_DERS = [['edebiyat', 'Türk Dili ve Edebiyatı'], ['edebiyati', 'Türk Dili ve Edebiyatı'], ['matematik', 'Matematik'], ['ingilizce', 'Yabancı Dil'], ['english', 'Yabancı Dil'], ['biyoloji', 'Biyoloji'], ['cografya', 'Coğrafya'], ['felsefe', 'Felsefe'], ['kimya', 'Kimya'], ['fizik', 'Fizik'], ['tarih', 'Tarih']];
function elYazisiDers(metin) { const w = trn(metin).replace(/[^a-z\s]/g, '').split(/\s+/).filter((q) => q.length >= 4); let en = null;
  w.forEach((q) => EL_DERS.forEach(([e, ad]) => { if (e.length < 5 || Math.abs(q.length - e.length) > 2) return; const h = basLev(q, e) / e.length; if (h <= 0.25 && (!en || h < en.h)) en = { h, ad }; }));
  return en ? en.ad : ''; }
const BAS_ADLAR = [['turk dili ve edebiyati', 'Türk Dili ve Edebiyatı'], ['ingilizce', 'Yabancı Dil'], ['almanca', 'İkinci Yabancı Dil'], ['yabanci dil', 'Yabancı Dil'], ['matematik', 'Matematik'], ['fizik', 'Fizik'], ['kimya', 'Kimya'], ['biyoloji', 'Biyoloji'], ['cografya', 'Coğrafya'], ['tarih', 'Tarih'], ['din kulturu ve ahlak bilgisi', 'Din Kültürü ve Ahlak Bilgisi'], ['felsefe', 'Felsefe']];
function basLev(a, b) { const d = []; for (let i = 0; i <= a.length; i++) d[i] = [i]; for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[a.length][b.length]; }
// Bulanık ders adı: önce "ders" geçen satırlar, yoksa (yalnız uzun adlar) tüm metin
function basBulanik(metin) { const satirlar = trn(metin).replace(/[^a-z\n ]/g, ' ').split('\n').map((x) => x.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const dene = (sat, sadeceUzun) => { let en = null; for (const l of sat) { const w = l.split(' ');
      for (const [ad, ders] of BAS_ADLAR) { if (sadeceUzun && ad.length < 9) continue; const n = ad.split(' ').length;
        for (let i = 0; i + n <= w.length; i++) { const e = basLev(w.slice(i, i + n).join(' '), ad) / ad.length; if (e <= 0.25 && (!en || e < en.e)) en = { e, ders }; } } } return en; };
  const ds = satirlar.filter((l) => /\bders[a-z]?\b/.test(l));
  const r = dene(ds, false) || dene(satirlar, true); return r ? r.ders : ''; }
async function basDersDene(c) { const h0 = Math.round(c.height * 0.25), o = Math.min(2.2, 2000 / c.width), W = Math.round(c.width * o), H = Math.round(h0 * o);
  const kaynak = document.createElement('canvas'); kaynak.width = W; kaynak.height = H; const kx = kaynak.getContext('2d'); kx.fillStyle = '#fff'; kx.fillRect(0, 0, W, H); kx.drawImage(c, 0, 0, c.width, h0, 0, 0, W, H);
  for (const aci of [0, -3, 3, -5, 5, -7, 7]) for (const esik of [0, 150, 110]) {
    const k = document.createElement('canvas'); k.width = W; k.height = H; const x = k.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, W, H);
    x.translate(W / 2, H / 2); x.rotate(aci * Math.PI / 180); x.translate(-W / 2, -H / 2); x.drawImage(kaynak, 0, 0); x.setTransform(1, 0, 0, 1, 0, 0);
    if (esik) { const im = x.getImageData(0, 0, W, H), d = im.data; for (let i = 0; i < d.length; i += 4) { const v = (0.3 * d[i] + 0.59 * d[i + 1] + 0.11 * d[i + 2]) < esik ? 0 : 255; d[i] = d[i + 1] = d[i + 2] = v; } x.putImageData(im, 0, 0); }
    const t = (await basIsci.recognize(k)).data.text, b = basCoz(t); if (b.dersKesin) return b.ders; const f = basBulanik(t); if (f) return f; }
  return ''; }
// Aynı dosyanın sonraki sayfasında başlık okunamazsa önceki sayfanınki alınır ama SARI kalır (sessiz tahmin yok)
function basDevir(r, onceki, geri) { if (!onceki || !onceki.bas || !r.bas) return; const ayni = String(r.ad || '').split(' s.')[0] === String(onceki.ad || '').split(' s.')[0]; if (!ayni) return;
  if (!r.bas.sinifKesin && onceki.bas.sinif && !(geri && r.bas.sinif)) { r.bas.sinif = onceki.bas.sinif; r.bas.kesin = false; r.bas.devir = true; r.bas.sinifDevir = true; }
  if (!r.bas.dersKesin && onceki.bas.ders && !(geri && r.bas.ders)) { r.bas.ders = onceki.bas.ders; r.bas.kesin = false; r.bas.devir = true; } }
// 1.6.26 Şube oylaması: bir dosyadaki kâğıtlar çoğunlukla aynı şubedendir. Belirgin çoğunluk (≥%60) varsa kesin olmayan
// farklı şubeler çoğunluğa çekilir; kesin okunmuş farklı şube korunur ama kesinliği kalkar (sarı, kontrol).
function listedeVar(r, s) { const k = skT(s), L = k && SL[k] && SL[k].liste; if (!L) return false; const v = [r.no && (r.no.okunan || r.no.deger), ...((r.no && r.no.adaylar) || [])].filter(Boolean).map(String); return L.some((o) => v.includes(o.no)); } // şube listesi bu numarayı içeriyorsa okunan şube doğrudur
function subeOy(liste) { const say = {}, dog = {}; let top = 0; liste.forEach((r) => { const s = r.bas && r.bas.sinif; if (!s || r.bas.sinifDevir) return; dog[s] = (dog[s] || 0) + 1; say[s] = (say[s] || 0) + (r.bas.sinifKesin ? 2 : 1); top += r.bas.sinifKesin ? 2 : 1; });
  const [m, n] = Object.entries(say).sort((a, b) => b[1] - a[1])[0] || []; if (!m || n / top < 0.6) return;
  // 1.6.28: karışık şubeli dosyalar (11-F + 11-D) için farklı okunan şube EZİLMEZ; yalnız şubesi okunamayan sayfa çoğunluğu alır (sarı)
  // Ama tek sayfada okunmuş (tekil) kesin olmayan farklı şube ve ondan devralınanlar çoğunluğa çekilir (sarı); ≥2 sayfada okunan şube korunur.
  const sev = (x) => (String(x || '').match(/^\d{1,2}/) || [''])[0];
  liste.forEach((r) => { if (!r.bas || r.bas.sinif === m) return; const s = r.bas.sinif;
    if (s && sev(s) && sev(s) !== sev(m)) { r.bas.kesin = false; r.bas.subeFarkli = m; return; } // farklı sınıf seviyesi (9 ↔ 11) basılıdır, çekilmez
    if (!s || (r.bas.sinifDevir && (dog[s] || 0) < 2) || (!r.bas.sinifDevir && !r.bas.sinifKesin && (dog[s] || 0) < 2 && !listedeVar(r, s))) { if (s) r.bas.sinifOkunan = s; r.bas.sinif = m; r.bas.kesin = false; r.bas.devir = true; r.bas.sinifDevir = !s; if (s) r.bas.subeFarkli = m; }
    else { r.bas.kesin = false; r.bas.subeFarkli = m; } }); }
globalThis.__basCoz = basCoz;
// 1.6.3: Okul No — işaretli alan 36 oyla okunur; "Form kâğıdı" seçiliyse Numarası hücresi kendisi bulunur
async function noYeni(r, img, c) {
  const noA = alanlar.find((a) => a.tur === 'no'); let v = null;
  if ($('formNo') && $('formNo').checked) { const f = await B.formKimlik(c); taniEk(r, 'form', f); if (f.no) v = { s: f.no, guven: f.noGuven, neden: f.noNeden, oylar: f.oylar, adaylar: f.noAdaylar, belirsiz: f.noBelirsiz }; }
  if (!v && noA) { v = B.noOku(img, noA, ''); taniEk(r, 'kutu', { alan: noA, no: v && v.s, oylar: v && v.oylar });
    // 1.6.25: kutu kipinde de sınıf/şube (ör. 11-F) etiket yanından okunur; numara kutudan kalır
    if (B.etiketNo) { try { const f = await (B.noBul || B.etiketNo)(c, { uzunluk: 4 }); if (f && f.sinif) r.etiket = { sinif: f.sinif, kutu: f.kutu }; taniEk(r, 'etiket', f); } catch (e) { } } }
  // 1.6.16 kutu çizilmemişse: basılı etiketin (Sınıf-Numara / Number / Okul No) sağındaki el yazısı kendisi okunur
  if (!v && B.etiketNo) { const say = {}; sinif.forEach((o) => { const l = String(o.no).length; say[l] = (say[l] || 0) + 1; }); const uz = Number(Object.keys(say).sort((a, b) => say[b] - say[a])[0]) || 4;
    const f = await (B.noBul || B.etiketNo)(c, { uzunluk: uz }); taniEk(r, 'etiket', f); r.etiket = { sinif: f.sinif || '', kutu: f.kutu };
    if (f.no) v = { s: f.no, guven: Math.min(f.noGuven, 85), neden: f.noNeden || 'etiket yanından okundu', oylar: f.oylar, adaylar: f.noAdaylar, belirsiz: f.noBelirsiz }; }
  if (!v || !v.s) return; r.no = r.no || { deger: '', guven: 0 };
  if (r.no.deger && r.no.deger !== v.s) r.no.eski = r.no.deger;
  Object.assign(r.no, { deger: v.s, guven: v.guven, neden: v.neden, oylar: v.oylar, oylu: true, adaylar: v.adaylar, belirsiz: v.belirsiz });
}
// 1.6.4: hane sayısı tutmuyorsa (listedeki numaralarla ya da oylu okumada 4 hane) ya da iki aday yakınsa asla yeşil olmaz
function haneTutmaz(r) { const n = String(r.no.deger || '').length; if (!n) return true; const sinif = listeAl(r); if (sinif.length) { const say = {}; sinif.forEach((o) => { const l = String(o.no).length; say[l] = (say[l] || 0) + 1; }); const enc = Number(Object.keys(say).sort((a, b) => say[b] - say[a])[0]); return n !== enc; } return !!r.no.oylu && n !== 4; }
const noSari = (r) => !listeAl(r).length || !r.no.deger || r.no.guven < P.ESIK || !!(r.ogr && r.ogr.kontrol) || haneTutmaz(r) || (!!r.no.belirsiz && !(r.ogr && r.ogr.uyum === 'no+ad'));
function kucuk(im) { if (!im) return null; const c = document.createElement('canvas'); c.width = im.w; c.height = im.h; c.className = 'kucuk';
  const d = c.getContext('2d').createImageData(im.w, im.h); for (let i = 0; i < im.w * im.h; i++) { const v = im.g[i]; d.data[4 * i] = d.data[4 * i + 1] = d.data[4 * i + 2] = v; d.data[4 * i + 3] = 255; } c.getContext('2d').putImageData(d, 0, 0);
  c.style.height = '30px'; return c; }
function el(t, a = {}, k = []) { const e = document.createElement(t); Object.entries(a).forEach(([x, v]) => (x === 'text' ? (e.textContent = v) : x.startsWith('on') ? (e[x] = v) : e.setAttribute(x, v))); k.forEach((c) => c && e.appendChild(c)); return e; }
function tabloCiz() {
  $('incele').hidden = !sonuc.length; 
  const oto = sonuc.some((r) => r.oto), adVar = sonuc.some((r) => r.ogr || r.adSoyad), kol = oto ? [maxlar.length === 1 ? maxlar[0] : 100] : maxlar;
  const tb = el('table'), bas = el('tr', {}, [el('th', { text: 'Sayfa' }), el('th', { text: 'Okul No' })]); if (adVar) bas.appendChild(el('th', { text: 'Ad Soyad' }));
  kol.forEach((m, j) => bas.appendChild(el('th', { text: oto ? 'Puan (' + m + ')' : 'S' + (j + 1) + ' (' + m + ')' }))); bas.appendChild(el('th', { text: 'Top.' })); bas.appendChild(el('th', { text: '' })); tb.appendChild(bas);
  sonuc.forEach((r, i) => {
    const tr = el('tr'); tr.appendChild(el('td', { text: String(i + 1), title: r.ad }));
    if (!r.hizali) { tr.appendChild(el('td', { colspan: kol.length + 2 + (adVar ? 1 : 0), text: r.ad + ': ' + r.hata, style: 'background:#ffb3b3;font-weight:bold;text-align:left' })); }
    else {
      const noBoz = noSari(r), noI = el('input', { class: 'no', value: r.no.deger, inputmode: 'numeric', 'aria-label': 'Okul no' });
      const adTd = adVar ? el('td', { class: noBoz ? 'kontrol' : '', style: 'text-align:left;min-width:150px' }) : null;
      const adCiz = () => { if (!adTd) return; adTd.innerHTML = ''; const sinif = listeAl(r), o = sinif.find((q) => q.no === r.no.deger);
        adTd.append(el('b', { text: o ? (o.ad || '(listede adı yok)') : r.no.deger ? (sinif.length ? 'listede yok' : 'sınıf listesi yüklü değil') : '' }), el('span', { class: 'guven', text: (r.adSoyad ? 'kâğıtta: ' + r.adSoyad : '') + (r.ogr && r.ogr.neden ? ' · ' + r.ogr.neden : '') }));
        if (r.ogr && r.ogr.alternatif && r.ogr.alternatif.no !== r.no.deger) adTd.appendChild(el('button', { class: 'btn acik', text: 'Bu öğrenci: ' + r.ogr.alternatif.no, onclick: () => { r.no.deger = String(r.ogr.alternatif.no); r.no.guven = 100; r.ogr.kontrol = false; tabloCiz(); } })); };
      noI.oninput = () => { r.no.deger = noI.value.replace(/\D/g, ''); r.no.guven = 100; if (r.ogr) { r.ogr.kontrol = false; r.ogr.neden = 'elle düzeltildi'; } noI.parentNode.classList.remove('kontrol'); if (adTd) { adTd.classList.remove('kontrol'); adCiz(); } };
      const noTd = el('td', { class: noBoz ? 'kontrol' : '' }, [noI, el('span', { class: 'guven', text: (r.no.deger ? '%' + r.no.guven : 'okunamadı') + (r.no.belirsiz ? ' · iki aday' : '') }), kucuk(r.no.img)]); tr.appendChild(noTd);
      if (noBoz && r.no.adaylar) r.no.adaylar.filter((s) => s !== r.no.deger).slice(0, 2).forEach((s) => noTd.appendChild(el('button', { class: 'btn acik', text: s, title: 'Bu numarayı seç', onclick: () => { noI.value = s; noI.oninput(); tabloCiz(); } }))); if (adTd) { adCiz(); tr.appendChild(adTd); }
      const top = el('td', { class: 'top' }), topH = () => { top.textContent = r.puanlar.reduce((t, p) => t + (Number(String(p.deger).replace(',', '.')) || 0), 0); };
      r.puanlar.forEach((p) => { const i2 = el('input', { value: p.deger, inputmode: 'decimal', title: p.neden || '' }), td = el('td', { class: p.kontrol ? 'kontrol' : '' }, [i2, el('span', { class: 'guven', text: p.bos ? 'boş' : '%' + p.guven + (p.neden ? ' · ' + p.neden : '') }), kucuk(p.img)]);
        if (p.adaylar && p.kontrol) p.adaylar.slice(0, 3).forEach((a) => { const v = a.split(' ')[0]; td.appendChild(el('button', { class: 'btn acik', text: v, title: 'Bu değeri seç', onclick: () => { i2.value = v; i2.oninput(); } })); });
        i2.oninput = () => { p.deger = i2.value.trim(); p.duzeltildi = true; p.guven = 100; p.bos = p.deger === ''; const v = Number(p.deger.replace(',', '.')); const asar = p.deger !== '' && !(v >= 0 && v <= Number(p.max)); td.classList.toggle('kontrol', asar); i2.title = asar ? 'azamiden büyük ya da geçersiz' : ''; topH(); };
        tr.appendChild(td); });
      topH(); tr.appendChild(top);
    }
    tr.appendChild(el('td', {}, [el('button', { class: 'btn', text: '−', title: 'Bu sayfayı çıkar', onclick: () => { sonuc.splice(i, 1); tabloCiz(); } })]));
    tb.appendChild(tr);
  });
  $('tablo').innerHTML = ''; $('tablo').appendChild(tb);
}
// 1.6.0 Metin çıktısı: kopyala / yapıştır (Excel için)
$('metinKopya').onclick = async () => { const t = sonuc.filter((r) => r.hizali).map((r) => { const o = listeAl(r).find((q) => q.no === r.no.deger); return [r.no.deger, o ? o.ad : '', ...r.puanlar.map((p) => String(p.deger).replace('.', ','))].join('\t'); }).join('\n');
  const k = $('metinCikti'); k.hidden = false; k.value = t; k.select(); try { await navigator.clipboard.writeText(t); bildir('Tablo panoya kopyalandı (' + t.split('\n').length + ' satır). Yapıştırmadan önce sarı satırları kontrol edin.'); } catch (e) { bildir('Metin aşağıda seçili; Ctrl+C ile kopyalayın.'); } };

// 1.4.0 Toplu yükle köprüsü (toplu.js): hazırlanan sayfaları mevcut okumaya verir
globalThis.TaramaPdfSayfalar = pdfSayfalar;
globalThis.TopluSayfaAyarla = (liste) => { sayfalar = liste; $('sayfaBilgi').textContent = sayfalar.length + ' sayfa'; $('oku').disabled = !sayfalar.length; ilkCiz(); };
// 1.5.0 Otomatik kayıt: okunan/düzeltilen sonuçlar (küçük resimler hariç) 5 sn'de bir bu bilgisayara saklanır; sayfa kapanıp açılınca geri yüklenebilir.
let sonTaslak = '', kosu = 0;
function taslakYaz(bitti) { try { const t = JSON.stringify(sonuc.map((r) => Object.assign({}, r, { sari: !r.hizali || noSari(r) || (r.puanlar || []).some((p) => p.kontrol), no: r.no && { deger: r.no.deger, guven: r.no.guven }, puanlar: r.puanlar && r.puanlar.map((p) => Object.assign({}, p, { img: null })) })));
  if (t !== sonTaslak || bitti) { sonTaslak = t; depo.set({ tarama_taslak: { zaman: Date.now(), kosu, bitti: !!bitti, maxlar, sonuc: JSON.parse(t) } }); } } catch (e) { /* kayıt hatası okumayı durdurmaz */ } }
setInterval(() => taslakYaz(false), 5000);
globalThis.TaramaTaslakYukle = (tk) => { if (!tk || !tk.sonuc || !tk.sonuc.length) return 0; sonuc = tk.sonuc; sonTaslak = JSON.stringify(sonuc); tabloCiz(); notlarKur(); return sonuc.length; };

// 1.6.20 Yerel Okuma Servisi (isteğe bağlı; yalnız 127.0.0.1, erişim belirteci). Okul No ve puan hücreleri iki el yazısı modeliyle
// (Qwen2-VL-2B, TrOCR-large) okunur: ikisi aynı ve yerel okuyucu emin olup başka bir şey demiyorsa yeşil, aksi hâlde sarı.
// Ad Soyad yalnız öneridir, hiçbir zaman yeşil yapmaz. Görüntüler yalnız bellekte; taslağa/diske yazılmaz. Kaydet'e dokunulmaz.
function kanvasKirp(c, a) { if (!a || !(a.w > 0) || !(a.h > 0)) return null; const n = a.x <= 1.5 && a.y <= 1.5 && a.w <= 1.5 && a.h <= 1.5, x = n ? a.x * c.width : a.x, y = n ? a.y * c.height : a.y, w = n ? a.w * c.width : a.w, h = n ? a.h * c.height : a.h;
  if (w < 8 || h < 6) return null; const o = Math.min(2, Math.max(0.5, 80 / h)), k = document.createElement('canvas'); k.width = Math.round(w * o); k.height = Math.round(h * o);
  const g = k.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, k.width, k.height); g.drawImage(c, x, y, w, h, 0, 0, k.width, k.height); return k; }
const KIRP = new Map();
// 1.6.27: Okul No ve puan kesitleri elle kutu (alanlar) ya da bulunan etiket/puan kutusundan HER ZAMAN sayfadan alınır (önizleme değil)
function yerelKirp(r, c) {
  const adA = alanlar.find((a) => a.tur === 'ad'), noA = alanlar.find((a) => a.tur === 'no'), k = {}, sab = tur() === 'sablon';
  if (r.no) k.no = (noA && !sab ? kanvasKirp(c, noA) : null) || (r.etiket && r.etiket.kutu ? kanvasKirp(c, r.etiket.kutu) : null);
  k.puan = (r.puanlar || []).map((p, j) => { const a = !sab && alanlar.find((x) => x.tur === 'soru' && x.j === j); return (a ? kanvasKirp(c, a) : null) || (!sab && p.kutu ? kanvasKirp(c, p.kutu) : null); });
  if (adA && tur() !== 'sablon') k.ad = kanvasKirp(c, adA);
  Object.defineProperty(r, '_yerel', { value: k, enumerable: false, configurable: true, writable: true }); // JSON'a (taslak) girmez
}
// 1.6.22: servis "Sınıf / No" alanında sınıfı da (11-F) okuyabilir: yalnız rakamlar, uzunsa son haneler alınır
function noUz() { const say = {}; if (!sinif.length) { sonuc.forEach((r) => { const l = String((r.no && (r.no.okunan || r.no.deger)) || '').length; if (l >= 3 && l <= 6) say[l] = (say[l] || 0) + 1; }); return Number(Object.keys(say).sort((a, b) => say[b] - say[a])[0]) || 4; } // 1.6.28 listesiz: okunan numaraların çoğunluk uzunluğu
  sinif.forEach((o) => { const l = String(o.no).length; say[l] = (say[l] || 0) + 1; }); return Number(Object.keys(say).sort((a, b) => say[b] - say[a])[0]) || 4; }
function noServisDuz(so) { if (!so) return so; const u = noUz(), d = (v) => { if (v == null || v === '') return v; const s = String(v).replace(/\D/g, ''); return s.length > u ? s.slice(-u) : s; };
  const o = Object.assign({}, so, { deger: d(so.deger) }), m = so.motorlar || {}; o.motorlar = Object.assign({}, m, { qwen: d(m.qwen), trocr: d(m.trocr) });
  if (o.durum === 'yesil' && m.qwen != null && m.trocr != null && d(m.qwen) !== d(m.trocr)) o.durum = 'sari'; return o; }
// 1.6.27 Puan oylaması: servis modelleri (ölçülmüş ağırlıklarla; yoksa Qwen 1, TrOCR .8, Paddle .6) + tarayıcı okuması (güveni) + tarayıcı
// adayları. Azami puanı aşan değer elenir. YEŞİL yalnız: servisin seçili ikilisi aynı + tarayıcı da aynı değeri (ya da adaylarında) okumuş + toplam tutuyor.
function puanOyla(p, so) {
  const mx = Number(p.max) || 100, gec = (q) => q !== '' && q != null && /^\d{1,3}([.,]\d{1,2})?$/.test(String(q)) && Number(String(q).replace(',', '.')) >= 0 && Number(String(q).replace(',', '.')) <= mx;
  const m = so.motorlar || {}, toplamSorun = /^toplam tutmuyor/.test(p.neden || ''), eski = p.bos || p.deger == null ? '' : String(p.deger);
  const pAday = (p.adaylar || []).map((a) => String(a).split(' ')), oy = {}, ekle = (v, w) => { v = String(v == null ? '' : v).replace(',', '.'); if (gec(v)) oy[v] = (oy[v] || 0) + w; };
  const W = { qwen: 1, trocr: 0.8, paddle: 0.6 }; if (Array.isArray(so.oylar) && so.oylar.length) so.oylar.forEach(([v, w]) => ekle(v, Number(w) || 0)); else Object.keys(m).forEach((k) => ekle(m[k], W[k] || 0.5));
  if (eski) ekle(eski, 0.9 * Math.max(0.3, (p.guven || 50) / 100)); pAday.forEach(([v, y]) => ekle(v, 0.4 * (parseInt(String(y || '').replace('%', ''), 10) || 30) / 100));
  const sira = Object.entries(oy).sort((a, b) => b[1] - a[1]); if (!sira.length) { p.kontrol = true; p.neden = (toplamSorun ? p.neden + ' · ' : '') + 'okunamadı (servis + tarayıcı)'; return 's'; }
  const en = sira[0][0], destek = eski === en || pAday.some(([v]) => v === en);
  if (en !== eski) { p.okunan = eski; p.deger = en; p.bos = false; } p.adaylar = [...new Set([eski, ...sira.slice(1, 4).map((x) => x[0]), m.qwen, m.trocr, m.paddle].filter((q) => q && q !== en))];
  if (so.durum === 'yesil' && String(so.deger) === en && destek && !toplamSorun) { p.kontrol = false; p.guven = Math.max(p.guven || 0, 95); p.neden = 'yerel servis + tarayıcı aynı'; return 'y'; }
  p.kontrol = true; p.guven = Math.min(p.guven || 60, P.ESIK - 1); p.neden = (toplamSorun ? p.neden + ' · ' : '') + 'oylama ' + en + (sira[1] ? ' (2.: ' + sira[1][0] + ')' : '') + ' — kontrol edin'; return 's'; }
async function yerelTur(rows) { rows = rows || sonuc;
  const YO = globalThis.YerelOkuma; if (!YO) return;
  const nolar = sinif.map((o) => String(o.no)), is = [];
  for (const r of rows) { if (!r.hizali) continue; const k = r._yerel || {};
    const noG = r.no && (k.no || r.no.img); if (noG) is.push({ r, tip: 'no', alan: { tur: 'no', png: YO.png(noG) } }); // 1.6.27 boş okunsa da servis dener
    (r.puanlar || []).forEach((p, j) => { const g = (k.puan || [])[j] || p.img; if (g && !p.alanYok) is.push({ r, p, tip: 'puan', alan: { tur: 'puan', png: YO.png(g) } }); });
    if (k.ad && sinif.length) is.push({ r, tip: 'ad', alan: { tur: 'ad', png: YO.png(k.ad), adaylar: sinif.map((o) => ({ anahtar: String(o.no), ad: o.ad || '' })) } }); }
  if (!is.length) return;
  $('ilerleme').textContent = 'Yerel okuma servisi: ' + is.length + ' alan';
  const s = await YO.oku(is.map((x) => x.alan)); if (!s) { console.log('Yerel okuma servisi yanıt vermedi; yerel okuma kullanıldı'); return; }
  let yesil = 0, sari = 0;
  is.forEach((x, i) => { const r = x.r, so = s[i]; if (!so) return;
    if (x.tip === 'no') { const so2 = noServisDuz(so), m = so2.motorlar || {}, b = YO.rakamBirlestir(r.no.deger, r.no.guven / 100, so2); if (!b) return;
      // 1.6.26: servis BİRİNCİL okuyucu. İki model aynıysa değer servisinkidir (listede varsa yeşil); farklıysa Qwen değeri, sarı. Tarayıcı okuması aday kalır
      const eski = String(r.no.deger || ''), sv = so2.durum === 'yesil' && so2.deger ? String(so2.deger) : '', u = noUz();
      if (sv && sv.length === u) { if (sv !== eski) { r.no.okunan = eski; r.no.deger = sv; }
        r.no.adaylar = [...new Set([eski, m.trocr, m.paddle, ...(r.no.adaylar || [])].filter((v) => v && v !== sv))];
        if (sinif.length && nolar.includes(sv) && !(eski && eski !== sv && nolar.includes(eski) && !(r.no.adaylar || []).includes(sv))) { r.no.guven = Math.max(r.no.guven || 0, 95); r.no.neden = 'yerel servis: iki model aynı'; r.no.belirsiz = false; yesil++; }
        else { r.no.guven = Math.min(r.no.guven || 70, P.ESIK - 1); r.no.belirsiz = true; r.no.neden = sinif.length ? 'yerel servis ' + sv + ' okudu ama sınıf listesinde yok — kontrol edin' : 'yerel servis ' + sv + ' okudu (sınıf listesi yok — kontrol edin)'; sari++; } }
      else { const q = [so2.deger, m.qwen].map((v) => String(v || '')).find((v) => v.length === u) || ''; if (q && q !== eski) { r.no.okunan = eski; r.no.deger = q; }
        r.no.adaylar = [...new Set([eski, m.qwen, m.trocr, m.paddle, ...(r.no.adaylar || [])].filter((v) => v && v !== r.no.deger))];
        r.no.guven = Math.min(r.no.guven || 70, P.ESIK - 1); r.no.belirsiz = true; r.no.neden = b.not || 'yerel servis emin değil — kontrol edin'; sari++; }
      if (sinif.length || r.adSoyad) r.ogr = B.ogrenciEsle(sinif, r.no, r.adSoyad); }
    else if (x.tip === 'puan') { const p = x.p; if (!so.durum) return; const r2 = puanOyla(p, so); if (r2 === 'y') yesil++; else sari++; }
    else if (x.tip === 'ad' && so.oneri && so.oneri.anahtar) { // yalnız öneri: numarayı değiştirmez, satırı asla yeşil yapmaz
      const on = String(so.oneri.anahtar); r.ogr = r.ogr || { kontrol: true, neden: '' };
      if (on !== String(r.no.deger)) { r.ogr.kontrol = true; r.ogr.alternatif = { no: on }; r.ogr.neden = (r.ogr.neden ? r.ogr.neden + ' · ' : '') + 'yerel servis adı başka öğrenciye benzetti (' + on + ')'; }
      else r.ogr.yerelAd = 'yerel servis adı da bu öğrenciyi gösteriyor'; } });
  // soru puanları değiştiyse kâğıttaki toplamla sağlama yeniden yapılır
  for (const r of rows) { const sg = r.saglama; if (!r.hizali || !sg || sg.toplam === null || !r.puanlar || r.puanlar.length < 2) continue;
    const top = r.puanlar.reduce((t, p) => t + (Number(String(p.deger).replace(',', '.')) || 0), 0); sg.soruToplam = top;
    if (top !== sg.toplam) r.puanlar.forEach((p) => { if (!/toplam tutmuyor/.test(p.neden || '')) { p.kontrol = true; p.neden = 'toplam tutmuyor (kâğıtta ' + sg.toplam + ', sorular ' + top + ')' + (p.neden ? ' · ' + p.neden : ''); } }); }
  console.log('Yerel okuma servisi: ' + is.length + ' alan, ' + yesil + ' yeşil, ' + sari + ' sarı');
}
{ const YO = globalThis.YerelOkuma; // ayar satırı
  const goster = async () => { if (!YO || !$('yoDurum')) return; const d = await YO.durum(1500);
    $('yoDurum').textContent = d.durum === 'kapali' ? (d.acik ? 'servis kapalı — yerel okuma kullanılıyor' : 'kullanılmıyor') : !d.acik || !d.eslesmis ? 'servis açık, eşleşmemiş' : d.durum === 'hazir' ? 'BAĞLI (' + (d.cihaz === 'cuda' ? 'GPU' : 'CPU') + ')' : 'modeller ' + d.durum; };
  if (YO && $('yoBaglan')) { $('yoBaglan').onclick = async () => { const r = await YO.eslestir(); bildir(r.ok ? 'Yerel okuma servisine bağlandı.' : 'Bağlanamadı: ' + r.hata); goster(); };
    $('yoKapat').onclick = async () => { await YO.kapat(); goster(); };
    // 1.6.26: servis açık ve eşleşmemişse kendiliğinden bağlan (Kullanma seçilmediyse)
    const oto = async () => { let r = null; try { r = YO.otoEslestir ? await YO.otoEslestir() : null; } catch (e) { r = null; } await goster();
      if (r && !r.ok && r.neden === 'eslestirme_kapali' && $('yoDurum')) $('yoDurum').textContent = 'servis açık, eşleşmemiş — Başlat menüsü → Yerel Okuma → "Yerel Okuma - Eşleştir"e bir kez tıklayın; bu sayfa kendiliğinden bağlanır';
      else if (r && r.ok && $('yoDurum')) $('yoDurum').textContent += r.d && r.d.metin === 'hazir' ? ' · başlık: PaddleOCR' : ' · başlık: Tesseract'; return r; };
    // eşleşme bekleniyorsa 10 dk boyunca 15 sn'de bir yeniden denenir (kısayola tıklayınca sayfayı yenilemek gerekmez)
    oto().then((r) => { if (!r || r.ok || r.neden !== 'eslestirme_kapali') return; let n = 0; const z = setInterval(async () => { n++; const q = await oto(); if ((q && (q.ok || q.neden !== 'eslestirme_kapali')) || n >= 40) clearInterval(z); }, 15000); }); } }

// 1.6.2 İsteğe bağlı Gemini ikinci okuyucu (varsayılan kapalı). Yalnız sarı Okul No / puan hücre kesiti gider.
const G = globalThis.GeminiOku;
if (G) G.ayarAl().then((a) => { $('gemAcik').checked = a.acik; $('gemAnahtar').value = a.anahtar; $('gemAnahtar').hidden = !a.acik; });
if (G) { const yaz = () => { $('gemAnahtar').hidden = !$('gemAcik').checked; G.ayarYaz({ acik: $('gemAcik').checked, anahtar: $('gemAnahtar').value }); };
  $('gemAcik').onchange = yaz; $('gemAnahtar').onchange = yaz; }
async function geminiTur() {
  if (!G) return; const a = await G.ayarAl(); if (!a.acik || !a.anahtar) return;
  let n = 0, y = 0;
  for (const r of sonuc) { if (!r.hizali) continue; const sinif = listeAl(r), nolar = sinif.map((o) => o.no);
    if (r.no && noSari(r) && r.no.img) { $('ilerleme').textContent = 'Gemini ile kontrol: ' + (++n);
      const k = G.karar('no', r.no.deger, await G.hucreOku(G.pngYap(r.no.img), 'no', a.anahtar), nolar);
      r.no.gemini = k.neden; if (k.yesil) { r.no.deger = k.deger; r.no.guven = Math.max(r.no.guven, 95); if (r.ogr) r.ogr = B.ogrenciEsle(sinif, r.no, r.adSoyad); y++; } else if (k.aday) r.no.aday = k.aday; }
    (r.puanlar || []).forEach((p) => { p._g = p.kontrol && !p.bos && p.img; });
    for (const p of r.puanlar || []) { if (!p._g) continue; delete p._g; $('ilerleme').textContent = 'Gemini ile kontrol: ' + (++n);
      const k = G.karar('puan', p.deger, await G.hucreOku(G.pngYap(p.img), 'puan', a.anahtar), null);
      if (k.yesil) { p.kontrol = false; p.neden = 'yerel + Gemini aynı'; y++; } else { p.neden = (p.neden ? p.neden + ' · ' : '') + k.neden; } } }
  if (n) console.log('Gemini: ' + n + ' hücre soruldu, ' + y + ' hücre doğrulandı');
}

// 1.6.8 Not tablosu: Okul No | Ad Soyad (maskeli) | Not. Hücreler düzenlenebilir, +/− satır, Excel'den yapıştırma.
// Sarı = belirsiz; elle düzeltilen ya da ✓ ile onaylanan satır kesin sayılır. "e-Okul'a yaz" tabloyu e-Okul sekmesine verir; Kaydet'e siz basarsınız.
let notlar = [];
const BASIT = /[?&]basit=1/.test(location.search); // 1.6.9: Not Girişi panelinden açıldı
if (BASIT) { ['soruBilgi', 'incele'].forEach((i) => { const e = $(i); if (e) e.style.display = 'none'; }); }
const notGecerli = (v) => { v = String(v).trim().toUpperCase(); return v === 'G' || (/^\d{1,3}$/.test(v) && +v <= 100); };
function notlarKur() {
  notlar = sonuc.map((r, si) => { const d = (r.puanlar || []).map((p) => String(p.deger == null ? '' : p.deger).replace(',', '.'));
    const not = d.some((v) => v.toUpperCase() === 'G') ? 'G' : d.length && !d.some((v) => v === '') ? String(Math.round(d.reduce((a, v) => a + Number(v), 0))) : '';
    const no = r.no && r.no.deger || '', sari = !r.hizali || noSari(r) || (r.puanlar || []).some((p) => p.kontrol);
    const bs = r.bas || {}; return { si, lst: r.lst || '', no, not: not === '' ? 'G' : not, kesin: !sari && not !== '' && notGecerli(not), sinif: bs.sinif || '', ders: bs.ders || '', alan: bs.alan || '', basKesin: !!bs.kesin }; });
  // 1.6.27 Sınıf listesinde olup kâğıdı okunmamış öğrenciler: G (girmedi). Ayrı renkte, düzenlenebilir; e-Okul'da değeri olan kutuya yazılmaz
  // 1.6.28 G yalnız kendi grubunun (sınıf-şube) listesinden; gruplar sıralı gösterilir
  [...new Set(notlar.map((n) => n.lst).filter(Boolean))].forEach((an) => { const L = LST.get(an) || [], gr = notlar.filter((n) => n.lst === an), var_ = new Set(gr.map((n) => n.no)), o0 = gr.find((n) => n.sinif) || {};
    const supheli = notlar.some((n) => !n.lst && !n.girmedi && n.no); // listesiz grupta okunmuş kâğıt varsa (şube yanlış okunmuş olabilir) G'ler sarı
    L.forEach((o) => { if (!var_.has(o.no)) notlar.push({ lst: an, no: o.no, not: 'G', kesin: !supheli, girmedi: true, eksik: true, sinif: o0.sinif || an, ders: o0.ders || '', alan: o0.alan || '', basKesin: !!o0.basKesin }); }); });
  const sira = [...new Set(notlar.map((n) => n.sinif || ''))]; notlar = sira.flatMap((g) => notlar.filter((n) => (n.sinif || '') === g));
  notCiz();
}
function notCiz() {
  const k = $('notTablo'); if (!k) return; $('notBolum').hidden = false; k.innerHTML = '';
  const tb = el('table', {}, [el('tr', {}, [el('th', { text: 'Okul No' }), el('th', { text: 'Ad Soyad' }), el('th', { text: 'Not' }), el('th', { text: '' })])]);
  const nolar = notlar.map((n) => n.no);
  let gOnce = null;
  notlar.forEach((n, i) => { if (GRUPLAR.length > 1 && (n.sinif || '') !== gOnce) { gOnce = n.sinif || ''; const gr = notlar.filter((q) => (q.sinif || '') === gOnce), gi = GRUPLAR.find((x) => x.sinif === gOnce) || {};
      tb.appendChild(el('tr', { class: 'grupBas' }, [el('td', { colspan: '4', style: 'text-align:left;font-weight:bold;background:#e0e0e0', text: (gOnce || 'şube okunamadı') + ' — ' + gr.filter((q) => !q.girmedi).length + ' kâğıt' + (gi.liste ? ', liste: ' + gi.liste + ' (' + gr.filter((q) => q.girmedi).length + ' G)' : ', bu şubenin listesi yok (e-Okul\'da bu şubeyi Listele\'yin)') })])); }
    const cift = n.no && nolar.indexOf(n.no) !== i || nolar.lastIndexOf(n.no) !== i, sari = !n.kesin || cift || !notGecerli(n.not) || !n.no;
    const sinif = LST.get(n.lst) || [], o = sinif.find((q) => q.no === n.no), tr = el('tr', { class: n.girmedi && n.not === 'G' ? 'girmedi' : sari ? 'kontrol' : '' });
    const gir = (alan) => { const x = el('input', { value: n[alan], inputmode: alan === 'no' ? 'numeric' : 'text', 'aria-label': alan === 'no' ? 'Okul No' : 'Not' }); x.onchange = () => { n[alan] = x.value.trim().toUpperCase(); n.kesin = true; notCiz(); }; return x; };
    tr.append(el('td', {}, [gir('no')]), el('td', { style: 'text-align:left', text: (o ? B.maskele(o.ad) : (n.no ? (sinif.length ? 'listede yok' : 'bu şubenin listesi yok') : '')) + (n.girmedi ? ' — kâğıdı okunmadı → G (girmedi); kâğıdı varsa notu yazın' : '') }), el('td', {}, [gir('not')]),
      el('td', {}, [sari && n.no && notGecerli(n.not) && !cift ? el('button', { class: 'btn acik', text: '✓', title: 'Kâğıtla karşılaştırdım, doğru', onclick: () => { n.kesin = true; notCiz(); } }) : null,
        el('button', { class: 'btn', text: '−', title: 'Satırı sil', onclick: () => { notlar.splice(i, 1); notCiz(); } })]));
    tb.appendChild(tr); });
  k.appendChild(tb);
  const sar = notlar.filter((n, i) => !n.kesin || !notGecerli(n.not) || !n.no || nolar.indexOf(n.no) !== i || nolar.lastIndexOf(n.no) !== i).length;
  const gi = notlar.filter((n) => n.girmedi && n.not === 'G').length; $('notOzet').textContent = notlar.length + ' satır, ' + sar + ' sarı' + (gi ? ', ' + gi + ' öğrenci G (girmedi, mavi)' : '') + '.';
}
if ($('notArti')) {
  $('notArti').onclick = () => { notlar.push({ no: '', not: '', kesin: false }); notCiz(); };
  $('notTablo').addEventListener('paste', (e) => { const t = (e.clipboardData || window.clipboardData).getData('text'); if (!t || !/[\t\n]/.test(t)) return; e.preventDefault();
    t.split(/\r?\n/).map((l) => l.split('\t').map((x) => x.trim())).filter((c) => c.some((x) => x)).forEach((c) => {
      const no = (c.find((x) => /^\d{1,6}$/.test(x)) || '').trim(), not = c.length > 1 ? c[c.length - 1].toUpperCase() : '';
      if (no) notlar.push({ no, not, kesin: true }); });
    notCiz(); bildir('Yapıştırılan satırlar eklendi. Okul No ve Not sütunlarını kontrol edin.'); });
  $('notYaz').onclick = () => { if (!notlar.length) return bildir('Tablo boş.');
    const nolar = notlar.map((n) => n.no);
    const satirlar = notlar.filter((n) => n.no).map((n, i) => ({ no: n.no, not: n.not, kesin: n.kesin && notGecerli(n.not) && nolar.indexOf(n.no) === nolar.lastIndexOf(n.no), eksik: !!(n.girmedi && n.not === 'G'), sinif: n.sinif || '', ders: n.ders || '', alan: n.alan || '', basKesin: !!n.basKesin }));
    depo.set({ ng_not_tablosu: { zaman: Date.now(), satirlar } }, () => bildir(satirlar.length + ' satır e-Okul sekmesine verildi. Hızlı Not Girişi sayfasında Güvenlik Kodu\'nu yazın (ya da paneldeki "Okunan puanları yaz"a basın). Kaydet\'e siz basarsınız.')); };
}

// 1.6.24 Tanı kaydı: yalnız Okul No ve puan kesitleri (küçük), etiket kutuları, yazı tanıma ham çıktıları, ayarlar ve hatalar.
// Ad/soyad, sayfanın tamamı ve sınıf listesi YAZILMAZ. Dosya yalnız bu bilgisayarın İndirilenler klasörüne kaydedilir; hiçbir yere gönderilmez.
const TANI = { hatalar: [], log: [], sayfalar: [], noKesit: null, bas: [] };
// başlık yazı tanıma çıktısı (Ad Soyad satırı çıkarılır)
function taniSar(w) { if (!w || w.__tani) return; w.__tani = true; const r0 = w.recognize.bind(w);
  w.recognize = async (...a) => { const t0 = Date.now(); try { const x = await r0(...a); try { if (TANI.bas.length < 12) TANI.bas.push({ ms: Date.now() - t0, guven: x.data && Math.round(x.data.confidence), metin: String((x.data && x.data.text) || '').split('\n').filter((l) => !/ad[ıi]?\s*soyad|name/i.test(l)).join('\n').slice(0, 1200) }); } catch (e) { } return x; }
    catch (e) { TANI.hatalar.push('başlık OCR: ' + (e && e.message || e)); throw e; } }; }
{ const sar = (ad) => { const o = console[ad].bind(console); console[ad] = (...a) => { try { if (TANI.log.length < 400) TANI.log.push(ad + ': ' + a.map((x) => (typeof x === 'string' ? x : (x && x.message) || JSON.stringify(x))).join(' ').slice(0, 300)); } catch (e) { } o(...a); }; };
  sar('log'); sar('warn'); sar('error');
  addEventListener('error', (e) => TANI.hatalar.push('error: ' + (e.message || '') + ' @' + (e.filename || '').split('/').pop() + ':' + (e.lineno || '')));
  addEventListener('unhandledrejection', (e) => TANI.hatalar.push('promise: ' + ((e.reason && e.reason.message) || String(e.reason)).slice(0, 300)));
  globalThis.ETK_DEBUG = (k) => { try { TANI.noKesit = kucukPng(k, 600); } catch (e) { } }; }
function kucukPng(src, enCok, a) { const W = src.width, H = src.height, x = a ? Math.max(0, Math.round(a.x * W)) : 0, y = a ? Math.max(0, Math.round(a.y * H)) : 0, w = a ? Math.min(W - x, Math.round(a.w * W)) : W, h = a ? Math.min(H - y, Math.round(a.h * H)) : H;
  if (!(w > 2 && h > 2)) return null; const o = Math.min(1, enCok / w), k = document.createElement('canvas'); k.width = Math.max(1, Math.round(w * o)); k.height = Math.max(1, Math.round(h * o));
  const g = k.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, k.width, k.height); g.drawImage(src, x, y, w, h, 0, 0, k.width, k.height); return k.toDataURL('image/png'); }
function taniEk(r, ad, f) { if (!f) return; const t = r._tani || {}; t[ad] = { no: f.no, guven: f.noGuven, neden: f.neden || f.noNeden, etiket: f.etiket, ham: f.ham, dbg: f.dbg, kutu: f.kutu, noKutu: f.noKutu, oylar: f.oylar, adaylar: f.noAdaylar, yon: f.yon, tur: f.tur, alan: f.alan };
  Object.defineProperty(r, '_tani', { value: t, enumerable: false, configurable: true, writable: true }); }
function taniSayfa(r, s) { const c = s.c, t = r._tani || {}, p0 = r.puanlar && r.puanlar[0], ek = t.etiket || t.form || {};
  const nk = ek.kutu && ek.kutu.w ? ek.kutu : (t.kutu && t.kutu.alan) || null, pk = p0 && p0.kutu && p0.kutu.w ? p0.kutu : null, pad = (a) => a && { x: Math.max(0, a.x - a.w * 0.15), y: Math.max(0, a.y - a.h * 0.4), w: a.w * 1.3, h: a.h * 1.8 };
  TANI.sayfalar.push({ sayfa: TANI.sayfalar.length + 1, boyut: [c.width, c.height], hizali: r.hizali, hata: r.hata || '', tur: tur(),
    no: r.no ? { deger: r.no.deger, guven: r.no.guven, neden: r.no.neden, oylar: r.no.oylar, adaylar: r.no.adaylar, okunan: r.no.okunan } : null,
    puanlar: (r.puanlar || []).map((p) => ({ deger: p.deger, guven: p.guven, kontrol: p.kontrol, bos: p.bos, neden: p.neden, max: p.max, adaylar: p.adaylar, kutu: p.kutu })),
    etiket: t.etiket || null, form: t.form || null, kutuOkuma: t.kutu || null, bas: r.bas ? { ders: r.bas.ders, dersKesin: r.bas.dersKesin, seviye: r.bas.seviye, sinavNo: r.bas.sinavNo, sinif: r.bas.sinif, sinifKesin: r.bas.sinifKesin, alan: r.bas.alan, kesin: r.bas.kesin } : null, basOcr: TANI.bas.splice(0),
    kesit: { no: nk ? kucukPng(c, 500, nk) : null, noIslenmis: TANI.noKesit, puan: pk ? kucukPng(c, 300, pad(pk)) : null } });
  TANI.noKesit = null; }
async function taniKaydet() {
  const m = (globalThis.chrome && chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest() : {}, boy = async (y) => { try { const b = await (await fetch(y)).arrayBuffer(); return b.byteLength; } catch (e) { return 'okunamadı: ' + e.message; } };
  let yo = null; try { yo = globalThis.YerelOkuma ? await YerelOkuma.durum(1500) : null; } catch (e) { yo = { hata: e.message }; }
  const d = { surum: m.version || '', zaman: new Date().toISOString(), tarayici: navigator.userAgent, dpr: devicePixelRatio, ekran: [screen.width, screen.height], dil: navigator.language,
    ayar: { ust: UST, tur: tur(), formNo: !!($('formNo') && $('formNo').checked), esik: P.ESIK, maxlar, alanlar, alanYeni, sinifListesi: listeSay(), siniflar: Object.values(SL).map((x) => x.ad + ':' + x.liste.length).concat(KEYSIZ.length ? ['şubesiz:' + KEYSIZ.length] : []), gruplar: GRUPLAR, rakamHazir: !!(P.hazir && P.hazir()) },
    yerelServis: yo && { durum: yo.durum, acik: yo.acik, eslesmis: yo.eslesmis, cihaz: yo.cihaz, metin: yo.metin, qwen: yo.qwen, surum: yo.surum, eslestirmeAcik: yo.eslestirme_acik }, paddleSayfa: TANI.paddle || 0, paddleMs: TANI.paddleMs || 0, gemini: !!($('gemAcik') && $('gemAcik').checked),
    tesseract: { var: !!globalThis.Tesseract, surum: globalThis.Tesseract && Tesseract.version, lang: await boy('lib/lang/tur.traineddata.gz'), core: await boy('lib/tess-core/tesseract-core-simd-lstm.wasm'), rakamBin: await boy('rakam.bin') },
    ocrDeneme: await ocrDene(), sayfalar: TANI.sayfalar,
    son: sonuc.map((r, i) => ({ sayfa: i + 1, no: r.no && r.no.deger, noGuven: r.no && r.no.guven, noNeden: r.no && r.no.neden, noAday: r.no && r.no.adaylar, sari: !!(r.hizali && noSari(r)), puan: (r.puanlar || []).map((p) => ({ d: p.deger, k: !!p.kontrol, n: p.neden, a: p.adaylar })), sinif: r.bas && r.bas.sinif, ders: r.bas && r.bas.ders })), // 1.6.27 son değerler (servis + liste sonrası)
    notTablosu: (notlar || []).map((n) => ({ no: n.no, not: n.not, kesin: !!n.kesin, girmedi: !!n.girmedi })), hatalar: TANI.hatalar, log: TANI.log, mesaj: $('mesaj').textContent };
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(d, null, 1)], { type: 'application/json' }));
  a.download = 'not-girisi-tani-' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.json'; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
  bildir('Tanı dosyası İndirilenler klasörüne kaydedildi: ' + a.download + ' (yalnız Okul No/puan kesitleri; ad ve sayfanın tamamı yok).'); }
// 1.6.27 Ölçüm verisi (yerel model seçimi için, Olc.cmd): yalnız Okul No / puan kesitleri + öğretmenin kontrol ettiği değerler. Ad yok.
// Dosya yalnız İndirilenler'e yazılır; Olc.cmd bu bilgisayarda okur ve işi bitince siler.
function olcumKaydet() { const ornek = [], png = (c) => (c && c.toDataURL ? c.toDataURL('image/png').replace(/^data:image\/png;base64,/, '') : '');
  (notlar || []).forEach((n) => { if (n.si == null || !n.kesin || n.girmedi) return; const r = sonuc[n.si], k = KIRP.get(n.si); if (!r || !k) return;
    if (k.no && /^\d{3,6}$/.test(n.no)) ornek.push({ tur: 'no', png: png(k.no), etiket: n.no });
    const ps = r.puanlar || []; if (ps.length === 1 && k.puan && k.puan[0] && /^\d{1,3}$/.test(n.not)) ornek.push({ tur: 'puan', png: png(k.puan[0]), etiket: n.not });
    else ps.forEach((p, j) => { if (p.duzeltildi && k.puan && k.puan[j] && /^\d{1,3}([.,]\d)?$/.test(String(p.deger))) ornek.push({ tur: 'puan', png: png(k.puan[j]), etiket: String(p.deger) }); }); });
  if (ornek.length < 6) return bildir('Ölçüm için en az 6 kontrol edilmiş alan gerekli. Not tablosunda satırları kâğıtla karşılaştırıp ✓ ile onaylayın, sonra yeniden deneyin.');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify({ surum: (chrome.runtime.getManifest() || {}).version, zaman: new Date().toISOString(), ornekler: ornek })], { type: 'application/json' }));
  a.download = 'not-girisi-olcum-' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.json'; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
  bildir(ornek.length + ' alan ölçüm dosyasına yazıldı (' + a.download + ', İndirilenler). Yerel Okuma klasöründeki Olc.cmd\'yi çalıştırın: modeller bu bilgisayarda karşılaştırılır, en iyisi varsayılan olur, dosya silinir.'); }
if ($('olcumKaydet')) $('olcumKaydet').onclick = () => { try { olcumKaydet(); } catch (e) { bildir('Ölçüm verisi kaydedilemedi: ' + e.message); } };
if ($('taniKaydet')) $('taniKaydet').onclick = () => { taniKaydet().catch((e) => bildir('Tanı kaydedilemedi: ' + e.message)); };
async function ocrDene() { if (!globalThis.Tesseract) return 'Tesseract yok'; const t0 = Date.now(); let w = null;
  try { const url = (y) => (globalThis.chrome && chrome.runtime && chrome.runtime.getURL ? chrome.runtime.getURL('tarama/' + y) : new URL(y, location.href).href);
    w = await Tesseract.createWorker('tur', 1, { workerPath: url('lib/worker.min.js'), corePath: url('lib/tess-core/'), langPath: url('lib/lang'), workerBlobURL: false, cacheMethod: 'none' });
    const k = document.createElement('canvas'); k.width = 900; k.height = 120; const g = k.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, 900, 120); g.fillStyle = '#000'; g.font = 'bold 34px Times New Roman, serif'; g.fillText('11. SINIF TÜRK DİLİ VE EDEBİYATI', 20, 50); g.fillText('Sınıf / No: 1. DÖNEM 1. SINAV', 20, 100);
    const r = await w.recognize(k); return { ms: Date.now() - t0, metin: r.data.text, guven: Math.round(r.data.confidence) }; }
  catch (e) { return { ms: Date.now() - t0, hata: String((e && e.message) || e) }; } finally { try { w && w.terminate(); } catch (e) { } } }
// 1.6.24 Üst bölge: sayfanın altı beyazlanır (koordinatlar değişmez; kutular ve oranlar aynı kalır). Şablonlu kâğıtta (köşe işaretli) uygulanmaz.
const ustAcik = () => UST < 100 && tur() !== 'sablon';
function ustMaske(c) { const k = document.createElement('canvas'); k.width = c.width; k.height = c.height; const g = k.getContext('2d', { willReadFrequently: true });
  g.drawImage(c, 0, 0); const y = Math.round(c.height * UST / 100); g.fillStyle = '#fff'; g.fillRect(0, y, c.width, c.height - y); return k; }
if ($('ustYuzde')) { const u = $('ustYuzde'); depo.get(['tarama_ust'], (v) => { if (v && v.tarama_ust) UST = Math.max(10, Math.min(100, Number(v.tarama_ust) || 25)); u.value = UST; });
  u.onchange = () => { UST = Math.max(10, Math.min(100, Number(u.value) || 25)); u.value = UST; depo.set({ tarama_ust: UST }); }; }
// 1.6.25 Rakam karışıklığı (4/6, 4/1, 4/7, 1/7): aynı sınıfın numaraları çoğunlukla aynı haneyle başlar (ör. 42xx).
// Bir sayfanın ilk hanesi çoğunluktan farklıysa oylarda çoğunluk haneli aday varsa ona, yoksa bilinen karışık çiftse ilk hane çoğunluğa çevrilir.
// Sınıf listesi varsa yalnız listedeki numaraya geçilir. Her düzeltme SARI kalır (asla yeşil değil).
// 1.6.26 Sınıf listesi varken Okul No HER ZAMAN listedeki bir numaraya oturtulur (listede olmayan numara bırakılmaz).
// Uzaklık: hane karışıklığına duyarlı düzenleme mesafesi (1/7, 3/5/6/8, 4/6/1/7/9, 0/6/8 değişimi 0.4; diğer değişim/ekleme/silme 1).
// Okunan değer, oylar ve adaylar (yerel servis dahil) denenir; başka sayfada kesin kullanılan numara cezalı. Oturtulan satır hep SARI.
const HKAR = { 1: '74', 7: '14', 3: '5868', 5: '36', 6: '45803', 4: '6179', 9: '4', 8: '3605', 0: '68' };
const hMal = (a, b) => (a === b ? 0 : ((HKAR[a] || '').includes(b) || (HKAR[b] || '').includes(a) ? 0.4 : 1));
function noUzak(a, b) { const m = a.length, n = b.length; let d = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) { const e = [i]; for (let j = 1; j <= n; j++) e[j] = Math.min(d[j] + 1, e[j - 1] + 1, d[j - 1] + hMal(a[i - 1], b[j - 1])); d = e; } return d[n]; }
function listeOtur(liste) { if (!sinif.length) return 0; const nolar = [...new Set(sinif.map((o) => String(o.no)).filter(Boolean))]; if (!nolar.length) return 0; let say = 0;
  const kesin = new Set(liste.filter((r) => r.hizali && r.no && nolar.includes(String(r.no.deger)) && !noSari(r)).map((r) => String(r.no.deger)));
  const alinan = new Set(liste.filter((r) => r.no && nolar.includes(String(r.no.deger))).map((r) => String(r.no.deger))); // başka kâğıdın birebir okuduğu numara (sarı da olsa)
  liste.forEach((r) => { if (!r.hizali || !r.no) return; const v = String(r.no.deger || ''); if (nolar.includes(v)) return;
    const ad = [v, ...String(r.no.oylar || '').split(/\s+/).map((x) => x.split('×')[0]), ...(r.no.adaylar || [])].map((x) => String(x || '').replace(/\D/g, '')).filter(Boolean);
    if (!ad.length) return; const sk = nolar.map((n) => { let m = Infinity; ad.forEach((a, i) => { m = Math.min(m, noUzak(a, n) + (i ? 0.15 : 0)); }); return { n, m: m + (kesin.has(n) ? 1.5 : alinan.has(n) ? 1.0 : 0) }; }).sort((a, b) => a.m - b.m);
    const en = sk[0], ik = sk[1];
    if (v && en.m > 1.5) { r.no.okunan = r.no.okunan || v; r.no.guven = Math.min(r.no.guven || 60, P.ESIK - 1); r.no.belirsiz = true; r.no.neden = v + ' sınıf listesinde yok, yakın numara da yok (başka şube?) — kontrol edin'; r.no.adaylar = [...new Set([...(r.no.adaylar || []), ...sk.slice(0, 2).map((x) => x.n)])]; return; } // 1.6.28 uzak numaraya oturtma yok
    r.no.okunan = r.no.okunan || v; r.no.deger = en.n; r.no.guven = Math.min(r.no.guven || 60, P.ESIK - 1); r.no.belirsiz = true;
    r.no.neden = (v ? v + ' sınıf listesinde yok' : 'numara okunamadı') + ' → en yakın ' + en.n + (en.m > 1.2 || (ik && ik.m - en.m < 0.3) ? ' (zayıf eşleşme)' : '') + ' — kontrol edin';
    r.no.adaylar = [...new Set([v, ...sk.slice(1, 3).map((x) => x.n)].filter((x) => x && x !== en.n))]; say++;
    r.ogr = B.ogrenciEsle(sinif, r.no, r.adSoyad); if (r.ogr) r.ogr.kontrol = true; });
  return say; }
const KARISIK = { 4: '1679', 6: '4', 1: '47', 7: '14', 9: '4', 3: '8', 8: '3', 5: '6' };
function haneDuzelt(liste) { const rs = liste.filter((r) => r.hizali && r.no && /^\d{4}$/.test(r.no.deger || '')); if (rs.length < 4) return 0;
  const say = {}; rs.forEach((r) => { const h = r.no.deger[0]; say[h] = (say[h] || 0) + 1; }); const [ch, n] = Object.entries(say).sort((a, b) => b[1] - a[1])[0]; if (n / rs.length < 0.6) return 0;
  const listede = (v) => !sinif.length || sinif.some((o) => o.no === v); let d = 0;
  rs.forEach((r) => { const v = r.no.deger; if (v[0] === ch) return;
    const oy = String(r.no.oylar || '').split(/\s+/).map((x) => x.split('×')[0]).concat(r.no.adaylar || []).filter((x) => /^\d{4}$/.test(x) && x[0] === ch && listede(x));
    let y = oy[0] || ''; if (!y && (KARISIK[ch] || '').includes(v[0]) && listede(ch + v.slice(1))) y = ch + v.slice(1); /* 1.6.25: oy adaylarında ilk haneyi çevir */ if (!y && sinif.length && (KARISIK[ch] || '').includes(v[0])) { const o2 = String(r.no.oylar || '').split(/\s+/).map((x) => x.split('×')[0]).filter((x) => /^\d{4}$/.test(x) && (KARISIK[ch] || '').includes(x[0])).map((x) => ch + x.slice(1)).filter((x) => sinif.some((o) => o.no === x)); if (o2.length) y = o2[0]; } /* 1.6.25: listede yoksa listedeki en yakın (tek hane farkı) */ if (!y && sinif.length && (KARISIK[ch] || '').includes(v[0])) { const c = ch + v.slice(1); const yk = sinif.map((o) => String(o.no || '')).filter((x) => x.length === 4 && x[0] === ch && [...x].filter((h, i) => h !== c[i]).length <= 1); if (yk.length === 1) y = yk[0]; }
    if (!y || y === v) return; r.no.okunan = r.no.okunan || v; r.no.deger = y; r.no.guven = Math.min(r.no.guven || 0, P.ESIK - 1); r.no.belirsiz = true;
    r.no.neden = 'ilk hane ' + v[0] + '→' + ch + ' (diğer kâğıtlar ' + ch + ' ile başlıyor; ' + v + ' de olabilir) — kontrol edin'; r.no.adaylar = [...new Set([v, ...(r.no.adaylar || [])])].filter((x) => x !== y); d++;
    if (sinif.length) r.ogr = B.ogrenciEsle(sinif, r.no, r.adSoyad); });
  return d; }
