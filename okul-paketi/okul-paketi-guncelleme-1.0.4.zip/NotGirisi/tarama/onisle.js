/* Telefon fotoğrafı ön işleme (Not Girişi Asistanı 1.4.0). Tamamen yerel; görüntü hiçbir yere gönderilmez.
   Adımlar: sayfa kenarını bul + perspektifi düzelt, (bulunamazsa) eğikliği düzelt, gölge/ışık eşitle, gri + kontrast, ters sayfayı çevir. */
(function (kok) {
  'use strict';
  function gri(img) { var n = img.width * img.height, g = new Float32Array(n), d = img.data; for (var i = 0; i < n; i++) g[i] = 0.299 * d[4 * i] + 0.587 * d[4 * i + 1] + 0.114 * d[4 * i + 2]; return g; }
  function kucult(g, w, h, k) { var W = Math.max(1, Math.round(w * k)), H = Math.max(1, Math.round(h * k)), o = new Float32Array(W * H);
    for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) o[y * W + x] = g[Math.min(h - 1, Math.floor(y / k)) * w + Math.min(w - 1, Math.floor(x / k))]; return { g: o, w: W, h: H }; }
  function otsu(g) { var hs = new Float64Array(256), n = g.length, i; for (i = 0; i < n; i++) hs[Math.max(0, Math.min(255, g[i] | 0))]++;
    var top = 0; for (i = 0; i < 256; i++) top += i * hs[i]; var sB = 0, wB = 0, en = 0, t = 128;
    for (i = 0; i < 256; i++) { wB += hs[i]; if (!wB) continue; var wF = n - wB; if (!wF) break; sB += i * hs[i]; var mB = sB / wB, mF = (top - sB) / wF, v = wB * wF * (mB - mF) * (mB - mF); if (v > en) { en = v; t = i; } } return t; }
  function cozH(src, dst) { // src -> dst eşlemesi (4 nokta)
    var A = [], b = [], i, c, r, k;
    for (i = 0; i < 4; i++) { var x = src[i][0], y = src[i][1], u = dst[i][0], v = dst[i][1]; A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u); A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v); }
    for (c = 0; c < 8; c++) { var p = c; for (r = c + 1; r < 8; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r; var t = A[c]; A[c] = A[p]; A[p] = t; t = b[c]; b[c] = b[p]; b[p] = t;
      if (Math.abs(A[c][c]) < 1e-12) return null;
      for (r = 0; r < 8; r++) if (r !== c) { var f = A[r][c] / A[c][c]; for (k = c; k < 8; k++) A[r][k] -= f * A[c][k]; b[r] -= f * b[c]; } }
    var H = b.map(function (v, i) { return v / A[i][i]; }); H.push(1); return H; }
  function ornek(g, w, h, x, y) { if (x < 0 || y < 0 || x > w - 1.001 || y > h - 1.001) return 255; var ix = x | 0, iy = y | 0, fx = x - ix, fy = y - iy, i = iy * w + ix;
    return g[i] * (1 - fx) * (1 - fy) + g[i + 1] * fx * (1 - fy) + g[i + w] * (1 - fx) * fy + g[i + w + 1] * fx * fy; }
  // Kâğıt: koyu zeminde en büyük açık bölge; dört köşesi
  function sayfaBul(g, w, h) {
    var k = Math.min(1, 360 / Math.max(w, h)), s = kucult(g, w, h, k), t = otsu(s.g), W = s.w, H = s.h, m = new Uint8Array(W * H), i;
    for (i = 0; i < m.length; i++) m[i] = s.g[i] > t ? 1 : 0;
    var lab = new Int32Array(W * H), en = 0, enA = 0, st = new Int32Array(W * H), id = 0;
    for (i = 0; i < m.length; i++) { if (!m[i] || lab[i]) continue; id++; var a = 0, sp = 0; st[sp++] = i; lab[i] = id;
      while (sp) { var q = st[--sp], x = q % W, y = (q / W) | 0; a++;
        if (x > 0 && m[q - 1] && !lab[q - 1]) { lab[q - 1] = id; st[sp++] = q - 1; } if (x < W - 1 && m[q + 1] && !lab[q + 1]) { lab[q + 1] = id; st[sp++] = q + 1; }
        if (y > 0 && m[q - W] && !lab[q - W]) { lab[q - W] = id; st[sp++] = q - W; } if (y < H - 1 && m[q + W] && !lab[q + W]) { lab[q + W] = id; st[sp++] = q + W; } }
      if (a > enA) { enA = a; en = id; } }
    var oran = enA / (W * H); if (oran < 0.2 || oran > 0.96) return null;
    // sınır pikseli kenara değiyorsa (kâğıt kadrajı taşıyor) kırpma yapma
    var kenar = 0, tl, tr, bl, br, a1 = 1e9, a2 = -1e9, b1 = -1e9, b2 = 1e9;
    for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) { if (lab[y * W + x] !== en) continue; if (x === 0 || y === 0 || x === W - 1 || y === H - 1) kenar++;
      var p = x + y, d = x - y; if (p < a1) { a1 = p; tl = [x, y]; } if (p > a2) { a2 = p; br = [x, y]; } if (d > b1) { b1 = d; tr = [x, y]; } if (d < b2) { b2 = d; bl = [x, y]; } }
    if (kenar > 0.25 * (W + H)) return null;
    var Q = [tl, tr, bl, br].map(function (p) { return [(p[0] + 0.5) / k, (p[1] + 0.5) / k]; });
    // dörtgen alanı bölge alanına yakın olmalı (gerçekten dörtgen kâğıt)
    var alan = Math.abs((Q[1][0] - Q[0][0]) * (Q[2][1] - Q[0][1]) - (Q[2][0] - Q[0][0]) * (Q[1][1] - Q[0][1])) / 2 + Math.abs((Q[1][0] - Q[3][0]) * (Q[2][1] - Q[3][1]) - (Q[2][0] - Q[3][0]) * (Q[1][1] - Q[3][1])) / 2;
    if (alan < 0.8 * enA / (k * k) || alan > 1.25 * enA / (k * k)) return null;
    return Q;
  }
  function duzelt(g, w, h, Q, enCok) {
    var d = function (a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1]); }, W = (d(Q[0], Q[1]) + d(Q[2], Q[3])) / 2, H = (d(Q[0], Q[2]) + d(Q[1], Q[3])) / 2, k = Math.min(1.2, enCok / Math.max(W, H));
    W = Math.round(W * k); H = Math.round(H * k); var M = cozH([[0, 0], [W, 0], [0, H], [W, H]], Q); if (!M) return null; var o = new Float32Array(W * H);
    for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) { var u = x + 0.5, v = y + 0.5, z = M[6] * u + M[7] * v + 1; o[y * W + x] = ornek(g, w, h, (M[0] * u + M[1] * v + M[2]) / z - 0.5, (M[3] * u + M[4] * v + M[5]) / z - 0.5); }
    return { g: o, w: W, h: H };
  }
  function dondur(s, aci) { // derece, merkez etrafında
    var r = aci * Math.PI / 180, c = Math.cos(r), sn = Math.sin(r), W = s.w, H = s.h, o = new Float32Array(W * H), cx = W / 2, cy = H / 2;
    for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) { var dx = x - cx, dy = y - cy; o[y * W + x] = ornek(s.g, W, H, c * dx + sn * dy + cx, -sn * dx + c * dy + cy); } return { g: o, w: W, h: H };
  }
  function egiklik(s) { // satır izdüşümü varyansı en büyük açı
    var k = Math.min(1, 500 / Math.max(s.w, s.h)), t = kucult(s.g, s.w, s.h, k), th = otsu(t.g), pts = [];
    for (var y = 0; y < t.h; y++) for (var x = 0; x < t.w; x++) if (t.g[y * t.w + x] < th - 20) pts.push(x - t.w / 2, y - t.h / 2);
    if (pts.length < 200) return 0; var en = 0, enV = -1, D = t.h * 2;
    for (var a = -10; a <= 10.01; a += 0.5) { var r = a * Math.PI / 180, c = Math.cos(r), sn = Math.sin(r), hs = new Float64Array(D * 2);
      for (var i = 0; i < pts.length; i += 2) { var yy = Math.round(-sn * pts[i] + c * pts[i + 1] + D); if (yy >= 0 && yy < D * 2) hs[yy]++; }
      var v = 0; for (i = 0; i < hs.length; i++) v += hs[i] * hs[i]; if (v > enV) { enV = v; en = a; } }
    return Math.abs(en) < 0.4 ? 0 : en;
  }
  // Gölge/ışık eşitleme: kâğıt zeminini blok en büyükleriyle tahmin et, böl
  function isikEsitle(s) {
    var W = s.w, H = s.h, B = Math.max(8, Math.round(Math.max(W, H) / 40)), bw = Math.ceil(W / B), bh = Math.ceil(H / B), z = new Float32Array(bw * bh), i, x, y;
    for (y = 0; y < bh; y++) for (x = 0; x < bw; x++) { var hs = []; for (var yy = y * B; yy < Math.min(H, y * B + B); yy += 2) for (var xx = x * B; xx < Math.min(W, x * B + B); xx += 2) hs.push(s.g[yy * W + xx]);
      hs.sort(function (a, b) { return a - b; }); z[y * bw + x] = hs[Math.floor(hs.length * 0.9)]; }
    var gen = function (a, r) { var o = new Float32Array(a.length); for (var y = 0; y < bh; y++) for (var x = 0; x < bw; x++) { var m = -1; for (var dy = -r; dy <= r; dy++) for (var dx = -r; dx <= r; dx++) { var X = x + dx, Y = y + dy; if (X >= 0 && Y >= 0 && X < bw && Y < bh && a[Y * bw + X] > m) m = a[Y * bw + X]; } o[y * bw + x] = m; } return o; };
    var bul = function (a) { var o = new Float32Array(a.length); for (var y = 0; y < bh; y++) for (var x = 0; x < bw; x++) { var t = 0, n = 0; for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { var X = x + dx, Y = y + dy; if (X >= 0 && Y >= 0 && X < bw && Y < bh) { t += a[Y * bw + X]; n++; } } o[y * bw + x] = t / n; } return o; };
    z = bul(bul(gen(z, 2))); var o = new Float32Array(W * H);
    for (y = 0; y < H; y++) for (x = 0; x < W; x++) { var zx = Math.min(bw - 1.001, Math.max(0, (x + 0.5) / B - 0.5)), zy = Math.min(bh - 1.001, Math.max(0, (y + 0.5) / B - 0.5));
      var zz = bw > 1 && bh > 1 ? ornek(z, bw, bh, zx, zy) : z[0]; o[y * W + x] = Math.min(255, 245 * s.g[y * W + x] / Math.max(30, zz)); }
    // kontrast: koyu uçu 0'a çek
    var srt = []; for (i = 0; i < o.length; i += 7) srt.push(o[i]); srt.sort(function (a, b) { return a - b; }); var lo = srt[Math.floor(srt.length * 0.005)], hi = 245;
    if (lo > 50) { var f = (hi - 30) / (hi - lo); for (i = 0; i < o.length; i++) o[i] = Math.max(0, Math.min(255, hi - (hi - o[i]) * f)); } // soluk mürekkebi koyulaştır, kutu çizgilerini abartma
    // açık gri (kutu çizgisi, gölge kalıntısı) beyaza yaklaşsın; koyu mürekkep olduğu gibi kalsın
    for (i = 0; i < o.length; i++) { var v = o[i]; o[i] = v <= 110 ? v : v >= 190 ? 255 : 110 + (v - 110) * 145 / 80; }
    return { g: o, w: W, h: H };
  }
  // Ana işlev. img: {width,height,data RGBA}. sec: {enCok, isaretBul}
  function onisle(img, sec) {
    sec = sec || {}; var enCok = sec.enCok || 2000, g = gri(img), w = img.width, h = img.height, notlar = [], s;
    var k0 = Math.min(1, (enCok * 1.3) / Math.max(w, h)); if (k0 < 1) { var kk = kucult(g, w, h, k0); g = kk.g; w = kk.w; h = kk.h; }
    var Q = sayfaBul(g, w, h); s = Q ? duzelt(g, w, h, Q, enCok) : null;
    if (s) notlar.push('kenar+perspektif'); else { var k = Math.min(1, enCok / Math.max(w, h)); s = k < 1 ? kucult(g, w, h, k) : { g: g, w: w, h: h }; }
    s = isikEsitle(s); notlar.push('ışık');
    if (!Q) { var a = egiklik(s); if (a) { s = dondur(s, a); notlar.push('eğiklik ' + a.toFixed(1) + '°'); } }
    if (s.w > s.h * 1.15) { s = dondur90(s); notlar.push('90°'); }
    var out = rgba(s);
    if (sec.isaretBul) { var is = sec.isaretBul(out); if (is && (is[0].y + is[1].y) / 2 > out.height / 2) { s = dondur180(s); out = rgba(s); notlar.push('ters çevrildi'); } }
    out.notlar = notlar; return out;
  }
  function dondur90(s) { var W = s.h, H = s.w, o = new Float32Array(W * H); for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) o[y * W + x] = s.g[(s.h - 1 - x) * s.w + y]; return { g: o, w: W, h: H }; }
  function dondur180(s) { var o = new Float32Array(s.g.length); for (var i = 0; i < o.length; i++) o[i] = s.g[o.length - 1 - i]; return { g: o, w: s.w, h: s.h }; }
  function rgba(s) { var d = new Uint8ClampedArray(s.w * s.h * 4); for (var i = 0; i < s.w * s.h; i++) { var v = s.g[i]; d[4 * i] = d[4 * i + 1] = d[4 * i + 2] = v; d[4 * i + 3] = 255; } return { width: s.w, height: s.h, data: d }; }
  var api = { onisle: onisle, sayfaBul: sayfaBul, egiklik: egiklik };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  kok.FotoOnisle = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
