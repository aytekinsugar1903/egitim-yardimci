// Arka plan (MV3 service worker): araç çubuğu simgesi ve sekme açma. Ağ isteği yok; veri işlemez.
const E_OKUL = /^https:\/\/(e-okul|eokul|[^/]+\.e-okul)\.meb\.gov\.tr\//i;
const SAYFALAR = { notoku: 'ice/ice.html', tarama: 'ice/ice.html', ice: 'ice/ice.html', iceOgren: 'ice/ice.html#ogrenilen' }; // 1.9.0 el yazısı okuma kaldırıldı; eski anahtarlar Excel sayfasına gider // 1.7.0 ice: Excel'den not girişi
chrome.action.onClicked.addListener(async (tab) => {
  if (tab && tab.id != null && E_OKUL.test(tab.url || '')) {
    try { await chrome.tabs.sendMessage(tab.id, { tip: 'nga-ac' }, { frameId: 0 }); return; } catch (e) { /* panel yüklenmemiş */ }
  }
  chrome.tabs.create({ url: chrome.runtime.getURL(SAYFALAR.notoku) });
});
// 1.9.20 Sesli not: e-Okul mikrofona izin vermez. 1.9.18 gibi görünür ses-ac penceresi açılır (gizli/offscreen yok).
try { importScripts("../ses/yonet.js"); } catch (e) {}
let sesPencere = null, sesSekme = null, sesKare = null;
function sesHedefYaz(kayit) {
  if (kayit && kayit.tabId != null) sesSekme = kayit.tabId;
  if (kayit && kayit.frameId != null) sesKare = kayit.frameId;
  try { chrome.storage.local.set({ ngaSesHedef: { tabId: sesSekme, frameId: sesKare, z: Date.now() } }); } catch (e) {}
}
function sesPencereAc() {
  const url = chrome.runtime.getURL("ses/ses.html");
  const ac = () => chrome.windows.create({ url: url, type: "popup", width: 480, height: 360, focused: true }, (w) => { sesPencere = w && w.id; });
  if (sesPencere != null) {
    chrome.windows.get(sesPencere, () => {
      if (chrome.runtime.lastError) { sesPencere = null; ac(); }
      else chrome.windows.update(sesPencere, { focused: true });
    });
    return;
  }
  ac();
}
function sesKapa() {
  try { chrome.storage.local.set({ ngaSesKomut: { k: "dur", z: Date.now() } }); } catch (e) {}
  if (sesPencere != null) {
    try { chrome.windows.remove(sesPencere, () => { void chrome.runtime.lastError; }); } catch (e) {}
    sesPencere = null;
  }
}
function sesParcaIlet(paket) {
  const Y = (typeof NGASesYonet !== "undefined") ? NGASesYonet : null;
  const p = Y && Y.sesParcaPaket ? Y.sesParcaPaket(paket) : Object.assign({ tip: "nga-ses-parca" }, paket, { final: paket && paket.final !== false });
  try { chrome.storage.local.set({ ngaSesMetin: p }); } catch (e) {}
  const tabId = sesSekme;
  if (tabId == null) return;
  const kareler = Y && Y.sesKareHedefleri ? Y.sesKareHedefleri({ frameId: sesKare }) : (sesKare != null && sesKare !== 0 ? [sesKare, 0] : [0]);
  const gonder = (frameId, msg) => {
    try { chrome.tabs.sendMessage(tabId, msg, { frameId: frameId }, () => { void chrome.runtime.lastError; }); } catch (e) {}
  };
  if (Y && Y.sesParcaDagit) Y.sesParcaDagit(p, kareler, gonder);
  else kareler.forEach((f) => gonder(f, p));
  try { chrome.tabs.sendMessage(tabId, p, () => { void chrome.runtime.lastError; }); } catch (e) {}
  if (chrome.scripting && chrome.scripting.executeScript) {
    try {
      chrome.scripting.executeScript({
        target: { tabId: tabId, allFrames: true },
        func: (msg) => { try { if (self.NGASes && self.NGASes._hap && self.NGASes._hap.parcaIsle) self.NGASes._hap.parcaIsle(msg); } catch (e) {} },
        args: [p]
      }, () => { void chrome.runtime.lastError; });
    } catch (e) {}
  }
}
chrome.runtime.onMessage.addListener((m, gonderen) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m) return;
  if (m.tip === "ses-ac") {
    const Y = (typeof NGASesYonet !== "undefined") ? NGASesYonet : null;
    const kayit = Y && Y.sesSekmeKaydet ? Y.sesSekmeKaydet(gonderen, m) : { tabId: gonderen.tab && gonderen.tab.id, frameId: gonderen.frameId };
    sesHedefYaz(kayit);
    sesPencereAc();
    return;
  }
  if (m.tip === "ses-kapa") { sesKapa(); return; }
  if (m.tip === "ses-izin-pencere") { sesPencereAc(); return; }
  if (m.tip === "nga-ses-parca") { sesParcaIlet(m); return; }
});

chrome.runtime.onMessage.addListener((m, gonderen) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'sekme-ac' || !SAYFALAR[m.hedef]) return;
  chrome.tabs.create({ url: chrome.runtime.getURL(SAYFALAR[m.hedef]) });
});

function dosyaAdiGuvenli(ad, yedek) {
  let s = String(ad || yedek || 'OYSS.xlsx');
  s = s.replace(/[\\/:*?"<>|]+/g, '_').replace(/[\u0000-\u001f]/g, '');
  s = s.replace(/^.*[\\/]/, '');
  const nokta = s.lastIndexOf('.');
  let taban = nokta > 0 ? s.slice(0, nokta) : s;
  let uzanti = nokta > 0 ? s.slice(nokta) : '.xlsx';
  taban = taban.replace(/[.\s]+$/g, '').replace(/^[.\s]+/g, '') || 'OYSS';
  uzanti = uzanti.replace(/[.\s]+$/g, '') || '.xlsx';
  if (uzanti.charAt(0) !== '.') uzanti = '.' + uzanti;
  return (taban + uzanti).slice(0, 150);
}
function indirYoluGuvenli(ad, yedek) {
  const ham = String(ad || yedek || 'OYSS.xlsx').replace(/[\u0000-\u001f]/g, '').replace(/\\/g, '/');
  const parts = ham.split('/').filter(Boolean);
  const temiz = [];
  for (let i = 0; i < parts.length; i++) {
    if (parts[i] === '.' || parts[i] === '..') continue;
    if (i === parts.length - 1) temiz.push(dosyaAdiGuvenli(parts[i], yedek || 'OYSS.xlsx'));
    else {
      const parca = parts[i].replace(/[\\/:*?"<>|]+/g, '_').replace(/^[.\s]+|[.\s]+$/g, '').slice(0, 80);
      if (parca) temiz.push(parca);
    }
  }
  return (temiz.join('/') || dosyaAdiGuvenli(yedek || 'OYSS.xlsx')).slice(0, 240);
}
function u8b64(u8) {
  let s = '';
  const CH = 0x8000;
  for (let i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
  return btoa(s);
}
const indirGunluk = [];
function gunluk(kayit) {
  indirGunluk.push(Object.assign({ t: new Date().toISOString() }, kayit));
  if (indirGunluk.length > 40) indirGunluk.shift();
  try { chrome.storage.local.set({ ngaOyssIndirGunluk: indirGunluk.slice(-20) }); } catch (e) {}
}

// 1.9.9: şablon uzantı paketinden SW'de okunur. İçerik betimi sayfa kökeninden fetch ederse
// (web_accessible_resources yok) istek chrome-extension://invalid/ olur ve Failed to fetch düşer.
chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'oyss-sablon') return;
  (async () => {
    try {
      const r = await fetch(chrome.runtime.getURL('oyss/OYSS_Soru_Bazli_Not_Sablonu.xlsx'));
      if (!r.ok) throw new Error('şablon HTTP ' + r.status);
      const u8 = new Uint8Array(await r.arrayBuffer());
      gunluk({ adim: 'sablon', ok: true, bayt: u8.length });
      yanit({ ok: true, veri: u8b64(u8), bayt: u8.length });
    } catch (e) {
      const hata = String(e && e.message || e);
      gunluk({ adim: 'sablon', ok: false, hata });
      yanit({ ok: false, hata });
    }
  })();
  return true;
});

// 1.9.4: OYSS Excel/zip indirmesi (içerik betiğindeki a.click kullanıcı jesti bitince sessiz kalabilir)
chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'oyss-indir') return;
  try {
    const tur = String(m.tur || 'application/octet-stream').replace(/[^a-z0-9.+\/-]/gi, '') || 'application/octet-stream';
    const url = 'data:' + tur + ';base64,' + String(m.veri || '');
    const ad = indirYoluGuvenli(m.ad, 'OYSS.xlsx');
    if (!m.veri) {
      const hata = 'indirme verisi boş';
      gunluk({ adim: 'indir', ok: false, ad, hata });
      yanit({ ok: false, hata, ad });
      return true;
    }
    chrome.downloads.download({ url, filename: ad, saveAs: false, conflictAction: 'uniquify' }, (id) => {
      const err = chrome.runtime.lastError && chrome.runtime.lastError.message;
      if (err || !id) {
        gunluk({ adim: 'indir', ok: false, ad, id: id || null, hata: err || 'indirme başlamadı' });
        yanit({ ok: false, hata: err || 'indirme başlamadı', ad, id: id || null });
        return;
      }
      const bitir = () => {
        chrome.downloads.search({ id }, (items) => {
          const it = (items && items[0]) || {};
          const yol = it.filename || '';
          let klasor = '';
          if (yol) {
            const n = Math.max(yol.lastIndexOf('\\'), yol.lastIndexOf('/'));
            klasor = n >= 0 ? yol.slice(0, n) : '';
          }
          gunluk({ adim: 'indir', ok: true, ad, id, yol, klasor });
          yanit({ ok: true, ad, id, yol, klasor });
        });
      };
      const dinle = (delta) => {
        if (delta.id !== id || !delta.state) return;
        if (delta.state.current === 'complete') { chrome.downloads.onChanged.removeListener(dinle); bitir(); }
        else if (delta.state.current === 'interrupted') {
          chrome.downloads.onChanged.removeListener(dinle);
          const hata = (delta.error && delta.error.current) || 'indirme yarıda kesildi';
          gunluk({ adim: 'indir', ok: false, ad, id, hata });
          yanit({ ok: false, hata, ad, id });
        }
      };
      chrome.downloads.onChanged.addListener(dinle);
      chrome.downloads.search({ id }, (items) => {
        if (items && items[0] && items[0].state === 'complete') { chrome.downloads.onChanged.removeListener(dinle); bitir(); }
      });
    });
  } catch (e) {
    const hata = String(e && e.message || e);
    gunluk({ adim: 'indir', ok: false, hata });
    yanit({ ok: false, hata });
  }
  return true;
});

chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'oyss-indir-gunluk') return;
  yanit({ ok: true, gunluk: indirGunluk.slice() });
  return true;
});

chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'oyss-indir-goster' || !m.id) return;
  try { chrome.downloads.show(+m.id); yanit({ ok: true }); }
  catch (e) { yanit({ ok: false, hata: String(e && e.message || e) }); }
  return true;
});

chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== 'oyss-indir-ac' || !m.id) return;
  try {
    chrome.downloads.open(+m.id);
    const err = chrome.runtime.lastError && chrome.runtime.lastError.message;
    yanit({ ok: !err, hata: err || '' });
  } catch (e) { yanit({ ok: false, hata: String(e && e.message || e) }); }
  return true;
});
