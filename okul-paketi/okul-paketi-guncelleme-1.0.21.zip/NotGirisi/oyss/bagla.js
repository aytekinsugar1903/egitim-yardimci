// 1.9.4: OYSS ayrı panel bağlacı. Ders notu kontrollerini (nga-ders, otomatik Listele, sütun) kullanmaz.
(function (kok) {
  'use strict';
  const oyssHTML = () => `<div id="nga-oyss-kok">
     <p style="color:#333;font-size:12px;margin:4px 0">Bu sekme yalnız <b>OYSS Not Girişi</b> (OOK10020) içindir; ders notu girişi ile karışmaz. Kutucuklarla sınıf, ders ve şubeyi işaretleyin; <b>İşaretlileri indir</b> listeyi okur ve Excel'i tek adımda kaydeder (ayrı bir "çek" gerekmez). Sınav: sayfada seçtiğiniz sınav (yoksa ilk <b>(OYSS Yazılı Sınav (Asıl))</b>). <b>Şube sınav durumu</b> ve <b>Kapat</b> düğmesine dokunulmaz. Güvenlik Koduna dokunulmaz.</p>
     <p style="font-size:12px;margin:8px 0 4px"><b>Hızlı seçim</b> — çoklu kutucuk. Yalnız OYSS sınıfları (5-6-7, 9-10-11) ve kılavuz dersleri. Dosyalar Chrome İndirilenler altında <b>Not Girisi/OYSS/tarih/</b> klasörüne iner.</p>
     <p style="font-size:12px;margin:4px 0"><b>1. Sınıf</b> <label><input type="checkbox" id="nga-oyss-sinif-hepsi"> Tümünü seç</label></p>
     <div id="nga-oyss-siniflar" style="font-size:12px;margin:0 0 6px"></div>
     <p style="font-size:12px;margin:4px 0"><b>2. Ders</b> <label><input type="checkbox" id="nga-oyss-ders-hepsi"> Tümünü seç</label></p>
     <div id="nga-oyss-dersler" style="font-size:12px;margin:0 0 6px;max-height:140px;overflow:auto;border:1px solid #eee;padding:4px 6px">Önce sınıf seçin</div>
     <p style="font-size:12px;margin:4px 0"><b>3. Şube</b> <label><input type="checkbox" id="nga-oyss-sube-kutu-hepsi"> Tümünü seç</label>
       <button type="button" id="nga-oyss-sube-oku">Şubeleri yenile</button>
       <input id="nga-oyss-sube-yaz" type="text" placeholder="veya yazın" style="width:7em" autocomplete="off">
     </p>
     <div id="nga-oyss-sube-kutulari" style="font-size:12px;margin:0 0 6px;max-height:140px;overflow:auto;border:1px solid #eee;padding:4px 6px">Önce sınıf seçin</div>
     <p style="font-size:12px;margin:4px 0">
       <button type="button" id="nga-oyss-hizli-aktar">İşaretlileri indir</button>
       <button type="button" id="nga-oyss-hepsi-indir">Hepsini seç ve indir</button>
       <button type="button" id="nga-oyss-hizli-ac">Ses için şubeyi aç</button>
     </p>
     <div id="nga-oyss-ses-kutu" style="margin:8px 0;padding:8px;border:1px solid #ddd;background:#fff">
       <p style="font-size:12px;margin:0 0 4px"><b>Sesli soru puanı</b> (isteğe bağlı)</p>
       <p style="font-size:11px;margin:0 0 6px;color:#555">Mikrofonu siz açarsınız (sayfanın altındaki hap panelinden Başlat). Puanlar hemen hücrelere yazılır; "onaylıyorum" beklenmez. "bitti" öğrenciyi bitirir, "iptal" seçimi kaldırır. Chrome ses tanımayı Google'a gönderir; öğrenci verisi eklenti sunucusuna gitmez. Sesle Kaydet'e basılmaz. Güvenlik Koduna dokunulmaz.</p>
       <label style="font-size:11px;display:block;margin:0 0 6px"><input type="checkbox" id="nga-oyss-ses-onay"> Anladım, ses tanımanın Google'a gittiğini kabul ediyorum.</label>
       <button type="button" id="nga-oyss-ses">🎤 Mikrofonu aç</button>
       <p id="nga-oyss-ses-hedef" style="font-size:12px;margin:4px 0;padding:4px 6px;background:#fff3e0;border:1px solid #ffcc80"><b>Hedef:</b> (henüz yok)</p>
       <p id="nga-oyss-aktif-baglam" style="font-size:12px;margin:4px 0;padding:4px 6px;background:#eef6ff;border:1px solid #c5daf0"><b>Aktif bağlam:</b> (yok — açık OYSS listesi varsa o kullanılır; yoksa sınıf, şube ve dersi söyleyin)</p>
       <p class="not" id="nga-oyss-ses-durum" style="font-size:12px;margin:4px 0">Örnek: "elli beş, soru bir on, dört, on bir, soru sekiz on beş, bitti". Puan hemen yazılır (onaylıyorum gerekmez). Azami puan aşılırsa yazılmaz.</p>
       <pre id="nga-oyss-ses-onizleme" style="white-space:pre-wrap;font:11px/1.35 sans-serif;background:#f7f7f7;border:1px solid #ddd;padding:6px;min-height:2em"></pre>
       <div id="nga-oyss-ses-kayitlar" style="font-size:12px;margin:4px 0;max-height:180px;overflow:auto;border:1px solid #eee;padding:4px 6px;background:#fafafa">Henüz öğrenci kaydı yok.</div>
       <button type="button" id="nga-oyss-ses-onayla" hidden>Onayla ve yaz</button>
       <button type="button" id="nga-oyss-ses-vazgec" hidden>Vazgeç</button>
     </div>
     <details id="nga-oyss-tum-kutu" style="margin:8px 0">
       <summary style="font-size:12px;cursor:pointer"><b>Tüm okulu tara</b> (eski yol, uzun sürer)</summary>
       <p style="font-size:12px;margin:8px 0 4px">Şubeleri seçin; her şube için sınıf listesi <b>bir kez</b> çekilir (dersler dolaşılmaz). Excel'de o düzeyin OYSS dersleri ayrı sayfa olarak, aynı öğrenci listesi ve 1–15. soru sütunlarıyla hazırlanır.</p>
       <p style="font-size:12px;margin:4px 0"><b>Şube listesi</b> <button type="button" id="nga-oyss-sube-yenile">Sayfadan oku</button>
         <label><input type="checkbox" id="nga-oyss-sube-hepsi" checked> Tümü</label>
         <label title="2026-2027: ortaokul 5-6-7 ve lise 9-10-11; yalnız kılavuzdaki dersler. Kapsam dışı şube ve derslere gidilmez."><input type="checkbox" id="nga-oyss-kapsam" checked> Yalnız OYSS kapsamı</label></p>
       <p class="not" id="nga-oyss-kapsam-not" style="font-size:11px;margin:2px 0;color:#555"></p>
       <div id="nga-oyss-subeler" style="max-height:160px;overflow:auto;border:1px solid #ddd;padding:4px 6px;font-size:12px;background:#fff"></div>
       <p style="font-size:12px;margin:8px 0 4px">Dersler Excel'de hazırlanır — bu yolda sayfadan ders seçmeniz gerekmez. Lise 9–11: TDE, Matematik, Fizik, Kimya, Biyoloji, Tarih, Coğrafya, Din Kültürü ve Ahlak Bilgisi, Felsefe, İngilizce. Ortaokul 5–7: Türkçe, Matematik, Fen Bilimleri, Sosyal Bilgiler, Din Kültürü ve Ahlak Bilgisi, İngilizce. Her ders sayfasında soru 1–15 ve Katılım (5 seçenek) hazırdır. Sınav: sayfada önceden seçtiğiniz sınav her şubede aynen seçilir.</p>
       <button type="button" id="nga-oyss-tum">Tüm okulu tara</button>
     </details>
     <p style="font-size:12px;margin:4px 0">Çıktı
       <label><input type="radio" name="ngaOyssCikti" id="nga-oyss-cikti-zip" value="zip" checked> Ayrı dosyalar (zip)</label>
       <label><input type="radio" name="ngaOyssCikti" id="nga-oyss-cikti-kitap" value="kitap"> Tek çalışma kitabı</label>
     </p>
     <button type="button" id="nga-oyss-aktar">Bu ekrandaki listeyi yeniden indir</button>
     <button type="button" id="nga-oyss-iptal" hidden>İptal</button>
     <button type="button" id="nga-oyss-yukle">Excel yükle</button> <span style="font-size:11px;color:#555">(bir veya birden çok dosya)</span>
     <input id="nga-oyss-dosya" type="file" accept=".xlsx,.zip" multiple hidden>
     <button type="button" id="nga-oyss-yaz">e-Okul'a yaz ve Kaydet</button>
     <button type="button" id="nga-oyss-tani" title="Öğrenci verisi olmadan sayfa yapısını panoya kopyalar.">Tanı raporu</button>
     <button type="button" id="nga-oyss-testindir" title="Küçük bir deneme xlsx indirerek indirme yolunu sınar.">Test indirme</button>
     <p style="font-size:12px;margin:4px 0"><label>Hız <select id="nga-oyss-hiz"><option value="normal">Normal</option><option value="hizli" selected>Hızlı</option><option value="cokhizli">Çok hızlı</option></select></label></p>
     <p class="not" id="nga-oyss-durum" style="font-size:12px;margin:4px 0">Liste henüz çekilmedi.</p>
     <pre id="nga-oyss-rapor" style="white-space:pre-wrap;font:11px/1.35 sans-serif;background:#f7f7f7;border:1px solid #ddd;padding:6px;max-height:140px;overflow:auto"></pre>
     <p id="nga-oyss-son-indir" style="font-size:12px;margin:6px 0" hidden></p>
     <div id="nga-oyss-excel-kutu" style="margin:8px 0;padding:8px;border:1px solid #ddd;background:#fff" hidden>
       <p style="font-size:12px;margin:0 0 4px"><b>Excel önizleme</b> <span id="nga-oyss-excel-ad" style="color:#555"></span></p>
       <div id="nga-oyss-excel-tablo" style="max-height:180px;overflow:auto;font-size:11px"></div>
       <p style="font-size:11px;margin:4px 0">Sesle puanlar önizlemeye hemen yazılır. "e-Okul'a yaz" açık OYSS tablosuna işler (Kaydet'e basılmaz) ve sesli Excel'i aynı klasöre kaydeder. "Yeni Excel olarak kaydet" orijinali bozmaz.</p>
       <button type="button" id="nga-oyss-excel-eokul-yaz">e-Okul'a yaz</button>
       <button type="button" id="nga-oyss-excel-kaydet">Yeni Excel olarak kaydet</button>
     </div>
     <div id="nga-oyss-indir-liste-kutu" style="margin:8px 0">
       <p style="font-size:12px;margin:0 0 4px"><b>İndirilen dosyalar</b> (yalnız ad/yol/sınıf-şube-ders; öğrenci verisi yok)
         <button type="button" id="nga-oyss-indir-temizle">Listeyi temizle</button></p>
       <div id="nga-oyss-indir-liste" style="font-size:12px;max-height:160px;overflow:auto;border:1px solid #ddd;padding:4px 6px;background:#fff"></div>
     </div>
  </div>`;
  function bagla(p, $) {
    if (!p || typeof OyssNot === 'undefined') return;
    const durum = $('nga-oyss-durum'), rapor = $('nga-oyss-rapor'), dosya = $('nga-oyss-dosya'), hizSel = $('nga-oyss-hiz');
    if (!durum || !dosya) return;
    let iceOzet = null;
    let gruplar = null, iptal = false;
    const yazDurum = (t, r, hata) => {
      durum.textContent = t;
      durum.style.color = hata ? '#b00020' : '';
      durum.style.fontWeight = hata ? '700' : '';
      if (rapor) {
        rapor.textContent = r || '';
        rapor.style.background = hata ? '#fdecea' : '#f7f7f7';
        rapor.style.borderColor = hata ? '#b00020' : '#ddd';
        rapor.style.color = hata ? '#7a1020' : '';
      }
    };
    async function sablonAl() {
      // 1.9.9: şablon SW'den okunur. Sayfadan fetch(chrome.runtime.getURL) → chrome-extension://invalid/ / Failed to fetch.
      if (!chrome.runtime || !chrome.runtime.sendMessage) throw new Error('chrome.runtime.sendMessage yok; şablon alınamadı.');
      const r = await chrome.runtime.sendMessage({ tip: 'oyss-sablon' });
      if (!r || !r.ok) throw new Error('OYSS şablonu alınamadı: ' + ((r && r.hata) || 'service worker yanıt vermedi'));
      const bin = Uint8Array.from(atob(r.veri), (c) => c.charCodeAt(0));
      return bin.buffer;
    }
    async function indir(ad, buf, tur, meta) {
      const yol = (ad && String(ad).indexOf("/") >= 0) ? ad : OyssNot.indirYolu(ad);
      const r = await OyssNot.dosyaIndir(yol, buf, tur);
      const ok = r === true || (r && r.ok);
      if (!ok) {
        const h = (r && r.hata) || ("İndirme başlatılamadı: " + yol);
        yazDurum("İndirme başarısız: " + h, (r && r.yol) || h, true);
        throw new Error(h);
      }
      const kayit = Object.assign({}, meta || {}, (r && typeof r === "object") ? r : { ok: true, ad: yol });
      indirListeyeEkle(kayit);
      gosterSonIndirme(kayit);
      return kayit;
    }
    function ozetGruplar(g) {
      return (g || []).map((x) => (x.sube || "—") + " / " + (x.ders || "—") + " · " + (x.ogrenciler || []).length + " öğrenci · " + (x.soruSayisi || 0) + " soru").join("\n");
    }
    function hataOzet(sonuc) {
      return (sonuc.hatalar || []).concat(sonuc.atlanan || []).map((x) => "• " + x).join("\n");
    }
    const depo = (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) || null;
    if (depo) depo.get("ngaOyssHiz", (v) => { if (hizSel) hizSel.value = v.ngaOyssHiz || "hizli"; });
    if (hizSel) hizSel.onchange = () => { if (depo) depo.set({ ngaOyssHiz: hizSel.value }); };
    function kac(s) { return String(s || "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c])); }
    function listeDoldur() {
      const kutu = $("nga-oyss-subeler");
      if (!kutu) return;
      const once = [...kutu.querySelectorAll("input[data-oyss-sube]")].filter((c) => c.checked).map((c) => c.value);
      const hepsi = $("nga-oyss-sube-hepsi") && $("nga-oyss-sube-hepsi").checked;
      const kapsam = yalnizOyss();
      const tumSube = OyssNot.subeListesi(window);
      const subeler = kapsam ? tumSube.filter((s) => OyssNot.oyssSubeMi(s.text)) : tumSube;
      const notEl = $("nga-oyss-kapsam-not");
      if (notEl) notEl.textContent = kapsam ? ("OYSS kapsamı: ortaokul 5-6-7, lise 9-10-11 ve kılavuzdaki dersler." + (tumSube.length > subeler.length ? " Kapsam dışı " + (tumSube.length - subeler.length) + " şube gizlendi." : "")) : "";
      if (!subeler.length) { kutu.textContent = tumSube.length ? "Bu listede OYSS kapsamında şube yok (5-6-7 / 9-10-11)." : "Şube listesi sayfada bulunamadı. OYSS Not Girişi (OOK10020) ekranında mısınız?"; return; }
      kutu.innerHTML = subeler.map((s) => {
        const v = String(s.index);
        const sec = hepsi || !once.length || once.includes(v);
        return '<label style="display:block"><input type="checkbox" data-oyss-sube="1" value="' + v + '"' + (sec ? " checked" : "") + "> " + kac(s.text) + "</label>";
      }).join("");
    }
    function yalnizOyss() { const c = $("nga-oyss-kapsam"); return !c || c.checked; }
    function secilenSubeler() {
      const kutu = $("nga-oyss-subeler");
      const isaret = [...(kutu ? kutu.querySelectorAll("input[data-oyss-sube]") : [])].filter((c) => c.checked).map((c) => +c.value);
      return OyssNot.subeListesi(window).filter((s) => isaret.includes(s.index));
    }
    async function kvkkOk() {
      if (!depo) return true;
      return new Promise((r) => depo.get("ngaKvkkOnay", (v) => r(!!v.ngaKvkkOnay)));
    }
    async function aktarGruplar(liste, tekAd) {
      if (!liste || !liste.length) throw new Error("Aktarılacak öğrenci listesi yok.");
      const sayfalar = OyssNot.gruplariDersSayfalarina(liste);
      if (!sayfalar.length) throw new Error("Aktarılacak ders sayfası yok.");
      const sablon = await sablonAl();
      const kitap = p.querySelector("#nga-oyss-cikti-kitap") && p.querySelector("#nga-oyss-cikti-kitap").checked;
      const subeSay = new Set(sayfalar.map((g) => OyssNot.katla(g.sube))).size;
      if (kitap) {
        const out = await OyssNot.sablonCokluKitap(sablon, sayfalar);
        const ad = tekAd || "OYSS_Tum_Subeler.xlsx";
        await indir(OyssNot.indirYolu(ad), out, null, { ad, ders: "çoklu", sube: sayfalar[0] && sayfalar[0].sube });
        return subeSay + " şube, " + sayfalar.length + " ders sayfası tek çalışma kitabına yazıldı ve indirildi.";
      }
      if (subeSay === 1 && !tekAd) {
        const indirilenAd = [];
        for (const g of sayfalar) {
          const ad = OyssNot.dosyaAdiKisa(OyssNot.sinifDuzeyi(g.sube), g.sube, g.ders);
          const out = await OyssNot.sablonCokluKitap(sablon, [g]);
          await indir(OyssNot.indirYolu(ad), out, null, { sinif: OyssNot.sinifDuzeyi(g.sube), sube: g.sube, harf: OyssNot.subeHarfOku(g.sube), ders: g.ders, grup: g, buf: out });
          indirilenAd.push(ad);
        }
        return "1 şube, " + sayfalar.length + " ders dosyası indirildi: " + indirilenAd.join(", ");
      }
      if (subeSay === 1) {
        const out = await OyssNot.sablonCokluKitap(sablon, sayfalar);
        const ad = tekAd || OyssNot.dosyaAdiSube(sayfalar[0]);
        await indir(OyssNot.indirYolu(ad), out, null, { ad, sube: sayfalar[0].sube, ders: sayfalar[0].ders, grup: sayfalar[0], buf: out });
        return "1 şube, " + sayfalar.length + " ders sayfası indirildi: " + ad;
      }
      const z = await OyssNot.sablonCokluZip(sablon, sayfalar);
      await indir(OyssNot.indirYolu("OYSS_Subeler.zip"), z.zip, "application/zip", { ad: "OYSS_Subeler.zip" });
      return z.dosyalar.length + " şube dosyası zip içinde indirildi: " + z.dosyalar.join(", ");
    }
    const btnAktar = $("nga-oyss-aktar"), btnTum = $("nga-oyss-tum"), btnIptal = $("nga-oyss-iptal"), btnYukle = $("nga-oyss-yukle"), btnYaz = $("nga-oyss-yaz"), btnTani = $("nga-oyss-tani"), btnTest = $("nga-oyss-testindir");
    if ($("nga-oyss-sube-yenile")) $("nga-oyss-sube-yenile").onclick = () => { listeDoldur(); yazDurum("Şube listesi sayfadan okundu (" + OyssNot.subeListesi(window).length + " şube)."); };
    if ($("nga-oyss-sube-hepsi")) $("nga-oyss-sube-hepsi").onchange = (e) => {
      const kutu = $("nga-oyss-subeler");
      if (kutu) kutu.querySelectorAll("input[data-oyss-sube]").forEach((c) => { c.checked = e.target.checked; });
    };
    if ($("nga-oyss-kapsam")) {
      if (depo) depo.get("ngaOyssKapsam", (v) => { if (v.ngaOyssKapsam === false) { $("nga-oyss-kapsam").checked = false; listeDoldur(); } });
      $("nga-oyss-kapsam").onchange = () => { if (depo) depo.set({ ngaOyssKapsam: $("nga-oyss-kapsam").checked }); listeDoldur(); };
    }
    listeDoldur();

    let oyssSecim = { siniflar: [], dersler: [], subeler: [] };
    let ogrenilenSubeler = [];
    const SINIFLAR = (OyssNot.OYSS_SINIF_SECIM || [5, 6, 7, 9, 10, 11]).map(String);
    const subeYaz = $("nga-oyss-sube-yaz");
    function secimiSakla() {
      if (!depo) return;
      depo.set({ ngaOyssHizliSecim: { siniflar: oyssSecim.siniflar.slice(), dersler: oyssSecim.dersler.slice(), subeler: oyssSecim.subeler.slice() } });
    }
    function subeOnbellekSakla() {
      if (!depo) return;
      depo.set({ ngaOyssSubeOnbellek: { z: Date.now(), ops: ogrenilenSubeler.map((s) => ({ text: s.text || "", value: s.value || "", sinif: s.sinif == null ? "" : s.sinif, harf: s.harf || "", alan: s.alan || "" })) } });
    }
    function ogrenSubelerHizli() {
      const canli = OyssNot.subeleriOku(window, { yalnizOyss: true });
      if (canli && canli.length) {
        ogrenilenSubeler = canli;
        subeOnbellekSakla();
      }
      return ogrenilenSubeler;
    }
    function isaretli(arr, v) { return (arr || []).indexOf(v) >= 0; }
    function kutuDegis(arr, v, on) {
      const i = arr.indexOf(v);
      if (on && i < 0) arr.push(v);
      if (!on && i >= 0) arr.splice(i, 1);
    }
    function sinifDersSubeTemizle(n) {
      const s = String(n);
      oyssSecim.dersler = oyssSecim.dersler.filter((k) => String(k).split("|")[0] !== s);
      oyssSecim.subeler = oyssSecim.subeler.filter((k) => String(k).split("|")[0] !== s);
    }
    function sinifKutulariCiz() {
      const k = $("nga-oyss-siniflar"); if (!k) return;
      k.innerHTML = SINIFLAR.map((n) => '<label style="display:inline-block;margin:0 8px 2px 0"><input type="checkbox" data-oyss-sinif="' + n + '"' + (isaretli(oyssSecim.siniflar, n) ? " checked" : "") + "> " + n + "</label>").join("");
      k.querySelectorAll("input[data-oyss-sinif]").forEach((c) => { c.onchange = () => { const n = c.getAttribute("data-oyss-sinif"); kutuDegis(oyssSecim.siniflar, n, c.checked); if (!c.checked) sinifDersSubeTemizle(n); secimiSakla(); dersleriDoldur(); subeleriDoldurHizli(); hepsiDurum(); }; });
      const hepsi = $("nga-oyss-sinif-hepsi");
      if (hepsi) { hepsi.checked = SINIFLAR.every((n) => isaretli(oyssSecim.siniflar, n)); hepsi.onchange = () => { if (!hepsi.checked) SINIFLAR.forEach(sinifDersSubeTemizle); oyssSecim.siniflar = hepsi.checked ? SINIFLAR.slice() : []; secimiSakla(); dersleriDoldur(); subeleriDoldurHizli(); hepsiDurum(); sinifKutulariCiz(); }; }
    }
    function dersleriDoldur() {
      const k = $("nga-oyss-dersler"); if (!k) return;
      const siniflar = oyssSecim.siniflar;
      if (!siniflar.length) { k.textContent = "Önce sınıf seçin"; return; }
      const blok = siniflar.map((n) => {
        const liste = OyssNot.oyssDersAdlariDuzey(n);
        return "<div style=\"margin:0 0 4px\"><b>" + n + ". sınıf</b> " + liste.map((d) => {
          const key = n + "|" + d;
          return '<label style="display:inline-block;margin:0 8px 2px 0"><input type="checkbox" data-oyss-ders="' + kac(key) + '"' + (isaretli(oyssSecim.dersler, key) ? " checked" : "") + "> " + kac(d) + "</label>";
        }).join("") + "</div>";
      }).join("");
      k.innerHTML = blok;
      k.querySelectorAll("input[data-oyss-ders]").forEach((c) => { c.onchange = () => { kutuDegis(oyssSecim.dersler, c.getAttribute("data-oyss-ders"), c.checked); secimiSakla(); hepsiDurum(); }; });
    }
    function gorunenSubeKaynagi() {
      const canli = OyssNot.subeleriOku(window, { yalnizOyss: true });
      if (canli && canli.length) {
        ogrenilenSubeler = canli;
        subeOnbellekSakla();
        return canli;
      }
      return ogrenilenSubeler.slice();
    }
    function subeleriDoldurHizli() {
      const k = $("nga-oyss-sube-kutulari"); if (!k) return;
      const kaynak = gorunenSubeKaynagi();
      const siniflar = oyssSecim.siniflar;
      let goster = kaynak;
      if (siniflar.length) goster = kaynak.filter((s) => siniflar.indexOf(String(s.sinif)) >= 0);
      if (!goster.length) {
        k.textContent = kaynak.length ? "Seçilen sınıfların şubesi listede yok. Şubeleri yenile ile tekrar okuyun." : "Şube listesi henüz okunamadı. OYSS ekranındaysanız Şubeleri yenile’ye basın.";
        return;
      }
      const sir = {}, gruplar = [];
      goster.forEach((s) => {
        const n = String(s.sinif != null && s.sinif !== "" ? s.sinif : "");
        if (!sir[n]) { sir[n] = []; gruplar.push(n); }
        sir[n].push(s);
      });
      k.innerHTML = gruplar.map((n) => {
        return "<div style=\"margin:0 0 4px\"><b>" + kac(n ? (n + ". sınıf") : "Diğer") + "</b> " + sir[n].map((x) => {
          const key = OyssNot.subeAnahtar(x);
          const et = OyssNot.subeEtiket(x) || x.text || "";
          const ekstra = (x.text && et && OyssNot.katla(et) !== OyssNot.katla(x.text)) ? ' <span style="color:#555">' + kac(x.text) + "</span>" : "";
          return '<label style="display:block"><input type="checkbox" data-oyss-sube-kutu="' + kac(key) + '" data-text="' + kac(x.text || "") + '" data-value="' + kac(x.value || "") + '" data-sinif="' + kac(n) + '" data-harf="' + kac(x.harf || "") + '" data-alan="' + kac(x.alan || "") + '"' + (isaretli(oyssSecim.subeler, key) ? " checked" : "") + "> " + kac(et) + ekstra + "</label>";
        }).join("") + "</div>";
      }).join("");
      k.querySelectorAll("input[data-oyss-sube-kutu]").forEach((c) => { c.onchange = () => { kutuDegis(oyssSecim.subeler, c.getAttribute("data-oyss-sube-kutu"), c.checked); const n = c.getAttribute("data-sinif"); if (c.checked && n && oyssSecim.siniflar.indexOf(n) < 0) { oyssSecim.siniflar.push(n); sinifKutulariCiz(); dersleriDoldur(); } secimiSakla(); hepsiDurum(); }; });
      if (subeYaz && subeYaz.value.trim()) {
        const yaz = subeYaz.value.trim();
        goster.forEach((x) => {
          const key = OyssNot.subeAnahtar(x);
          if (!isaretli(oyssSecim.subeler, key) && OyssNot.subeHedefBul([x], x.sinif, yaz)) oyssSecim.subeler.push(key);
        });
        k.querySelectorAll("input[data-oyss-sube-kutu]").forEach((c) => { c.checked = isaretli(oyssSecim.subeler, c.getAttribute("data-oyss-sube-kutu")); });
      }
    }
    function hepsiDurum() {
      const hd = $("nga-oyss-ders-hepsi");
      if (hd) {
        const kutular = [...($("nga-oyss-dersler") ? $("nga-oyss-dersler").querySelectorAll("input[data-oyss-ders]") : [])];
        hd.checked = kutular.length && kutular.every((c) => c.checked);
      }
      const hs = $("nga-oyss-sube-kutu-hepsi");
      if (hs) {
        const kutular = [...($("nga-oyss-sube-kutulari") ? $("nga-oyss-sube-kutulari").querySelectorAll("input[data-oyss-sube-kutu]") : [])];
        hs.checked = kutular.length && kutular.every((c) => c.checked);
      }
    }
    function tumDersleriSec(on) {
      oyssSecim.dersler = [];
      if (on) oyssSecim.siniflar.forEach((n) => { (OyssNot.oyssDersAdlariDuzey(n) || []).forEach((d) => oyssSecim.dersler.push(n + "|" + d)); });
      dersleriDoldur(); secimiSakla(); hepsiDurum();
    }
    function tumSubeleriSec(on) {
      oyssSecim.subeler = [];
      if (on) {
        $("nga-oyss-sube-kutulari") && $("nga-oyss-sube-kutulari").querySelectorAll("input[data-oyss-sube-kutu]").forEach((c) => oyssSecim.subeler.push(c.getAttribute("data-oyss-sube-kutu")));
      }
      subeleriDoldurHizli(); secimiSakla(); hepsiDurum();
    }
    function isaretliSubeler() {
      const k = $("nga-oyss-sube-kutulari");
      return [...(k ? k.querySelectorAll("input[data-oyss-sube-kutu]:checked") : [])].map((c) => ({
        key: c.getAttribute("data-oyss-sube-kutu") || "",
        text: c.getAttribute("data-text") || "",
        value: c.getAttribute("data-value") || "",
        sinif: Number(c.getAttribute("data-sinif")),
        harf: c.getAttribute("data-harf") || "",
        alan: c.getAttribute("data-alan") || "",
      }));
    }
    function isaretliDersler() {
      const k = $("nga-oyss-dersler");
      return [...(k ? k.querySelectorAll("input[data-oyss-ders]:checked") : [])].map((c) => {
        const key = c.getAttribute("data-oyss-ders") || "";
        const i = key.indexOf("|");
        return { key, sinif: Number(key.slice(0, i)), ders: key.slice(i + 1) };
      });
    }
    function secilenKombinasyonlar() {
      const subeler = isaretliSubeler();
      const dersler = isaretliDersler();
      const kombo = OyssNot.oyssSecimKombinasyonlari({ subeler, dersler });
      return kombo.map((k) => {
        const su = subeler.find((s) => s.key && k.key ? s.key === k.key : (Number(s.sinif) === Number(k.sinif) && OyssNot.katla(s.harf) === OyssNot.katla(k.harf) && OyssNot.katla(s.alan || "") === OyssNot.katla(k.alan || "")));
        return Object.assign({}, k, { hedef: su ? { text: su.text, value: su.value, sinif: su.sinif, harf: su.harf, alan: su.alan } : null });
      });
    }
    if ($("nga-oyss-ders-hepsi")) $("nga-oyss-ders-hepsi").onchange = (e) => tumDersleriSec(e.target.checked);
    if ($("nga-oyss-sube-kutu-hepsi")) $("nga-oyss-sube-kutu-hepsi").onchange = (e) => tumSubeleriSec(e.target.checked);
    if ($("nga-oyss-sube-oku")) $("nga-oyss-sube-oku").onclick = () => {
      const n = ogrenSubelerHizli().length;
      subeleriDoldurHizli();
      yazDurum(n ? ("Şubeler sayfadan okundu (" + n + " şube). Yalnız işaretledikleriniz işlenir.") : "Şube açılır listesi boş veya henüz yüklenmedi. OYSS ekranında biraz bekleyip tekrar deneyin.", "", !n);
    };
    if (subeYaz) subeYaz.onchange = () => { subeleriDoldurHizli(); secimiSakla(); };
    ogrenSubelerHizli();
    sinifKutulariCiz(); dersleriDoldur(); subeleriDoldurHizli();
    if (depo) depo.get(["ngaOyssHizliSecim", "ngaOyssSubeOnbellek"], (v) => {
      const onb = v && v.ngaOyssSubeOnbellek;
      if ((!ogrenilenSubeler || !ogrenilenSubeler.length) && onb && Array.isArray(onb.ops) && onb.ops.length) {
        ogrenilenSubeler = onb.ops.slice();
      }
      ogrenSubelerHizli();
      const y = OyssNot.hizliSecimYukle(v && v.ngaOyssHizliSecim);
      oyssSecim.siniflar = y.siniflar.slice();
      oyssSecim.dersler = y.dersler.slice();
      const anahtarlar = new Set(ogrenilenSubeler.map((s) => OyssNot.subeAnahtar(s)));
      oyssSecim.subeler = y.subeler.filter((k) => anahtarlar.has(k));
      secimiSakla();
      sinifKutulariCiz(); dersleriDoldur(); subeleriDoldurHizli(); hepsiDurum();
    });

    const oturumDosyalar = [];
    let excelOturum = null, indirListe = [];
    function gosterSonIndirme(r) {
      const el = $("nga-oyss-son-indir"); if (!el) return;
      el.hidden = false;
      const yol = (r && (r.yol || r.ad)) || "";
      const klasor = (r && r.klasor) || "Not Girisi/OYSS/";
      el.innerHTML = "İndirildi: <b>" + kac((r && r.ad) || yol) + "</b> — " + kac(yol || ("Chrome İndirilenler / " + klasor)) +
        (r && r.id ? ' <a href="#" id="nga-oyss-klasor-goster">Klasörü göster</a>' : "");
      const a = $("nga-oyss-klasor-goster");
      if (a && r && r.id) a.onclick = (e) => { e.preventDefault(); try { chrome.runtime.sendMessage({ tip: "oyss-indir-goster", id: r.id }); } catch (err) {} };
    }
    function indirListeyeEkle(r) {
      if (!r) return;
      const kayit = {
        id: r.id || 0, ad: r.ad || "", yol: r.yol || "", klasor: r.klasor || "",
        sinif: r.sinif || "", sube: r.sube || "", harf: r.harf || (r.sube ? OyssNot.subeHarfOku(r.sube) : ""),
        ders: r.ders || "", tarih: OyssNot.yerelTarihISO(), z: Date.now()
      };
      indirListe = [kayit].concat(indirListe.filter((x) => !(x.ad === kayit.ad && x.yol === kayit.yol))).slice(0, 80);
      if (r.grup && r.buf) oturumDosyalar.unshift({ sinif: kayit.sinif, harf: kayit.harf, ders: kayit.ders, ad: kayit.ad, yol: kayit.yol, id: kayit.id, grup: r.grup, buf: r.buf });
      if (depo) depo.set({ ngaOyssIndirilenler: indirListe.map((x) => ({ id: x.id, ad: x.ad, yol: x.yol, klasor: x.klasor, sinif: x.sinif, sube: x.sube, harf: x.harf, ders: x.ders, tarih: x.tarih, z: x.z })) });
      indirListeCiz();
    }
    function indirListeCiz() {
      const k = $("nga-oyss-indir-liste"); if (!k) return;
      if (!indirListe.length) { k.textContent = "Henüz indirilen dosya yok."; return; }
      k.innerHTML = indirListe.map((x, i) => {
        const et = [x.sinif && x.harf ? (x.sinif + "-" + x.harf) : (x.sube || ""), x.ders, x.tarih].filter(Boolean).join(" · ");
        return '<div data-ind="' + i + '" style="padding:3px 0;border-bottom:1px solid #eee"><label><input type="radio" name="nga-oyss-ind-sec" value="' + i + '"> <b>' + kac((x.ad || "").replace(/^.*[\\/]/, "")) + "</b></label> <span style=\"color:#555\">" + kac(et) + "</span> " +
          (x.id ? '<a href="#" data-goster="' + i + '">Klasörü göster</a> <a href="#" data-ac="' + i + '">Aç</a> ' : "") +
          '<a href="#" data-yukle="' + i + '">Kaynak olarak yükle</a></div>';
      }).join("");
      k.querySelectorAll("[data-goster]").forEach((a) => { a.onclick = (e) => { e.preventDefault(); const x = indirListe[+a.getAttribute("data-goster")]; if (x && x.id) try { chrome.runtime.sendMessage({ tip: "oyss-indir-goster", id: x.id }); } catch (err) {} }; });
      k.querySelectorAll("[data-ac]").forEach((a) => { a.onclick = (e) => { e.preventDefault(); const x = indirListe[+a.getAttribute("data-ac")]; if (x && x.id) try { chrome.runtime.sendMessage({ tip: "oyss-indir-ac", id: x.id }); } catch (err) {} }; });
      k.querySelectorAll("[data-yukle]").forEach((a) => { a.onclick = (e) => { e.preventDefault(); excelKaynaktanYukle(indirListe[+a.getAttribute("data-yukle")]); }; });
    }
    if (depo) depo.get("ngaOyssIndirilenler", (v) => { indirListe = (v && v.ngaOyssIndirilenler) || []; indirListeCiz(); });
    if ($("nga-oyss-indir-temizle")) $("nga-oyss-indir-temizle").onclick = () => { indirListe = []; if (depo) depo.set({ ngaOyssIndirilenler: [] }); indirListeCiz(); yazDurum("Liste temizlendi. Dosyalar diskte duruyor."); };

    function excelOnizlemeCiz(grup, ad) {
      const kutu = $("nga-oyss-excel-kutu"), tablo = $("nga-oyss-excel-tablo"), adEl = $("nga-oyss-excel-ad");
      if (!kutu || !grup) return;
      kutu.hidden = false;
      if (adEl) adEl.textContent = (ad || "") + (grup.sube ? " — " + grup.sube : "") + (grup.ders ? " / " + grup.ders : "") + (grup.soruSayisi ? (" · " + (grup.ogrenciler || []).length + " öğrenci / " + grup.soruSayisi + " soru") : "");
      const maxlar = grup.puanlar || [];
      const nSoru = grup.soruSayisi || maxlar.length || 0;
      let html = "<table border=\"1\" cellpadding=\"3\" cellspacing=\"0\"><thead><tr><th>Okul No</th><th>Ad</th>";
      for (let i = 0; i < nSoru; i++) html += "<th>" + kac(OyssNot.soruBaslikYaz(i + 1, maxlar[i])) + "</th>";
      html += "<th>Toplam</th><th>Katılım</th></tr></thead><tbody>";
      (grup.ogrenciler || []).forEach((o) => {
        const top = OyssNot.puanToplam(o.puan || [], maxlar);
        html += "<tr><td>" + kac(o.no) + "</td><td>" + kac(o.ad || "") + "</td>";
        for (let i = 0; i < nSoru; i++) {
          const h = top.hatalar.some((x) => x.indexOf((i + 1) + ". soru") === 0);
          const hucre = (o.puan && o.puan[i] != null && o.puan[i] !== "") ? o.puan[i] : "";
          html += "<td" + (h ? " style=\"background:#fdecea;color:#b00020;font-weight:700\"" : "") + ">" + kac(hucre) + "</td>";
        }
        html += "<td>" + (top.toplam == null || top.toplam === "" ? "" : String(top.toplam)) + "</td><td>" + kac(o.katilim || "") + "</td></tr>";
      });
      html += "</tbody></table>";
      if (tablo) tablo.innerHTML = html;
    }
    function excelOturumaAl(grup, kayit, buf) {
      excelOturum = { grup: grup, ad: (kayit && (kayit.ad || kayit.yol)) || "", yol: kayit && kayit.yol, id: kayit && kayit.id, kayit: kayit, buf: buf };
      excelOnizlemeCiz(grup, excelOturum.ad);
    }
    async function excelKaynaktanYukle(kayit) {
      if (!kayit) return;
      const ot = oturumDosyalar.find((x) => (kayit.id && x.id === kayit.id) || (x.ad && x.ad === kayit.ad) || (x.sinif && Number(x.sinif) === Number(kayit.sinif) && OyssNot.katla(x.harf) === OyssNot.katla(kayit.harf) && OyssNot.katla(x.ders) === OyssNot.katla(kayit.ders)));
      if (ot && ot.grup) { excelOturumaAl(ot.grup, kayit, ot.buf); yazDurum("Excel oturuma alındı: " + (kayit.ad || "") + ". Sesle puan söyleyebilirsiniz."); return; }
      yazDurum("Bu dosyanın içeriği oturumda yok (öğrenci verisi saklanmaz). Lütfen İndirilenler'den dosyayı seçin: " + (kayit.yol || kayit.ad || ""), "", true);
      const inp = $("nga-oyss-dosya");
      if (inp) inp.click();
    }
    async function excelSesDosyaKaydet() {
      if (!excelOturum || !excelOturum.grup) throw new Error("Önce bir Excel yükleyin veya indirin.");
      const sablon = await sablonAl();
      const ad = OyssNot.indirYolu(OyssNot.yeniExcelAdi(excelOturum.ad || "OYSS.xlsx"));
      const out = await OyssNot.sablonCokluKitap(sablon, [excelOturum.grup]);
      const r = await indir(ad, out, null, { sinif: excelOturum.kayit && excelOturum.kayit.sinif, sube: excelOturum.grup.sube, harf: excelOturum.kayit && excelOturum.kayit.harf, ders: excelOturum.grup.ders, grup: excelOturum.grup, buf: out });
      return r;
    }
    if ($("nga-oyss-excel-kaydet")) $("nga-oyss-excel-kaydet").onclick = async () => {
      if (!excelOturum || !excelOturum.grup) return yazDurum("Önce bir Excel yükleyin veya indirin.", "", true);
      try {
        const r = await excelSesDosyaKaydet();
        yazDurum("Yeni Excel kaydedildi (orijinal duruyor): " + (r.ad || ""));
      } catch (e) { yazDurum("Kaydedilemedi: " + (e && e.message || e), "", true); }
    };
    if ($("nga-oyss-excel-eokul-yaz")) $("nga-oyss-excel-eokul-yaz").onclick = async () => {
      if (!excelOturum || !excelOturum.grup) return yazDurum("Önce bir Excel yükleyin veya sesle doldurun.", "", true);
      const ogr = excelOturum.grup.ogrenciler || [];
      const satirlar = ogr.filter((o) => {
        const puan = o.puan || [];
        const dolu = puan.some((v) => v != null && String(v).trim() !== "");
        return dolu || !!(o.katilim && String(o.katilim).trim());
      }).map((o) => ({ no: o.no, puan: o.puan || [], katilim: o.katilim || "" }));
      if (!satirlar.length) return yazDurum("Önizlemede yazılacak puan yok.", "", true);
      try {
        let kayitAd = "";
        try {
          const kay = await excelSesDosyaKaydet();
          kayitAd = (kay && (kay.ad || kay.yol)) || "";
        } catch (e) { yazDurum("Excel kaydedilemedi: " + (e && e.message || e), "", true); }
        const r = await OyssNot.sesYaz(window, satirlar);
        const ek = kayitAd ? (" Sesli Excel kaydedildi: " + kayitAd + ".") : "";
        if (r && r.yazilan) yazDurum("e-Okul tablosuna yazıldı (" + r.yazilan + " öğrenci). Kaydet'e basılmadı." + ek, (r.hatalar && r.hatalar.length) ? r.hatalar.join(" · ") : "");
        else yazDurum("Yazılamadı. " + ((r && r.hatalar && r.hatalar.join(" · ")) || "Açık OYSS listesi bu Excel ile eşleşmiyor olabilir.") + ek, "", true);
      } catch (e) { yazDurum("e-Okul'a yazılamadı: " + (e && e.message || e), "", true); }
    };

    async function isaretlileriIndir() {
      const kombolar = secilenKombinasyonlar();
      if (!kombolar.length) { yazDurum("Önce sınıf, ders ve şube kutucuklarını işaretleyin. İşaretlenmeyen şube işlenmez.", "", true); return; }
      const cozulen = [];
      for (const k of kombolar) {
        const hedef = k.hedef || { text: k.sube, harf: k.harf, sinif: k.sinif, alan: k.alan, value: k.value };
        let hit = (hedef && hedef.index != null) ? hedef : OyssNot.subeHedefBul(OyssNot.subeleriOku(window), k.sinif, hedef);
        if (!hit) {
          const haz = await OyssNot.subeHedefHazirla(window, k.sinif, hedef);
          if (haz && haz.ok) hit = haz.hit;
          else {
            yazDurum((haz && haz.hata) || ("Bu şube sayfanın açılır listesinde yok: " + k.sinif + " / " + (k.harf || k.sube) + ". Mevcut şubeler: " + OyssNot.subeSecenekOzeti(OyssNot.subeleriOku(window))), "", true);
            return;
          }
        }
        cozulen.push(Object.assign({}, k, { hedef: hit }));
      }
      const sablon = await sablonAl();
      const subeMap = new Map();
      cozulen.forEach((k) => {
        const key = String(k.hedef.index) + "|" + k.sinif;
        if (!subeMap.has(key)) subeMap.set(key, { hedef: k.hedef, sinif: k.sinif, dersler: [] });
        const g = subeMap.get(key);
        if (g.dersler.indexOf(k.ders) < 0) g.dersler.push(k.ders);
      });
      let n = 0, toplam = cozulen.length, mesajlar = [];
      for (const g of subeMap.values()) {
        if (iptal) throw new Error("İşlem iptal edildi.");
        yazDurum("OYSS: " + (n + 1) + "/" + toplam + " " + (g.hedef.text) + " listesi okunuyor…", "");
        const sonuc = await OyssNot.tumSubeleriCek(window, {
          hiz: (hizSel && hizSel.value) || "hizli",
          secilenSubeler: [g.hedef],
          ders: g.dersler[0],
          tekDers: true,
          yalnizOyss: true,
          iptal: () => iptal,
          ilerleme: (q) => yazDurum("OYSS: " + (q.mesaj || ""), ""),
        });
        const ana = sonuc.gruplar && sonuc.gruplar[0];
        if (!ana) { mesajlar.push("Alınamadı: " + g.hedef.text + " — " + ((sonuc.hatalar && sonuc.hatalar[0]) || "")); continue; }
        for (const ders of g.dersler) {
          if (iptal) throw new Error("İşlem iptal edildi.");
          const grup = Object.assign({}, ana, { ders, dersler: [ders], ogrenciler: (ana.ogrenciler || []).map((o) => ({ no: o.no, ad: o.ad, puan: (o.puan || []).slice(), katilim: o.katilim || "" })) });
          const ad = OyssNot.dosyaAdiKisa(g.sinif, g.hedef.text, ders);
          const out = await OyssNot.sablonCokluKitap(sablon, [grup]);
          const r = await indir(OyssNot.indirYolu(ad), out, null, { sinif: g.sinif, sube: g.hedef.text, harf: OyssNot.subeHarfOku(g.hedef.text), ders, grup, buf: out });
          excelOturumaAl(grup, r, out);
          n++;
          mesajlar.push(ad);
        }
      }
      yazDurum(n + " Excel indirildi (Not Girisi/OYSS/" + OyssNot.yerelTarihISO() + "/).", mesajlar.join("\n"));
    }
    async function calistirIndir(btn) {
      iptal = false;
      if (btnIptal) btnIptal.hidden = false;
      if (btn) btn.disabled = true;
      window.__ngaOyssCalisiyor = true;
      try {
        if (!(await kvkkOk())) return yazDurum("KVKK onayı olmadan çalışmaz.");
        await isaretlileriIndir();
      } catch (e) { yazDurum("İndirilemedi: " + (e && e.message || e), "", true); }
      finally { if (btn) btn.disabled = false; if (btnIptal) btnIptal.hidden = true; window.__ngaOyssCalisiyor = false; }
    }
    const btnHizliAc = $("nga-oyss-hizli-ac"), btnHizliAktar = $("nga-oyss-hizli-aktar"), btnHepsiIndir = $("nga-oyss-hepsi-indir");
    if (btnHizliAktar) btnHizliAktar.onclick = () => calistirIndir(btnHizliAktar);
    if (btnHepsiIndir) btnHepsiIndir.onclick = async () => {
      oyssSecim.siniflar = SINIFLAR.slice();
      sinifKutulariCiz(); tumDersleriSec(true); subeleriDoldurHizli(); tumSubeleriSec(true);
      await calistirIndir(btnHepsiIndir);
    };
    if (btnHizliAc) btnHizliAc.onclick = async () => {
      const kombo = secilenKombinasyonlar()[0];
      if (!kombo) return yazDurum("Ses için önce bir sınıf-şube-ders işaretleyin veya sesle söyleyin.", "", true);
      let hit = OyssNot.subeHedefBul(OyssNot.subeleriOku(window), kombo.sinif, kombo.hedef || { text: kombo.sube, harf: kombo.harf, sinif: kombo.sinif, alan: kombo.alan, value: kombo.value });
      if (!hit) {
        const haz = await OyssNot.subeHedefHazirla(window, kombo.sinif, kombo.hedef || { text: kombo.sube, harf: kombo.harf, sinif: kombo.sinif, alan: kombo.alan });
        if (haz && haz.ok) hit = haz.hit;
        else return yazDurum((haz && haz.hata) || ("Bu şube sayfada yok: " + kombo.sinif + "-" + kombo.harf + ". Mevcut şubeler: " + OyssNot.subeSecenekOzeti(OyssNot.subeleriOku(window))), "", true);
      }
      iptal = false; if (btnIptal) btnIptal.hidden = false; btnHizliAc.disabled = true; window.__ngaOyssCalisiyor = true;
      try {
        if (!(await kvkkOk())) return yazDurum("KVKK onayı olmadan çalışmaz.");
        const sonuc = await OyssNot.tumSubeleriCek(window, {
          hiz: (hizSel && hizSel.value) || "hizli", secilenSubeler: [hit], ders: kombo.ders, tekDers: true, yalnizOyss: true,
          iptal: () => iptal, ilerleme: (q) => yazDurum("OYSS: " + (q.mesaj || ""), ""),
        });
        const ek = hataOzet(sonuc);
        if (sonuc.gruplar.length) yazDurum("Şube açıldı: " + hit.text + " / " + kombo.ders + " (" + ((sonuc.gruplar[0].ogrenciler || []).length) + " öğrenci / " + (sonuc.gruplar[0].soruSayisi || 0) + " soru). Sesle puan söyleyebilirsiniz.", ozetGruplar(sonuc.gruplar) + (ek ? "\n\n" + ek : ""));
        else yazDurum("Liste alınamadı. " + (sonuc.hatalar[0] || sonuc.atlanan[0] || ""), ek, true);
      } catch (e) { yazDurum("Açılamadı: " + (e && e.message || e), "", true); }
      finally { btnHizliAc.disabled = false; if (btnIptal) btnIptal.hidden = true; window.__ngaOyssCalisiyor = false; }
    };

    let sesBekleyen = null, sesAcik = false, sesBekleyenBaglam = null, sesHedef = "sayfa", aktifBaglam = null;
    const sesDurumEl = $("nga-oyss-ses-durum"), sesOnizEl = $("nga-oyss-ses-onizleme"), aktifBaglamEl = $("nga-oyss-aktif-baglam");
    const btnSes = $("nga-oyss-ses"), btnSesOnayla = $("nga-oyss-ses-onayla"), btnSesVaz = $("nga-oyss-ses-vazgec"), sesOnayKutu = $("nga-oyss-ses-onay");
    const yazSesDurum = (t, hata) => { if (!sesDurumEl) return; sesDurumEl.textContent = t; sesDurumEl.style.color = hata ? "#b00020" : ""; };
    function baglamEtiketYaz(b) {
      if (window.NGASes && window.NGASes.baglamEtiket) return window.NGASes.baglamEtiket(b);
      const parca = [];
      if (b && b.sinif != null && b.harf) parca.push(b.sinif + "/" + b.harf);
      else if (b && b.sinif != null) parca.push(String(b.sinif));
      else if (b && b.harf) parca.push(b.harf);
      const ders = b && b.ders ? String(b.ders).trim() : "";
      const alan = b && b.alan && String(b.alan).trim().length <= 40 ? String(b.alan).trim() : "";
      let et = parca[0] || "";
      if (et && ders) et += " – " + ders;
      else if (ders) et = ders;
      if (et && alan) et += " (" + alan + ")";
      return et;
    }
    function aktifBaglamGoster() {
      if (!aktifBaglamEl) return;
      const et = baglamEtiketYaz(aktifBaglam);
      if (aktifBaglam && (aktifBaglam.kisim || aktifBaglam.ok)) {
        const ek = aktifBaglam.ok ? "" : " — dersi de söyleyin";
        aktifBaglamEl.innerHTML = "<b>Aktif bağlam:</b> " + kac(et || "anlaşıldı") + ek + " — sonraki komutlar bu sınıf içindir (yeni bağlam söyleyene kadar).";
      } else {
        aktifBaglamEl.innerHTML = "<b>Aktif bağlam:</b> (yok — önce sınıf, şube ve dersi söyleyin, ör. \"11 A bilişim matematik\")";
      }
    }
    function aktifBaglamAyarla(b) {
      if (!b) return;
      aktifBaglam = (window.NGASes && window.NGASes.baglamYapistir) ? window.NGASes.baglamYapistir(null, b) : Object.assign({}, b);
      aktifBaglamGoster();
    }
    let sesAkis = { parcalar: [], sira: 0, biriken: "" };
    let sesKayitlar = [];
    const sesYazilanImza = {};
    let sesOnayIsleyen = false;
    const sesHedefEl = $("nga-oyss-ses-hedef"), sesKayitEl = $("nga-oyss-ses-kayitlar");
    function kayitImza(s) {
      return String(s.no || "") + "|" + JSON.stringify(s.puan || {}) + "|" + (s.katilim || "");
    }
    function batchImza(liste) {
      return (liste || []).map(kayitImza).join(";");
    }
    function sesHedefBul() {
      if (excelOturum && excelOturum.grup && excelOturum.grup.ogrenciler) {
        const ad = ((excelOturum.ad || "").replace(/^.*[\\/]/, "")) || "açık dosya";
        return { tur: "excel", ad: ad, grup: excelOturum.grup, satirlar: excelOturum.grup.ogrenciler, puanlar: excelOturum.grup.puanlar || [], etiket: "Hedef: Excel " + ad };
      }
      const sayfa = OyssNot.sayfaOku(window);
      if (sayfa && sayfa.satirlar && sayfa.satirlar.length) {
        const sube = sayfa.sube || "", ders = sayfa.ders || "";
        const n = sayfa.satirlar.length;
        const harf = OyssNot.subeHarfOku(sube);
        const sinif = OyssNot.sinifDuzeyi(sube);
        const kisa = (sinif && harf) ? (sinif + "/" + harf) : (sube || "?");
        const alan = (OyssNot.alanAyir(sube).alan || "");
        const meta = OyssNot.sayfaSoruMeta(sayfa);
        return {
          tur: "oyss", sayfa: sayfa, satirlar: sayfa.satirlar, puanlar: meta.puanlar || [],
          etiket: "Hedef: OYSS tablosu – " + [kisa, ders].filter(Boolean).join(" ") + " (" + n + " öğrenci)",
          baglam: { sinif: sinif, harf: harf, ders: ders, alan: alan, kisim: !!(sinif && harf), ok: !!(sinif && harf && ders), ham: sube }
        };
      }
      return { tur: "", satirlar: [], puanlar: [], etiket: "Hedef: yok — OYSS öğrenci listesini açın, listeden bir Excel seçin veya sınıf-şube-ders söyleyin." };
    }
    function sesHedefGoster() {
      const h = sesHedefBul();
      if (sesHedefEl) {
        sesHedefEl.textContent = h.etiket;
        sesHedefEl.style.background = h.tur ? "#e8f5e9" : "#fff3e0";
        sesHedefEl.style.borderColor = h.tur ? "#a5d6a7" : "#ffcc80";
      }
      if (h.baglam && (h.baglam.kisim || h.baglam.ok) && !(aktifBaglam && (aktifBaglam.kisim || aktifBaglam.ok))) {
        aktifBaglamAyarla(h.baglam);
      }
      return h;
    }
    function sesMetinGoster(ara) {
      if (!sesOnizEl) return;
      const cap = (s, n) => { const t = String(s || ""); return t.length > n ? t.slice(-n) : t; };
      const biriken = cap((sesAkis && sesAkis.biriken) || "", 200);
      const anlik = cap(ara || "", 200);
      sesOnizEl.textContent = (biriken ? ('Duyulan: "' + biriken + '"') : "") + (anlik ? ((biriken ? "\n" : "") + 'Anlık: "' + anlik + '"') : "");
    }
    function sesKayitListesiCiz() {
      if (!sesKayitEl) return;
      if (!sesKayitlar.length) { sesKayitEl.textContent = "Henüz öğrenci kaydı yok."; return; }
      sesKayitEl.innerHTML = sesKayitlar.map((s) => {
        const ikon = s.durum === "yazildi" ? "✓" : (s.durum === "bekliyor" ? "⏳" : "✗");
        const renk = s.durum === "yazildi" ? "#1b5e20" : (s.durum === "bekliyor" ? "#333" : "#b00020");
        const puanlar = Object.keys(s.puan || {}).sort((a, b) => +a - +b).map((n) => n + ". soru " + s.puan[n]).join(", ");
        const kat = s.katilim ? ("Katılım: " + s.katilim) : "";
        const uy = (s.uyarilar || []).concat(s.hatalar || []).join("; ");
        return '<div style="padding:3px 0;border-bottom:1px solid #eee;color:' + renk + '"><b>' + ikon + "</b> Okul No " + kac(s.no) + (s.ad ? (" — " + kac(s.ad)) : " — listede yok") + (puanlar ? ": " + kac(puanlar) : "") + (s.toplam ? " · Toplam " + s.toplam : "") + (kat ? " · " + kac(kat) : "") + (uy ? ' <span style="color:#b00020">⚠ ' + kac(uy) + "</span>" : "") + "</div>";
      }).join("");
    }
    function sesKayitZenginlestir(satir, kaynak) {
      const kn = OyssNot.noNorm(satir.no);
      const o = ((kaynak && kaynak.satirlar) || []).find((x) => OyssNot.noNorm(x.no) === kn);
      const maxlar = (kaynak && kaynak.puanlar) || [];
      const dizi = [];
      Object.keys(satir.puan || {}).sort((a, b) => +a - +b).forEach((n) => { dizi[+n - 1] = satir.puan[n]; });
      const top = OyssNot.puanToplam(dizi, maxlar);
      const hatalar = [];
      if (!kaynak) hatalar.push("hedef yok");
      else if (!o) hatalar.push("bu listede yok");
      return {
        no: satir.no, puan: satir.puan || {}, katilim: satir.katilim || "",
        ad: (o && o.ad) || "", uyarilar: top.hatalar || [], hatalar: hatalar,
        toplam: top.toplam, imza: kayitImza(satir), durum: "bekliyor"
      };
    }
    async function yazSesKayitlari(liste) {
      const kaynak = ogrenciKaynak();
      const bekleyen = (liste || []).map((s) => ({ no: s.no, puan: s.puan, katilim: s.katilim, imza: s.imza || kayitImza(s) }));
      if (!kaynak) { yazSesDurum("Yazılacak hedef yok. OYSS öğrenci listesini açın veya bir Excel seçin.", true); return false; }
      if (!bekleyen.length) { yazSesDurum("Onaylanacak öğrenci kaydı yok.", true); return false; }
      sesOnayIsleyen = true;
      try {
        let r;
        if (kaynak.tur === "excel") {
          r = OyssNot.sesExcelUygula(kaynak.grup, bekleyen);
          excelOturum.grup = r.grup;
          excelOnizlemeCiz(r.grup, excelOturum.ad);
          const ek = (r.hatalar || []).concat(r.uyarilar || []).join(" · ");
          yazSesDurum(r.yazilan ? ("Excel önizlemesine yazıldı (" + r.yazilan + " öğrenci). Yeni dosya olarak kaydedin. Kaydet'e basılmadı.") : ("Yazılamadı. " + ek), !r.yazilan);
        } else {
          r = await OyssNot.sesYaz(window, bekleyen, { araMs: 15 });
          const ek = (r.hatalar || []).concat(r.uyarilar || []).join(" · ");
          yazSesDurum(r.yazilan ? ("Puanlar OYSS tablosuna yazıldı (" + r.yazilan + " öğrenci). Kaydet'e siz basarsınız.") : ("Yazılamadı. " + ek), !r.yazilan);
        }
        const yazilanNo = {};
        (r && r.yazilanDetay ? r.yazilanDetay : bekleyen).forEach((s) => { if (s && s.no) yazilanNo[OyssNot.noNorm(s.no)] = true; });
        const ok = !!(r && r.yazilan);
        sesKayitlar.forEach((s) => {
          if (s.durum === "bekliyor" && yazilanNo[OyssNot.noNorm(s.no)]) s.durum = ok ? "yazildi" : "hata";
        });
        if (ok) sesYazilanImza[batchImza(bekleyen)] = true;
        sesKayitListesiCiz();
        sesBekleyen = sesKayitlar.filter((s) => s.durum === "bekliyor").map((s) => ({ no: s.no, puan: s.puan, katilim: s.katilim }));
        if (btnSesOnayla) btnSesOnayla.hidden = !sesBekleyen.length;
        sesHedefGoster();
        return ok;
      } catch (e) {
        yazSesDurum("Yazılamadı: " + (e && e.message || e), true);
        return false;
      } finally { sesOnayIsleyen = false; }
    }
    function sesPaketiIsle(paket, ara) {
      if (paket && window.NGASes && window.NGASes.sesParcaEkle) sesAkis = window.NGASes.sesParcaEkle(sesAkis, paket);
      else if (paket && Array.isArray(paket.parcalar) && paket.parcalar.length) sesAkis = { parcalar: paket.parcalar.slice(), sira: paket.sira || paket.parcalar.length, biriken: paket.parcalar.join(" ").replace(/\s+/g, " ").trim() };
      if (window.NGASes && window.NGASes._hap && window.NGASes._hap.parcaIsle) {
        if (paket && paket.final !== false) window.NGASes._hap.parcaIsle(paket);
        sesMetinGoster(ara || "");
        sesHedefGoster();
        const hd = window.NGASes._hap.durumGet && window.NGASes._hap.durumGet();
        if (hd && (hd.durumYazi || hd.uyari || hd.sonHata)) yazSesDurum((hd.durumYazi || "") + (hd.uyari && hd.uyari !== hd.durumYazi ? (" · " + hd.uyari) : (hd.sonHata ? (" · " + hd.sonHata) : "")), !!hd.uyari);
        if (btnSesOnayla) btnSesOnayla.hidden = true;
        return;
      }
      sesMetinGoster(ara || "");
      const hedef = sesHedefGoster();
      const taban = aktifBaglam || (hedef && hedef.baglam) || null;
      const coz = (window.NGASes && window.NGASes.sesAkisCoz) ? window.NGASes.sesAkisCoz(sesAkis.biriken, taban) : { baglam: taban, kuyruk: [], beklemede: [], onay: false, hatalar: [] };
      if (coz.baglam && (coz.baglam.kisim || coz.baglam.ok)) aktifBaglamAyarla(coz.baglam);
      else aktifBaglamGoster();
      const kaynak = ogrenciKaynak();
      const goster = [];
      const yazilacak = [];
      (coz.kuyruk || []).forEach((b) => {
        const im = batchImza(b.kayitlar || []);
        if (b.onay && sesYazilanImza[im]) {
          (b.kayitlar || []).forEach((s) => {
            const z = sesKayitZenginlestir(s, kaynak);
            z.durum = "yazildi";
            goster.push(z);
          });
          return;
        }
        (b.kayitlar || []).forEach((s) => {
          const z = sesKayitZenginlestir(s, kaynak);
          if (z.hatalar && z.hatalar.length && z.hatalar.indexOf("bu listede yok") >= 0) z.durum = "hata";
          else z.durum = "bekliyor";
          goster.push(z);
        });
        if (b.onay && (b.kayitlar || []).length && !sesYazilanImza[im]) yazilacak.push(b);
      });
      sesKayitlar = goster;
      sesKayitListesiCiz();
      sesBekleyen = sesKayitlar.filter((s) => s.durum === "bekliyor").map((s) => ({ no: s.no, puan: s.puan, katilim: s.katilim }));
      const hedefYok = !kaynak;
      const baglamAc = !kaynak && coz.baglam && (coz.baglam.kisim || coz.baglam.ok) && !sesBekleyen.length;
      if (baglamAc) sesBekleyenBaglam = coz.baglam;
      if (btnSesOnayla) {
        btnSesOnayla.hidden = !(sesBekleyen.length || baglamAc);
        btnSesOnayla.textContent = baglamAc ? "Bağlamı onayla ve aç" : "Onayla ve yaz";
      }
      if (btnSesVaz) btnSesVaz.hidden = !((sesAkis && sesAkis.biriken) || sesBekleyen.length);
      if (yazilacak.length && kaynak && !sesOnayIsleyen) {
        const hepsi = [];
        yazilacak.forEach((b) => { (b.kayitlar || []).forEach((s) => hepsi.push(s)); });
        yazSesDurum("Onay komutu alındı; " + hepsi.length + " kayıt " + (kaynak.tur === "excel" ? "Excel'e" : "OYSS tablosuna") + " yazılıyor. Kaydet'e basılmaz.", false);
        yazSesKayitlari(hepsi);
      } else if (yazilacak.length && !kaynak) {
        yazSesDurum("Onaylandı ama hedef yok. OYSS listesini açın veya bir Excel seçin; sonra tekrar onaylayın.", true);
      } else if (sesBekleyen.length) {
        yazSesDurum((aktifBaglam && (aktifBaglam.kisim || aktifBaglam.ok) ? ("Bağlam: " + baglamEtiketYaz(aktifBaglam) + ". ") : "") + sesBekleyen.length + " kayıt bekliyor. \"onaylıyorum\" deyin veya Onayla ve yaz'a basın. \"iptal\" son kaydı siler.", false);
      } else if (coz.baglam && (coz.baglam.kisim || coz.baglam.ok)) {
        yazSesDurum("Aktif bağlam: " + baglamEtiketYaz(coz.baglam) + (kaynak ? ". Okul no ve soruları söyleyin; bitince \"onaylıyorum\"." : ". Bu listenin hedefi açık değil; şubeyi açmak için onaylayın veya OYSS listesini yükleyin."), !kaynak);
      } else if (sesAkis.biriken && (coz.hatalar || []).length) {
        yazSesDurum("Kısmen anlaşıldı. " + (coz.hatalar || []).join(" · "), true);
      }
    }
    function onizlemeGizle() {
      sesBekleyen = null; sesBekleyenBaglam = null;
      sesKayitlar = sesKayitlar.filter((s) => s.durum === "yazildi");
      sesKayitListesiCiz();
      if (btnSesOnayla) { btnSesOnayla.hidden = true; btnSesOnayla.textContent = "Onayla ve yaz"; }
      if (btnSesVaz) btnSesVaz.hidden = true;
    }
    function basHarf(ad) { return String(ad || "").split(/\s+/).map((k) => k ? k[0] + "." : "").join(" "); }
    function ogrenciKaynak() {
      if (excelOturum && excelOturum.grup && excelOturum.grup.ogrenciler) return { tur: "excel", grup: excelOturum.grup, satirlar: excelOturum.grup.ogrenciler, puanlar: excelOturum.grup.puanlar || [] };
      const sayfa = OyssNot.sayfaOku(window);
      if (sayfa && sayfa.satirlar && sayfa.satirlar.length) {
        const meta = OyssNot.sayfaSoruMeta(sayfa);
        return { tur: "sayfa", sayfa, satirlar: sayfa.satirlar, puanlar: meta.puanlar, sorular: sayfa.sorular };
      }
      return null;
    }
    function onizlemeGoster(ayris, transkript, baglam) {
      const kaynak = ogrenciKaynak();
      const satirlar = (ayris && ayris.satirlar) || [];
      const satir = [];
      if (transkript) satir.push('Duyulan: "' + transkript + '"');
      if (baglam || aktifBaglam) {
        const goster = baglam || aktifBaglam;
        const et = baglamEtiketYaz(goster);
        satir.push("Bağlam: " + (et || "anlaşılamadı") + (goster.ok ? " (kalıcı)" : (goster.kisim ? " (ders eksik)" : " (eksik)")));
      }
      if (ayris && ayris.hatalar && ayris.hatalar.length) satir.push("Anlaşılamayan: " + ayris.hatalar.join(" · "));
      if (baglam && baglam.ok && !satirlar.length) {
        if (sesOnizEl) sesOnizEl.textContent = satir.join("\n") + "\nOnaylarsanız bu sınıf-şube-ders açılır / Excel eşlenir. Yazılmaz.";
        sesBekleyenBaglam = baglam; sesBekleyen = null;
        if (btnSesOnayla) { btnSesOnayla.hidden = false; btnSesOnayla.textContent = "Bağlamı onayla ve aç"; }
        if (btnSesVaz) btnSesVaz.hidden = false;
        return;
      }
      if (!satirlar.length) {
        if (sesOnizEl) sesOnizEl.textContent = satir.join("\n");
        if (btnSesOnayla) btnSesOnayla.hidden = !sesBekleyenBaglam;
        if (btnSesVaz) btnSesVaz.hidden = !transkript;
        sesBekleyen = null;
        return;
      }
      const harita = new Map();
      ((kaynak && kaynak.satirlar) || []).forEach((x) => { const kn = OyssNot.noNorm(x.no); if (kn && !harita.has(kn)) harita.set(kn, x); });
      const uygulanacak = [];
      const maxlar = (kaynak && kaynak.puanlar) || [];
      for (const kmt of satirlar) {
        const o = harita.get(OyssNot.noNorm(kmt.no));
        const puanlar = Object.keys(kmt.puan || {}).sort((a, b) => +a - +b).map((n) => n + ". soru " + kmt.puan[n]);
        const kat = kmt.katilim ? ("Katılım: " + kmt.katilim) : "";
        const dizi = [];
        Object.keys(kmt.puan || {}).sort((a, b) => +a - +b).forEach((n) => { dizi[+n - 1] = kmt.puan[n]; });
        const top = OyssNot.puanToplam(dizi, maxlar);
        const par = puanlar.concat(kat ? [kat] : []).concat(top.toplam ? ["Toplam: " + top.toplam] : []).join(", ") || "(boş)";
        if (!kaynak) satir.push("Okul No " + kmt.no + " — önce bağlamı onaylayın veya Excel/şube açın. Yazılmayacak.");
        else if (!o) satir.push("Okul No " + kmt.no + " — bu listede yok. Yazılmayacak.");
        else {
          const uyari = top.hatalar.length ? " ⚠ " + top.hatalar.join("; ") : "";
          satir.push("Okul No " + kmt.no + " (" + basHarf(o.ad) + "): " + par + uyari);
          if (!top.hatalar.length) uygulanacak.push(kmt);
          else uygulanacak.push(kmt);
        }
      }
      satir.push(kaynak && kaynak.tur === "excel" ? "Onaylamadan Excel'e yazılmaz. Yeni dosya olarak kaydedilir; orijinal durur." : "Onaylamadan e-Okul'a yazılmaz. Kaydet'e basılmaz.");
      if (sesOnizEl) sesOnizEl.textContent = satir.join("\n");
      sesBekleyen = uygulanacak.length ? uygulanacak : null;
      if (btnSesOnayla) { btnSesOnayla.hidden = !(sesBekleyen || sesBekleyenBaglam); btnSesOnayla.textContent = sesBekleyenBaglam && !sesBekleyen ? "Bağlamı onayla ve aç" : "Onayla ve yaz"; }
      if (btnSesVaz) btnSesVaz.hidden = false;
    }
    async function baglamUygula(baglam, skorlar) {
      aktifBaglamAyarla(baglam);
      const et = baglamEtiketYaz(baglam);
      const es = OyssNot.indirKaydiEsle(indirListe.concat(oturumDosyalar.map((x) => ({ sinif: x.sinif, harf: x.harf, ders: x.ders, ad: x.ad, yol: x.yol, id: x.id }))), baglam);
      const ot = oturumDosyalar.find((x) => Number(x.sinif) === Number(baglam.sinif) && OyssNot.katla(x.harf) === OyssNot.katla(baglam.harf) && (OyssNot.katla(x.ders) === OyssNot.katla(baglam.ders) || OyssNot.katla(x.ders).indexOf(OyssNot.katla(baglam.ders)) >= 0));
      if (ot && ot.grup) {
        excelOturumaAl(ot.grup, { ad: ot.ad, yol: ot.yol, id: ot.id, sinif: ot.sinif, harf: ot.harf, ders: ot.ders }, ot.buf);
        yazSesDurum("Bağlam onaylandı ve kaldı: " + et + " (Excel). " + (skorlar && skorlar.length ? "Puan önizlemesini kontrol edin." : "Şimdi yalnız okul no ve soruları söyleyin."), false);
        if (skorlar && skorlar.length) { sesBekleyenBaglam = null; onizlemeGoster({ satirlar: skorlar, hatalar: [] }, "", aktifBaglam); }
        else { sesBekleyenBaglam = null; }
        aktifBaglamGoster();
        return true;
      }
      if (es.length && !ot) {
        yazSesDurum("Eşleşen dosya listede var ama oturumda açık değil: " + ((es[0].ad || es[0].yol) || "") + ". 'Kaynak olarak yükle' ile seçin veya bu şubeyi indireyim.", true);
        sesBekleyenBaglam = baglam;
        if (btnSesOnayla) { btnSesOnayla.hidden = false; btnSesOnayla.textContent = "Bu şubeyi indir"; }
        return false;
      }
      let hit = OyssNot.subeHedefBul(OyssNot.subeleriOku(window), baglam.sinif, { text: baglam.harf, harf: baglam.harf, sinif: baglam.sinif, alan: baglam.alan });
      if (!hit) {
        const haz = await OyssNot.subeHedefHazirla(window, baglam.sinif, { text: baglam.harf, harf: baglam.harf, sinif: baglam.sinif, alan: baglam.alan });
        if (haz && haz.ok) hit = haz.hit;
      }
      if (hit) {
        yazSesDurum("Sayfada şube açılıyor: " + hit.text + " / " + (baglam.ders || ""), false);
        const sonuc = await OyssNot.tumSubeleriCek(window, {
          hiz: (hizSel && hizSel.value) || "hizli", secilenSubeler: [Object.assign({}, hit, { sinif: baglam.sinif, harf: baglam.harf, alan: baglam.alan })], ders: baglam.ders, tekDers: true, yalnizOyss: true,
          iptal: () => iptal, ilerleme: (q) => yazDurum("OYSS: " + (q.mesaj || ""), ""),
        });
        if (sonuc.gruplar && sonuc.gruplar[0]) {
          yazSesDurum("Bağlam onaylandı ve kaldı: " + et + " (e-Okul listesi). " + ((sonuc.gruplar[0].ogrenciler || []).length) + " öğrenci / " + (sonuc.gruplar[0].soruSayisi || 0) + " soru. Sonraki komutlar yalnız okul no / soru olabilir.", false);
          sesBekleyenBaglam = null;
          if (skorlar && skorlar.length) onizlemeGoster({ satirlar: skorlar, hatalar: [] }, "", aktifBaglam);
          aktifBaglamGoster();
          return true;
        }
      }
      yazSesDurum("Eşleşen Excel yok: " + et + ". İndirmek için onaylayın (yalnız bu bağlamın kutucuğu işaretlenir)." + (hit ? "" : ("\nMevcut şubeler: " + OyssNot.subeSecenekOzeti(OyssNot.subeleriOku(window)))), true);
      sesBekleyenBaglam = baglam;
      if (baglam.sinif) { if (oyssSecim.siniflar.indexOf(String(baglam.sinif)) < 0) oyssSecim.siniflar.push(String(baglam.sinif)); }
      if (baglam.ders && baglam.sinif) { const key = baglam.sinif + "|" + baglam.ders; if (oyssSecim.dersler.indexOf(key) < 0) oyssSecim.dersler.push(key); }
      sinifKutulariCiz(); dersleriDoldur();
      ogrenSubelerHizli(); subeleriDoldurHizli();
      if (hit) {
        const key = OyssNot.subeAnahtar(Object.assign({}, hit, { sinif: baglam.sinif, harf: baglam.harf || OyssNot.subeHarfOku(hit.text), alan: baglam.alan || hit.alan }));
        if (key && oyssSecim.subeler.indexOf(key) < 0) oyssSecim.subeler.push(key);
        subeleriDoldurHizli();
      }
      secimiSakla();
      if (btnSesOnayla) { btnSesOnayla.hidden = false; btnSesOnayla.textContent = "Bu şubeyi indir"; }
      aktifBaglamGoster();
      return false;
    }
    if (depo && sesOnayKutu) depo.get("ngaOyssSesOnay", (v) => { if (v.ngaOyssSesOnay) sesOnayKutu.checked = true; });
    if (sesOnayKutu) sesOnayKutu.onchange = () => { if (depo) depo.set({ ngaOyssSesOnay: !!sesOnayKutu.checked }); };
    if (btnSes && depo && chrome.runtime && chrome.runtime.sendMessage) {
      const sesPaketten = (paket, ara) => { if (paket || ara) sesPaketiIsle(paket, ara); };
      chrome.storage.onChanged.addListener((c, a) => {
        if (a !== "local") return;
        if (c.ngaSesDurum && c.ngaSesDurum.newValue) {
          const v = c.ngaSesDurum.newValue;
          if (v.bitti || (v.hata && /izni|bulunamad/.test(v.t || ""))) { sesAcik = false; if (btnSes) btnSes.textContent = "🎤 Mikrofonu aç"; }
          if (v.t) yazSesDurum(v.t, v.hata);
        }
        if (c.ngaSesAra && c.ngaSesAra.newValue && c.ngaSesAra.newValue.t) sesMetinGoster(c.ngaSesAra.newValue.t);
        if (c.ngaSesMetin && c.ngaSesMetin.newValue) sesPaketten(c.ngaSesMetin.newValue);
      });
      if (chrome.runtime && chrome.runtime.onMessage) {
        chrome.runtime.onMessage.addListener((m) => {
          if (!m || m.tip !== "nga-ses-parca") return;
          sesPaketten({ t: m.t, biriken: m.biriken, parcalar: m.parcalar, sira: m.sira, final: !!m.final });
        });
      }
      btnSes.onclick = () => {
        if (sesAcik) {
          sesAcik = false;
          btnSes.textContent = "🎤 Mikrofonu aç";
          depo.set({ ngaSesKomut: { k: "dur", z: Date.now() } });
          yazSesDurum("Mikrofon kapatıldı. Biriken metin ve kayıtlar duruyor; \"onaylıyorum\" demediyseniz Onayla ve yaz ile yazabilirsiniz.", false);
          sesHedefGoster();
          return;
        }
        if (sesOnayKutu && !sesOnayKutu.checked) return yazSesDurum("Önce ses tanımanın Google'a gittiğini kabul edin (kutuyu işaretleyin).", true);
        sesAcik = true;
        btnSes.textContent = "⏹ Mikrofonu kapat";
        const hedef = sesHedefGoster();
        yazSesDurum((hedef.etiket ? hedef.etiket + ". " : "") + (aktifBaglam && (aktifBaglam.kisim || aktifBaglam.ok) ? ("Aktif bağlam: " + baglamEtiketYaz(aktifBaglam) + ". ") : (hedef.baglam ? "Açık liste bağlam olarak alındı. " : "Önce sınıf-şube-ders söyleyin veya listeyi açın. ")) + "Sürekli dinleme açılıyor. Bitince \"onaylıyorum\" deyin.", false);
        try {
          const hap = window.NGASes && window.NGASes._hap;
          if (hap && hap.el) { hap.el.style.display = ""; hap.ac(); }
          else chrome.runtime.sendMessage({ tip: "ses-ac" });
        } catch (e) { sesAcik = false; btnSes.textContent = "🎤 Mikrofonu aç"; yazSesDurum("Ses penceresi açılamadı.", true); }
      };
    } else if (btnSes) { btnSes.disabled = true; btnSes.textContent = "🎤 Sesli giriş kullanılamıyor"; }
    if (window.NGASes && window.NGASes.hapKur) {
      try {
        window.NGASes.hapKur({
          kvkkOk: () => !!(sesOnayKutu && sesOnayKutu.checked),
          hedef: () => sesHedefBul(),
          excelGrup: () => excelOturum && excelOturum.grup,
          excelYenile: (grup) => { if (excelOturum) { excelOturum.grup = grup; excelOnizlemeCiz(grup, excelOturum.ad); } },
          yazDurum: yazSesDurum
        });
      } catch (e) {}
    }
    aktifBaglamGoster();
    sesHedefGoster();
    if (btnSesOnayla) btnSesOnayla.onclick = async () => {
      if (sesBekleyenBaglam && (!sesBekleyen || btnSesOnayla.textContent.indexOf("indir") >= 0 || btnSesOnayla.textContent.indexOf("aç") >= 0)) {
        try {
          if (btnSesOnayla.textContent.indexOf("indir") >= 0) {
            await isaretlileriIndir();
            if (sesBekleyenBaglam) aktifBaglamAyarla(sesBekleyenBaglam);
            sesBekleyenBaglam = null;
            yazSesDurum("İndirme bitti. Aktif bağlam duruyor; şimdi yalnız okul no ve soruları söyleyin.", false);
            aktifBaglamGoster();
            return;
          }
          const skor = sesBekleyen;
          await baglamUygula(sesBekleyenBaglam, skor);
        } catch (e) { yazSesDurum("Bağlam açılamadı: " + (e && e.message || e), true); }
        return;
      }
      if (!sesBekleyen || !sesBekleyen.length) return yazSesDurum("Onaylanacak bir komut yok.", true);
      await yazSesKayitlari(sesBekleyen);
    };
    if (btnSesVaz) btnSesVaz.onclick = () => { onizlemeGizle(); yazSesDurum("Bekleyen kayıtlar iptal edildi. Yazılmış olanlar ve Kaydet duruyor.", false); };
    if (btnAktar) btnAktar.onclick = async () => {
      try {
        if (!(await kvkkOk())) return yazDurum('KVKK onayı olmadan çalışmaz.');
        const sayfa = OyssNot.sayfaOku(window);
        if (!sayfa || !sayfa.satirlar.length) return yazDurum('Bu şubede OYSS tablosu yok. Öğrenci Listesi Yükle\'ye basın veya seçilen şubeleri Excel\'e aktarın.');
        const g = [{
          sube: sayfa.sube, sinav: sayfa.sinav,
          ogrenciler: sayfa.satirlar.map((s) => ({ no: s.no, ad: s.ad })),
        }];
        const msg = await aktarGruplar(g, OyssNot.dosyaAdiSube(g[0]));
        yazDurum(msg, ozetGruplar(g));
      } catch (e) { yazDurum('Aktarılamadı: ' + (e && e.message || e), (OyssNot.indirGunluk || []).slice(-10).map((g) => (g.ok ? 'TAMAM ' : 'HATA ') + (g.adim || '') + ' ' + (g.ad || '') + ' ' + (g.hata || '')).join('\n'), true); }
    };
    if (btnTani) btnTani.onclick = async () => {
      try {
        const metin = OyssNot.taniRaporu(window);
        let kopyalandi = false;
        try { await navigator.clipboard.writeText(metin); kopyalandi = true; } catch (e) {
          try {
            const ta = document.createElement('textarea');
            ta.value = metin; ta.style.position = 'fixed'; ta.style.left = '-9999px';
            document.body.appendChild(ta); ta.select();
            kopyalandi = document.execCommand('copy');
            ta.remove();
          } catch (e2) {}
        }
        let ek = metin;
        try {
          const sw = await chrome.runtime.sendMessage({ tip: 'oyss-indir-gunluk' });
          if (sw && sw.gunluk && sw.gunluk.length) {
            ek += '\n\n— İndirme günlüğü (service worker) —\n' + sw.gunluk.map((g) => '  ' + JSON.stringify(g)).join('\n');
          }
        } catch (e3) { ek += '\n(SW günlüğü alınamadı: ' + (e3 && e3.message || e3) + ')'; }
        yazDurum(kopyalandi ? 'Tanı raporu panoya kopyalandı (öğrenci verisi yok). Yapıştırmayı bana gönderin.' : 'Panoya kopyalanamadı; metni aşağıdan alın.', ek);
      } catch (e) { yazDurum('Tanı raporu alınamadı: ' + (e && e.message || e), '', true); }
    };
    if (btnTest) btnTest.onclick = async () => {
      try {
        const r = await OyssNot.testIndir();
        const ok = r === true || (r && r.ok);
        const ad = (r && r.ad) || 'OYSS_test_indirme.xlsx';
        if (ok) yazDurum('Test indirme başladı: ' + ad);
        else yazDurum('Test indirme başarısız: ' + ((r && r.hata) || 'dosya inmedi. Tanı raporundaki indirme günlüğüne bakın.'), (r && r.hata) || '', true);
      } catch (e) { yazDurum('Test indirme hata: ' + (e && e.message || e), '', true); }
    };
    if (btnIptal) btnIptal.onclick = () => { iptal = true; };
    if (btnTum) btnTum.onclick = async () => {
      iptal = false;
      if (btnIptal) btnIptal.hidden = false;
      btnTum.disabled = true;
      window.__ngaOyssCalisiyor = true;
      try {
        if (!(await kvkkOk())) return yazDurum('KVKK onayı olmadan çalışmaz.');
        const sec = secilenSubeler();
        if (!sec.length) { yazDurum('Hiç şube seçilmedi. Listeden en az bir şube işaretleyin veya Sayfadan oku\'ya basın.'); return; }
        const sonuc = await OyssNot.tumSubeleriCek(window, {
          hiz: (hizSel && hizSel.value) || 'hizli',
          secilenSubeler: sec,
          yalnizOyss: yalnizOyss(),
          iptal: () => iptal,
          ilerleme: (q) => yazDurum('OYSS: ' + (q.mesaj || ''), ''),
        });
        const ek = hataOzet(sonuc);
        if (sonuc.gruplar.length) {
          const msg = await aktarGruplar(sonuc.gruplar);
          const bas = sonuc.hatalar && sonuc.hatalar.length ? ('Kısmen tamam. İlk hata: ' + sonuc.hatalar[0] + ' ') : '';
          yazDurum(bas + msg, ozetGruplar(sonuc.gruplar) + (ek ? '\n\n' + ek : ''));
        } else {
          yazDurum('Hiç öğrenci listesi alınamadı. ' + (sonuc.hatalar[0] || sonuc.atlanan[0] || 'Adımı kontrol edin.'), ek, true);
        }
      } catch (e) { yazDurum('Excel\'e aktarma durdu: ' + (e && e.message || e), (OyssNot.indirGunluk || []).slice(-10).map((g) => (g.ok ? 'TAMAM ' : 'HATA ') + (g.adim || '') + ' ' + (g.hata || '')).join('\n'), true); }
      finally {
        window.__ngaOyssCalisiyor = false;
        if (btnIptal) btnIptal.hidden = true;
        btnTum.disabled = false;
      }
    };
    if (btnYukle) btnYukle.onclick = () => dosya.click();
    dosya.onchange = async () => {
      const files = [...(dosya.files || [])]; dosya.value = '';
      if (!files.length) return;
      try {
        const aday = [];
        for (const f of files) aday.push({ ad: f.name, buf: await f.arrayBuffer() });
        iceOzet = await OyssNot.excelDosyalariOzet(aday);
        gruplar = iceOzet.gruplar;
        const dosyaHata = (iceOzet.dosyalar || []).filter((d) => d.hata);
        if (!gruplar.length && dosyaHata.length) throw new Error(dosyaHata.map((d) => d.ad + ': ' + d.hata).join('; '));
        if (!gruplar.length) throw new Error('Dosyalarda AYAR/NOTLAR veya şube-ders sayfası bulunamadı.');
        if (!iceOzet.coklu) {
          yazDurum(gruplar.length + ' grup yüklendi (yalnız bu oturum, depolanmaz). e-Okul\'a yaz, açık şube/ders ile eşleşeni kullanır.', ozetGruplar(gruplar));
        } else {
          const dolu = (iceOzet.dosyalar || []).reduce((n, d) => n + (d.dolu || []).length, 0);
          const bos = (iceOzet.dosyalar || []).reduce((n, d) => n + (d.bos || []).length, 0);
          const plan = OyssNot.icePlan(iceOzet);
          yazDurum(iceOzet.dosyalar.length + ' dosya yüklendi: ' + dolu + ' dolu ders işlenecek, ' + bos + ' boş ders atlanacak. e-Okul\'a yaz dosyaları sırayla işler.', OyssNot.iceOzetMetin(plan) + (dosyaHata.length ? '\n' + dosyaHata.map((d) => 'HATA ' + d.ad + ': ' + d.hata).join('\n') : ''));
        }
      } catch (e) { gruplar = null; iceOzet = null; yazDurum('Excel okunamadı: ' + (e && e.message || e), '', true); }
    };
    if (btnYaz) btnYaz.onclick = async () => {
      try {
        if (!(await kvkkOk())) return yazDurum('KVKK onayı olmadan çalışmaz.');
        if (!gruplar || !gruplar.length) return yazDurum('Önce doldurulmuş Excel\'i yükleyin (bir veya birden çok dosya, zip veya tek kitap).');
        const hiz = (hizSel && hizSel.value) || 'hizli';
        if (iceOzet && iceOzet.coklu) {
          const plan = OyssNot.icePlan(iceOzet);
          const sonuclar = plan.filter((p) => p.durum !== 'bekliyor').map((p) => ({ durum: p.durum, dosya: p.dosya, sube: p.sube, ders: p.ders, neden: p.neden }));
          const sira = plan.filter((p) => p.durum === 'bekliyor');
          if (!sira.length) {
            OyssNot.iceKaydet(sonuclar);
            return yazDurum('İşlenecek dolu ders sayfası yok.', OyssNot.iceOzetMetin(sonuclar), sonuclar.some((x) => x.durum === 'hata'));
          }
          window.__ngaOyssCalisiyor = true;
          if (btnIptal) btnIptal.hidden = false;
          try {
            for (let i = 0; i < sira.length; i++) {
              if (window.__ngaOyssIptal) {
                sonuclar.push({ durum: 'hata', dosya: sira[i].dosya, sube: sira[i].sube, ders: sira[i].ders, neden: 'İptal edildi' });
                for (let j = i + 1; j < sira.length; j++) sonuclar.push({ durum: 'atlandi', dosya: sira[j].dosya, sube: sira[j].sube, ders: sira[j].ders, neden: 'İptal' });
                break;
              }
              const g = sira[i].grup;
              yazDurum((i + 1) + '/' + sira.length + ' işleniyor: ' + (sira[i].dosya || '') + ' — ' + (g.sube || '') + ' / ' + (g.ders || ''), OyssNot.iceOzetMetin(sonuclar.concat([{ durum: 'bekliyor', dosya: sira[i].dosya, sube: g.sube, ders: g.ders, neden: 'yazılıyor' }])));
              try {
                const haz = await OyssNot.sayfaHazirla(window, g, { hiz });
                if (!haz.ok) { sonuclar.push({ durum: 'hata', dosya: sira[i].dosya, sube: g.sube || '', ders: g.ders || '', neden: haz.hata || 'Sayfa hazırlanamadı' }); continue; }
                const sayfa = haz.sayfa || OyssNot.sayfaOku(window);
                if (!sayfa || !sayfa.sorular || !sayfa.sorular.length) {
                  sonuclar.push({ durum: 'hata', dosya: sira[i].dosya, sube: g.sube || '', ders: g.ders || '', neden: 'OYSS soru tablosu yok' });
                  continue;
                }
                const r = await OyssNot.yazVeKaydet(window, g, { hiz });
                if (r.kaydedildi) sonuclar.push({ durum: 'islendi', dosya: sira[i].dosya, sube: g.sube || '', ders: g.ders || '', yazilan: r.yazilan, neden: 'Kaydet\'e basıldı' });
                else sonuclar.push({ durum: 'hata', dosya: sira[i].dosya, sube: g.sube || '', ders: g.ders || '', neden: (r.hatalar && r.hatalar[0]) || 'Kaydet\'e basılmadı.' });
              } catch (e) {
                sonuclar.push({ durum: 'hata', dosya: sira[i].dosya, sube: g.sube || '', ders: g.ders || '', neden: (e && e.message) || String(e) });
              }
            }
          } finally {
            window.__ngaOyssCalisiyor = false;
            window.__ngaOyssIptal = false;
            if (btnIptal) btnIptal.hidden = true;
          }
          OyssNot.iceKaydet(sonuclar);
          const ozet = OyssNot.iceOzetMetin(sonuclar);
          const nH = sonuclar.filter((x) => x.durum === 'hata').length;
          const nI = sonuclar.filter((x) => x.durum === 'islendi').length;
          yazDurum('Çoklu yazım bitti: ' + nI + ' işlendi, ' + sonuclar.filter((x) => x.durum === 'atlandi').length + ' atlandı, ' + nH + ' hata.', ozet, nH > 0);
          return;
        }
        let sayfa = OyssNot.sayfaOku(window);
        let g = OyssNot.grupSec(gruplar, sayfa);
        if (!g && sayfa && sayfa.sube) {
          const ayni = gruplar.filter((x) => OyssNot.katla(x.sube) === OyssNot.katla(sayfa.sube));
          if (ayni.length === 1) g = ayni[0];
        }
        if (!g) return yazDurum('Yüklenen Excel açık şube/ders ile eşleşmedi. Doğru dosyayı yükleyin veya o şubeyi e-Okul\'da açın.', ozetGruplar(gruplar) + '\nAçık: ' + ((sayfa && sayfa.sube) || '—') + ' / ' + ((sayfa && sayfa.ders) || '—'));
        const haz = await OyssNot.sayfaHazirla(window, g, { hiz });
        if (!haz.ok) return yazDurum('Sayfa hazırlanamadı: ' + (haz.hata || ''), ozetGruplar([g]));
        sayfa = haz.sayfa || OyssNot.sayfaOku(window);
        if (!sayfa || !sayfa.sorular || !sayfa.sorular.length) return yazDurum('OYSS soru tablosu yok. Ders ve sınav seçilip Öğrenci Listesi Yükle denendi; tablo gelmedi. Ders notu (OOK07003) sayfasında bu düğme Kaydet\'e basmaz.');
        const r = await OyssNot.yazVeKaydet(window, g, { hiz });
        yazDurum(r.kaydedildi ? ('Yazıldı ve Kaydet\'e basıldı (' + (g.sube || '') + ' / ' + (g.ders || '') + ').') : (r.ok === false ? 'Kaydet\'e basılmadı.' : 'Tamamlandı.'), OyssNot.raporMetin(r));
      } catch (e) { yazDurum('Yazılamadı: ' + (e && e.message || e), '', true); }
    };
  }
  kok.NGAOyssBagla = bagla;
  kok.NGAOyssHTML = oyssHTML;
})(typeof globalThis !== 'undefined' ? globalThis : this);
