// 1.6.17 Sesli not girişi (e-Okul Pro sesli devamsızlık yaklaşımı). Web Speech API (tr-TR); veri bu bilgisayarda kalır (ses tanımayı Chrome'un kendi hizmeti yapar).
// "12 numara 85", "on iki numara seksen beş", "Ayşe Yılmaz 85", "12 numara girmedi" -> satır bulunur, puan seçili sütuna daktilo gibi yazılır, satır vurgulanır.
// Kaydet'e ve Güvenlik Kodu'na ASLA dokunmaz.
(function (kok) {
  'use strict';
  const BIR = { sifir: 0, bir: 1, iki: 2, uc: 3, dort: 4, bes: 5, alti: 6, yedi: 7, sekiz: 8, dokuz: 9 };
  const ON = { on: 10, yirmi: 20, otuz: 30, kirk: 40, elli: 50, altmis: 60, yetmis: 70, seksen: 80, doksan: 90 };
  const SAYI_SOZ = ['altmis', 'yetmis', 'seksen', 'doksan', 'yirmi', 'otuz', 'kirk', 'elli', 'sifir', 'dort', 'yedi', 'sekiz', 'dokuz', 'alti', 'bes', 'bir', 'iki', 'uc', 'yuz', 'bin', 'on'];
  const sade = s => String(s || '').replace(/I/g, 'ı').replace(/İ/g, 'i').toLowerCase().replace(/ı/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c').replace(/i̇/g, 'i');
  function birlesikSayiAyir(token) {
    const s = String(token || '');
    if (!s || /^\d+$/.test(s)) return null;
    const out = [];
    let i = 0;
    while (i < s.length) {
      let hit = '';
      for (let k = 0; k < SAYI_SOZ.length; k++) { const w = SAYI_SOZ[k]; if (s.indexOf(w, i) === i) { hit = w; break; } }
      if (!hit) return null;
      out.push(hit);
      i += hit.length;
    }
    return out.length ? out : null;
  }
  // sözcükle sayılar -> rakam; "on iki seksen beş" iki ayrı sayı (12, 85) olur
  // "4 bin 250" / "dörtbinikiyüzelli" tek sayı (4250) olur; rakam-rakam ve ikili birleşim okul no'da yapılır
  function sayilar(metin) {
    const ham = sade(metin).replace(/[.,;:!?]+/g, ' ').replace(/(\d)\s*-\s*(\d)/g, '$1 $2');
    const t = [];
    ham.split(/\s+/).filter(Boolean).forEach((raw) => {
      const parca = (!/^\d+$/.test(raw) && !(raw in BIR) && !(raw in ON) && raw !== 'yuz' && raw !== 'bin') ? birlesikSayiAyir(raw) : null;
      if (parca) t.push.apply(t, parca); else t.push(raw);
    });
    const cik = [];
    let ara = 0, top = 0, var_ = false, son = '';
    const bitir = () => { if (var_) cik.push(String(top + ara)); ara = 0; top = 0; var_ = false; son = ''; };
    for (const w of t) {
      if (w in BIR) { if (var_ && (ara % 10) !== 0) bitir(); ara += BIR[w]; var_ = true; son = 'bir'; }
      else if (w in ON) { if (var_ && (ara % 100) !== 0) bitir(); ara += ON[w]; var_ = true; son = 'on'; }
      else if (w === 'yuz') { if (var_ && ara >= 100) bitir(); ara = (ara || 1) * 100; var_ = true; son = 'yuz'; }
      else if (w === 'bin') { if (top) bitir(); top = (ara || 1) * 1000; ara = 0; var_ = true; son = 'bin'; }
      else if (/^\d+$/.test(w)) {
        const n = +w;
        if (var_ && (son === 'bin' || son === 'yuz') && n < (son === 'bin' ? 1000 : 100)) { ara += n; son = 'say'; }
        else if (!var_) { ara = n; var_ = true; son = 'say'; }
        else { bitir(); ara = n; var_ = true; son = 'say'; }
      }
      else { bitir(); cik.push(w); }
    }
    bitir(); return cik;
  }
  function okulNoTopla(w, i) {
    if (!/^\d+$/.test(w[i])) return null;
    if (w[i + 1] === 'soru' || w[i + 1] === 'sorusu') return null;
    if (w[i].length >= 3) return { no: String(+w[i]), atla: 1 };
    const parts = [w[i]];
    let j = i + 1;
    while (j < w.length && /^\d+$/.test(w[j]) && w[j].length <= 2) {
      if (w[j + 1] === 'soru' || w[j + 1] === 'sorusu') break;
      if (parts.join('').length >= 5) break;
      parts.push(w[j]);
      j++;
      if (parts.join('').length >= 4) {
        if (parts.join('').length === 4 && j < w.length && /^\d+$/.test(w[j]) && w[j].length === 1 && w[j + 1] !== 'soru' && w[j + 1] !== 'sorusu') { parts.push(w[j]); j++; }
        break;
      }
    }
    return { no: String(+parts.join('')), atla: parts.length };
  }
  const GIRMEDI = /^(girmedi|gelmedi|yok|g|gir)$/;
  // komut -> [{no?, ad?, puan}] ; hatalar: anlaşılmayan parçalar
  function ayristir(metin) {
    const w = sayilar(metin), cikti = [], hatalar = []; let ref = [], noMu = false;
    const ekle = (puan) => { const r = { puan };
      if (noMu || (ref.length === 1 && /^\d+$/.test(ref[0]))) r.no = ref.find(x => /^\d+$/.test(x)) || ''; else r.ad = ref.filter(x => !/^\d+$/.test(x)).join(' ');
      if (!r.no && !r.ad) hatalar.push('öğrenci yok (' + puan + ')'); else cikti.push(r); ref = []; noMu = false; };
    for (let i = 0; i < w.length; i++) { const x = w[i];
      if (/^(numara|numarali|no|nolu|numarasi)$/.test(x)) { noMu = true; continue; }
      if (/^(puan|not|notu|aldi|ve|virgul|sonraki|tamam)$/.test(x)) continue;
      if (GIRMEDI.test(x) && ref.length) { ekle('G'); continue; }
      if (/^\d+$/.test(x)) {
        if (!ref.length) { ref.push(x); continue; }          // ilk sayı öğrenci numarası
        if (ref.length === 1 && /^\d+$/.test(ref[0]) && !noMu && i + 1 < w.length && /^(numara|numarali|no|nolu)$/.test(w[i + 1])) { hatalar.push(ref[0]); ref = [x]; continue; }
        ekle(x); continue; }
      ref.push(x);
    }
    if (ref.length) hatalar.push(ref.join(' ') + ' (puan yok)');
    return { satirlar: cikti, hatalar };
  }
  const gecerli = p => p === 'G' || (/^\d{1,3}$/.test(String(p)) && +p >= 0 && +p <= 100);
  function adBenzer(a, b) { a = sade(a).replace(/[^a-z ]/g, '').trim(); b = sade(b).replace(/[^a-z ]/g, '').trim(); if (!a || !b) return 0;
    const lev = (x, y) => { let p = [...Array(y.length + 1).keys()]; for (let i = 1; i <= x.length; i++) { const c = [i]; for (let j = 1; j <= y.length; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1)); p = c; } return p[y.length]; };
    const ta = a.split(/\s+/), tb = b.split(/\s+/); let top = 0; ta.forEach(q => { let en = 0; tb.forEach(v => { en = Math.max(en, 1 - lev(q, v) / Math.max(q.length, v.length)); }); top += en; });
    return top / ta.length * (ta.length >= 2 ? 1 : 0.9); }
  // ogrenciler: [{no, ad}] -> {o, neden}
  function bul(ogrenciler, s) {
    if (s.no) { const o = ogrenciler.find(x => String(x.no) === String(+s.no)) || ogrenciler.find(x => String(x.no) === s.no); return o ? { o } : { neden: s.no + ' numara listede yok' }; }
    const sk = ogrenciler.map(o => ({ o, p: adBenzer(s.ad, o.ad) })).sort((a, b) => b.p - a.p);
    if (!sk.length || sk[0].p < 0.75) return { neden: 'ad listede bulunamadı' };
    if (sk[1] && sk[0].p - sk[1].p < 0.1) return { neden: 'ad birden çok öğrenciye benziyor; numarayla söyleyin' };
    return { o: sk[0].o };
  }
  // 1.9.13 OYSS ses: "okul no 4255, 1. soru 5, 2. soru 10" / "okul no 4255 girmedi"
  const SIRA_SOZ = [
    ["on besinci", "15"], ["on dorduncu", "14"], ["on ucuncu", "13"],
    ["on ikinci", "12"], ["on birinci", "11"], ["onuncu", "10"],
    ["dokuzuncu", "9"], ["sekizinci", "8"], ["yedinci", "7"],
    ["altinci", "6"], ["besinci", "5"], ["dorduncu", "4"],
    ["ucuncu", "3"], ["ikinci", "2"], ["birinci", "1"]
  ];
  const KAT_ESLE = [
    { kat: "Özel Eğitim İhtiyacı Olan Öğrenci", soz: ["ozel egitim ihtiyaci olan ogrenci", "ozel egitim ihtiyaci", "ozel egitim", "ozel ogrenci"] },
    { kat: "Sınava Girmedi", soz: ["sinava girmedi", "girmedi", "gelmedi"] },
    { kat: "Sınava Girdi", soz: ["sinava girdi", "katildi", "geldi", "girdi"] },
    { kat: "Kopya", soz: ["kopya cekti", "kopya"] },
    { kat: "Muaf", soz: ["muaf"] }
  ];
  function katilimSozcu(w, i) {
    const rest = w.slice(i).join(" ");
    for (const k of KAT_ESLE) {
      for (const sz of k.soz) {
        if (rest === sz || rest.startsWith(sz + " ")) return { kat: k.kat, atla: sz.split(" ").length };
      }
    }
    if (w[i] === "yok") return { kat: "Sınava Girmedi", atla: 1 };
    return null;
  }
  function ayristirOyss(metin) {
    let ham = sade(metin);
    for (const [a, b] of SIRA_SOZ) ham = ham.replace(new RegExp("\\b" + a + "\\b", "g"), b);
    ham = ham.replace(/\b(\d{1,2})\s*(inci|nci|uncu|uncu|\.)\b/g, "$1");
    const w = sayilar(ham), satirlar = [], hatalar = [];
    let cur = null, expectNo = false, pendingSoru = 0;
    const yeni = (no) => { cur = { no: String(no).replace(/^0+/, "") || "0", puan: {}, katilim: "" }; satirlar.push(cur); expectNo = false; pendingSoru = 0; };
    for (let i = 0; i < w.length; i++) {
      const x = w[i], next = w[i + 1] || "", once = w[i - 1] || "";
      if (/^(okul|numara|numarali|numarasi|no|nolu)$/.test(x)) { expectNo = true; continue; }
      if (/^(puan|puani|not|notu|ve|virgul|sonraki|tamam|olarak|ile)$/.test(x)) continue;
      if (/^(katilim|secenek|durum|secenegi)$/.test(x)) continue;
      const kat = katilimSozcu(w, i);
      if (kat) {
        if (!cur) hatalar.push("katılım için okul no yok (" + kat.kat + ")");
        else cur.katilim = kat.kat;
        i += kat.atla - 1;
        continue;
      }
      if (x === "soru" || x === "sorusu") continue;
      if (/^\d+$/.test(x)) {
        if (next === "soru" || next === "sorusu") { pendingSoru = +x; continue; }
        if ((once === "soru" || once === "sorusu") && !pendingSoru) { pendingSoru = +x; continue; }
        if (pendingSoru) {
          if (pendingSoru < 1 || pendingSoru > 15) { hatalar.push("soru no geçersiz: " + pendingSoru); pendingSoru = 0; continue; }
          if (!cur) { hatalar.push(pendingSoru + ". soru için okul no yok"); pendingSoru = 0; continue; }
          cur.puan[pendingSoru] = x; pendingSoru = 0; continue;
        }
        if (expectNo || !cur) {
          const paket = okulNoTopla(w, i);
          if (paket) { yeni(paket.no); i += paket.atla - 1; continue; }
          yeni(x); continue;
        }
        hatalar.push("anlaşılmayan sayı: " + x);
        continue;
      }
      if (x) hatalar.push(x);
    }
    if (pendingSoru) hatalar.push(pendingSoru + ". sorunun puanı yok");
    if (!satirlar.length) hatalar.push("okul no bulunamadı");
    return { satirlar, hatalar };
  }

  const DERS_SES = [
    ["turk dili ve edebiyati", "Türk Dili ve Edebiyatı"],
    ["turk dili", "Türk Dili ve Edebiyatı"],
    ["edebiyat", "Türk Dili ve Edebiyatı"],
    ["tde", "Türk Dili ve Edebiyatı"],
    ["fen bilimleri", "Fen Bilimleri"],
    ["sosyal bilgiler", "Sosyal Bilgiler"],
    ["din kulturu ve ahlak bilgisi", "Din Kültürü ve Ahlak Bilgisi"],
    ["din kulturu", "Din Kültürü ve Ahlak Bilgisi"],
    ["dkab", "Din Kültürü ve Ahlak Bilgisi"],
    ["turkce", "Türkçe"],
    ["matematik", "Matematik"],
    ["ingilizce", "İngilizce"],
    ["fen", "Fen Bilimleri"],
    ["sosyal", "Sosyal Bilgiler"],
    ["din", "Din Kültürü ve Ahlak Bilgisi"],
    ["fizik", "Fizik"],
    ["kimya", "Kimya"],
    ["biyoloji", "Biyoloji"],
    ["tarih", "Tarih"],
    ["cografya", "Coğrafya"],
    ["felsefe", "Felsefe"]
  ];
  function metindenParca(ham, sadeHedef) {
    const raw = String(ham || "");
    const hedef = String(sadeHedef || "").trim();
    if (!hedef) return "";
    const tokens = raw.split(/[\s,./_-]+/).filter(Boolean);
    const hedefP = hedef.split(/\s+/).filter(Boolean);
    for (let i = 0; i < tokens.length; i++) {
      const acc = [];
      for (let j = i; j < tokens.length; j++) {
        acc.push(tokens[j]);
        const accS = sade(acc.join(" ")).replace(/[-_/]+/g, " ").trim();
        if (accS === hedef) return acc.join(" ");
        if (accS.length > hedef.length + 2) break;
      }
    }
    return sadeHedef;
  }
  function sesYaziNorm(t) { return String(t || "").replace(/\s+/g, " ").trim(); }
  function sesDurumMetniMi(t) {
    const k = sade(t);
    return /sesli not durduruldu|biriken metin panelde|sesli not penceresi kapandi|dinliyorum \(surekli\)|mikrofon izni|hedef:/.test(k);
  }
  function sesMetinAyikla(t) {
    let s = String(t || "");
    s = s.replace(/sesli not penceresi kapandı[.!]*/gi, " ");
    s = s.replace(/sesli not durduruldu[.!]*/gi, " ");
    s = s.replace(/biriken metin panelde duruyor[.!]*/gi, " ");
    s = s.replace(/dinliyorum\s*\(sürekli\)[.!]*/gi, " ");
    s = s.replace(/onaylamadan yazılmaz[.!]*/gi, " ");
    s = s.replace(/\bhedef\b[:\s]*/gi, " ");
    return s.replace(/\s+/g, " ").trim();
  }
  function sesAlanMakul(a) {
    const t = sesYaziNorm(a);
    if (!t || t.length > 40) return "";
    if (sesDurumMetniMi(t)) return "";
    if (/hedef|durduruldu|biriken|dinliyorum|duyulan|panelde/.test(sade(t))) return "";
    return t;
  }
  function sesFinalDedupEkle(parcalar, yeni) {
    const t = sesYaziNorm(sesMetinAyikla(yeni));
    if (!t || sesDurumMetniMi(t)) return (parcalar || []).slice();
    const arr = (parcalar || []).slice();
    const last = sesYaziNorm(arr[arr.length - 1] || "");
    if (!last) { arr.push(t); return arr; }
    if (t === last) return arr;
    const a = sade(t), b = sade(last);
    if (a === b) return arr;
    if (t.indexOf(last) === 0 || a.indexOf(b) === 0) { arr[arr.length - 1] = t; return arr; }
    if (last.indexOf(t) === 0 || b.indexOf(a) === 0) return arr;
    if (last.endsWith(t) || t.endsWith(last) || b.endsWith(a) || a.endsWith(b)) {
      if (t.length > last.length) arr[arr.length - 1] = t;
      return arr;
    }
    for (let n = Math.min(a.length, b.length); n >= 8; n--) {
      if (b.slice(-n) === a.slice(0, n)) {
        arr[arr.length - 1] = last + t.slice(t.length - (a.length - n));
        return arr;
      }
    }
    arr.push(t);
    return arr;
  }
  function sesTanimaAdim(durum, ev) {
    const d = {
      parcalar: (durum && Array.isArray(durum.parcalar)) ? durum.parcalar.slice() : [],
      sira: (durum && durum.sira) || 0,
      biriken: (durum && durum.biriken) || "",
      ara: ""
    };
    if (!ev) { d.biriken = d.parcalar.join(" ").replace(/\s+/g, " ").trim(); return d; }
    const results = ev.results || [];
    const bas = (typeof ev.resultIndex === "number" && ev.resultIndex >= 0) ? ev.resultIndex : 0;
    let ara = "";
    for (let i = bas; i < results.length; i++) {
      const r = results[i] || {};
      const text = sesYaziNorm((r[0] && r[0].transcript) || r.transcript || "");
      if (!text) continue;
      if (r.isFinal) d.parcalar = sesFinalDedupEkle(d.parcalar, text);
      else ara += (ara ? " " : "") + text;
    }
    d.sira = d.parcalar.length;
    d.biriken = d.parcalar.join(" ").replace(/\s+/g, " ").trim();
    d.ara = sesYaziNorm(ara);
    return d;
  }
  function ayristirBaglam(metin) {
    const hamGelen = sesMetinAyikla(metin);
    let ham = sade(hamGelen).replace(/[-_/'`´]+/g, " ");
    for (const [a, b] of SIRA_SOZ) ham = ham.replace(new RegExp("\\b" + a + "\\b", "g"), b);
    ham = ham.replace(/\b(\d{1,2})\s*\./g, "$1 ").replace(/\b(\d{1,2})\s*(inci|nci|uncu)\b/g, "$1");
    const sirali = DERS_SES.slice().sort((x, y) => y[0].length - x[0].length);
    let ders = "", dersBas = -1, dersUz = 0;
    for (const [k, d] of sirali) {
      const re = new RegExp("\\b" + k + "\\b", "g");
      let m;
      while ((m = re.exec(ham))) {
        if (m.index >= dersBas) { ders = d; dersBas = m.index; dersUz = m[0].length; }
      }
    }
    const dersKelime = new Set();
    DERS_SES.forEach(([k]) => k.split(/\s+/).forEach((w) => { if (w && w !== "ve" && w !== "ile") dersKelime.add(w); }));
    const w = sayilar(ham);
    const atla = /^(sinif|sinifi|sube|subesi|subesinin|alan|alani|bolum|bolumu|ve|ile)$/;
    const skorBas = /^(okul|numara|numarali|numarasi|nolu)$/;
    const gurultu = /^(hedef|sesli|not|durduruldu|biriken|metin|panelde|duruyor|dinliyorum|duyulan|anlik|surekli|mikrofon|kaydet|basilir|basilmaz|aktif|baglam|onizleme|anlasilan|pencere|kapandi|dersi|soyleyin)$/;
    const katilimMi = (x) => !!(komutSozcu(x) || /^(girmedi|gelmedi|yok|girdi|muaf|kopya|ozel|egitim|ihtiyaci|olan|ogrenci)$/.test(x));
    let last = { sinif: null, harf: "", alanToks: [] };
    let curSinif = null, curHarf = "", after = [];
    const kaydet = () => {
      if (curSinif != null && curHarf) last = { sinif: curSinif, harf: curHarf, alanToks: after.slice() };
    };
    for (const x of w) {
      if (skorBas.test(x) || komutSozcu(x)) break;
      if (atla.test(x) || katilimMi(x) || gurultu.test(x) || dersKelime.has(x)) continue;
      if (/^(5|6|7|9|10|11)$/.test(x)) { kaydet(); curSinif = +x; curHarf = ""; after = []; continue; }
      if (/^[a-f]$/.test(x) && curSinif != null) { kaydet(); curHarf = x.toUpperCase(); after = []; continue; }
      if (!/^\d+$/.test(x)) after.push(x);
    }
    kaydet();
    const harfSade = last.harf ? sade(last.harf) : "";
    const ozet = [];
    for (const x of last.alanToks) {
      if (!x || x.length < 2) continue;
      if (harfSade && x === harfSade) continue;
      const prev = ozet[ozet.length - 1];
      if (!prev) { ozet.push(x); continue; }
      if (x === prev) continue;
      if (x.indexOf(prev) === 0 || prev.indexOf(x) === 0) { ozet[ozet.length - 1] = x.length >= prev.length ? x : prev; continue; }
      ozet.push(x);
    }
    const subst = ozet.filter((x) => x.length >= 3);
    const alanSade = (subst.length ? subst : ozet).slice(-2).join(" ").trim().slice(0, 40);
    const alan = sesAlanMakul(alanSade ? metindenParca(hamGelen, alanSade) : "");
    let skorIx = w.findIndex((x) => skorBas.test(x) || komutSozcu(x));
    if (skorIx < 0) skorIx = w.length;
    const kalan2 = w.slice(skorIx);
    const sinif = last.sinif, harf = last.harf;
    const kisim = sinif != null && !!harf;
    const ok = kisim && !!ders;
    return { ok, kisim, sinif, harf, alan, ders, kalan: kalan2.join(" "), ham: String(hamGelen || "") };
  }
  function baglamEtiket(b) {
    if (!b) return "";
    const parca = [];
    if (b.sinif != null && b.harf) parca.push(b.sinif + "/" + b.harf);
    else if (b.sinif != null) parca.push(String(b.sinif));
    else if (b.harf) parca.push(b.harf);
    const ders = b.ders ? String(b.ders).trim() : "";
    const alan = sesAlanMakul(b.alan);
    let et = parca[0] || "";
    if (et && ders) et += " – " + ders;
    else if (ders) et = ders;
    if (et && alan) et += " (" + alan.replace(/(^|[\s-])(\S)/g, (_, a, c) => a + c.toLocaleUpperCase("tr-TR")) + ")";
    return et;
  }
  function baglamYapistir(onceki, gelen) {
    const bos = { ok: false, kisim: false, sinif: null, harf: "", alan: "", ders: "", kalan: "", ham: "" };
    const o = onceki ? Object.assign({}, bos, onceki) : Object.assign({}, bos);
    o.alan = sesAlanMakul(o.alan);
    if (!gelen) {
      o.kisim = o.sinif != null && !!o.harf;
      o.ok = o.kisim && !!o.ders;
      return o;
    }
    if (gelen.kisim) {
      o.sinif = gelen.sinif;
      o.harf = gelen.harf;
      o.alan = sesAlanMakul(gelen.alan) || "";
      o.ders = gelen.ders || "";
      o.ham = gelen.ham ? sesMetinAyikla(gelen.ham) : o.ham;
      o.kalan = gelen.kalan || "";
    } else {
      const a = sesAlanMakul(gelen.alan);
      if (a) o.alan = a;
      if (gelen.ders) o.ders = gelen.ders;
      if (gelen.ham) o.ham = sesMetinAyikla(gelen.ham);
      if (gelen.kalan) o.kalan = gelen.kalan;
    }
    o.kisim = o.sinif != null && !!o.harf;
    o.ok = o.kisim && !!o.ders;
    return o;
  }

  function komutSozcu(x) {
    const k = sade(x).replace(/[^a-z]/g, "");
    if (/^(onayla|onayliyorum|onay|tamam)$/.test(k)) return "onay";
    if (/^(iptal|sil|vazgec)$/.test(k)) return "iptal";
    return "";
  }
  function sesParcaEkle(durum, paket) {
    const d = {
      parcalar: (durum && Array.isArray(durum.parcalar)) ? durum.parcalar.slice() : [],
      sira: (durum && durum.sira) || 0,
      biriken: (durum && durum.biriken) || ""
    };
    if (!paket) { d.biriken = d.parcalar.join(" ").replace(/\s+/g, " ").trim(); return d; }
    if (paket.final === false && !(Array.isArray(paket.parcalar) && paket.parcalar.length)) {
      d.biriken = d.parcalar.join(" ").replace(/\s+/g, " ").trim();
      return d;
    }
    if (Array.isArray(paket.parcalar) && paket.parcalar.length) {
      let p = [];
      paket.parcalar.forEach((tx) => { p = sesFinalDedupEkle(p, tx); });
      const sira = paket.sira || p.length;
      if (sira >= d.sira || p.length >= d.parcalar.length) {
        d.parcalar = p;
        d.sira = Math.max(d.sira, sira);
      } else {
        p.forEach((tx) => { d.parcalar = sesFinalDedupEkle(d.parcalar, tx); });
        d.sira = Math.max(d.sira, sira, d.parcalar.length);
      }
    } else if (paket.t && !sesDurumMetniMi(paket.t)) {
      const s = paket.sira || (d.sira + 1);
      if (s >= d.sira) {
        d.parcalar = sesFinalDedupEkle(d.parcalar, paket.t);
        d.sira = Math.max(s, d.parcalar.length);
      }
    }
    d.biriken = d.parcalar.join(" ").replace(/\s+/g, " ").trim();
    return d;
  }
  function sesAkisOlaylari(metin) {
    const ham = sade(metin).replace(/[-_/]+/g, " ");
    const w = sayilar(ham);
    const olaylar = [];
    let i = 0;
    while (i < w.length) {
      const k = komutSozcu(w[i]);
      if (k) { olaylar.push({ tur: k }); i++; continue; }
      let j = i + 1;
      while (j < w.length && !komutSozcu(w[j])) j++;
      const parca = w.slice(i, j).join(" ");
      const b = ayristirBaglam(parca);
      let skor = parca;
      if (b && b.kisim) {
        olaylar.push({ tur: "baglam", baglam: b });
        skor = b.kalan || "";
      }
      if (skor && skor.trim()) {
        const a = ayristirOyss(skor);
        (a.satirlar || []).forEach((s) => olaylar.push({ tur: "kayit", satir: s }));
        (a.hatalar || []).forEach((h) => {
          if (h === "okul no bulunamadı" && (a.satirlar || []).length) return;
          olaylar.push({ tur: "hata", hata: h });
        });
      }
      i = j;
    }
    return olaylar;
  }
  function sesAkisCoz(metin, oncekiBaglam) {
    const olaylar = sesAkisOlaylari(metin);
    let baglam = oncekiBaglam ? baglamYapistir(oncekiBaglam, null) : baglamYapistir(null, null);
    const kayitlar = [];
    const kuyruk = [];
    const hatalar = [];
    let onaySay = 0, iptalSay = 0;
    const flush = (onay) => {
      if (!kayitlar.length && !onay) return;
      kuyruk.push({ kayitlar: kayitlar.slice(), onay: !!onay });
    };
    for (const ev of olaylar) {
      if (ev.tur === "baglam") baglam = baglamYapistir(baglam, ev.baglam);
      else if (ev.tur === "kayit") kayitlar.push(ev.satir);
      else if (ev.tur === "iptal") { if (kayitlar.length) kayitlar.pop(); iptalSay++; }
      else if (ev.tur === "onay") { onaySay++; flush(true); kayitlar.length = 0; }
      else if (ev.tur === "hata") hatalar.push(ev.hata);
    }
    const beklemede = kayitlar.slice();
    if (beklemede.length) kuyruk.push({ kayitlar: beklemede, onay: false });
    return {
      baglam, olaylar, kuyruk, beklemede, onay: onaySay > 0, onaySay, iptalSay, hatalar,
      ham: String(metin || "")
    };
  }

  function noNormSes(no) { return String(no == null ? "" : no).replace(/\D/g, "").replace(/^0+/, "") || "0"; }
  function sesCanliOnMetin(metin) {
    let s = String(metin || "");
    const bol = s.split(/\b(?:okul\s+(?:numarası|numarasi|no|numara)|okul\s*no|numarası|numarasi)\b/i);
    let on = bol.length > 1 ? bol[0] : "";
    let skor = bol.length > 1 ? bol.slice(1).join(" ") : s;
    if (!on) {
      const m = s.match(/^([\s\S]*?\b(?:şubesi|subesi|dersi|ders)\b)([\s\S]*)$/i);
      if (m && /hedef|\d\s*['’`´]?\s*[a-fA-F]|sınıf|sinif/i.test(m[1])) { on = m[1]; skor = m[2]; }
    }
    return { on: on.trim(), skor: String(skor || "").trim() };
  }
  function okulNoListeSec(w, i, listeNos) {
    const liste = new Set((listeNos || []).map(noNormSes));
    const nums = [];
    let j = i;
    while (j < w.length && /^\d+$/.test(w[j])) {
      nums.push(w[j]);
      if (nums.join("").length >= 6) break;
      j++;
    }
    if (!nums.length) return null;
    for (let k = nums.length; k >= 1; k--) {
      const no = noNormSes(nums.slice(0, k).join(""));
      if (liste.has(no)) return { no, atla: k, listede: true };
    }
    return { no: noNormSes(nums[0]), atla: 1, listede: false };
  }
  function sesCanliOlaylari(metin, baglam) {
    baglam = baglam || {};
    const listeNos = baglam.listeNos || [];
    const liste = new Set(listeNos.map(noNormSes));
    const parca = sesCanliOnMetin(metin);
    const baglamParca = parca.on ? ayristirBaglam(parca.on) : null;
    let ham = sade(parca.skor || metin).replace(/[-_/'`´]+/g, " ");
    for (const [a, b] of SIRA_SOZ) ham = ham.replace(new RegExp("\\b" + a + "\\b", "g"), b);
    ham = ham.replace(/\b(\d{1,2})\s*(inci|nci|uncu|uncu|\.)\b/g, "$1");
    const w = sayilar(ham);
    const olaylar = [];
    if (baglamParca && (baglamParca.kisim || baglamParca.ok || baglamParca.ders)) olaylar.push({ tur: "baglam", baglam: baglamParca });
    let i = 0, expectNo = !!(parca.on || /okul|numara/i.test(String(metin || "")));
    const aktif = baglam.aktifNo ? noNormSes(baglam.aktifNo) : "";
    const soruSayisi = baglam.soruSayisi || 15;
    while (i < w.length) {
      const x = w[i];
      if (/^(okul|numara|numarali|numarasi|no|nolu)$/.test(x)) { expectNo = true; i++; continue; }
      if (/^(puan|puani|not|notu|ve|virgul|sonraki|olarak|ile|hedef|ders|dersi|sube|subesi|sinif|sinifi)$/.test(x)) { i++; continue; }
      if (/^(onayliyorum|onayla|onay|tamam)$/.test(x)) { i++; continue; }
      if (x === "bitti") { olaylar.push({ tur: "bitti" }); expectNo = false; i++; continue; }
      if (x === "iptal" || x === "vazgec") { olaylar.push({ tur: "iptal" }); expectNo = false; i++; continue; }
      const kat = katilimSozcu(w, i);
      if (kat) { olaylar.push({ tur: "katilim", katilim: kat.kat }); i += kat.atla; expectNo = false; continue; }
      if (x === "soru" || x === "sorusu") {
        if (/^\d+$/.test(w[i + 1] || "")) {
          const no = +w[i + 1];
          if (/^\d+$/.test(w[i + 2] || "")) {
            olaylar.push({ tur: "soru", no, puan: String(+w[i + 2]) });
            i += 3; expectNo = false; continue;
          }
          i += 2; expectNo = false; continue;
        }
        i++; continue;
      }
      if (/^\d+$/.test(x)) {
        const sec = okulNoListeSec(w, i, listeNos);
        const listede = !!(sec && sec.listede);
        const no = sec ? sec.no : noNormSes(x);
        const atla = sec ? sec.atla : 1;
        const ogrenciDene = expectNo || !aktif || listede || +no > 20 || String(no).length >= 3;
        if (ogrenciDene && (listede || expectNo || !aktif || +no > 20 || String(no).length >= 3) && !(aktif && !listede && !expectNo && +no <= 20 && String(no).length <= 2)) {
          if (listede || expectNo || !aktif || +no > 20 || String(no).length >= 3) {
            olaylar.push({ tur: "ogrenci", no });
            i += atla; expectNo = false; continue;
          }
        }
        if (aktif && /^\d+$/.test(x)) {
          olaylar.push({ tur: "puan", puan: String(+x) });
          i += 1; expectNo = false; continue;
        }
        i += 1; continue;
      }
      i++;
    }
    return olaylar;
  }
  function sesCanliBekleyenNo(metin, listeNos, uyari) {
    if (uyari && uyari !== "bulunamadı") return "";
    const ham = sade(metin || "");
    const w = sayilar(ham);
    const digs = [];
    let i = w.length - 1;
    while (i >= 0 && /^\d+$/.test(w[i])) { digs.unshift(w[i]); i--; }
    if (!digs.length) return "";
    const no = noNormSes(digs.join(""));
    const liste = (listeNos || []).map(noNormSes);
    if (liste.indexOf(no) >= 0) return "";
    if (liste.some((n) => n !== no && n.indexOf(no) === 0)) return no;
    return "";
  }
  function sesCanliBosSoru(puan, soruSayisi) {
    const p = puan || {};
    const n = soruSayisi || 8;
    for (let i = 1; i <= n; i++) {
      const v = p[i];
      if (v == null || v === "") return i;
    }
    return 0;
  }
  function sesCanliAdim(durum, metin, ortam) {
    ortam = ortam || {};
    const d = durum ? Object.assign({}, durum) : {};
    d.yazilan = Object.assign({}, d.yazilan || {});
    d.biten = (d.biten || []).slice();
    d.uyari = "";
    d.kaydetTik = false;
    const liste = ortam.liste || [];
    const listeNos = ortam.listeNos || liste.map((x) => noNormSes(x.no));
    const soruSayisi = ortam.soruSayisi || 8;
    const maxlar = ortam.maxlar || [];
    const noN = ortam.noNorm || noNormSes;
    const bul = (no) => liste.find((x) => noN(x.no) === noN(no));
    const olaylar = sesCanliOlaylari(metin, { aktifNo: d.aktifNo, listeNos, soruSayisi });
    d.olaylar = olaylar;
    const yazPuan = (no, soru, puan) => {
      const kn = noN(no);
      if (!d.yazilan[kn]) d.yazilan[kn] = { no: kn, puan: {}, katilim: "" };
      const max = (maxlar[soru - 1] != null) ? maxlar[soru - 1] : undefined;
      const hataFn = ortam.puanHata;
      const h = hataFn ? hataFn(puan, max) : ((max != null && +puan > +max) ? ("azami " + max + " puanı aşıyor (" + puan + ")") : "");
      if (h) {
        d.uyari = (soru + ". soru " + h);
        d.sonHata = d.uyari;
        return false;
      }
      d.yazilan[kn].puan = Object.assign({}, d.yazilan[kn].puan);
      d.yazilan[kn].puan[soru] = String(puan);
      if (typeof ortam.yazHucre === "function") ortam.yazHucre(kn, soru, String(puan));
      return true;
    };
    for (const ev of olaylar) {
      if (ev.tur === "baglam") {
        d.baglam = ev.baglam;
        if (typeof ortam.baglam === "function") ortam.baglam(ev.baglam);
        continue;
      }
      if (ev.tur === "ogrenci") {
        const sat = bul(ev.no);
        if (!sat) { d.uyari = "bulunamadı"; d.sonHata = "Okul no bulunamadı: " + ev.no; continue; }
        d.aktifNo = noN(ev.no);
        d.aktifAd = sat.ad || "";
        if (!d.yazilan[d.aktifNo]) d.yazilan[d.aktifNo] = { no: d.aktifNo, puan: {}, katilim: "" };
        if (typeof ortam.sec === "function") ortam.sec(d.aktifNo, sat);
        continue;
      }
      if (ev.tur === "iptal") {
        const eski = d.aktifNo;
        d.aktifNo = "";
        d.aktifAd = "";
        if (typeof ortam.birak === "function") ortam.birak(eski);
        continue;
      }
      if (ev.tur === "bitti") {
        if (d.aktifNo && d.biten.indexOf(d.aktifNo) < 0) d.biten.push(d.aktifNo);
        const eski = d.aktifNo;
        d.aktifNo = "";
        d.aktifAd = "";
        if (typeof ortam.bitir === "function") ortam.bitir(eski);
        continue;
      }
      if (ev.tur === "katilim") {
        if (!d.aktifNo) { d.uyari = "önce okul no söyleyin"; continue; }
        if (!d.yazilan[d.aktifNo]) d.yazilan[d.aktifNo] = { no: d.aktifNo, puan: {}, katilim: "" };
        d.yazilan[d.aktifNo].katilim = ev.katilim;
        if (typeof ortam.yazKatilim === "function") ortam.yazKatilim(d.aktifNo, ev.katilim);
        continue;
      }
      if (ev.tur === "soru" || ev.tur === "puan") {
        if (!d.aktifNo) { d.uyari = "önce okul no söyleyin"; continue; }
        let soru = ev.no;
        if (ev.tur === "puan") {
          const p = (d.yazilan[d.aktifNo] && d.yazilan[d.aktifNo].puan) || {};
          soru = sesCanliBosSoru(p, soruSayisi);
          if (!soru) { d.uyari = "boş soru kalmadı"; continue; }
        }
        if (!soru || soru < 1 || soru > soruSayisi) { d.uyari = "soru no geçersiz"; continue; }
        yazPuan(d.aktifNo, soru, ev.puan);
      }
    }
    const toplam = liste.length || ortam.toplam || 0;
    const sira = d.aktifNo ? (liste.findIndex((x) => noN(x.no) === noN(d.aktifNo)) + 1) : d.biten.length;
    d.durumYazi = toplam ? ("Puan girişi sürüyor " + (sira || 0) + "/" + toplam) : "Puan girişi sürüyor";
    if (d.uyari === "bulunamadı") d.durumYazi = "bulunamadı";
    return d;
  }

  const api = { sayilar, ayristir, ayristirOyss, ayristirBaglam, baglamYapistir, baglamEtiket, okulNoTopla, birlesikSayiAyir, gecerli, bul, adBenzer, KAT_ESLE, SIRA_SOZ, DERS_SES, komutSozcu, sesParcaEkle, sesAkisOlaylari, sesAkisCoz, sesTanimaAdim, sesFinalDedupEkle, sesDurumMetniMi, sesMetinAyikla, sesYaziNorm, sesCanliOlaylari, sesCanliAdim, sesCanliBekleyenNo, sesCanliBosSoru, okulNoListeSec, sesCanliOnMetin };
  if (typeof module !== 'undefined') { module.exports = api; return; }
  kok.NGASes = api;
  // ---- Sayfa: e-Okul not tablosu ----
  const A = kok.NGAAkis; if (!A) return;
  const mask = a => String(a || '').split(/\s+/).map(k => k ? k[0] + '.' : '').join(' ');
  async function yaz(doc, ayar, s, durum) {
    const T = A.ogrenciTablosu(doc); if (!T) return durum('Not tablosu yok. Önce Listele\'ye basın.', true);
    const og = T.satirlar.map(tr => ({ no: (tr.cells[0] ? tr.cells[0].textContent : '').replace(/\D/g, ''), ad: (tr.cells[1] ? tr.cells[1].textContent : '').trim(), tr })).filter(x => x.no);
    if (!gecerli(s.puan)) return durum('"' + s.puan + '" geçersiz puan (0-100 ya da G). Yazılmadı.', true);
    const b = bul(og, s); if (!b.o) return durum(b.neden + '. Yazılmadı.', true);
    const x = A.hucreGirdisi(b.o.tr, T.bas, ayar.tur, ayar.sinav, ayar.alan); if (!x) return durum(b.o.no + ' numarada seçili sütunun kutusu yok. Yazılmadı.', true);
    const W = doc.defaultView, ev = t => x.dispatchEvent(new W.Event(t, { bubbles: true })), v = String(s.puan);
    x.focus && x.focus(); x.value = ''; ev('input');
    for (const ch of v) { x.value += ch; ev('input'); await new Promise(r => setTimeout(r, 20 + Math.random() * 30)); }
    ev('change'); x.blur && x.blur(); ev('blur');
    og.forEach(q => { if (q.tr.style.outline.indexOf('255') >= 0 || q.tr.dataset.ngaSes) { q.tr.style.outline = ''; delete q.tr.dataset.ngaSes; } });
    b.o.tr.dataset.ngaSes = '1'; b.o.tr.style.outline = '3px solid #ffd400'; x.style.background = '#c8f7c5'; b.o.tr.scrollIntoView && b.o.tr.scrollIntoView({ block: 'center' });
    const m = b.o.no + ' numara (' + mask(b.o.ad) + '): ' + v;
    durum('✓ ' + m, false);
    try { if (ayar.konus !== false && W.speechSynthesis) { const u = new W.SpeechSynthesisUtterance(b.o.no + ' numara ' + (v === 'G' ? 'girmedi' : v)); u.lang = 'tr-TR'; u.rate = 1.2; W.speechSynthesis.speak(u); } } catch (e) {}
    return true;
  }
  // panel.js çağırır: dugme (🎤), durum alanı ve o anki sütun ayarını veren işlev
  function bagla(dugme, durumEl, ayarAl) {
    const SR = kok.SpeechRecognition || kok.webkitSpeechRecognition;
    const durum = (t, hata) => { durumEl.textContent = t; durumEl.style.background = hata ? '#ffeb3b' : '#c8f7c5'; };
    if (!SR) { dugme.disabled = true; dugme.textContent = '🎤 Bu tarayıcıda ses tanıma yok'; return; }
    let tan = null, acik = false;
    const kapa = () => { acik = false; dugme.textContent = '🎤 Sesli not: Başlat'; dugme.style.background = '#000'; };
    // 1.6.23: e-Okul sayfası "Permissions-Policy: microphone=()" gönderir; sayfada mikrofon hiç açılamaz (izin verseniz de not-allowed).
    // Dinleme küçük bir uzantı penceresinde yapılır; tanınan metin chrome.storage.local ile buraya gelir ve aynı ayrıştırma/yazma kullanılır.
    const st = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
    if (!st || !chrome.runtime || !chrome.runtime.sendMessage) { dugme.disabled = true; dugme.textContent = '🎤 Sesli not kullanılamıyor'; return; }
    let sira = Promise.resolve();
    chrome.storage.onChanged.addListener((c, a) => { if (a !== 'local') return;
      if (c.ngaSesDurum && c.ngaSesDurum.newValue) { const v = c.ngaSesDurum.newValue; if (acik) durum(v.t, v.hata); if (v.bitti || (v.hata && /izni|bulunamad/.test(v.t))) kapa(); }
      if (acik && c.ngaSesMetin && c.ngaSesMetin.newValue) { const t = String(c.ngaSesMetin.newValue.t || ''); if (!t || sesDurumMetniMi(t) || c.ngaSesMetin.newValue.final === false) return; sira = sira.then(async () => { const r = ayristir(t);
          if (!r.satirlar.length) { durum('Anlaşılmadı: "' + t.slice(0, 40) + '". Örnek: "12 numara 85"', true); return; }
          for (const s of r.satirlar) await yaz(document, ayarAl(), s, durum); if (r.hatalar.length) durum('Kısmen anlaşıldı; atlanan: ' + r.hatalar.join(' | '), true); }).catch(() => {}); } });
    dugme.onclick = () => {
      if (acik) { kapa(); st.set({ ngaSesKomut: { k: 'dur', z: Date.now() } }); durum('Durduruldu.', false); return; }
      acik = true; dugme.textContent = '⏹ Sesli not: Durdur'; dugme.style.background = '#b00020';
      durum('Sesli not penceresi açılıyor. İlk seferde pencerede "Mikrofon kullanılsın mı?" sorusuna İzin ver deyin; pencere açık kalsın.', false);
      try { chrome.runtime.sendMessage({ tip: 'ses-ac' }); } catch (e) { kapa(); durum('Sesli not penceresi açılamadı. Sayfayı yenileyip yeniden deneyin.', true); } };
  }
  kok.NGASes.yaz = yaz; kok.NGASes.bagla = bagla;
})(typeof window !== 'undefined' ? window : globalThis);
