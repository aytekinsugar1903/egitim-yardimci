// 1.9.22 OYSS/Excel sesli puan girişi — yüzen hap panel (Evrak Asistanı / Eyüp ŞEKER).
// e-Okul mikrofona izin vermez; tanıma görünür ses-ac penceresinde yapılır (1.9.18 yolu).
// Puanlar hemen yazılır; Kaydet'e ve Güvenlik Kodu'na dokunulmaz.
(function (kok) {
  "use strict";
  const S = () => kok.NGASes;
  const O = () => kok.OyssNot;
  const HINT = "Puanları sırayla '3 12 9' ya da 'soru bir beş' diye söyleyin; düzeltmek için 'soru dört dokuz' deyin";
  const SARI = "#ffe566";

  function noN(no) {
    const N = O();
    return N && N.noNorm ? N.noNorm(no) : String(no || "").replace(/\D/g, "").replace(/^0+/, "") || "0";
  }
  function kayitSuresiOku(doc) {
    if (!doc) return "";
    const aday = doc.querySelectorAll("[id*='ure'], [id*='Sure'], [id*='sure'], [id*='Sure'], [class*='sure'], [class*='Sure']");
    for (const el of aday) {
      if (el.closest && el.closest("#nga-ses-hap")) continue;
      const t = String((el.textContent || el.value || "")).trim();
      if (/\d{1,2}:\d{2}/.test(t) && /s[uü]re/i.test(t + " " + (el.id || "") + " " + (el.className || ""))) {
        const m = t.match(/(\d{1,2}:\d{2}(?::\d{2})?)/);
        return m ? m[1] : t;
      }
    }
    const govde = String((doc.body && doc.body.innerText) || doc.body && doc.body.textContent || "");
    const m = govde.match(/kay[ıi]t\s*s[uü]resi?\s*[:\-]?\s*(\d{1,2}:\d{2}(?::\d{2})?)/i);
    if (m) return m[1];
    const m2 = govde.match(/s[uü]re\s*[:\-]?\s*(\d{1,2}:\d{2}(?::\d{2})?)/i);
    return m2 ? m2[1] : "";
  }

  function hapKur(opts) {
    opts = opts || {};
    const doc = (opts.document) || (kok.document);
    if (!doc || !doc.body) return null;
    if (doc.getElementById("nga-ses-hap")) return kok.NGASes && kok.NGASes._hap;
    const st = (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) || null;
    const stil = doc.createElement("style");
    stil.id = "nga-ses-hap-stil";
    stil.textContent = "#nga-ses-hap{position:fixed;z-index:2147483000;left:50%;bottom:18px;transform:translateX(-50%);background:#1b1b1b;color:#fff;border-radius:28px;box-shadow:0 8px 28px rgba(0,0,0,.28);padding:10px 14px 12px;min-width:320px;max-width:min(560px,calc(100vw - 24px));font:13px/1.35 sans-serif;user-select:none}"
      + "#nga-ses-hap *{box-sizing:border-box;font:inherit;color:inherit}"
      + "#nga-ses-hap .nga-hap-ust{display:flex;align-items:center;gap:8px;cursor:move}"
      + "#nga-ses-hap b.nga-hap-ad{font-weight:700;letter-spacing:.2px}"
      + "#nga-ses-hap .nga-hap-pulse{width:10px;height:10px;border-radius:50%;background:#666;flex:0 0 auto}"
      + "#nga-ses-hap.nga-dinliyor .nga-hap-pulse{background:#3dff8a;box-shadow:0 0 0 0 rgba(61,255,138,.7);animation:ngaHapPulse 1.2s infinite}"
      + "@keyframes ngaHapPulse{0%{box-shadow:0 0 0 0 rgba(61,255,138,.55)}70%{box-shadow:0 0 0 8px rgba(61,255,138,0)}100%{box-shadow:0 0 0 0 rgba(61,255,138,0)}}"
      + "#nga-ses-hap .nga-hap-btn{background:#fff;color:#111;border:0;border-radius:16px;padding:4px 12px;font-weight:700;cursor:pointer}"
      + "#nga-ses-hap .nga-hap-btn[data-k=dur]{background:#c62828;color:#fff}"
      + "#nga-ses-hap .nga-hap-x{margin-left:auto;background:transparent;color:#fff;border:0;font-size:18px;cursor:pointer;line-height:1;padding:0 4px}"
      + "#nga-ses-hap .nga-hap-durum{margin:6px 0 0;font-weight:600}"
      + "#nga-ses-hap .nga-hap-uyari{margin:2px 0 0;color:#ffd54f;min-height:1em}"
      + "#nga-ses-hap .nga-hap-hint{margin:4px 0 0;color:#cfd8dc;font-size:11px}"
      + "#nga-ses-hap .nga-hap-sure{margin:2px 0 0;color:#90caf9;font-size:11px}"
      + "#nga-ses-hap .nga-hap-mic{margin:4px 0 0;font-size:11px;color:#b3e5fc}"
      + "#nga-ses-hap .nga-hap-duyulan{margin:2px 0 0;font-size:11px;color:#eee;white-space:pre-wrap}"
      + "#nga-ses-hap .nga-hap-islem{margin:2px 0 0;font-size:11px;color:#c8e6c9}";
    doc.head.appendChild(stil);
    const el = doc.createElement("div");
    el.id = "nga-ses-hap";
    el.setAttribute("data-nga-eklenti", "1");
    el.innerHTML = '<div class="nga-hap-ust">'
      + '<span class="nga-hap-pulse" aria-hidden="true"></span>'
      + '<b class="nga-hap-ad">Evrak Asistanı · Sesli puan</b>'
      + '<button type="button" class="nga-hap-btn" data-k="bas" id="nga-hap-baslat">Başlat</button>'
      + '<button type="button" class="nga-hap-x" id="nga-hap-kapat" title="Kapat">×</button>'
      + "</div>"
      + '<div class="nga-hap-mic" id="nga-hap-mic">Pencere kapalı</div>'
      + '<div class="nga-hap-durum" id="nga-hap-durum">Hazır. Başlat\'a basıp okul no söyleyin.</div>'
      + '<div class="nga-hap-duyulan" id="nga-hap-duyulan">Duyulan: —</div>'
      + '<div class="nga-hap-islem" id="nga-hap-islem"></div>'
      + '<div class="nga-hap-uyari" id="nga-hap-uyari"></div>'
      + '<div class="nga-hap-hint">' + HINT + "</div>"
      + '<div class="nga-hap-sure" id="nga-hap-sure" hidden></div>';
    doc.body.appendChild(el);

    let durum = { yazilan: {}, biten: [], aktifNo: "", aktifAd: "", uyari: "", durumYazi: "" };
    let dinliyor = false, sonParcalar = [], islenen = 0, sonSon = "", bekleyenOnEk = "";
    let satirEl = null, sureZaman = null;
    const basBtn = el.querySelector("#nga-hap-baslat");
    const durumEl = el.querySelector("#nga-hap-durum");
    const uyariEl = el.querySelector("#nga-hap-uyari");
    const sureEl = el.querySelector("#nga-hap-sure");
    const micEl = el.querySelector("#nga-hap-mic");
    const duyulanEl = el.querySelector("#nga-hap-duyulan");
    const islemEl = el.querySelector("#nga-hap-islem");
    let micDurum = "Pencere kapalı";
    let sonDuyulan = "";
    let sonIslem = "";

    function micYaz(s) { micDurum = s; if (micEl) micEl.textContent = s; }
    function islemlerdenYaz(d) {
      const evs = (d && d.olaylar) || [];
      const parca = [];
      evs.forEach((ev) => {
        if (ev.tur === "ogrenci") parca.push((d.uyari === "bulunamadı") ? ("bulunamadı " + ev.no) : (ev.no + " seçildi"));
        else if (ev.tur === "soru") parca.push("Soru " + ev.no + " = " + ev.puan);
        else if (ev.tur === "puan") {
          const kn = d.aktifNo;
          const puanlar = kn && d.yazilan && d.yazilan[kn] && d.yazilan[kn].puan;
          const nos = puanlar ? Object.keys(puanlar).map(Number).sort((a, b) => a - b) : [];
          const son = nos.length ? nos[nos.length - 1] : "?";
          parca.push("Soru " + son + " = " + ev.puan);
        }
        else if (ev.tur === "katilim") parca.push("Katılım: " + ev.katilim);
        else if (ev.tur === "bitti") parca.push("Bitti");
        else if (ev.tur === "iptal") parca.push("İptal");
        else if (ev.tur === "baglam" && ev.baglam) parca.push("Bağlam alındı");
      });
      if (!parca.length && d && d.uyari === "bulunamadı") {
        const ek = d.sonHata ? (" " + String(d.sonHata).replace(/^Okul no bulunamadı:\s*/, "")) : "";
        parca.push("bulunamadı" + ek);
      }
      if (parca.length) sonIslem = parca.join(" · ");
    }
    function yazUI() {
      if (micEl) micEl.textContent = micDurum;
      if (durum.uyari === "bulunamadı") durumEl.textContent = "bulunamadı";
      else if (durum.durumYazi) durumEl.textContent = durum.durumYazi + (durum.aktifNo ? (" · Okul no " + durum.aktifNo + (durum.aktifAd ? (" " + durum.aktifAd) : "")) : "");
      else durumEl.textContent = dinliyor ? "Dinliyorum. Okul no söyleyin." : "Hazır. Başlat'a basıp okul no söyleyin.";
      if (duyulanEl) {
        const cap = sonDuyulan.length > 200 ? sonDuyulan.slice(-200) : sonDuyulan;
        duyulanEl.textContent = cap ? ("Duyulan: " + cap) : "Duyulan: —";
      }
      if (islemEl) islemEl.textContent = sonIslem || "";
      uyariEl.textContent = (durum.uyari && durum.uyari !== "bulunamadı") ? durum.uyari : (durum.sonHata && durum.uyari !== "bulunamadı" ? durum.sonHata : "");
    }
    function sureGuncelle() {
      const t = kayitSuresiOku(doc);
      if (t) { sureEl.hidden = false; sureEl.textContent = "Kayıt süresi: " + t; }
      else sureEl.hidden = true;
    }
    function hedef() {
      if (typeof opts.hedef === "function") return opts.hedef() || {};
      const sayfa = O() && O().sayfaOku && O().sayfaOku(kok);
      return sayfa ? { tur: "oyss", sayfa, satirlar: sayfa.satirlar, puanlar: (O().sayfaSoruMeta ? O().sayfaSoruMeta(sayfa).puanlar : []) } : {};
    }
    let excelTaban = null, excelTabanImza = "";
    function grupKopya(grup) {
      if (!grup) return null;
      return {
        sube: grup.sube, ders: grup.ders, sinav: grup.sinav,
        soruSayisi: grup.soruSayisi,
        puanlar: (grup.puanlar || []).slice(),
        dersler: grup.dersler ? grup.dersler.slice() : undefined,
        ogrenciler: (grup.ogrenciler || []).map((o) => ({
          no: o.no, ad: o.ad, puan: (o.puan || []).slice(), katilim: o.katilim || "", katilimHam: o.katilimHam
        }))
      };
    }
    function excelGrupAl(h) {
      if (typeof opts.excelGrup === "function") return opts.excelGrup() || (h && h.grup);
      return h && h.grup;
    }
    function excelUygulaYazilan(h, yazilan) {
      const N = O();
      const grup = excelGrupAl(h);
      if (!N || !N.sesExcelUygula || !grup) return;
      const imza = (grup.ogrenciler || []).map((o) => String(o.no || "")).join(",");
      if (!excelTaban || excelTabanImza !== imza) {
        excelTaban = grupKopya(grup);
        excelTabanImza = imza;
      }
      const satirlar = [];
      Object.keys(yazilan || {}).forEach((k) => {
        const y = yazilan[k];
        if (!y) return;
        satirlar.push({ no: y.no || k, puan: y.puan || {}, katilim: y.katilim || "" });
      });
      const r = N.sesExcelUygula(excelTaban, satirlar);
      if (r && r.grup) {
        h.grup = r.grup;
        if (typeof opts.excelYenile === "function") opts.excelYenile(r.grup);
      }
      if (r && r.hatalar && r.hatalar.length) durum.sonHata = r.hatalar[0];
    }
    function ortamKur() {
      const h = hedef();
      const sayfa = h.sayfa || (h.tur === "oyss" ? h : null);
      const liste = (h.satirlar || (sayfa && sayfa.satirlar) || []).map((s) => ({ no: s.no, ad: s.ad, tr: s.tr, girdiler: s.girdiler, select: s.select, puan: s.puan }));
      const meta = (sayfa && O() && O().sayfaSoruMeta) ? O().sayfaSoruMeta(sayfa) : { soruSayisi: (h.puanlar || []).length || 8, puanlar: h.puanlar || [] };
      const soruSayisi = meta.soruSayisi || (h.puanlar || []).length || (sayfa && sayfa.sorular && sayfa.sorular.length) || 8;
      const maxlar = (meta.puanlar && meta.puanlar.length) ? meta.puanlar : (h.puanlar || (sayfa && sayfa.sorular || []).map((q) => q.max));
      function boya(sat, ac) {
        if (!sat || !sat.tr) return;
        if (ac) {
          if (satirEl && satirEl !== sat.tr) {
            satirEl.style.background = satirEl.getAttribute("data-nga-once-bg") || "";
            satirEl.removeAttribute("data-nga-ses-aktif");
          }
          if (!sat.tr.getAttribute("data-nga-once-bg")) sat.tr.setAttribute("data-nga-once-bg", sat.tr.style.background || "");
          sat.tr.style.background = SARI;
          sat.tr.setAttribute("data-nga-ses-aktif", "1");
          satirEl = sat.tr;
          try { sat.tr.scrollIntoView({ block: "center", behavior: "smooth" }); } catch (e) { try { sat.tr.scrollIntoView(true); } catch (e2) {} }
        } else {
          sat.tr.style.background = sat.tr.getAttribute("data-nga-once-bg") || "";
          sat.tr.removeAttribute("data-nga-ses-aktif");
          if (satirEl === sat.tr) satirEl = null;
        }
      }
      function satBul(no) { return liste.find((x) => noN(x.no) === noN(no)); }
      function hucreInput(sat, soru) {
        if (sat && sat.tr) {
          const ins = sat.tr.querySelectorAll("input:not([type=hidden]), textarea");
          if (ins && ins[soru - 1]) return ins[soru - 1];
        }
        return sat && sat.girdiler && sat.girdiler[soru - 1];
      }
      function yazHucre(no, soru, puan) {
        if (h.tur === "excel") return;
        const sat = satBul(no);
        const inp = hucreInput(sat, soru);
        if (inp && O() && O().degerYaz) O().degerYaz(inp, O().puanYaz ? O().puanYaz(puan) : puan);
      }
      function yazKatilim(no, kat) {
        if (h.tur === "excel") return;
        const sat = satBul(no);
        if (sat && sat.select && O() && O().secenekYaz) O().secenekYaz(sat.select, kat);
      }
      return {
        liste, soruSayisi, maxlar, toplam: liste.length,
        puanHata: O() && O().puanHata, noNorm: noN,
        yazHucre, yazKatilim,
        excelUygula: (yazilan) => excelUygulaYazilan(h, yazilan),
        sec(no) { const sat = satBul(no); if (sat) boya(sat, true); },
        birak(no) { const sat = satBul(no); if (sat) boya(sat, false); },
        bitir(no) { const sat = satBul(no); if (sat) boya(sat, false); }
      };
    }
    function parcaIsle(paket) {
      const api = S();
      if (!api || !api.sesCanliAdim) return;
      if (paket && paket.final === false) return;
      let parcalar = sonParcalar.slice();
      if (paket && api.sesParcaEkle) {
        const d = api.sesParcaEkle({ parcalar: parcalar, sira: parcalar.length, biriken: parcalar.join(" ") }, paket);
        parcalar = d.parcalar || [];
      } else if (paket && paket.t) {
        parcalar = api.sesFinalDedupEkle ? api.sesFinalDedupEkle(parcalar, paket.t) : parcalar.concat([String(paket.t)]);
      }
      const ortam = ortamKur();
      const bas = islenen;
      for (let i = bas; i < parcalar.length; i++) {
        const p = parcalar[i];
        if (!p || p === sonSon) { islenen = i + 1; continue; }
        const metin = bekleyenOnEk ? (bekleyenOnEk + " " + p) : p;
        durum = api.sesCanliAdim(durum, metin, ortam);
        sonDuyulan = p;
        islemlerdenYaz(durum);
        const listeNos = ortam.listeNos || (ortam.liste || []).map((x) => ortam.noNorm ? ortam.noNorm(x.no) : x.no);
        bekleyenOnEk = (api.sesCanliBekleyenNo && durum.uyari === "bulunamadı") ? (api.sesCanliBekleyenNo(metin, listeNos, durum.uyari) || "") : "";
        if (bekleyenOnEk) durum.uyari = "";
        islenen = i + 1;
        sonSon = p;
      }
      if (bas > 0 && parcalar[bas - 1] && sonParcalar[bas - 1] && parcalar[bas - 1] !== sonParcalar[bas - 1] && String(parcalar[bas - 1]).indexOf(sonParcalar[bas - 1]) === 0) {
        const ek = String(parcalar[bas - 1]).slice(sonParcalar[bas - 1].length);
        if (api.sesYaziNorm && api.sesYaziNorm(ek)) {
          const metin = bekleyenOnEk ? (bekleyenOnEk + " " + ek) : ek;
          durum = api.sesCanliAdim(durum, metin, ortam);
          sonDuyulan = (sonDuyulan || "") + ek;
          islemlerdenYaz(durum);
          const listeNos = (ortam.liste || []).map((x) => ortam.noNorm ? ortam.noNorm(x.no) : x.no);
          bekleyenOnEk = (api.sesCanliBekleyenNo && durum.uyari === "bulunamadı") ? (api.sesCanliBekleyenNo(metin, ortam.listeNos || listeNos, durum.uyari) || "") : "";
          if (bekleyenOnEk) durum.uyari = "";
        }
        sonSon = parcalar[bas - 1];
      }
      if (typeof ortam.excelUygula === "function") ortam.excelUygula(durum.yazilan);
      sonParcalar = parcalar;
      yazUI();
    }

    function ac() {
      if (typeof opts.kvkkOk === "function" && !opts.kvkkOk()) {
        durum.sonHata = "Önce ses tanımanın Google'a gittiğini kabul edin (paneldeki kutuyu işaretleyin).";
        yazUI();
        return;
      }
      dinliyor = true;
      el.classList.add("nga-dinliyor");
      basBtn.textContent = "Durdur";
      basBtn.setAttribute("data-k", "dur");
      micYaz("Dinliyorum");
      durumEl.textContent = "Dinliyorum. Ses penceresi açıldı; konuşun.";
      try { chrome.runtime.sendMessage({ tip: "ses-ac" }); } catch (e) {
        dinliyor = false;
        el.classList.remove("nga-dinliyor");
        basBtn.textContent = "Başlat";
        basBtn.setAttribute("data-k", "bas");
        durum.sonHata = "Ses tanıma başlatılamadı.";
        yazUI();
      }
    }
    function kapa(gizle) {
      dinliyor = false;
      el.classList.remove("nga-dinliyor");
      basBtn.textContent = "Başlat";
      basBtn.setAttribute("data-k", "bas");
      micYaz("Pencere kapalı");
      try { chrome.runtime.sendMessage({ tip: "ses-kapa" }); } catch (e) {}
      try { if (st) st.set({ ngaSesKomut: { k: "dur", z: Date.now() } }); } catch (e) {}
      if (gizle) el.style.display = "none";
      else { durumEl.textContent = durum.durumYazi || "Durduruldu. Kaydet'e siz basarsınız."; }
      yazUI();
    }
    basBtn.onclick = (e) => { e.stopPropagation(); if (dinliyor) kapa(false); else ac(); };
    el.querySelector("#nga-hap-kapat").onclick = (e) => { e.stopPropagation(); kapa(true); };
    // sürükle
    let surukle = null;
    el.querySelector(".nga-hap-ust").addEventListener("pointerdown", (e) => {
      if (e.target && e.target.closest && e.target.closest("button")) return;
      const r = el.getBoundingClientRect();
      surukle = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      el.style.transform = "none";
      el.style.left = r.left + "px";
      el.style.bottom = "auto";
      el.style.top = r.top + "px";
      try { e.target.setPointerCapture && e.target.setPointerCapture(e.pointerId); } catch (err) {}
    });
    doc.addEventListener("pointermove", (e) => {
      if (!surukle) return;
      el.style.left = Math.max(8, e.clientX - surukle.dx) + "px";
      el.style.top = Math.max(8, e.clientY - surukle.dy) + "px";
    });
    doc.addEventListener("pointerup", () => {
      if (!surukle) return;
      surukle = null;
      if (st) st.set({ ngaSesHapKonum: { left: el.style.left, top: el.style.top } });
    });
    if (st) st.get("ngaSesHapKonum", (v) => {
      const k = v && v.ngaSesHapKonum;
      if (!k || !k.left) return;
      el.style.transform = "none";
      el.style.left = k.left;
      el.style.top = k.top;
      el.style.bottom = "auto";
    });
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener((m) => {
        if (!m || m.tip !== "nga-ses-parca") return;
        if (m.final === false) return;
        parcaIsle(m);
      });
    }
    if (st && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((c, a) => {
        if (a !== "local") return;
        if (c.ngaSesMetin && c.ngaSesMetin.newValue) parcaIsle(c.ngaSesMetin.newValue);
        if (c.ngaSesDurum && c.ngaSesDurum.newValue) {
          const v = c.ngaSesDurum.newValue;
          if (v.hata && /izin|not-allowed|İzin yok|izni yok/i.test(v.t || "")) micYaz("İzin yok");
          else if (v.bitti) micYaz("Pencere kapalı");
          else if (/Dinliyorum/i.test(v.t || "") && !v.hata) micYaz("Dinliyorum");
          if (v.hata && v.t) { uyariEl.textContent = v.t; }
          if (v.bitti) { dinliyor = false; el.classList.remove("nga-dinliyor"); basBtn.textContent = "Başlat"; basBtn.setAttribute("data-k", "bas"); }
          yazUI();
        }
      });
    }
    sureGuncelle();
    sureZaman = setInterval(sureGuncelle, 1000);
    const api = { el, ac, kapa, parcaIsle, durumGet: () => durum, ortamKur, kayitSuresiOku: () => kayitSuresiOku(doc), micGet: () => micDurum, duyulanGet: () => sonDuyulan, islemGet: () => sonIslem };
    if (kok.NGASes) kok.NGASes._hap = api;
    return api;
  }

  if (kok.NGASes) kok.NGASes.hapKur = hapKur;
  else kok.NGASes = { hapKur };
})(typeof window !== "undefined" ? window : globalThis);
