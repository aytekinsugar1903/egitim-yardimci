// 1.9.18 Sesli not penceresi (uzantı sayfası). e-Okul "Permissions-Policy: microphone=()" verdiği için
// mikrofon orada açılamaz; burada açılır. Durum #d öğesinde gösterilir (Hazırlanıyor / Dinliyorum / İzin yok / Hata).
(function (kok) {
  function yazNorm(t) { return String(t || "").replace(/\s+/g, " ").trim(); }
  function durumMetniMi(t) {
    const k = yazNorm(t).toLocaleLowerCase("tr-TR");
    return /sesli not durduruldu|biriken metin panelde|sesli not penceresi kapandı|dinliyorum \(sürekli\)|mikrofon izni|hedef:/.test(k);
  }
  function finalDedupEkle(parcalar, yeni) {
    const t = yazNorm(yeni);
    if (!t || durumMetniMi(t)) return parcalar.slice();
    const arr = parcalar.slice();
    const last = yazNorm(arr[arr.length - 1] || "");
    if (!last) { arr.push(t); return arr; }
    if (t === last) return arr;
    if (t.indexOf(last) === 0) { arr[arr.length - 1] = t; return arr; }
    if (last.indexOf(t) === 0) return arr;
    if (last.endsWith(t) || t.endsWith(last)) {
      if (t.length > last.length) arr[arr.length - 1] = t;
      return arr;
    }
    const a = t.toLocaleLowerCase("tr-TR"), b = last.toLocaleLowerCase("tr-TR");
    for (let n = Math.min(a.length, b.length); n >= 8; n--) {
      if (b.slice(-n) === a.slice(0, n)) {
        arr[arr.length - 1] = last + t.slice(n);
        return arr;
      }
    }
    arr.push(t);
    return arr;
  }

  const HATA = {
    "not-allowed": "İzin yok: Mikrofon izni verilmedi. Adres çubuğundaki mikrofon simgesine tıklayıp İzin ver seçin, sonra Tekrar dene'ye basın.",
    "service-not-allowed": "İzin yok: Chrome ses tanımaya izin vermedi. Chrome'u güncelleyip Tekrar dene'ye basın.",
    "audio-capture": "Hata: Mikrofon bulunamadı. Mikrofonun takılı ve Windows Ses ayarlarında seçili olduğunu kontrol edin.",
    "network": "Hata: Ses tanıma için internet bağlantısı gerekiyor (Chrome sesi Google'da metne çevirir). Bağlantıyı kontrol edin.",
    "language-not-supported": "Hata: Bu Chrome Türkçe ses tanımayı desteklemiyor; Chrome'u güncelleyin.",
    "no-speech": "Ses algılanmadı; dinlemeye devam ediliyor."
  };

  function baslatPencere(win) {
    const w = win || kok;
    const doc = w.document;
    const chromeObj = w.chrome || (typeof chrome !== "undefined" ? chrome : null);
    const el = doc.getElementById("d") || doc.getElementById("durum");
    const hamEl = doc.getElementById("ham");
    const btnDur = doc.getElementById("b");
    const btnTekrar = doc.getElementById("tekrar");
    if (!el) return { hata: "durum alanı yok (#d)" };
    const st = (chromeObj && chromeObj.storage && chromeObj.storage.local) || null;
    const durumYaz = (t, hata) => {
      el.textContent = t;
      el.style.background = hata ? "#ffeb3b" : "#c8f7c5";
    };
    const tekrarGoster = (goster) => {
      if (!btnTekrar) return;
      btnTekrar.style.display = goster ? "inline-block" : "none";
    };
    const durum = (t, hata) => {
      durumYaz(t, hata);
      if (hata) tekrarGoster(true);
      if (st) {
        try { st.set({ ngaSesDurum: { t, hata: !!hata, z: Date.now() } }); } catch (e) {}
      }
    };
    if (!st) { durum("Hata: Depolama yok; sesli not çalışmaz.", true); return { hata: "depolama yok" }; }
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SR) { durum("Hata: Bu pencerede ses tanıma yok. Chrome kullanın.", true); return { hata: "SR yok" }; }

    let acik = true, tan = null, kapatiliyor = false, baslatiliyor = false, basladi = false, sira = 0, araZ = 0;
    const parcalar = [];
    function birikenYaz() { return parcalar.join(" ").replace(/\s+/g, " ").trim(); }
    function hamGoster(ara) {
      if (!hamEl) return;
      const b = birikenYaz();
      const bGoster = b.length > 200 ? b.slice(-200) : b;
      hamEl.textContent = (bGoster ? ("Duyulan: " + bGoster) : "") + (ara ? ((bGoster ? "\n" : "") + "Anlık: " + ara) : "");
    }
    function paketYaz() {
      sira = parcalar.length;
      const z = Date.now();
      const biriken = birikenYaz();
      const paket = { t: parcalar[parcalar.length - 1] || "", final: true, z, sira, parcalar: parcalar.slice(), biriken };
      st.set({ ngaSesMetin: paket });
      try { chromeObj.runtime.sendMessage({ tip: "nga-ses-parca", t: paket.t, final: true, z, sira, parcalar: paket.parcalar, biriken }); } catch (e) {}
    }
    function araYaz(ara) {
      const t = yazNorm(ara);
      araZ++;
      st.set({ ngaSesAra: { t, z: Date.now(), n: araZ } });
      hamGoster(t);
    }
    const tanima = () => {
      tan = new SR();
      tan.lang = "tr-TR";
      tan.interimResults = true;
      tan.continuous = true;
      tan.maxAlternatives = 1;
      tan.onresult = (e) => {
        if (!acik) return;
        const bas = (typeof e.resultIndex === "number" && e.resultIndex >= 0) ? e.resultIndex : 0;
        let ara = "";
        let yeniFinal = false;
        for (let i = bas; i < e.results.length; i++) {
          const r = e.results[i];
          const text = yazNorm((r[0] && r[0].transcript) || r.transcript || "");
          if (!text) continue;
          if (r.isFinal) {
            const onceki = parcalar.join("\0");
            const kopya = finalDedupEkle(parcalar, text);
            parcalar.length = 0;
            Array.prototype.push.apply(parcalar, kopya);
            if (parcalar.join("\0") !== onceki) yeniFinal = true;
          } else {
            ara += (ara ? " " : "") + text;
          }
        }
        if (yeniFinal) { paketYaz(); hamGoster(ara); }
        if (ara) araYaz(ara);
        else hamGoster("");
      };
      tan.onerror = (e) => {
        const k = (e && e.error) || "";
        if (k === "aborted") return;
        if (k === "no-speech") {
          durumYaz(HATA["no-speech"], false);
          return;
        }
        if (k === "not-allowed" || k === "service-not-allowed") {
          acik = false;
          kapatiliyor = true;
          try { if (tan) tan.stop(); } catch (err) {}
          durum(HATA[k], true);
          try { chromeObj.runtime.sendMessage({ tip: "ses-izin-pencere" }); } catch (err) {}
          return;
        }
        if (k === "audio-capture") {
          acik = false;
          kapatiliyor = true;
          durum(HATA[k], true);
          return;
        }
        if (k === "network" || k === "language-not-supported") {
          durum(HATA[k] || ("Hata: " + k), true);
          return;
        }
        durum(HATA[k] || ("Hata: Dinleme kesildi (" + k + "). Tekrar dene'ye basın veya bekleyin."), true);
      };
      tan.onend = () => {
        tan = null;
        if (!acik || kapatiliyor) return;
        (w.setTimeout || setTimeout)(() => { if (acik && !kapatiliyor && !baslatiliyor) baslat(); }, 250);
      };
    };
    async function mikrofonIzni() {
      const nav = w.navigator;
      if (!nav || !nav.mediaDevices || !nav.mediaDevices.getUserMedia) return true;
      const s = await nav.mediaDevices.getUserMedia({ audio: true });
      try { (s.getTracks ? s.getTracks() : []).forEach((tr) => { try { tr.stop(); } catch (e) {} }); } catch (e) {}
      return true;
    }
    const baslat = () => {
      if (baslatiliyor || kapatiliyor) return;
      if (tan) {
        try { tan.start(); acik = true; basladi = true; tekrarGoster(false); durum("Dinliyorum (sürekli). Sınıf, şube ve dersi söyleyin; ardından okul no ve puanları. Bitince panelden durdurun veya bu pencereyi kapatın.", false); return; } catch (e) {}
      }
      baslatiliyor = true;
      acik = true;
      kapatiliyor = false;
      const devam = () => {
        try {
          tanima();
          tan.start();
          basladi = true;
          tekrarGoster(false);
          durum("Dinliyorum (sürekli). Sınıf, şube ve dersi söyleyin; ardından okul no ve puanları. Bitince panelden durdurun veya bu pencereyi kapatın.", false);
        } catch (err) {
          acik = false;
          durum("Hata: Mikrofon başlatılamadı: " + (err && err.message || err), true);
        } finally { baslatiliyor = false; }
      };
      Promise.resolve()
        .then(() => mikrofonIzni())
        .then(() => devam())
        .catch((e) => {
          baslatiliyor = false;
          acik = false;
          const ad = (e && e.name) || "";
          durum(ad === "NotFoundError" ? HATA["audio-capture"] : HATA["not-allowed"], true);
          try { chromeObj.runtime.sendMessage({ tip: "ses-izin-pencere" }); } catch (err) {}
        });
    };
    const bitir = (mesaj) => {
      acik = false; kapatiliyor = true;
      try { if (tan) tan.stop(); } catch (e) {}
      tan = null;
      tekrarGoster(false);
      const t = mesaj || "Sesli not durduruldu. Biriken metin panelde duruyor.";
      durumYaz(t, false);
      if (st) st.set({ ngaSesDurum: { t, hata: false, z: Date.now(), bitti: true } });
      if (/kapandı|kapat/.test(t) === false && /durduruldu/.test(t) && w.close) {
        try { w.close(); } catch (e) {}
      }
    };
    if (btnDur) btnDur.onclick = () => bitir("Sesli not durduruldu. Biriken metin panelde duruyor.");
    if (btnTekrar) btnTekrar.onclick = () => { kapatiliyor = false; acik = true; basladi = false; tekrarGoster(false); durumYaz("Hazırlanıyor…", false); baslat(); };
    if (chromeObj && chromeObj.storage && chromeObj.storage.onChanged && chromeObj.storage.onChanged.addListener) {
      chromeObj.storage.onChanged.addListener((c, a) => {
        if (a === "local" && c.ngaSesKomut && c.ngaSesKomut.newValue && c.ngaSesKomut.newValue.k === "dur") bitir("Sesli not durduruldu. Biriken metin panelde duruyor.");
      });
    }
    if (w.addEventListener) w.addEventListener("beforeunload", () => bitir("Sesli not penceresi kapandı. Biriken metin panelde duruyor."));
    (w.setTimeout || setTimeout)(() => {
      if (!basladi && el && /Hazırlanıyor/.test(el.textContent || "")) {
        durum("Hata: Mikrofon 3 saniyede başlatılamadı. İzin penceresi geldiyse onaylayın; gelmediyse Tekrar dene'ye basın.", true);
      }
    }, 3000);
    baslat();
    return { el, baslat, bitir };
  }

  const api = { baslatPencere, finalDedupEkle, yazNorm, durumMetniMi };
  if (typeof module !== "undefined" && module.exports) { module.exports = api; return; }
  baslatPencere(kok);
})(typeof window !== "undefined" ? window : globalThis);
