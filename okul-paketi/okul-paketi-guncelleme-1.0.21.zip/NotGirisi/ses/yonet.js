// 1.9.20 Ses yönlendirme: ses-ac → arka plan → OYSS sekmesinin tüm kareleri (tablo iframe'de olabilir).
(function (kok) {
  "use strict";
  function sesSekmeKaydet(gonderen, m) {
    const tabId = (m && m.sekme != null) ? m.sekme
      : (gonderen && gonderen.tab && gonderen.tab.id != null ? gonderen.tab.id : null);
    const frameId = (m && m.kare != null) ? m.kare
      : (gonderen && typeof gonderen.frameId === "number" ? gonderen.frameId : null);
    return { tabId: tabId == null ? null : tabId, frameId: frameId == null ? null : frameId };
  }
  function sesKareHedefleri(kayit) {
    const k = [];
    if (kayit && kayit.frameId != null && k.indexOf(kayit.frameId) < 0) k.push(kayit.frameId);
    if (k.indexOf(0) < 0) k.push(0);
    return k;
  }
  function sesParcaPaket(m) {
    if (!m) return null;
    return {
      tip: "nga-ses-parca",
      t: m.t || "",
      biriken: m.biriken || "",
      parcalar: m.parcalar || [],
      sira: m.sira || 0,
      z: m.z || Date.now(),
      final: m.final !== false
    };
  }
  function sesParcaDagit(paket, kareler, gonder) {
    const uniq = [];
    (kareler || [0]).forEach((id) => { if (uniq.indexOf(id) < 0) uniq.push(id); });
    uniq.forEach((id) => { try { gonder(id, paket); } catch (e) {} });
    return uniq.length;
  }
  function sesIcerikAl(m, isle) {
    if (!m || m.tip !== "nga-ses-parca") return false;
    if (m.final === false) return false;
    if (typeof isle === "function") isle(m);
    return true;
  }
  const api = { sesSekmeKaydet, sesKareHedefleri, sesParcaPaket, sesParcaDagit, sesIcerikAl };
  if (typeof module !== "undefined" && module.exports) { module.exports = api; return; }
  kok.NGASesYonet = api;
})(typeof self !== "undefined" ? self : globalThis);
