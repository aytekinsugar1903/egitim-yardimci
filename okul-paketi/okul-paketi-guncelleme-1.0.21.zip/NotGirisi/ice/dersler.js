// 1.7.0 Yerleşik ders listesi (yedek): e-Okul sayfasından okunan liste HER ZAMAN önceliklidir; bu liste yalnız açılır liste boş kalmasın diye.
// Kaynaklar (yalnız resmî çizelgelerdeki adlar, aynen):
//  ilk/orta: TTKB 23/05/2024 tarih 21 sayılı karar, İlköğretim Kurumları (İlkokul ve Ortaokul) Haftalık Ders Çizelgesi (zorunlu dersler)
//            https://ttkb.meb.gov.tr/meb_iys_dosyalar/2025_02/10103210_ilkogretimkurumlari_hdc_2024_21.pdf
//  lise:     TTKB 2025 Anadolu Lisesi Haftalık Ders Çizelgesi (ortak dersler + seçmeli)  https://ttkb.meb.gov.tr/meb_iys_dosyalar/2025_05/20144001_202505.pdf
// Meslek lisesi alan dersleri, İHL meslek dersleri ve Hazırlık sınıfı dersleri doğrulanamadığı için EKLENMEDİ (e-Okul sayfasından okunur).
(function (kok) {
  'use strict';
  const ILK_ORTA = ['Türkçe', 'Matematik', 'Hayat Bilgisi', 'Fen Bilimleri', 'Sosyal Bilgiler', 'T.C. İnkılap Tarihi ve Atatürkçülük', 'Yabancı Dil', 'Din Kültürü ve Ahlak Bilgisi', 'Görsel Sanatlar', 'Müzik', 'Beden Eğitimi ve Oyun', 'Beden Eğitimi ve Spor', 'Teknoloji ve Tasarım', 'Trafik Güvenliği', 'Bilişim Teknolojileri ve Yazılım', 'Rehberlik ve Kariyer Planlama', 'İnsan Hakları, Vatandaşlık ve Demokrasi'];
  const LISE = ['TÜRK DİLİ VE EDEBİYATI', 'DİN KÜLTÜRÜ VE AHLAK BİLGİSİ', 'TARİH', 'T.C. İNKILAP TARİHİ VE ATATÜRKÇÜLÜK', 'COĞRAFYA', 'MATEMATİK', 'FİZİK', 'KİMYA', 'BİYOLOJİ', 'FELSEFE', 'BİRİNCİ YABANCI DİL', 'BEDEN EĞİTİMİ VE SPOR', 'GÖRSEL SANATLAR/MÜZİK', 'SAĞLIK BİLGİSİ VE TRAFİK KÜLTÜRÜ', 'SEÇMELİ MATEMATİK', 'TEMEL MATEMATİK', 'SEÇMELİ FİZİK', 'SEÇMELİ KİMYA', 'SEÇMELİ BİYOLOJİ', 'SEÇMELİ TÜRK DİLİ VE EDEBİYATI', 'SEÇMELİ TARİH', 'SEÇMELİ COĞRAFYA', 'PSİKOLOJİ', 'SOSYOLOJİ', 'MANTIK', 'SEÇMELİ BİRİNCİ YABANCI DİL', 'SEÇMELİ İKİNCİ YABANCI DİL', 'OSMANLI TÜRKÇESİ', 'KUR’AN-I KERİM', 'PEYGAMBERİMİZİN HAYATI', 'TEMEL DİNÎ BİLGİLER', 'BİLİŞİM TEKNOLOJİLERİ VE YAZILIM', 'PROJE TASARIMI VE UYGULAMALARI', 'TEMEL HUKUK BİLGİSİ', 'GİRİŞİMCİLİK'];
  // Sınıf adı e-Okul'daki gibi: "11. Sınıf / F Şubesi" (e-Okul Sınıf Listesi dışa aktarımında görüldü)
  const sinifAdi = (s) => { const m = /^(\d{1,2})-(.+)$/.exec(String(s || '')); return m ? m[1] + '. Sınıf / ' + m[2] + ' Şubesi' : String(s || ''); };
  const dersler = (sinif) => { const d = +String(sinif || '').split('-')[0]; return d >= 1 && d <= 8 ? ILK_ORTA.slice() : d >= 9 ? LISE.slice() : ILK_ORTA.concat(LISE); };
  const benzersiz = (arr) => {
    const out = [], gor = new Set();
    (arr || []).forEach((x) => {
      const t = String(x || '').trim();
      if (!t) return;
      const k = t.replace(/I/g, 'ı').replace(/İ/g, 'i').toLocaleLowerCase('tr');
      if (gor.has(k)) return;
      gor.add(k);
      out.push(t);
    });
    return out;
  };
  // Sayfa listesi (o şubenin e-Okul ders seçimi) > şube önbelleği > MEB çizelgesi + elle eklenenler.
  // "Son okunan" genel listeye düşülmez (başka şubenin kısa listesi her sınıfa yayılmasın).
  function dersListesiKur(opts) {
    opts = opts || {};
    const extra = opts.extra || [];
    const sayfa = (opts.sayfa || []).map((x) => String(x || '').trim()).filter(Boolean);
    const cache = (opts.cache || []).map((x) => String(x || '').trim()).filter(Boolean);
    const meb = (opts.meb && opts.meb.length) ? opts.meb : dersler(opts.sinif);
    if (sayfa.length) return benzersiz(sayfa.concat(extra));
    if (cache.length) return benzersiz(cache.concat(extra));
    return benzersiz(meb.concat(extra));
  }
  function subeAnahtar(sinif, sube) {
    const s = String(sinif || '').trim();
    const u = String(sube || '').trim().toLocaleUpperCase('tr');
    if (/^\d{1,2}-[A-ZÇĞİÖŞÜ]/.test(s)) return s.replace(/\s+/g, '');
    if (s && u) return s + '-' + u;
    return s || u;
  }
  function kayitEslesir(sinifAnahtar, ders, secim) {
    if (!secim) return true;
    const ham = String(sinifAnahtar || '').trim();
    const m = /^(\d{1,2}|ANA|HAZ)-(.+)$/.exec(ham) || /^(\d{1,2})$/.exec(ham);
    const seviye = m ? String(m[1]) : '';
    const harf = m && m[2] ? String(m[2]).toLocaleUpperCase('tr') : '';
    const siniflar = secim.siniflar || [];
    const subeler = secim.subeler || [];
    const derslerSec = secim.dersler || [];
    if (siniflar.length && seviye && siniflar.map(String).indexOf(seviye) < 0) return false;
    if (subeler.length) {
      const aday = [ham, seviye && harf ? (seviye + '-' + harf) : ''].filter(Boolean);
      const var_ = subeler.some((x) => aday.indexOf(String(x).trim()) >= 0 || aday.indexOf(String(x).trim().toLocaleUpperCase('tr')) >= 0);
      if (!var_) return false;
    }
    if (ders && derslerSec.length) {
      const kd = String(ders).replace(/I/g, 'ı').replace(/İ/g, 'i').toLocaleLowerCase('tr');
      if (!derslerSec.some((d) => String(d).replace(/I/g, 'ı').replace(/İ/g, 'i').toLocaleLowerCase('tr') === kd)) return false;
    }
    return true;
  }
  const api = { ILK_ORTA, LISE, dersler, sinifAdi, dersListesiKur, kayitEslesir, subeAnahtar, benzersiz };
  if (typeof module !== 'undefined') module.exports = api; else kok.NGADersler = api;
})(typeof window !== 'undefined' ? window : globalThis);
