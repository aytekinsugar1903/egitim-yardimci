/* Ürün lisans ayarı — Evrak Asistanı / Eyüp ŞEKER */
self.EA_LISANS_AYAR = {
  "urun": "notgirisi",
  "kabul": [
    "notgirisi"
  ],
  "ad": "e-Okul Not Girişi Asistanı",
  "surum": "1.9.12",
  "depo": "ea_lisans_notgirisi_v1",
  "hazirMetin": "e-Okul sekmesini yenileyin; Not Girişi paneli açılır."
};
