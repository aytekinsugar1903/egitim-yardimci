/* © 2026 Eyüp ŞEKER — Evrak Asistanı. Tüm hakları saklıdır. */
// Evrak Asistanı v3.6.30 (DENEYSEL) — "Evrak Ekleri" yerel okuyucu: PDF (eklentiyle gelen pdf.js), DOCX, XLSX, XLS (yaklaşık).
// Tüm işlem bu bilgisayarda, tarayıcıda yapılır; ek dosyası hiçbir dış sunucuya gönderilmez. Dış kütüphane yok (ZIP: tarayıcının DecompressionStream'i).
(function (G) {
    'use strict';
    const td8 = new TextDecoder("utf-8");
    const u16 = (b, o) => b[o] | (b[o + 1] << 8);
    const u32 = (b, o) => (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;
    async function inflateRaw(data) {
        const ds = new DecompressionStream("deflate-raw");
        const out = new Response(new Blob([data]).stream().pipeThrough(ds));
        return new Uint8Array(await out.arrayBuffer());
    }
    // ZIP (merkezî dizin) okuyucu → { ad: async () => Uint8Array }
    function unzipIndex(buf) {
        const b = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
        let eocd = -1;
        for (let i = b.length - 22; i >= Math.max(0, b.length - 66000); i--) { if (u32(b, i) === 0x06054b50) { eocd = i; break; } }
        if (eocd < 0) throw new Error("ZIP değil");
        const n = u16(b, eocd + 10); let p = u32(b, eocd + 16);
        const files = {};
        for (let k = 0; k < n && p + 46 <= b.length; k++) {
            if (u32(b, p) !== 0x02014b50) break;
            const method = u16(b, p + 10), csize = u32(b, p + 20), nl = u16(b, p + 28), el = u16(b, p + 30), cl = u16(b, p + 32), lho = u32(b, p + 42);
            const name = td8.decode(b.subarray(p + 46, p + 46 + nl));
            files[name] = async () => {
                const ds = lho + 30 + u16(b, lho + 26) + u16(b, lho + 28);
                const raw = b.subarray(ds, ds + csize);
                if (method === 0) return raw;
                if (method === 8) return inflateRaw(raw);
                throw new Error("desteklenmeyen sıkıştırma " + method);
            };
            p += 46 + nl + el + cl;
        }
        return files;
    }
    const xmlUnesc = s => s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#(\d+);/g, (m, d) => String.fromCodePoint(+d)).replace(/&#x([0-9a-f]+);/gi, (m, h) => String.fromCodePoint(parseInt(h, 16))).replace(/&amp;/g, "&");
    async function docxText(buf) {
        const z = unzipIndex(buf);
        if (!z["word/document.xml"]) throw new Error("word/document.xml yok");
        const x = td8.decode(await z["word/document.xml"]());
        const paras = [], tables = [];
        // tablolar: ilk satırı form alanı adayı
        x.replace(/<w:tbl>([\s\S]*?)<\/w:tbl>/g, (m, t) => {
            const rows = [];
            t.replace(/<w:tr[ >][\s\S]*?<\/w:tr>/g, tr => { const cells = []; tr.replace(/<w:tc>([\s\S]*?)<\/w:tc>/g, (mm, tc) => { cells.push(xmlUnesc((tc.match(/<w:t[^>]*>[^<]*<\/w:t>/g) || []).map(s => s.replace(/<[^>]+>/g, "")).join("")).trim()); return ""; }); rows.push(cells); return ""; });
            tables.push(rows); return "";
        });
        x.replace(/<w:p[ >][\s\S]*?<\/w:p>/g, p => { const t = xmlUnesc((p.match(/<w:t[^>]*>[^<]*<\/w:t>|<w:tab\/>/g) || []).map(s => s === "<w:tab/>" ? "\t" : s.replace(/<[^>]+>/g, "")).join("")); paras.push(t); return ""; });
        return { text: paras.join("\n").replace(/\n{3,}/g, "\n\n").trim(), tables: tables };
    }
    function colIdx(ref) { const m = /^([A-Z]+)/.exec(ref || ""); let n = 0; if (!m) return -1; for (const c of m[1]) n = n * 26 + (c.charCodeAt(0) - 64); return n - 1; }
    async function xlsxRead(buf, maxRows) {
        const z = unzipIndex(buf);
        const ss = [];
        if (z["xl/sharedStrings.xml"]) {
            const x = td8.decode(await z["xl/sharedStrings.xml"]());
            x.replace(/<si>([\s\S]*?)<\/si>/g, (m, si) => { ss.push(xmlUnesc((si.match(/<t[^>]*>[^<]*<\/t>/g) || []).map(s => s.replace(/<[^>]+>/g, "")).join(""))); return ""; });
        }
        const names = [];
        if (z["xl/workbook.xml"]) td8.decode(await z["xl/workbook.xml"]()).replace(/<sheet [^>]*name="([^"]*)"/g, (m, n) => { names.push(xmlUnesc(n)); return ""; });
        const sheetFiles = Object.keys(z).filter(k => /^xl\/worksheets\/sheet\d+\.xml$/.test(k)).sort((a, b) => parseInt(a.match(/\d+/)) - parseInt(b.match(/\d+/)));
        const sheets = [];
        for (let si = 0; si < sheetFiles.length && si < 5; si++) {
            const x = td8.decode(await z[sheetFiles[si]]());
            const rows = [];
            x.replace(/<row([^>]*?)(?:\/>|>([\s\S]*?)<\/row>)/g, (m, ra, r) => {
                const rn = +((ra.match(/ r="(\d+)"/) || [])[1] || (rows.length + 1)); // satır numarasına göre yerleştir (boş satırlar korunur)
                if (rn > (maxRows || 60)) return "";
                while (rows.length < rn - 1) rows.push([]);
                r = r || "";
                const cells = [];
                r.replace(/<c ([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g, (mm, attrs, inner) => {
                    const ref = (attrs.match(/r="([A-Z]+\d+)"/) || [])[1], t = (attrs.match(/t="([^"]+)"/) || [])[1];
                    let v = "";
                    if (inner) {
                        if (t === "inlineStr") v = xmlUnesc((inner.match(/<t[^>]*>[^<]*<\/t>/g) || []).map(s => s.replace(/<[^>]+>/g, "")).join(""));
                        else { const vv = (inner.match(/<v>([^<]*)<\/v>/) || [])[1]; if (vv !== undefined) v = t === "s" ? (ss[+vv] || "") : xmlUnesc(vv); }
                    }
                    const ci = ref ? colIdx(ref) : cells.length;
                    while (cells.length < ci) cells.push("");
                    cells[ci] = String(v).trim();
                    return "";
                });
                rows.push(cells); return "";
            });
            sheets.push({ name: names[si] || ("Sayfa" + (si + 1)), rows: rows });
        }
        return { sheets: sheets };
    }
    // XLS (BIFF8) — yaklaşık: SST (paylaşılan metin) kaydındaki metinler sırasıyla alınır; hücre konumu çözülmez.
    function xlsStrings(buf) {
        const b = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
        const out = [];
        for (let i = 0; i + 8 < b.length && out.length < 400; i++) {
            if (u16(b, i) !== 0x00FC) continue;
            const len = u16(b, i + 2); if (len < 8 || i + 4 + len > b.length) continue;
            const total = u32(b, i + 4), uniq = u32(b, i + 8); if (!uniq || uniq > total || uniq > 100000) continue;
            let p = i + 12; const end = i + 4 + len;
            for (let k = 0; k < uniq && p + 3 <= end; k++) {
                const cc = u16(b, p), fl = b[p + 2]; p += 3;
                let rich = 0, ext = 0;
                if (fl & 8) { rich = u16(b, p); p += 2; }
                if (fl & 4) { ext = u32(b, p); p += 4; }
                let s = "";
                if (fl & 1) { for (let j = 0; j < cc && p + 1 < end; j++, p += 2) s += String.fromCharCode(u16(b, p)); }
                else { for (let j = 0; j < cc && p < end; j++, p++) s += String.fromCharCode(b[p]); }
                p += rich * 4 + ext;
                if (s.trim()) out.push(s.trim());
            }
            break; // CONTINUE kayıtlarına bölünmüş uzun SST'ler kısmen okunur
        }
        return out;
    }
    // PDF — eklentiyle gelen pdf.js (uzak kod yok). İçerik betiğinden dinamik import; çalışan (worker) olmazsa pdf.js sahte çalışana düşer.
    let pdfLibP = null;
    async function pdfLib() {
        if (!pdfLibP) pdfLibP = (async () => {
            const url = (G.chrome && chrome.runtime && chrome.runtime.getURL) ? chrome.runtime.getURL("pdfjs/pdf.min.mjs") : G.__EBYS_PDFJS_URL;
            const lib = await import(url);
            try { lib.GlobalWorkerOptions.workerSrc = url.replace(/pdf\.min\.mjs$/, "pdf.worker.min.mjs"); } catch (e) {}
            return lib;
        })();
        return pdfLibP;
    }
    async function pdfText(buf, maxPages) {
        const lib = await pdfLib();
        const doc = await lib.getDocument({ data: new Uint8Array(buf), isEvalSupported: false, useSystemFonts: false, disableFontFace: true }).promise;
        const n = Math.min(doc.numPages, maxPages || 6), out = [];
        for (let p = 1; p <= n; p++) {
            const tc = await (await doc.getPage(p)).getTextContent();
            let line = "", lastY = null;
            for (const it of tc.items) { const y = it.transform ? Math.round(it.transform[5]) : null; if (lastY !== null && y !== null && Math.abs(y - lastY) > 2) { out.push(line); line = ""; } line += it.str; lastY = y; if (it.hasEOL) { out.push(line); line = ""; lastY = null; } }
            if (line) out.push(line);
        }
        try { doc.destroy(); } catch (e) {}
        return out.join("\n").replace(/[ \t]+/g, " ").trim();
    }
    // ---- içerikten istenenler / form alanları
    const REQ_RE = /(istenmektedir|istenmekte|gönderilmesi|gönderilmesini|doldurul|bildirilmesi|bildirilmesini|iletilmesi|iletilmesini|yüklenmesi|hazırlanması|teslim edilmesi|eksiksiz|en geç|tarihine kadar|son gün)/i;
    function requestedLines(text, max) {
        const out = [];
        String(text || "").split(/\n|(?<=[.!?])\s+/).map(s => s.replace(/\s+/g, " ").trim()).forEach(s => { if (s.length >= 15 && s.length <= 300 && REQ_RE.test(s) && !out.includes(s) && out.length < (max || 6)) out.push(s); });
        return out;
    }
    const isLabel = s => { const t = String(s || "").trim(); return t.length >= 2 && t.length <= 60 && /[A-Za-zÇĞİÖŞÜçğıöşü]/.test(t) && !/^\d+([.,]\d+)?$/.test(t); };
    // Excel/tablo formu: en çok metin etiketi içeren ilk satırlardan biri başlık satırı sayılır; altındaki satırlar boşsa "doldurulacak form".
    function formFieldsFromRows(rows) {
        let best = -1, bestN = 0;
        for (let i = 0; i < Math.min(rows.length, 15); i++) { const n = (rows[i] || []).filter(isLabel).length; if (n > bestN && n >= 2) { best = i; bestN = n; } }
        if (best < 0) return null;
        const hdr = rows[best].map(x => String(x || "").trim());
        const fields = hdr.filter(isLabel).filter((x, i, a) => a.indexOf(x) === i).slice(0, 40);
        const below = rows.slice(best + 1, best + 30);
        const filled = below.filter(r => (r || []).some((c, i) => hdr[i] && String(c || "").trim() && !/^\d+$/.test(String(c).trim()))).length;
        const title = rows.slice(0, best).map(r => (r || []).filter(Boolean).join(" ")).filter(Boolean).join(" — ").slice(0, 200);
        return { headerRow: best + 1, fields: fields, emptyForm: filled === 0, filledRows: filled, title: title };
    }
    function kindOf(name) {
        const m = /\.([a-z0-9]{2,5})\s*$/i.exec(String(name || "").replace(/[)\s]+$/, ""));
        return m ? m[1].toLowerCase() : "";
    }
    // Tek giriş: bayt → { kind, text, fields, form, points, note }
    async function analyze(buf, fileName) {
        const kind = kindOf(fileName);
        const b = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
        const isZip = b[0] === 0x50 && b[1] === 0x4B, isPdf = b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46, isCfb = b[0] === 0xD0 && b[1] === 0xCF;
        const res = { kind: kind, text: "", form: null, sheets: null, points: [], note: "", approx: false };
        if (isPdf || kind === "pdf") {
            res.kind = "pdf"; res.text = await pdfText(b);
            if (!res.text) res.note = "PDF'te metin katmanı yok (taranmış görüntü olabilir).";
        } else if (isZip && (kind === "docx" || kind === "odt" || !kind)) {
            const d = await docxText(b); res.kind = "docx"; res.text = d.text;
            const t = d.tables.find(rows => formFieldsFromRows(rows)); if (t) res.form = formFieldsFromRows(t);
            const pf = d.text.split("\n").map(l => (/^\s*([^:：\t_]{2,50}?)\s*[:：]\s*(_{3,}|\.{4,}|…{2,}|\t+)/.exec(l) || /^\s*([^:：\t_]{2,50}?)\s*[:：].*_{3,}/.exec(l) || [])[1]).filter(Boolean).map(x => x.trim()); // v3.6.32: "ETİKET : ____" satırları
            const vt = d.tables.find(rows => rows.filter(r => r.length === 2 && isLabel(r[0]) && !r[1]).length >= 2);
            if (vt) { const f = vt.filter(r => r.length === 2 && isLabel(r[0]) && !r[1]).map(r => r[0].replace(/[:：]\s*$/, "")); if (!res.form || f.length >= res.form.fields.length - 1) res.form = { headerRow: 0, fields: f, emptyForm: true, filledRows: 0, title: "", vertical: true }; }
            if (pf.length) res.form = { headerRow: 0, fields: pf.concat(res.form ? res.form.fields.filter(x => !pf.includes(x)) : []), emptyForm: true, filledRows: 0, title: "", paragraph: true };
        } else if (isZip && (kind === "xlsx" || kind === "xlsm")) {
            const x = await xlsxRead(b); res.kind = "xlsx"; res.sheets = x.sheets;
            for (const s of x.sheets) { const f = formFieldsFromRows(s.rows); if (f) { f.sheet = s.name; res.form = f; break; } }
            res.text = x.sheets.map(s => s.rows.slice(0, 20).map(r => r.filter(Boolean).join(" | ")).filter(Boolean).join("\n")).join("\n");
        } else if (isCfb && kind === "xls") {
            const ss = xlsStrings(b); res.kind = "xls"; res.approx = true; res.text = ss.join("\n");
            const lab = ss.filter(isLabel).slice(0, 40);
            if (lab.length >= 2) res.form = { headerRow: 0, fields: lab, emptyForm: null, filledRows: null, title: "", approx: true };
            res.note = "Eski Excel (.xls): metinler yaklaşık okundu; sütun sırası doğrulanmalı.";
        } else {
            res.note = "Bu dosya türü okunmuyor (" + (kind || "bilinmiyor") + ").";
            return res;
        }
        res.points = requestedLines(res.text, 4);
        if (res.form && res.form.fields.length) res.points.push("Form alanları: " + res.form.fields.slice(0, 8).join(", ") + (res.form.fields.length > 8 ? "…" : ""));
        return res;
    }

    // ===================== v3.6.30: OKUL BİLGİLERİ PROFİLİ + EXCEL FORM DOLDURMA (yerel) =====================
    // v3.6.47: Kurum Ayarları alanları (okulAdi = kurumAdi ile eş anlamlı; form doldurma eski anahtarları da tanır)
    const PROFILE_FIELDS = [
        ["kurumTuru", "Kurum türü", ["kurum turu", "kurum tipi"]],
        ["okulAdi", "Kurum adı", ["okul adi", "okulun adi", "kurum adi", "kurumun adi", "okul", "kurum", "okul ismi", "kurumadi"]],
        ["ustBirim", "Bağlı üst birim", ["ust birim", "bagli birim", "bagli oldugu birim", "ust kurum"]],
        ["kurumKodu", "Kurum kodu", ["kurum kodu", "okul kodu", "kurum kod", "mebbis kodu", "kurum no"]],
        ["detsis", "DETSİS / MERSİS no", ["detsis", "mersis", "detsis no", "mersis no"]],
        ["il", "İl", ["il", "ili", "il adi"]],
        ["ilce", "İlçe", ["ilce", "ilcesi", "ilce adi"]],
        ["adres", "Adres", ["adres", "adresi", "okul adresi", "kurum adresi", "acik adres"]],
        ["telefon", "Telefon", ["telefon", "tel", "telefon no", "telefon numarasi", "okul telefonu", "irtibat telefonu", "tel no"]],
        ["faks", "Faks", ["faks", "fax", "belgegecer"]],
        ["eposta", "E-posta", ["e posta", "eposta", "e mail", "email", "mail", "elektronik posta", "e posta adresi"]],
        ["web", "Web adresi", ["web", "web adresi", "internet adresi", "web sitesi"]],
        ["mudur", "Amir adı (Müdür / İlçe MEM Müdürü)", ["mudur", "okul muduru", "kurum muduru", "mudurun adi soyadi", "muduru", "kurum amiri", "amir adi"]],
        ["amirUnvani", "Amir unvanı", ["amir unvani", "unvan", "imza unvani"]],
        ["mudurYrd", "Müdür yardımcısı / şube müdürü", ["mudur yardimcisi", "mudur yrd", "mudur yardimcilari", "sorumlu mudur yardimcisi", "sube muduru"]],
        ["irtibatKisi", "İrtibat kişisi", ["irtibat", "irtibat kisisi", "sorumlu", "sorumlu kisi", "yetkili", "dolduran", "hazirlayan"]],
        ["ogrenciSayisi", "Öğrenci sayısı", ["ogrenci sayisi", "toplam ogrenci", "ogrenci mevcudu", "mevcut", "toplam ogrenci sayisi"]],
        ["kizOgrenci", "Kız öğrenci sayısı", ["kiz", "kiz ogrenci", "kiz ogrenci sayisi"]],
        ["erkekOgrenci", "Erkek öğrenci sayısı", ["erkek", "erkek ogrenci", "erkek ogrenci sayisi"]],
        ["ogretmenSayisi", "Öğretmen sayısı", ["ogretmen sayisi", "toplam ogretmen", "kadrolu ogretmen", "ogretmen"]],
        ["personelSayisi", "Personel sayısı", ["personel sayisi", "toplam personel", "personel"]],
        ["derslikSayisi", "Derslik sayısı", ["derslik sayisi", "derslik", "sinif sayisi", "dershane sayisi"]],
        ["subeSayisi", "Şube sayısı", ["sube sayisi", "sube"]],
        ["ogretimSekli", "Öğretim şekli", ["ogretim sekli", "normal ikili", "tam gun yarim gun"]],
        ["egitimYili", "Eğitim-öğretim yılı", ["egitim ogretim yili", "ogretim yili", "egitim yili"]]
    ];
    const fold = s => String(s || "").toLocaleLowerCase("tr-TR").replace(/ı/g, "i").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ş/g, "s").replace(/ö/g, "o").replace(/ç/g, "c").replace(/[^a-z0-9]+/g, " ").trim();
    // etiket → profil alanı (bulanık: tam eşleşme > baştan eşleşme > tüm kelimeler içerilir); kısa eş anlamlılar (il, tel…) yalnızca tam eşleşir
    // v3.6.32: TUTUCU eşleştirme. Okul düzeyindeki değer yalnızca açıkça okulu tarif eden alana yazılır.
    //  - Başka kişi/birime ait alan (işletme, danışman, kulüp, öğrenci, veli…) → asla.
    //  - Sayılar (öğrenci/öğretmen/derslik…) yalnızca "etiket : değer" alanında, sınıf/cinsiyet/alan/dal/rakam kırılımı YOKSA.
    //  - mode "row" (yatay veri tablosu başlığı): yalnızca kimlik alanları (okul adı, kurum kodu, il, ilçe) ve tablo alan/dal/sınıf/işletme tablosu DEĞİLSE.
    //    (v3.6.31 hatası: "9. Sınıf Erkek" başlığı "erkek" eş anlamlısının sonda eşleşmesiyle Erkek öğrenci sayısını alıyordu.)
    const QUAL_RE = /\b(kulup|kulubu|kolu|danisman|danismani|ogretmenin|ogretmenlerin|velinin|velisi|ogrencinin|ogrencilerin|personelin|katilimci|katilimcinin|gorevlinin|isletme|isletmenin|isletmesi|stajyer|usta|firma|firmanin|sirket|koordinator)\b/;
    const BREAKDOWN_RE = /\d|\b(sinif|sinifi|kiz|erkek|alan|alani|dal|dali|program|brans|subesi|yas|donem)\b/;
    const DATA_TABLE_RE = /\b(alan|dal|sinif|isletme|isletmenin|brans|adi soyadi|ad soyad|tc kimlik|ogrenci adi|ogrencinin)\b|\b\d+\s*(\.|\b)\s*sinif/;
    const ID_KEYS = new Set(["okulAdi", "kurumKodu", "il", "ilce"]);
    const COUNT_KEYS = new Set(["ogrenciSayisi", "kizOgrenci", "erkekOgrenci", "ogretmenSayisi", "personelSayisi", "derslikSayisi", "subeSayisi"]);
    const CONTACT_KEYS = new Set(["telefon", "eposta", "faks", "adres", "web", "irtibatKisi", "mudurYrd", "mudur"]);
    function matchField(label, ctxTitle, mode) {
        const k = matchField0(label);
        if (!k) return null;
        const f = fold(label), ctx = fold(ctxTitle || "");
        if (QUAL_RE.test(f) && !ID_KEYS.has(k)) return null;
        if (COUNT_KEYS.has(k) && (BREAKDOWN_RE.test(f.replace(/\b(kiz|erkek)\b/, k === "kizOgrenci" || k === "erkekOgrenci" ? "" : "$&")) || QUAL_RE.test(ctx) || BREAKDOWN_RE.test(ctx.replace(/\b(egitim ogretim yili|\d{4}\s*\d{4})\b/g, "")))) return null;
        if ((k === "kizOgrenci" || k === "erkekOgrenci") && !/ogrenci/.test(f)) return null; // yalnız "Erkek"/"Kız" başlığı yetmez
        if (ctx && QUAL_RE.test(ctx) && (COUNT_KEYS.has(k) || CONTACT_KEYS.has(k))) return null;
        if (mode === "row") {
            if (!ID_KEYS.has(k)) { if (!(/\b(okul|okulun|kurum|kurumun)\b/.test(f) && CONTACT_KEYS.has(k))) return null; }
        }
        return k;
    }
    function isDataTable(headers, title) { const h = fold((headers || []).join(" ") + " " + (title || "")); return DATA_TABLE_RE.test(h); }
    function matchField0(label) {
        const f = fold(label).replace(/\b(nin|nın|in|ın|un|ün|no|numarasi)\b$/, "").trim();
        if (!f || f.length > 60) return null;
        if (/\b(formu|listesi|cizelgesi|tablosu|cetveli|raporu)$/.test(f)) return null; // başlık, alan değil
        const fw = f.split(" ").length;
        let best = null, bestScore = 0;
        for (const [key, , syns] of PROFILE_FIELDS) {
            for (const sy of syns) {
                let sc = 0;
                if (f === sy) sc = 100 + sy.length;
                else if (sy.length >= 5 && (f.startsWith(sy + " ") || f.endsWith(" " + sy))) sc = 60 + sy.length;
                else if (sy.length >= 5 && fw <= sy.split(" ").length + 2 && sy.split(" ").every(w => (" " + f + " ").includes(" " + w + " "))) sc = 40 + sy.length;
                if (sc > bestScore) { bestScore = sc; best = key; }
            }
        }
        return best;
    }
    const enc = new TextEncoder();
    const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
    const crc32 = d => { let c = 0xFFFFFFFF; for (let i = 0; i < d.length; i++) c = CRC[(c ^ d[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
    function zipStore(files) { // [{name, data:Uint8Array}] → Uint8Array (sıkıştırmasız ZIP; Excel açar)
        const parts = [], cen = []; let off = 0;
        const w16 = v => [v & 255, (v >>> 8) & 255], w32 = v => [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255];
        for (const f of files) {
            const nm = enc.encode(f.name), c = crc32(f.data), L = f.data.length;
            const lh = new Uint8Array([].concat(w32(0x04034b50), w16(20), w16(0x0800), w16(0), w16(0), w16(0x21), w32(c), w32(L), w32(L), w16(nm.length), w16(0)));
            parts.push(lh, nm, f.data);
            cen.push(new Uint8Array([].concat(w32(0x02014b50), w16(20), w16(20), w16(0x0800), w16(0), w16(0), w16(0x21), w32(c), w32(L), w32(L), w16(nm.length), w16(0), w16(0), w16(0), w16(0), w32(0), w32(off))), nm);
            off += lh.length + nm.length + L;
        }
        const cs = cen.reduce((a, b) => a + b.length, 0);
        const end = new Uint8Array([].concat(w32(0x06054b50), w16(0), w16(0), w16(files.length), w16(files.length), w32(cs), w32(off), w16(0)));
        const all = parts.concat(cen, [end]); const out = new Uint8Array(all.reduce((a, b) => a + b.length, 0)); let p = 0; for (const a of all) { out.set(a, p); p += a.length; }
        return out;
    }
    const xesc = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    const cname = i => { let s = ""; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
    // Form yerleşimi: (a) yatay — başlık satırı, değer altındaki satıra; (b) dikey — etiket hücresi, değer sağındaki boş hücreye.
    function planFill(rows, profile) {
        const P = profile || {}, plan = [], seen = new Set();
        const hf = formFieldsFromRows(rows);
        const vertical = [];
        rows.slice(0, 60).forEach((r, ri) => { (r || []).forEach((c, ci) => { if (isLabel(c) && /[:：]?\s*$/.test(c) && matchField(c) && !String((r[ci + 1] || "")).trim() && (r.filter(Boolean).length <= 2)) vertical.push({ ri, ci, label: c }); }); });
        if (vertical.length >= Math.max(2, hf ? hf.fields.filter(matchField).length : 0)) {
            vertical.forEach(v => { const key = matchField(v.label); const val = P[key]; plan.push({ label: v.label.replace(/[:：]\s*$/, ""), key, row: v.ri + 1, col: v.ci + 1, value: val ? String(val) : "" }); });
            // eşleşmeyen dikey etiketler: "........:" biçimli, sağı boş → sarı
            rows.slice(0, 60).forEach((r, ri) => { const nz = (r || []).map((c, ci) => [c, ci]).filter(x => String(x[0] || "").trim()); if (nz.length === 1 && /[:：]\s*$/.test(nz[0][0]) && !matchField(nz[0][0])) plan.push({ label: String(nz[0][0]).replace(/[:：]\s*$/, ""), key: null, row: ri + 1, col: nz[0][1] + 1, value: "" }); });
            return { layout: "dikey", items: plan };
        }
        if (!hf) return { layout: "yok", items: [] };
        const hr = hf.headerRow - 1, hdr = rows[hr] || [];
        const ctx = hf.title || "";
        const dataRow = rows[hr + 1] || [];
        hdr.forEach((h, ci) => {
            if (!isLabel(h) || seen.has(ci)) return; seen.add(ci);
            if (/^(s\.?\s*no|sn|sira( no)?|no)$/i.test(fold(h))) return;
            const existing = String(dataRow[ci] == null ? "" : dataRow[ci]).trim();
            const dataT = isDataTable(hdr, ctx);
            let key = matchField(h, ctx, "row"); if (key && dataT && !ID_KEYS.has(key)) key = null;
            if (key && dataT && /\b(alan|dal|sinif|isletme)\b/.test(fold(hdr.join(" ") + " " + ctx))) key = null; // alan/dal/sınıf/işletme tablosu: hiçbir okul değeri yazılmaz
            const val = key ? P[key] : "";
            if (existing) { plan.push({ label: String(h), key, row: hr + 2, col: ci, value: existing, existing: true }); return; } // formda zaten yazılı: dokunulmaz
            plan.push({ label: String(h), key, row: hr + 2, col: ci, value: val ? String(val) : "" });
        });
        return { layout: "yatay", items: plan, headerRow: hf.headerRow };
    }
    // XLSX formun KENDİSİNİ doldurur (biçim korunur): değerler satır içi metin olarak yazılır, boş kalanlar sarı.
    async function fillXlsx(buf, profile) {
        const z = unzipIndex(buf);
        const x = await xlsxRead(buf, 80);
        let si = 0, pl = null;
        for (; si < x.sheets.length; si++) { pl = planFill(x.sheets[si].rows, profile); if (pl.items.length) break; }
        if (!pl || !pl.items.length) return { ok: false, error: "Form alanı bulunamadı", plan: pl };
        const sheetName = Object.keys(z).filter(k => /^xl\/worksheets\/sheet\d+\.xml$/.test(k)).sort((a, b) => parseInt(a.match(/\d+/)) - parseInt(b.match(/\d+/)))[si];
        let sx = td8.decode(await z[sheetName]());
        let st = z["xl/styles.xml"] ? td8.decode(await z["xl/styles.xml"]()) : null;
        let yellowXf = null;
        if (st) {
            const fc = +((st.match(/<fills count="(\d+)"/) || [])[1] || 0);
            st = st.replace(/<fills count="(\d+)">([\s\S]*?)<\/fills>/, (m, n, inner) => '<fills count="' + (+n + 1) + '">' + inner + '<fill><patternFill patternType="solid"><fgColor rgb="FFFFFF00"/><bgColor indexed="64"/></patternFill></fill></fills>');
            st = st.replace(/<cellXfs count="(\d+)">([\s\S]*?)<\/cellXfs>/, (m, n, inner) => { yellowXf = +n; return '<cellXfs count="' + (+n + 1) + '">' + inner + '<xf numFmtId="0" fontId="0" fillId="' + fc + '" borderId="0" xfId="0" applyFill="1"/></cellXfs>'; });
        }
        const setCell = (r, c, val, yellow) => {
            const ref = cname(c) + r;
            const cellX = (keepS) => '<c r="' + ref + '"' + (yellow && yellowXf !== null ? ' s="' + yellowXf + '"' : keepS) + (val ? ' t="inlineStr"><is><t xml:space="preserve">' + xesc(val) + '</t></is></c>' : '/>');
            const reC = new RegExp('<c r="' + ref + '"([^>]*?)(?:/>|>[\\s\\S]*?</c>)');
            if (reC.test(sx)) { sx = sx.replace(reC, (m, a) => cellX((a.match(/ s="\d+"/) || [""])[0])); return; }
            const reR = new RegExp('<row r="' + r + '"([^>]*?)(/>|>([\\s\\S]*?)</row>)');
            if (reR.test(sx)) {
                sx = sx.replace(reR, (m, a, tail, inner) => {
                    inner = inner || ""; const cells = inner.match(/<c [\s\S]*?(?:\/>|<\/c>)/g) || [];
                    let ins = cells.findIndex(cc => { const rr = (cc.match(/r="([A-Z]+)\d+"/) || [])[1]; return rr && (rr.length > cname(c).length || (rr.length === cname(c).length && rr > cname(c))); });
                    if (ins < 0) ins = cells.length; cells.splice(ins, 0, cellX(""));
                    return '<row r="' + r + '"' + a.replace(/ spans="[^"]*"/, "") + '>' + cells.join("") + '</row>';
                });
                return;
            }
            // satır yok → sırasına göre eklenir
            const rowsAll = sx.match(/<row r="(\d+)"/g) || []; const after = rowsAll.map(t => +t.match(/\d+/)[0]).find(n => n > r);
            const newRow = '<row r="' + r + '">' + cellX("") + '</row>';
            if (after) sx = sx.replace('<row r="' + after + '"', newRow + '<row r="' + after + '"'); else sx = sx.replace(/<sheetData\s*\/>/, '<sheetData>' + newRow + '</sheetData>').replace('</sheetData>', newRow + '</sheetData>');
        };
        pl.items.forEach(it => { if (!it.existing) setCell(it.row, it.col, it.value, !it.value); }); // dikey: col = etiketin sağı (0 tabanlı ci+1); yatay: col = başlık sütunu (0 tabanlı)
        const files = [];
        for (const k of Object.keys(z)) {
            if (/^xl\/calcChain\.xml$/.test(k)) continue;
            let d = await z[k]();
            if (k === sheetName) d = enc.encode(sx);
            else if (k === "xl/styles.xml" && st) d = enc.encode(st);
            else if (k === "[Content_Types].xml") d = enc.encode(td8.decode(d).replace(/<Override PartName="\/xl\/calcChain\.xml"[^>]*\/>/, ""));
            else if (k === "xl/_rels/workbook.xml.rels") d = enc.encode(td8.decode(d).replace(/<Relationship [^>]*calcChain[^>]*\/>/, ""));
            files.push({ name: k, data: new Uint8Array(d) });
        }
        return { ok: true, bytes: zipStore(files), plan: pl, sheet: x.sheets[si].name, filled: pl.items.filter(i => i.value && !i.existing).length, filledLabels: pl.items.filter(i => i.value && !i.existing).map(i => i.label + " = " + i.value), existing: pl.items.filter(i => i.existing).map(i => i.label), missing: pl.items.filter(i => !i.value).map(i => i.label) };
    }
    // XLS (yazılamaz) ve DOCX tablolar için: etiket | değer biçiminde YENİ bir xlsx (eksikler sarı)
    function labelsToXlsx(labels, profile, title) {
        const rows = labels.map(l => { const k = matchField(l); const v = k && profile && profile[k] ? String(profile[k]) : ""; return { l, v }; });
        const ss = [], sIdx = s => { let i = ss.indexOf(s); if (i < 0) { i = ss.length; ss.push(s); } return i; };
        let r = 0; const rx = [];
        const row = (cells) => { r++; rx.push('<row r="' + r + '">' + cells.map((c, i) => c.v === "" && !c.y ? "" : '<c r="' + cname(i) + r + '"' + (c.y ? ' s="1"' : c.b ? ' s="2"' : "") + (c.v === "" ? "/>" : ' t="s"><v>' + sIdx(c.v) + '</v></c>')).join("") + '</row>'); };
        if (title) row([{ v: title, b: 1 }]);
        row([{ v: "Alan", b: 1 }, { v: "Değer", b: 1 }]);
        rows.forEach(x => row([{ v: x.l }, { v: x.v, y: !x.v }]));
        const X = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
        const files = [
            ["[Content_Types].xml", X + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/></Types>'],
            ["_rels/.rels", X + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
            ["xl/workbook.xml", X + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Form" sheetId="1" r:id="rId1"/></sheets></workbook>'],
            ["xl/_rels/workbook.xml.rels", X + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/></Relationships>'],
            ["xl/styles.xml", X + '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFFF00"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="0" fillId="2" borderId="0" xfId="0" applyFill="1"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs></styleSheet>'],
            ["xl/worksheets/sheet1.xml", X + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><cols><col min="1" max="1" width="40" customWidth="1"/><col min="2" max="2" width="50" customWidth="1"/></cols><sheetData>' + rx.join("") + '</sheetData></worksheet>'],
            ["xl/sharedStrings.xml", X + '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' + ss.length + '" uniqueCount="' + ss.length + '">' + ss.map(s => '<si><t xml:space="preserve">' + xesc(s) + '</t></si>').join("") + '</sst>']
        ].map(([n, d]) => ({ name: n, data: enc.encode(d) }));
        return { ok: true, bytes: zipStore(files), filled: rows.filter(x => x.v).length, missing: rows.filter(x => !x.v).map(x => x.l) };
    }

    // v3.6.31: DOCX tablo formunu YERİNDE doldurur (biçim korunur): eşleşen boş hücrelere değer, eksik hücrelere sarı gölge (w:shd FFFF00).
    // Yerleşim: (a) yatay — başlık satırı + altındaki ilk satır; (b) dikey — "Etiket | (boş)" satırları.
    async function fillDocx(buf, profile) {
        const z = unzipIndex(buf);
        if (!z["word/document.xml"]) return { ok: false, error: "word/document.xml yok" };
        let x = td8.decode(await z["word/document.xml"]());
        const P = profile || {};
        const cellText = tc => xmlUnesc((tc.match(/<w:t[^>]*>[^<]*<\/w:t>/g) || []).map(t => t.replace(/<[^>]+>/g, "")).join("")).trim();
        const setTc = (tc, val, yellow) => {
            let out = tc;
            if (yellow) {
                if (/<w:tcPr>/.test(out)) out = out.replace(/<w:shd [^>]*\/>/, "").replace("<w:tcPr>", '<w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="FFFF00"/>');
                else if (/<w:tcPr\/>/.test(out)) out = out.replace("<w:tcPr/>", '<w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="FFFF00"/></w:tcPr>');
                else out = out.replace(/^<w:tc>/, '<w:tc><w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="FFFF00"/></w:tcPr>');
            }
            if (val) {
                const run = '<w:r><w:t xml:space="preserve">' + xesc(val) + '</w:t></w:r>';
                if (/<w:p\/>/.test(out)) out = out.replace("<w:p/>", "<w:p>" + run + "</w:p>");
                else if (/<w:p[ >]/.test(out)) out = out.replace(/(<w:p(?: [^>]*)?>(?:<w:pPr>[\s\S]*?<\/w:pPr>)?)/, "$1" + run);
                else out = out.replace("</w:tc>", "<w:p>" + run + "</w:p></w:tc>");
            }
            return out;
        };
        const items = [];
        // v3.6.32: tablo DIŞI "ETİKET : ____" paragrafları (yer tutucu: ___ / .... / … / sekme; birden çok run'a bölünmüş olabilir)
        const PH_RE = /(_{3,}|\.{4,}|…{2,}|\t+)/;
        const fillPara = (pX) => {
            const ts = []; const re = /(<w:t(?: [^>]*)?>)([^<]*)(<\/w:t>)|<w:tab\/>/g; let m;
            while ((m = re.exec(pX))) ts.push({ i: m.index, len: m[0].length, open: m[1] || "", txt: m[1] ? xmlUnesc(m[2]) : "\t", close: m[3] || "", tab: !m[1] });
            if (!ts.length) return pX;
            const full = ts.map(t => t.txt).join("");
            const mm = /^\s*([^:：\t_]{2,50}?)\s*[:：]\s*(_{3,}|\.{4,}|…{2,}|\t+)\s*$/.exec(full);
            if (!mm) {
                if (/_{3,}/.test(full) && /[:：]/.test(full)) { const lab = full.split(/[:：]/)[0].trim(); if (lab && lab.length <= 50) { items.push({ label: lab, key: null, value: "" }); return pX.replace(/<w:r>|<w:r (?=[^>]*>)/g, r => r).replace(/(<w:r(?: [^>]*)?>)(<w:rPr>)?/g, (a, r, rp) => r + (rp ? '<w:rPr><w:highlight w:val="yellow"/>' : '<w:rPr><w:highlight w:val="yellow"/></w:rPr>')); } }
                return pX;
            }
            const lab = mm[1].trim(); const k = matchField(lab, "", "label"); const v = k && P[k] ? String(P[k]) : "";
            items.push({ label: lab, key: k, value: v });
            const phStart = mm.index + mm[0].lastIndexOf(mm[2]), phEnd = phStart + mm[2].length;
            // yer tutucuyu içeren run'ları düzenle: ilk parçaya değer, diğer parçalardan yer tutucu silinir; değer yoksa sarı vurgu
            let pos = 0, out = "", last = 0, first = true;
            ts.forEach(t => {
                const a = pos, b = pos + t.txt.length; pos = b;
                const s0 = Math.max(a, phStart), e0 = Math.min(b, phEnd);
                out += pX.slice(last, t.i); last = t.i + t.len;
                if (s0 >= e0) { out += pX.slice(t.i, t.i + t.len); return; }
                if (v) {
                    const keep = t.txt.slice(0, s0 - a) + (first ? ((s0 > 0 && !/\s$/.test(full.slice(0, s0))) ? " " : "") + v : "") + t.txt.slice(e0 - a);
                    first = false;
                    out += t.tab ? (keep ? '<w:t xml:space="preserve">' + xesc(keep) + '</w:t>' : "") : '<w:t xml:space="preserve">' + xesc(keep) + '</w:t>';
                } else out += pX.slice(t.i, t.i + t.len);
            });
            out += pX.slice(last);
            if (!v) out = out.replace(/(<w:r(?: [^>]*)?>)(<w:rPr>)?/g, (a, r, rp) => r + (rp ? '<w:rPr><w:highlight w:val="yellow"/>' : '<w:rPr><w:highlight w:val="yellow"/></w:rPr>'));
            return out;
        };
        x = x.split(/(<w:tbl>[\s\S]*?<\/w:tbl>)/).map(seg => seg.startsWith("<w:tbl>") ? seg : seg.replace(/<w:p[ >][\s\S]*?<\/w:p>/g, pX => PH_RE.test(pX.replace(/<[^>]+>/g, "")) || /<w:tab\/>/.test(pX) ? fillPara(pX) : pX)).join("");
        x = x.replace(/<w:tbl>([\s\S]*?)<\/w:tbl>/g, (tblM) => {
            const rowsX = tblM.match(/<w:tr[ >][\s\S]*?<\/w:tr>/g) || [];
            const rows = rowsX.map(tr => (tr.match(/<w:tc>[\s\S]*?<\/w:tc>/g) || []));
            const txt = rows.map(r => r.map(cellText));
            const edits = new Map(); // "ri,ci" → {val, yellow}
            // dikey: tam 2 hücre, sol etiket eşleşir/":" ile biter, sağ boş
            const vert = txt.map((r, ri) => ({ r, ri })).filter(o => o.r.length === 2 && isLabel(o.r[0]) && !o.r[1]);
            const hf = formFieldsFromRows(txt);
            if (vert.length >= 2 && (!hf || vert.length >= hf.fields.length - 1)) {
                vert.forEach(o => { const lab = o.r[0].replace(/[:：]\s*$/, ""); const k = matchField(lab); const v = k && P[k] ? String(P[k]) : ""; edits.set(o.ri + "," + 1, { val: v, yellow: !v }); items.push({ label: lab, key: k, value: v }); });
            } else if (hf && txt[hf.headerRow]) {
                const hr = hf.headerRow - 1, dr = hr + 1, ctx = hf.title || "";
                txt[hr].forEach((h, ci) => {
                    if (!isLabel(h) || /^(s\.?\s*no|sn|sira( no)?|no)$/i.test(fold(h))) return;
                    const ex = (txt[dr][ci] || "").trim();
                    let k = matchField(h, ctx, "row");
                    if (k && /\b(alan|dal|sinif|isletme)\b/.test(fold(txt[hr].join(" ") + " " + ctx))) k = null; // v3.6.32
                    if (ex) { items.push({ label: h, key: k, value: ex, existing: true }); return; }
                    const v = k && P[k] ? String(P[k]) : ""; edits.set(dr + "," + ci, { val: v, yellow: !v }); items.push({ label: h, key: k, value: v });
                });
            }
            if (!edits.size) return tblM;
            let ri = -1;
            return tblM.replace(/<w:tr[ >][\s\S]*?<\/w:tr>/g, tr => { ri++; let ci = -1; return tr.replace(/<w:tc>[\s\S]*?<\/w:tc>/g, tc => { ci++; const e = edits.get(ri + "," + ci); return e ? setTc(tc, e.val, e.yellow) : tc; }); });
        });
        if (!items.length) return { ok: false, error: "Form tablosu bulunamadı" };
        const files = [];
        for (const k of Object.keys(z)) files.push({ name: k, data: k === "word/document.xml" ? enc.encode(x) : new Uint8Array(await z[k]()) });
        return { ok: true, bytes: zipStore(files), filled: items.filter(i => i.value && !i.existing).length, filledLabels: items.filter(i => i.value && !i.existing).map(i => i.label + " = " + i.value), existing: items.filter(i => i.existing).map(i => i.label), missing: items.filter(i => !i.value).map(i => i.label) };
    }
    G.EBYS_EK = { fillDocx, PROFILE_FIELDS, matchField, planFill, fillXlsx, labelsToXlsx, zipStore, fold, unzipIndex, docxText, xlsxRead, xlsStrings, pdfText, analyze, requestedLines, formFieldsFromRows, kindOf };
})(typeof globalThis !== "undefined" ? globalThis : this);
