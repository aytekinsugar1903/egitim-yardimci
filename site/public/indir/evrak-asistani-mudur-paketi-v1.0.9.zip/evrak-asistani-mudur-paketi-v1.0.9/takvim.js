/* © 2026 Eyüp ŞEKER — Evrak Asistanı. Tüm hakları saklıdır. */
// Evrak Asistanı — 🗓️ Günlü evrak takvimi sayfası (v3.5.1). Takip listesini (chrome.storage.local "ebys_takip_v1") YALNIZCA okur ve gösterir;
// hiçbir yere göndermez, hiçbir şey değiştirmez. İndirmeler (takvim dosyası .html, not defteri .txt) yalnızca düğmeye basınca, Blob ile, bu bilgisayara.
/* global chrome */
(function () {
    "use strict";
    const POLICY_VERSION = "2026-10-19a";
    const CONSENT_KEY = "ebys_consent_v1";
    const TK = (function () {
    // ---- Evrak Asistanı günlü evrak takip çekirdeği (v3.5): iş günü sayacı, takip deposu, bildirim eşikleri, CSV ve .ics üretimi.
    // Tek kaynak: hem content.js'e hem background.js'e (v35src/takip_core.js) aynen gömülür. Ağ erişimi, kişi adı, okula özgü veri İÇERMEZ.
    const STORE_KEY = "ebys_takip_v1";              // { items: [...], dismissed: [evrak no] }
    const SETTINGS_KEY = "ebys_takip_settings_v1";  // { autoAdd, notify: { enabled, thresholds, overdue, dailyTime } }
    const NOTIFIED_KEY = "ebys_takip_notified_v1";  // yalnızca arka plan: { "<id>|<sonTarih>|<eşik>": "YYYY-MM-DD" } (tekrar bildirmeme)
    const MAX_ITEMS = 500;
    const THRESHOLD_CHOICES = [5, 3, 2, 1, 0];      // 0 = son gün
    const DEFAULT_SETTINGS = { autoAdd: true, notify: { enabled: true, thresholds: [3, 1, 0], overdue: true, dailyTime: "08:30" } };
    // sabit tarihli resmî tatiller (content.js'teki geri sayımla AYNI liste; dinî bayramlar her yıl değiştiği için dahil değildir)
    const FIXED_HOLIDAYS = ["01-01", "04-23", "05-01", "05-19", "07-15", "08-30", "10-29"];
    const pad2 = (n) => String(n).padStart(2, "0");
    const isPlainObject = v => v !== null && typeof v === "object" && !Array.isArray(v);
    function utcDate(y, m, d) { const dt = new Date(Date.UTC(y, m - 1, d)); return (dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d) ? dt : null; }
    function fromIso(s) { const m = String(s || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? utcDate(+m[1], +m[2], +m[3]) : null; }
    function isoOf(dt) { return dt.getUTCFullYear() + "-" + pad2(dt.getUTCMonth() + 1) + "-" + pad2(dt.getUTCDate()); }
    function isValidIso(s) { return !!fromIso(s); }
    function fmtTr(iso) { const d = fromIso(iso); return d ? pad2(d.getUTCDate()) + "." + pad2(d.getUTCMonth() + 1) + "." + d.getUTCFullYear() : ""; }
    function parseTrOrIso(s) {
        s = String(s || "").trim();
        if (isValidIso(s)) return s;
        const m = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
        const d = m && utcDate(+m[3], +m[2], +m[1]);
        return d ? isoOf(d) : "";
    }
    // İstanbul saatiyle bugün / saat (Türkiye 2016'dan beri sürekli UTC+3; Intl yoksa +3 kullanılır)
    function istanbulParts(ms) {
        const t = ms == null ? Date.now() : ms;
        try {
            const p = {};
            new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Istanbul", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" })
                .formatToParts(new Date(t)).forEach(x => { p[x.type] = x.value; });
            return { iso: p.year + "-" + p.month + "-" + p.day, hh: +p.hour % 24, mm: +p.minute };
        } catch (e) {
            const n = new Date(t + 3 * 3600000);
            return { iso: isoOf(n), hh: n.getUTCHours(), mm: n.getUTCMinutes() };
        }
    }
    function todayIso(ms) { return istanbulParts(ms).iso; }
    function isBusinessDay(dt) {
        const wd = dt.getUTCDay();
        if (wd === 0 || wd === 6) return false;
        return !FIXED_HOLIDAYS.includes(pad2(dt.getUTCMonth() + 1) + "-" + pad2(dt.getUTCDate()));
    }
    // (a, b] aralığındaki iş günü sayısı (a < b)
    function businessDaysBetween(aIso, bIso) {
        const a = fromIso(aIso), b = fromIso(bIso);
        if (!a || !b || b <= a) return 0;
        let n = 0;
        for (let t = a.getTime() + 86400000; t <= b.getTime(); t += 86400000) if (isBusinessDay(new Date(t))) n++;
        return n;
    }
    function calDays(aIso, bIso) { const a = fromIso(aIso), b = fromIso(bIso); return a && b ? Math.round((b.getTime() - a.getTime()) / 86400000) : null; }
    // Kalan süre: remaining = kalan iş günü (bugünden sonra, son tarih dahil); 0 = bugün son gün (ya da son tarih hafta sonu/tatil ve bugün son iş günü); < 0 = süresi geçti
    function remainingOf(deadlineIso, today) {
        const cal = calDays(today, deadlineIso);
        if (cal === null) return null;
        if (cal < 0) return { remaining: -Math.max(1, businessDaysBetween(deadlineIso, today)), cal: cal, overdueDays: -cal, overdue: true };
        if (cal === 0) return { remaining: 0, cal: 0, overdueDays: 0, overdue: false };
        return { remaining: businessDaysBetween(today, deadlineIso), cal: cal, overdueDays: 0, overdue: false };
    }
    // Renkler content.js'teki geri sayımla aynı: kırmızı ≤ 2, turuncu ≤ 5, yeşil; süresi geçen kırmızı
    function statusOf(deadlineIso, today) {
        const r = remainingOf(deadlineIso, today);
        if (!r) return { remaining: 9999, level: "green", color: "#86EFAC", label: "Tarih yok", plain: "tarih yok", overdue: false, cal: null };
        const level = r.overdue || r.remaining <= 2 ? "red" : r.remaining <= 5 ? "orange" : "green";
        const color = level === "red" ? "#F87171" : level === "orange" ? "#FB923C" : "#86EFAC";
        let plain, label;
        if (r.overdue) { plain = "süresi geçti (" + r.overdueDays + " gün)"; label = "⚠️ Süresi geçti (" + r.overdueDays + " gün)"; }
        else if (r.cal === 0) { plain = "bugün son gün"; label = "⏰ Bugün son gün"; }
        else if (r.remaining === 0) { plain = "bugün son iş günü"; label = "⏰ Bugün son iş günü"; }
        else { plain = r.remaining + " iş günü kaldı"; label = "⏳ " + r.remaining + " iş günü kaldı"; }
        return Object.assign({}, r, { level: level, color: color, label: label, plain: plain });
    }
    function clean(s, max) { s = String(s == null ? "" : s).replace(/\p{Cc}+/gu, " ").replace(/\s+/g, " ").trim(); return s.length > max ? s.slice(0, max - 1).trimEnd() + "…" : s; }
    function shortSender(s) { return clean(s, 80); }
    function newId() { return "t" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
    function sanitizeItem(x) {
        if (!isPlainObject(x)) return null;
        const sonTarih = parseTrOrIso(x.sonTarih);
        const konu = clean(x.konu, 200);
        if (!sonTarih || !konu) return null;
        const out = {
            id: /^[A-Za-z0-9_-]{1,40}$/.test(String(x.id || "")) ? String(x.id) : newId(),
            evrakNo: clean(x.evrakNo, 80),
            konu: konu,
            gonderen: shortSender(x.gonderen),
            sonTarih: sonTarih,
            ilkGorulme: parseTrOrIso(x.ilkGorulme) || todayIso(),
            durum: x.durum === "tamamlandi" ? "tamamlandi" : "acik",
            not: clean(x.not, 300),
            kaynak: x.kaynak === "elle" ? "elle" : "otomatik"
        };
        const kimde = clean(x.kimde, 120); if (kimde) { out.kimde = kimde; out.kimdeKaynak = x.kimdeKaynak === "elle" ? "elle" : x.kimdeKaynak === "gecmis" ? "gecmis" : "ebys"; }
        if (x.tarihElle) out.tarihElle = true;
        // NEW (v3.5.2): evrak tarihi ve "kısa içerik" (yalnızca yazıda son tarihin geçtiği cümle(ler), en çok 300 karakter; yazının tamamı saklanmaz)
        const tarih = parseTrOrIso(x.tarih); if (tarih) out.tarih = tarih;
        const kisa = clean(x.kisa, 300); if (kisa) out.kisa = kisa;
        if (out.durum === "tamamlandi") out.tamamlanma = parseTrOrIso(x.tamamlanma) || todayIso();
        return out;
    }
    function sanitizeStore(v) {
        const s = isPlainObject(v) ? v : {};
        const seenId = new Set(), seenNo = new Set(), items = [];
        (Array.isArray(s.items) ? s.items : []).forEach(x => {
            const it = sanitizeItem(x);
            if (!it || seenId.has(it.id) || (it.evrakNo && seenNo.has(it.evrakNo))) return;
            seenId.add(it.id); if (it.evrakNo) seenNo.add(it.evrakNo);
            items.push(it);
        });
        // sınır: önce en eski tamamlananlar, sonra en eski son tarihliler atılır
        if (items.length > MAX_ITEMS) {
            const order = items.slice().sort((a, b) => (a.durum === b.durum ? 0 : a.durum === "tamamlandi" ? -1 : 1) || a.sonTarih.localeCompare(b.sonTarih));
            const drop = new Set(order.slice(0, items.length - MAX_ITEMS).map(x => x.id));
            for (let i = items.length - 1; i >= 0; i--) if (drop.has(items[i].id)) items.splice(i, 1);
        }
        const dismissed = Array.from(new Set((Array.isArray(s.dismissed) ? s.dismissed : []).map(x => clean(x, 80)).filter(Boolean))).slice(-MAX_ITEMS);
        return { items: items, dismissed: dismissed };
    }
    function isValidStore(v) { return isPlainObject(v) && Array.isArray(v.items) && v.items.every(x => sanitizeItem(x) !== null) && (v.dismissed === undefined || Array.isArray(v.dismissed)); }
    function sanitizeTime(t) { const m = String(t || "").match(/^(\d{1,2}):(\d{2})$/); return m && +m[1] < 24 && +m[2] < 60 ? pad2(+m[1]) + ":" + m[2] : DEFAULT_SETTINGS.notify.dailyTime; }
    function sanitizeSettings(v) {
        const s = isPlainObject(v) ? v : {}, n = isPlainObject(s.notify) ? s.notify : {};
        const th = Array.isArray(n.thresholds) ? n.thresholds.map(Number).filter(x => THRESHOLD_CHOICES.includes(x)) : DEFAULT_SETTINGS.notify.thresholds;
        return {
            autoAdd: s.autoAdd === undefined ? DEFAULT_SETTINGS.autoAdd : s.autoAdd === true,
            notify: {
                enabled: n.enabled === undefined ? DEFAULT_SETTINGS.notify.enabled : n.enabled === true,
                thresholds: Array.from(new Set(th)).sort((a, b) => b - a),
                overdue: n.overdue === undefined ? DEFAULT_SETTINGS.notify.overdue : n.overdue === true,
                dailyTime: sanitizeTime(n.dailyTime)
            }
        };
    }
    function isValidSettings(v) { return isPlainObject(v) && (v.notify === undefined || isPlainObject(v.notify)); }
    function findByNo(store, evrakNo) { return evrakNo ? store.items.find(x => x.evrakNo === evrakNo) || null : null; }
    // Evrakın son tarihi belirlendiğinde: var olan kaydı günceller ya da (otomatikse) ekler. Dönüş: { store, action: "added"|"updated"|"same"|"dismissed"|"manual", item }
    function upsertFromDoc(store, rec, opts) {
        store = sanitizeStore(store);
        const today = (opts && opts.today) || todayIso();
        const no = clean(rec.evrakNo, 80);
        const ex = findByNo(store, no);
        if (ex) {
            let changed = false;
            const k = clean(rec.konu, 200), g = shortSender(rec.gonderen), iso = parseTrOrIso(rec.sonTarih);
            if (k && k !== ex.konu && ex.kaynak !== "elle") { ex.konu = k; changed = true; }
            if (g && g !== ex.gonderen) { ex.gonderen = g; changed = true; }
            if (iso && iso !== ex.sonTarih && !ex.tarihElle) { ex.sonTarih = iso; changed = true; }
            const kd = clean(rec.kimde, 120);
            if (kd) {
                const fromGecmis = rec.kimdeKaynak === "gecmis";
                const fromEbys = rec.kimdeKaynak === "ebys" || fromGecmis;
                const keepGecmis = ex.kimdeKaynak === "gecmis" && !fromGecmis;
                if (!keepGecmis && (fromEbys || !ex.kimde || ex.kimdeKaynak !== "elle")) {
                    const srcNew = fromGecmis ? "gecmis" : fromEbys ? "ebys" : (rec.kimdeKaynak === "elle" ? "elle" : "ebys");
                    if (kd !== (ex.kimde || "") || (fromEbys && ex.kimdeKaynak !== srcNew)) { ex.kimde = kd; ex.kimdeKaynak = srcNew; changed = true; }
                }
            }
            const kz = clean(rec.kisa, 300), td = parseTrOrIso(rec.tarih); // NEW (v3.5.2)
            if (kz && kz !== ex.kisa) { ex.kisa = kz; changed = true; }
            if (td && td !== ex.tarih) { ex.tarih = td; changed = true; }
            return { store: store, action: changed ? "updated" : "same", item: ex };
        }
        const force = !!(opts && opts.force);
        if (!force && no && store.dismissed.includes(no)) return { store: store, action: "dismissed", item: null };
        if (!force && !(opts && opts.autoAdd)) return { store: store, action: "manual", item: null };
        const it = sanitizeItem({ evrakNo: no, konu: rec.konu, gonderen: rec.gonderen, sonTarih: rec.sonTarih, ilkGorulme: today, durum: "acik", not: rec.not || "", kaynak: force && rec.kaynak === "elle" ? "elle" : "otomatik", tarih: rec.tarih, kisa: rec.kisa, kimde: rec.kimde, kimdeKaynak: rec.kimdeKaynak });
        if (!it) return { store: store, action: "invalid", item: null };
        store.items.push(it);
        if (no) store.dismissed = store.dismissed.filter(x => x !== no);
        return { store: sanitizeStore(store), action: "added", item: it };
    }
    function addManual(store, rec, today) {
        store = sanitizeStore(store);
        const no = clean(rec.evrakNo, 80);
        if (no && findByNo(store, no)) return { store: store, item: null, error: "Bu evrak numarası zaten takipte." };
        const it = sanitizeItem({ evrakNo: no, konu: rec.konu, gonderen: rec.gonderen, sonTarih: rec.sonTarih, ilkGorulme: today || todayIso(), durum: "acik", not: rec.not, kaynak: "elle", tarihElle: true, kimde: rec.kimde, kimdeKaynak: rec.kimde ? "elle" : "" });
        if (!it) return { store: store, item: null, error: "Konu ve geçerli bir son tarih gerekli." };
        store.items.push(it);
        if (no) store.dismissed = store.dismissed.filter(x => x !== no);
        return { store: sanitizeStore(store), item: it, error: "" };
    }
    function updateItem(store, id, patch, today) {
        store = sanitizeStore(store);
        const it = store.items.find(x => x.id === id);
        if (!it) return { store: store, item: null, error: "Kayıt bulunamadı." };
        if (patch.sonTarih !== undefined) { const iso = parseTrOrIso(patch.sonTarih); if (!iso) return { store: store, item: it, error: "Geçerli bir tarih girin." }; if (iso !== it.sonTarih) { it.sonTarih = iso; it.tarihElle = true; } }
        if (patch.konu !== undefined) { const k = clean(patch.konu, 200); if (!k) return { store: store, item: it, error: "Konu boş olamaz." }; it.konu = k; }
        if (patch.not !== undefined) it.not = clean(patch.not, 300);
        if (patch.kimde !== undefined) {
            const kd = clean(patch.kimde, 120);
            if (kd) { it.kimde = kd; it.kimdeKaynak = patch.kimdeKaynak === "ebys" ? "ebys" : patch.kimdeKaynak === "gecmis" ? "gecmis" : "elle"; }
            else { delete it.kimde; delete it.kimdeKaynak; }
        }
        if (patch.durum !== undefined) {
            it.durum = patch.durum === "tamamlandi" ? "tamamlandi" : "acik";
            if (it.durum === "tamamlandi") it.tamamlanma = today || todayIso(); else delete it.tamamlanma;
        }
        return { store: sanitizeStore(store), item: it, error: "" };
    }
    // Silinen / geri alınan evrak numarası "dismissed" listesine girer → aynı evrak yeniden otomatik eklenmez ("📅 Takibe al" ile eklenebilir)
    function removeItem(store, id, remember) {
        store = sanitizeStore(store);
        const it = store.items.find(x => x.id === id);
        store.items = store.items.filter(x => x.id !== id);
        if (it && it.evrakNo && remember !== false && !store.dismissed.includes(it.evrakNo)) store.dismissed.push(it.evrakNo);
        return { store: sanitizeStore(store), item: it || null };
    }
    function openItems(store) { return sanitizeStore(store).items.filter(x => x.durum === "acik"); }
    function sortForList(items, today) {
        return items.map(x => ({ x: x, s: statusOf(x.sonTarih, today) }))
            .sort((a, b) => a.s.remaining - b.s.remaining || a.x.sonTarih.localeCompare(b.x.sonTarih) || a.x.konu.localeCompare(b.x.konu, "tr"))
            .map(o => o.x);
    }
    function counts(store, today) {
        const st = sanitizeStore(store), open = st.items.filter(x => x.durum === "acik");
        const ss = open.map(x => statusOf(x.sonTarih, today));
        return { open: open.length, done: st.items.length - open.length, overdue: ss.filter(s => s.overdue).length, red: ss.filter(s => s.level === "red").length,
            soon: ss.filter(s => !s.overdue && s.remaining <= 3).length, manual: st.items.filter(x => x.kaynak === "elle").length, dismissed: st.dismissed.length };
    }
    function kimdeOf(it) { return clean(it && it.kimde, 120); }
    function kimdeLabel(it) { return kimdeOf(it) || "bilinmiyor"; }
    function filterByKimde(items, filter) {
        if (!filter || filter === "tumu" || filter === "") return (items || []).slice();
        if (filter === "__bilinmiyor__") return (items || []).filter(it => !kimdeOf(it));
        return (items || []).filter(it => kimdeOf(it) === filter);
    }
    function summaryByKimde(store, today) {
        const map = new Map();
        openItems(store).forEach(it => {
            const key = kimdeOf(it) || "__bilinmiyor__";
            if (!map.has(key)) map.set(key, { key: key, name: kimdeLabel(it), open: 0, overdue: 0 });
            const row = map.get(key);
            row.open++;
            if (statusOf(it.sonTarih, today).overdue) row.overdue++;
        });
        return Array.from(map.values()).sort((a, b) => (a.key === "__bilinmiyor__") - (b.key === "__bilinmiyor__") || b.open - a.open || a.name.localeCompare(b.name, "tr"));
    }
    // ---- bildirim mantığı (arka plan): hangi açık evrak hangi eşikte bildirilmeli?
    // Eşik: kalan iş günü ≤ eşik olan EN KÜÇÜK seçili eşik (Chrome o gün kapalıysa sonraki açılışta telafi edilir); her eşik her evrak için bir kez;
    // süresi geçmiş evrak günde bir kez. Anahtar son tarihi de içerir → tarih düzeltilirse yeniden bildirilir.
    function stageOf(item, today, settings) {
        const s = statusOf(item.sonTarih, today);
        if (s.cal === null) return null;
        if (s.overdue) return settings.notify.overdue ? "gecti" : null;
        const th = settings.notify.thresholds.filter(t => s.remaining <= t).sort((a, b) => a - b);
        return th.length ? "t" + th[0] : null;
    }
    function dueNotifications(store, settings, notified, today) {
        settings = sanitizeSettings(settings);
        notified = isPlainObject(notified) ? notified : {};
        if (!settings.notify.enabled) return [];
        const out = [];
        sortForList(openItems(store), today).forEach(it => {
            const stage = stageOf(it, today, settings);
            if (!stage) return;
            const key = it.id + "|" + it.sonTarih + "|" + stage;
            const last = notified[key];
            if (stage === "gecti" ? last === today : !!last) return;
            out.push({ key: key, stage: stage, item: it, status: statusOf(it.sonTarih, today) });
        });
        return out;
    }
    function notificationText(item, today) {
        const s = statusOf(item.sonTarih, today);
        return {
            title: clean(item.konu, 70) || "Günlü evrak",
            message: "Son tarih: " + fmtTr(item.sonTarih) + " — " + s.plain,
            contextMessage: item.evrakNo ? "Evrak No: " + clean(item.evrakNo, 60) : "Evrak Asistanı — Günlü Takip"
        };
    }
    function pruneNotified(notified, store, today) {
        const ids = new Set(sanitizeStore(store).items.map(x => x.id)), out = {};
        Object.keys(isPlainObject(notified) ? notified : {}).forEach(k => {
            const d = notified[k], cd = calDays(d, today);
            if (ids.has(k.split("|")[0]) && cd !== null && cd <= 90) out[k] = d;
        });
        return out;
    }
    // Günlük saat: bugün HH:MM (İstanbul) geçmediyse bugün, geçtiyse yarın → epoch ms
    function nextDailyMs(dailyTime, nowMs) {
        const t = sanitizeTime(dailyTime).split(":").map(Number);
        const p = istanbulParts(nowMs);
        const offsetMs = (Date.UTC(+p.iso.slice(0, 4), +p.iso.slice(5, 7) - 1, +p.iso.slice(8, 10), p.hh, p.mm) - Math.floor(nowMs / 60000) * 60000);
        let target = Date.UTC(+p.iso.slice(0, 4), +p.iso.slice(5, 7) - 1, +p.iso.slice(8, 10), t[0], t[1]) - offsetMs;
        if (target <= nowMs) target += 86400000;
        return target;
    }
    function isBeforeDailyTime(dailyTime, nowMs) {
        const t = sanitizeTime(dailyTime).split(":").map(Number), p = istanbulParts(nowMs);
        return p.hh * 60 + p.mm < t[0] * 60 + t[1];
    }
    // ---- dışa aktarma: Excel uyumlu CSV (UTF-8 BOM, ; ayraç, CRLF) — formül enjeksiyonuna karşı = + - @ ile başlayan hücreler ' ile başlatılır
    const CSV_COLUMNS = ["Evrak No", "Konu", "Gönderen", "Kimde", "Son Tarih", "Kalan İş Günü", "Durum", "Not"];
    function csvCell(v) {
        let s = String(v == null ? "" : v);
        if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+$/.test(s)) s = "'" + s;
        return /[";\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }
    function durumText(it, s) { return it.durum === "tamamlandi" ? "Tamamlandı" : s.overdue ? "Süresi geçti" : s.remaining === 0 ? "Son gün" : "Açık"; }
    function buildCsv(store, today) {
        const st = sanitizeStore(store);
        const open = sortForList(st.items.filter(x => x.durum === "acik"), today);
        const done = st.items.filter(x => x.durum === "tamamlandi").sort((a, b) => a.sonTarih.localeCompare(b.sonTarih));
        const rows = [CSV_COLUMNS];
        open.concat(done).forEach(it => {
            const s = statusOf(it.sonTarih, today);
            rows.push([it.evrakNo, it.konu, it.gonderen, it.kimde || "bilinmiyor", fmtTr(it.sonTarih), it.durum === "tamamlandi" ? "" : String(s.remaining), durumText(it, s), it.not]);
        });
        return "\uFEFF" + rows.map(r => r.map(csvCell).join(";")).join("\r\n") + "\r\n";
    }
    // ---- dışa aktarma: iCalendar (.ics, RFC 5545) — açık her evrak için son tarihte tüm gün etkinliği + 3 gün ve 1 gün önce hatırlatma (günlük saatte)
    function fnv1a(s) { let h = 0x811c9dc5; for (const ch of String(s)) { h ^= ch.codePointAt(0); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(16).padStart(8, "0"); }
    function icsUid(it) { return "evrak-" + (it.evrakNo ? fnv1a("no:" + it.evrakNo) + fnv1a("no2:" + it.evrakNo) : fnv1a("id:" + it.id) + fnv1a("id2:" + it.id)) + "@evrak-asistani"; }
    function icsEsc(s) { return String(s == null ? "" : s).replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n"); }
    function icsFold(line) {
        // 75 sekizlik sınırı (UTF-8), çok baytlı karakter bölünmez
        const enc = (c) => { const n = c.codePointAt(0); return n < 0x80 ? 1 : n < 0x800 ? 2 : n < 0x10000 ? 3 : 4; };
        const out = []; let cur = "", len = 0, limit = 75;
        for (const ch of line) {
            const b = enc(ch);
            if (len + b > limit) { out.push(cur); cur = " "; len = 1; limit = 75; }
            cur += ch; len += b;
        }
        out.push(cur);
        return out.join("\r\n");
    }
    function icsDuration(minutesBefore) {
        const d = Math.floor(minutesBefore / 1440), h = Math.floor((minutesBefore % 1440) / 60), m = minutesBefore % 60;
        return "-P" + (d ? d + "D" : "") + (h || m ? "T" + (h ? h + "H" : "") + (m ? m + "M" : "") : (d ? "" : "T0M"));
    }
    function utcStamp(ms) { const d = new Date(ms); return d.getUTCFullYear() + pad2(d.getUTCMonth() + 1) + pad2(d.getUTCDate()) + "T" + pad2(d.getUTCHours()) + pad2(d.getUTCMinutes()) + pad2(d.getUTCSeconds()) + "Z"; }
    function buildIcs(store, today, nowMs, dailyTime) {
        const t = sanitizeTime(dailyTime).split(":").map(Number), atMin = t[0] * 60 + t[1];
        const L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Evrak Asistani//Gunlu Evrak Takibi 3.5.0//TR", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
            "X-WR-CALNAME:Evrak Takip", "X-WR-TIMEZONE:Europe/Istanbul",
            "BEGIN:VTIMEZONE", "TZID:Europe/Istanbul", "BEGIN:STANDARD", "DTSTART:19700101T000000", "TZOFFSETFROM:+0300", "TZOFFSETTO:+0300", "TZNAME:+03", "END:STANDARD", "END:VTIMEZONE"];
        const stamp = utcStamp(nowMs == null ? Date.now() : nowMs);
        sortForList(openItems(store), today).forEach(it => {
            const d = fromIso(it.sonTarih), next = new Date(d.getTime() + 86400000);
            const konu = clean(it.konu, 200);
            const desc = [it.evrakNo ? "Evrak No: " + it.evrakNo : "", it.gonderen ? "Gönderen: " + it.gonderen : "", it.kimde ? "Kimde: " + it.kimde : "Kimde: bilinmiyor", "Son tarih: " + fmtTr(it.sonTarih), it.not ? "Not: " + it.not : "", "Evrak Asistanı — Günlü Evrak Takibi"].filter(Boolean).join("\n");
            L.push("BEGIN:VEVENT", "UID:" + icsUid(it), "DTSTAMP:" + stamp,
                "DTSTART;VALUE=DATE:" + isoOf(d).replace(/-/g, ""), "DTEND;VALUE=DATE:" + isoOf(next).replace(/-/g, ""),
                "SUMMARY:" + icsEsc("Son gün: " + konu), "DESCRIPTION:" + icsEsc(desc), "STATUS:CONFIRMED", "TRANSP:TRANSPARENT");
            [[3, "3 gün kaldı"], [1, "1 gün kaldı"]].forEach(([days, txt]) => {
                L.push("BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:" + icsEsc(konu + " — " + txt + " (son tarih " + fmtTr(it.sonTarih) + ")"), "TRIGGER:" + icsDuration(days * 1440 - atMin), "END:VALARM");
            });
            L.push("END:VEVENT");
        });
        L.push("END:VCALENDAR");
        return L.map(icsFold).join("\r\n") + "\r\n";
    }
    function fileName(ext, today) { return "evrak-takip-" + (today || todayIso()) + "." + ext; }
    return { STORE_KEY, SETTINGS_KEY, NOTIFIED_KEY, MAX_ITEMS, THRESHOLD_CHOICES, DEFAULT_SETTINGS, FIXED_HOLIDAYS, fromIso, isoOf, isValidIso, fmtTr, parseTrOrIso, istanbulParts, todayIso,
        isBusinessDay, businessDaysBetween, calDays, remainingOf, statusOf, clean, shortSender, newId, sanitizeItem, sanitizeStore, isValidStore, sanitizeTime, sanitizeSettings, isValidSettings,
        findByNo, upsertFromDoc, addManual, updateItem, removeItem, openItems, sortForList, counts, kimdeOf, kimdeLabel, filterByKimde, summaryByKimde, stageOf, dueNotifications, notificationText, pruneNotified, nextDailyMs, isBeforeDailyTime,
        CSV_COLUMNS, csvCell, buildCsv, fnv1a, icsUid, icsEsc, icsFold, icsDuration, buildIcs, fileName };

    })();
    const TV = (function (TK) {
    // ---- Evrak Asistanı takip TAKVİMİ çekirdeği (v3.5.1): aylık takvim + ay listesi (HTML), tek dosyalık çevrimdışı takvim, not defteri (.txt).
    // Tek kaynak: content.js (indirilen dosyalar) ve takvim.js (eklentinin takvim sayfası) içine AYNEN gömülür. Girdi: TK (takip çekirdeği).
    // Ağ erişimi, uzak kaynak, kişi adı, okula özgü veri YOKTUR; tüm metinler HTML kaçışlıdır.
    const MONTHS = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
    const DAYS = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"];
    const pad2 = (n) => String(n).padStart(2, "0");
    const esc = (s) => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    function ymOf(iso) { return String(iso || "").slice(0, 7); }
    function ymParts(ym) { const m = String(ym || "").match(/^(\d{4})-(\d{2})$/); return m && +m[2] >= 1 && +m[2] <= 12 ? { y: +m[1], m: +m[2] } : null; }
    function addMonths(ym, n) { const p = ymParts(ym); if (!p) return ""; const t = p.y * 12 + (p.m - 1) + n; return Math.floor(t / 12) + "-" + pad2((t % 12) + 1); }
    function monthTitle(ym) { const p = ymParts(ym); return p ? MONTHS[p.m - 1] + " " + p.y : ""; }
    // Pazartesi ile başlayan haftalar: [[{ iso, day, inMonth }, ×7], ...]
    function monthGrid(ym) {
        const p = ymParts(ym); if (!p) return [];
        const first = new Date(Date.UTC(p.y, p.m - 1, 1)), lead = (first.getUTCDay() + 6) % 7;
        const days = new Date(Date.UTC(p.y, p.m, 0)).getUTCDate(), weeks = [], nw = Math.ceil((lead + days) / 7);
        let t = first.getTime() - lead * 86400000;
        for (let k = 0; k < nw; k++) {
            const w = [];
            for (let i = 0; i < 7; i++, t += 86400000) { const d = new Date(t); w.push({ iso: TK.isoOf(d), day: d.getUTCDate(), inMonth: d.getUTCMonth() === p.m - 1 }); }
            weeks.push(w);
        }
        return weeks;
    }
    // kayıt + durum: level red/orange/green; tamamlanan "done" (gri)
    function decorate(it, today) {
        const s = TK.statusOf(it.sonTarih, today), done = it.durum === "tamamlandi";
        const short = done ? "Tamamlandı" : s.overdue ? s.overdueDays + " gün geçti" : s.cal === 0 ? "Bugün son gün" : s.remaining === 0 ? "Son iş günü" : s.remaining + " iş günü";
        return { it: it, s: s, done: done, level: done ? "done" : s.level, short: short, plain: done ? "tamamlandı" : s.plain };
    }
    function itemsOfMonth(store, ym, today) {
        const st = TK.sanitizeStore(store);
        return st.items.filter(x => ymOf(x.sonTarih) === ym).map(x => decorate(x, today))
            .sort((a, b) => a.it.sonTarih.localeCompare(b.it.sonTarih) || (a.done - b.done) || a.s.remaining - b.s.remaining || a.it.konu.localeCompare(b.it.konu, "tr"));
    }
    const LEVEL_TEXT = { red: "Kırmızı (≤ 2 iş günü / süresi geçti)", orange: "Turuncu (3–5 iş günü)", green: "Yeşil (6+ iş günü)", done: "Gri (tamamlandı)" };
    function shortKonu(s, n) { s = TK.clean(s, 200); return s.length > n ? s.slice(0, n - 1).trimEnd() + "…" : s; }
    // aylık takvim + altında ayın listesi (HTML parçası)
    function monthHtml(store, ym, today) {
        const items = itemsOfMonth(store, ym, today), byDay = {};
        items.forEach(x => { (byDay[x.it.sonTarih] = byDay[x.it.sonTarih] || []).push(x); });
        let h = '<section class="tv-month" data-ym="' + esc(ym) + '"><h2 class="tv-title">' + esc(monthTitle(ym)) + '</h2>'
            + '<table class="tv-grid" role="grid" aria-label="' + esc(monthTitle(ym)) + ' takvimi"><thead><tr>' + DAYS.map((d, i) => '<th scope="col" class="' + (i >= 5 ? "tv-we" : "") + '"><span class="tv-dl">' + d + '</span><span class="tv-ds">' + d.slice(0, 3) + '</span></th>').join("") + '</tr></thead><tbody>';
        monthGrid(ym).forEach(w => {
            h += "<tr>";
            w.forEach((c, i) => {
                const evs = c.inMonth ? (byDay[c.iso] || []) : [];
                const cls = ["tv-day", c.inMonth ? "" : "tv-out", c.iso === today ? "tv-today" : "", i >= 5 ? "tv-we" : "", evs.length ? "tv-has" : ""].filter(Boolean).join(" ");
                h += '<td class="' + cls + '" data-iso="' + c.iso + '"><div class="tv-num">' + c.day + (c.iso === today ? ' <span class="tv-todaylbl">Bugün</span>' : "") + "</div>";
                evs.forEach(x => {
                    h += '<div class="tv-ev tv-' + x.level + '" title="' + esc(x.it.konu + (x.it.evrakNo ? " — " + x.it.evrakNo : "") + " — " + x.plain) + '">'
                        + '<span class="tv-k">' + esc(shortKonu(x.it.konu, 40)) + '</span>'
                        + (x.it.evrakNo ? '<span class="tv-no">' + esc(x.it.evrakNo) + '</span>' : '<span class="tv-no">✍️ elle eklendi</span>')
                        + '<span class="tv-left">' + esc(x.short) + "</span></div>";
                });
                h += "</td>";
            });
            h += "</tr>";
        });
        h += '</tbody></table><h3 class="tv-lh">' + esc(monthTitle(ym)) + " — evraklar (" + items.length + ")</h3>";
        if (!items.length) h += '<p class="tv-empty">Bu ay son tarihi olan takipli evrak yok.</p>';
        else {
            h += '<table class="tv-list"><thead><tr><th>Son tarih</th><th>Kalan</th><th>Evrak No</th><th>Konu</th><th>Gönderen</th><th>Kimde</th><th>Not</th></tr></thead><tbody>';
            items.forEach(x => {
                h += '<tr class="tv-row tv-' + x.level + '"><td class="tv-nowrap">' + esc(TK.fmtTr(x.it.sonTarih)) + '</td><td class="tv-nowrap"><span class="tv-badge tv-' + x.level + '">' + esc(x.short) + '</span></td><td class="tv-mono">' + esc(x.it.evrakNo || "—") + "</td><td>" + esc(x.it.konu) + "</td><td>" + esc(x.it.gonderen || "") + "</td><td>" + esc(x.it.kimde || "bilinmiyor") + "</td><td>" + esc(x.it.not || "") + "</td></tr>";
            });
            h += "</tbody></table>";
        }
        return h + '<p class="tv-legend">' + ["red", "orange", "green", "done"].map(l => '<span class="tv-badge tv-' + l + '">' + LEVEL_TEXT[l] + "</span>").join(" ") + " · Kalan süre iş günüyle (hafta sonu ve sabit tarihli resmî tatiller hariç; dinî bayramlar dahil edilmez).</p></section>";
    }
    // açık + koyu tema, yazdırma (A4 yatay, her zaman açık renk)
    const CSS = [
        ":root{--bg:#F8FAFC;--fg:#0F172A;--mut:#475569;--card:#FFFFFF;--line:#CBD5E1;--out:#EEF2F7;--we:#F1F5F9;--today:#2563EB;",
        "--red:#B91C1C;--redbg:#FEE2E2;--orange:#9A3412;--orangebg:#FFEDD5;--green:#166534;--greenbg:#DCFCE7;--done:#475569;--donebg:#E2E8F0;}",
        "@media (prefers-color-scheme: dark){:root{--bg:#0F172A;--fg:#F1F5F9;--mut:#CBD5E1;--card:#1E293B;--line:#475569;--out:#162032;--we:#1A2436;--today:#60A5FA;",
        "--red:#FCA5A5;--redbg:#450A0A;--orange:#FDBA74;--orangebg:#431407;--green:#86EFAC;--greenbg:#052E16;--done:#CBD5E1;--donebg:#334155;}}",
        "*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:14px 'Segoe UI',Tahoma,Arial,sans-serif;line-height:1.35}",
        ".tv-wrap{max-width:1400px;margin:0 auto;padding:14px 16px}.tv-head{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:8px}",
        ".tv-head h1{font-size:20px;margin:0 12px 0 0}.tv-btn{background:var(--card);color:var(--fg);border:1px solid var(--line);border-radius:8px;padding:7px 12px;font:inherit;font-weight:600;cursor:pointer}",
        ".tv-btn:hover,.tv-btn:focus-visible{border-color:var(--today);outline:2px solid transparent}.tv-btn.tv-primary{background:var(--today);color:#fff;border-color:var(--today)}",
        ".tv-info{color:var(--mut);font-size:12.5px;margin:4px 0 10px}.tv-warn{background:var(--orangebg);color:var(--orange);border:1px solid var(--orange);padding:8px 10px;border-radius:8px}",
        ".tv-title{font-size:22px;margin:6px 0 8px}.tv-grid{width:100%;border-collapse:collapse;table-layout:fixed;background:var(--card)}",
        ".tv-grid th{padding:6px;border:1px solid var(--line);font-size:13px;text-align:left}.tv-grid th.tv-we{color:var(--mut)}.tv-ds{display:none}",
        ".tv-grid td{vertical-align:top;border:1px solid var(--line);height:104px;padding:4px;overflow:hidden}.tv-grid td.tv-we{background:var(--we)}.tv-grid td.tv-out{background:var(--out);color:var(--mut)}",
        ".tv-grid td.tv-today{outline:3px solid var(--today);outline-offset:-3px}.tv-num{font-weight:700;font-size:13px;margin-bottom:3px}.tv-todaylbl{font-size:11px;font-weight:700;color:var(--today)}",
        ".tv-ev{border-left:5px solid var(--done);background:var(--donebg);color:var(--fg);border-radius:4px;padding:2px 4px;margin:0 0 3px;font-size:11.5px;display:flex;flex-direction:column}",
        ".tv-ev .tv-k{font-weight:600}.tv-ev .tv-no{font-size:10.5px;color:var(--mut);word-break:break-all}.tv-ev .tv-left{font-size:10.5px;font-weight:700}",
        ".tv-ev.tv-red{border-color:var(--red);background:var(--redbg)}.tv-ev.tv-red .tv-left{color:var(--red)}.tv-ev.tv-orange{border-color:var(--orange);background:var(--orangebg)}.tv-ev.tv-orange .tv-left{color:var(--orange)}",
        ".tv-ev.tv-green{border-color:var(--green);background:var(--greenbg)}.tv-ev.tv-green .tv-left{color:var(--green)}.tv-ev.tv-done{opacity:.9}.tv-ev.tv-done .tv-k{text-decoration:line-through}",
        ".tv-lh{font-size:16px;margin:14px 0 6px}.tv-list{width:100%;border-collapse:collapse;background:var(--card);font-size:13px}.tv-list th,.tv-list td{border:1px solid var(--line);padding:5px 7px;text-align:left;vertical-align:top}",
        ".tv-list th{background:var(--we)}.tv-nowrap{white-space:nowrap}.tv-mono{font-family:Consolas,'Courier New',monospace;font-size:12px;word-break:break-all}.tv-row.tv-done td{color:var(--mut)}",
        ".tv-badge{display:inline-block;border:1px solid currentColor;border-radius:6px;padding:1px 6px;font-size:11.5px;font-weight:700;margin:2px 2px 2px 0}",
        ".tv-badge.tv-red{color:var(--red);background:var(--redbg)}.tv-badge.tv-orange{color:var(--orange);background:var(--orangebg)}.tv-badge.tv-green{color:var(--green);background:var(--greenbg)}.tv-badge.tv-done{color:var(--done);background:var(--donebg)}",
        ".tv-legend{color:var(--mut);font-size:12px;margin:8px 0 18px}.tv-empty{color:var(--mut)}.tv-month{margin-bottom:18px}",
        "@media (max-width:800px){.tv-dl{display:none}.tv-ds{display:inline}.tv-grid td{height:80px}}",
        ".js .tv-month{display:none}.js .tv-month.tv-active{display:block}",
        "@media print{@page{size:A4 landscape;margin:9mm}:root{--bg:#fff;--fg:#000;--mut:#333;--card:#fff;--line:#888;--out:#F3F4F6;--we:#F7F7F7;--today:#1D4ED8;",
        "--red:#991B1B;--redbg:#FEE2E2;--orange:#9A3412;--orangebg:#FFEDD5;--green:#166534;--greenbg:#DCFCE7;--done:#374151;--donebg:#E5E7EB}",
        "body{font-size:11px;-webkit-print-color-adjust:exact;print-color-adjust:exact}.tv-noprint{display:none!important}.tv-wrap{max-width:none;padding:0}",
        ".tv-grid td{height:auto;min-height:20mm}.tv-ev{font-size:9px}.tv-ev .tv-no,.tv-ev .tv-left{font-size:8.5px}.tv-lh{page-break-before:always;break-before:page;margin-top:0}.tv-list{font-size:10px}.tv-list tr{page-break-inside:avoid}",
        ".tv-title{font-size:16px;margin:0 0 4px}.js .tv-month.tv-active{display:block}}"
    ].join("\n");
    // takvimde gösterilecek aylar: açık kayıtların en erkeninden (en çok 12 ay önce) en geçine kadar; bu ay her zaman dahil; en çok 24 ay
    function monthRange(store, today) {
        const st = TK.sanitizeStore(store), cur = ymOf(today);
        const yms = st.items.map(x => ymOf(x.sonTarih)).filter(Boolean).sort();
        let a = cur, b = cur;
        if (yms.length) { if (yms[0] < a) a = yms[0]; if (yms[yms.length - 1] > b) b = yms[yms.length - 1]; }
        if (a < addMonths(cur, -12)) a = addMonths(cur, -12);
        const out = [];
        for (let x = a; x <= b && out.length < 24; x = addMonths(x, 1)) out.push(x);
        return out;
    }
    function stampTr(ms) { const p = TK.istanbulParts(ms); return TK.fmtTr(p.iso) + " " + pad2(p.hh) + ":" + pad2(p.mm); }
    // TEK DOSYALIK takvim: çift tıklayınca internetsiz açılır (gömülü stil + küçük gezinme betiği; dış kaynak yok)
    function standaloneHtml(store, today, nowMs) {
        const yms = monthRange(store, today), cur = ymOf(today), c = TK.counts(store, today);
        const nav = '<div class="tv-head tv-noprint"><button class="tv-btn" id="tv-prev" type="button">◀ Önceki ay</button><button class="tv-btn" id="tv-today" type="button">Bu ay</button><button class="tv-btn" id="tv-next" type="button">Sonraki ay ▶</button>'
            + '<button class="tv-btn tv-primary" id="tv-print" type="button">🖨️ Yazdır / PDF olarak kaydet</button></div>';
        const script = "(function(){var d=document;d.documentElement.className='js';var s=[].slice.call(d.querySelectorAll('.tv-month'));var i=0;s.forEach(function(e,k){if(e.getAttribute('data-ym')===" + JSON.stringify(cur) + ")i=k;});"
            + "function show(){s.forEach(function(e,k){e.className='tv-month'+(k===i?' tv-active':'');});var p=d.getElementById('tv-prev'),n=d.getElementById('tv-next');if(p)p.disabled=i<=0;if(n)n.disabled=i>=s.length-1;}"
            + "d.getElementById('tv-prev').onclick=function(){if(i>0){i--;show();}};d.getElementById('tv-next').onclick=function(){if(i<s.length-1){i++;show();}};"
            + "d.getElementById('tv-today').onclick=function(){s.forEach(function(e,k){if(e.getAttribute('data-ym')===" + JSON.stringify(cur) + ")i=k;});show();};d.getElementById('tv-print').onclick=function(){window.print();};show();})();";
        return '<!DOCTYPE html>\n<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Evrak Takip Takvimi — ' + esc(monthTitle(cur)) + '</title>'
            + '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; script-src \'unsafe-inline\'"><style>' + CSS + '</style></head><body><div class="tv-wrap">'
            + '<div class="tv-head"><h1>🗓️ Evrak Takip Takvimi</h1></div>'
            + '<p class="tv-info">Oluşturma: ' + esc(stampTr(nowMs)) + ' (İstanbul saati) · Açık: ' + c.open + ' · Süresi geçen: ' + c.overdue + ' · Tamamlanan: ' + c.done
            + ' · Bu dosya Evrak Asistanı tarafından <b>bu bilgisayarda</b> oluşturuldu; internet gerektirmez ve kendiliğinden güncellenmez (güncel hâli için eklentiden yeniden indirin).</p>'
            + nav + yms.map(ym => monthHtml(store, ym, today)).join("\n") + '</div><script>' + script + '</script></body></html>\n';
    }
    // NOT DEFTERİ listesi: sıralı (süresi geçen → en yakın), sonra tamamlananlar; Windows Not Defteri için UTF-8 BOM + CRLF
    function notepadText(store, today, nowMs) {
        const st = TK.sanitizeStore(store);
        const open = TK.sortForList(st.items.filter(x => x.durum === "acik"), today).map(x => decorate(x, today));
        const done = st.items.filter(x => x.durum === "tamamlandi").sort((a, b) => a.sonTarih.localeCompare(b.sonTarih)).map(x => decorate(x, today));
        const line = (x) => TK.fmtTr(x.it.sonTarih) + " — " + (x.done ? "tamamlandı" : x.s.overdue ? "SÜRESİ GEÇTİ (" + x.s.overdueDays + " gün)" : x.s.cal === 0 ? "BUGÜN SON GÜN" : x.s.remaining === 0 ? "bugün son iş günü" : x.s.remaining + " iş günü kaldı")
            + " — " + (x.it.evrakNo || "(evrak no yok)") + " — " + TK.clean(x.it.konu, 200) + (x.it.not ? "  [Not: " + TK.clean(x.it.not, 300) + "]" : "");
        const L = ["EVRAK TAKİP LİSTESİ (günlü evraklar)", "Oluşturma: " + stampTr(nowMs) + " (İstanbul saati) — Evrak Asistanı, bu bilgisayarda", "Biçim: son tarih — kalan süre — evrak no — konu", "Kalan süre iş günüyle (hafta sonu ve sabit tarihli resmî tatiller hariç).", ""];
        L.push("AÇIK EVRAKLAR (" + open.length + ")", "------------------------------");
        if (!open.length) L.push("(açık günlü evrak yok)");
        open.forEach(x => L.push(line(x)));
        if (done.length) { L.push("", "TAMAMLANANLAR (" + done.length + ")", "------------------------------"); done.forEach(x => L.push(line(x))); }
        return "\uFEFF" + L.join("\r\n") + "\r\n";
    }
    function htmlFileName(today) { return "evrak-takip-takvimi-" + ymOf(today) + ".html"; }
    return { MONTHS, DAYS, esc, ymOf, ymParts, addMonths, monthTitle, monthGrid, decorate, itemsOfMonth, monthHtml, CSS, monthRange, standaloneHtml, notepadText, htmlFileName, stampTr };

    })(TK);
    const get = (keys) => new Promise(res => { try { const p = chrome.storage.local.get(keys, (o) => res(o || {})); if (p && p.then) p.then(o => res(o || {}), () => res({})); } catch (e) { res({}); } });
    const root = document.getElementById("tv-root");
    const st0 = document.createElement("style"); st0.textContent = TV.CSS; document.head.appendChild(st0);
    const q = new URLSearchParams(location.search);
    let ym = TV.ymParts(q.get("ym")) ? q.get("ym") : TV.ymOf(TK.todayIso()), lastDay = TK.todayIso(), data = { store: null, ok: false };
    function download(name, text, mime) {
        const url = URL.createObjectURL(new Blob([text], { type: mime }));
        const a = document.createElement("a"); a.href = url; a.download = name; a.style.display = "none";
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e) { /* yok */ } }, 60000);
    }
    function render() {
        const today = TK.todayIso(); lastDay = today;
        const st = TK.sanitizeStore(data.store), c = TK.counts(st, today);
        let h = '<div class="tv-head"><h1>🗓️ Günlü evrak takvimi</h1>'
            + '<span class="tv-noprint"><button class="tv-btn" id="tv-prev" type="button">◀ Önceki ay</button> <button class="tv-btn" id="tv-today" type="button">Bu ay</button> <button class="tv-btn" id="tv-next" type="button">Sonraki ay ▶</button></span>'
            + '<span class="tv-noprint"><button class="tv-btn tv-primary" id="tv-print" type="button">🖨️ Yazdır / PDF olarak kaydet</button> <button class="tv-btn" id="tv-dl-html" type="button">📄 Takvim dosyası (.html)</button> <button class="tv-btn" id="tv-dl-txt" type="button">📝 Not defteri (.txt)</button></span></div>';
        if (!data.ok) {
            root.innerHTML = h + '<p class="tv-warn" id="tv-noconsent">⚠️ Önce EBYS sayfasında Evrak Asistanı gizlilik onayını vermelisiniz. Onay verilmeden takip listesi gösterilmez.</p>';
            root.querySelectorAll(".tv-head button").forEach(b => { b.disabled = true; });
            return;
        }
        h += '<p class="tv-info">Açık: <b>' + c.open + '</b> · Süresi geçen: <b>' + c.overdue + '</b> · Tamamlanan: ' + c.done + ' · Bugün: ' + TV.esc(TK.fmtTr(today))
            + ' · Liste EBYS sekmesinde değiştikçe bu sayfa kendiliğinden güncellenir. Veriler yalnızca bu bilgisayarda; bu sayfa internete bağlanmaz.</p>';
        root.innerHTML = h + TV.monthHtml(st, ym, today);
        const go = (n) => { ym = TV.addMonths(ym, n); render(); };
        document.getElementById("tv-prev").onclick = () => go(-1);
        document.getElementById("tv-next").onclick = () => go(1);
        document.getElementById("tv-today").onclick = () => { ym = TV.ymOf(TK.todayIso()); render(); };
        document.getElementById("tv-print").onclick = () => window.print();
        document.getElementById("tv-dl-html").onclick = () => download(TV.htmlFileName(TK.todayIso()), TV.standaloneHtml(data.store, TK.todayIso(), Date.now()), "text/html;charset=utf-8");
        document.getElementById("tv-dl-txt").onclick = () => download(TK.fileName("txt", TK.todayIso()), TV.notepadText(data.store, TK.todayIso(), Date.now()), "text/plain;charset=utf-8");
        document.title = "Evrak takvimi — " + TV.monthTitle(ym);
    }
    async function load() {
        const o = await get([TK.STORE_KEY, CONSENT_KEY]);
        const c = o[CONSENT_KEY];
        data = { store: o[TK.STORE_KEY] || null, ok: !!(c && c.accepted === true && c.version === POLICY_VERSION) };
        render();
    }
    try { if (chrome.storage && chrome.storage.onChanged) chrome.storage.onChanged.addListener((ch, area) => { if ((!area || area === "local") && (TK.STORE_KEY in ch || CONSENT_KEY in ch)) load(); }); } catch (e) { /* yok */ }
    setInterval(() => { if (TK.todayIso() !== lastDay) render(); }, 60000);
    load();
})();
