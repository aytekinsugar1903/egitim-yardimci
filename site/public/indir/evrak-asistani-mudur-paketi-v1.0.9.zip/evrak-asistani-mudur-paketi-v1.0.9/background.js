/* © 2026 Eyüp ŞEKER — Evrak Asistanı. Tüm hakları saklıdır. */
// Evrak Asistanı v3.5.0 — arka plan hizmet çalışanı (Manifest V3 background.service_worker)
// Görevi YALNIZCA günlü evrak hatırlatmalarıdır: chrome.alarms ile (tarayıcı açılışında, ~60 dakikada bir ve kullanıcının seçtiği günlük saatte)
// chrome.storage.local'daki takip listesine bakar, eşiğe gelen açık evrakları chrome.notifications ile masaüstünde bildirir.
// • Müdür Paketi v1.0.4 (kaynak: Evrak Asistanı 3.6.59 günlü takip çekirdeği). Ağ erişimi YOKTUR; bildirim yalnızca konu, son tarih ve evrak sayısı içerir. Veriler chrome.storage.local'da kalır.
// • Gizlilik onayı (aynı politika sürümü) yoksa, bildirimler kapalıysa ya da açık takip kaydı yoksa hiçbir alarm kurulmaz, bildirim gösterilmez.
// • Bildirime tıklanınca https://ebys.meb.gov.tr/ yeni sekmede açılır (tabs izni gerekmez).
"use strict";
const EBYS_POLICY_VERSION = "2026-10-19a";
const CONSENT_KEY = "ebys_consent_v1";
const EBYS_URL = "https://ebys.meb.gov.tr/";
const ALARM_HOURLY = "ebys-takip-saatlik";
const ALARM_DAILY = "ebys-takip-gunluk";
const NOTIF_PREFIX = "ebys-takip:";
const ICON = "icons/bildirim-128.png";
const MAX_SINGLE = 3; // bir kontrolde en çok 3 ayrı bildirim; fazlası tek özet bildirimde

const TK = (function() {
    // ---- Evrak Asistanı günlü evrak takip çekirdeği (v3.5): iş günü sayacı, takip deposu, bildirim eşikleri, CSV ve .ics üretimi.
    // Tek kaynak: hem content.js'e hem background.js'e (v35src/takip_core.js) aynen gömülür. Ağ erişimi, kişi adı, okula özgü veri İÇERMEZ.
    const STORE_KEY = "ebys_takip_v1";              // { items: [...], dismissed: [evrak no] }
    const SETTINGS_KEY = "ebys_takip_settings_v1";  // { autoAdd, notify: { enabled, thresholds, overdue, dailyTime } }
    const NOTIFIED_KEY = "ebys_takip_notified_v1";  // yalnızca arka plan: { "<id>|<sonTarih>|<eşik>": "YYYY-MM-DD" } (tekrar bildirmeme)
    const MAX_ITEMS = 500;
    const THRESHOLD_CHOICES = [5, 3, 2, 1, 0];      // 0 = son gün
    const DEFAULT_SETTINGS = { autoAdd: true, notify: { enabled: true, thresholds: [3, 1, 0], overdue: true, dailyTime: "08:30" } };
    // sabit tarihli resmî tatiller (content.js'teki geri sayımla AYNI liste; dinî bayramlar her yıl değiştiği için dahil değildir)
    const FIXED_HOLIDAYS = ["01-01", "04-23", "05-01", "05-19", "07-15", "08-30", "10-29"];
    const pad2 = (n) => String(n).padStart(2, "0");
    const isPlainObject = v => v !== null && typeof v === "object" && !Array.isArray(v);
    function utcDate(y, m, d) { const dt = new Date(Date.UTC(y, m - 1, d)); return (dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d) ? dt : null; }
    function fromIso(s) { const m = String(s || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? utcDate(+m[1], +m[2], +m[3]) : null; }
    function isoOf(dt) { return dt.getUTCFullYear() + "-" + pad2(dt.getUTCMonth() + 1) + "-" + pad2(dt.getUTCDate()); }
    function isValidIso(s) { return !!fromIso(s); }
    function fmtTr(iso) { const d = fromIso(iso); return d ? pad2(d.getUTCDate()) + "." + pad2(d.getUTCMonth() + 1) + "." + d.getUTCFullYear() : ""; }
    function parseTrOrIso(s) {
        s = String(s || "").trim();
        if (isValidIso(s)) return s;
        const m = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
        const d = m && utcDate(+m[3], +m[2], +m[1]);
        return d ? isoOf(d) : "";
    }
    // İstanbul saatiyle bugün / saat (Türkiye 2016'dan beri sürekli UTC+3; Intl yoksa +3 kullanılır)
    function istanbulParts(ms) {
        const t = ms == null ? Date.now() : ms;
        try {
            const p = {};
            new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Istanbul", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" })
                .formatToParts(new Date(t)).forEach(x => { p[x.type] = x.value; });
            return { iso: p.year + "-" + p.month + "-" + p.day, hh: +p.hour % 24, mm: +p.minute };
        } catch (e) {
            const n = new Date(t + 3 * 3600000);
            return { iso: isoOf(n), hh: n.getUTCHours(), mm: n.getUTCMinutes() };
        }
    }
    function todayIso(ms) { return istanbulParts(ms).iso; }
    function isBusinessDay(dt) {
        const wd = dt.getUTCDay();
        if (wd === 0 || wd === 6) return false;
        return !FIXED_HOLIDAYS.includes(pad2(dt.getUTCMonth() + 1) + "-" + pad2(dt.getUTCDate()));
    }
    // (a, b] aralığındaki iş günü sayısı (a < b)
    function businessDaysBetween(aIso, bIso) {
        const a = fromIso(aIso), b = fromIso(bIso);
        if (!a || !b || b <= a) return 0;
        let n = 0;
        for (let t = a.getTime() + 86400000; t <= b.getTime(); t += 86400000) if (isBusinessDay(new Date(t))) n++;
        return n;
    }
    function calDays(aIso, bIso) { const a = fromIso(aIso), b = fromIso(bIso); return a && b ? Math.round((b.getTime() - a.getTime()) / 86400000) : null; }
    // Kalan süre: remaining = kalan iş günü (bugünden sonra, son tarih dahil); 0 = bugün son gün (ya da son tarih hafta sonu/tatil ve bugün son iş günü); < 0 = süresi geçti
    function remainingOf(deadlineIso, today) {
        const cal = calDays(today, deadlineIso);
        if (cal === null) return null;
        if (cal < 0) return { remaining: -Math.max(1, businessDaysBetween(deadlineIso, today)), cal: cal, overdueDays: -cal, overdue: true };
        if (cal === 0) return { remaining: 0, cal: 0, overdueDays: 0, overdue: false };
        return { remaining: businessDaysBetween(today, deadlineIso), cal: cal, overdueDays: 0, overdue: false };
    }
    // Renkler content.js'teki geri sayımla aynı: kırmızı ≤ 2, turuncu ≤ 5, yeşil; süresi geçen kırmızı
    function statusOf(deadlineIso, today) {
        const r = remainingOf(deadlineIso, today);
        if (!r) return { remaining: 9999, level: "green", color: "#86EFAC", label: "Tarih yok", plain: "tarih yok", overdue: false, cal: null };
        const level = r.overdue || r.remaining <= 2 ? "red" : r.remaining <= 5 ? "orange" : "green";
        const color = level === "red" ? "#F87171" : level === "orange" ? "#FB923C" : "#86EFAC";
        let plain, label;
        if (r.overdue) { plain = "süresi geçti (" + r.overdueDays + " gün)"; label = "⚠️ Süresi geçti (" + r.overdueDays + " gün)"; }
        else if (r.cal === 0) { plain = "bugün son gün"; label = "⏰ Bugün son gün"; }
        else if (r.remaining === 0) { plain = "bugün son iş günü"; label = "⏰ Bugün son iş günü"; }
        else { plain = r.remaining + " iş günü kaldı"; label = "⏳ " + r.remaining + " iş günü kaldı"; }
        return Object.assign({}, r, { level: level, color: color, label: label, plain: plain });
    }
    function clean(s, max) { s = String(s == null ? "" : s).replace(/\p{Cc}+/gu, " ").replace(/\s+/g, " ").trim(); return s.length > max ? s.slice(0, max - 1).trimEnd() + "…" : s; }
    function shortSender(s) { return clean(s, 80); }
    function newId() { return "t" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
    function sanitizeItem(x) {
        if (!isPlainObject(x)) return null;
        const sonTarih = parseTrOrIso(x.sonTarih);
        const konu = clean(x.konu, 200);
        if (!sonTarih || !konu) return null;
        const out = {
            id: /^[A-Za-z0-9_-]{1,40}$/.test(String(x.id || "")) ? String(x.id) : newId(),
            evrakNo: clean(x.evrakNo, 80),
            konu: konu,
            gonderen: shortSender(x.gonderen),
            sonTarih: sonTarih,
            ilkGorulme: parseTrOrIso(x.ilkGorulme) || todayIso(),
            durum: x.durum === "tamamlandi" ? "tamamlandi" : "acik",
            not: clean(x.not, 300),
            kaynak: x.kaynak === "elle" ? "elle" : "otomatik"
        };
        const kimde = clean(x.kimde, 120); if (kimde) { out.kimde = kimde; out.kimdeKaynak = x.kimdeKaynak === "elle" ? "elle" : x.kimdeKaynak === "gecmis" ? "gecmis" : "ebys"; }
        if (x.tarihElle) out.tarihElle = true;
        // NEW (v3.5.2): evrak tarihi ve "kısa içerik" (yalnızca yazıda son tarihin geçtiği cümle(ler), en çok 300 karakter; yazının tamamı saklanmaz)
        const tarih = parseTrOrIso(x.tarih); if (tarih) out.tarih = tarih;
        const kisa = clean(x.kisa, 300); if (kisa) out.kisa = kisa;
        if (out.durum === "tamamlandi") out.tamamlanma = parseTrOrIso(x.tamamlanma) || todayIso();
        return out;
    }
    function sanitizeStore(v) {
        const s = isPlainObject(v) ? v : {};
        const seenId = new Set(), seenNo = new Set(), items = [];
        (Array.isArray(s.items) ? s.items : []).forEach(x => {
            const it = sanitizeItem(x);
            if (!it || seenId.has(it.id) || (it.evrakNo && seenNo.has(it.evrakNo))) return;
            seenId.add(it.id); if (it.evrakNo) seenNo.add(it.evrakNo);
            items.push(it);
        });
        // sınır: önce en eski tamamlananlar, sonra en eski son tarihliler atılır
        if (items.length > MAX_ITEMS) {
            const order = items.slice().sort((a, b) => (a.durum === b.durum ? 0 : a.durum === "tamamlandi" ? -1 : 1) || a.sonTarih.localeCompare(b.sonTarih));
            const drop = new Set(order.slice(0, items.length - MAX_ITEMS).map(x => x.id));
            for (let i = items.length - 1; i >= 0; i--) if (drop.has(items[i].id)) items.splice(i, 1);
        }
        const dismissed = Array.from(new Set((Array.isArray(s.dismissed) ? s.dismissed : []).map(x => clean(x, 80)).filter(Boolean))).slice(-MAX_ITEMS);
        return { items: items, dismissed: dismissed };
    }
    function isValidStore(v) { return isPlainObject(v) && Array.isArray(v.items) && v.items.every(x => sanitizeItem(x) !== null) && (v.dismissed === undefined || Array.isArray(v.dismissed)); }
    function sanitizeTime(t) { const m = String(t || "").match(/^(\d{1,2}):(\d{2})$/); return m && +m[1] < 24 && +m[2] < 60 ? pad2(+m[1]) + ":" + m[2] : DEFAULT_SETTINGS.notify.dailyTime; }
    function sanitizeSettings(v) {
        const s = isPlainObject(v) ? v : {}, n = isPlainObject(s.notify) ? s.notify : {};
        const th = Array.isArray(n.thresholds) ? n.thresholds.map(Number).filter(x => THRESHOLD_CHOICES.includes(x)) : DEFAULT_SETTINGS.notify.thresholds;
        return {
            autoAdd: s.autoAdd === undefined ? DEFAULT_SETTINGS.autoAdd : s.autoAdd === true,
            notify: {
                enabled: n.enabled === undefined ? DEFAULT_SETTINGS.notify.enabled : n.enabled === true,
                thresholds: Array.from(new Set(th)).sort((a, b) => b - a),
                overdue: n.overdue === undefined ? DEFAULT_SETTINGS.notify.overdue : n.overdue === true,
                dailyTime: sanitizeTime(n.dailyTime)
            }
        };
    }
    function isValidSettings(v) { return isPlainObject(v) && (v.notify === undefined || isPlainObject(v.notify)); }
    function findByNo(store, evrakNo) { return evrakNo ? store.items.find(x => x.evrakNo === evrakNo) || null : null; }
    // Evrakın son tarihi belirlendiğinde: var olan kaydı günceller ya da (otomatikse) ekler. Dönüş: { store, action: "added"|"updated"|"same"|"dismissed"|"manual", item }
    function upsertFromDoc(store, rec, opts) {
        store = sanitizeStore(store);
        const today = (opts && opts.today) || todayIso();
        const no = clean(rec.evrakNo, 80);
        const ex = findByNo(store, no);
        if (ex) {
            let changed = false;
            const k = clean(rec.konu, 200), g = shortSender(rec.gonderen), iso = parseTrOrIso(rec.sonTarih);
            if (k && k !== ex.konu && ex.kaynak !== "elle") { ex.konu = k; changed = true; }
            if (g && g !== ex.gonderen) { ex.gonderen = g; changed = true; }
            if (iso && iso !== ex.sonTarih && !ex.tarihElle) { ex.sonTarih = iso; changed = true; }
            const kd = clean(rec.kimde, 120);
            if (kd) {
                const fromGecmis = rec.kimdeKaynak === "gecmis";
                const fromEbys = rec.kimdeKaynak === "ebys" || fromGecmis;
                const keepGecmis = ex.kimdeKaynak === "gecmis" && !fromGecmis;
                if (!keepGecmis && (fromEbys || !ex.kimde || ex.kimdeKaynak !== "elle")) {
                    const srcNew = fromGecmis ? "gecmis" : fromEbys ? "ebys" : (rec.kimdeKaynak === "elle" ? "elle" : "ebys");
                    if (kd !== (ex.kimde || "") || (fromEbys && ex.kimdeKaynak !== srcNew)) { ex.kimde = kd; ex.kimdeKaynak = srcNew; changed = true; }
                }
            }
            const kz = clean(rec.kisa, 300), td = parseTrOrIso(rec.tarih); // NEW (v3.5.2)
            if (kz && kz !== ex.kisa) { ex.kisa = kz; changed = true; }
            if (td && td !== ex.tarih) { ex.tarih = td; changed = true; }
            return { store: store, action: changed ? "updated" : "same", item: ex };
        }
        const force = !!(opts && opts.force);
        if (!force && no && store.dismissed.includes(no)) return { store: store, action: "dismissed", item: null };
        if (!force && !(opts && opts.autoAdd)) return { store: store, action: "manual", item: null };
        const it = sanitizeItem({ evrakNo: no, konu: rec.konu, gonderen: rec.gonderen, sonTarih: rec.sonTarih, ilkGorulme: today, durum: "acik", not: rec.not || "", kaynak: force && rec.kaynak === "elle" ? "elle" : "otomatik", tarih: rec.tarih, kisa: rec.kisa, kimde: rec.kimde, kimdeKaynak: rec.kimdeKaynak });
        if (!it) return { store: store, action: "invalid", item: null };
        store.items.push(it);
        if (no) store.dismissed = store.dismissed.filter(x => x !== no);
        return { store: sanitizeStore(store), action: "added", item: it };
    }
    function addManual(store, rec, today) {
        store = sanitizeStore(store);
        const no = clean(rec.evrakNo, 80);
        if (no && findByNo(store, no)) return { store: store, item: null, error: "Bu evrak numarası zaten takipte." };
        const it = sanitizeItem({ evrakNo: no, konu: rec.konu, gonderen: rec.gonderen, sonTarih: rec.sonTarih, ilkGorulme: today || todayIso(), durum: "acik", not: rec.not, kaynak: "elle", tarihElle: true, kimde: rec.kimde, kimdeKaynak: rec.kimde ? "elle" : "" });
        if (!it) return { store: store, item: null, error: "Konu ve geçerli bir son tarih gerekli." };
        store.items.push(it);
        if (no) store.dismissed = store.dismissed.filter(x => x !== no);
        return { store: sanitizeStore(store), item: it, error: "" };
    }
    function updateItem(store, id, patch, today) {
        store = sanitizeStore(store);
        const it = store.items.find(x => x.id === id);
        if (!it) return { store: store, item: null, error: "Kayıt bulunamadı." };
        if (patch.sonTarih !== undefined) { const iso = parseTrOrIso(patch.sonTarih); if (!iso) return { store: store, item: it, error: "Geçerli bir tarih girin." }; if (iso !== it.sonTarih) { it.sonTarih = iso; it.tarihElle = true; } }
        if (patch.konu !== undefined) { const k = clean(patch.konu, 200); if (!k) return { store: store, item: it, error: "Konu boş olamaz." }; it.konu = k; }
        if (patch.not !== undefined) it.not = clean(patch.not, 300);
        if (patch.kimde !== undefined) {
            const kd = clean(patch.kimde, 120);
            if (kd) { it.kimde = kd; it.kimdeKaynak = patch.kimdeKaynak === "ebys" ? "ebys" : patch.kimdeKaynak === "gecmis" ? "gecmis" : "elle"; }
            else { delete it.kimde; delete it.kimdeKaynak; }
        }
        if (patch.durum !== undefined) {
            it.durum = patch.durum === "tamamlandi" ? "tamamlandi" : "acik";
            if (it.durum === "tamamlandi") it.tamamlanma = today || todayIso(); else delete it.tamamlanma;
        }
        return { store: sanitizeStore(store), item: it, error: "" };
    }
    // Silinen / geri alınan evrak numarası "dismissed" listesine girer → aynı evrak yeniden otomatik eklenmez ("📅 Takibe al" ile eklenebilir)
    function removeItem(store, id, remember) {
        store = sanitizeStore(store);
        const it = store.items.find(x => x.id === id);
        store.items = store.items.filter(x => x.id !== id);
        if (it && it.evrakNo && remember !== false && !store.dismissed.includes(it.evrakNo)) store.dismissed.push(it.evrakNo);
        return { store: sanitizeStore(store), item: it || null };
    }
    function openItems(store) { return sanitizeStore(store).items.filter(x => x.durum === "acik"); }
    function sortForList(items, today) {
        return items.map(x => ({ x: x, s: statusOf(x.sonTarih, today) }))
            .sort((a, b) => a.s.remaining - b.s.remaining || a.x.sonTarih.localeCompare(b.x.sonTarih) || a.x.konu.localeCompare(b.x.konu, "tr"))
            .map(o => o.x);
    }
    function counts(store, today) {
        const st = sanitizeStore(store), open = st.items.filter(x => x.durum === "acik");
        const ss = open.map(x => statusOf(x.sonTarih, today));
        return { open: open.length, done: st.items.length - open.length, overdue: ss.filter(s => s.overdue).length, red: ss.filter(s => s.level === "red").length,
            soon: ss.filter(s => !s.overdue && s.remaining <= 3).length, manual: st.items.filter(x => x.kaynak === "elle").length, dismissed: st.dismissed.length };
    }
    function kimdeOf(it) { return clean(it && it.kimde, 120); }
    function kimdeLabel(it) { return kimdeOf(it) || "bilinmiyor"; }
    function filterByKimde(items, filter) {
        if (!filter || filter === "tumu" || filter === "") return (items || []).slice();
        if (filter === "__bilinmiyor__") return (items || []).filter(it => !kimdeOf(it));
        return (items || []).filter(it => kimdeOf(it) === filter);
    }
    function summaryByKimde(store, today) {
        const map = new Map();
        openItems(store).forEach(it => {
            const key = kimdeOf(it) || "__bilinmiyor__";
            if (!map.has(key)) map.set(key, { key: key, name: kimdeLabel(it), open: 0, overdue: 0 });
            const row = map.get(key);
            row.open++;
            if (statusOf(it.sonTarih, today).overdue) row.overdue++;
        });
        return Array.from(map.values()).sort((a, b) => (a.key === "__bilinmiyor__") - (b.key === "__bilinmiyor__") || b.open - a.open || a.name.localeCompare(b.name, "tr"));
    }
    // ---- bildirim mantığı (arka plan): hangi açık evrak hangi eşikte bildirilmeli?
    // Eşik: kalan iş günü ≤ eşik olan EN KÜÇÜK seçili eşik (Chrome o gün kapalıysa sonraki açılışta telafi edilir); her eşik her evrak için bir kez;
    // süresi geçmiş evrak günde bir kez. Anahtar son tarihi de içerir → tarih düzeltilirse yeniden bildirilir.
    function stageOf(item, today, settings) {
        const s = statusOf(item.sonTarih, today);
        if (s.cal === null) return null;
        if (s.overdue) return settings.notify.overdue ? "gecti" : null;
        const th = settings.notify.thresholds.filter(t => s.remaining <= t).sort((a, b) => a - b);
        return th.length ? "t" + th[0] : null;
    }
    function dueNotifications(store, settings, notified, today) {
        settings = sanitizeSettings(settings);
        notified = isPlainObject(notified) ? notified : {};
        if (!settings.notify.enabled) return [];
        const out = [];
        sortForList(openItems(store), today).forEach(it => {
            const stage = stageOf(it, today, settings);
            if (!stage) return;
            const key = it.id + "|" + it.sonTarih + "|" + stage;
            const last = notified[key];
            if (stage === "gecti" ? last === today : !!last) return;
            out.push({ key: key, stage: stage, item: it, status: statusOf(it.sonTarih, today) });
        });
        return out;
    }
    function notificationText(item, today) {
        const s = statusOf(item.sonTarih, today);
        return {
            title: clean(item.konu, 70) || "Günlü evrak",
            message: "Son tarih: " + fmtTr(item.sonTarih) + " — " + s.plain,
            contextMessage: item.evrakNo ? "Evrak No: " + clean(item.evrakNo, 60) : "Evrak Asistanı — Günlü Takip"
        };
    }
    function pruneNotified(notified, store, today) {
        const ids = new Set(sanitizeStore(store).items.map(x => x.id)), out = {};
        Object.keys(isPlainObject(notified) ? notified : {}).forEach(k => {
            const d = notified[k], cd = calDays(d, today);
            if (ids.has(k.split("|")[0]) && cd !== null && cd <= 90) out[k] = d;
        });
        return out;
    }
    // Günlük saat: bugün HH:MM (İstanbul) geçmediyse bugün, geçtiyse yarın → epoch ms
    function nextDailyMs(dailyTime, nowMs) {
        const t = sanitizeTime(dailyTime).split(":").map(Number);
        const p = istanbulParts(nowMs);
        const offsetMs = (Date.UTC(+p.iso.slice(0, 4), +p.iso.slice(5, 7) - 1, +p.iso.slice(8, 10), p.hh, p.mm) - Math.floor(nowMs / 60000) * 60000);
        let target = Date.UTC(+p.iso.slice(0, 4), +p.iso.slice(5, 7) - 1, +p.iso.slice(8, 10), t[0], t[1]) - offsetMs;
        if (target <= nowMs) target += 86400000;
        return target;
    }
    function isBeforeDailyTime(dailyTime, nowMs) {
        const t = sanitizeTime(dailyTime).split(":").map(Number), p = istanbulParts(nowMs);
        return p.hh * 60 + p.mm < t[0] * 60 + t[1];
    }
    // ---- dışa aktarma: Excel uyumlu CSV (UTF-8 BOM, ; ayraç, CRLF) — formül enjeksiyonuna karşı = + - @ ile başlayan hücreler ' ile başlatılır
    const CSV_COLUMNS = ["Evrak No", "Konu", "Gönderen", "Kimde", "Son Tarih", "Kalan İş Günü", "Durum", "Not"];
    function csvCell(v) {
        let s = String(v == null ? "" : v);
        if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+$/.test(s)) s = "'" + s;
        return /[";\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }
    function durumText(it, s) { return it.durum === "tamamlandi" ? "Tamamlandı" : s.overdue ? "Süresi geçti" : s.remaining === 0 ? "Son gün" : "Açık"; }
    function buildCsv(store, today) {
        const st = sanitizeStore(store);
        const open = sortForList(st.items.filter(x => x.durum === "acik"), today);
        const done = st.items.filter(x => x.durum === "tamamlandi").sort((a, b) => a.sonTarih.localeCompare(b.sonTarih));
        const rows = [CSV_COLUMNS];
        open.concat(done).forEach(it => {
            const s = statusOf(it.sonTarih, today);
            rows.push([it.evrakNo, it.konu, it.gonderen, it.kimde || "bilinmiyor", fmtTr(it.sonTarih), it.durum === "tamamlandi" ? "" : String(s.remaining), durumText(it, s), it.not]);
        });
        return "\uFEFF" + rows.map(r => r.map(csvCell).join(";")).join("\r\n") + "\r\n";
    }
    // ---- dışa aktarma: iCalendar (.ics, RFC 5545) — açık her evrak için son tarihte tüm gün etkinliği + 3 gün ve 1 gün önce hatırlatma (günlük saatte)
    function fnv1a(s) { let h = 0x811c9dc5; for (const ch of String(s)) { h ^= ch.codePointAt(0); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(16).padStart(8, "0"); }
    function icsUid(it) { return "evrak-" + (it.evrakNo ? fnv1a("no:" + it.evrakNo) + fnv1a("no2:" + it.evrakNo) : fnv1a("id:" + it.id) + fnv1a("id2:" + it.id)) + "@evrak-asistani"; }
    function icsEsc(s) { return String(s == null ? "" : s).replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n"); }
    function icsFold(line) {
        // 75 sekizlik sınırı (UTF-8), çok baytlı karakter bölünmez
        const enc = (c) => { const n = c.codePointAt(0); return n < 0x80 ? 1 : n < 0x800 ? 2 : n < 0x10000 ? 3 : 4; };
        const out = []; let cur = "", len = 0, limit = 75;
        for (const ch of line) {
            const b = enc(ch);
            if (len + b > limit) { out.push(cur); cur = " "; len = 1; limit = 75; }
            cur += ch; len += b;
        }
        out.push(cur);
        return out.join("\r\n");
    }
    function icsDuration(minutesBefore) {
        const d = Math.floor(minutesBefore / 1440), h = Math.floor((minutesBefore % 1440) / 60), m = minutesBefore % 60;
        return "-P" + (d ? d + "D" : "") + (h || m ? "T" + (h ? h + "H" : "") + (m ? m + "M" : "") : (d ? "" : "T0M"));
    }
    function utcStamp(ms) { const d = new Date(ms); return d.getUTCFullYear() + pad2(d.getUTCMonth() + 1) + pad2(d.getUTCDate()) + "T" + pad2(d.getUTCHours()) + pad2(d.getUTCMinutes()) + pad2(d.getUTCSeconds()) + "Z"; }
    function buildIcs(store, today, nowMs, dailyTime) {
        const t = sanitizeTime(dailyTime).split(":").map(Number), atMin = t[0] * 60 + t[1];
        const L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Evrak Asistani//Gunlu Evrak Takibi 3.5.0//TR", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
            "X-WR-CALNAME:Evrak Takip", "X-WR-TIMEZONE:Europe/Istanbul",
            "BEGIN:VTIMEZONE", "TZID:Europe/Istanbul", "BEGIN:STANDARD", "DTSTART:19700101T000000", "TZOFFSETFROM:+0300", "TZOFFSETTO:+0300", "TZNAME:+03", "END:STANDARD", "END:VTIMEZONE"];
        const stamp = utcStamp(nowMs == null ? Date.now() : nowMs);
        sortForList(openItems(store), today).forEach(it => {
            const d = fromIso(it.sonTarih), next = new Date(d.getTime() + 86400000);
            const konu = clean(it.konu, 200);
            const desc = [it.evrakNo ? "Evrak No: " + it.evrakNo : "", it.gonderen ? "Gönderen: " + it.gonderen : "", it.kimde ? "Kimde: " + it.kimde : "Kimde: bilinmiyor", "Son tarih: " + fmtTr(it.sonTarih), it.not ? "Not: " + it.not : "", "Evrak Asistanı — Günlü Evrak Takibi"].filter(Boolean).join("\n");
            L.push("BEGIN:VEVENT", "UID:" + icsUid(it), "DTSTAMP:" + stamp,
                "DTSTART;VALUE=DATE:" + isoOf(d).replace(/-/g, ""), "DTEND;VALUE=DATE:" + isoOf(next).replace(/-/g, ""),
                "SUMMARY:" + icsEsc("Son gün: " + konu), "DESCRIPTION:" + icsEsc(desc), "STATUS:CONFIRMED", "TRANSP:TRANSPARENT");
            [[3, "3 gün kaldı"], [1, "1 gün kaldı"]].forEach(([days, txt]) => {
                L.push("BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:" + icsEsc(konu + " — " + txt + " (son tarih " + fmtTr(it.sonTarih) + ")"), "TRIGGER:" + icsDuration(days * 1440 - atMin), "END:VALARM");
            });
            L.push("END:VEVENT");
        });
        L.push("END:VCALENDAR");
        return L.map(icsFold).join("\r\n") + "\r\n";
    }
    function fileName(ext, today) { return "evrak-takip-" + (today || todayIso()) + "." + ext; }
    return { STORE_KEY, SETTINGS_KEY, NOTIFIED_KEY, MAX_ITEMS, THRESHOLD_CHOICES, DEFAULT_SETTINGS, FIXED_HOLIDAYS, fromIso, isoOf, isValidIso, fmtTr, parseTrOrIso, istanbulParts, todayIso,
        isBusinessDay, businessDaysBetween, calDays, remainingOf, statusOf, clean, shortSender, newId, sanitizeItem, sanitizeStore, isValidStore, sanitizeTime, sanitizeSettings, isValidSettings,
        findByNo, upsertFromDoc, addManual, updateItem, removeItem, openItems, sortForList, counts, kimdeOf, kimdeLabel, filterByKimde, summaryByKimde, stageOf, dueNotifications, notificationText, pruneNotified, nextDailyMs, isBeforeDailyTime,
        CSV_COLUMNS, csvCell, buildCsv, fnv1a, icsUid, icsEsc, icsFold, icsDuration, buildIcs, fileName };
})();

const storageGet = (keys) => new Promise((res) => { try { const p = chrome.storage.local.get(keys, (o) => res(o || {})); if (p && p.then) p.then((o) => res(o || {}), () => res({})); } catch (e) { res({}); } });
const storageSet = (obj) => new Promise((res) => { try { const p = chrome.storage.local.set(obj, () => res()); if (p && p.then) p.then(() => res(), () => res()); } catch (e) { res(); } });
const call = (fn) => new Promise((res) => { try { const p = fn((v) => res(v)); if (p && p.then) p.then(res, () => res(undefined)); } catch (e) { res(undefined); } });

async function loadState() {
    const o = await storageGet([CONSENT_KEY, TK.STORE_KEY, TK.SETTINGS_KEY, TK.NOTIFIED_KEY]);
    const c = o[CONSENT_KEY];
    return {
        consent: !!(c && c.accepted === true && c.version === EBYS_POLICY_VERSION),
        store: TK.sanitizeStore(o[TK.STORE_KEY]),
        settings: TK.sanitizeSettings(o[TK.SETTINGS_KEY]),
        notified: (o[TK.NOTIFIED_KEY] && typeof o[TK.NOTIFIED_KEY] === "object") ? o[TK.NOTIFIED_KEY] : {}
    };
}
function active(st) { return st.consent && st.settings.notify.enabled && TK.openItems(st.store).length > 0; }

async function clearAll() {
    await call((cb) => chrome.alarms.clear(ALARM_HOURLY, cb));
    await call((cb) => chrome.alarms.clear(ALARM_DAILY, cb));
    const all = (await call((cb) => chrome.notifications.getAll(cb))) || {};
    for (const id of Object.keys(all)) if (id.startsWith(NOTIF_PREFIX)) await call((cb) => chrome.notifications.clear(id, cb));
}

// Alarmlar yalnızca onay + bildirim açık + en az bir açık kayıt varken kurulur; aksi hâlde silinir.
async function ensureAlarms(st) {
    st = st || await loadState();
    if (!active(st)) { await call((cb) => chrome.alarms.clear(ALARM_HOURLY, cb)); await call((cb) => chrome.alarms.clear(ALARM_DAILY, cb)); return false; }
    const now = Date.now();
    const hourly = await call((cb) => chrome.alarms.get(ALARM_HOURLY, cb));
    if (!hourly) chrome.alarms.create(ALARM_HOURLY, { delayInMinutes: 60, periodInMinutes: 60 });
    const want = TK.nextDailyMs(st.settings.notify.dailyTime, now);
    const daily = await call((cb) => chrome.alarms.get(ALARM_DAILY, cb));
    if (!daily || Math.abs(daily.scheduledTime - want) > 60000) chrome.alarms.create(ALARM_DAILY, { when: want });
    return true;
}

function notify(id, opt) {
    return call((cb) => chrome.notifications.create(id, Object.assign({ type: "basic", iconUrl: ICON, priority: 1 }, opt), cb));
}

// Kontrol: günlük saatten önce (İstanbul) bildirim gösterilmez; o saatte Chrome kapalıysa ilk açılışta/ilk saatlik kontrolde gösterilir.
async function runCheck(reason) {
    const st = await loadState();
    if (!active(st)) { await ensureAlarms(st); return { shown: 0, reason: "inactive" }; }
    const now = Date.now(), today = TK.todayIso(now);
    if (reason !== "daily" && TK.isBeforeDailyTime(st.settings.notify.dailyTime, now)) return { shown: 0, reason: "before-daily-time" };
    const due = TK.dueNotifications(st.store, st.settings, st.notified, today);
    const notified = TK.pruneNotified(st.notified, st.store, today);
    let shown = 0;
    for (const d of due.slice(0, MAX_SINGLE)) {
        const t = TK.notificationText(d.item, today);
        await notify(NOTIF_PREFIX + d.item.id + ":" + d.stage + ":" + today, { title: t.title, message: t.message, contextMessage: t.contextMessage, priority: d.status.level === "red" ? 2 : 1 });
        shown++;
    }
    if (due.length > MAX_SINGLE) {
        await notify(NOTIF_PREFIX + "ozet:" + today + ":" + now, { title: "Günlü evrak: " + (due.length - MAX_SINGLE) + " evrak daha", message: "Son tarihi yaklaşan ya da geçen " + (due.length - MAX_SINGLE) + " evrak daha var.", contextMessage: "Evrak Asistanı → 📅 Günlü Takip" });
        shown++;
    }
    due.forEach(d => { notified[d.key] = today; });
    if (due.length || JSON.stringify(notified) !== JSON.stringify(st.notified)) await storageSet({ [TK.NOTIFIED_KEY]: notified });
    await ensureAlarms(st);
    return { shown: shown, due: due.length };
}

// Aynı anda gelen olaylar (açılış + alarm) sırayla işlenir → çift bildirim olmaz
let queue = Promise.resolve();
function enqueue(fn) { const p = queue.then(fn, fn); queue = p.catch(() => {}); return p; }

chrome.runtime.onStartup.addListener(() => enqueue(() => runCheck("startup")));
chrome.runtime.onInstalled.addListener(() => enqueue(() => runCheck("installed")));
chrome.alarms.onAlarm.addListener((a) => {
    if (!a || (a.name !== ALARM_HOURLY && a.name !== ALARM_DAILY)) return;
    return enqueue(async () => {
        if (a.name === ALARM_DAILY) await call((cb) => chrome.alarms.clear(ALARM_DAILY, cb)); // tek seferlik; ensureAlarms ertesi günü kurar
        return runCheck(a.name === ALARM_DAILY ? "daily" : "hourly");
    });
});
chrome.storage.onChanged.addListener((changes, area) => {
    if (area && area !== "local") return;
    if (!(CONSENT_KEY in changes || TK.STORE_KEY in changes || TK.SETTINGS_KEY in changes)) return;
    return enqueue(async () => { const st = await loadState(); if (!st.consent) await clearAll(); else await ensureAlarms(st); });
});
chrome.notifications.onClicked.addListener((id) => {
    if (!String(id).startsWith(NOTIF_PREFIX)) return;
    try { chrome.tabs.create({ url: EBYS_URL }); } catch (e) {}
    try { chrome.notifications.clear(id); } catch (e) {}
});
// Panelden gelen iletiler: yalnızca bu eklentinin kendi betiklerinden (sender.id) kabul edilir.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!sender || sender.id !== chrome.runtime.id || !msg || typeof msg.type !== "string" || !/^ebys-takip-/.test(msg.type)) return;
    enqueue(async () => {
        if (msg.type === "ebys-takip-reset") { await clearAll(); return { ok: true }; }
        const st = await loadState();
        const level = await call((cb) => chrome.notifications.getPermissionLevel(cb));
        if (msg.type === "ebys-takip-status") {
            const alarms = ((await call((cb) => chrome.alarms.getAll(cb))) || []).filter(a => a.name === ALARM_HOURLY || a.name === ALARM_DAILY).map(a => ({ name: a.name, scheduledTime: a.scheduledTime }));
            return { ok: true, consent: st.consent, permission: level || "", alarms: alarms, active: active(st) };
        }
        if (msg.type === "ebys-takip-test") {
            if (!st.consent) return { ok: false, error: "consent" };
            const today = TK.todayIso(Date.now());
            await notify(NOTIF_PREFIX + "test:" + Date.now(), { title: "Test: Evrak Asistanı bildirimleri çalışıyor", message: "Son tarih: " + TK.fmtTr(today) + " — örnek bildirim", contextMessage: "Tıklayınca EBYS açılır" });
            return { ok: true, permission: level || "" };
        }
        if (msg.type === "ebys-takip-check") return Object.assign({ ok: true }, await runCheck("manual"));
        return { ok: false, error: "unknown" };
    }).then((r) => { try { sendResponse(r); } catch (e) {} }, (e) => { try { sendResponse({ ok: false, error: String(e) }); } catch (x) {} });
    return true;
});

// Müdür Paketi: araç çubuğu simgesi paneli aç/kapatır (yazma yok).
try { chrome.action.onClicked.addListener((tab) => { if (tab && tab.id) chrome.tabs.sendMessage(tab.id, { evrakToggle: true }, () => void chrome.runtime.lastError); }); } catch (e) {}


// Müdür Paketi: lisans kapısı lisans/arka.js’te. Araç çubuğu simgesi paneli aç/kapatır.
