Mozilla pdf.js (pdfjs-dist 6.4.299), Apache License 2.0 — bkz. LICENSE.
Yalnızca setup.html (görev dağılımı PDF okuma) kullanır; dosyalar değiştirilmeden paketlenmiştir. Uzak kod yüklenmez.
