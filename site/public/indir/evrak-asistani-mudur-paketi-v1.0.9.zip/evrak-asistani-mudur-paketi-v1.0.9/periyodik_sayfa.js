/* Evrak Asistanı — Düzenli Yazılar yönetim sayfası */
(function () {
  'use strict';
  const P = self.EA_PERIYODIK;
  const $ = s => document.querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const renk = { gecikti: '#F87171', bugun: '#F87171', yakin: '#FB923C', bekliyor: '#93C5FD', gunyok: '#FBBF24', gonderildi: '#22C55E', yok: '#94A3B8', bitti: '#94A3B8' };
  const sira = { gecikti: 0, bugun: 1, yakin: 2, gunyok: 3, bekliyor: 4, gonderildi: 5, yok: 6, bitti: 7 };


  let depo = null, aday = { adaylar: [], yoksay: [], satirlar: [] }, takip = null, paraf = null;
  let sekme = (location.hash || '#donem').slice(1);
  let gorAy = P.bugunIso().slice(0, 7);
  let cizYil = +P.bugunIso().slice(0, 4);

  function bildir(m, hata) {
    const b = $('#bildirim'); b.innerHTML = m; b.style.display = 'block';
    b.style.background = hata ? '#7F1D1D' : '#14532D'; b.style.borderColor = hata ? '#F87171' : '#22C55E';
    clearTimeout(b.__t); b.__t = setTimeout(() => { b.style.display = 'none'; }, 5000);
  }

  async function yukle() {
    try { await P.eskiHazirTemizle(); } catch (e) { }
    const x = await P.oku([P.KEY, P.ADAY_KEY, P.TAKIP_KEY, P.PARAF_KEY]);
    depo = P.depoTemizle(x[P.KEY]);
    const a = x[P.ADAY_KEY] && typeof x[P.ADAY_KEY] === 'object' ? x[P.ADAY_KEY] : {};
    aday = { adaylar: Array.isArray(a.adaylar) ? a.adaylar : [], yoksay: Array.isArray(a.yoksay) ? a.yoksay : [], satirlar: Array.isArray(a.satirlar) ? a.satirlar : [], tarama: a.tarama || null };
    takip = x[P.TAKIP_KEY] || null;
    paraf = x[P.PARAF_KEY] || null;
  }
  async function kaydet(m) { depo = await P.kaydetVeEsitle(depo); ciz(); if (m) bildir(m); }
  async function adayKaydet() { await P.yaz({ [P.ADAY_KEY]: aday }); }

  // ---------------- çizim ----------------
  function ciz() {
    document.querySelectorAll('.sekme').forEach(b => b.classList.toggle('aktif', b.dataset.s === sekme));
    const oneriSay = gorunenAdaylar().length;
    const sb = document.querySelector('.sekme[data-s="oneriler"]');
    sb.innerHTML = '💡 Öneriler' + (oneriSay ? '<span class="sayi">' + oneriSay + '</span>' : '');
    const f = { donem: cizDonem, liste: cizListe, oneriler: cizOneriler, cizelge: cizCizelge, ayarlar: cizAyarlar }[sekme] || cizDonem;
    f();
  }

  function cizDonem() {
    const bugun = P.bugunIso();
    const satirlar = [];
    depo.kartlar.filter(k => k.aktif).forEach(k => {
      let donemler;
      if (gorAy === bugun.slice(0, 7)) donemler = P.aktifDonemler(k, bugun);
      else donemler = P.donemVarMi(k, gorAy) ? [gorAy] : [];
      donemler.forEach(p => { const d = P.durum(k, p, bugun, depo.ayar.ekTatiller, P.gelenBul(k, takip, p)); satirlar.push({ k, p, d }); });
    });
    satirlar.sort((a, b) => (sira[a.d.kod] - sira[b.d.kod]) || String(a.d.sonTarih).localeCompare(String(b.d.sonTarih)));
    const bekleyen = satirlar.filter(s => !['gonderildi', 'yok', 'bitti'].includes(s.d.kod)).length;
    let h = '<div class="ust"><div class="ay-sec"><button class="b gri kucuk" id="ay-geri">‹</button><b>' + esc(P.ayAdi(gorAy)) + '</b><button class="b gri kucuk" id="ay-ileri">›</button>' +
      (gorAy !== bugun.slice(0, 7) ? '<button class="b gri kucuk" id="ay-bugun">Bu ay</button>' : '') + '</div><span class="bos"></span><span class="soluk">' +
      satirlar.length + ' yazı · ' + bekleyen + ' bekliyor</span><button class="b gri kucuk" id="btn-yazdir">🖨️ Yazdır</button></div>';
    if (!depo.kartlar.length) {
      h += bosAnlatim();
    } else if (!satirlar.length) {
      h += '<div class="bos-mesaj">Bu ay için düzenli yazı yok.</div>';
    } else {
      h += '<table><thead><tr><th>Yazı</th><th>Kime</th><th>Dönem / Son gün</th><th>Durum</th><th>İşlem</th></tr></thead><tbody>' + satirlar.map((s, i) => {
        const g = s.d.gonderim;
        const gelen = s.d.gelen ? '<div style="color:#FDE68A;font-size:12px;">📨 Hatırlatma yazısı geldi' + (s.d.gelen.evrakNo ? ' (' + esc(s.d.gelen.evrakNo) + ')' : '') + '</div>' : '';
        return '<tr><td><b>' + esc(s.k.ad) + '</b>' + (s.k.konuKodu ? '<div class="soluk">🗂 ' + esc(s.k.konuKodu) + '</div>' : '') + gelen + '</td>' +
          '<td>' + esc(s.k.kime || '—') + '</td>' +
          '<td>' + esc(P.ayAdi(s.p)) + '<div class="soluk">' + (s.d.sonTarih ? P.trTarih(s.d.sonTarih) : '—') + '</div></td>' +
          '<td><span class="etiket" style="background:' + (renk[s.d.kod] || '#93C5FD') + '22;color:' + (renk[s.d.kod] || '#93C5FD') + ';">' + esc(s.d.etiket) + '</span>' +
          (g && g.no ? '<div class="soluk">' + esc(g.no) + '</div>' : '') + (g && g.kaynak === 'tarama' ? '<div class="soluk">listeden bulundu</div>' : '') + '</td>' +
          '<td><div class="islem">' + (g ? '<button class="b gri kucuk" data-geri="' + i + '">↩ Geri al</button>'
            : (s.k.metin ? '<button class="b mor kucuk" data-kopya="' + i + '">📋 Metni kopyala</button>' : '') +
            '<button class="b yesil kucuk" data-gonder="' + i + '">✅ Gönderildi</button><button class="b gri kucuk" data-yok="' + i + '">➖ Bu dönem yok</button>') +
          '<button class="b gri kucuk" data-duzen="' + esc(s.k.id) + '">✏️</button></div></td></tr>';
      }).join('') + '</tbody></table>';
    }
    $('#icerik').innerHTML = h;
    const b = (id, f) => { const e = $(id); if (e) e.onclick = f; };
    b('#ay-geri', () => { gorAy = P.ayEkle(gorAy, -1); ciz(); });
    b('#ay-ileri', () => { gorAy = P.ayEkle(gorAy, 1); ciz(); });
    b('#ay-bugun', () => { gorAy = P.bugunIso().slice(0, 7); ciz(); });
    b('#btn-yazdir', () => window.print());
    baglaBos();
    document.querySelectorAll('[data-gonder]').forEach(e => e.onclick = () => isaretle(satirlar[+e.dataset.gonder], 'elle'));
    document.querySelectorAll('[data-yok]').forEach(e => e.onclick = () => isaretle(satirlar[+e.dataset.yok], 'yok'));
    document.querySelectorAll('[data-geri]').forEach(e => e.onclick = () => { const s = satirlar[+e.dataset.geri]; delete s.k.gonderim[s.p]; kaydet('↩ Geri alındı.'); });
    document.querySelectorAll('[data-kopya]').forEach(e => e.onclick = () => kopyala(satirlar[+e.dataset.kopya]));
    document.querySelectorAll('[data-duzen]').forEach(e => e.onclick = () => duzenle(depo.kartlar.find(k => k.id === e.dataset.duzen)));
  }

  function bosAnlatim() {
    return '<div class="bos-mesaj"><b>Liste henüz boş.</b> Nasıl oluşturulur:<br><br>' +
      '1) EBYS\'yi açın. Üstteki <b>🔁 Düzenli yazılar</b> rozetine tıklayın ve <b>🔍 Geçmiş yazılardan bul</b> düğmesine basın.<br>' +
      '&nbsp;&nbsp;&nbsp;&nbsp;Parafladıklarım listesi sayfa sayfa okunur; her ay aynı konuyla giden yazılar (ör. aylık rapor, dönem sonu çizelgesi) bulunur.<br>' +
      '2) Bulunanlar <b>💡 Öneriler</b> sekmesine gelir; son günü ve kime gittiğini kontrol edip <b>Listeye ekle</b> deyin.<br>' +
      '3) Ya da <b>➕ Yeni düzenli yazı</b> ile elle ekleyin.<br><br>' +
      '<button class="b" id="bos-oneri">💡 Önerilere git</button></div>';
  }
  function baglaBos() { const e = $('#bos-oneri'); if (e) e.onclick = () => sekmeAc('oneriler'); }

  async function isaretle(s, tur) {
    let no = '';
    if (tur === 'elle') { no = prompt('“' + s.k.ad + '” — ' + P.ayAdi(s.p) + ' gönderildi.\nEvrak sayısı (isteğe bağlı):', ''); if (no === null) return; }
    s.k.gonderim[s.p] = { tarih: P.bugunIso(), no: String(no || '').trim(), kaynak: tur, konu: '' };
    if (tur === 'elle' && s.d.gelen && s.d.gelen.id && takip && Array.isArray(takip.items)) {
      const it = takip.items.find(i => i.id === s.d.gelen.id);
      if (it && it.durum !== 'tamamlandi') { it.durum = 'tamamlandi'; it.tamamlanma = P.bugunIso(); await P.yaz({ [P.TAKIP_KEY]: takip }); }
    }
    kaydet(tur === 'yok' ? '➖ Bu dönem yok olarak işaretlendi.' : '✅ Gönderildi olarak işaretlendi.');
  }
  async function kopyala(s) {
    const r = P.donemMetni(s.k, s.p);
    try { await navigator.clipboard.writeText(r.metin); bildir('📋 Kopyalandı. ' + (r.degisen.length ? 'Güncellenen: ' + r.degisen.slice(0, 5).map(d => esc(d.eski) + ' → <b>' + esc(d.yeni) + '</b>').join(', ') : 'Metinde ay/tarih yoktu.')); }
    catch (e) { bildir('⚠️ Panoya kopyalanamadı: ' + esc(e.message || e), true); }
  }

  function cizListe() {
    if (!depo.kartlar.length) { $('#icerik').innerHTML = bosAnlatim(); baglaBos(); return; }
    const k = depo.kartlar.slice().sort((a, b) => (b.aktif - a.aktif) || a.ad.localeCompare(b.ad, 'tr'));
    $('#icerik').innerHTML = '<table><thead><tr><th>Yazı</th><th>Ne zaman</th><th>Kime</th><th>Eşleşme</th><th>Metin</th><th></th></tr></thead><tbody>' + k.map(c =>
      '<tr style="' + (c.aktif ? '' : 'opacity:.5') + '"><td><b>' + esc(c.ad) + '</b>' + (c.aktif ? '' : ' <span class="soluk">(pasif)</span>') + (c.not ? '<div class="soluk">' + esc(c.not) + '</div>' : '') + '</td>' +
      '<td>' + esc(neZaman(c)) + (c.bitis ? '<div class="soluk">' + P.trTarih(c.bitis) + ' tarihine kadar</div>' : '') + '</td>' +
      '<td>' + esc(c.kime || '—') + (c.konuKodu ? '<div class="soluk">🗂 ' + esc(c.konuKodu) + '</div>' : '') + '</td>' +
      '<td class="soluk">' + esc(c.anahtar ? 'kelimeler: ' + c.anahtar : (c.ornekKonu ? 'konuya benzer: ' + c.ornekKonu : 'ada benzer')) + '</td>' +
      '<td>' + (c.metin ? '✅' + (c.sablonaEkle ? ' <span class="soluk">şablonda</span>' : '') : '<span class="soluk">yok</span>') + '</td>' +
      '<td><div class="islem"><button class="b kucuk" data-duzen="' + esc(c.id) + '">✏️ Düzenle</button><button class="b kirmizi kucuk" data-sil="' + esc(c.id) + '">🗑</button></div></td></tr>'
    ).join('') + '</tbody></table>';
    document.querySelectorAll('[data-duzen]').forEach(e => e.onclick = () => duzenle(depo.kartlar.find(c => c.id === e.dataset.duzen)));
    document.querySelectorAll('[data-sil]').forEach(e => e.onclick = () => {
      const c = depo.kartlar.find(x => x.id === e.dataset.sil);
      if (!c || !confirm('“' + c.ad + '” listeden silinsin mi? Gönderim geçmişi de silinir. (Bunun yerine Düzenle → Pasif de yapabilirsiniz.)')) return;
      depo.kartlar = depo.kartlar.filter(x => x.id !== c.id); kaydet('🗑 Silindi.');
    });
  }
  function neZaman(c) {
    const gun = c.gun === 'son' ? 'ay sonu' : (c.gun ? 'ayın ' + c.gun + "'ine kadar" : 'son gün girilmemiş');
    if (c.periyot === 'aylik') return 'Her ay · ' + gun;
    return P.PERIYOTLAR[c.periyot].ad + ' (' + c.aylar.map(m => P.AYLAR[m - 1]).join(', ') + ') · ' + gun;
  }

  // ---------------- öneriler ----------------
  function gorunenAdaylar() {
    // Öneriler yalnız taramadan (ve tekrarlı yazı kurallarından) gelir; sabit/hazır liste yoktur.
    return (aday.adaylar || []).filter(a => !aday.yoksay.includes(a.id) && !depo.kartlar.some(k => P.eslesir(k, a.ornekKonu)));
  }
  function cizOneriler() {
    const list = gorunenAdaylar();
    const t = aday.tarama;
    let h = '<div class="ipucu">💡 Öneriler, EBYS\'de <b>🔁 Düzenli yazılar → 🔍 Geçmiş yazılardan bul</b> ile okunan yazılardan çıkarılır: aynı konuyla en az 3 farklı ayda giden yazılar.' +
      (t ? ' Son tarama: <b>' + P.trTarih(t.tarih) + '</b> · toplam ' + (aday.satirlar || []).length + ' yazı.' : ' <b>Henüz tarama yapılmadı.</b>') +
      ' Mevcut <b>Tekrarlı yazı</b> kurallarınız da buraya öneri olarak gelir.</div>';
    if (!list.length) { $('#icerik').innerHTML = h + '<div class="bos-mesaj">Şu an öneri yok.</div>'; return; }
    const yuksek = list.filter(a => a.guven === 'yuksek' && a.gun !== '');
    if (yuksek.length > 1) h += '<div style="margin-bottom:10px;"><button class="b yesil" id="tumunu-ekle">➕ Güvenli ' + yuksek.length + ' öneriyi birden ekle</button></div>';
    h += list.map((a, i) => {
      const kay = a.kaynak === 'tekrar' ? '🔁 Tekrarlı yazı kuralınızdan' :
        a.aySayisi + ' farklı ayda ' + a.adet + ' kez gönderilmiş · ' + P.ayAdi(a.ilk) + ' – ' + P.ayAdi(a.son) + (a.son12 != null ? ' · son 12 ayda ' + a.son12 + ' ay' : '');
      return '<div class="kart"><div style="display:flex;gap:10px;align-items:flex-start;"><div style="flex:1;"><h3>' + esc(a.ad) + '</h3>' +
        '<div class="soluk">' + esc(kay) + '</div>' +
        '<div style="margin-top:4px;">📆 ' + esc(neZaman(P.kartTemizle(Object.assign({}, a)) || a)) + (a.kime ? ' · 🎯 ' + esc(a.kime) : '') + (a.metin ? ' · 📝 geçmiş metin bulundu' : '') + '</div>' +
        (a.not ? '<div style="color:#FDE68A;font-size:12.5px;">' + esc(a.not) + '</div>' : '') +
        (a.ornekler && a.ornekler.length ? '<details style="margin-top:5px;"><summary>Örnek yazılar (' + a.ornekler.length + ')</summary><div class="soluk" style="margin-top:4px;line-height:1.5;">' +
          a.ornekler.slice(0, 15).map(o => P.trTarih(o.tarih) + ' — ' + esc(o.konu) + (o.yer ? ' → ' + esc(o.yer) : '')).join('<br>') + '</div></details>' : '') +
        '</div><div class="islem"><button class="b yesil kucuk" data-ekle="' + i + '">➕ Listeye ekle</button><button class="b gri kucuk" data-yoksay="' + i + '">Yoksay</button></div></div></div>';
    }).join('');
    $('#icerik').innerHTML = h;
    document.querySelectorAll('[data-ekle]').forEach(e => e.onclick = () => duzenle(adaydanKart(list[+e.dataset.ekle]), list[+e.dataset.ekle]));
    document.querySelectorAll('[data-yoksay]').forEach(e => e.onclick = async () => { aday.yoksay.push(list[+e.dataset.yoksay].id); await adayKaydet(); ciz(); });
    const te = $('#tumunu-ekle'); if (te) te.onclick = async () => {
      if (!confirm(yuksek.length + ' öneri listeye eklensin mi? Sonra tek tek düzenleyebilirsiniz.')) return;
      yuksek.forEach(a => { const k = P.kartTemizle(adaydanKart(a)); if (k) { depo.kartlar.push(k); aday.yoksay.push(a.id); } });
      await adayKaydet(); kaydet('➕ ' + yuksek.length + ' düzenli yazı eklendi.');
    };
  }
  function adaydanKart(a) {
    const k = {
      ad: a.ad, ornekKonu: a.ornekKonu, anahtar: a.anahtar || '', kime: a.kime || '', periyot: a.periyot, gun: a.gun, aylar: a.aylar || [],
      bitis: a.bitis || '', metin: a.metin || '', metinAy: a.metinAy || '', baslangic: a.ilk || '', not: '', gonderim: {}, __adayId: a.id
    };
    const c = P.kartTemizle(k);
    // geçmiş gönderimleri doldur (yıllık çizelge için)
    (a.ornekler || []).forEach(o => { const p = P.donemBul(c, o.tarih); if (p && !c.gonderim[p]) c.gonderim[p] = { tarih: o.tarih, no: o.no || '', kaynak: 'tarama', konu: o.konu }; });
    (aday.satirlar || []).forEach(o => { if (!P.eslesir(c, o.konu)) return; const p = P.donemBul(c, o.tarih); if (p && !c.gonderim[p]) c.gonderim[p] = { tarih: o.tarih, no: o.no || '', kaynak: 'tarama', konu: o.konu }; });
    if (!c.metin) { const m = P.parafMetniBul(c, paraf, a.ornekler); if (m) { c.metin = m.metin; c.metinAy = m.ay || ''; } }
    c.__adayId = a.id;
    return c;
  }

  // ---------------- yıllık çizelge ----------------
  function cizCizelge() {
    const bugun = P.bugunIso();
    let h = '<div class="ust"><div class="ay-sec"><button class="b gri kucuk" id="yil-geri">‹</button><b>' + cizYil + '</b><button class="b gri kucuk" id="yil-ileri">›</button></div>' +
      '<span class="bos"></span><span class="soluk">✅ gönderildi · ❌ gönderilmedi · ⏳ bekliyor · ➖ yok</span><button class="b gri kucuk" id="btn-csv">📗 Excel (CSV)</button><button class="b gri kucuk" id="btn-yazdir">🖨️ Yazdır</button></div>';
    if (!depo.kartlar.length) { $('#icerik').innerHTML = h + bosAnlatim(); baglaBos(); return; }
    h += '<table class="cizelge"><thead><tr><th>Yazı</th>' + P.AYLAR.map(a => '<th>' + a.slice(0, 3) + '</th>').join('') + '</tr></thead><tbody>' +
      depo.kartlar.filter(k => k.aktif || Object.keys(k.gonderim).some(p => p.startsWith(cizYil + '-'))).map(k => '<tr><td><b>' + esc(k.ad) + '</b><div class="soluk">' + esc(neZaman(k)) + '</div></td>' +
        P.AYLAR.map((_, m) => {
          const p = P.ayKey(cizYil, m + 1);
          if (!P.donemVarMi(k, p)) return '<td></td>';
          const d = P.durum(k, p, bugun, depo.ayar.ekTatiller);
          const gelecek = p > bugun.slice(0, 7);
          let s = '', r = '#64748B', t = '';
          if (d.kod === 'gonderildi') { s = '✅'; r = '#22C55E'; t = 'Gönderildi ' + P.trTarih(d.gonderim.tarih) + (d.gonderim.no ? ' ' + d.gonderim.no : ''); }
          else if (d.kod === 'yok') { s = '➖'; t = 'Bu dönem yok'; }
          else if (d.kod === 'bitti') { s = ''; }
          else if (d.kod === 'gecikti') { s = '❌'; r = '#F87171'; t = 'Gönderilmedi (son gün ' + P.trTarih(d.sonTarih) + ')'; }
          else if (!gelecek) { s = '⏳'; r = '#FB923C'; t = d.etiket; }
          return '<td title="' + esc(t) + '"><span class="hucre" style="color:' + r + '">' + s + '</span></td>';
        }).join('') + '</tr>').join('') + '</tbody></table>' +
      '<p class="soluk">Geçmiş aylar, EBYS\'deki tarama ile bulunan yazılardan dolar. Tarama yapılmadan önceki aylar ❌ görünebilir; hücreye bakıp gerekirse ✏️ ile düzeltin.</p>';
    $('#icerik').innerHTML = h;
    $('#yil-geri').onclick = () => { cizYil--; ciz(); };
    $('#yil-ileri').onclick = () => { cizYil++; ciz(); };
    $('#btn-yazdir').onclick = () => window.print();
    $('#btn-csv').onclick = () => indir('duzenli_yazilar_' + cizYil + '.csv', P.cizelgeCsv(depo, cizYil, bugun), 'text/csv;charset=utf-8');
  }

  // ---------------- ayarlar ----------------
  function cizAyarlar() {
    const a = depo.ayar;
    $('#icerik').innerHTML = '<div class="kart" style="max-width:720px;"><h3>🔔 Hatırlatma</h3>' +
      '<label style="display:flex;gap:6px;align-items:center;margin:8px 0;"><input type="checkbox" id="a-bildirim"' + (a.bildirim ? ' checked' : '') + '> Windows bildirimi göster</label>' +
      '<label>Kaç gün kala hatırlatılsın? (virgülle; 0 = son gün)<input type="text" id="a-esik" value="' + esc(a.esikler.join(', ')) + '"></label>' +
      '<label style="display:flex;gap:6px;align-items:center;margin:8px 0;"><input type="checkbox" id="a-gecikme"' + (a.gecikmeBildir ? ' checked' : '') + '> Geciken yazıyı her gün bir kez hatırlat</label>' +
      '<label>Bildirimler bu saatten sonra gelsin<input type="text" id="a-saat" value="' + esc(a.saat) + '" placeholder="09:05" style="max-width:120px;"></label>' +
      '<label style="margin-top:10px;">Ek tatil günleri (dinî bayramlar, idari izin; gg.aa.yyyy, virgülle). Son gün tatile denk gelirse önceki iş gününe çekilir.<input type="text" id="a-tatil" value="' + esc(a.ekTatiller.map(P.trTarih).join(', ')) + '"></label>' +
      '<div class="islem" style="margin-top:12px;"><button class="b" id="a-kaydet">💾 Kaydet</button><button class="b gri" id="a-test">🔔 Deneme bildirimi</button></div></div>' +
      '<div class="kart" style="max-width:720px;"><h3>🧹 Öneriler</h3><div class="soluk">Yoksaydığınız ' + aday.yoksay.length + ' öneri var. Tarama sonucunda ' + (aday.satirlar || []).length + ' yazı saklı (yalnızca konu, tarih, yer, evrak no).</div>' +
      '<div class="islem" style="margin-top:8px;"><button class="b gri" id="a-yoksay">Yoksayılanları geri getir</button><button class="b kirmizi" id="a-tarama-sil">Tarama sonuçlarını sil</button></div></div>';
    $('#a-kaydet').onclick = () => {
      a.bildirim = $('#a-bildirim').checked; a.gecikmeBildir = $('#a-gecikme').checked;
      a.esikler = $('#a-esik').value.split(/[,; ]+/).map(Number).filter(n => Number.isInteger(n) && n >= 0 && n <= 15);
      a.saat = /^\d{1,2}:\d{2}$/.test($('#a-saat').value.trim()) ? $('#a-saat').value.trim().padStart(5, '0') : '09:05';
      a.ekTatiller = $('#a-tatil').value.split(/[,;\s]+/).map(P.trDenIso).filter(Boolean);
      kaydet('💾 Ayarlar kaydedildi.');
    };
    $('#a-test').onclick = () => { try { chrome.runtime.sendMessage({ type: 'ea-periyodik-test' }, () => { void chrome.runtime.lastError; bildir('🔔 Deneme bildirimi gönderildi. Görmediyseniz Windows bildirim ayarlarını kontrol edin.'); }); } catch (e) { } };
    $('#a-yoksay').onclick = async () => { aday.yoksay = []; await adayKaydet(); ciz(); bildir('Yoksayılanlar geri geldi.'); };
    $('#a-tarama-sil').onclick = async () => { if (!confirm('Tarama sonuçları ve öneriler silinsin mi? (Listeniz silinmez.)')) return; aday = { adaylar: [], yoksay: aday.yoksay, satirlar: [] }; await adayKaydet(); ciz(); bildir('Silindi.'); };
  }

  // ---------------- düzenleme penceresi ----------------
  function duzenle(kart, adayKaydi) {
    const yeni = !kart || !depo.kartlar.some(k => k.id === kart.id);
    const k = P.kartTemizle(Object.assign({ ad: 'Yeni düzenli yazı', periyot: 'aylik', gun: 5 }, kart || {}));
    if (kart && kart.gun === '') k.gun = '';
    const ark = document.createElement('div'); ark.className = 'modal-arka';
    const gunSecenek = '<option value="">— seçin —</option>' + Array.from({ length: 31 }, (_, i) => '<option value="' + (i + 1) + '"' + (k.gun === i + 1 ? ' selected' : '') + '>Ayın ' + (i + 1) + "'i</option>").join('') + '<option value="son"' + (k.gun === 'son' ? ' selected' : '') + '>Ayın son günü</option>';
    ark.innerHTML = '<div class="modal"><h2>' + (yeni ? '➕ Düzenli yazı ekle' : '✏️ ' + esc(k.ad)) + '</h2><div class="izgara">' +
      '<label class="tam">Yazının adı (şablonlarda bu adla görünür)<input type="text" id="f-ad" value="' + esc(k.ad) + '"></label>' +
      '<label>Ne sıklıkla<select id="f-periyot">' + Object.keys(P.PERIYOTLAR).map(p => '<option value="' + p + '"' + (k.periyot === p ? ' selected' : '') + '>' + P.PERIYOTLAR[p].ad + '</option>').join('') + '</select></label>' +
      '<label>Son gün<select id="f-gun">' + gunSecenek + '</select></label>' +
      '<div class="tam" id="f-aylar-kap"><label>Hangi aylarda gidiyor?</label><div class="aylar-sec">' + P.AYLAR.map((a, i) => '<label><input type="checkbox" class="f-ay" value="' + (i + 1) + '"' + (k.aylar.includes(i + 1) ? ' checked' : '') + '>' + a + '</label>').join('') + '</div></div>' +
      '<label>Kime gidiyor (Gereği)<input type="text" id="f-kime" value="' + esc(k.kime) + '" placeholder="ör. İlçe Milli Eğitim Müdürlüğü"></label>' +
      '<label>Konu kodu (isteğe bağlı)<input type="text" id="f-kod" value="' + esc(k.konuKodu) + '" placeholder="ör. 349"></label>' +
      '<label>Başlangıç ayı (boşsa hep)<input type="month" id="f-bas" value="' + esc(k.baslangic) + '"></label>' +
      '<label>Bitiş tarihi (boşsa süresiz)<input type="date" id="f-bitis" value="' + esc(k.bitis) + '"></label>' +
      '<label class="tam">Tanıma kelimeleri (virgülle; boşsa konunun benzerliğine bakılır). Örn: <i>aylık rapor</i> ya da <i>çizelge, bildirim</i>' +
      '<input type="text" id="f-anahtar" value="' + esc(k.anahtar) + '"></label>' +
      '<div class="tam soluk" id="f-eslesme"></div>' +
      '<label class="tam">Cevap metni (geçen dönemin yazısı; ay adları ve tarihler her dönem kendiliğinden güncellenir)<textarea id="f-metin" placeholder="Geçen ay gönderdiğiniz yazının metnini buraya yapıştırın.">' + esc(k.metin) + '</textarea></label>' +
      '<label>Bu metin hangi dönemin?<input type="month" id="f-metinay" value="' + esc(k.metinAy) + '"></label>' +
      '<div style="display:flex;flex-direction:column;justify-content:flex-end;gap:6px;"><button class="b gri kucuk" id="f-parafdan">🎓 Parafladıklarım\'dan metni getir</button></div>' +
      '<div class="tam"><details id="f-oniz-kap"><summary>👁 Bu dönem için metnin önizlemesi</summary><div class="onizleme" id="f-oniz" style="margin-top:6px;"></div></details></div>' +
      '<label class="tam" style="display:flex;gap:6px;align-items:center;"><input type="checkbox" id="f-sablon"' + (k.sablonaEkle ? ' checked' : '') + '> Kendi Şablonlarım\'a ekle (Cevap Yaz\'da Otonom ve 📋 Şablon menüsü bu metni kullanabilsin)</label>' +
      '<label class="tam">Not<input type="text" id="f-not" value="' + esc(k.not) + '"></label>' +
      '<label class="tam" style="display:flex;gap:6px;align-items:center;"><input type="checkbox" id="f-aktif"' + (k.aktif ? ' checked' : '') + '> Aktif (takip edilsin, hatırlatılsın)</label>' +
      '</div><div class="islem" style="margin-top:14px;justify-content:flex-end;"><span id="f-hata" style="color:#F87171;margin-right:auto;"></span><button class="b gri" id="f-iptal">Vazgeç</button><button class="b yesil" id="f-kaydet">💾 Kaydet</button></div></div>';
    document.body.appendChild(ark);
    const q = s => ark.querySelector(s);
    const formdan = () => {
      const g = q('#f-gun').value;
      return P.kartTemizle(Object.assign({}, k, {
        ad: q('#f-ad').value, periyot: q('#f-periyot').value, gun: g === 'son' ? 'son' : (g ? +g : ''),
        aylar: Array.from(ark.querySelectorAll('.f-ay:checked')).map(x => +x.value),
        kime: q('#f-kime').value, konuKodu: q('#f-kod').value, baslangic: q('#f-bas').value, bitis: q('#f-bitis').value,
        anahtar: q('#f-anahtar').value, metin: q('#f-metin').value, metinAy: q('#f-metinay').value,
        sablonaEkle: q('#f-sablon').checked, not: q('#f-not').value, aktif: q('#f-aktif').checked
      }));
    };
    const aylarGoster = () => {
      const p = q('#f-periyot').value;
      q('#f-aylar-kap').style.display = p === 'aylik' ? 'none' : '';
      if (p !== 'aylik' && !ark.querySelectorAll('.f-ay:checked').length) P.varsayilanAylar(p).forEach(m => { const c = ark.querySelector('.f-ay[value="' + m + '"]'); if (c) c.checked = true; });
    };
    const eslesmeGoster = () => {
      const c = formdan(); if (!c) return;
      const satir = (aday.satirlar || []).filter(s => P.eslesir(c, s.konu));
      q('#f-eslesme').innerHTML = satir.length ? '🔎 Taranan yazılardan <b>' + satir.length + '</b> tanesi bu kurala uyuyor (ör. ' + esc(satir[0].konu) + ' — ' + P.trTarih(satir[0].tarih) + ').' : ((aday.satirlar || []).length ? '⚠️ Taranan yazılardan hiçbiri bu kelimelere uymuyor; otomatik "gönderildi" işareti çalışmaz.' : '');
    };
    const onizle = () => {
      const c = formdan(); if (!c || !c.metin) { q('#f-oniz').textContent = 'Metin yok.'; return; }
      const p = P.aktifDonemler(c, P.bugunIso()).slice(-1)[0] || P.bugunIso().slice(0, 7);
      const r = P.donemMetni(c, p);
      let html = esc(r.metin);
      r.degisen.forEach(d => { html = html.split(esc(d.yeni)).join('<mark>' + esc(d.yeni) + '</mark>'); });
      q('#f-oniz').innerHTML = '<div class="soluk" style="margin-bottom:6px;">' + esc(P.ayAdi(p)) + ' dönemi · ' + (r.degisen.length ? r.degisen.length + ' yer güncellendi (sarı)' : 'değişen yer yok') + '</div>' + html;
    };
    q('#f-periyot').onchange = aylarGoster; aylarGoster();
    q('#f-anahtar').oninput = eslesmeGoster; q('#f-ad').oninput = eslesmeGoster; eslesmeGoster();
    q('#f-oniz-kap').ontoggle = onizle; q('#f-metin').oninput = () => { if (q('#f-oniz-kap').open) onizle(); }; q('#f-metinay').onchange = onizle;
    q('#f-parafdan').onclick = () => {
      const c = formdan(); if (!c) return;
      const ornek = (aday.satirlar || []).filter(s => P.eslesir(c, s.konu)).sort((a, b) => b.tarih.localeCompare(a.tarih));
      const m = P.parafMetniBul(c, paraf, ornek);
      if (!m) { q('#f-hata').textContent = 'Parafladıklarım\'dan öğrenilmiş metin bulunamadı. EBYS\'de şablon öğrenme (Parafladıklarım) çalıştırıldıysa kelimeleri kontrol edin; ya da metni yapıştırın.'; return; }
      q('#f-metin').value = m.metin; if (m.ay) q('#f-metinay').value = m.ay; q('#f-hata').textContent = ''; bildir('🎓 Metin getirildi (' + esc(m.no) + ').'); if (q('#f-oniz-kap').open) onizle();
    };
    q('#f-iptal').onclick = () => ark.remove();
    ark.addEventListener('mousedown', e => { if (e.target === ark) ark.__d = true; });
    ark.addEventListener('mouseup', e => { if (e.target === ark && ark.__d) ark.remove(); ark.__d = false; });
    q('#f-kaydet').onclick = async () => {
      const c = formdan();
      if (!c || !c.ad.trim()) { q('#f-hata').textContent = 'Ad boş olamaz.'; return; }
      if (c.gun === '') { if (!confirm('Son gün seçilmedi. Hatırlatma yapılamaz. Yine de kaydedilsin mi?')) return; }
      if (c.periyot !== 'aylik' && !c.aylar.length) { q('#f-hata').textContent = 'En az bir ay seçin.'; return; }
      if (c.metin && !c.metinAy) c.metinAy = P.oncekiDonem(c, P.bugunIso().slice(0, 7)) || P.bugunIso().slice(0, 7);
      const i = depo.kartlar.findIndex(x => x.id === c.id);
      if (i >= 0) depo.kartlar[i] = c; else depo.kartlar.push(c);
      // taramadan gönderimleri doldur
      P.gonderimleriIsle(depo, aday.satirlar || []);
      if (adayKaydi) { aday.yoksay.push(adayKaydi.id); await adayKaydet(); }
      ark.remove();
      await kaydet('💾 Kaydedildi: ' + esc(c.ad) + (c.sablonaEkle && c.metin ? ' (Kendi Şablonlarım\'a da eklendi)' : ''));
    };
  }

  // ---------------- yedek ----------------
  function indir(ad, icerik, tur) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([icerik], { type: tur })); a.download = ad; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  $('#btn-disa').onclick = () => indir('duzenli_yazilar_yedek_' + P.bugunIso() + '.json', JSON.stringify({ tur: 'evrak-asistani-duzenli-yazilar', surum: 1, tarih: P.bugunIso(), veri: depo }, null, 1), 'application/json');
  $('#btn-ice').onclick = () => $('#dosya').click();
  $('#dosya').onchange = async e => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    try {
      const j = JSON.parse(await f.text());
      const gelen = P.depoTemizle(j && j.veri ? j.veri : j);
      if (!gelen.kartlar.length) throw new Error('Dosyada düzenli yazı yok.');
      const birles = confirm(gelen.kartlar.length + ' düzenli yazı bulundu.\n\nTamam = mevcut listeye EKLE (aynı adlılar güncellenir)\nİptal = vazgeç');
      if (!birles) return;
      gelen.kartlar.forEach(g => { const i = depo.kartlar.findIndex(k => k.id === g.id || k.ad === g.ad); if (i >= 0) depo.kartlar[i] = Object.assign(g, { id: depo.kartlar[i].id }); else depo.kartlar.push(g); });
      kaydet('📂 ' + gelen.kartlar.length + ' düzenli yazı yüklendi.');
    } catch (err) { bildir('⚠️ Yedek okunamadı: ' + esc(err.message || err), true); }
  };
  $('#btn-yeni').onclick = () => duzenle(null);

  function sekmeAc(s) { sekme = s; history.replaceState(null, '', '#' + s); ciz(); }
  document.querySelectorAll('.sekme').forEach(b => b.onclick = () => sekmeAc(b.dataset.s));
  window.addEventListener('hashchange', () => { sekme = (location.hash || '#donem').slice(1); ciz(); });

  try {
    chrome.storage.onChanged.addListener(async (ch, alan) => {
      if (alan !== 'local') return;
      if (ch[P.KEY] || ch[P.ADAY_KEY] || ch[P.TAKIP_KEY]) { if (document.querySelector('.modal-arka')) return; await yukle(); ciz(); }
    });
  } catch (e) { }
  try { $('#surum').textContent = chrome.runtime.getManifest().name + ' v' + chrome.runtime.getManifest().version; } catch (e) { }

  (async () => {
    if (!(await P.onayVarMi())) {
      $('#icerik').innerHTML = '<div class="bos-mesaj">Evrak Asistanı\'nı kullanmak için önce EBYS sayfasında gizlilik onayını verin.</div>';
      return;
    }
    await yukle(); ciz();
  })();
})();
