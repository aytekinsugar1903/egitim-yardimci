// Evrak Asistanı DYS 1.0.25 — gelen yazı özeti (yerel; hiçbir yere gönderilmez)
(function (G) {
    const tl = s => String(s || "").toLocaleLowerCase("tr-TR");
    const BAS = [/^(say[ıi]n\b.{0,60}|.{0,60}(m[üu]d[üu]rl[üu][gğ][üu]ne|makam[ıi]na|ba[sş]kanl[ıi][gğ][ıi]na|valili[gğ]ine|kaymakaml[ıi][gğ][ıi]na)|da[gğ][ıi]t[ıi]m yerlerine)$/i, /^t\.?\s*c\.?$/i, /^t\.c\./i, /valili[gğ]i|kaymakaml[ıi][gğ]ı|bakanl[ıi][gğ]ı|m[üu]d[üu]rl[üu][gğ][üu]$|ba[sş]kanl[ıi][gğ]ı$|^hastanesi/i,
        /^(say[ıi]|konu|[iİ]lgi|ek|ekler|ek ?\d|da[gğ][ıi]t[ıi]m|gere[gğ]i|bilgi|tarih)\s*[:\-]/i, /^(da[gğ][ıi]t[ıi]m|gere[gğ]i|bilgi)\s*:?$/i, /^[a-zçğıöşü]\)\s/i,
        /e-?imza|elektronik imza|güvenli elektronik|do[gğ]rulama|dogrulama|belgedogrula|evraksorgu|turkiye\.gov/i,
        /kep\b|kep adresi|telefon|tel\s*[:.]|faks|fax|e-?posta|@|https?:|www\.|\.gov\.tr|bilgi i[cç]in|adres\s*:/i,
        /mah\.|mahallesi|cad\.|caddesi|sok\.|sokak|bulvar|no\s*:|kat\s*:/i, /^(ad[ıi] ?soyad[ıi]|unvan[ıi]?|imza)\s*:?/i,
        /^(vali|kaymakam|il sa[gğ]l[ıi]k m[üu]d[üu]r[üu]|m[üu]d[üu]r|m[üu]d[üu]r v\.?|ba[sş]hekim|vali a\.?|vali yard[ıi]mc[ıi]s[ıi])\.?$/i];
    const ONEM = [[/rica ederim|rica olunur/, 3], [/gerekmektedir|gerekti[gğ]i|zorunlu/, 3], [/bildirilmesi|g[öo]nderilmesi|iletilmesi|yap[ıi]lmas[ıi]|sa[gğ]lanmas[ıi]|doldurulmas[ıi]|tamamlanmas[ıi]|teslim/, 2.5],
        [/son g[üu]n|kadar|mesai bitimine|s[üu]resi/, 2], [/talep|istenmektedir|duyurulur|bilgilerinizi|hususunda|bilgilerinize/, 1.5], [/toplant[ıi]|e[gğ]itim|denetim|ba[sş]vuru|ödeme|anket|rapor/, 1]];
    function satirTemiz(t) {
        return String(t || "").replace(/\r/g, "").split(/\n/).map(x => x.replace(/\s+/g, " ").trim()).filter(x => x && !BAS.some(r => r.test(x)) && !/^[\d\s.\/\-:]+$/.test(x) && x.length > 2);
    }
    function sesTemizle(s) {
        const AY = ["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"];
        s = String(s || "").replace(/\b(\d{1,2})[.\/](\d{1,2})[.\/](\d{4})\b/g, (m, g, a) => (+a >= 1 && +a <= 12 && +g >= 1 && +g <= 31) ? (+g) + " " + AY[+a - 1] : m); // 1.0.26: tarih sözle
        return String(s || "").replace(/E-?\s*\d[\d.\-\s]{4,}/g, " ").replace(/\b\d{1,2}[.\/]\d{1,2}[.\/]\d{2,4}\b/g, " ").replace(/\b\d+(?:[.\-]\d+){2,}\b/g, " ")
            .replace(/\d{4,}/g, " ").replace(/\(\s*[a-zçğıöşü]?\s*\)/gi, " ").replace(/\s+([.,;:])/g, "$1").replace(/\s+/g, " ").trim();
    }
    function ozetCikar(metin, n) {
        n = n || 3; let H = String(metin || "").replace(/\r/g, "").split("\n").map(x => x.trim());
        // 1.0.27: gövde = Sayı/Konu başlığından SONRA, ilk Gereği/Bilgi/Dağıtım/Ek satırından ÖNCE
        let bas = -1; H.forEach((x, i) => { if (/^(say[ıi]|konu)\s*:/i.test(x) && i < H.length * 0.6) bas = i; });
        if (bas >= 0) H = H.slice(bas + 1);
        const son = H.findIndex((x, i) => i > 0 && /^(gere[gğ]i|bilgi|da[gğ][ıi]t[ıi]m|ekler?|ek listesi|ek-?\d)\s*(:|\d|$|\()/i.test(x));
        if (son > 0) H = H.slice(0, son);
        let L = satirTemiz(H.join("\n"));
        // imza bloğu: sondan, kısa satırlar (ad/unvan) atılır
        while (L.length && L[L.length - 1].length < 45 && !/[.]$/.test(L[L.length - 1])) L.pop();
        const govde = L.join(" ").replace(/\s+/g, " ");
        let cum = govde.split(/(?<=[.!?])\s+(?=[A-ZÇĞİÖŞÜ0-9"“(])/).map(c => sesTemizle(c)).filter(c => c.length >= 25 && c.split(" ").length >= 4);
        if (!cum.length) return "";
        const P = cum.map((c, i) => { const f = tl(c); let p = 0; ONEM.forEach(([r, w]) => { if (r.test(f)) p += w; }); if (/^ilgi|^ilgide/.test(f)) p += 0.5; p += Math.min(c.length, 220) / 400; if (c.length > 400) p -= 1; return { c, i, p }; });
        const sec = P.slice().sort((a, b) => b.p - a.p).slice(0, Math.min(Math.max(2, n), 4, P.length)).filter((x, k) => k < 2 || x.p >= 1.5).sort((a, b) => a.i - b.i);
        return sec.map(x => x.c.length > 300 ? x.c.slice(0, 297).replace(/\s\S*$/, "") + "…" : x.c).join(" ");
    }
    G.EA_OZET = { ozetCikar, sesTemizle, satirTemiz };
    if (typeof module !== "undefined") module.exports = G.EA_OZET;
})(typeof globalThis !== "undefined" ? globalThis : this);
