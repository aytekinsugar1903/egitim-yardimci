/* © 2026 Eyüp ŞEKER — Evrak Asistanı. Tüm hakları saklıdır. */
// EBYS Otonom Core v3 — sayfa dünyası köprüsü (v3.6.30: + ekPrepare) (manifest: "world": "MAIN", yalnızca üst çerçeve)
// İçerik betiği yalıtılmış dünyada çalışır ve sayfanın window.CKEDITOR / pdf.js (PDFViewerApplication) nesnelerini göremez.
// Müdür Paketi (salt okunur): ping, önizleme pdf.js metni ve ek okuma. Yazma işlemleri (setData, havale seçimi, tıklama) kapalıdır.
// (v3.5.2) Hızlı Seçim penceresindeki bir satırın Gereği/Bilgi düğme bileşenine seçim (sobSet; gönderme düğmelerine dokunmaz).
(function () {
    'use strict';
    if (window.self !== window.top) return;
    if (window.__ebysBridgeLoaded) return;
    window.__ebysBridgeLoaded = true;
    const BRIDGE_ID = "b" + Math.random().toString(36).slice(2); // v3.6.21

    const reply = (id, result) => {
        try { document.dispatchEvent(new CustomEvent("ebys-bridge-res", { detail: JSON.stringify({ id: id, result: result }) })); } catch (e) {}
    };
    const visible = (el) => { try { return !!(el && el.getClientRects().length && getComputedStyle(el).visibility !== "hidden"); } catch (e) { return false; } };
    function ckList() {
        const CK = window.CKEDITOR;
        if (!CK || !CK.instances) return [];
        return Object.keys(CK.instances).map(k => {
            const i = CK.instances[k];
            return { name: k, visible: visible(i && i.container && i.container.$), ready: !i.status || i.status === "ready" };
        });
    }
    function previewFrames() {
        return Array.from(document.querySelectorAll("#mainPreviewForm iframe.onizlemeFrame, iframe.onizlemeFrame")).sort((a, b) => visible(b) - visible(a));
    }
    async function pdfData() {
        for (const f of previewFrames()) {
            let w = null; try { w = f.contentWindow; void w.document; } catch (e) { continue; }
            const app = w && w.PDFViewerApplication; if (!app) continue;
            try { if (app.initializedPromise) await app.initializedPromise; } catch (e) {}
            const doc = app.pdfDocument; if (!doc) continue;
            const d = await doc.getData(); let bin = ""; const C = 0x8000; for (let i = 0; i < d.length; i += C) bin += String.fromCharCode.apply(null, d.subarray(i, i + C));
            return { ok: true, b64: btoa(bin), size: d.length };
        }
        return { ok: false, error: "pdf.js bulunamadı" };
    }
    async function pdfText(maxPages) {
        for (const f of previewFrames()) {
            let w = null;
            try { w = f.contentWindow; void w.document; } catch (e) { continue; }
            const app = w && w.PDFViewerApplication;
            if (!app) continue;
            try { if (app.initializedPromise) await app.initializedPromise; } catch (e) {}
            let doc = app.pdfDocument;
            const t0 = Date.now();
            while (!doc && Date.now() - t0 < 4000) { await new Promise(r => setTimeout(r, 150)); doc = app.pdfDocument; }
            if (!doc) continue;
            const n = Math.min(doc.numPages || 1, maxPages || 4);
            const out = [];
            for (let p = 1; p <= n; p++) {
                const page = await doc.getPage(p);
                const tc = await page.getTextContent();
                let line = "", lastY = null, lastEnd = null;
                for (const it of tc.items) {
                    if (typeof it.str !== "string") continue;
                    const x = it.transform ? it.transform[4] : 0, y = it.transform ? it.transform[5] : 0;
                    if (lastY !== null && Math.abs(y - lastY) > 2) { out.push(line); line = ""; lastEnd = null; }
                    if (lastEnd !== null && x - lastEnd > 1 && line && !/\s$/.test(line) && !/^\s/.test(it.str)) line += " ";
                    line += it.str;
                    lastY = y; lastEnd = x + (it.width || 0);
                    if (it.hasEOL) { out.push(line); line = ""; lastY = null; lastEnd = null; }
                }
                if (line) out.push(line);
                out.push("");
            }
            return { ok: true, text: out.join("\n").replace(/\n{3,}/g, "\n\n").trim(), pages: n };
        }
        return { ok: false, error: "pdf.js bulunamadı" };
    }

    // ===== NEW (v3.6.19): GEREĞİ KAYDEDİCİ — yalnızca PASİF gözlem (asıl işlevler aynen çağrılır, EBYS davranışı değişmez)
    let REC = null;
    const recTxt = (x, n) => String(x == null ? "" : x).replace(/\s+/g, " ").trim().slice(0, n || 200);
    function recLog(t) { if (!REC || REC.done) return; REC.lines.push(((Date.now() - REC.t0) / 1000).toFixed(1) + "s " + t); if (REC.lines.length > 500) REC.lines.splice(0, 50); }
    function recEl(el) {
        if (!el || !el.tagName) return "-";
        return el.tagName.toLowerCase() + (el.id ? "#" + el.id.split(":").slice(-3).join(":") : "") + (typeof el.className === "string" && el.className.trim() ? "." + el.className.trim().split(/\s+/).slice(0, 4).join(".") : "") + (el.children.length < 3 ? ' "' + recTxt(el.textContent, 40) + '"' : "");
    }
    function recPath(el) { const out = []; for (let i = 0; el && i < 6; i++, el = el.parentElement) out.push(recEl(el)); return out.join(" < "); }
    function recHook() {
        const PF = window.PrimeFaces, $ = window.jQuery;
        try {
            const R = PF && PF.ajax && PF.ajax.Request;
            if (R && !R.__ebysRec) {
                R.__ebysRec = true;
                const wrap = (name) => { const o = R[name]; if (typeof o !== "function") return; R[name] = function(cfg) {
                    try { if (REC && cfg) recLog("PF." + name + " s=" + recTxt(cfg.source && (cfg.source.id || cfg.source), 120) + " e=" + recTxt(cfg.event, 30) + " p=" + recTxt(cfg.process, 300) + " u=" + recTxt(cfg.update, 300) + (cfg.params ? " params=" + recTxt(JSON.stringify(cfg.params), 400) : "")); } catch (e) {}
                    return o.apply(this, arguments);
                }; };
                wrap("handle"); if (!R.handle) wrap("send");
            }
        } catch (e) {}
        try {
            if ($ && !document.__ebysRecAjax) {
                document.__ebysRecAjax = true;
                $(document).on("ajaxSend.ebysrec", (ev, xhr, opt) => { if (REC) recLog("XHR gönder " + recTxt(opt && opt.url, 80) + " veri=" + recTxt(decodeURIComponent(String((opt && opt.data) || "")).replace(/javax\.faces\.ViewState=[^&]*/g, "ViewState=…"), 700)); });
                $(document).on("ajaxComplete.ebysrec", (ev, xhr) => {
                    if (!REC) return;
                    const t = String((xhr && xhr.responseText) || "");
                    const ids = (t.match(/<update id="([^"]+)"/g) || []).map(x => x.slice(12, -1).split(":").slice(-2).join(":"));
                    const ev2 = (t.match(/<(eval|extension)[^>]*>([\s\S]*?)<\/\1>/g) || []).join(" ").slice(0, 2000);
                    recLog("XHR yanıt " + (xhr && xhr.status) + " güncellenen=[" + ids.join(", ") + "] " + (ev2 ? "eval/ext=" + recTxt(ev2, 2000) : "") + (/<error/.test(t) ? " HATA=" + recTxt(t.match(/<error[\s\S]*?<\/error>/)[0], 600) : ""));
                    if (/geregiLov:lovTree/.test(t) && !REC.treeResp) { REC.treeResp = true; recLog("AĞAÇ YANITI (ilk 6KB): " + recTxt(t, 6000)); }
                });
                $(document).on("ajaxError.ebysrec", (ev, xhr, opt, err) => { if (REC) recLog("XHR HATA " + (xhr && xhr.status) + " " + recTxt(err, 200)); });
            }
        } catch (e) {}
    }
    const REC_EVENTS = ["mousedown", "mouseup", "click", "dblclick", "keydown"];
    function recOnEvent(e) {
        if (!REC) return;
        const t = e.target;
        if (!t || !t.closest) return;
        if (t.closest("#ebys-inbox-panel, #ebys-stop-btn, #ebys-diag-box")) return; // eklentinin kendi öğeleri
        const inForm = t.closest('[id^="windowCevapEvrak"], .ui-dialog, [id*="Lov"]');
        if (!inForm) return;
        recLog("OLAY " + e.type + (e.isTrusted ? "" : " (yapay)") + " → " + recPath(t));
    }
    function recWidgetInfo() {
        const PF = window.PrimeFaces, out = [];
        try {
            Object.keys((PF && PF.widgets) || {}).forEach(k => {
                const w = PF.widgets[k];
                if (!w || !/gereg/i.test(String(w.id || "") + k)) return;
                const c = w.cfg || {};
                out.push("widget " + k + " id=" + String(w.id).split(":").slice(-2).join(":") + " tür=" + (w.constructor && w.constructor.name) + " cfg=" + Object.keys(c).join(",") + " selectionMode=" + c.selectionMode + " behaviors=" + Object.keys(c.behaviors || {}).join(",") + " propagateSelection=" + c.propagateSelection + " dynamic=" + c.dynamic + " nodeClick=" + (typeof w.nodeClick));
            });
        } catch (e) { out.push("widget hata " + e.message); }
        return out.join("\n");
    }
    function recTick() {
        if (!REC || REC.done) return;
        if (Date.now() - REC.t0 > REC.ms) { recLog("SÜRE DOLDU"); REC.endReason = "süre"; recStop(); return; }
        REC.dumps = REC.dumps || {};
        document.querySelectorAll('[id$="lovTree"], [id$="LovTable"], [id*="geregiLov"][id$="lovDialogId"]').forEach(t => {
            if (!t.id || t.offsetParent === null || getComputedStyle(t).display === "none") return;
            if (!t.querySelector(".ui-treenode, tr[data-ri], tr[data-rk]")) return;
            const sig = t.querySelectorAll(".ui-treenode, tr").length + ":" + recTxt(t.textContent, 120);
            const d = REC.dumps[t.id] || (REC.dumps[t.id] = { sig: "", n: 0 });
            if (d.sig === sig || d.n >= 3) return;
            d.sig = sig; d.n++;
            if (/geregiLov/.test(t.id)) REC.dlgCaptured = true;
            recLog("GÖRÜNÜR LİSTE " + t.id.split(":").slice(-3).join(":") + " — HTML (ilk 8KB): " + recTxt((t.closest(".ui-dialog") || t).outerHTML, 8000));
            recLog("WIDGET: " + recWidgetInfo());
        });
        // v3.6.21: KÖK NEDEN (0,3 sn'de bitme): EBYS'nin önceden çizilmiş GİZLİ uyarı penceresi (visibility:hidden / aria-hidden) "görünür" sayılıyordu.
        // Artık kesin görünürlük + kayıt başında görünür DEĞİLKEN sonradan görünür olması gerekir.
        const strictVis = d => { try { const cs = getComputedStyle(d), r = d.getBoundingClientRect(); return cs.display !== "none" && cs.visibility !== "hidden" && cs.opacity !== "0" && d.getAttribute("aria-hidden") !== "true" && r.width > 0 && r.height > 0; } catch (e) { return false; } };
        // v3.6.23: Cevap Yaz penceresi uyarı sayılmaz — en içteki pencere, 'Lütfen seçim' metni VE görünür 'Direkt Gönder' düğmesi gerekir
        const prmAll = Array.from(document.querySelectorAll(".ui-dialog")).filter(d => !/^windowCevapEvrak/.test(d.id || "") && !d.querySelector(".ui-dialog") && /l[uü]tfen\s+se[cç]im/i.test(d.textContent || "") && Array.from(d.querySelectorAll("button, a, span")).some(b => /direkt\s*g[oö]nder/i.test(b.textContent || "") && strictVis(b)));
        if (!REC.prmInit) { REC.prmInit = new Set(prmAll.filter(strictVis)); if (REC.prmInit.size) recLog("Not: kayıt başında zaten açık uyarı penceresi var (sayılmaz)"); }
        const prm = prmAll.find(d => strictVis(d) && !REC.prmInit.has(d));
        if (prm && !REC.promptSeen) { REC.promptSeen = true; REC.endReason = "uyarı"; recLog("UYARI PENCERESİ GELDİ: " + recTxt(prm.textContent, 300) + " | düğmeler: " + Array.from(prm.querySelectorAll("button")).map(b => recTxt(b.textContent, 40)).join(" / ")); recStop(); return; }
        const bk = document.getElementById("bekleyinizStatusDialog");
        const bkv = !!(bk && bk.offsetParent !== null && getComputedStyle(bk).display !== "none");
        if (bkv !== REC.bk) { REC.bk = bkv; recLog("Lütfen Bekleyiniz " + (bkv ? "AÇILDI" : "kapandı")); }
    }
    function recStart(ms, label) {
        recStop(true);
        REC = { t0: Date.now(), ms: Math.min(120000, ms || 60000), lines: [], done: false, label: label || "", bk: null };
        recHook();
        REC_EVENTS.forEach(t => document.addEventListener(t, recOnEvent, true));
        REC.timer = setInterval(recTick, 300);
        recLog("Kayıt başladı (" + REC.label + ") PF=" + !!window.PrimeFaces + " jQuery=" + !!window.jQuery);
        recLog("WIDGET (başlangıç): " + recWidgetInfo());
    }
    function recStop(silent) {
        if (!REC || REC.done) return;
        REC.done = true; clearInterval(REC.timer);
        REC_EVENTS.forEach(t => document.removeEventListener(t, recOnEvent, true));
        if (!silent) REC.lines.push("Kayıt bitti.");
    }
    document.addEventListener("ebys-bridge-req", async (e) => {
        let req = null;
        try { req = JSON.parse(e.detail); } catch (err) { return; }
        if (!req || typeof req.id !== "string" || typeof req.op !== "string") return;
        let result = { ok: false };
        try {
            const WRITE_OPS = ["sobSet","pfClick","treeSelectSingle","treeNodeClick","ckSetData","direktClick"];
            if (WRITE_OPS.indexOf(req.op) >= 0) {
                result = { ok: false, error: "Müdür Paketi salt okunur: EBYS'de yazma işlemi yok." };
                reply(req.id, result);
                return;
            }
            if (req.op === "ping") {
                const fr = previewFrames()[0];
                let pdf = false; try { pdf = !!(fr && fr.contentWindow && fr.contentWindow.PDFViewerApplication); } catch (er) {}
                result = { ok: true, ck: !!window.CKEDITOR, ckInstances: ckList().map(x => x.name), pdf: pdf };
            } else if (req.op === "sobSet") {
                // NEW (v3.5.2): PrimeFaces SelectOneButton (Kişiye Havale - Hızlı Seçim satırı) — yalnızca verilen bileşende Gereği/Bilgi/Koordine seçer ya da seçimi kaldırır
                const el = document.getElementById(String(req.id || ""));
                if (!el || !el.classList.contains("ui-selectonebutton")) result = { ok: false, error: "bileşen yok" };
                else {
                    const $ = window.jQuery;
                    const btns = Array.from(el.querySelectorAll(":scope > .ui-button"));
                    const want = String(req.value || "");
                    const btn = btns.find(b => { const i = b.querySelector("input"); return i && i.value === want; });
                    const act = btns.find(b => b.classList.contains("ui-state-active"));
                    let w = null;
                    try { const PF = window.PrimeFaces; if (PF && typeof PF.getWidgetById === "function") w = PF.getWidgetById(req.id); if (!w && PF && PF.widgets) w = Object.values(PF.widgets).find(x => x && x.id === req.id) || null; } catch (er) {}
                    if (want && !btn) result = { ok: false, error: "seçenek yok" };
                    else if (w && $ && typeof w.select === "function") { if (want) w.select($(btn)); else if (act && typeof w.unselect === "function") w.unselect($(act)); result = { ok: true, via: "widget" }; }
                    else if ($ && (want ? btn : act)) { $(want ? btn : act).trigger("click"); result = { ok: true, via: "jquery" }; }
                    else result = { ok: false, error: "PrimeFaces yok" };
                }
            } else if (req.op === "pfClick") {
                // NEW (v3.6.10): eklentinin data-ebys-pick ile işaretlediği LoV öğesi / uyarı düğmesi; Onay Akışı (akisLov/akisAdimLov) içindeyse REDDEDİLİR
                const tok = String(req.tok || "").replace(/[^\w-]/g, "");
                let el = null;
                const docs = [document]; document.querySelectorAll("iframe, frame").forEach(f => { try { if (f.contentDocument) docs.push(f.contentDocument); } catch (er) {} });
                for (const d of docs) { el = d.querySelector('[data-ebys-pick="' + tok + '"]'); if (el) break; }
                if (!tok || !el) result = { ok: false, error: "öğe yok" };
                else if (el.closest('[id*="akisLov"], [id*="akisAdimLov"]')) result = { ok: false, error: "Onay Akışı yasak" };
                else {
                    const W = el.ownerDocument.defaultView || window, $ = W.jQuery || window.jQuery;
                    if (req.mode === "widget") {
                        let via = "";
                        const PF = W.PrimeFaces || window.PrimeFaces;
                        if (PF && PF.widgets && $) {
                            for (const w of Object.values(PF.widgets)) {
                                try {
                                    if (!w || !w.jq || !w.jq[0] || !w.jq[0].contains(el)) continue;
                                    const node = $(el).closest("li.ui-treenode, .ui-treenode"), row = $(el).closest("tr[data-ri], tr[data-rk]");
                                    if (node.length && typeof w.selectNode === "function") { w.selectNode(node); if (typeof w.fireNodeSelectEvent === "function") w.fireNodeSelectEvent(node); via = "tree"; break; }
                                    if (row.length && typeof w.selectRow === "function") { w.selectRow(row); via = "table"; break; }
                                } catch (er) {}
                            }
                        }
                        result = { ok: !!via, via: via || "widget yok" };
                    } else if ($) { $(el).trigger("mousedown").trigger("mouseup").trigger("click"); result = { ok: true, via: "jquery" }; }
                    else { el.click(); result = { ok: true, via: "native" }; }
                }
            } else if (req.op === "treeSelectSingle") {
                // NEW (v3.6.20): tekli seçimli PrimeFaces Tree (Gereği: selectionMode=single, behaviors=select) — widget API ile seçim + TEK select olayı
                // v3.6.54: aynı id'li gizli kopyalar yüzünden getElementById yanlış (gizli) ağacı verebiliyordu — önce içerik betiğinin işaretlediği CANLI öğeler
                const tk = String(req.tok || "").replace(/[^a-z0-9]/gi, "");
                const tree = (tk && document.querySelector('[data-ea-pick-tree="' + tk + '"]')) || document.getElementById(String(req.treeId || "")), li = (tk && document.querySelector('[data-ea-pick-li="' + tk + '"]')) || document.getElementById(String(req.liId || ""));
                const $ = window.jQuery, PF = window.PrimeFaces;
                if (!tree || !li || !tree.contains(li)) result = { ok: false, error: "düğüm yok" };
                else if (/akisLov|akisAdimLov/.test(tree.id)) result = { ok: false, error: "Onay Akışı yasak" };
                else {
                    let w = null, wv = "";
                    let stale = "";
                    // v3.6.54: widget'ın jq[0]'ı bu canlı ağaç olmalı; aynı id'li ama başka (gizli/kopuk) öğeye bağlı widget BAYATTIR → kullanılmaz
                    try { Object.keys((PF && PF.widgets) || {}).forEach(k => { const x = PF.widgets[k]; if (!x) return; const jq0 = x.jq && x.jq[0]; if (!w && jq0 === tree) { w = x; wv = k; } }); } catch (er) {}
                    if (!w) { try { Object.keys((PF && PF.widgets) || {}).forEach(k => { const x = PF.widgets[k]; if (!x || w || x.id !== tree.id) return; const jq0 = x.jq && x.jq[0]; if (jq0 && jq0 !== tree) { stale = k; return; } w = x; wv = k; }); } catch (er) {} }
                    if (!w && stale) result = { ok: false, error: "Tree widget bayat (" + stale + ": başka/gizli ağaca bağlı)" };
                    else if (!w || !$) result = { ok: false, error: "Tree widget yok" };
                    else {
                        const via = [], $li = $(li);
                        let fired = 0;
                        const origFire = w.fireNodeSelectEvent;
                        if (typeof origFire === "function") w.fireNodeSelectEvent = function() { fired++; return origFire.apply(this, arguments); };
                        try {
                            if (typeof w.unselectAllNodes === "function") { w.unselectAllNodes(); via.push("unselectAllNodes"); }
                            if (typeof w.selectNode === "function") { w.selectNode($li); via.push("selectNode"); }
                            const sel = document.getElementById(tree.id + "_selection"), rk = li.getAttribute("data-rowkey");
                            if (sel && rk != null && sel.value !== rk && !String(sel.value).split(",").includes(rk)) { sel.value = rk; via.push("seçim girdisi yazıldı"); }
                            if (!fired) {
                                if (typeof origFire === "function") { origFire.call(w, $li); fired++; via.push("fireNodeSelectEvent"); }
                                else if (w.cfg && w.cfg.behaviors && typeof w.cfg.behaviors.select === "function") { w.cfg.behaviors.select.call(w, { params: [{ name: tree.id + "_instanceSelection", value: rk }] }); fired++; via.push("behaviors.select"); }
                            } else via.push("select olayı selectNode içinden");
                        } finally { if (typeof origFire === "function") w.fireNodeSelectEvent = origFire; }
                        result = { ok: fired === 1, via: via.join(" → ") + " (widget " + wv + ", mode=" + (w.cfg && w.cfg.selectionMode) + ", select olayı=" + fired + ")", mode: w.cfg && w.cfg.selectionMode };
                    }
                }
            } else if (req.op === "lovWidgets") {
                // NEW (v3.6.37): Gereği LOV hazırlığı — ilk açılışta PrimeFaces Dialog/Tree widget'ları tembel kuruluyor; sonuç ağacı GİZLİ diyaloğa
                // yazılıp diyalog gösterilmiyordu. Burada: widget var mı (rapor) + istenirse gizli diyaloğu widget.show() ile görünür yap. Seçim/gönderme YOK.
                const PF = window.PrimeFaces, lov = String(req.lovId || ""), out = { dialog: false, tree: false, shown: false, ajaxBusy: false };
                try { out.ajaxBusy = !!(PF && PF.ajax && PF.ajax.Queue && PF.ajax.Queue.isEmpty && !PF.ajax.Queue.isEmpty()) || !!(window.jQuery && window.jQuery.active); } catch (er) {}
                if (lov && !/akisLov|akisAdimLov/.test(lov)) {
                    try {
                        Object.keys((PF && PF.widgets) || {}).forEach(k => {
                            const w = PF.widgets[k], id = String((w && w.id) || "");
                            if (!id.includes(lov)) return;
                            if (/lovDialogId$/.test(id)) {
                                out.dialog = true;
                                const el = document.getElementById(id);
                                if (req.show && el && !visible(el) && el.querySelector(".ui-treenode, tr[data-ri]") && typeof w.show === "function") { w.show(); out.shown = true; }
                            }
                            if (/lovTree$|:lovTree/.test(id)) out.tree = true;
                        });
                    } catch (er) { out.error = String(er && er.message || er); }
                }
                result = out;
            } else if (req.op === "treeNodeClick") {
                // NEW (v3.6.18): PrimeFaces Tree düğümüne insan tıklamasıyla aynı yoldan (widget.nodeClick) TEK tıklama; Onay Akışı reddedilir
                const tree = document.getElementById(String(req.treeId || "")), li = document.getElementById(String(req.liId || ""));
                const content = li && (li.querySelector(":scope > .ui-treenode-content") || li.querySelector(".ui-treenode-content"));
                const $ = window.jQuery, PF = window.PrimeFaces;
                if (!tree || !content || !tree.contains(content)) result = { ok: false, error: "düğüm yok" };
                else if (/akisLov|akisAdimLov/.test(tree.id)) result = { ok: false, error: "Onay Akışı yasak" };
                else {
                    let w = null;
                    try { if (PF && PF.widgets) w = Object.values(PF.widgets).find(x => x && (x.id === tree.id || (x.jq && x.jq[0] === tree))); } catch (er) {}
                    if (w && $ && typeof w.nodeClick === "function") {
                        const ev = $.Event("click", { target: content, currentTarget: content, which: 1, button: 0, metaKey: false, ctrlKey: false, shiftKey: false });
                        w.nodeClick(ev, $(content)); result = { ok: true, via: "nodeClick" };
                    } else if ($) { $(content).trigger("click"); result = { ok: true, via: "jQuery click" }; }
                    else result = { ok: false, error: "PrimeFaces/jQuery yok" };
                }
            } else if (req.op === "ajaxState") { // v3.6.57: PASİF istek izleyici (yalnızca jQuery ajaxSend/ajaxComplete dinler; hiçbir isteğe dokunmaz)
                const W = window;
                if (!W.__eaAjaxW && W.jQuery) {
                    const st = W.__eaAjaxW = { pending: 0, last: Date.now(), log: [], reqs: [], n: 0 };
                    const prm = (d, k) => { const m = d.match(new RegExp("(?:^|&)" + k.replace(/\./g, "\\.") + "=([^&]*)")); try { return m ? decodeURIComponent(m[1].replace(/\+/g, " ")) : ""; } catch (x) { return m ? m[1] : ""; } };
                    const info = (o) => { const d = String((o && o.data) || ""); const src = prm(d, "javax.faces.source"); return { s: src || String((o && o.url) || "?").slice(-40), e: prm(d, "javax.faces.behavior.event"), u: prm(d, "javax.faces.partial.render") }; };
                    W.jQuery(W.document).on("ajaxSend.eaW", function (ev, xhr, o) { st.pending++; st.last = Date.now(); const r = Object.assign({ id: ++st.n, t: Date.now(), end: 0, status: "" }, info(o)); try { o.__eaId = r.id; } catch (x) {} st.reqs.push(r); if (st.reqs.length > 100) st.reqs.shift(); st.log.push({ t: Date.now(), k: "başladı", s: r.s + (r.e ? " e=" + r.e : "") }); if (st.log.length > 200) st.log.shift(); });
                    W.jQuery(W.document).on("ajaxComplete.eaW", function (ev, xhr, o) {
                        st.pending = Math.max(0, st.pending - 1); st.last = Date.now();
                        const r = st.reqs.find(x => x.id === (o && o.__eaId));
                        let kind = "?"; try { const t = String((xhr && xhr.responseText) || ""); kind = /<error>/.test(t) ? "error" : /<redirect/.test(t) ? "redirect" : /<partial-response/.test(t) ? "ok" : (t ? "yanıt" : "boş"); } catch (x) {}
                        if (r) { r.end = Date.now(); r.status = (xhr && xhr.status) + " " + kind; }
                        st.log.push({ t: Date.now(), k: "bitti " + (xhr && xhr.status) + " " + kind, s: r ? r.s + (r.e ? " e=" + r.e : "") : "?" }); if (st.log.length > 200) st.log.shift();
                    });
                }
                const st = W.__eaAjaxW;
                if (!st) result = { ok: false, error: "jQuery yok" };
                else { const since = Number(req.since) || 0, rs = Number(req.reqSince) || 0; result = { ok: true, pending: st.pending, quietMs: Date.now() - st.last, now: Date.now(), log: st.log.filter(x => x.t > since), reqs: rs ? st.reqs.filter(x => x.t >= rs) : [] }; }
            } else if (req.op === "recStart") {
                // v3.6.20: elle kayıt sürerken otomatik kayıt onu EZMEZ
                if (req.ifIdle && REC && !REC.done) result = { ok: true, skipped: true };
                else { recStart(Number(req.ms) || 60000, String(req.label || "")); result = { ok: true, bid: BRIDGE_ID }; }
            } else if (req.op === "recGet") {
                if (req.bid && req.bid !== BRIDGE_ID) return; // başka (eski) köprü örneğinin kaydı değil
                if (req.stop && REC && (!req.label || REC.label === req.label)) recStop();
                result = { ok: true, bid: BRIDGE_ID, done: !!(REC && REC.done), promptSeen: !!(REC && REC.promptSeen), endReason: (REC && REC.endReason) || "", text: REC ? REC.lines.join("\n") : "" };
            } else if (req.op === "ckList") {
                result = { ok: true, list: ckList() };
            } else if (req.op === "ckSetData") {
                const i = window.CKEDITOR && window.CKEDITOR.instances && window.CKEDITOR.instances[req.name];
                if (!i || typeof i.setData !== "function") result = { ok: false, error: "CKEditor örneği yok: " + req.name };
                else {
                    await new Promise(res => {
                        let done = false; const fin = () => { if (!done) { done = true; res(); } };
                        try { i.setData(String(req.html || ""), { callback: fin }); } catch (er) { try { i.setData(String(req.html || "")); } catch (er2) {} }
                        setTimeout(fin, 1500);
                    });
                    try { if (i.updateElement) i.updateElement(); if (i.fire) i.fire("change"); } catch (er) {}
                    result = { ok: true, name: req.name };
                }
            } else if (req.op === "direktState" || req.op === "direktClick") {
                // v3.6.33: dağıtım uyarısındaki "Direkt Gönder" (yalnızca dağıtım kanalı seçimi). Hedef: data-ebys-pick belirteçli, .ui-dialog İÇİNDE, metni "direkt" içeren,
                // "mülki" içermeyen düğme. Ana formdaki Kaydet/Parafla/İmzala/Gönder'e bu işlem dokunamaz.
                const el = document.querySelector('[data-ebys-pick="' + String(req.tok).replace(/"/g, "") + '"]');
                const dlg = el && el.closest(".ui-dialog");
                const tx = el ? (el.textContent || el.value || "").toLocaleLowerCase("tr-TR") : "";
                const PF = window.PrimeFaces, $ = window.jQuery || window.$;
                let qEmpty = true; try { const Q = PF && PF.ajax && PF.ajax.Queue; if (Q) qEmpty = typeof Q.isEmpty === "function" ? Q.isEmpty() : !(Q.requests && Q.requests.length); } catch (er) {}
                let active = 0; try { active = $ && $.active ? $.active : 0; } catch (er) {}
                let wv = null; try { if (PF && PF.widgets && dlg) wv = Object.keys(PF.widgets).find(k => PF.widgets[k] && PF.widgets[k].id === dlg.id) || null; } catch (er) {}
                const okTarget = !!(el && dlg && /direk|doğrudan|dogrudan/.test(tx) && !/mülki|mulki/.test(tx));
                const st = { ok: okTarget, qEmpty: qEmpty, jqActive: active, widget: wv, dlgVisible: !!(dlg && visible(dlg) && dlg.getAttribute("aria-hidden") !== "true"), disabled: !!(el && (el.disabled || el.getAttribute("aria-disabled") === "true" || /ui-state-disabled/.test(el.className || ""))), hasOnclick: !!(el && (el.onclick || el.getAttribute("onclick"))) };
                if (req.op === "direktState" || !okTarget) result = st;
                else {
                    let via = req.strategy;
                    try {
                        if (req.strategy === "onclick") { if (typeof el.onclick === "function") el.onclick.call(el, new MouseEvent("click", { bubbles: true, cancelable: true })); else throw new Error("onclick yok"); }
                        else if (req.strategy === "jq") { if ($) $(el).trigger("click"); else throw new Error("jQuery yok"); }
                        else if (req.strategy === "mouse") {
                            const r = el.getBoundingClientRect(), o = { bubbles: true, cancelable: true, view: window, button: 0, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
                            try { el.dispatchEvent(new PointerEvent("pointerdown", o)); } catch (er) {}
                            el.dispatchEvent(new MouseEvent("mousedown", o)); try { el.focus(); } catch (er) {}
                            try { el.dispatchEvent(new PointerEvent("pointerup", o)); } catch (er) {}
                            el.dispatchEvent(new MouseEvent("mouseup", o)); el.dispatchEvent(new MouseEvent("click", o));
                        } else throw new Error("bilinmeyen yöntem");
                        result = Object.assign(st, { clicked: true, via: via });
                    } catch (er) { result = Object.assign(st, { clicked: false, via: via, error: String(er && er.message || er) }); }
                }
            } else if (req.op === "ekPrepare") {
                // v3.6.30: "Evrak Ekleri" satırındaki İndir düğmesinin PrimeFaces isteğini, iframe'e indirme KOMUTU VERMEDEN çalıştırır
                // (sunucu tarafında dosya seçilir; içerik betiği ardından aynı kökenden dosyaDetayGosterServlet?indir=true&dosya=… adresini okur).
                const btn = document.getElementById(req.btnId);
                const PF = window.PrimeFaces;
                if (!btn || !PF || typeof PF.ab !== "function") result = { ok: false, error: !btn ? "düğme yok" : "PrimeFaces yok" };
                else {
                    const oc = btn.getAttribute("onclick") || "";
                    const s = (oc.match(/s:&quot;([^&]+)&quot;|s:"([^"]+)"/) || []).slice(1).find(Boolean) || btn.id;
                    const f = (oc.match(/f:&quot;([^&]+)&quot;|f:"([^"]+)"/) || []).slice(1).find(Boolean) || (btn.form && btn.form.id) || "mainPreviewForm";
                    result = await new Promise(res => {
                        const t = setTimeout(() => res({ ok: false, error: "zaman aşımı" }), req.timeoutMs || 8000);
                        try { PF.ab({ s: s, f: f, p: s, oncomplete: function (xhr, status, args) { clearTimeout(t); res({ ok: true, status: String(status || ""), show: !!(args && String(args.dosyaDetayGoster) === "true") }); } }); }
                        catch (er) { clearTimeout(t); res({ ok: false, error: String(er) }); }
                    });
                }
            } else if (req.op === "pdfText") {
                result = await pdfText(req.maxPages);
            } else if (req.op === "pdfData") { // v3.6.49: açık önizlemenin PDF baytları (yalnızca okuma; indirme içerik betiğinde)
                result = await pdfData();
            }
        } catch (err) { result = { ok: false, error: String((err && err.message) || err) }; }
        reply(req.id, result);
    });
})();
