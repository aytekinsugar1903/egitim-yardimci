/* Evrak Asistanı — Düzenli Yazılar (Aylık Rapor Takvimi) çekirdeği
 * Saf mantık: dönem / son tarih hesabı, konu eşleştirme, ay kaydırma, aday bulma, şablon eşitleme.
 * content script (periyodik.js), yönetim sayfası (periyodik_sayfa.js) ve arka plan (periyodik_bg.js) ortak kullanır.
 * Veri yalnızca chrome.storage.local içinde tutulur; dışarı hiçbir şey gönderilmez.
 */
(function (root) {
  'use strict';
  if (root.EA_PERIYODIK) return;

  const KEY = 'ebys_periyodik_v1';          // { kartlar:[], ayar:{}, sablonAdlari:{} }
  const ADAY_KEY = 'ebys_periyodik_aday_v1'; // { adaylar:[], yoksay:[], tarama:{} }
  const BILDIRIM_KEY = 'ebys_periyodik_bildirim_v1';
  const TPL_KEY = 'ebys_reply_templates_v2';
  const TPL_META_KEY = 'ebys_tpl_meta_v1';
  const TAKIP_KEY = 'ebys_takip_v1';
  const TEKRAR_KEY = 'ebys_tekrar_v1';
  const PARAF_KEY = 'ebys_paraf_docs_v1';
  const CONSENT_KEY = 'ebys_consent_v1';

  const AYLAR = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
  const PERIYOTLAR = {
    aylik: { ad: 'Her ay', uzunluk: 1 },
    '2aylik': { ad: '2 ayda bir', uzunluk: 2 },
    '3aylik': { ad: '3 ayda bir', uzunluk: 3 },
    '6aylik': { ad: '6 ayda bir', uzunluk: 6 },
    yillik: { ad: 'Yılda bir', uzunluk: 12 },
    donemlik: { ad: 'Dönemlik (seçilen aylar)', uzunluk: 3 }
  };
  // Sabit resmî tatiller (ay-gün). 28 Ekim, Cumhuriyet Bayramı arifesi (13:00'ten yarım gün) — son gün kaydırılır.
  const SABIT_TATIL = ['01-01', '04-23', '05-01', '05-19', '07-15', '08-30', '10-28', '10-29'];
  // Ramazan / Kurban (tam gün) ve arife (13:00'ten yarım gün) 2026–2028.
  // Kaynak: 2429 sayılı Kanun; 2026–2028 tarihleri Diyanet takvimi (2027–2028 ileride bir gün kayabilir).
  const BAYRAM_TATIL = [
    '2026-03-20', '2026-03-21', '2026-03-22',
    '2026-05-27', '2026-05-28', '2026-05-29', '2026-05-30',
    '2027-03-09', '2027-03-10', '2027-03-11',
    '2027-05-16', '2027-05-17', '2027-05-18', '2027-05-19',
    '2028-02-26', '2028-02-27', '2028-02-28',
    '2028-05-05', '2028-05-06', '2028-05-07', '2028-05-08'
  ];
  const ARIFE_TATIL = [
    '2026-03-19', '2026-05-26',
    '2027-03-08', '2027-05-15',
    '2028-02-25', '2028-05-04'
  ];
  const VARSAYILAN_AYAR = { esikler: [5, 3, 1, 0], gecikmeBildir: true, bildirim: true, saat: '09:05', ekTatiller: [] };

  // ---------- yardımcılar ----------
  const pad = n => String(n).padStart(2, '0');
  const isObj = x => x !== null && typeof x === 'object' && !Array.isArray(x);
  const yeniId = () => 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  function bugunIso(ms) {
    try {
      const p = {};
      new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Istanbul', year: 'numeric', month: '2-digit', day: '2-digit' })
        .formatToParts(new Date(ms == null ? Date.now() : ms)).forEach(x => { p[x.type] = x.value; });
      return p.year + '-' + p.month + '-' + p.day;
    } catch (e) {
      const d = new Date((ms == null ? Date.now() : ms) + 3 * 3600e3);
      return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate());
    }
  }
  const isoTarih = (y, m, d) => y + '-' + pad(m) + '-' + pad(d);
  const ayKey = (y, m) => y + '-' + pad(m);
  const ayParcala = k => { const m = String(k || '').match(/^(\d{4})-(\d{2})/); return m ? { y: +m[1], m: +m[2] } : null; };
  const ayEkle = (k, n) => { const p = ayParcala(k); if (!p) return ''; const t = p.y * 12 + (p.m - 1) + n; return ayKey(Math.floor(t / 12), (t % 12) + 1); };
  const ayFark = (a, b) => { const x = ayParcala(a), y = ayParcala(b); return x && y ? (y.y * 12 + y.m) - (x.y * 12 + x.m) : 0; };
  const ayGunSayisi = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
  const utc = iso => { const m = String(iso || '').match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? Date.UTC(+m[1], +m[2] - 1, +m[3]) : NaN; };
  const gunFark = (a, b) => Math.round((utc(b) - utc(a)) / 864e5); // b - a
  const trTarih = iso => { const m = String(iso || '').match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? m[3] + '.' + m[2] + '.' + m[1] : ''; };
  const ayAdi = k => { const p = ayParcala(k); return p ? AYLAR[p.m - 1] + ' ' + p.y : ''; };
  function trDenIso(s) {
    const m = String(s || '').match(/(\d{1,2})[./-](\d{1,2})[./-](\d{4})/);
    if (!m) return '';
    const d = +m[1], mo = +m[2], y = +m[3];
    if (mo < 1 || mo > 12 || d < 1 || d > ayGunSayisi(y, mo)) return '';
    return isoTarih(y, mo, d);
  }

  function isGunu(iso, ekTatiller) {
    const t = utc(iso); if (isNaN(t)) return false;
    const wd = new Date(t).getUTCDay();
    if (wd === 0 || wd === 6) return false;
    const md = iso.slice(5, 10);
    if (SABIT_TATIL.includes(md)) return false;
    if (BAYRAM_TATIL.includes(iso) || ARIFE_TATIL.includes(iso)) return false;
    if (Array.isArray(ekTatiller) && ekTatiller.includes(iso)) return false;
    return true;
  }
  function oncekiIsGunu(iso, ekTatiller) {
    let t = utc(iso);
    for (let i = 0; i < 10; i++) {
      const d = new Date(t), s = isoTarih(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate());
      if (isGunu(s, ekTatiller)) return s;
      t -= 864e5;
    }
    return iso;
  }

  // ---------- metin normalleştirme ----------
  const trKucuk = s => String(s || '').replace(/I/g, 'ı').replace(/İ/g, 'i').toLocaleLowerCase('tr');
  const ASCII = { 'ç': 'c', 'ğ': 'g', 'ı': 'i', 'ö': 'o', 'ş': 's', 'ü': 'u', 'â': 'a', 'î': 'i', 'û': 'u' };
  const asciile = s => s.replace(/[çğıöşüâîû]/g, c => ASCII[c]);
  const AY_ASCII = AYLAR.map(a => asciile(trKucuk(a)));
  const DOLGU = new Set(('ve veya ile için icin ilgili hakkinda hk hk. konu konulu bu su bir olan olarak gibi da de ki ait gore dair uzere ' +
    'sayili tarihli tarih yazi yazisi yazimiz yaziniz ay ayi ayina ayinda aylik donem donemi donemine yili yil ' +
    'mudurlugu mudurlugune mudurlugumuz okulumuz okul baskanligi).').split(/\s+/));

  function konuNormal(s) {
    let t = asciile(trKucuk(s));
    t = t.replace(/\([^)]*\)|\[[^\]]*\]/g, ' ')
      .replace(/e-\d{6,10}[-\w.]*/g, ' ')
      .replace(/\d{1,2}[./-]\d{1,2}[./-]\d{2,4}/g, ' ')
      .replace(/\b(19|20)\d{2}\b/g, ' ')
      .replace(/\d+/g, ' ');
    AY_ASCII.forEach(a => { t = t.replace(new RegExp('\\b' + a + '[a-z]*', 'g'), ' '); });
    t = t.replace(/[^a-z\s]/g, ' ').replace(/\s+/g, ' ').trim();
    return t;
  }
  function kelimeler(s) { return konuNormal(s).split(' ').filter(w => w.length > 1 && !DOLGU.has(w)); }
  function benzerlik(a, b) {
    const A = new Set(kelimeler(a)), B = new Set(kelimeler(b));
    if (!A.size || !B.size) return 0;
    let k = 0; A.forEach(w => { if (B.has(w)) k++; });
    return k / (A.size + B.size - k);
  }
  function anahtarListe(kart) {
    return String(kart.anahtar || '').split(/[,;\n]/).map(x => konuNormal(x)).filter(Boolean);
  }
  /** Bir konu bu karta mı ait? */
  function eslesir(kart, konu) {
    if (!konu) return false;
    const n = ' ' + konuNormal(konu) + ' ';
    const anah = anahtarListe(kart);
    if (anah.length) return anah.every(a => n.includes(' ' + a + ' ') || n.includes(a));
    if (kart.ornekKonu) return benzerlik(kart.ornekKonu, konu) >= 0.6;
    return benzerlik(kart.ad, konu) >= 0.6;
  }

  // ---------- kart / dönem ----------
  function kartTemizle(k) {
    if (!isObj(k)) return null;
    const ad = String(k.ad || '').trim().slice(0, 120);
    if (!ad) return null;
    const periyot = PERIYOTLAR[k.periyot] ? k.periyot : 'aylik';
    let gun = k.gun === 'son' ? 'son' : parseInt(k.gun, 10);
    if (gun !== 'son' && !(gun >= 1 && gun <= 31)) gun = '';
    let aylar = Array.isArray(k.aylar) ? [...new Set(k.aylar.map(Number).filter(x => x >= 1 && x <= 12))].sort((a, b) => a - b) : [];
    if (periyot !== 'aylik' && !aylar.length) aylar = varsayilanAylar(periyot);
    const gonderim = {};
    if (isObj(k.gonderim)) Object.keys(k.gonderim).forEach(p => {
      if (/^\d{4}-\d{2}$/.test(p) && isObj(k.gonderim[p])) {
        const g = k.gonderim[p];
        gonderim[p] = { tarih: /^\d{4}-\d{2}-\d{2}$/.test(g.tarih) ? g.tarih : '', no: String(g.no || '').slice(0, 80), kaynak: g.kaynak === 'tarama' ? 'tarama' : (g.kaynak === 'yok' ? 'yok' : 'elle'), konu: String(g.konu || '').slice(0, 200) };
      }
    });
    return {
      id: /^[\w-]{1,40}$/.test(String(k.id || '')) ? String(k.id) : yeniId(),
      ad,
      anahtar: String(k.anahtar || '').slice(0, 300),
      ornekKonu: String(k.ornekKonu || '').slice(0, 200),
      kime: String(k.kime || '').slice(0, 160),
      periyot, gun, aylar,
      baslangic: /^\d{4}-\d{2}$/.test(k.baslangic) ? k.baslangic : '',
      bitis: /^\d{4}-\d{2}-\d{2}$/.test(k.bitis) ? k.bitis : '',
      konuKodu: String(k.konuKodu || '').slice(0, 30),
      metin: String(k.metin || '').slice(0, 20000),
      metinAy: /^\d{4}-\d{2}$/.test(k.metinAy) ? k.metinAy : '',
      sablonaEkle: k.sablonaEkle !== false,
      not: String(k.not || '').slice(0, 500),
      aktif: k.aktif !== false,
      gonderim,
      eklenme: /^\d{4}-\d{2}-\d{2}$/.test(k.eklenme) ? k.eklenme : bugunIso()
    };
  }
  function varsayilanAylar(periyot) {
    if (periyot === '2aylik') return [2, 4, 6, 8, 10, 12];
    if (periyot === '3aylik') return [1, 4, 7, 10];
    if (periyot === '6aylik') return [1, 7];
    if (periyot === 'yillik') return [1];
    if (periyot === 'donemlik') return [3, 6, 9, 12];
    return [];
  }
  function depoTemizle(d) {
    d = isObj(d) ? d : {};
    const kartlar = [];
    const ids = new Set();
    (Array.isArray(d.kartlar) ? d.kartlar : []).forEach(k => { const c = kartTemizle(k); if (c && !ids.has(c.id)) { ids.add(c.id); kartlar.push(c); } });
    const a = isObj(d.ayar) ? d.ayar : {};
    const ayar = {
      esikler: Array.isArray(a.esikler) ? [...new Set(a.esikler.map(Number).filter(x => x >= 0 && x <= 15))].sort((x, y) => y - x) : VARSAYILAN_AYAR.esikler.slice(),
      gecikmeBildir: a.gecikmeBildir !== false,
      bildirim: a.bildirim !== false,
      saat: /^\d{2}:\d{2}$/.test(a.saat) ? a.saat : VARSAYILAN_AYAR.saat,
      ekTatiller: Array.isArray(a.ekTatiller) ? a.ekTatiller.filter(x => /^\d{4}-\d{2}-\d{2}$/.test(x)).slice(0, 60) : []
    };
    const sablonAdlari = isObj(d.sablonAdlari) ? d.sablonAdlari : {};
    return { kartlar, ayar, sablonAdlari };
  }

  /** Kartın bu ay (YYYY-MM) dönemi var mı? */
  function donemVarMi(kart, p) {
    const x = ayParcala(p); if (!x) return false;
    if (kart.baslangic && ayFark(kart.baslangic, p) < 0) return false;
    if (kart.periyot === 'aylik') return true;
    return kart.aylar.includes(x.m);
  }
  /** Dönemin son tarihi (iş gününe çekilmiş ISO) */
  function sonTarih(kart, p, ekTatiller) {
    const x = ayParcala(p); if (!x || kart.gun === '') return '';
    const son = ayGunSayisi(x.y, x.m);
    const g = kart.gun === 'son' ? son : Math.min(kart.gun, son);
    return oncekiIsGunu(isoTarih(x.y, x.m, g), ekTatiller);
  }
  function oncekiDonem(kart, p) { for (let i = 1; i <= 24; i++) { const q = ayEkle(p, -i); if (donemVarMi(kart, q)) return q; } return ''; }
  function sonrakiDonem(kart, p) { for (let i = 1; i <= 24; i++) { const q = ayEkle(p, i); if (donemVarMi(kart, q)) return q; } return ''; }
  function donemUzunlukGun(kart, p) {
    const o = oncekiDonem(kart, p);
    const u = o ? ayFark(o, p) : (PERIYOTLAR[kart.periyot] || PERIYOTLAR.aylik).uzunluk;
    return Math.max(1, u) * 30;
  }
  /** Gönderilme tarihi (ISO) hangi döneme sayılır? Son tarihten 15 gün sonrasına kadar geç gönderim de aynı döneme sayılır. */
  function donemBul(kart, iso) {
    const k = iso.slice(0, 7);
    for (const p of [ayEkle(k, -1), k, ayEkle(k, 1), ayEkle(k, 2), ayEkle(k, 3), ayEkle(k, 4), ayEkle(k, 5), ayEkle(k, 6), ayEkle(k, 7), ayEkle(k, 8), ayEkle(k, 9), ayEkle(k, 10), ayEkle(k, 11), ayEkle(k, 12)]) {
      if (!donemVarMi(kart, p)) continue;
      const st = kart.gun === '' ? isoTarih(+p.slice(0, 4), +p.slice(5, 7), ayGunSayisi(+p.slice(0, 4), +p.slice(5, 7))) : sonTarih(kart, p);
      const f = gunFark(iso, st); // son tarih - gönderim
      if (f >= -15 && f < donemUzunlukGun(kart, p) - 15) return p;
    }
    return '';
  }
  /** Bir dönemin durumu */
  function durum(kart, p, bugun, ekTatiller, gelen) {
    bugun = bugun || bugunIso();
    const g = kart.gonderim[p];
    let st = sonTarih(kart, p, ekTatiller);
    let gelenBilgi = null;
    if (gelen && gelen.sonTarih) { gelenBilgi = gelen; if (!st || gelen.sonTarih < st) st = gelen.sonTarih; }
    if (g && g.kaynak === 'yok') return { kod: 'yok', etiket: '➖ Bu dönem yok', renk: '#94A3B8', sonTarih: st, gelen: gelenBilgi };
    if (g) return { kod: 'gonderildi', etiket: '✅ Gönderildi' + (g.tarih ? ' (' + trTarih(g.tarih) + ')' : ''), renk: '#22C55E', sonTarih: st, gonderim: g, gelen: gelenBilgi };
    if (kart.bitis && st && st > kart.bitis) return { kod: 'bitti', etiket: '⏹ Süresi bitti', renk: '#94A3B8', sonTarih: st };
    if (!st) return { kod: 'gunyok', etiket: '❔ Son gün girilmemiş', renk: '#FBBF24', sonTarih: '', gelen: gelenBilgi };
    const kalan = gunFark(bugun, st);
    if (kalan < 0) return { kod: 'gecikti', etiket: '🔴 ' + (-kalan) + ' gün gecikti', renk: '#F87171', sonTarih: st, kalan, gelen: gelenBilgi };
    if (kalan === 0) return { kod: 'bugun', etiket: '⏰ Bugün son gün', renk: '#F87171', sonTarih: st, kalan, gelen: gelenBilgi };
    if (kalan <= 3) return { kod: 'yakin', etiket: '⏳ ' + kalan + ' gün kaldı', renk: '#FB923C', sonTarih: st, kalan, gelen: gelenBilgi };
    return { kod: 'bekliyor', etiket: '🕒 ' + kalan + ' gün kaldı', renk: '#93C5FD', sonTarih: st, kalan, gelen: gelenBilgi };
  }
  /** Bugün için "takip edilecek" dönem: bu ayın dönemi; önceki dönem gönderilmediyse o da (gecikmiş) */
  function aktifDonemler(kart, bugun) {
    bugun = bugun || bugunIso();
    const k = bugun.slice(0, 7), sonuc = [];
    const o = oncekiDonem(kart, k);
    if (o && !kart.gonderim[o] && (!kart.baslangic || ayFark(kart.baslangic, o) >= 0) && ayFark(o, k) <= 3) {
      const st = sonTarih(kart, o);
      // Önceki dönem yalnızca o dönemde zaten takip ediliyorduysa "gecikti" sayılır
      // (liste bugün oluşturulduysa geçen ayı gecikmiş göstermeyelim; taramadan gelen geçmiş varsa gösterelim).
      const takipteydi = (kart.eklenme && kart.eklenme < st) || Object.keys(kart.gonderim).some(x => x < o && ayFark(x, o) <= 6);
      if (st && st < bugun && takipteydi && (!kart.bitis || st <= kart.bitis)) sonuc.push(o);
    }
    if (donemVarMi(kart, k)) sonuc.push(k);
    else { const s = sonrakiDonem(kart, k); if (s && ayFark(k, s) <= 1) sonuc.push(s); }
    return sonuc;
  }

  // ---------- gelen evrak (günlü takip) bağlantısı ----------
  function gelenBul(kart, takipStore, p) {
    const items = isObj(takipStore) && Array.isArray(takipStore.items) ? takipStore.items : [];
    let en = null;
    items.forEach(it => {
      if (!it || it.durum === 'tamamlandi' || !it.sonTarih || !eslesir(kart, it.konu)) return;
      if (p && it.sonTarih.slice(0, 7) !== p && donemBul(kart, it.sonTarih) !== p) return;
      if (!en || it.sonTarih < en.sonTarih) en = it;
    });
    return en ? { id: en.id, evrakNo: en.evrakNo || '', sonTarih: en.sonTarih, konu: en.konu } : null;
  }

  // ---------- metindeki ay/tarihleri kaydırma ----------
  const AY_RE = new RegExp('(' + AYLAR.map(a => a + '|' + a.toLocaleUpperCase('tr')).join('|') + ')(?![a-zçğıöşü])(\\s*[\\/.\\-]?\\s*)?((?:19|20)\\d{2})?', 'g');
  function harfDuzeni(ornek, yeni) {
    if (ornek === ornek.toLocaleUpperCase('tr')) return yeni.toLocaleUpperCase('tr');
    return yeni;
  }
  /**
   * Metindeki ay adlarını ve yakın tarihleri delta ay kaydırır.
   * Yalnızca kaynak döneme yakın (kaynak ayın 3 ay öncesi..1 ay sonrası) ay/tarihler kaydırılır; eski ilgi tarihleri (ör. 2023 talimatı) değişmez.
   * Dönen: { metin, degisen:[{eski,yeni}] }
   */
  function ayKaydir(metin, kaynakAy, hedefAy) {
    const delta = kaynakAy && hedefAy ? ayFark(kaynakAy, hedefAy) : 0;
    const degisen = [];
    if (!metin || !delta) return { metin: metin || '', degisen, delta };
    const yakin = k => { const f = ayFark(k, kaynakAy); return f >= -1 && f <= 3; };
    let t = metin.replace(AY_RE, (tam, ad, ayr, yil) => {
      const mi = AYLAR.findIndex(a => a === ad || a.toLocaleUpperCase('tr') === ad);
      if (mi < 0) return tam;
      const kp = ayParcala(kaynakAy);
      let y = yil ? +yil : (mi + 1 <= kp.m + 1 ? kp.y : kp.y - 1);
      const k = ayKey(y, mi + 1);
      if (yil && !yakin(k)) return tam;
      const yeni = ayParcala(ayEkle(k, delta));
      const s = harfDuzeni(ad, AYLAR[yeni.m - 1]) + (yil ? (ayr || ' ') + yeni.y : (ayr || ''));
      if (s !== tam) degisen.push({ eski: tam.trim(), yeni: s.trim() });
      return s;
    });
    t = t.replace(/\b(\d{1,2})([./])(\d{1,2})\2((?:19|20)\d{2})\b/g, (tam, d, ay, m, y) => {
      const k = ayKey(+y, +m);
      if (+m < 1 || +m > 12 || !yakin(k)) return tam;
      const yeni = ayParcala(ayEkle(k, delta));
      const gg = Math.min(+d, ayGunSayisi(yeni.y, yeni.m));
      const s = pad(gg) + ay + pad(yeni.m) + ay + yeni.y;
      if (s !== tam) degisen.push({ eski: tam, yeni: s });
      return s;
    });
    return { metin: t, degisen, delta };
  }
  /** Kartın p dönemi için hazır metni */
  function donemMetni(kart, p) {
    if (!kart.metin) return { metin: '', degisen: [], delta: 0 };
    return ayKaydir(kart.metin, kart.metinAy || oncekiDonem(kart, p) || p, p);
  }

  // ---------- liste taramasından aday bulma ----------
  function yuzdelik(arr, q) { const a = arr.slice().sort((x, y) => x - y); return a[Math.min(a.length - 1, Math.floor(q * (a.length - 1) + 0.5))]; }
  const ORTAK_GUNLER = [1, 3, 5, 7, 10, 15, 20, 25];
  // CİMER, izin, dilekçe gibi arada bir gelen yazılar düzenli sayılmaz.
  const DUZENSIZ_RE = /\b(cimer|bimer|izin|izni|dilekce|dilekcesi|sikayet|sikayeti)\b/;
  function duzensizKonuMu(konu) { return DUZENSIZ_RE.test(konuNormal(konu)); }
  /** Aynı adımla (ay) en uzun ardışık dönem zinciri. Aylık için 3 = üç ay üst üste. */
  function enUzunArdisik(aylar, adim) {
    const set = new Set(aylar);
    let en = 1;
    aylar.forEach(a => {
      let n = 1, k = a;
      while (set.has(ayEkle(k, adim))) { k = ayEkle(k, adim); n++; }
      if (n > en) en = n;
    });
    return en;
  }
  /**
   * satirlar: [{konu, tarih(ISO), yer, no}]
   * Dönen: [{ad, ornekKonu, anahtar, kime, periyot, gun, aylar, adet, aySayisi, ilk, son, ornekler:[...], no}]
   */
  function adayBul(satirlar, mevcutKartlar) {
    const gruplar = new Map();
    (satirlar || []).forEach(s => {
      if (!s || !s.konu || !s.tarih) return;
      const n = kelimeler(s.konu).join(' ');
      if (!n || n.length < 4) return;
      let g = gruplar.get(n);
      if (!g) {
        // yakın grup var mı?
        for (const [k, v] of gruplar) { if (benzerlik(k, n) >= 0.75) { g = v; break; } }
        if (!g) { g = { anahtarN: n, satirlar: [] }; gruplar.set(n, g); }
      }
      g.satirlar.push(s);
    });
    const sonuc = [];
    gruplar.forEach(g => {
      const aylar = [...new Set(g.satirlar.map(s => s.tarih.slice(0, 7)))].sort();
      if (aylar.length < 3) return;
      const farklar = [];
      for (let i = 1; i < aylar.length; i++) farklar.push(ayFark(aylar[i - 1], aylar[i]));
      const med = yuzdelik(farklar, 0.5);
      let periyot = 'aylik';
      if (med >= 10) periyot = 'yillik'; else if (med >= 5) periyot = '6aylik'; else if (med >= 3) periyot = '3aylik'; else if (med === 2) periyot = '2aylik';
      // Düzenlilik: en az 3 ardışık dönem, düşük sapma, bilinen düzensiz konular elenir.
      if (g.satirlar.some(s => duzensizKonuMu(s.konu)) || duzensizKonuMu(g.anahtarN)) return;
      const uz = PERIYOTLAR[periyot].uzunluk;
      const beklenen = Math.floor(ayFark(aylar[0], aylar[aylar.length - 1]) / uz) + 1;
      if (g.satirlar.length / aylar.length > 1.6) return;
      if (beklenen && aylar.length / beklenen < 0.7) return;
      if (enUzunArdisik(aylar, uz) < 3) return;
      const sapma = farklar.filter(f => Math.abs(f - med) > Math.max(1, Math.round(med * 0.34))).length;
      if (farklar.length >= 2 && sapma / farklar.length > 0.25) return;
      // son 12 ayda en az 3 kez gönderilmemişse (aylık iddiası için) yine de öner ama düşük güven
      const gunler = g.satirlar.map(s => +s.tarih.slice(8, 10));
      const g75 = yuzdelik(gunler, 0.8);
      const gun = g75 >= 26 ? 'son' : (ORTAK_GUNLER.find(x => x >= g75) || 'son');
      const ayOn = periyot === 'aylik' ? [] : [...new Set(aylar.map(a => +a.slice(5, 7)))].sort((a, b) => a - b);
      const yerSay = {};
      g.satirlar.forEach(s => { if (s.yer) yerSay[s.yer] = (yerSay[s.yer] || 0) + 1; });
      const kime = Object.keys(yerSay).sort((a, b) => yerSay[b] - yerSay[a])[0] || '';
      const ornek = g.satirlar.slice().sort((a, b) => b.tarih.localeCompare(a.tarih));
      const ad = temizBaslik(ornek[0].konu);
      const zatenVar = (mevcutKartlar || []).some(k => ornek.slice(0, 5).some(s => eslesir(k, s.konu)));
      const son12 = aylar.filter(a => ayFark(a, bugunIso().slice(0, 7)) <= 12).length;
      sonuc.push({
        id: 'a' + Math.abs(hash(g.anahtarN)).toString(36),
        ad, ornekKonu: ornek[0].konu, anahtar: '', kime, periyot, gun,
        aylar: periyot === 'aylik' ? [] : ayOn,
        adet: g.satirlar.length, aySayisi: aylar.length, son12,
        ilk: aylar[0], son: aylar[aylar.length - 1],
        ornekler: ornek.slice(0, 40).map(s => ({ konu: s.konu, tarih: s.tarih, no: s.no || '', yer: s.yer || '' })),
        zatenVar,
        guven: son12 >= 6 || aylar.length >= 8 ? 'yuksek' : 'orta'
      });
    });
    return sonuc.sort((a, b) => (b.son12 - a.son12) || (b.aySayisi - a.aySayisi));
  }
  function temizBaslik(konu) {
    let t = String(konu || '').replace(/\([^)]*\)/g, ' ')
      .replace(new RegExp('\\b(' + AYLAR.join('|') + '|' + AYLAR.map(a => a.toLocaleUpperCase('tr')).join('|') + ')\\b[\\s/.-]*((19|20)\\d{2})?', 'g'), ' ')
      .replace(/\b(19|20)\d{2}\b/g, ' ').replace(/\d{1,2}[./-]\d{1,2}[./-]\d{2,4}/g, ' ')
      .replace(/\s+(ayı|ayına|ayına ait|dönemi)\b/gi, ' ')
      .replace(/\s+/g, ' ').replace(/^[\s\-–:.,]+|[\s\-–:.,]+$/g, '').trim();
    return (t || String(konu || '')).slice(0, 120);
  }
  function hash(s) { let h = 0x811c9dc5; for (const c of String(s)) { h ^= c.codePointAt(0); h = Math.imul(h, 0x1000193); } return h | 0; }

  /** Mevcut tekrarlı kurallardan (ebys_tekrar_v1) aday üret */
  function tekrarAdaylari(tekrar) {
    const r = isObj(tekrar) && Array.isArray(tekrar.rules) ? tekrar.rules : [];
    const out = [];
    r.forEach(x => {
      if (!x || !x.konu || !isObj(x.rule)) return;
      const rule = x.rule;
      if (Number.isInteger(rule.weekday)) return; // haftalık → bu modülün konusu değil
      let periyot = 'aylik', aylar = [], gun = '';
      if (Array.isArray(rule.days) && rule.days.length) gun = Math.max(...rule.days.map(Number).filter(n => n >= 1 && n <= 31)) || '';
      if (Array.isArray(rule.endMonths) && rule.endMonths.length) { periyot = 'donemlik'; aylar = rule.endMonths.map(Number); if (!gun) gun = 'son'; }
      out.push({
        id: 't' + Math.abs(hash(x.id + x.konu)).toString(36), kaynak: 'tekrar',
        ad: temizBaslik(x.konu), ornekKonu: x.konu, anahtar: '', kime: '', periyot, gun, aylar,
        bitis: /^\d{4}-\d{2}-\d{2}$/.test(rule.until || '') ? rule.until : '',
        adet: 0, aySayisi: 0, ornekler: [], guven: 'yuksek'
      });
    });
    return out;
  }

  // ---------- tarama sonucunu kartlara işleme ----------
  /** satirlar içinde kartlara uyanları bulup gonderim'e yazar. Dönen: işaretlenen sayısı */
  function gonderimleriIsle(depo, satirlar) {
    let n = 0;
    depo.kartlar.forEach(k => {
      (satirlar || []).forEach(s => {
        if (!s.tarih || !eslesir(k, s.konu)) return;
        const p = donemBul(k, s.tarih);
        if (!p || k.gonderim[p]) return;
        k.gonderim[p] = { tarih: s.tarih, no: s.no || '', kaynak: 'tarama', konu: s.konu.slice(0, 200) };
        n++;
      });
    });
    return n;
  }
  /** Kart için Parafladıklarım önbelleğinden (ebys_paraf_docs_v1) en uygun metni bul */
  function parafMetniBul(kart, paraf, ornekler) {
    if (!isObj(paraf)) return null;
    // 1) evrak numarasıyla birebir
    for (const o of (ornekler || [])) {
      if (o.no && paraf[o.no] && paraf[o.no].b && paraf[o.no].b.length >= 40) return { metin: paraf[o.no].b, ay: donemBul(kart, o.tarih) || o.tarih.slice(0, 7), no: o.no };
    }
    // 2) konu eşleşmesi (en yeni okunan)
    let en = null;
    Object.keys(paraf).forEach(key => {
      const d = paraf[key];
      if (!d || !d.b || d.b.length < 40 || !eslesir(kart, d.k)) return;
      if (!en || (d.at || 0) > (en.at || 0)) en = Object.assign({ key }, d);
    });
    return en ? { metin: en.b, ay: '', no: en.key } : null;
  }

  // ---------- şablon eşitleme (Kendi Şablonlarım'a) ----------
  /** templates & meta nesnelerini yerinde günceller. Dönen: {degisti:boolean} */
  function sablonEsitle(depo, templates, meta, bugun) {
    bugun = bugun || bugunIso();
    let degisti = false;
    const sahip = depo.sablonAdlari || (depo.sablonAdlari = {});
    const aktifIdler = new Set();
    depo.kartlar.forEach(k => {
      if (!k.aktif || !k.sablonaEkle || !k.metin) return;
      aktifIdler.add(k.id);
      const p = aktifDonemler(k, bugun).slice(-1)[0] || bugun.slice(0, 7);
      const metin = donemMetni(k, p).metin;
      let ad = sahip[k.id];
      if (!ad || (templates[ad] !== undefined && !sahipMi(sahip, ad, k.id) )) ad = null;
      if (!ad) {
        ad = k.ad;
        if (templates[ad] !== undefined && !Object.values(sahip).includes(ad)) ad = k.ad + ' (düzenli)';
        let i = 2; while (templates[ad] !== undefined && !Object.values(sahip).includes(ad)) ad = k.ad + ' (düzenli ' + (i++) + ')';
        sahip[k.id] = ad; degisti = true;
      }
      if (templates[ad] !== metin) { templates[ad] = metin; degisti = true; }
      if (meta && !meta[ad]) { meta[ad] = { ogr: true, konular: [k.ornekKonu || k.ad].slice(0, 8), adet: 1 }; degisti = true; }
    });
    // silinen / pasif kartların şablonlarını kaldır (yalnız bizim oluşturduklarımız)
    Object.keys(sahip).forEach(id => {
      if (aktifIdler.has(id)) return;
      const ad = sahip[id];
      if (ad && templates[ad] !== undefined) { delete templates[ad]; if (meta && meta[ad]) delete meta[ad]; degisti = true; }
      delete sahip[id]; degisti = true;
    });
    return { degisti };
  }
  function sahipMi(sahip, ad, id) { return sahip[id] === ad; }

  // ---------- chrome.storage yardımcıları ----------
  const hasStorage = () => typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
  function oku(keys) { return new Promise(r => { if (!hasStorage()) return r({}); try { chrome.storage.local.get(keys, x => r(x || {})); } catch (e) { r({}); } }); }
  function yaz(obj) { return new Promise(r => { if (!hasStorage()) return r(); try { chrome.storage.local.set(obj, () => r()); } catch (e) { r(); } }); }
  async function onayVarMi() { const x = await oku([CONSENT_KEY]); const c = x[CONSENT_KEY]; return !!(c && c.accepted === true); }
  /** Eski sürümlerdeki sabit öneri kayıtlarını (kimliği "h-" ile başlayan) sessizce temizler. Kullanıcının eklediği kartlar korunur. */
  async function eskiHazirTemizle() {
    const x = await oku([KEY, ADAY_KEY]);
    const yaz_ = {};
    const hz = v => /^h-/.test(String(isObj(v) ? v.id : (v || '')));
    const d = x[KEY];
    if (isObj(d) && Array.isArray(d.kartlar)) {
      const kalan = d.kartlar.filter(k => !hz(k));
      if (kalan.length !== d.kartlar.length) yaz_[KEY] = Object.assign({}, d, { kartlar: kalan });
    }
    const a = x[ADAY_KEY];
    if (isObj(a)) {
      const ys = Array.isArray(a.yoksay) ? a.yoksay.filter(v => !hz(v)) : a.yoksay;
      const ad = Array.isArray(a.adaylar) ? a.adaylar.filter(v => !hz(v) && !(isObj(v) && v.kaynak === 'hazir')) : a.adaylar;
      if ((Array.isArray(a.yoksay) && ys.length !== a.yoksay.length) || (Array.isArray(a.adaylar) && ad.length !== a.adaylar.length)) yaz_[ADAY_KEY] = Object.assign({}, a, { yoksay: ys, adaylar: ad });
    }
    if (Object.keys(yaz_).length) await yaz(yaz_);
    return Object.keys(yaz_);
  }
  async function depoOku() { const x = await oku([KEY]); return depoTemizle(x[KEY]); }
  async function depoYaz(depo) { await yaz({ [KEY]: depoTemizle(depo) }); }
  /** Depoyu yazar ve şablonları eşitler */
  async function kaydetVeEsitle(depo) {
    depo = depoTemizle(depo);
    const x = await oku([TPL_KEY, TPL_META_KEY]);
    const tpl = isObj(x[TPL_KEY]) ? x[TPL_KEY] : {};
    const meta = isObj(x[TPL_META_KEY]) ? x[TPL_META_KEY] : {};
    const tplOk = Object.values(tpl).every(v => typeof v === 'string');
    const r = tplOk ? sablonEsitle(depo, tpl, meta) : { degisti: false };
    const yazilacak = { [KEY]: depo };
    if (r.degisti) { yazilacak[TPL_KEY] = tpl; yazilacak[TPL_META_KEY] = meta; }
    await yaz(yazilacak);
    return depo;
  }

  // ---------- dışa aktarma ----------
  function csvHucre(v) { let s = String(v == null ? '' : v); if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+$/.test(s)) s = "'" + s; return /[";\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
  function cizelgeCsv(depo, yil, bugun) {
    const bas = ['Yazı', 'Kime', 'Periyot', 'Son gün'].concat(AYLAR);
    const rows = [bas];
    depo.kartlar.forEach(k => {
      const r = [k.ad, k.kime, PERIYOTLAR[k.periyot].ad, k.gun === 'son' ? 'Ay sonu' : (k.gun ? 'Ayın ' + k.gun + "'i" : '')];
      for (let m = 1; m <= 12; m++) {
        const p = ayKey(yil, m);
        if (!donemVarMi(k, p)) { r.push(''); continue; }
        const d = durum(k, p, bugun, depo.ayar.ekTatiller);
        r.push(d.kod === 'gonderildi' ? 'Gönderildi ' + trTarih(d.gonderim.tarih) + (d.gonderim.no ? ' ' + d.gonderim.no : '') : d.kod === 'gecikti' ? 'GÖNDERİLMEDİ' : d.kod === 'yok' ? 'Yok' : (p > bugun.slice(0, 7) ? '' : d.etiket.replace(/^[^\wÇĞİÖŞÜçğıöşü]+/, '')));
      }
      rows.push(r);
    });
    return '﻿' + rows.map(r => r.map(csvHucre).join(';')).join('\r\n') + '\r\n';
  }

  root.EA_PERIYODIK = {
    KEY, ADAY_KEY, BILDIRIM_KEY, TPL_KEY, TPL_META_KEY, TAKIP_KEY, TEKRAR_KEY, PARAF_KEY, CONSENT_KEY,
    AYLAR, PERIYOTLAR, VARSAYILAN_AYAR,
    pad, bugunIso, ayKey, ayParcala, ayEkle, ayFark, ayAdi, trTarih, trDenIso, gunFark, isGunu, oncekiIsGunu,
    konuNormal, kelimeler, benzerlik, eslesir, temizBaslik, duzensizKonuMu, enUzunArdisik, BAYRAM_TATIL, ARIFE_TATIL, SABIT_TATIL,
    kartTemizle, depoTemizle, varsayilanAylar, donemVarMi, sonTarih, oncekiDonem, sonrakiDonem, donemBul, durum, aktifDonemler,
    gelenBul, ayKaydir, donemMetni, adayBul, tekrarAdaylari, gonderimleriIsle, parafMetniBul, sablonEsitle,
    oku, yaz, onayVarMi, eskiHazirTemizle, depoOku, depoYaz, kaydetVeEsitle, cizelgeCsv, csvHucre, yeniId
  };
})(typeof self !== 'undefined' ? self : (typeof window !== 'undefined' ? window : globalThis));
