/* © 2026 Eyüp ŞEKER — uzantı sayfaları: lisans/deneme yoksa lisans ekranına yönlendirir. */
(function () {
  'use strict';
  var de = document.documentElement; de.style.visibility = 'hidden';
  function ac() { de.style.visibility = ''; }
  try {
    chrome.runtime.sendMessage({ type: 'ea-lisans', op: 'durum' }, function (d) {
      if (chrome.runtime.lastError || !d) { ac(); return; }
      if (d.izin) { ac(); return; }
      location.replace(chrome.runtime.getURL('lisans/lisans.html') + '?geri=' + encodeURIComponent(location.href));
    });
  } catch (e) { ac(); }
})();
