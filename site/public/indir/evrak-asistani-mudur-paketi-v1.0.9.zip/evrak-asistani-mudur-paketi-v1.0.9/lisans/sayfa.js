/* lisans.html: ortak lisans ekranını sayfa kipinde açar; değişince arka plana bildirir. */
(function () {
  'use strict';
  var A = self.EA_LISANS_AYAR = self.EA_LISANS_AYAR || {};
  A.mod = 'sayfa';
  var geri = new URLSearchParams(location.search).get('geri');
  if (geri && geri.indexOf(chrome.runtime.getURL('')) !== 0) geri = null;
  A.hazirMetin = 'Hazır. ' + (A.hazirMetin || 'Çalıştığınız sayfayı yenileyin.');
  A.degisti = function (d) {
    chrome.runtime.sendMessage({ type: 'ea-lisans', op: 'degisti' }, function () { void chrome.runtime.lastError; });
    if (d && d.izin && geri) setTimeout(function () { location.replace(geri); }, 1200);
  };
})();
