/* © 2026 Eyüp ŞEKER — Evrak Asistanı uzantı lisans kapısı (MV3 service worker).
   İçerik betikleri yalnız lisans/deneme geçerliyken kaydedilir (chrome.scripting); süre bitince kaydı kaldırılır.
   Sonra ürünün kendi arka plan betiği değiştirilmeden yüklenir. */
importScripts('ayar.js', 'ea-lisans.js', 'icerik.js');
(function () {
  'use strict';
  var L = self.EA_LISANS, A = self.EA_LISANS_AYAR || {}, ICERIK = self.EA_ICERIK || [];
  var SAYFA = chrome.runtime.getURL('lisans/lisans.html');
  var sira = Promise.resolve();
  function kayitliIdler() {
    return chrome.scripting.getRegisteredContentScripts().then(function (l) { return l.map(function (s) { return s.id; }); }, function () { return []; });
  }
  async function uygula0(d, zorla) {
    d = d || await L.durum();
    var bizim = ICERIK.map(function (x) { return x.id; });
    var ids = await kayitliIdler(), degisti = false;
    var eski = bizim.filter(function (i) { return ids.indexOf(i) >= 0; });
    if (eski.length && (zorla || !d.izin)) { await chrome.scripting.unregisterContentScripts({ ids: eski }); degisti = !d.izin; ids = []; }
    if (d.izin) {
      var eksik = ICERIK.filter(function (x) { return ids.indexOf(x.id) < 0; });
      if (eksik.length) { await chrome.scripting.registerContentScripts(eksik); degisti = true; }
      if (d.bit) chrome.alarms.create('ea-lisans-bitis', { when: Math.max(Date.now() + 60000, +d.bit + 1000) });
    }
    d.yenidenYukle = !!(degisti && d.izin);
    return d;
  }
  function uygula(d, zorla) { var p = sira.then(function () { return uygula0(d, zorla); }); sira = p.catch(function () {}); return p; }
  function bakimUygula(zorla) { return L.bakim().catch(function () { return L.durum(); }).then(function (d) { return uygula(d, zorla); }); }
  function sayfaAc() { chrome.tabs.create({ url: SAYFA }); }
  self.EA_LISANS_KAPI = { uygula: uygula, sayfaAc: sayfaAc };

  chrome.runtime.onInstalled.addListener(function (r) {
    bakimUygula(true).then(function (d) { if (!d.izin && r && (r.reason === 'install' || r.reason === 'update')) sayfaAc(); }, function () {});
  });
  chrome.runtime.onStartup.addListener(function () { bakimUygula(false).catch(function () {}); });
  chrome.alarms.create('ea-lisans-yenile', { delayInMinutes: 1, periodInMinutes: 60 });
  chrome.alarms.onAlarm.addListener(function (a) {
    if (a && (a.name === 'ea-lisans-yenile' || a.name === 'ea-lisans-bitis')) bakimUygula(false).catch(function () {});
  });
  if (A.simgeAc) chrome.action.onClicked.addListener(function () { L.durum().then(function (d) { if (!d.izin) sayfaAc(); }); });
  chrome.runtime.onMessage.addListener(function (m, s, cevap) {
    if (!m || m.type !== 'ea-lisans' || !s || s.id !== chrome.runtime.id) return;
    (async function () {
      if (m.op === 'ac') { sayfaAc(); return { ok: 1 }; }
      return uygula(null, false);
    })().then(cevap, function (e) { cevap({ izin: false, mesaj: String(e) }); });
    return true;
  });
  L.durum().then(function (d) { return uygula(d, false); }).catch(function () {});
})();

// Ürünün kendi arka plan betiği (değiştirilmedi)
importScripts('../background.js');

// v1.0.8: Düzenli Yazılar (EBYS 3.7.1'den) — yalnız yerel bildirim; background.js'e dokunmaz
try { importScripts('../periyodik_core.js', '../periyodik_bg.js'); } catch (e) { console.warn('[Evrak Asistanı] Düzenli Yazılar yüklenemedi', e); }
