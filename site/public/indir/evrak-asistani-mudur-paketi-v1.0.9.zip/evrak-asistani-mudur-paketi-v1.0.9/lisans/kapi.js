/* © 2026 Eyüp ŞEKER — lisans/deneme yoksa sayfada küçük bir uyarı gösterir; ürün betikleri bu durumda yüklenmez. Veri okumaz. */
(function () {
  'use strict';
  if (window.top !== window || document.getElementById('ea-lisans-uyari')) return;
  function kutu(metin, dugme, fn) {
    var h = document.createElement('div'); h.id = 'ea-lisans-uyari';
    var k = h.attachShadow({ mode: 'closed' });
    var st = document.createElement('style');
    st.textContent = '.k{position:fixed;right:14px;bottom:14px;z-index:2147483647;max-width:360px;background:#fff;color:#1a1a1a;border:1px solid #c6d4f5;border-left:4px solid #0d47a1;border-radius:10px;box-shadow:0 6px 24px #0003;padding:12px 14px;font:14px/1.4 system-ui,Segoe UI,sans-serif}button{margin-top:8px;padding:7px 12px;border:0;border-radius:7px;background:#0d47a1;color:#fff;font-weight:700;cursor:pointer}.x{float:right;background:none;color:#555;margin:0;padding:0 4px}';
    var d = document.createElement('div'); d.className = 'k';
    var x = document.createElement('button'); x.className = 'x'; x.textContent = '×'; x.title = 'Kapat'; x.onclick = function () { h.remove(); };
    var p = document.createElement('div'); p.textContent = metin;
    var b = document.createElement('button'); b.textContent = dugme; b.onclick = fn;
    d.append(x, p, b); k.append(st, d); (document.body || document.documentElement).appendChild(h);
  }
  try {
    chrome.runtime.sendMessage({ type: 'ea-lisans', op: 'durum' }, function (d) {
      if (chrome.runtime.lastError || !d) return;
      if (d.izin) { if (d.yenidenYukle) kutu((d.ad || 'Evrak Asistanı') + ': ' + d.mesaj + ' Özelliklerin bu sayfada açılması için sayfayı yenileyin.', 'Sayfayı yenile', function () { location.reload(); }); return; }
      kutu((d.ad || 'Evrak Asistanı') + ': ' + (d.mesaj || 'Lisans gerekli.'), 'Lisans / deneme ekranını aç', function () { chrome.runtime.sendMessage({ type: 'ea-lisans', op: 'ac' }); });
    });
  } catch (e) {}
})();
