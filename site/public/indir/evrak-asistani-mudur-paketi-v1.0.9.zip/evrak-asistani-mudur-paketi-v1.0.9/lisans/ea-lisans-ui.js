/* © 2026 Eyüp ŞEKER — Evrak Asistanı ortak lisans ekranı. İlk açılışta kurum kodu + lisans sözleşmesi + KVKK onayı.
   mod 'kilit': izin yoksa sayfa içeriğini gizler (Okul Paketi). mod 'sayfa': uzantının lisans.html sayfası. Öğrenci verisi sunucuya gitmez. */
(function (root) {
  'use strict';
  if (typeof document === 'undefined' || !root.EA_LISANS) return;
  var L = root.EA_LISANS, A = root.EA_LISANS_AYAR || {}, MOD = A.mod || 'kilit';
  var KVKK = 'https://otonomevrak.com/yasal/kvkk-ve-sorumluluk', KOSUL = 'https://otonomevrak.com/yasal/lisans-kosullari', SATIN = 'https://otonomevrak.com/fiyatlar/';

  function el(t, a, c) {
    var e = document.createElement(t); a = a || {};
    Object.keys(a).forEach(function (k) {
      if (a[k] == null) return;
      if (k === 'text') e.textContent = a[k]; else e.setAttribute(k, a[k]);
    });
    (c || []).forEach(function (x) { if (x != null) e.appendChild(typeof x === 'string' ? document.createTextNode(x) : x); });
    return e;
  }
  function $(id) { return document.getElementById(id); }
  function mesaj(d, ek) {
    var m = (d && d.mesaj) || '';
    if (ek) m = ek + (m ? ' — ' + m : '');
    if (d && d.sonHata && d.sonHata !== ek) m += (m ? ' ' : '') + d.sonHata;
    return m;
  }
  function kilit(acik) {
    if (MOD !== 'kilit') return;
    document.documentElement.classList.toggle('ea-lisans-kilit', !acik);
    var ov = $('eaLisans'); if (ov) ov.hidden = !!acik;
    var r = $('eaLisansRozet'); if (r) r.hidden = !acik;
  }
  async function boya(d, hata) {
    d = d || await L.durum();
    var s = $('eaLisansDurum');
    if (s) { s.textContent = mesaj(d, hata); s.dataset.durum = d.durum || ''; }
    var kk = $('eaKurumKodu'); if (kk && d.kk && !kk.value) kk.value = d.kk;
    var soz = $('eaSozlesme'); if (soz && d.sozlesme) soz.checked = true;
    var r = $('eaLisansRozet');
    if (r) { r.textContent = d.durum === 'deneme' ? 'Deneme' : 'Lisans'; r.title = d.mesaj || ''; }
    var hazir = $('eaHazir'); if (hazir) hazir.hidden = !(MOD === 'sayfa' && d.izin);
    kilit(!!d.izin);
    if (typeof A.degisti === 'function') { try { A.degisti(d); } catch (e) {} }
    return d;
  }
  function ekranKur() {
    if ($('eaLisans')) return;
    var st = document.createElement('style');
    st.textContent = 'html.ea-lisans-kilit body>*:not(#eaLisans){visibility:hidden!important}'
      + '#eaLisans{position:fixed;inset:0;z-index:2147483646;background:#f4f1ea;color:#1a1a1a;overflow:auto;font:16px/1.45 system-ui,Segoe UI,sans-serif;visibility:visible!important}'
      + (MOD === 'sayfa' ? '#eaLisans{position:static;min-height:100vh}' : '')
      + '#eaLisans .kutu{max-width:460px;margin:6vh auto;padding:24px;background:#fff;border-radius:14px;box-shadow:0 8px 32px #0002}'
      + '#eaLisans h1{font-size:22px;margin:0 0 4px;color:#0d47a1}#eaLisans .alt{color:#555;font-size:13px;margin:6px 0 14px}'
      + '#eaLisans label{display:block;margin:10px 0 4px;font-weight:600}#eaLisans label.onay{font-weight:400;display:flex;gap:8px;align-items:flex-start}'
      + '#eaLisans input[type=text]{width:100%;box-sizing:border-box;padding:10px;font:inherit;border:1px solid #ccc;border-radius:8px}'
      + '#eaLisans .satir{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}'
      + '#eaLisans button{padding:10px 14px;border:0;border-radius:8px;background:#0d47a1;color:#fff;font-weight:700;cursor:pointer}#eaLisans button.sec{background:#ece8df;color:#1a1a1a}'
      + '#eaLisans .durum{margin-top:14px;padding:10px;border-radius:8px;background:#eef3fb;font-size:14px}'
      + '#eaLisans .durum[data-durum=bitti],#eaLisans .durum[data-durum=gecersiz],#eaLisans .durum[data-durum=cevrimdisi]{background:#fdecea;color:#7a1f16}'
      + '#eaHazir{margin-top:12px;padding:10px;border-radius:8px;background:#e7f6ec;color:#14532d;font-weight:600}'
      + '#eaLisansRozet{position:fixed;right:10px;bottom:10px;z-index:2147483645;font:700 12px system-ui,sans-serif;padding:4px 10px;border-radius:999px;background:#e8f0fe;color:#0d47a1;border:1px solid #c6d4f5;cursor:pointer}';
    document.head.appendChild(st);
    if (MOD === 'kilit') document.documentElement.classList.add('ea-lisans-kilit');
    var ov = el('div', { id: 'eaLisans', role: 'dialog', 'aria-labelledby': 'eaLisansBaslik' }, [
      el('div', { class: 'kutu' }, [
        el('h1', { id: 'eaLisansBaslik', text: L.AD }),
        el('p', { class: 'alt', text: 'Sürüm ' + L.SURUM + ' · Evrak Asistanı · Eyüp ŞEKER. Resmî bir MEB ürünü değildir.' }),
        el('label', { 'for': 'eaKurumKodu', text: 'Kurum kodu' }),
        el('input', { id: 'eaKurumKodu', type: 'text', inputmode: 'numeric', autocomplete: 'off', placeholder: 'ör. 123456' }),
        el('label', { class: 'onay' }, [
          el('input', { id: 'eaSozlesme', type: 'checkbox' }),
          el('span', {}, [el('a', { href: KOSUL, target: '_blank', rel: 'noopener', text: 'Lisans Koşulları' }), '’nı ve ',
            el('a', { href: KVKK, target: '_blank', rel: 'noopener', text: 'KVKK ve Sorumluluk Metni' }),
            '’ni okudum, kabul ediyorum. Veri sorumlusunun kurumum olduğunu; öğrenci verisinin bu bilgisayarda kaldığını biliyorum.'])
        ]),
        el('div', { class: 'satir' }, [el('button', { id: 'eaDeneme', type: 'button', text: '48 saatlik denemeyi başlat' })]),
        el('label', { 'for': 'eaAnahtar', text: 'Lisans anahtarı (EA-XXXX-XXXX-XXXX-XXXX)' }),
        el('input', { id: 'eaAnahtar', type: 'text', autocomplete: 'off', spellcheck: 'false' }),
        el('div', { class: 'satir' }, [
          el('button', { id: 'eaEtkin', type: 'button', text: 'Etkinleştir' }),
          el('button', { id: 'eaDogrula', type: 'button', class: 'sec', text: 'Doğrula' }),
          MOD === 'kilit' ? el('button', { id: 'eaKapat', type: 'button', class: 'sec', text: 'Uygulamaya dön' }) : null
        ]),
        el('p', { class: 'alt' }, ['Lisans sunucusuna yalnızca anahtar, kurum kodu, rastgele kurulum kimliği, ürün ve sürüm gider. Öğrenci, not ve evrak verisi gönderilmez. ',
          el('a', { href: SATIN, target: '_blank', rel: 'noopener', text: 'Lisans satın al' })]),
        el('div', { id: 'eaLisansDurum', class: 'durum', 'aria-live': 'polite' }),
        el('div', { id: 'eaHazir', hidden: 'hidden', text: A.hazirMetin || 'Hazır. Çalıştığınız sayfayı yenileyin.' })
      ])
    ]);
    document.body.appendChild(ov);
    if (MOD === 'kilit') {
      var rz = el('button', { id: 'eaLisansRozet', type: 'button', hidden: 'hidden', text: 'Lisans' });
      rz.addEventListener('click', function () { $('eaLisans').hidden = false; });
      document.body.appendChild(rz);
      $('eaKapat').addEventListener('click', async function () { var d = await L.durum(); if (d.izin) $('eaLisans').hidden = true; else boya(d); });
    }
    function dugme(id, fn) {
      $(id).addEventListener('click', async function () {
        var b = this; b.disabled = true;
        try { var r = await fn(); await boya(await L.durum(), r && r.ok === false ? r.hata : ''); } finally { b.disabled = false; }
      });
    }
    dugme('eaDeneme', function () { return L.denemeBaslat($('eaKurumKodu').value, $('eaSozlesme').checked); });
    dugme('eaEtkin', function () { return L.anahtarGir($('eaAnahtar').value, $('eaKurumKodu').value, $('eaSozlesme').checked); });
    dugme('eaDogrula', function () { return L.bakim(); });
  }
  async function baslat() { ekranKur(); await boya(await L.bakim()); }
  root.EA_LISANS_UI = { baslat: baslat, boya: boya };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(baslat, 0); });
  else setTimeout(baslat, 0);
})(typeof window !== 'undefined' ? window : this);
