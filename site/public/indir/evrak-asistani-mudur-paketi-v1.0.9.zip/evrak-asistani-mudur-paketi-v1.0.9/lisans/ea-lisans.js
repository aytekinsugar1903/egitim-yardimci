/* © 2026 Eyüp ŞEKER — Evrak Asistanı ortak lisans çekirdeği (EBYS / Rehberlik 1.1.1 ile aynı sözleşme).
   Sunucu: evrak-lisans-api (api.otonomevrak.com). EAT1 Ed25519 imzalı jeton, EA-XXXX-XXXX-XXXX-XXXX anahtarı,
   48 saatlik deneme (kurum kodu + ürün), 7 gün çevrimdışı tolerans, cihaz sınırı sunucuda (bireysel 2, kurum 7).
   Sunucuya YALNIZCA: lisans anahtarı, kurum kodu, rastgele kurulum kimliği, ürün kodu, sürüm. Öğrenci / evrak / not verisi gönderilmez.
   Ayar: self.EA_LISANS_AYAR = { urun, kabul[], ad, depo, surum, depoUrl? }
   Depo: chrome.storage.local (uzantı) | depoUrl (Okul Paketi yerel sunucusu) | localStorage. */
(function (G) {
  'use strict';
  var A = G.EA_LISANS_AYAR || {};
  var URUN = String(A.urun || '').toLowerCase();
  var KABUL = (A.kabul || [URUN]).map(function (x) { return String(x).toLowerCase(); });
  var AD = A.ad || 'Evrak Asistanı';
  var DEPO = A.depo || ('ea_lisans_' + URUN + '_v1');
  var SURUM = String(A.surum || '');
  var ACIK_ANAHTAR = '323Rkw1x_X3jmAV-_jadV0jxuNThV6_KY0maIAhTar0';
  var API = 'https://api.otonomevrak.com';
  var SAAT = 3600000, GUN = 24 * SAAT, DENEME_MS = 48 * SAAT, YENILE_MS = GUN;
  var SOZLESME_SURUMU = '2026-11-17';

  function b64uDec(s) {
    s = String(s).replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    var b = atob(s), u = new Uint8Array(b.length);
    for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i);
    return u;
  }
  function kkNorm(k) { return String(k || '').replace(/\D/g, ''); }
  function anahtarBicim(k) { return /^EA(-[A-Z0-9]{4}){4}$/.test(String(k || '').trim().toUpperCase()); }
  function urunNorm(x) { return String(x || '').toLowerCase().replace(/[^a-z0-9]/g, ''); }

  function tokenParse(tok) {
    var m = /^EAT1\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/.exec(String(tok || '').trim());
    if (!m) return null;
    try {
      return { yuk: JSON.parse(new TextDecoder().decode(b64uDec(m[1]))), veri: new TextEncoder().encode('EAT1.' + m[1]), imza: b64uDec(m[2]) };
    } catch (e) { return null; }
  }
  var anahtarP = null;
  async function tokenVerify(tok) {
    var p = tokenParse(tok);
    if (!p || p.imza.length !== 64) return null;
    try {
      anahtarP = anahtarP || crypto.subtle.importKey('raw', b64uDec(ACIK_ANAHTAR), { name: 'Ed25519' }, false, ['verify']);
      return (await crypto.subtle.verify({ name: 'Ed25519' }, await anahtarP, p.imza, p.veri)) ? p.yuk : null;
    } catch (e) { return null; }
  }

  // ---- depo ----
  function chromeDepo() { try { return G.chrome && chrome.storage && chrome.storage.local ? chrome.storage.local : null; } catch (e) { return null; } }
  async function yukleKayit() {
    try {
      var c = chromeDepo();
      if (c) { var r = await c.get(DEPO); return (r && r[DEPO]) || {}; }
      if (A.depoUrl) { var x = await fetch(A.depoUrl, { cache: 'no-store' }); return x.ok ? ((await x.json()) || {}) : {}; }
      return JSON.parse(G.localStorage.getItem(DEPO) || '{}') || {};
    } catch (e) { return {}; }
  }
  async function yazKayit(k) {
    try {
      var c = chromeDepo();
      if (c) { var o = {}; o[DEPO] = k; await c.set(o); }
      else if (A.depoUrl) await fetch(A.depoUrl, { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(k) });
      else G.localStorage.setItem(DEPO, JSON.stringify(k));
    } catch (e) {}
    return k;
  }
  function iidAl(k) {
    if (!k.iid) k.iid = A.iid || (crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2) + Date.now());
    return k.iid;
  }
  function simdi(kayit, now) { var n = now == null ? Date.now() : now; return Math.max(n, (kayit && +kayit.sonGorulen) || 0); }
  function urunUyuyor(yuk) {
    var p = yuk && urunNorm(yuk.product || yuk.urun);
    return !!p && KABUL.indexOf(p) >= 0;
  }
  function sure(ms) {
    var s = Math.max(0, ms), g = Math.floor(s / GUN), sa = Math.floor((s % GUN) / SAAT), dk = Math.floor((s % SAAT) / 60000);
    return g ? g + ' gün ' + sa + ' saat' : sa ? sa + ' saat ' + dk + ' dk' : dk + ' dk';
  }

  function durumHesapla(kayit, yuk, kurumKodu, now) {
    var t = simdi(kayit, now), kk = kkNorm(kurumKodu);
    if (!kk) return { durum: 'kurulum', izin: false, mesaj: AD + "'nı kullanmaya başlamak için kurum kodunu girip lisans sözleşmesini ve KVKK metnini onaylayın (48 saatlik deneme başlar)." };
    if (kayit && kayit.token && !yuk) return { durum: 'gecersiz', izin: false, mesaj: 'Lisans bilgisi bozuk ya da değiştirilmiş. Lisans anahtarınızı yeniden girin.' };
    if (yuk) {
      if (yuk.typ !== 'deneme' && yuk.typ !== 'lisans') return { durum: 'gecersiz', izin: false, mesaj: 'Bu jeton türü bu üründe kullanılamaz.' };
      if (!urunUyuyor(yuk)) return { durum: 'gecersiz', izin: false, mesaj: 'Bu lisans başka bir Evrak Asistanı ürünü için verilmiş. ' + AD + ' anahtarı gerekir.' };
      if (kkNorm(yuk.kk) !== kk) return { durum: 'gecersiz', izin: false, mesaj: 'Lisans başka bir kurum kodu için verilmiş (' + yuk.kk + '). Kurum kodunuzu ya da anahtarınızı kontrol edin.' };
      if (yuk.iid !== '*' && kayit && yuk.iid && yuk.iid !== kayit.iid) return { durum: 'gecersiz', izin: false, mesaj: 'Lisans bu cihaz için etkinleştirilmemiş. Lisans anahtarınızı yeniden girin.' };
      var bit = +yuk.bit || +yuk.exp;
      if (bit && t >= bit) return yuk.typ === 'deneme'
        ? { durum: 'bitti', izin: false, plan: 'deneme', bit: bit, mesaj: '48 saatlik deneme süreniz doldu. Devam etmek için ' + AD + ' lisansı alın ve anahtarı girin. Verileriniz silinmedi.' }
        : { durum: 'bitti', izin: false, plan: yuk.plan, bit: bit, mesaj: 'Lisans süreniz doldu (' + new Date(bit).toLocaleDateString('tr-TR') + '). Yenilemek için lisansınızı uzatın. Verileriniz silinmedi.' };
      if (yuk.typ === 'deneme') return { durum: 'deneme', izin: true, plan: 'deneme', bit: bit, kalanMs: bit - t, mesaj: 'Deneme sürümü: ' + sure(bit - t) + ' kaldı.' };
      var exp = +yuk.exp;
      if (exp && t >= exp) return { durum: 'cevrimdisi', izin: false, plan: yuk.plan, bit: bit, mesaj: 'Lisans 7 gündür doğrulanamadı. İnternet bağlantısını kontrol edip Doğrula düğmesine basın. Verileriniz silinmedi.' };
      var grace = exp && (exp - t) < 6 * GUN;
      return { durum: 'etkin', izin: true, plan: yuk.plan, bit: bit, kalanMs: bit - t, cevrimdisi: grace,
        mesaj: (yuk.plan === 'yillik' ? 'Yıllık' : yuk.plan === 'aylik' ? 'Aylık' : 'Kurum') + ' lisans etkin — bitiş ' + new Date(bit).toLocaleDateString('tr-TR') + (grace ? ' (çevrimdışı: ' + sure(exp - t) + ' içinde doğrulanmalı)' : '') + '.' };
    }
    // Sunucuya henüz ulaşılamadıysa yerel deneme saati (aynı 48 saat; sunucu jetonu gelince o geçerli olur)
    var bas = kayit && +kayit.yerelDenemeBas;
    if (bas && t < bas + DENEME_MS) return { durum: 'deneme', izin: true, plan: 'deneme', bit: bas + DENEME_MS, kalanMs: bas + DENEME_MS - t, dogrulanmadi: true, mesaj: 'Deneme sürümü: ' + sure(bas + DENEME_MS - t) + ' kaldı (lisans sunucusuna henüz ulaşılamadı).' };
    if (bas) return { durum: 'bitti', izin: false, plan: 'deneme', bit: bas + DENEME_MS, mesaj: '48 saatlik deneme süreniz doldu. Devam etmek için ' + AD + ' lisansı alın ve anahtarı girin. Verileriniz silinmedi.' };
    return { durum: 'kurulum', izin: false, mesaj: 'Lisans sözleşmesini ve KVKK metnini onaylayıp kurum kodunu kaydedin (48 saatlik deneme başlar).' };
  }

  async function post(yol, govde) {
    var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var tm = setTimeout(function () { if (ctl) ctl.abort(); }, 12000);
    try {
      var r = await fetch(API + yol, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(govde), signal: ctl ? ctl.signal : undefined, credentials: 'omit', cache: 'no-store' });
      var j = null; try { j = await r.json(); } catch (e) {}
      return { ok: r.ok, status: r.status, j: j || {} };
    } catch (e) {
      return { ok: false, status: 0, j: { hata: 'Lisans sunucusuna ulaşılamadı (internet bağlantısı).' } };
    } finally { clearTimeout(tm); }
  }
  // Sunucuya giden alanların tamamı (başka alan eklenmez):
  function govde(k, kk) { return { iid: k.iid, kurumKodu: kk, surum: SURUM, urun: URUN }; }

  async function jetonAl(k, kk, anahtar) {
    iidAl(k);
    if (!k.yerelDenemeBas && !anahtar && !k.anahtar) k.yerelDenemeBas = Date.now();
    var g = govde(k, kk);
    var r = (anahtar || k.anahtar) ? await post('/v1/etkinlestir', Object.assign({ anahtar: (anahtar || k.anahtar) }, g)) : await post('/v1/deneme', g);
    var y = r.ok && r.j.token ? await tokenVerify(r.j.token) : null;
    if (y) { k.token = r.j.token; k.hata = ''; k.sonDogrulama = Date.now(); }
    else k.hata = (r.j && r.j.hata) || ('Sunucu yanıtı: ' + r.status);
    if (r.status === 403 || r.status === 410) {
      k.token = '';
      // sunucu denemenin bittiğini söylüyorsa yerel deneme saati de bitmiş sayılır (yerel sıfırlamaya karşı)
      if (!anahtar && !k.anahtar && r.j && r.j.bit) k.yerelDenemeBas = Math.min(+k.yerelDenemeBas || Date.now(), +r.j.bit - DENEME_MS);
    }
    await yazKayit(k);
    return { ok: !k.hata, hata: k.hata, kayit: k };
  }
  function sozlesmeKaydet(k) { k.sozlesme = { surum: SOZLESME_SURUMU, kvkk: true, at: new Date().toISOString() }; }

  async function anahtarGir(anahtar, kurumKodu, sozlesme) {
    if (!sozlesme) return { ok: false, hata: 'Önce lisans sözleşmesini ve KVKK metnini onaylayın.' };
    var kk = kkNorm(kurumKodu);
    if (!kk || kk.length < 4) return { ok: false, hata: 'Kurum kodu en az 4 rakam olmalıdır.' };
    var k = await yukleKayit();
    k.kk = kk; sozlesmeKaydet(k);
    var a = String(anahtar || '').trim();
    if (!anahtarBicim(a)) return { ok: false, hata: 'Anahtar biçimi: EA-XXXX-XXXX-XXXX-XXXX' };
    k.anahtar = a.toUpperCase();
    await yazKayit(k);
    return jetonAl(k, kk, k.anahtar);
  }
  async function denemeBaslat(kurumKodu, sozlesme) {
    if (!sozlesme) return { ok: false, hata: 'Önce lisans sözleşmesini ve KVKK metnini onaylayın.' };
    var kk = kkNorm(kurumKodu);
    if (!kk || kk.length < 4) return { ok: false, hata: 'Kurum kodu en az 4 rakam olmalıdır.' };
    var k = await yukleKayit();
    k.kk = kk; sozlesmeKaydet(k);
    if (!k.yerelDenemeBas) k.yerelDenemeBas = Date.now();
    await yazKayit(k);
    return jetonAl(k, kk, null);
  }
  async function durum(now) {
    var k = await yukleKayit();
    var n = now == null ? Date.now() : now;
    if (!k.sonGorulen || n > k.sonGorulen) { k.sonGorulen = n; await yazKayit(k); }
    var yuk = k.token ? await tokenVerify(k.token) : null;
    var d = durumHesapla(k, yuk, k.kk, n);
    var sozOk = !!(k.sozlesme && k.sozlesme.surum === SOZLESME_SURUMU);
    if (!sozOk && d.izin) { d.izin = false; d.durum = 'kurulum'; d.mesaj = 'Lisans sözleşmesinin ve KVKK metninin bu sürümünü onaylayın.'; }
    return Object.assign(d, { anahtarVar: !!k.anahtar, sonHata: k.hata || '', sozlesme: sozOk, kk: k.kk || '', urun: URUN, ad: AD, surum: SURUM });
  }
  async function bakim() {
    var k = await yukleKayit();
    if (!k.kk) return durum();
    var p = k.token ? tokenParse(k.token) : null, y = p && p.yuk;
    if (!y || (y.typ !== 'deneme' && Date.now() - (+y.iat || 0) > YENILE_MS) || (y.typ === 'deneme' && k.anahtar)) await jetonAl(k, k.kk, k.anahtar || null);
    return durum();
  }

  G.EA_LISANS = {
    URUN: URUN, KABUL: KABUL, AD: AD, API: API, DEPO: DEPO, SURUM: SURUM, DENEME_MS: DENEME_MS, YENILE_MS: YENILE_MS,
    SOZLESME_SURUMU: SOZLESME_SURUMU, ACIK_ANAHTAR: ACIK_ANAHTAR,
    tokenParse: tokenParse, tokenVerify: tokenVerify, durumHesapla: durumHesapla, kkNorm: kkNorm, anahtarBicim: anahtarBicim,
    urunUyuyor: urunUyuyor, yukleKayit: yukleKayit, yazKayit: yazKayit, durum: durum, bakim: bakim,
    anahtarGir: anahtarGir, denemeBaslat: denemeBaslat, jetonAl: jetonAl
  };
})(typeof self !== 'undefined' ? self : this);
