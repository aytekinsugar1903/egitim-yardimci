/* Evrak Asistanı — Düzenli Yazılar: arka plan (bildirimler)
 * sw.js içinden background.js'ten SONRA yüklenir; background.js'e dokunmaz.
 * Kendi alarm / bildirim adlarını kullanır (ebys-periyodik-*), mevcut alarmlara karışmaz.
 */
(function () {
  'use strict';
  const P = self.EA_PERIYODIK;
  if (!P) return;
  const ALARM = 'ebys-periyodik-saatlik';
  const ONEK = 'ebys-periyodik:';
  const ICON = 'icons/bildirim-128.png';

  function saatDakika() {
    try {
      const p = {};
      new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Istanbul', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date()).forEach(x => { p[x.type] = x.value; });
      return (+p.hour) * 60 + (+p.minute);
    } catch (e) { const d = new Date(Date.now() + 3 * 3600e3); return d.getUTCHours() * 60 + d.getUTCMinutes(); }
  }

  async function kontrol(neden) {
    try {
      if (!(await P.onayVarMi())) return;
      try { await P.eskiHazirTemizle(); } catch (e) { }
      const x = await P.oku([P.KEY, P.BILDIRIM_KEY, P.TAKIP_KEY]);
      const depo = P.depoTemizle(x[P.KEY]);
      if (!depo.ayar.bildirim || !depo.kartlar.length) return;
      const [hh, mm] = depo.ayar.saat.split(':').map(Number);
      if (neden !== 'test' && saatDakika() < hh * 60 + mm) return; // sabah saatinden önce rahatsız etme
      const bugun = P.bugunIso();
      const gecmis = x[P.BILDIRIM_KEY] && typeof x[P.BILDIRIM_KEY] === 'object' ? x[P.BILDIRIM_KEY] : {};
      const yeni = {};
      Object.keys(gecmis).forEach(k => { if (P.gunFark(gecmis[k], bugun) <= 60) yeni[k] = gecmis[k]; });
      const gonderilecek = [];
      depo.kartlar.forEach(k => {
        if (!k.aktif) return;
        P.aktifDonemler(k, bugun).forEach(p => {
          const d = P.durum(k, p, bugun, depo.ayar.ekTatiller, P.gelenBul(k, x[P.TAKIP_KEY], p));
          let asama = null;
          if (d.kod === 'gecikti') asama = depo.ayar.gecikmeBildir ? 'gecti' : null;
          else if (typeof d.kalan === 'number') {
            const e = depo.ayar.esikler.filter(t => d.kalan <= t).sort((a, b) => a - b)[0];
            if (e !== undefined) asama = 't' + e;
          }
          if (!asama) return;
          const anahtar = k.id + '|' + p + '|' + asama;
          if (asama === 'gecti' ? yeni[anahtar] === bugun : yeni[anahtar]) return;
          yeni[anahtar] = bugun;
          gonderilecek.push({ k, p, d, anahtar });
        });
      });
      if (!gonderilecek.length) { await P.yaz({ [P.BILDIRIM_KEY]: yeni }); return; }
      if (gonderilecek.length > 3) {
        bildir(ONEK + 'toplu-' + bugun, '🔁 ' + gonderilecek.length + ' düzenli yazı bekliyor',
          gonderilecek.slice(0, 4).map(g => '• ' + g.k.ad + ' — ' + g.d.etiket.replace(/^\S+\s/, '')).join('\n'), 'Evrak Asistanı — Düzenli Yazılar');
      } else {
        gonderilecek.forEach(g => bildir(ONEK + g.anahtar, '🔁 ' + g.k.ad,
          P.ayAdi(g.p) + ' dönemi — son gün ' + P.trTarih(g.d.sonTarih) + ' — ' + g.d.etiket.replace(/^\S+\s/, '') + (g.k.kime ? '\nKime: ' + g.k.kime : ''),
          'Evrak Asistanı — Düzenli Yazılar'));
      }
      await P.yaz({ [P.BILDIRIM_KEY]: yeni });
    } catch (e) { console.warn('[Evrak Asistanı] Düzenli yazı bildirimi:', e); }
  }
  function bildir(id, baslik, mesaj, alt) {
    try {
      chrome.notifications.create(id, { type: 'basic', iconUrl: ICON, title: String(baslik).slice(0, 80), message: String(mesaj).slice(0, 300), contextMessage: alt, priority: 1, requireInteraction: false }, () => void chrome.runtime.lastError);
    } catch (e) { }
  }

  try { chrome.alarms.create(ALARM, { delayInMinutes: 2, periodInMinutes: 60 }); } catch (e) { }
  try {
    chrome.alarms.onAlarm.addListener(a => { if (a && a.name === ALARM) kontrol('saatlik'); });
    chrome.runtime.onStartup.addListener(() => setTimeout(() => kontrol('acilis'), 30000));
    chrome.notifications.onClicked.addListener(id => {
      if (!String(id).startsWith(ONEK)) return;
      try { chrome.tabs.create({ url: chrome.runtime.getURL('periyodik.html') }); } catch (e) { }
      try { chrome.notifications.clear(id); } catch (e) { }
    });
    chrome.runtime.onMessage.addListener((m, sender, cevap) => {
      if (!m || typeof m.type !== 'string' || !m.type.startsWith('ea-periyodik-')) return; // başka mesajlara karışma
      if (m.type === 'ea-periyodik-ac') {
        try { chrome.tabs.create({ url: chrome.runtime.getURL('periyodik.html') + (m.hash ? '#' + String(m.hash).replace(/[^\w-]/g, '') : '') }, () => cevap({ ok: !chrome.runtime.lastError })); } catch (e) { cevap({ ok: false }); }
        return true;
      }
      if (m.type === 'ea-periyodik-test') { bildir(ONEK + 'test-' + Date.now(), '🔁 Deneme bildirimi', 'Düzenli yazı hatırlatmaları bu şekilde görünecek.', 'Evrak Asistanı — Düzenli Yazılar'); kontrol('test').then(() => cevap({ ok: true })); return true; }
      if (m.type === 'ea-periyodik-sifirla') { P.yaz({ [P.BILDIRIM_KEY]: {} }).then(() => cevap({ ok: true })); return true; }
    });
  } catch (e) { }
})();
