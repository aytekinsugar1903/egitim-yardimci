function _0x3366(_0x190168, _0x5ec775) {
    _0x190168 = _0x190168 - 0xb4;
    const _0x1c219b = _0x1c21();
    let _0x336621 = _0x1c219b[_0x190168];
    return _0x336621;
}
function _0x1c21() {
    const _0x5a2ddd = ['get', 'PDF okunamadı: ', 'yardimcilar', 'PDF okundu', 'Tarih', 'okul', 'key', 'trim', 'indexOf', 'hidden', '” klasöründe ', '<< /Type /Catalog /Pages 2 0 R >>', 'message', 'font', ' — ', 'Birime Havale kutusu kayboldu — kontrol edin', 'error', 'clr', 'Emin misiniz? Tekrar tıklayın', 'kisiSeeded', '#fm', '#oto_cancel', '.log', 'Yanlış kişi seçildi: ', 'kisiKurum', ' daha önce işlenmiş.', 'Konu yazıldı: ', '__EA_CLICK_STATS__', 'Numara okunamadı (elle kaydedildiyse numarayı ekleyin)', 'matches', '.ui-dialog,.ui-overlaypanel', 'Tamam', ' | Havale: ', '1958598jHMNfW', '#s_katalog', 'parse', 'Benzer kayıt seçiliyor: ', 'canvas', 'focusin', 'stop', '#act', '.ui-datatable-data tr,input[type=radio],.ui-radiobutton-box,tbody tr', 'children', 'Konu metni kesilmiş görünüyor (“', 'Geldiği kişi', ' id=', 'Boş değer: ', '</button>\x0a<div id=\x22panel\x22>\x0a <div id=\x22hd\x22><span class=\x22logo\x22>', 'includes', 'replace', 'top', 'getComputedStyle', 'right', 'shift', ' → ', 'Sayı', 'havale', 'add', 'local', 'Kayıtlar klasörü hatırlandı: ', 'readwrite', '--fs', 'contains', 'Gizlilik Politikası', '<svg viewBox=\x220 0 64 64\x22 width=\x22100%\x22 height=\x22100%\x22><defs><linearGradient id=\x22eg\x22 x1=\x220\x22 y1=\x220\x22 x2=\x220\x22 y2=\x221\x22><stop offset=\x220\x22 stop-color=\x22#2196f3\x22/><stop offset=\x221\x22 stop-color=\x22#0a3a8c\x22/></linearGradient></defs><rect width=\x2264\x22 height=\x2264\x22 rx=\x2215\x22 fill=\x22url(#eg)\x22/><path d=\x22M16 11h22l10 10v32H16z\x22 fill=\x22#fff\x22/><path d=\x22M38 11l10 10H38z\x22 fill=\x22#c8def9\x22/><rect x=\x2221\x22 y=\x2226\x22 width=\x2222\x22 height=\x223\x22 rx=\x221.5\x22 fill=\x22#78a0d7\x22/><rect x=\x2221\x22 y=\x2233\x22 width=\x2222\x22 height=\x223\x22 rx=\x221.5\x22 fill=\x22#78a0d7\x22/><rect x=\x2221\x22 y=\x2240\x22 width=\x2214\x22 height=\x223\x22 rx=\x221.5\x22 fill=\x22#78a0d7\x22/><circle cx=\x2246\x22 cy=\x2247\x22 r=\x2212\x22 fill=\x22#fff\x22/><circle cx=\x2246\x22 cy=\x2247\x22 r=\x229.5\x22 fill=\x22#2eaa5a\x22/><path d=\x22M41.5 47.5l3.2 3.2 6-6.5\x22 stroke=\x22#fff\x22 stroke-width=\x222.6\x22 fill=\x22none\x22 stroke-linecap=\x22round\x22 stroke-linejoin=\x22round\x22/></svg>', 'className', 'appendChild', '] ⚠ Sayfa yenileniyor/kapanıyor! Son tıklanan: ', 'onsuccess', ' — listeden birimi siz seçin', 'Klasör izni verilmedi.', 'div', 'varsayılan', 'Bu öğe seçilemedi (üst grup olabilir), sıradaki deneniyor…', 'onMessage', 'offsetHeight', 'Ağaçta okul düğümü bulunamadı (', '\x5c$&', '\x0a%%EOF\x0a', 'button,a,input[type=button],input[type=submit],.ui-button', 'Benzer kayıt satırı seçiliyor: ', 'Ağaç düğümüne tıklanıyor: ', 'Konu kodu uyuşmuyor (beklenen ', 'ebys_evrak_kayit_on_v1', 'substr', ' tarihli ', 'submit', 'now', 'findIndex', 'querySelectorAll', 'dispatchEvent', 'list', 'Konu kodu seçili değil / görünmüyor', 'Parent', ' için TC 11 haneli değil; TC ile arama yapılmayacak.', 'Zaman aşımı', 'https://mebbis.meb.gov.tr/Default.aspx', 'Benzer kayıt penceresi kapanmadı (seçim işlemedi)', 'imza', 'stringify', 'parentElement', 'put', 'getBoundingClientRect', '.ui-state-highlight,.ui-treenode-selected', 'li,tr', 'input,textarea', '▶ Kaldığı yerden devam et', '118011rxRdUe', '.ui-messages,.ui-growl-message,.ui-message-error,.ui-messages-error,.ui-messages-warn,.ui-messages-fatal,.ui-state-error,.ui-dialog', 'tcHint', '__evrakKayitYuklendi', 'title', 'font-size:.95em;padding:4px;border:1px solid #888;border-radius:4px;width:100%', 'Evrak tarihi', 'kayit', 'Havale bölgesinde betik sızıntısı görüldü; okul adı öğrenilmedi.', '0|Genel\x0a10|Mevzuat İşleri\x0a010.01|Kanunlar\x0a010.02|Tüzükler\x0a010.03|Yönetmelikler\x0a010.04|Yönergeler\x0a010.05|Tebliğler\x0a010.06|Genelgeler\x0a010.06.01|İç Genelgeler\x0a010.06.02|Dış Genelgeler\x0a010.06.99|Diğer\x0a010.07|Talimatlar, Duyurular, Sirkülerler\x0a010.07.01|Talimatlar\x0a010.07.02|Duyurular\x0a010.07.03|Sirkülerler\x0a010.07.99|Diğer\x0a010.08|Rehber, Kılavuz\x0a010.09|Standartlar\x0a010.99|Diğer\x0a20|Olurlar, Onaylar\x0a30|Anlaşma, Sözleşme Ve Protokoller\x0a030.01|Anlaşmalar\x0a030.02|Sözleşmeler\x0a030.03|Protokoller\x0a030.04|Şartnameler\x0a030.04.01|İdari\x0a030.04.02|Teknik\x0a030.04.99|Diğer\x0a030.99|Diğer\x0a40|Faaliyet Raporları\x0a040.01|Haftalık\x0a040.02|Aylık\x0a040.03|Üç Aylık\x0a040.04|Altı Aylık\x0a040.05|Yıllık\x0a040.06|Konsolide\x0a040.99|Diğer\x0a41|Brifingler Ve Bilgi Notları\x0a041.01|Brifingler\x0a041.02|Bilgi Notları\x0a041.99|Diğer\x0a42|İstatistikler\x0a44|Anketler\x0a45|Görüşler\x0a045.01|Teknik Ve Mesleki\x0a045.02|Hukuki\x0a045.03|İdari\x0a045.99|Diğer\x0a50|Kurullar Ve Toplantılar\x0a050.01|Kurullar, Senatolar, Meclisler\x0a050.01.01|Seçim Ve Atama İşleri\x0a050.01.02|Davetler Ve Gündemler\x0a050.01.03|Tutanaklar\x0a050.01.04|Kararlar\x0a050.01.05|Ödemeler\x0a050.01.99|Diğer\x0a050.02|Yönetim Kurulları, Belediye Encümeni\x0a050.02.01|Seçim Ve Atama İşleri\x0a050.02.02|Davetler Ve Gündemler\x0a050.02.03|Tutanaklar\x0a050.02.04|Kararlar\x0a050.02.05|Ödemeler\x0a050.02.99|Diğer\x0a050.03|Danışma, Disiplin, Koordinasyon Kurulları\x0a050.03.01|Seçim Ve Atama İşleri\x0a050.03.02|Davetler Ve Gündemler\x0a050.03.03|Tutanaklar\x0a050.03.04|Kararlar\x0a050.03.05|Ödemeler\x0a050.03.99|Diğer\x0a050.04|İhtisas Kurulları\x0a050.04.01|Seçim Ve Atama İşleri\x0a050.04.02|Davetler Ve Gündemler\x0a050.04.03|Tutanaklar\x0a050.04.04|Kararlar\x0a050.04.05|Ödemeler\x0a050.04.99|Diğer\x0a050.05|Konseyler\x0a050.05.01|Seçim Ve Atama İşleri\x0a050.05.02|Davetler Ve Gündemler\x0a050.05.03|Tutanaklar\x0a050.05.04|Kararlar\x0a050.05.05|Ödemeler\x0a050.05.99|Diğer\x0a050.06|Komite, Komisyonlar\x0a050.06.01|Seçim Ve Atama İşleri\x0a050.06.02|Davetler Ve Gündemler\x0a050.06.03|Tutanaklar\x0a050.06.04|Kararlar\x0a050.06.05|Ödemeler\x0a050.06.99|Diğer\x0a050.99|Diğer\x0a51|Bilimsel Ve Kültürel Toplantılar\x0a051.01|Kongre\x0a051.02|Konferans\x0a051.03|Şura\x0a051.04|Sempozyum\x0a051.05|Seminer\x0a051.06|Bienal\x0a051.07|Kurultay\x0a051.08|Çalıştay\x0a051.09|Panel\x0a051.10|Kolokyum\x0a051.99|Diğer\x0a60|Kalite Yönetim Sistemi\x0a060.01|Kalite El Kitabı\x0a060.02|Temel Prosedürler Ve Bağlı İşlemler\x0a060.04|Talimatlar\x0a060.05|Formlar\x0a060.07|İzleme Ve Ölçme İşlemleri\x0a060.07.01|Müşteri Memnuniyeti (Veri Analizi)\x0a060.07.02|Tetkik İşlemleri\x0a060.07.03|İzleme Ve Ölçme Sonuçlarının Analizi (Veri Analizi)\x0a060.07.99|Diğer\x0a060.08|İyileştirme İşlemleri\x0a060.08.01|Düzeltici Faaliyetler\x0a060.08.02|Önleyici Faaliyetler\x0a060.08.99|Diğer\x0a060.09|Bireysel Öneriler\x0a060.10|Yönetimin Gözden Geçirmesi\x0a060.11|Hizmet (Ürün) Gerçekleştirme\x0a060.11.01|Planlama\x0a060.11.02|Hizmete Bağlı Şartların Belirlenmesi Ve Gözden Geçirilmesi\x0a060.11.03|Tasarım Ve Geliştirme\x0a060.11.04|Üretim Ve Hizmet (Ürün) Sağlanması (Sunulması)\x0a060.11.99|Diğer\x0a060.12|Kalibrasyon\x0a060.99|Diğer\x0a100|Eğitim Ve Öğretim İşleri (Genel)\x0a101|Eğitim Ve Öğretim Programları\x0a101.01|Okul Öncesi, İlkokul Ve Ortaokul Programları\x0a101.01.01|Hazırlama/Geliştirme\x0a101.01.02|Uygulama\x0a101.01.03|İzleme/Değerlendirme\x0a101.01.04|Revizyon\x0a101.02|Genel Ortaöğretim Programları\x0a101.02.01|Hazırlama/Geliştirme\x0a101.02.02|Uygulama\x0a101.02.03|İzleme/Değerlendirme\x0a101.02.04|Revizyon\x0a101.03|Mesleki Ortaöğretim Programları\x0a101.04|Yaygın Eğitim Programları\x0a101.04.01|Hazırlama/Geliştirme\x0a101.04.02|Uygulama\x0a101.04.03|İzleme/Değerlendirme\x0a101.04.04|Revizyon\x0a101.05|Özel Eğitim Programları\x0a101.99|Diğer\x0a102|Eğitim-Öğretim Yılı Çalışma Takvimi\x0a103|Ölçme Ve Değerlendirme\x0a105|Okul, Kurum Açma, Kapatma, Devir, Ad Verme İşleri\x0a105.01|Okul, Kurum, Program Açma/Kapatma/Devir İşlemleri\x0a105.02|Alan/Dal Açma/Kapatma/Devir İşlemleri\x0a105.03|Okullara Ad Verme İşlemleri\x0a105.04|Pansiyon Açma/Kapatma/Kapasite Belirleme İşlemleri\x0a105.05|Mülga İşlemleri\x0a105.06|Halk Katkılarına Ait İşlemler\x0a105.99|Diğer\x0a110|Kontenjanların Belirlenmesi\x0a110.01|Okul Düzeyinde\x0a110.02|Eğitim Bölgesi Düzeyinde\x0a110.03|Yatılı İlköğretim Öğrenci\x0a110.04|Yatılı Öğrenci\x0a110.05|Mesleki Ve Teknik Ortaöğretim Kurumları Alan/Dal\x0a110.99|Diğer\x0a115|Yazılı Ve Görsel Eğitim Materyali (Modül)/Ders Kitapları\x0a115.01|Yazılı Ve Görsel Eğitim Materyali (Modül)\x0a115.02|Temel Ders Kitapları\x0a115.03|Öğretmen El Kitapları\x0a115.04|Yardımcı Ders Kitapları\x0a115.05|Meb Ders Kitaplarının Yazılması\x0a115.06|İş Ve İşlem Yaprakları\x0a115.99|Diğer\x0a116|Ders Kitapları Ve Diğer Eğitim Araçlarını İnceleme\x0a116.01|Meb Ders Kitapları\x0a116.02|Yabancı Ülke Ders Kitapları\x0a116.03|Özel Sektör Ders Kitapları\x0a116.99|Diğer\x0a117|Ders Araç Ve Gereçleri Hazırlama Çalışmaları\x0a117.01|Temrin Hazırlama\x0a117.02|Özel Eğitime Yönelik Ders Araç Ve Gereçleri Hazırlama Çalışm.\x0a117.03|Laboratuar Hazırlığı\x0a117.99|Diğer\x0a120|Ders Planları\x0a120.01|Ünitelendirilmiş Yıllık Plan\x0a120.02|Günlük Plan\x0a120.03|Ünite Planı\x0a120.04|Ders Planı\x0a120.99|Diğer\x0a121|Haftalık Ders Dağıtım Çizelgeleri Ve Programları\x0a121.01|Haftalık Ders Dağıtım Çizelgeleri\x0a121.02|Haftalık Ders Programları\x0a121.99|Diğer\x0a125|Sınav Komisyonları/Sınavlar\x0a125.01|Sınav Komisyonları\x0a125.02|Okul/Kurumda Yapılan Sınavlar\x0a125.03|Okul/Kurumda Yapılan Ortak Sınavlar\x0a125.04|Merkezi Sistemle Yapılan Sınavlar\x0a125.05|Yurtdışı Sınavları\x0a125.99|Diğer\x0a130|Telafi Eğitimi\x0a130.01|Yapılamayan Dersler İçin Düzenlenen Yetiştirme/Telafi Eğitimi\x0a130.02|Meslek Lisesi Dip. Almak İçin Telafi Eğitimi\x0a130.03|Denklik İşlemlerinde Telafi Eğitimi\x0a130.04|Çıraklık Eğitiminde Telafi Eğitimi\x0a130.05|Çıraklık Eğitiminde Yoğunlaştırılmış Eğitim\x0a130.06|Ustalık Eğitiminde Yoğunlaştırılmış Eğitim\x0a130.99|Diğer\x0a135|Eğitim Kurumlarında Açılan Kurslar\x0a135.01|Meslek Edindirme Eğitimi Ve Kursları\x0a135.01.01|Kalfalık\x0a135.01.02|Ustalık\x0a135.01.03|Eğitici Ustalık\x0a135.02|Geliştirme Ve Uyum Kursları\x0a135.03|Yaygın Eğitim Kursları\x0a135.04|Yetiştirme Ve Hazırlık Kursları\x0a135.05|Yurtdışı Mesleki Ve Teknik Eğitim Kursları\x0a135.06|Özel Sektörle İşbirliği Kursları\x0a135.07|Aile Eğitimi Kursları\x0a135.99|Diğer\x0a136|Okul Sağlığı Çalışmaları\x0a137|Okuma Kültürü Ve Kütüphane İşleri\x0a140|Taşımalı Eğitim\x0a141|Tam Gün Tam Yıl Eğitim Uygulaması\x0a142|İkili Mesleki Eğitim Uygulaması\x0a145|Mesleki Açık Öğretim İşlemleri\x0a150|Yüksek Öğrenim İşleri\x0a150.01|Yurt Dışında Özel Yüksek Öğrenim Göreceklerin İşlemleri\x0a150.02|Resmi Burslu Öğrenci İşlemleri (T.C. Vatandaşları)\x0a150.03|Resmi Burslu Öğrenci İşlemleri (Yabancı Uyruklu)\x0a150.99|Diğer\x0a155|Yurt Dışı Eğitim-Öğretim İşleri\x0a155.01|Tcs (Türk Cumhuriyetleri Sınavı) İşleri\x0a155.02|Yurt Dışı Türkiye Türkçesi Eğitim Öğretim Merkezi İşleri\x0a155.03|Yurt Dışında Yaşayan Vatandaşların Çocuklarının Eğitimi\x0a155.03.01|Türkçe Ve Türk Kültürü Dersleri İle İlgili İşlemler\x0a155.03.02|Yabancı Dil Olarak Türkçe Dersleri İle İlgili İşlemler\x0a155.04|Öğrenim Belgelerinin Teyidi\x0a155.99|Diğer\x0a160|Özel Eğitim, Rehberlik Ve Danışma Hizmetleri\x0a160.01|Özel Eğitim Hizmetleri\x0a160.01.01|Özel Eğitim Sınıfları\x0a160.01.02|Kaynaştırma Eğitimi\x0a160.01.03|Bireyselleştirilmiş Eğitim Programları\x0a160.01.04|Özel Eğitimde Aile Eğitimi Çalışmaları\x0a160.01.05|Evde Özel Eğitime Muhtaç Öğrencilerle İlgili İşlemler\x0a160.01.06|Bilim Sanat Merkezleri\x0a160.02|Rehberlik Ve Danışma Hizmetleri\x0a160.02.01|Psikolojik Ölçme Araçları\x0a160.02.02|Rehberlik Programları\x0a160.02.03|Rehberlik Araştırma Merkezleri Modülü Çalışmaları\x0a160.02.04|Eğitsel Ve Mesleki Rehberlik Çalışmaları\x0a160.02.05|Hayat Boyu Rehberlik Çalışmaları\x0a160.02.06|Kariyer Rehberliği Çalışmaları\x0a160.02.07|Uyumlu Eğitim Ortamları Oluşturma Çalışmaları\x0a160.02.08|Psikososyal Koruma Ve Önleme Çalışmaları\x0a160.02.09|Öğrenci Tanıma Ve Tanılamaya İlişkin Çalışmalar\x0a160.02.10|Aile Eğitim Ve Rehberlik Çalışmaları\x0a160.02.11|Psikolojik Danışmanlık Ve Rehberlik\x0a160.03|Tanıtım Ve Yöneltme Çalışmaları\x0a160.03.01|Mesleki Rehberlik\x0a160.04|Şiddet Eylemlerinden Ve Zararlı Maddelerden Korunma\x0a160.04.01|Şiddet Eylemlerinden Korunma\x0a160.04.02|Zararlı Maddelerden Korunma\x0a160.99|Diğer\x0a165|Eğitime Yardımcı Dernek Ve Kurumlar\x0a165.01|Okul Aile Birlikleri\x0a165.02|Sivil Toplum Kuruluşları\x0a165.02.01|Öğrenci Konseyi\x0a165.02.02|Veli Konseyi\x0a165.99|Diğer\x0a170|Yerel Yönetimlerdeki Eğitimle İlgili Kararlar\x0a170.01|İdare Meclisi\x0a170.02|İl Encümeni\x0a170.03|Özel Komisyonlar\x0a170.99|Diğer\x0a175|Meslek Standartları Ve Tanımları\x0a175.01|Sektör Komiteleri\x0a175.02|Meslek Standartları\x0a175.03|Meslek Tanımları\x0a175.04|Nitelik Kod Kılavuzu Çalışmaları\x0a175.99|Diğer\x0a188|Nöbet Hizmetleri\x0a188.01|Müdür Yardımcısı Nöbeti\x0a188.02|Öğretmen Nöbeti\x0a188.03|Belletici Nöbeti\x0a188.04|Öğrenci Nöbeti\x0a188.99|Diğer\x0a198|Eğitimle İlgili Defter, Dosya, Çizelge Ve Belgeler\x0a198.01|Defterler\x0a198.01.01|Diploma Defteri\x0a198.01.02|Tasdikname Defteri\x0a198.01.03|Sınıf Geçme Defteri\x0a198.01.04|Yıllık Devamsızlık Defteri\x0a198.01.05|Öğrenci Kütük Defteri\x0a198.01.06|Kalfalık Belge Defteri\x0a198.01.07|Ustalık Belge Defteri\x0a198.01.08|Eğitici Ustalık Belge Defteri\x0a198.01.09|Belge Defteri(Okulda Verilen Kurslarla İlgili Belgelerin Defteri)\x0a198.02|Mezuniyet/Ayrılma Belgeleri\x0a198.02.01|Diploma\x0a198.02.02|Geçici Mezuniyet Belgesi\x0a198.02.03|Öğrenim Belgesi\x0a198.02.04|Öğrenim Durum Belgesi\x0a198.02.05|Tasdikname\x0a198.02.06|Yüz Yüze Eğitimi Tamamlama Belgesi\x0a198.03|Sertifika,Kurs/Tamamlama Ve Diğer Belgeler\x0a198.03.01|Sertifika\x0a198.03.02|Kurs Belgesi\x0a198.03.03|Kalfalık Belgesi\x0a198.03.04|Ustalık Belgesi\x0a198.03.05|Usta Öğreticilik Belgesi\x0a198.03.06|Bitirme Belgesi\x0a198.03.07|Mesleki Eğitimi Tamamlama Belgesi\x0a198.03.08|İş Yeri Açma Belgesi\x0a198.03.09|Öğrenci Belgesi\x0a198.04|Öğrenci Kişisel Dosyaları\x0a198.05|Resmî Burslu Öğrenci Garanti (Sponsorluk) Belgesi\x0a198.99|Diğer\x0a199|Eğitim Öğretim İle İlgili Diğer İşler\x0a200|Öğrenci İşleri (Genel)\x0a205|Kayıt-Kabul\x0a210|Nakil Ve Geçişler\x0a210.01|Nakiller\x0a210.02|Okul Türleri Arasında Geçiş\x0a210.03|Teknik Liseye Geçiş\x0a210.04|Alana/Dal Değişikliği\x0a210.99|Diğer\x0a215|Denklik İşleri\x0a215.01|Yurtdışı Eğitim Denkliği\x0a215.02|Mesleki Ve Teknik Eğitim Denkliği\x0a215.99|Diğer\x0a220|Devam-Devamsızlık\x0a225|Ödül Ve Disiplin İşleri\x0a225.01|Ödül İşleri\x0a225.01.01|Teşekkür Belgesi\x0a225.01.02|Takdirname Belgesi\x0a225.01.03|Onur Belgesi\x0a225.01.04|Başarı Belgesi\x0a225.01.05|Üstün Başarı Belgesi\x0a225.02|Disiplin İşleri\x0a225.99|Diğer\x0a230|Öğrenci Askerlik İşlemleri\x0a235|Yabancı Uyruklu Öğrenciler (İlk Ve Orta Öğretim)\x0a240|Mezunların İzlenmesi\x0a245|Yatılılık/Bursluluk İşlemleri\x0a245.01|İl/İlçe Yatılılık Ve Bursluluk Komisyonu İşlemleri\x0a245.02|Parasız Yatılılık\x0a245.03|Paralı Yatılılık\x0a245.04|Bursluluk\x0a245.04.01|Devlet Bursları\x0a245.04.02|Şartlı Nakit Transferi İşlemleri\x0a245.04.03|Özel Kurum/Kuruluşlarca Verilen Burslar\x0a245.05|Yarım Yatılılık\x0a245.99|Diğer\x0a250|Okul Ve İşletmelerde Meslekî Eğitim/Staj Çalışmaları\x0a250.01|Öğrenci Sigorta İşlemleri\x0a250.02|İş Kazaları\x0a250.03|Meslek Hastalıkları\x0a250.04|Öğrenci Ve Veli Talepleri\x0a250.99|Diğer\x0a299|Öğrenci İşleriyle İlgili Diğer İşler\x0a300|Sosyal Ve Kültürel Faaliyetler (Genel)\x0a305|Öğrenci Meclisleri\x0a305.01|Okul Öğrenci Meclisi\x0a305.02|İl Öğrenci Meclisi\x0a305.03|Türkiye Öğrenci Meclisi\x0a305.99|Diğer\x0a310|Müsamereler, Yarışmalar\x0a310.01|Kültürel, Bilgi, Beceri Proje Vb. Yarışmalar\x0a310.01.01|Özel\x0a310.01.02|Resmi\x0a310.02|Halkoyunları Yarışmaları\x0a310.03|Müzik Yarışmaları\x0a310.04|Uluslar Arası Halkoyunları, Müzik Yarışmaları Ve Festivalleri\x0a310.05|Sponsorluk\x0a310.99|Diğer\x0a315|Kardeş Okul Uygulamaları\x0a315.01|Yurt İçi\x0a315.02|Yurt Dışı\x0a315.99|Diğer\x0a316|Dost Aile Uygulamaları\x0a317|Misafir Öğrenci Uygulamaları\x0a320|Öğrenci/Çocuk Kulüpleri\x0a325|Toplum Hizmeti Çalışmaları\x0a330|Spor Faaliyetleri\x0a330.01|İlkokul Ve Ortaokullar Arası Spor Yarışmaları\x0a330.02|Ortaöğretim Kurumları Arası Spor Yarışmaları\x0a330.03|Dünya Liseler Arası Spor Yarışmaları\x0a330.04|Sponsorluk\x0a330.99|Diğer\x0a335|İzcilik Faaliyetleri\x0a335.01|İzcilik Kampları\x0a335.02|İzci Ünitelerinin Kurulması\x0a335.03|İzci Evleri\x0a335.04|Arama, Kurtarma, İzci Birliği\x0a335.05|İl İzci Kurulları\x0a335.06|İzcilerin Eğitimi\x0a335.99|Diğer\x0a340|Öğrenci Eğitim Faaliyetleri (Kamplar)\x0a340.01|Öğrenci Eğitim Yaz Kampları\x0a340.02|Öğrenci Eğitim Kış Kampları\x0a340.03|Uluslar Arası Öğrenci Eğitim Kampları\x0a340.99|Diğer\x0a349|Sosyal Ve Kültürel Faaliyetlerle İlgili Diğer İşler\x0a350|Öğretmen Yetiştirme Ve Eğitimi İşleri (Genel)\x0a355|Yök\x27Le İlişkiler\x0a355.01|Üniversitelerle İlişkiler\x0a355.02|Eğitim Fakülteleri İle İlişkiler\x0a355.03|Beden Eğitimi Ve Spor Yüksek Okulu İle İlişkiler\x0a355.99|Diğer\x0a360|Öğretmen Yeterlikleri\x0a360.01|Okul Temelli Meslekî Gelişim (Dünya Bankası Destekli) Ortaöğretim Kademesi Öğretmenlerinin Özel Alan\x0a360.02|Ortaöğretim Kademesi Öğretmenlerinin Özel Alan Yeterliklerinin Belirlenmesi (Ab Destekli)\x0a360.03|Öğretmen Mesleği Genel Yeterlikleri İle İlköğretim Kademesi Öğretmenlerine İlişkin Özel Alan Yeterlikleri\x0a360.04|Öğretmenliğe Atanacakların Alanlarıyla İlgili İşlemler\x0a360.05|Yurt Dışından Mezun Olan Öğretmen Adayları İle İlgili İşlemler\x0a360.99|Diğer\x0a399|Öğretmen Yetiştirme Ve Eğitimiyle İlgili Diğer İşler\x0a400|Özel Öğretim Kurumları (Genel)\x0a405|Özel Okul İşleri\x0a405.01|Türk Okulları\x0a405.02|Yabancı Okulları\x0a405.03|Azınlık Okulları\x0a405.04|Uluslar Arası Okullar\x0a405.05|Özel Okullarla İlgili Verilen Görüşler\x0a405.99|Diğer\x0a410|Özel Yaygın Eğitim Kurumları\x0a410.01|Özel Dershane İşleri\x0a410.02|Sürücü Kursları İşleri\x0a410.03|Çeşitli Özel Kurslar\x0a410.04|Uzaktan Öğretim Yapan Kuruluşlar\x0a410.05|Hizmetiçi Eğitim Merkezleri\x0a410.06|Öğrenci Etüd Eğitim Merkezleri\x0a410.07|Özel Eğitim Ve Rehabilitasyon Merkezleri\x0a410.08|Özel Yurtlar\x0a410.99|Diğer\x0a415|Trafik Genel Eğitim Planı\x0a420|Öğrenim Ücreti İşleri\x0a425|Ücretsiz Öğrenci/Kursiyer İşleri\x0a449|Özel Eğitimle İlgili Diğer İşler\x0a450|Eğitim Teknolojileri İşleri (Genel)\x0a451|Kalite Kontrol İşleri(Radyo, Tv Prog., Eğitim Yazılımları)\x0a455|Radyo Ve Televizyon Programlarının Hazırlanması\x0a460|Ürün Tasarım Ve Planlama İşleri\x0a460.01|Senaryo Hazırlama Ve Tasarım\x0a460.02|Videografik Ve Animasyon Hazırlama\x0a460.03|Eğitim Materyalleri Grafik Tasarımları\x0a460.04|Eğitim Yazılımı Tasarım Çalışmaları\x0a460.99|Diğer\x0a465|Dijital Fotoğraf Arşivi İşleri\x0a470|Eğitim Materyallerini Çoğaltma, Pazarlama Ve Yayınlama İşleri\x0a471|Sınav Evrakının Dağıtımı\x0a475|Soru Hazırlama İşleri\x0a480|Merkezi Sistem Sınavları\x0a480.01|Seviye Belirleme Sınavı (Sbs)\x0a480.02|Devlet Parasız Yatılılık Ve Bursluluk Sınavı (Dpybs)\x0a480.03|Açık Öğretim Okulları Sınavları (Aöos)\x0a480.04|Motorlu Taşıt Sürücü Adayları Sınavları (Mtsas)\x0a480.05|Diğer Sınavlar (Protokollü Sınavlar)\x0a480.06|Merkezi Sistem Sınavları İle İlgili İtirazlar\x0a480.99|Diğer\x0a481|Uzaktan Eğitim Ve E-Öğrenme İşleri\x0a481.01|Uzaktan Eğitim\x0a481.02|Elektronik Eğitim Materyalleri\x0a481.03|E-İçerik Hazırlama\x0a481.04|Teknoloji Destekli Eğitim\x0a481.05|Eğitim Bilişm Ağı\x0a485|Çağrı Merkezi (Call Center)\x0a485.01|Talepler\x0a485.02|Şikâyetler\x0a485.03|Bilişim Teknolojisi Sınıfları Arıza Bildirimleri\x0a485.99|Diğer\x0a490|Açık Öğretim Okulları\x0a490.01|Açık Öğretim Liseleri\x0a490.02|Açık İlköğretim Okulları\x0a490.03|Mesleki Açık Öğretim Liseleri\x0a490.04|Mesleki Ve Teknik Açık Öğretim Okulları\x0a490.05|Açık Öğretim Ortaokulu\x0a490.99|Diğer\x0a495|Açık Öğretim Kurumları Öğrenci Ders Notlarının Hazırlanması Ve Halk Eğitim Merkezi Müdürlükleri\x0a499|Eğitim Teknolojileriyle İlgili Diğer İşler\x0a600|Araştırma Ve Planlama İşleri(Genel)\x0a601|Teşkilatlanma İşleri\x0a601.01|Kuruluş, Yapılanma\x0a601.02|Yetkilendirme, Yetki Değişikliği\x0a601.03|Yönetimi Geliştirme\x0a601.04|Teşkilat Şemaları Ve Kadrolar\x0a601.04.01|Teşkilat Şemaları\x0a601.04.02|Norm Kadro Çalışmaları\x0a601.04.02.01|Görev/İş Tanımları\x0a601.04.02.02|Norm Kadro Pozisyonları\x0a601.04.02.99|Diğer\x0a601.04.99|Diğer\x0a601.99|Diğer\x0a602|Plan Ve Program İşleri\x0a602.01|Kalkınma Planı\x0a602.01.01|Hazırlık Çalışmaları\x0a602.01.02|İzleme Ve Değerlendirme\x0a602.01.99|Diğer\x0a602.02|Orta Vadeli Plan/Program\x0a602.02.01|Hazırlık Çalışmaları\x0a602.02.02|İzleme Ve Değerlendirme\x0a602.02.99|Diğer\x0a602.03|Yıllık Plan/Program\x0a602.03.01|Hazırlık Çalışmaları\x0a602.03.02|İzleme Ve Değerlendirme\x0a602.03.99|Diğer\x0a602.04|Stratejik Plan\x0a602.04.01|Veri Toplama\x0a602.04.02|Analiz Ve Raporlama\x0a602.04.03|Revizyon\x0a602.04.99|Diğer\x0a602.05|Eylem Planları\x0a602.06|Yönetim/İş Planları\x0a602.07|Yatırım Programları\x0a602.07.01|Hazırlık Çalışmaları\x0a602.07.02|Yatırım Revizyonu\x0a602.07.03|Ek Ödenek\x0a602.07.04|Ödenek Aktarma\x0a602.07.05|Serbest Bırakma\x0a602.07.06|Maliyet Revizyonu\x0a602.07.07|Dönem Gerçekleştirme Raporları\x0a602.07.99|Diğer\x0a602.08|Performans Programı\x0a602.08.01|Veri Toplama\x0a602.08.02|Maliyetlendirme\x0a602.08.03|İzleme Ve Değerlendirme\x0a602.08.04|Revize İşlemleri\x0a602.08.99|Diğer\x0a602.99|Diğer\x0a604|Proje İşleri\x0a604.01|Araştırma Projeleri\x0a604.01.01|Başvurular Ve Proje Önerileri\x0a604.01.02|Değerlendirme Ve Onay\x0a604.01.03|İzleme Ve Raporlandırma\x0a604.01.04|Değişiklikler Ve Tadilatlar\x0a604.01.05|Ödemeler Ve Mali İncelemeler\x0a604.01.06|Tescil/Patent/Mülkiyet İşlemleri\x0a604.01.99|Diğer\x0a604.02|Araştırma/Geliştirme Projeleri\x0a604.02.01|Başvurular Ve Proje Önerileri\x0a604.02.02|Değerlendirme Ve Onay\x0a604.02.03|İzleme Ve Raporlandırma\x0a604.02.04|Değişiklikler Ve Tadilatlar\x0a604.02.05|Ödemeler Ve Mali İncelemeler\x0a604.02.06|Tescil/Patent/Mülkiyet İşlemleri\x0a604.02.99|Diğer\x0a604.99|Diğer\x0a605|Araştırma İşleri\x0a605.01|Veri Toplama\x0a605.02|Raporlama\x0a605.99|Diğer\x0a609|Koordinasyon İşleri\x0a610|Soru Önergeleri\x0a611|Çevre İşleri\x0a611.01|Çevre Yönetimi\x0a611.02|Çed\x0a611.03|Denetim\x0a611.04|İklim Değişikliği\x0a611.99|Diğer\x0a612|İç Kontrol\x0a612.01|İç Kontrol Sistemi Ve Standartlar\x0a612.01.01|Süreçler\x0a612.01.02|İzleme Ve Değerlendirme\x0a612.01.03|İnceleme Ve Raporlama\x0a612.01.99|Diğer\x0a612.02|Ön Mali Kontrol\x0a612.99|Diğer\x0a619|Araştırma Ve Planlama İle İlgili Diğer İşler\x0a620|Basın Ve Halkla İlişkiler (Genel)\x0a621|Basın İşleri\x0a621.01|Basın Toplantıları\x0a621.02|Basına Verilen Demeçler\x0a621.03|Tekzipler\x0a621.04|Basında Yer Alan Haberler\x0a621.05|Basın Özetleri\x0a621.99|Diğer\x0a622|Talep, Şikayet, Görüşler\x0a622.01|Talep Ve Şikayetler\x0a622.02|Görüş Ve Teklifler\x0a622.03|Bilgi Ve Belge Talepleri\x0a622.99|Diğer\x0a639|Basın Ve Halkla İlişkiler Konusunda Diğer İşler\x0a640|Hukuk İşleri (Genel)\x0a641|Dava Dosyaları\x0a641.01|Avrupa İnsan Hakları Mahkemesi\x0a641.02|Tahkim\x0a641.02.01|Ulusal\x0a641.02.02|Uluslar Arası\x0a641.02.99|Diğer\x0a641.03|Adli Davalar\x0a641.03.01|Hukuk\x0a641.03.02|Ceza\x0a641.03.03|İcra\x0a641.03.99|Diğer\x0a641.04|İdari Davalar\x0a641.05|Vergi Davaları\x0a641.99|Diğer\x0a645|Tebligatlar\x0a646|Vekaletnameler, Azilnameler\x0a650|Bilirkişi Ve Ekspertiz\x0a651|Uzlaşma/ Sulh İşlemleri\x0a659|Hukukla İlgili Diğer İşler\x0a660|Teftiş/Denetim İşleri(Genel)\x0a661|Plan Ve Programları\x0a661.01|Yıllık\x0a661.02|Dönemsel\x0a661.99|Diğer\x0a662|Görev Emirleri\x0a663|Denetim,İnceleme,Soruşturma Ve Araştırma\x0a663.01|Cevaplı\x0a663.02|Denetim\x0a663.03|Genel Durum\x0a663.04|Ön İnceleme\x0a663.05|İnceleme\x0a663.06|Basit\x0a663.07|Soruşturma\x0a663.08|Araştırma\x0a663.09|Bilgi\x0a663.99|Diğer\x0a667|İhbar Ve Suç Duyuruları\x0a667.01|İhbar\x0a667.02|Suç Duyuruları\x0a667.99|Diğer\x0a668|Yüksek Denetleme Ve Kit Komisyonu\x0a668.01|Yüksek Denetleme Kurulu Raporları\x0a668.01.01|İvedi Durum Raporları\x0a668.01.02|Özel İnceleme Raporları\x0a668.01.03|Dönem Raporları\x0a668.01.04|Yıllık Raporlar\x0a668.01.05|Kuruluşun Cevabi Raporları\x0a668.01.99|Diğer\x0a668.02|Kit Komisyonu Raporları\x0a668.99|Diğer\x0a679|Teftiş/Denetim İle İlgili Diğer İşler\x0a700|Bilgi Sistemleri (Genel)\x0a702|Yazılım Geliştirme Ve Kodlama Çalışmaları\x0a702.01|Analiz Ve Tasarım Çalışmaları\x0a702.02|Kodlama Çalışmaları\x0a702.03|Test Çalışmaları\x0a702.99|Diğer\x0a703|Bilgi İşletim Sistemleri Planlama Ve Değerlendirme\x0a703.01|Proje Yönetimi\x0a703.02|Değişiklik Yönetimi\x0a703.03|Güvenlik Yönetimi\x0a703.04|Kaynak Yönetimi\x0a703.05|Konfigürasyon Yönetimi\x0a703.06|Olağanüstü Durum Yönetimi\x0a703.07|Problem Yönetimi\x0a703.99|Diğer\x0a704|Hatlar\x0a704.01|İnternet\x0a704.02|Data Hattı\x0a704.03|İntranet\x0a704.99|Diğer\x0a705|Sistem İle İlgili Talepler\x0a705.01|Yazılım Talepleri\x0a705.02|Donanım Talepleri\x0a705.99|Diğer\x0a708|Veri Girişi, İşleme Ve Aktarma İşleri\x0a708.01|Kayıt\x0a708.02|Düzeltme\x0a708.03|Silme\x0a708.04|Aktarma\x0a708.05|Sorgulama\x0a708.99|Diğer\x0a710|E-Uygulamalar\x0a710.01|Web Sayfası\x0a710.02|Abonelik\x0a710.03|E-İmza\x0a710.04|E-Posta İşlemleri\x0a710.05|Liste İşlemleri\x0a710.99|Diğer\x0a713|Kullanım Ve Erişim Yetkileri\x0a713.01|Yetki Verilmesi\x0a713.02|Yetki Kaldırılması\x0a713.03|Yetki Değişikliği\x0a713.99|Diğer\x0a719|Bilgi Sistemleri İle İlgili Diğer İşler\x0a720|Dış İlişkiler Ve Avrupa Birliği (Genel)\x0a721|Uluslararası Hukuk\x0a724|Ülkelerle İlişkiler\x0a724.01|İkili İlişkiler\x0a724.01.01|Genel Bilgiler\x0a724.01.02|Anlaşmalar, Sözleşmeler, Protokoller\x0a724.01.03|İşbirliği\x0a724.01.04|Sorunlar\x0a724.01.05|Yardımlar\x0a724.01.99|Diğer\x0a724.02|Çok Taraflı İlişkileri\x0a724.02.01|Genel Bilgiler\x0a724.02.02|Anlaşmalar, Sözleşmeler, Protokoller\x0a724.02.03|İşbirliği\x0a724.02.04|Sorunlar\x0a724.02.05|Yardımlar\x0a724.02.99|Diğer\x0a724.03|Türk Ve Müslüman Topluluklarla İlişkiler\x0a724.03.01|Genel Bilgiler\x0a724.03.02|Anlaşmalar, Sözleşmeler, Protokoller\x0a724.03.03|İşbirliği\x0a724.03.04|Sorunlar\x0a724.03.05|Yardımlar\x0a724.03.99|Diğer\x0a724.99|Diğer\x0a730|Uluslararası Ve Bölgesel Kuruluşlarla İlişkiler\x0a730.01|Politikalar\x0a730.02|Mevzuat Ve Üyelik İşlemleri\x0a730.02.01|Tüzük\x0a730.02.02|Üyelik İşlemleri\x0a730.02.03|Katkı Payları\x0a730.02.99|Diğer\x0a730.03|Toplantılar\x0a730.03.01|Genel Kurul\x0a730.03.02|Yönetim Kurulu\x0a730.03.03|Komiteler\x0a730.03.04|Alt Komiteler\x0a730.03.05|Çalışma Grupları\x0a730.03.99|Diğer\x0a730.06|Projeler\x0a730.06.01|Uluslararası Projeler\x0a730.06.02|Türkiye\x27Ye Yönelik Projeler\x0a730.06.99|Diğer\x0a730.07|İşbirliği\x0a730.08|Rapor, İnceleme, Anket Ve İstatistikler\x0a730.08.01|Raporlar\x0a730.08.02|İncelemeler\x0a730.08.03|Anketler\x0a730.08.04|İstatistikler\x0a730.08.99|Diğer\x0a730.09|İrtibat Büroları\x0a730.10|Bilgi Ve Belge Talepleri\x0a730.11|Başvuru Ve Şikayetler\x0a730.12|Denetim\x0a730.13|Yardımlar\x0a730.99|Diğer\x0a740|Avrupa Birliği (Ab) İle İlişkiler (Genel)\x0a741|Ab Hukuku\x0a741.01|Türkiye-Ab Ortaklık Hukuku\x0a741.01.01|Ortaklık Organlarının Kararları\x0a741.01.02|İçtihad\x0a741.01.99|Diğer\x0a741.02|Ab Hukuku Alanındaki Gelişmeler\x0a741.02.01|Birincil Hukuk\x0a741.02.02|İkincil Hukuk\x0a741.02.03|İçtihad\x0a741.02.99|Diğer\x0a741.99|Diğer\x0a742|Ab Karar Alma Mekanizması İle İlişkiler\x0a742.01|Bakanlar Konseyi\x0a742.02|Avrupa Komisyonu\x0a742.03|Avrupa Parlamentosu\x0a742.04|Avrupa Konseyi\x0a742.05|Adalet Divanı\x0a742.06|Sayıştay\x0a742.07|Ekonomik Ve Sosyal Komite\x0a742.08|Bölgeler Komitesi\x0a742.09|Avrupa Merkez Bankası\x0a742.10|Avrupa Yatırım Bankası\x0a742.11|Ombudsman\x0a742.99|Diğer\x0a743|Gümrük Birliği Ve Ortaklık Organları\x0a743.01|Ortaklık Konseyi\x0a743.02|Ortaklık Komitesi\x0a743.02.01|Tarım Ve Balıkçılık Alt Komitesi\x0a743.02.01.01|Toplantılar\x0a743.02.01.02|Çalışma Grupları\x0a743.02.01.99|Diğer\x0a743.02.02|İç Pazar Ve Rekabet Alt Komitesi\x0a743.02.03|Ticaret, Sanayi Ve Akçt Ürünleri Alt Komitesi\x0a743.02.04|Ekonomik Ve Parasal Konular, Sermaye Hareketleri Ve İstatistik Alt K.\x0a743.02.05|Teknolojik Yenilik, Eğitim Ve Araştırma Programları Alt Komitesi\x0a743.02.06|Ulaştırma, Çevre Ve Enerji (Trans-Avrupa Şebekeleri Dahil) Alt Komitesi\x0a743.02.07|Bölgesel Kalkınma Gelişme, İstihdam Ve Sosyal Politika Alt Komitesi\x0a743.02.08|Gümrük, Vergilendirme, Uyuşturucu Trafiği Ve Kara Para Aklama Alt K.\x0a743.02.99|Diğer\x0a743.03|Karma Parlamento Komisyonu\x0a743.04|Gümrük İşbirliği Komitesi\x0a743.05|Gümrük Birliği Ortak Komitesi\x0a743.06|Karma İstişare Komitesi\x0a743.07|Ab Teknik Komiteleri Ve Çalışma Grupları\x0a743.99|Diğer\x0a744|Ab Katılım Süreci\x0a744.01|Katılım Ortaklığı Belgesi\x0a744.02|Ulusal Program\x0a744.02.01|Hazırlık Çalışmaları\x0a744.02.02|İzlenmesi\x0a744.02.99|Diğer\x0a744.03|İlerleme Raporları\x0a744.04|Katılım Öncesi Mali İzleme Süreci\x0a744.05|Katılım Müzakereleri\x0a744.05.02|Strateji/Eylem Planı\x0a744.05.03|Müzakere Pozisyonu\x0a744.05.04|Mevzuat Taslakları\x0a744.05.05|Çalışma Grupları\x0a744.05.99|Diğer\x0a744.06|Siyasi Kriterler\x0a744.07|Ekonomik Kriterler\x0a744.08|İç Koordinasyon Uyum Komitesi\x0a744.09|Türkiye’Nin Avrupa Birliği İletişim Stratejisi\x0a744.10|Çeviri Eşgüdüm Çalışmaları\x0a744.10.01|Ab Müktesebatının Çeviri İşlemleri Ve Eşgüdümü\x0a744.10.02|Türk Mevzuatının Çeviri İşlemleri Ve Eşgüdümü\x0a744.10.03|Ab Terminolojisi Veri Tabanı\x0a744.10.99|Diğer\x0a744.11|Mevzuat Uyum Ulusal Veri Tabanı\x0a744.99|Diğer\x0a745|Topluluk Programları Ve Ajanslar\x0a745.01|Programlar\x0a745.01.01|Eğitim, Gençlik Ve Kültür Programları\x0a745.01.02|Araştırma Ve Teknolojik Gelişme Programları\x0a745.01.03|Rekabet Edebilirlik Ve Yenilik Çerçeve Programları\x0a745.01.99|Diğer\x0a745.02|Ajanslar\x0a745.99|Diğer\x0a746|Ab-Türkiye Mali İşbirliği\x0a746.01|Ipa(Katılım Öncesi Yardım Aracı-Instrument For Pre-Accession)\x0a746.01.01|Programlama Süreci\x0a746.01.02|Projeler\x0a746.01.02.01|Proje Teklifleri\x0a746.01.02.02|Proje Fişleri (Raporları)\x0a746.01.02.03|Fiş Değişiklikleri (Revizyon)\x0a746.01.02.04|İzleme Ve Değerlendirme\x0a746.01.02.99|Diğer\x0a746.01.03|Abgs’Nin Faydalanıcısı Olduğu Projeler\x0a746.01.03.01|Proje Teklifleri\x0a746.01.03.02|Proje Fişleri (Raporları)\x0a746.01.03.03|Fiş Değişiklikleri (Revizyon)\x0a746.01.03.04|İzleme Ve Değerlendirme\x0a746.01.03.99|Diğer\x0a746.01.04|Sınır Ötesi İşbirliği\x0a746.01.05|Operasyonel Programlar\x0a746.01.06|İzleme Komiteleri\x0a746.01.99|Diğer\x0a746.02|Çok Faydalanıcılı\x0a746.99|Diğer\x0a748|Ab Ve Üye Ülke Teknik Yardımları\x0a748.01|Ab Teknik Yardımları\x0a748.01.01|Taıex\x0a748.01.01.01|Uzman Desteği\x0a748.01.01.02|İnceleme Gezileri\x0a748.01.01.03|Seminer/Çalışma Grupları\x0a748.01.01.99|Diğer\x0a748.01.02|Eşleştirme (Twinning)\x0a748.01.02.01|Standart Eşleştirme\x0a748.01.02.02|Kısa Süreli Eşleştirme\x0a748.01.02.99|Diğer\x0a748.01.99|Diğer\x0a748.02|Üye Ülke Teknik Yardımları\x0a748.02.01|Matra/G2G.Nl\x0a748.02.02|Matra-Mtec\x0a748.02.99|Diğer\x0a748.99|Diğer\x0a749|Dış İlişkiler Ve Ab İle İlgili Diğer İşler\x0a750|Emlak Ve Yapım İşleri (Genel)\x0a751|Toplulaştırma İşlemleri\x0a752|Kamulaştırma Ve İrtifak Hakkı\x0a752.01|Kamulaştırma\x0a752.01.01|Kamu Yararı Kararı Ve Onay İşleri\x0a752.01.02|Teknik Çalışmalar\x0a752.01.03|Bedel Takdir Ve Uzlaşma\x0a752.01.04|Sorunlar\x0a752.01.05|Zarar Ve Ziyan\x0a752.01.06|Ödeme İşleri\x0a752.01.99|Diğer\x0a752.02|İrtifak Hakkı İşlemleri\x0a752.99|Diğer\x0a753|Kadastro Çalışmaları\x0a754|İmar İşleri\x0a755|Yapım (İnşaat) İşleri\x0a755.01|Etüd-Proje Ve Fizibilite İşleri\x0a755.02|İhale İşleri\x0a755.02.01|İzin Ve Onay İşleri\x0a755.02.02|Yaklaşık Maliyet Hesabı\x0a755.02.03|İhale İlan İşleri\x0a755.02.04|Şartnameler\x0a755.02.05|Başvuru İşlemleri Ve Tutanaklar\x0a755.02.06|Komisyon İşlemleri\x0a755.02.07|İtirazlar\x0a755.02.08|Sözleşme\x0a755.02.09|Kesin Teminat\x0a755.02.99|Diğer\x0a755.03|Uygulama İşleri\x0a755.03.01|İş Programı\x0a755.03.02|Ruhsatlandırma\x0a755.03.03|Hammadde Temini/Malzeme Seçimi\x0a755.03.04|Keşif Artışı\x0a755.03.05|Süre Uzatımı Ve Ödenek Dilim Değişikliği\x0a755.03.06|Birim Fiyat Ve Yeni Fiyat\x0a755.03.99|Diğer\x0a755.04|İnceleme Ve Kontrol İşleri\x0a755.05|Hakedişler Ve Ödemeler\x0a755.06|Geçici Ve Kesin Kabuller\x0a755.06.01|Geçici Ve Kesin Kabuller\x0a755.06.02|Fesih, Tasfiye Ve Devir İşlemleri\x0a755.06.99|Diğer\x0a755.07|Kesin Hesap İşlemleri\x0a755.07.01|Kesin Hesap\x0a755.07.02|Ssk İlişkisizlik Belgesi\x0a755.07.03|İş Deneyim Belgesi Verilmesi\x0a755.07.04|Teminatların İadesi\x0a755.07.99|Diğer\x0a755.99|Diğer\x0a756|Taşınmaz İşlemleri\x0a756.01|Tahsis, Devir Ve Takas\x0a756.02|Satış Ve Kiralama\x0a756.03|Envanter\x0a756.99|Diğer\x0a757|Harita Ve Fotoğraf İşleri\x0a757.01|Talepler\x0a757.02|Yapım Ve Güncelleme\x0a757.03|Sayısallaştırma\x0a757.04|Kayıt Ve Envanter\x0a757.99|Diğer\x0a769|Emlak Ve Yapımla İlgili Diğer İşler\x0a770|Eğitim İşleri (Genel)\x0a771|Eğitim Planları\x0a772|Burs İşleri\x0a772.01|Kontenjan Ve Duyurular\x0a772.02|Başvuru Ve Değerlendirme\x0a772.03|Ödemeler\x0a772.04|Tahsil,Takip, Atama\x0a772.99|Diğer\x0a773|Staj İşleri\x0a773.01|Kontenjan İşlemleri\x0a773.02|İzleme Ve Değerlendirme\x0a773.03|Belgelendirme\x0a773.99|Diğer\x0a774|Eğitimler, Kurslar\x0a774.01|Mesleki Yeterlilik Ve Gelişim\x0a774.01.01|Teklifler\x0a774.01.02|Program\x0a774.01.03|Duyuru\x0a774.01.04|Eğitici Temini\x0a774.01.05|Kayıt, Katılım Listeleri\x0a774.01.06|Eğitim Materyali\x0a774.01.07|Sınav\x0a774.01.08|Belgelendirme\x0a774.01.09|Yeterlilik\x0a774.01.99|Diğer\x0a774.02|Dil Eğitimi\x0a774.02.01|Teklifler\x0a774.02.02|Program\x0a774.02.03|Duyuru\x0a774.02.04|Eğitici Temini\x0a774.02.05|Kayıt, Katılım Listeleri\x0a774.02.06|Eğitim Materyali\x0a774.02.07|Sınav\x0a774.02.08|Belgelendirme\x0a774.02.09|Yeterlilik\x0a774.02.99|Diğer\x0a774.03|Rotasyon\x0a774.03.01|Teklifler\x0a774.03.02|Program\x0a774.03.03|Duyuru\x0a774.03.04|Eğitici Temini\x0a774.03.05|Kayıt, Katılım Listeleri\x0a774.03.06|Eğitim Materyali\x0a774.03.07|Sınav\x0a774.03.08|Belgelendirme\x0a774.03.09|Yeterlilik\x0a774.03.99|Diğer\x0a774.04|İntibak/Oryantasyon\x0a774.04.01|Teklifler\x0a774.04.02|Program\x0a774.04.03|Duyuru\x0a774.04.04|Eğitici Temini\x0a774.04.05|Kayıt, Katılım Listeleri\x0a774.04.06|Eğitim Materyali\x0a774.04.07|Sınav\x0a774.04.08|Belgelendirme\x0a774.04.09|Yeterlilik\x0a774.04.99|Diğer\x0a774.05|Görevde Yükselme\x0a774.05.01|Teklifler\x0a774.05.02|Program\x0a774.05.03|Duyuru\x0a774.05.04|Eğitici Temini\x0a774.05.05|Kayıt, Katılım Listeleri\x0a774.05.06|Eğitim Materyali\x0a774.05.07|Sınav\x0a774.05.08|Belgelendirme\x0a774.05.09|Yeterlilik\x0a774.05.99|Diğer\x0a774.06|Aday Memur\x0a774.06.01|Teklifler\x0a774.06.02|Program\x0a774.06.03|Duyuru\x0a774.06.04|Eğitici Temini\x0a774.06.05|Kayıt, Katılım Listeleri\x0a774.06.06|Eğitim Materyali\x0a774.06.07|Sınav\x0a774.06.08|Belgelendirme\x0a774.06.09|Yeterlilik\x0a774.06.99|Diğer\x0a774.07|Kariyer Uzman\x0a774.07.01|Teklifler\x0a774.07.02|Program\x0a774.07.03|Duyuru\x0a774.07.04|Eğitici Temini\x0a774.07.05|Kayıt, Katılım Listeleri\x0a774.07.06|Eğitim Materyali\x0a774.07.07|Sınav\x0a774.07.08|Belgelendirme\x0a774.07.09|Yeterlilik\x0a774.07.99|Diğer\x0a774.08|Kişisel Gelişim Ve Motivasyon\x0a774.08.01|Teklifler\x0a774.08.02|Program\x0a774.08.03|Duyuru\x0a774.08.04|Eğitici Temini\x0a774.08.05|Kayıt, Katılım Listeleri\x0a774.08.06|Eğitim Materyali\x0a774.08.07|Sınav\x0a774.08.08|Belgelendirme\x0a774.08.09|Yeterlilik\x0a774.08.99|Diğer\x0a774.09|Bilgilendirme-Bilinçlendirme\x0a774.09.01|Teklifler\x0a774.09.02|Program\x0a774.09.03|Duyuru\x0a774.09.04|Eğitici Temini\x0a774.09.05|Kayıt, Katılım Listeleri\x0a774.09.06|Eğitim Materyali\x0a774.09.07|Sınav\x0a774.09.08|Belgelendirme\x0a774.09.09|Yeterlilik\x0a774.09.99|Diğer\x0a774.99|Diğer\x0a779|Rehberlik, Danışmanlık İşleri\x0a800|İdari Ve Sosyal İşler (Genel)\x0a801|Taşıt Ve İş Makineleri\x0a801.01|Taşıt\x0a801.01.01|Plaka, Ruhsat Ve Muayene İşleri\x0a801.01.02|Akaryakıt İşleri\x0a801.01.03|Tahsis, Sevk Ve Kontrol İşleri\x0a801.01.04|Kaza İşleri\x0a801.01.99|Diğer\x0a801.02|İş Makineleri\x0a801.02.01|Plaka, Ruhsat Ve Muayene İşleri\x0a801.02.02|Akaryakıt İşleri\x0a801.02.03|Tahsis, Sevk Ve Kontrol İşleri\x0a801.02.04|Kaza İşleri\x0a801.02.99|Diğer\x0a801.99|Diğer\x0a802|Ulaştırma Ve Servis İşleri\x0a803|Resmi Mühür İş Ve İşlemleri\x0a804|Evrak Kayıt Ve Sevk İşlemleri\x0a804.01|Gelen-Giden Evrak\x0a804.02|Kontrollü Evrak İşlemleri\x0a804.03|Yanlış Evrakın İade İşlemleri\x0a804.99|Diğer\x0a805|Belge Yönetimi Ve Arşiv İşlemleri\x0a805.01|Belge Yönetimi\x0a805.01.01|Saklama Süreli Dosya Planı\x0a805.01.02|Kodlama İşlemleri\x0a805.01.99|Diğer\x0a805.02|Arşiv Yönetimi\x0a805.02.01|Devir-Teslim İşlemleri\x0a805.02.02|Ayıklama Ve İmha İşlemleri\x0a805.02.02.01|Ayıklama Ve İmha\x0a805.02.02.02|Uygunluk Görüşü\x0a805.02.02.99|Diğer\x0a805.02.03|Tasnif (Sınıflandırma) İşlemleri\x0a805.02.04|İnceleme Ve Denetleme\x0a805.02.05|Arşivlerden Yararlanma\x0a805.02.99|Diğer\x0a805.99|Diğer\x0a806|Kütüphane Ve Dokümantasyon İşleri\x0a806.01|Derme Geliştirme Ve Derleme İşleri\x0a806.01.01|Kitaplar\x0a806.01.02|Süreli Yayınlar\x0a806.01.03|Tezler\x0a806.01.04|Yazma Ve Nadir Eserler\x0a806.01.05|Veritabanları, Elektronik Ürün Ve Yayınlar\x0a806.01.99|Diğer\x0a806.02|Kullanıcı Hizmetleri\x0a806.02.01|Ödünç Verme İşlemleri\x0a806.02.02|Araştırma Hizmetleri\x0a806.02.03|Danışma Hizmetleri\x0a806.02.04|Elektronik Hizmetler\x0a806.02.99|Diğer\x0a806.99|Diğer\x0a807|Bakım-Onarım İşleri\x0a807.01|Bina Ve Tesisler\x0a807.02|Tesisat\x0a807.03|Mekanik\x0a807.04|Elektronik Ve Teknik Cihaz\x0a807.05|Taşıt Ve İş Makineleri\x0a807.99|Diğer\x0a808|Temizlik İşleri\x0a809|Taşınır Mal İşlemleri\x0a809.01|İstek\x0a809.02|Devir, Giriş-Çıkış İşlemleri\x0a809.03|Sayım Ve Döküm\x0a809.04|Kesin Hesap\x0a809.05|Taşınır Kayıt Kontrol Yetkilisi\x0a809.99|Diğer\x0a810|Sigorta İşleri\x0a810.01|Dahili Sigorta\x0a810.01.01|Yangın\x0a810.01.02|Nakliyat\x0a810.01.03|Kaza\x0a810.01.04|Mühendislik\x0a810.01.99|Diğer\x0a810.02|Harici Sigorta\x0a810.02.01|Yangın\x0a810.02.02|Nakliyat\x0a810.02.03|Kaza\x0a810.02.04|Mühendislik\x0a810.02.99|Diğer\x0a810.99|Diğer\x0a811|İletişim Ve Haberleşme İşleri\x0a811.01|Telefon\x0a811.01.01|Sabit\x0a811.01.02|Gsm\x0a811.01.03|Mobil\x0a811.01.99|Diğer\x0a811.02|Kablolu Tv\x0a811.03|Telsiz\x0a811.04|Faks\x0a811.05|İnternet\x0a811.99|Diğer\x0a812|Çevre Düzenleme İşleri\x0a813|Sosyal İşler\x0a813.01|Sosyal Tesisler\x0a813.01.01|Eğitim Tesisi, Misafirhane Ve Kamp\x0a813.01.01.01|Müracaat\x0a813.01.01.02|Tahsis\x0a813.01.01.03|Tahliye\x0a813.01.01.99|Diğer\x0a813.01.02|Lojman\x0a813.01.02.01|Müracaat\x0a813.01.02.02|Tahsis\x0a813.01.02.03|Tahliye\x0a813.01.02.99|Diğer\x0a813.01.03|Kreş Ve Gündüz Bakımevi\x0a813.01.03.01|Müracaat\x0a813.01.03.02|Tahsis\x0a813.01.03.03|Tahliye\x0a813.01.03.99|Diğer\x0a813.01.04|Spor Tesisi\x0a813.01.04.01|Müracaat\x0a813.01.04.02|Tahsis\x0a813.01.04.03|Tahliye\x0a813.01.04.99|Diğer\x0a813.01.05|Yemekhane, Kafeterya Ve Çay Ocağı\x0a813.01.05.01|Müracaat\x0a813.01.05.02|Tahsis\x0a813.01.05.03|Tahliye\x0a813.01.05.99|Diğer\x0a813.01.99|Diğer\x0a813.02|Temsili Ağırlamalar (Yemek, Araç Vb.)\x0a813.03|Sportif Faaliyetler\x0a813.99|Diğer\x0a814|Kampanyalar\x0a815|Sosyal Yardımlar\x0a819|İdari Ve Sosyal İşlerle İlgili Diğer İşler\x0a820|Tanıtım Ve Yayın İşleri (Genel)\x0a821|Kültür, Tanıtım İşleri\x0a821.01|Fuar\x0a821.02|Sergi\x0a821.03|Festivaller\x0a821.04|Tur Ve Gezi\x0a821.05|Yarışma\x0a821.06|Gösteri Ve Konserler\x0a821.07|Özel Gün Ve Haftalar\x0a821.99|Diğer\x0a823|Reklam Ve İlan İşleri\x0a823.01|Reklam İşleri\x0a823.02|İlan İşleri\x0a823.99|Diğer\x0a824|Yayın İşleri\x0a824.01|Kitap\x0a824.01.01|Teklifler\x0a824.01.02|Değerlendirmeler\x0a824.01.03|Yayın Hazırlık İşleri\x0a824.01.04|Telif İşleri\x0a824.01.05|İntihal\x0a824.01.99|Diğer\x0a824.02|Dergi\x0a824.02.01|Teklifler\x0a824.02.02|Değerlendirmeler\x0a824.02.03|Yayın Hazırlık İşleri\x0a824.02.04|Telif İşleri\x0a824.02.05|İntihal\x0a824.02.99|Diğer\x0a824.03|Broşür\x0a824.03.01|Teklifler\x0a824.03.02|Değerlendirmeler\x0a824.03.03|Yayın Hazırlık İşleri\x0a824.03.04|Telif İşleri\x0a824.03.05|İntihal\x0a824.03.99|Diğer\x0a824.04|Matbu Evrak\x0a824.04.01|Teklifler\x0a824.04.02|Değerlendirmeler\x0a824.04.03|Yayın Hazırlık İşleri\x0a824.04.04|Telif İşleri\x0a824.04.05|İntihal\x0a824.04.99|Diğer\x0a824.05|Takvim Ve Ajanda\x0a824.05.01|Teklifler\x0a824.05.02|Değerlendirmeler\x0a824.05.03|Yayın Hazırlık İşleri\x0a824.05.04|Telif İşleri\x0a824.05.05|İntihal\x0a824.05.99|Diğer\x0a824.06|Bülten\x0a824.06.01|Teklifler\x0a824.06.02|Değerlendirmeler\x0a824.06.03|Yayın Hazırlık İşleri\x0a824.06.04|Telif İşleri\x0a824.06.05|İntihal\x0a824.06.99|Diğer\x0a824.07|Resmi Doküman\x0a824.07.01|Teklifler\x0a824.07.02|Değerlendirmeler\x0a824.07.03|Yayın Hazırlık İşleri\x0a824.07.04|Telif İşleri\x0a824.07.05|İntihal\x0a824.07.99|Diğer\x0a824.08|Ses Ve Görüntü Malzemeleri\x0a824.08.01|Teklifler\x0a824.08.02|Değerlendirmeler\x0a824.08.03|Yayın Hazırlık İşleri\x0a824.08.04|Telif İşleri\x0a824.08.05|İntihal\x0a824.08.99|Diğer\x0a824.99|Diğer\x0a825|Basım, Depolama Ve Dağıtım İşleri\x0a825.01|Basım\x0a825.02|Depolama\x0a825.03|Dağıtım\x0a825.03.01|Yayın Talepleri\x0a825.03.02|Yardım Ve Bağış\x0a825.03.03|Abonelik Ve Satış\x0a825.03.99|Diğer\x0a825.99|Diğer\x0a828|Tercüme İşleri\x0a839|Tanıtım Ve Yayınla İlgili Diğer İşler\x0a840|Mali İşler (Genel)\x0a841|Bütçe Hazırlama Ve Uygulama\x0a841.01|Bütçe Hazırlık Çalışmaları\x0a841.01.01|Bütçe\x0a841.01.02|Ek Bütçe\x0a841.01.03|Geçici Bütçe\x0a841.01.99|Diğer\x0a841.02|Bütçe Uygulamaları\x0a841.02.01|Ödenek Talep Ve Göndermeleri\x0a841.02.02|Serbest Bırakma\x0a841.02.03|Ahp/Afp Vizeleri\x0a841.02.04|Ahp/Afp Revizeleri\x0a841.02.05|Aktarmalar\x0a841.02.06|Ek Ödenekler\x0a841.02.07|Ödenek Devri\x0a841.02.08|Ödenek İptalleri\x0a841.02.09|İlama Bağlı Borçlar\x0a841.02.10|Yedek Ödenekler\x0a841.02.11|Tenkisler\x0a841.02.12|Revize İşlemleri\x0a841.02.13|Akreditif Ve Taahhüt Artıkları\x0a841.02.14|Avanslar, Krediler, Mahsuplar\x0a841.02.15|Öz Gelirler\x0a841.02.16|Gelir Red Ve İadeleri\x0a841.02.17|Tahakkuk Ve Ödeme İşleri\x0a841.02.99|Diğer\x0a841.99|Diğer\x0a843|Mizan, Bilanço Ve Kesin Hesap İşleri\x0a843.01|Mizan\x0a843.02|Bilanço\x0a843.03|Kesin Hesap\x0a843.04|Bütçe Dönem Gerçekleştirme Raporları\x0a843.05|Tablolar\x0a843.05.01|Finansal Tablolar\x0a843.05.02|Gelir Tabloları\x0a843.05.03|Vaziyet Tabloları\x0a843.05.04|Günlük Ödeme Planları\x0a843.05.05|Nakit Akım Tabloları\x0a843.05.99|Diğer\x0a843.99|Diğer\x0a845|Sayıştay İncelemeleri\x0a845.01|Sorgu\x0a845.02|İlam\x0a845.03|Raporlama\x0a845.03.01|Uygunluk Bildirimi\x0a845.03.02|Performans Raporları\x0a845.03.99|Diğer\x0a845.99|Diğer\x0a846|Emanet İşleri\x0a846.01|Vergi\x0a846.02|Kefalet\x0a846.03|İcra\x0a846.04|Sendika\x0a846.99|Diğer\x0a849|Banka İşlemleri\x0a849.01|Ödeme Talimatları\x0a849.02|Repo Ve Faiz İşlemleri\x0a849.03|Kambiyo İşlemleri\x0a849.04|Tahsilatlar\x0a849.05|Mutabakatlar\x0a849.06|Ekstre Ve Dekontlar\x0a849.99|Diğer\x0a850|Kıymetli Evrak İşlemleri\x0a851|Finansman Ve Fon Yönetimi İşleri\x0a851.01|Finansman Programları\x0a851.02|Gelir Gider\x0a851.03|Kar Tevzii\x0a851.04|Sermaye\x0a851.99|Diğer\x0a853|Kredi İşlemleri\x0a853.01|Yurtdışı Krediler\x0a853.01.01|Geri Ödemeler\x0a853.01.02|Kur Farkları\x0a853.01.03|Gecikme Faizi\x0a853.01.99|Diğer\x0a853.02|Yurtiçi Krediler\x0a853.03|Hazineye Borçlar\x0a853.99|Diğer\x0a855|Borç Ve Alacak İşlemleri\x0a855.01|Kuruluşun Borç Ve Alacakları\x0a855.02|Gerçek Ve Tüzel Kişilerin Borç Ve Alacakları\x0a855.99|Diğer\x0a856|Harcama Yetkilileri Ve Gerçekleştirme Görevlileri\x0a857|Saymanlık Ve Sayman Bildirimleri\x0a858|İdari Yaptırım (Para Cezaları)\x0a869|Mali Konularda Diğer İşler\x0a870|Özel Kalem Ve Protokol İşleri (Genel)\x0a871|Makamın Konuşma Ve Açıklamaları\x0a872|Randevu Talepleri\x0a873|Temas Ve Ziyaretler\x0a873.01|Gezi Ve Ziyaret Programları\x0a873.02|Yabancı Temsilciler\x0a873.99|Diğer\x0a874|Günlük Programlar\x0a876|Davet Ve Tebrikler\x0a876.01|Özel Mektuplar\x0a876.02|Davetiyeler\x0a876.03|Tebrikler\x0a876.99|Diğer\x0a877|Protokol İşleri\x0a878|Resepsiyonlar\x0a879|Rezervasyonlar\x0a880|Törenler\x0a899|Özel Kalem Ve Protokolle İlgili Diğer İşler\x0a900|Personel İşleri (Genel)\x0a901|İş İstekleri\x0a902|Personel Alımı\x0a902.01|Alım Talepleri\x0a902.02|Alım İzinleri\x0a902.03|Sınavlar\x0a902.99|Diğer\x0a903|Personel Özlük İşleri\x0a903.01|İşe Giriş Belgeleri\x0a903.02|Atama İşleri\x0a903.02.01|Asaleten\x0a903.02.02|Vekaleten\x0a903.02.03|Tedviren\x0a903.02.99|Diğer\x0a903.03|Terfi Ve İntibak İşlemleri\x0a903.03.01|Terfi İşleri\x0a903.03.02|İntibak İşleri\x0a903.03.02.01|Hizmet Değerlendirmesi\x0a903.03.02.02|Öğrenim Değerlendirmesi\x0a903.03.02.99|Diğer\x0a903.03.99|Diğer\x0a903.04|Hizmet Cetveli Ve Hizmet Belgesi\x0a903.05|İzin İşleri\x0a903.05.01|Yıllık\x0a903.05.02|Sıhhi\x0a903.05.03|Mazeret\x0a903.05.04|Ücretsiz\x0a903.05.05|Yurtdışı\x0a903.05.99|Diğer\x0a903.06|Görevden Ayrılma\x0a903.06.01|Emeklilik\x0a903.06.02|İstifa\x0a903.06.03|Görevden Çekilmiş Sayılma\x0a903.06.04|Görevden Çıkarılma\x0a903.06.05|Vefat\x0a903.06.99|Diğer\x0a903.07|Görevlendirmeler\x0a903.07.01|Kurumiçi\x0a903.07.02|Kurumdışı\x0a903.07.03|Yurtdışı\x0a903.07.04|Ek Görevler\x0a903.07.05|Rotasyon\x0a903.07.99|Diğer\x0a903.08|Mükafat Ve Cezalar\x0a903.08.01|Ödül İşleri\x0a903.08.02|Disiplin İşleri\x0a903.08.99|Diğer\x0a903.09|Sicil İşleri\x0a903.09.01|Sicil Raporları\x0a903.09.02|Mal Beyannamesi\x0a903.09.99|Diğer\x0a903.10|Aile Yardımı Bildirimi\x0a903.11|Askerlik İşlemleri\x0a903.12|Hizmet Borçlanması\x0a903.13|Kimlik Ve Giriş Kartı İşlemleri\x0a903.14|Sağlık Karnesi\x0a903.99|Diğer\x0a907|Kadro Pozisyon İşleri\x0a907.01|Teklif\x0a907.02|İptal Ve İhdas\x0a907.03|Tenkis-Tahsis\x0a907.04|Vize İşlemleri\x0a907.99|Diğer\x0a912|Pasaport İşlemleri\x0a912.01|Diplomatik\x0a912.02|Hususi\x0a912.03|Hizmet\x0a912.04|Emekli\x0a912.99|Diğer\x0a914|Yabancı Uyruklu Personel İstihdamı\x0a915|Sendikalarla İlgili İşler\x0a915.01|İşveren Sendikaları\x0a915.02|Memur Sendikaları\x0a915.02.01|Üyelik Ve Dayanışma Aidatı\x0a915.02.02|Kurum İdari Kurulu Ve Yüksek İdari Kurul Toplantıları\x0a915.02.03|Yetkili Sendika Tespiti\x0a915.02.04|Temsilcilik\x0a915.02.99|Diğer\x0a915.03|İşçi Sendikaları\x0a915.03.01|Üyelik Ve Dayanışma Aidatı\x0a915.03.02|Temsilcilik\x0a915.03.03|İzin İşlemleri\x0a915.03.04|Toplu Sözleşme Ve Uygulama İşleri\x0a915.03.04.01|Müzakereler\x0a915.03.04.02|Uyuşmazlık Hali\x0a915.03.04.03|Grev - Lokavt\x0a915.03.04.04|Teşmil İşlemleri\x0a915.03.04.99|Diğer\x0a915.03.99|Diğer\x0a915.99|Diğer\x0a917|Sosyal Güvence Kapsamında Yapılan İşler\x0a917.01|Sigorta Primleri Bildirgeleri\x0a917.02|Tescil İşlemleri (İşe Giriş Bildirgeleri)\x0a917.03|İşçi Bildirim Listeleri\x0a917.99|Diğer\x0a918|Çalışan Sağlığı Ve İş Güvenliği\x0a918.01|İş Güvenliği\x0a918.02|Çalışan Sağlığı\x0a918.02.01|Meslek Hastalıkları\x0a918.02.02|İş Kazaları\x0a918.02.99|Diğer\x0a918.99|Diğer\x0a920|Performans Değerlendirme\x0a929|Personelle İlgili Diğer İşler\x0a930|Satınalma Ve Satış İşleri (Genel)\x0a933|Firma Bilgileri\x0a933.01|Yurtiçi\x0a933.02|Yurtdışı\x0a933.03|Yasaklı Firmalar\x0a933.99|Diğer\x0a934|Satınalma İşleri\x0a934.01|Mal Ve Malzeme Alımı\x0a934.01.01|Ön İzin Belgesi\x0a934.01.02|İhale Onay Belgesi\x0a934.01.03|Yaklaşık Maliyet Hesabı\x0a934.01.04|Duyurular\x0a934.01.05|Kik Onayı\x0a934.01.06|İhale İlan Tutanağı\x0a934.01.07|İlan Metni\x0a934.01.08|Şartnameler\x0a934.01.09|İhale Evrakının Teslim Alındığına Dair Tutanak\x0a934.01.10|Zarf Açma Ve Belge Kontrol Tutanağı\x0a934.01.11|İsteklilerce Teklif Edilen Fiyatlar Tutanağı\x0a934.01.12|İhale Komisyonu Ara Kararı\x0a934.01.13|İhale Komisyonu Kesin Kararı\x0a934.01.14|Yasaklı Olup Olmadığına Dair Kik Teyit Belgesi\x0a934.01.15|Firmalara Gönderilen Sonuç Bildirimleri\x0a934.01.16|İtirazlar\x0a934.01.17|Sözleşme\x0a934.01.18|Kesin Teminat\x0a934.01.19|Ödeme İşleri\x0a934.01.99|Diğer\x0a934.02|Hizmet\x0a934.02.01|Ön İzin Belgesi\x0a934.02.02|İhale Onay Belgesi\x0a934.02.03|Yaklaşık Maliyet Hesabı\x0a934.02.04|Duyurular\x0a934.02.05|Kik Onayı\x0a934.02.06|İhale İlan Tutanağı\x0a934.02.07|İlan Metni\x0a934.02.08|Şartnameler\x0a934.02.09|İhale Evrakının Teslim Alındığına Dair Tutanak\x0a934.02.10|Zarf Açma Ve Belge Kontrol Tutanağı\x0a934.02.11|İsteklilerce Teklif Edilen Fiyatlar Tutanağı\x0a934.02.12|İhale Komisyonu Ara Kararı\x0a934.02.13|İhale Komisyonu Kesin Kararı\x0a934.02.14|Yasaklı Olup Olmadığına Dair Kik Teyit Belgesi\x0a934.02.15|Firmalara Gönderilen Sonuç Bildirimleri\x0a934.02.16|İtirazlar\x0a934.02.17|Sözleşme\x0a934.02.18|Kesin Teminat\x0a934.02.19|Ödeme İşleri\x0a934.02.99|Diğer\x0a934.03|Gayrimenkul\x0a934.03.01|Ön İzin Belgesi\x0a934.03.02|İhale Onay Belgesi\x0a934.03.03|Yaklaşık Maliyet Hesabı\x0a934.03.04|Duyurular\x0a934.03.05|Kik Onayı\x0a934.03.06|İhale İlan Tutanağı\x0a934.03.07|İlan Metni\x0a934.03.08|Şartnameler\x0a934.03.09|İhale Evrakının Teslim Alındığına Dair Tutanak\x0a934.03.10|Zarf Açma Ve Belge Kontrol Tutanağı\x0a934.03.11|İsteklilerce Teklif Edilen Fiyatlar Tutanağı\x0a934.03.12|İhale Komisyonu Ara Kararı\x0a934.03.13|İhale Komisyonu Kesin Kararı\x0a934.03.14|Yasaklı Olup Olmadığına Dair Kik Teyit Belgesi\x0a934.03.15|Firmalara Gönderilen Sonuç Bildirimleri\x0a934.03.16|İtirazlar\x0a934.03.17|Sözleşme\x0a934.03.18|Kesin Teminat\x0a934.03.19|Ödeme İşleri\x0a934.03.99|Diğer\x0a934.99|Diğer\x0a939|Müşteri İlişkileri\x0a939.01|Bayiler\x0a939.02|Acentalar\x0a939.99|Diğer\x0a940|Fiyatların Belirlenmesi-Tarifeler\x0a941|Satış Talepleri Ve Teyitleri\x0a942|Satış İşlemleri\x0a942.01|Yurt Dışı Satışlar\x0a942.01.01|Direkt Satışlar\x0a942.01.02|İhracat Sevkiyatları\x0a942.01.03|İhraç Kayıtlı Satışlar\x0a942.01.04|Diib Kapsamında Satışlar\x0a942.01.99|Diğer\x0a942.02|Yurt İçi Satışlar\x0a942.02.01|Kontratlı Satışlar\x0a942.02.02|Cari Satışlar\x0a942.02.03|İhaleli Satışlar\x0a942.02.04|Elektronik Ticaret Şeklinde Satışlar\x0a942.02.99|Diğer\x0a942.03|Hurda Ve İhtiyaç Fazlası Malzeme Satışları\x0a942.03.01|İhtiyaç Fazlası Malzeme Satışı\x0a942.03.02|Ekonomik Ömrünü Tamamlamış Malzeme Satışı\x0a942.03.99|Diğer\x0a942.99|Diğer\x0a944|Gümrük İşlemleri\x0a945|Akreditif İşlemleri\x0a946|Ticari Belgeler\x0a946.01|İrsaliyeler\x0a946.02|Satış Fişleri\x0a946.03|Faturalar\x0a946.04|Yükleme Talimatları\x0a946.99|Diğer\x0a947|Stok Kontrol İşlemleri\x0a947.01|Malzeme Giriş İşlemleri\x0a947.02|Malzeme Çıkış İşlemleri\x0a947.03|Malzeme Transfer İşlemleri\x0a947.04|Malzeme İade İşlemleri\x0a947.05|Malzemelerin Kayıttan Düşülmesi İşlemleri\x0a947.99|Diğer\x0a948|Tanıtım Ve Pazarlama\x0a948.01|Tasarım Ve Markalama\x0a948.01.01|Tasarım\x0a948.01.02|Markalama\x0a948.01.99|Diğer\x0a948.02|Pazar Araştırması\x0a948.02.01|Veri Toplama\x0a948.02.02|Analiz Ve Değerlendirme\x0a948.02.99|Diğer\x0a948.03|Kaçak, Taklit, Sahte Ürün\x0a948.03.01|Kaçak\x0a948.03.02|Taklit\x0a948.03.03|Sahte\x0a948.03.99|Diğer\x0a948.99|Diğer\x0a949|Satınalma Ve Satışla İlgili Diğer İşler Güvenlik İşleri, Afet Ve Acil Durum Yönetimi Ve\x0a950|Topyekün Savunma Sivil Hizmetleri (Genel)\x0a951|Güvenlik İşleri\x0a951.01|İç Güvenlik\x0a951.01.01|İç Güvenlik Strateji Belgesi\x0a951.01.02|Eylem Planları\x0a951.01.03|İstihbarat Raporları\x0a951.01.04|Bilgilendirme Faaliyetleri\x0a951.01.05|İşbirliği\x0a951.01.06|İnceleme Ve Araştırma\x0a951.01.07|Radyo Ve Televizyon Yayınları\x0a951.01.08|Ekonomi Ve Sosyal Konular\x0a951.01.09|Siber Güvenlik\x0a951.01.10|İklim Güvenliği\x0a951.01.11|Gıda Güvenliği\x0a951.01.12|Su Ve Doğal Kaynak Güvenliği\x0a951.01.13|Enerji Güvenliği\x0a951.01.14|Bilim Ve Teknoloji Güvenliği\x0a951.01.15|Sıkıyönetim Ve Olağanüstü Hal\x0a951.01.16|Acil Durum/Kriz Yönetimi\x0a951.01.16.01|Dış Tehdit Kaynaklı\x0a951.01.16.02|Yaygın Şiddet Kaynaklı\x0a951.01.16.03|Doğal Afet Kaynaklı\x0a951.01.16.04|Sağlık Kaynaklı\x0a951.01.16.05|Ekonomik Kaynaklı\x0a951.01.16.99|Diğer\x0a951.01.99|Diğer\x0a951.02|Dış Güvenlik\x0a951.02.01|Dış Güvenlik Strateji Belgesi\x0a951.02.02|Eylem Planları\x0a951.02.03|İstihbarat Raporları\x0a951.02.04|Bilgilendirme Faaliyetleri\x0a951.02.05|İşbirliği\x0a951.02.06|İnceleme Ve Araştırma\x0a951.02.07|Silahların Kontrolü Ve Yayılmanın Önlenmesi\x0a951.02.08|Nükleer Enerjinin Barışçıl Kullanımı\x0a951.02.09|Barışı Destekleme Ve Koruma Harekâtları\x0a951.02.10|Dış Türkler\x0a951.02.99|Diğer\x0a951.03|Terörle Mücadele\x0a951.03.01|Terörle Mücadele Strateji Belgesi\x0a951.03.02|Eylem Planları\x0a951.03.03|İstihbarat Raporları\x0a951.03.04|İşbirliği Ve Koordinasyon\x0a951.03.05|Stratejik Bilgi Desteği\x0a951.03.06|Kamuoyu Bilgilendirme Ve Halkla İletişim\x0a951.03.07|Sosyal, Ekonomi, Eğitim Ve Kültür Çalışmaları\x0a951.03.08|Terör Örgütleri\x0a951.03.08.01|Bölücü Örgütler\x0a951.03.08.02|Yıkıcı Örgütler\x0a951.03.08.03|Dini İstismar Eden Örgütler\x0a951.03.08.04|Uluslararası Örgütler\x0a951.03.08.99|Diğer\x0a951.03.09|İnceleme Ve Araştırma\x0a951.03.10|İzleme Ve Değerlendirme\x0a951.03.11|Terörle Mücadele Raporu\x0a951.03.12|İnceleme/Denetleme\x0a951.03.99|Diğer\x0a951.04|Koruyucu Güvenlik\x0a951.04.01|Sabotajlara Karşı Koruma Planları, Koruma Planları\x0a951.04.02|Nöbetçi Memurluğu İşleri\x0a951.04.03|Koruyucu Güvenlik Denetleme Sonuç Raporları\x0a951.04.04|Yabancı Uyruklu Personel İle İlgili İşler\x0a951.04.05|Mülteciler Ve Sığınmacılar\x0a951.04.06|Özel Güvenlik Teşkilatı İle İlgili İşler\x0a951.04.07|Özel Güvenlik Bölgeleri İle İlgili İşler\x0a951.04.08|İstihbarat Ve Kaçakçılık İle İlgili İşler\x0a951.04.09|Patlayıcı Maddeler Ve Ateşli Silahlar İle İlgili İşler\x0a951.04.10|Güvenlik Soruşturmaları Ve Arşiv Araştırması\x0a951.04.11|Fiziki Emniyet Tedbirleri\x0a951.04.12|Evrak Güvenliği\x0a951.04.13|Haberleşme Güvenliği\x0a951.04.14|Yangın Önleme Ve Korunma\x0a951.04.15|Önemli Tesis Kriterleri\x0a951.04.99|Diğer\x0a951.99|Diğer\x0a952|Afet Ve Acil Durum Yönetimi\x0a952.01|Planlama Ve Risk/Zarar Azaltma İle İlgili İşler\x0a952.01.01|Ulusal Afet Yönetimi Strateji Belgesi\x0a952.01.02|Ulusal Deprem Strateji Ve Eylem Planı(Udsep-2023)\x0a952.01.03|Afet Ve Acil Durum Planları\x0a952.01.04|Risk Ve Zarar Azaltma İşleri\x0a952.01.04.01|Risk Belirleme\x0a952.01.04.02|Afet Etüdleri\x0a952.01.04.03|Genel Hayata Etkililik/Etkisizlik\x0a952.01.04.04|Afete Maruz Bölge\x0a952.01.04.05|Jeolojik Ve Jeoteknik Etüdler\x0a952.01.04.06|Mikrobölgeleme Etüdleri\x0a952.01.04.07|Meteorolojik Etüdler\x0a952.01.04.08|İklim Değişikliği\x0a952.01.04.09|İnsan Kaynaklı Afetler\x0a952.01.04.10|Tehlike/Risk Haritaları\x0a952.01.04.11|Yapı Analizleri\x0a952.01.04.12|Afet Önlemleri\x0a952.01.04.13|Kentsel Dönüşüm\x0a952.01.04.14|Afet Tahmini Ve Değerlendirme Çalışmaları\x0a952.01.04.15|Afet Kültürü Ve Bilinci\x0a952.01.04.99|Diğer\x0a952.01.05|Erken Uyarı, Gözlem Ve Tahmin Sistemleri\x0a952.01.05.01|Erken Uyarı Sistemleri\x0a952.01.05.02|Gözlem Sistemleri\x0a952.01.05.03|Tahmin Sistemleri\x0a952.01.05.99|Diğer\x0a952.01.99|Diğer\x0a952.02|Afet Ve Acil Durum Haberleşmesi\x0a952.02.01|Haberleşme Tesisleri/Merkezleri\x0a952.02.01.01|Afad Merkezleri\x0a952.02.01.02|Mobil Haberleşme Merkezleri\x0a952.02.01.99|Diğer\x0a952.02.02|Telsiz Sistemleri\x0a952.02.02.01|Vhf\x0a952.02.02.02|Uhf\x0a952.02.02.03|Hf\x0a952.02.02.99|Diğer\x0a952.02.03|Uydu Haberleşme Sistemleri\x0a952.02.03.01|Uydu Telefonları\x0a952.02.03.02|Upling Sistemleri\x0a952.02.03.99|Diğer\x0a952.02.04|Kablolu Ve Gsm Haberleşme Sistemleri\x0a952.02.04.01|Kablo Altyapılı Sistemler\x0a952.02.04.02|Gsm Altyapılı Sistemler\x0a952.02.04.03|Özel Santraller\x0a952.02.04.99|Diğer\x0a952.02.05|Kesintisiz Ve Güvenli İletişim\x0a952.02.06|İletişim Altyapıları\x0a952.02.06.01|Bilgi Sistemleri İletişim Altyapıları\x0a952.02.06.02|İkaz Ve Alarm Sistemleri İletişim Altyapıları\x0a952.02.06.03|Erken Uyarı Sistemleri İletişim Altyapıları\x0a952.02.06.99|Diğer\x0a952.02.07|Sistem İnceleme Ve Denetleme\x0a952.02.07.01|Sistem Test Raporları\x0a952.02.07.02|Çevrim Sonuçları\x0a952.02.07.03|Denetleme Raporu\x0a952.02.07.99|Diğer\x0a952.02.08|Bilgi Sistemleri\x0a952.02.09|Afet Ve Acil Durum Sigorta İşleri\x0a952.02.99|Diğer\x0a952.03|Afet Ve Acil Durum Müdahale Ve Yardım İşleri\x0a952.03.01|Başbakanlık Afet Ve Acil Durum Yönetimi Merkezi\x0a952.03.02|Afet Ve Acil Durum Yönetimi Merkezleri\x0a952.03.03|Afet Ve Acil Durum İlanı\x0a952.03.03.01|Deprem, Sel, Fırtına, Heyelan, Çığ\x0a952.03.03.02|İltica Ve Nüfus Hareketleri\x0a952.03.03.03|Yangınlar Ve Kazalar\x0a952.03.03.04|Kbrn Kazaları Ve Olayları\x0a952.03.03.05|Tehlikeli Ve Salgın Hastalıklar\x0a952.03.03.99|Diğer\x0a952.03.04|Duyuru\x0a952.03.05|Tahliye/Transfer\x0a952.03.06|Acil Müdahale\x0a952.03.06.01|İhtiyaç Belirleme Ve Talep/Tahsis\x0a952.03.06.02|Tahliye/Transfer\x0a952.03.06.03|Görevlendirme\x0a952.03.06.99|Diğer\x0a952.03.07|Haberleşme\x0a952.03.08|Güvenlik\x0a952.03.09|İlk Yardım\x0a952.03.10|Arama-Kurtarma\x0a952.03.11|Beslenme(İaşe)\x0a952.03.12|Barınma(İbate)\x0a952.03.13|Acil Yardım\x0a952.03.13.01|Ödenek Tahsisi\x0a952.03.13.02|Ödenek Tahsisi Süre Uzatımı\x0a952.03.13.03|Yurtiçi Ayni Yardım\x0a952.03.13.04|Yurtdışı Ayni Yardım\x0a952.03.13.05|Yurtdışı Nakdi Yardım\x0a952.03.13.99|Diğer\x0a952.03.14|Yardım Kampanyası\x0a952.03.14.01|Yurtiçi\x0a952.03.14.02|Yurtdışı\x0a952.03.14.99|Diğer\x0a952.03.15|Afet Ve Acil Durum Ekip Ve Ekipmanları\x0a952.03.15.01|Acil Kurtarma Ve Yardım\x0a952.03.15.02|İlk Yardım\x0a952.03.15.03|İtfaiye\x0a952.03.15.04|Sivil Savunma\x0a952.03.15.99|Diğer\x0a952.03.16|Gönüllüler Ve Stk\x27Lar\x0a952.03.16.01|Gönüllü Teşviki\x0a952.03.16.02|Akreditasyon (İlkyardım, Arama-Kurtarma Vs.)\x0a952.03.16.99|Diğer\x0a952.03.99|Diğer\x0a952.04|İyileştirme Çalışmaları\x0a952.04.01|Geçici İskan\x0a952.04.01.01|Yer Belirleme\x0a952.04.01.02|Geçici İskan Yapıları\x0a952.04.01.03|Kira Yardımı\x0a952.04.01.04|Sosyal, Sağlık Ve Eğitim Hizmetleri\x0a952.04.01.99|Diğer\x0a952.04.02|Afetten Zarar Görenlere Karşılıksız Yardım\x0a952.04.02.01|Sakatlık Ve Ölüm\x0a952.04.02.02|Konut/İşyeri Yardımı\x0a952.04.02.99|Diğer\x0a952.04.03|Kredi Yardımı\x0a952.04.04|Yerel Yönetimlere Ödenek Aktarımı\x0a952.04.04.01|Belediyeler\x0a952.04.04.02|İl Özel İdareleri\x0a952.04.04.99|Diğer\x0a952.04.99|Diğer\x0a952.05|Hasar Tespiti\x0a952.05.01|Hasar Tespit Raporu\x0a952.05.01.01|Ön Hasar Tespiti Raporu\x0a952.05.01.02|Kesin Hasar Tespiti\x0a952.05.01.03|İtirazlar Hasar Tespiti\x0a952.05.01.04|Yargı Kararıyla Düzenlenen Hasar Tespit Raporu\x0a952.05.01.99|Diğer\x0a952.05.02|Boşaltma, Yıkım\x0a952.05.99|Diğer\x0a952.06|Hak Sahipliği\x0a952.06.01|Talep Ve Taahhütname\x0a952.06.02|Hak Sahipliği İnceleme Komisyonu\x0a952.06.03|Hak Sahipliği Tespiti\x0a952.06.04|Borçlandırma\x0a952.06.05|Hak Sahipliğinin Sona Ermesi Ve Borcun Muacceliyeti\x0a952.06.06|Hak Sahipliğine Engel Durumlar\x0a952.06.07|Artan Konutlar\x0a952.06.99|Diğer\x0a952.07|Yerleşim Yeri Tespiti Ve Artan Arsalar\x0a952.07.01|Yer Seçimi\x0a952.07.02|Artan Arsalar\x0a952.07.99|Diğer\x0a952.99|Diğer\x0a953|Topyekün Savunma Sivil Hizmetleri\x0a953.01|Sivil Savunma Hizmetleri\x0a953.01.01|Sivil Savunma Planlama\x0a953.01.01.01|İl Ve İlçe Sivil Savunma Planları\x0a953.01.01.02|Daire Ve Müessese Sivil Savunma Planları\x0a953.01.01.03|Tahliye Planları\x0a953.01.01.04|Kabul Planları\x0a953.01.01.05|Sivil Savunma Arama Ve Kurtarma Birlikleri Harekat Ve İntikal Planları, Haber Merkezi Talimatı\x0a953.01.01.99|Diğer\x0a953.01.02|Sivil Savunma Servis Ve Yükümlüleri İşleri\x0a953.01.03|Sivil Savunma Gönüllüleri İşleri\x0a953.01.04|Sivil Toplum Kuruluşları (Stk) İle İlgili İşler\x0a953.01.05|Sivil Savunma Sevk Ve Harekatı İşleri\x0a953.01.06|Kamu Kurum Ve Kuruluşları İle Sivil Toplum Kuruluşlarının (Stk) Sivil Savunma Harekatı İle İlgili Ko\x0a953.01.07|Haber Alma Ve Yayma, İkaz Ve Alarm İşleri\x0a953.01.07.01|Haber Alma Ve Yayma İşleri\x0a953.01.07.02|İkaz Ve Alarm Merkezleri İle İlgili İşler\x0a953.01.07.03|Siren Sistemi İle İlgili İşler\x0a953.01.07.99|Diğer\x0a953.01.08|Kimyasal, Biyolojik, Radyolojik Ve Nükleer Savunma İşl.\x0a953.01.08.01|Kimyasal Savunma\x0a953.01.08.02|Biyolojik Savunma\x0a953.01.08.03|Radyolojik Ve Nükleer Savunma\x0a953.01.08.04|Dekontaminasyon (Arındırma) İşleri\x0a953.01.08.99|Diğer\x0a953.01.09|Sivil Savunma Araç, Gereç Ve Malzemelere Ait İşler\x0a953.01.99|Diğer\x0a953.02|Seferberlik Ve Savaş Hali Hazırlıkları\x0a953.02.01|Milli Alarm\x0a953.02.01.01|Alarm Tedbirleri İlanında Yapılacak Faaliyetler\x0a953.02.01.02|Nato Alarm Sistemi\x0a953.02.01.03|Alarm Kod Kelimeleri Ve Anlamları\x0a953.02.01.04|Alarm Kod İşlem Ve Görevlileri\x0a953.02.01.05|Milli Alarm Sistemi Eğitimleri\x0a953.02.01.06|Seferberlik İlanı Ve Duyuru İşlemleri\x0a953.02.01.07|24 Saat Süreli Çalışma Planları\x0a953.02.01.99|Diğer\x0a953.02.02|Lojistik\x0a953.02.02.01|Savaş Görev Planları\x0a953.02.02.02|Savaş Hasarı Onarım Planları\x0a953.02.02.03|Araç Seferberliği Ve Erteleme İşleri\x0a953.02.02.04|Trafikte Kaydı Olmayan Özel Sektör İş Makinelerinin Tespiti\x0a953.02.02.05|Mal Ve Hizmet Seferberliği İşleri\x0a953.02.02.06|Kaynak Planlama Faaliyetleri\x0a953.02.02.07|İl Ve İlçe Kaynak Sayım İşleri\x0a953.02.02.08|Milli Müdafaa Mükellefiyeti\x0a953.02.02.09|Ekonomik/Stratejik Tahrip Hedefleri Planlama İşleri\x0a953.02.02.10|Kriz/Harekat Merkezi İle İlgili İşler\x0a953.02.02.11|Haritalar\x0a953.02.02.12|Denetlemeler\x0a953.02.02.13|Tsk Harekat Kontrolüne Girecek Kamu Kurum Ve Kuruluşları\x0a953.02.02.14|Tsk Lojistik Seferberlik Dosyası\x0a953.02.02.99|Diğer\x0a953.02.03|Personel Seferberlik\x0a953.02.03.01|Sevk Tehir İşleri\x0a953.02.03.02|Personel Ve Kadro Erteleme İşleri\x0a953.02.03.03|Yasal Yaş Sınırları\x0a953.02.03.04|Sefer Görev Emirleri\x0a953.02.03.05|İnsan Gücü Planlaması\x0a953.02.03.06|Bedelli Askerlik\x0a953.02.03.07|Erteleme Sonuç Raporları\x0a953.02.03.99|Diğer\x0a953.02.04|Seferberlik Savaş Hali Planları\x0a953.02.04.01|Genel Planlar\x0a953.02.04.02|Özel Planlar\x0a953.02.04.03|Detay Planlar\x0a953.02.04.04|Planlama Ve Koordinasyon Kurulu İşleri\x0a953.02.04.05|Seferberlik Ve Savaş Hali Hazırlıkları Yıllık Faaliyet Raporu\x0a953.02.04.99|Diğer\x0a953.02.05|Milli Güvenlik Kurulu Genel Sekreterliği Tetkik Gezileri\x0a953.02.05.01|Tetkik Gezisi Planlaması\x0a953.02.05.02|Tetkik Gezisi Sonuç Raporu\x0a953.02.05.99|Diğer\x0a953.02.06|Seferberlik Ve Savaş Hali Hazırlıkları Oryantasyon Eğitimi\x0a953.02.07|Nato Sivil Olağanüstü Hal Planlaması\x0a953.02.07.01|Planlama Faaliyetleri\x0a953.02.07.02|Genel Kurul Toplantıları\x0a953.02.07.03|Sonuç Raporu\x0a953.02.07.99|Diğer\x0a953.02.99|Diğer\x0a953.03|Sığınaklar\x0a953.03.01|Genel Sığınaklar\x0a953.03.02|Özel Sığınaklar\x0a953.03.03|Tespit Ve Denetim İşleri\x0a953.03.04|Kayıt Ve İstatistik İşleri\x0a953.03.99|Diğer\x0a953.99|Diğer\x0a954|Tatbikatlar\x0a954.01|Uluslararası Ve Nato Tatbikatları\x0a954.02|Milli Tatbikatlar\x0a954.02.01|Seferberlik Ve Savaş Hali Plan Tatbikatları\x0a954.02.02|Milli Kriz/Harekat Yönetimi Tatbikatları\x0a954.02.02.01|Güven Serisi Tatbikatlar\x0a954.02.02.02|Afet/Acil Durum Tatbikatları\x0a954.02.02.99|Diğer\x0a954.02.03|Milli Alarm Sistemi Tatbikatı\x0a954.02.04|Sivil-Asker İşbirliği İle Yapılan Tatbikatlar\x0a954.02.05|Mal Ve Hizmet Seferberliği Tatbikatları\x0a954.02.06|Sivil Savunma Tatbikatları\x0a954.02.06.01|Sivil Savunma Plan Tatbikatı\x0a954.02.06.02|Sivil Savunma Servis Tatbikatı\x0a954.02.06.03|Örnek Sivil Savunma Tatbikatı\x0a954.02.06.04|Arama Ve Kurtarma İntikal Tatbikatı\x0a954.02.06.99|Diğer\x0a954.02.99|Diğer\x0a954.99|Diğer\x0a969|Güvenlik İşleri, Afet Ve Acil Durum Yönetimi Ve Topyekün Savunma Sivil Hizmetleri İle İlgili Diğer İşler', 'opacity', 'paraf', 'Birime Havale seçilemedi — listeden siz seçin', 'type', 'katalog', 'min', 'arrayBuffer', '.99', 'görev eşleşmesi', 'Özet → Konu kodu: ', ' yeni, ', 'tamam', '#actTxt', 'Uyarı: ', 'Evrak Sayı alanı bulunamadı — formu kontrol edin.', '” için “', 'setAttribute', 'Evrak Sayı geçersiz (“', 'tarih', 'gorevler', ' | Nereye: ', '\x00\x00\x00\x00', 'any', 'focus', 'location', 'transaction', 'Yeni kayıt mesajı gelmedi', 'center', '#dirpdf', 'block', 'forEach', 'Şimdi değil', 'exec', 'err', 'Çerçeve sayısı: ', 'text', 'getFile', 'done', 'version', 'onChanged', 'Kabul ediyorum', ' name=', 'iframe,frame', 'Escape', 'term', 'retry', 'Hata: ', 'Öneri listesi gelmedi: ', 'length', 'Upload', 'dosya', '#logdl', 'button', 'Kaydedildi (benzer kayıt seçildi)', '<< /Type /Pages /Kids [3 0 R] /Count 1 >>', 'left', 'fuzzy', ') ═══', '⏭ atlandı', 'resume', '.m span', '.ui-dialog', 'Eklenen üst yazı', 'height', 'li.ui-selectonemenu-item', 'lastChild', 'Hata', '.ui-autocomplete-panel,.ui-selectonemenu-panel,.ui-dialog,[role=listbox],[role=dialog],.ui-overlaypanel', 'isArray', 'recent', '): ', 'pace', 'prototype', 'skipEmpty', 'onclick', '#kat', 'input:not([type=hidden]):not([type=file]):not([type=radio]):not([type=checkbox]):not([type=button]):not([type=submit]),select,textarea,.ui-selectonemenu,.ui-autocomplete,.ui-calendar', 'skip', 'files', 'dir', 'cache', 'onkeydown', 'evrak_kayit_listesi.csv', 'entries', 'fromCharCode', 'Menüde yok: ', ' >>\x0astream\x0a', '--- doc ', 'visibility', ' (ilk kullanımda izin istenebilir)', 'Evet', 'HTMLTextAreaElement', 'Ad Soyad yazın.', 'Arama türü: Kullanıcı seçildi (liste).', 'keydown', '#33425b', '21raTtQb', '#hd', 'Devam için tıklayın', 'Benzer kayıt seçildi; yeni form doğrulanamadı, sonucu kontrol edin.', 'adim', 'every', 'Hazır', 'close', '()<>[]{}/%', 'sort', 'toFixed', 'Konu metni boş (satırdaki Konu kutusunu doldurun)', 'Konu alanı “', 'undefined', 'AJAX/bekleyiniz sürüyor — form kararlı değil', 'splice', 'floor', 'yok', 'label,span,td', 'durum', 'Birime Havale’deki şüpheli değer temizleniyor: “', '.ui-selectonemenu,.ui-autocomplete,.ui-calendar', 'evrak-otonom-host', 'input,.lovItemTitle', 'dataset', 'https://otonomevrak.com/evrak/gizlilik', 'oncomplete', 'reduce', 'TC 11 haneli olmalı', '\x0aendstream\x0aendobj\x0a', 'AÇIK PANEL: ', 'mousemove', 'evrak', 'input', 'evrakOtonom', '\x22Üst Yazı Ekle\x22 bulunamadı', 'Atlandı: ', 'BUTTON', 'Kullanıcı', 'display', 'gonderenPicked', '[data-k=t]', 'PDF’den metin çıkmadı (taranmış olabilir)', 'genel', 'Enter', '_blank', 'firstChild', 'values', 'Onay düğmesi: ', '.ui-autocomplete-panel,.ui-overlaypanel', 'Değer yok: ', '1117512YEESDV', 'lrn', '\x22 val=\x22', '[id*=\x22konuKoduLov\x22 i]', 'has', 'endobj', 'clientY', 'atla', 'endstream', 'DOCUMENT_POSITION_PRECEDING', 'setItem', 'Contents', 'catch', 'Birime Havale kutusu yok', 'konukodulov', 'text/plain;charset=utf-8', ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ', 'gonder', 'dict', '#stop', 'Kişi-Kurum', ' (“', 'Yarım kalan toplu işlem var. İzin için “▶ Kaldığı yerden devam et” düğmesine basın.', 'Arama türü zaten Kullanıcı.', 'learned', 'showDirectoryPicker', 'Resources', 'Çalışıyor', 'benzer', 'st ', 'iso', 'bottom', 'value', 'Gönderen adı yok (Ayarlar → Gönderen / Müdür yardımcıları)', 'pointerdown', 'Ağaç düğmesine tıklanıyor: ', '⚠ Önceki oturum “', 'havaleRules', 'SELECT', 'Menü: Gelen Evrak Kayıt', 'push', 'pop', '__EA_KAYIT_GUARDS__', 'Benzer kayıt seçimi tamamlandı: ', 'Filter', 'Klasörden PDF alınamadı: ', 'isConnected', 'kaydet', 'pointerover', 'A85', 'adresler', 'padEnd', 'result', 'Geldiği Kişi yanında “Kullanıcı” seçeneği bulunamadı; TC doğrudan yazılıyor.', 'cssText', '.pend', '#log', 'map', 'apply', '.pdf', 'ekOrj', 'Kaydet öncesi kontrol: ', 'records', 'input,select,textarea,button,.ui-selectonemenu,.ui-autocomplete', 'object', 'item', 'isler', 'kaynak', 'attachShadow', 'label,td,th,span,legend', 'getElementById', 'objectStore', 'Kapat', 'Sonuç bulunamadı: ', '#lrn', '#s_otoFab', 'run', 'Evrak sayı', '#fab', '#kisiAd', 'active', 'function', 'split', 'sec', 'HTMLInputElement', 'Kaydet zaten basıldı; ikinci kez basılmadı', 'ek-onay-notu', 'change', 'disabled', 'mouseup', 'veya', 'htmlFor', 'Klasör', '_panel', 'onerror', 'kod', ' yeni konu kataloğa eklendi.', '#kisiEkle', 'Ağaç düğmesi bulunamadı', '#csv', 'alttaki isim (listede yok)', '(metin yok)', 'innerHTML', 'pool', 'shown', 'Kaldırılacak klasör', '#act [data-a]', 'sayi', 'Gelen Evrak Kayıt', 'setProperty', 'kind', '.fn', '” adımında kesildi (sayfa yenilendi/kapandı). Evrak kaydedilmemiş olabilir.', 'name', 'okulAdi', '4675671CfiQff', 'items', 'toTimeString', '#kisiTc', ' (tahmin/dosya adı)', 'addListener', 'exact', 'Benzer kayıt seçildi, evrak kaydı tamamlandı', 'Klasöre yazılamadı, indiriliyor: ', 'position:fixed;left:12px;bottom:12px;z-index:2147483647;', 'addEventListener', 'numara', 'closest', 'querySelector', 'TC ile bulunamadı, adla aranıyor.', 'katalog ', 'Öğrenilenler silindi.', 'Benzer kayıt uyarısı: ', 'bos', ' 0 0 ', 'reverse', 'Konu kodu', ' (ayarlardan doldurun)', 'AHx', 'find', 'benzerAt', 'Kaydedildi', 'Yeni evrak formu temizlenmedi (önceki üst yazı görünüyor). “Gelen Evrak Kayıt”a elle tıklayıp Tekrar dene’ye basın', '#15803D', 'Benzer kayıt seçilemedi: ', '#tani', ' (boş/seçilmemiş)', ' | ', 'URL: ', '.ka', 'pickedEl', '13745OgLVmy', 'ToUnicode', 'havaleKural', 'marginBottom', 'mouseenter', 'konu', 'matchAll', 'ebys_okul_profil_v1', 'getDate', 'log', '697704tWCbny', 'pointerup', 'Sizi bekliyor', 'style', 'Birime Havale geçersiz', 'Arama türü: Kullanıcı seçildi (sekme).', 'XObject', 'data-label', '] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>', 'src', 'ArrowDown', 'td,span,a', 'Birime havale', ' / ', 'slice', 'yeni', ' | Alttaki isim: ', 'Yarım kalan toplu işlemden vazgeçildi.', ' — Kaydet’e basılmadı', '.st', 'havalePicked', 'toLocaleLowerCase', 'Evrak Sayı boş', 'origin', 'charCodeAt', '#otoTarih', '[data-k=x]', '#kisiUyari', '524vbnqiB', 'nakil=Nakiller', 'Pages', 'lastIndex', 'mousedown', 'getItem', 'Sayfa yenilendi: benzer kayıt uyarısı görünüyor, seçiliyor…', 'next', 'input:not([type=hidden])', 'textContent', 'Alan siz müdahale edince seçilmiş görünüyor, devam ediliyor.', 'checked', 'DOCUMENT_POSITION_FOLLOWING', 'mouseover', 'defaultView', 'ilgil', 'abs', ' · ', 'ownerDocument', 'flatMap', 'encode', 'noopener noreferrer', 'öğrenilmiş', 'toks', 'aria-label', 'createWritable', 'open', 'input,select,textarea', 'label[for=\x22', 'status', 'runtime', 'some', 'requestPermission', 'evrakKayitOtonom.v1', '<option></option>', 'icin', 'kayitHavaleVarsayilan', 'konuBulundu', '.ui-selectonemenu-label', '5 0 obj\x0a<< /Length ', 'ayar', 'Geldiği Kişi', ' 00000 n \x0a', '__ekIki', 'match', ' | Geldiği kişi: ', '#chip', 'anc', 'position:fixed;left:12px;bottom:12px;z-index:2147483646;width:min(380px,90vw);background:#0F172A;color:#F8FAFC;border:2px solid #FACC15;border-radius:12px;padding:12px;font:14px/1.45 \x22Segoe UI\x22,Tahoma,sans-serif;', 'Birime Havale doğrulandı: ', 'keyup', 'sp ', 'Font', '” → “', '” adımı yapılamadı. Elle düzeltip seçin:', ' type=', 'evrak islemleri', 'getFileHandle', 'scrollTop', '#dir', '\x5cs+(\x5cd+)\x5cs+\x5cd+\x5cs+R', 'onmousedown', 'text/csv;charset=utf-8', 'localeCompare', 'Henüz kayıt yok.', ' adımında (sayfa yenilendi) — KAYDEDİLMEMİŞ OLABİLİR', 'num', 'test', 'sınıf', 'outerHTML', 'queryPermission', 'join', 'Arama türü: Kullanıcı seçildi (radyo).', 'Geliş tipi', '📁 ', 'body', '<input data-f=\x22konu\x22 placeholder=\x22Konu\x22><select data-f=\x22gonderen\x22></select><input data-f=\x22havale\x22 placeholder=\x22Birime havale (boş = listedeki okulumuz)\x22>', 'display:flex;gap:8px;justify-content:flex-end;', 'scrollIntoView', 'picked', 'placeholder', 'Benzer kayıt seçeneği bulunamadı', 'startsWith', 'total', 'index', 'Liste öğesi (', 'prefer', 'Geldiği kişi TC ile aranıyor (…', 'Konu kodu otomatik seçilemedi — açılan listeden siz seçin, sonra “Elle yaptım, devam” deyin', '.ui-treenode-label,.ui-treenode-content', '.ui-radiobutton', 'kabul', 'createElement', 'Evrak Sayı alanı yok', 'label,span,td,th,div,a,button,li,legend,p,b,strong,h1,h2,h3,h4,h5', 'Seçenek yok: ', 'documentElement', 'oku', 'Onayla', 'target', 'removeItem', 'contentDocument', 'Konu', 'download', ' — satırdan seçin veya Ayarlar’dan varsayılan yazın.', '%PDF-1.4\x0a', 'Havale araması “', 'color:#7DD3FC;display:inline-block;margin-bottom:10px;', 'role', '#fff', ' class=\x22', 'Bu kişi zaten listede.', 'chip ', '” denemesi olmadı: ', 'kisiler', 'getAttribute', 'Sayfa mesajı: ', 'Kuyruk boş: önce PDF seçin.', 'Alan bulunamadı: ', 'Listeden seçilemedi (Enter kullanılmadı). Öğe: ', 'okundu', 'warn', '” (', 'newValue', '_kaydetClicked', 'oninput', 'Uyarı: TC 11 haneli değil. Kaydedildi ama TC ile arama yapılmayacak.', 'Evrak Kayıt modülü gizlilik onayı vermeden çalışmaz. Kayıt listesi, geldiği kişi listesi (ad ve TC) ve günlükler yalnızca bu bilgisayarda, eklentinin kendi deposunda tutulur; hiçbir yere gönderilmez.', 'Etiket bulunamadı: ', 'a,button,li,.ui-button', 'fillRect', 'Konu metni boş', 'data-item-label', '” olarak kalmadı (şu an: “', 'null', ' | Konu: ', 'innerText', '#oto_dir', 'Tanı hazır, dosya indirildi.', 'Evrak Sayı alanındaki hatalı değer temizleniyor: “', 'remove', 'assign', ' metni ──\x0a', ' (ekranda yalnızca eski numara var: ', ' evrak otomatik tekrarlanmadı (çift kayıt olmasın): ', 'xref\x0a0 6\x0a0000000000 65535 f \x0a', ' adımında — KAYDEDİLMEMİŞ OLABİLİR', 'metin kuralı', 'Üst yazı', 'onayla', 'Üst yazı ekle', '⚡ EVRAK KAYIT — klasördeki bugünkü PDF/JPEG\x27leri sırayla kaydet', 'Sistem uyarısı: ', 'benzerTried', '\x0a<style>\x0a:host{all:initial}\x0a*{box-sizing:border-box;font-family:\x27Segoe UI\x27,system-ui,Arial,sans-serif}\x0a[hidden]{display:none!important}\x0a#fab{width:60px;height:60px;padding:0;border:3px solid #fff;border-radius:50%;background:#0d47a1;cursor:pointer;box-shadow:0 6px 18px #0007;overflow:hidden;transition:transform .15s}\x0a#fab:hover{transform:scale(1.1)}\x0a#panel{--fs:15px;display:none;width:480px;height:620px;min-width:340px;min-height:320px;max-width:96vw;max-height:94vh;resize:both;overflow:hidden;\x0a background:#f4f7fb;color:#18222f;border-radius:16px;box-shadow:0 14px 44px #0008,0 0 0 1px #0b3d9144;font-size:var(--fs);flex-direction:column}\x0a#hd{background:linear-gradient(135deg,#0d47a1,#1e88e5);color:#fff;padding:10px 12px;display:flex;gap:8px;align-items:center;cursor:move;user-select:none}\x0a.logo{width:36px;height:36px;flex:none;border-radius:9px;overflow:hidden;box-shadow:0 2px 6px #0005}\x0a.ttl{flex:1;line-height:1.15}.ttl b{display:block;font-size:1.08em}.ttl small{opacity:.88;font-size:.78em}\x0a.chip{background:#ffffff2e;border-radius:20px;padding:3px 11px;font-size:.78em;font-weight:700;white-space:nowrap}\x0a.chip.run{background:#ffb300;color:#3a2a00}.chip.warn{background:#ff5252;color:#fff;animation:pl 1s infinite}.chip.ok{background:#43a047}\x0a@keyframes pl{50%{opacity:.55}}\x0a#hd button{background:#ffffff26;color:#fff;border:0;border-radius:8px;padding:4px 9px;font-size:.9em;cursor:pointer}\x0a#hd button:hover{background:#ffffff4d}\x0a#tabs{display:flex;background:#dfe8f5;padding:6px 8px 0;gap:4px}\x0a.tab{flex:1;border:0;background:none;padding:8px 6px;font-size:.95em;font-weight:700;color:#4a6285;cursor:pointer;border-radius:10px 10px 0 0}\x0a.tab:hover{background:#ffffff66}.tab.on{color:#0d47a1;background:#f4f7fb}\x0a#body{flex:1;overflow:auto;padding:12px}\x0asection{display:flex;flex-direction:column;gap:10px;min-height:100%}\x0a.card{background:#fff;border-radius:12px;padding:10px;box-shadow:0 1px 5px #0b3d9122}\x0a.row{display:flex;flex-wrap:wrap;gap:6px}\x0abutton.b,label.b{background:#1565c0;color:#fff;border:0;border-radius:10px;padding:8px 13px;font-size:.93em;font-weight:700;cursor:pointer;box-shadow:0 1px 3px #0003;display:inline-block}\x0abutton.b:hover,label.b:hover{filter:brightness(1.1)}button.b:disabled{opacity:.5;cursor:default}\x0a.big{width:100%;padding:13px 14px !important;font-size:1.02em !important;border-radius:12px !important}\x0a.dirl{flex:1;font-size:.85em;color:#33425b;font-weight:700;min-width:120px}\x0a#otoTarih{padding:4px 6px;border:1px solid #b5c3d8;border-radius:8px;font-size:.85em}\x0a.b.g{background:#2e9d52}.b.r{background:#d63c3c}.b.n{background:#5b6f8c}.b.sm{padding:3px 9px;font-size:.8em;border-radius:8px}\x0a#nums{background:#fff8e1;border:2px solid #ffc107;border-radius:12px;padding:9px 11px}\x0a#nums h4{margin:0 0 4px;font-size:.78em;letter-spacing:.3px;color:#7a5b00;text-transform:uppercase}\x0a.num{font-size:1.9em;font-weight:800;color:#c62828;line-height:1.1;word-break:break-all}\x0a.num small{display:block;font-size:.4em;font-weight:600;color:#444}\x0a#stepper{display:flex;flex-wrap:wrap;gap:4px}\x0a.sp{padding:2px 9px;border-radius:12px;font-size:.76em;background:#e3e9f2;color:#5a6b85;font-weight:700}\x0a.sp.ok{background:#d7f2de;color:#1b6b34}.sp.run{background:#ffe08a;color:#6b4a00}.sp.err{background:#ffd3d3;color:#9b1c1c}\x0a#q .it{display:flex;flex-direction:column;gap:4px;background:#fff;border-radius:12px;padding:9px;margin-bottom:8px;box-shadow:0 1px 5px #0b3d9122}\x0a#q .it .top{display:flex;gap:6px;align-items:center}\x0a#q .it input,#q .it select,.f input,.f textarea{font-size:.95em;padding:6px 8px;border:1px solid #b5c3d8;border-radius:8px;width:100%;background:#fcfdff}\x0a#q .it input:focus,#q .it select:focus,.f input:focus,.f textarea:focus{outline:2px solid #64b5f6;border-color:#64b5f6}\x0a#q .fn{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:700;color:#23324a}\x0a.st{font-weight:800;font-size:.85em}.st.done{color:#2e9d52}.st.run{color:#e08a00}\x0a#log{flex:1;min-height:150px;background:#0e1621;color:#dfe9f5;border-radius:12px;padding:9px;overflow:auto;font:.86em/1.5 Consolas,\x27Courier New\x27,monospace;white-space:pre-wrap}\x0a#log .ok{color:#7ee787}#log .err{color:#ff8b8b}\x0a#act{display:none;flex-direction:column;gap:6px;background:#ffebee;border:2px solid #d63c3c;border-radius:12px;padding:10px}\x0alabel.f,div.f{display:block;margin-top:8px;font-size:.88em;font-weight:700;color:#33425b}\x0a.card h3{margin:0 0 6px;font-size:.95em;color:#0d47a1}\x0a.rec{display:flex;gap:10px;align-items:center;background:#fff;border-radius:12px;padding:8px 10px;margin-bottom:6px;box-shadow:0 1px 4px #0b3d9122}\x0a.rec .n{font-size:1.25em;font-weight:800;color:#c62828;min-width:105px;word-break:break-all}\x0a.rec .m{flex:1;font-size:.88em;color:#33425b}.rec .m small{display:block;color:#7a8aa3}\x0a.bd{font-size:.72em;font-weight:800;border-radius:10px;padding:2px 8px;background:#d7f2de;color:#1b6b34;white-space:nowrap}.bd.x{background:#ffd3d3;color:#9b1c1c}\x0a</style>\x0a<button id=\x22fab\x22 title=\x22Evrak Kayıt Otonom\x22>', 'tagName', 'clientX', 'localStorage', 'otoFab', 'max', 'Tanı ', 'TEXTAREA', 'call', '<span></span><small></small>', '.ui-selectonemenu-filter', 'ASCIIHexDecode', 'toLowerCase', 'Geldiği kişi boş: ', 'onchange', '”: ', 'Sayfa adresi: ', 'Kaydet düğmesine basılıyor (1 kez, id=', '.auto', 'width', 'benzer kay', 'okunuyor', 'write', '#oto_go', 'small', 'flex', 'Klasör seçilmedi.', '.ui-dialog,[role=dialog],.modal,.ui-overlaypanel', '#fp', 'getClientRects', '.ui-selectonemenu-panel', '542627wmBxyT', 'rel', 'none', 'getMonth', 'select', '#go', 'raw', 'then', ' | Sayı: ', 'Yükle', '.run', 'set', '🔒 Evrak Asistanı — Evrak Kayıt', 'background:', 'gonderen', 'storage', 'input[type=radio]', 'click', 'Girdi yok', '#pdf', '.tab', ' PDF klasörden alındı.', 'rules', 'size', 'options', 'file', 'must', 'readable', '#s_', 'getFullYear', 'href', 'classList', 'gelisTipi', 'Uyarı: ekranda eski kayıt mesajı duruyor (', 'evet', 'padStart', 'Çalışıyor — ', 'ebys.meb.gov.tr', 'Menü', 'getWriter', 'devam', 'concat', 'ul,tbody,div', 'Uyarı: Birime Havale seçimi ekranda doğrulanamadı, kontrol edin.', '#numList', 'Kaydet', '#334155', 'Evrak Sayı', 'getContext', 'jQuery', 'createObjectURL', 'deflate', 'muhatap', 'Konu Kodu', 'saat', 'compareDocumentPosition', '.ui-selectonemenu-trigger', '\x22 ph=\x22', 'Liste kaydı ', ' — numara okunamadı', 'islem', ' /Height ', ' (boş)', 'createObjectStore', 'Dikkat: önceden hata/atlama olan ', 'code', 'Birime Havale', 'Okul adı öğrenildi: ', 'Konu kodu araması: “', 'create', 'Kaydet ve numarayı oku', '__EA_TEST__', 'sonGonderen', '\x22Eklenen üst yazı\x22 görünmedi', 'filter', 'sayiDurum', ';color:#fff;border:1px solid #CBD5E1;padding:7px 12px;border-radius:9px;font-weight:700;cursor:pointer;', 'li,tr,.ui-autocomplete-item', 'settings', ' sn sonra… Konu Kodu kutusuna bir harf yazıp listeyi açık bırakın', 'lastModified', ' sn sonra… (alana yazıp listeyi açık bırakın)', 'application/pdf'];
    _0x1c21 = function () {
        return _0x5a2ddd;
    };
    return _0x1c21();
}
let _unused_dzsp;
(function (_0x5b2992, _0x5c5893) {
    const _0x50beb6 = _0x5b2992();
    while (!false) {
        try {
            const _0x5d60cc = parseInt("542627wmBxyT") / 0x1 + parseInt("1117512YEESDV") / 0x2 + parseInt("118011rxRdUe") / 0x3 + -parseInt("524vbnqiB") / 0x4 * (parseInt("13745OgLVmy") / 0x5) + parseInt("1958598jHMNfW") / 0x6 + parseInt("21raTtQb") / 0x7 * (-parseInt("697704tWCbny") / 0x8) + -parseInt("4675671CfiQff") / 0x9;
            if (_0x5d60cc === _0x5c5893) {
                break;
            }
            else {
                _0x50beb6.push(_0x50beb6.shift());
            }
        }
        catch (_0x2d140f) {
            _0x50beb6.push(_0x50beb6.shift());
        }
    }
}(_0x1c21, 0x4f8f4), window.__ekIki = window.__ekIki || function (_0x4f22b2, _0x474a33) {
    const _0x11e0dd = window.__ekIkiS = window.__ekIkiS || {}, _0x4f22e1 = Date.now();
    if (_0x11e0dd[_0x4f22b2] && _0x4f22e1 - _0x11e0dd[_0x4f22b2] < 0xbb8) {
        _0x11e0dd[_0x4f22b2] = 0x0;
        if (_0x474a33) {
            _0x474a33.textContent = _0x474a33.dataset.ekOrj || _0x474a33.textContent;
        }
        return !false;
    }
    _0x11e0dd[_0x4f22b2] = _0x4f22e1;
    _0x474a33 && (_0x474a33.dataset.ekOrj = _0x474a33.dataset.ekOrj || _0x474a33.textContent, _0x474a33.textContent = "Emin misiniz? Tekrar tıklayın", setTimeout(() => {
        let _unused_2kmc;
        _0x11e0dd[_0x4f22b2] === _0x4f22e1 && (_0x11e0dd[_0x4f22b2] = 0x0, _0x474a33.textContent = _0x474a33.dataset.ekOrj);
    }, 0xbb8));
    return false;
}, (function () {
    let _unused_56m8;
    if (window.top !== window || window.__evrakKayitYuklendi) {
        return;
    }
    window.__evrakKayitYuklendi = !false;
    const _0x56145f = 'ebys_consent_v1', _0x17e23a = '2026-10-19a', _0x2d320b = "https://otonomevrak.com/evrak/gizlilik", _0x32f781 = "evrakKayitOtonom.v1", _0x1a2078 = [_0x32f781, _0x32f781 + ".log", _0x32f781 + ".run", _0x32f781 + ".auto", _0x32f781 + ".pend"], _0x5883e2 = Object.create(null), _0x30f464 = () => {
        let _unused_ee2m;
        try {
            return chrome.storage.local;
        }
        catch (_0x26a009) {
            return null;
        }
    }, _0x2f2f4f = { 'getItem': _0x45b6a0 => _0x5883e2[_0x45b6a0] === undefined ? null : JSON.stringify(_0x5883e2[_0x45b6a0]), 'setItem': (_0x1fae44, _0x437a38) => {
            const _0x509b19 = JSON.parse(_0x437a38);
            _0x5883e2[_0x1fae44] = _0x509b19;
            const _0x4e1560 = _0x30f464();
            if (_0x4e1560) {
                try {
                    const _0x3a972c = _0x4e1560.set({ [_0x1fae44]: _0x509b19 });
                    if (_0x3a972c && _0x3a972c.catch) {
                        _0x3a972c.catch(() => {
                        });
                    }
                }
                catch (_0x329c91) {
                }
            }
        }, 'removeItem': _0xeefed7 => {
            let _unused_d1r7;
            delete _0x5883e2[_0xeefed7];
            const _0xc4ab0b = _0x30f464();
            if (_0xc4ab0b) {
                try {
                    const _0x530942 = _0xc4ab0b.remove(_0xeefed7);
                    if (_0x530942 && _0x530942.catch) {
                        _0x530942.catch(() => {
                        });
                    }
                }
                catch (_0x1ac9f8) {
                }
            }
        } };
    function _0x400dba(_0x5b049f, _0x516196) {
        const _0x535479 = {}, _0x4acea5 = [], _0xeefab4 = _0x1807ec => {
            let _unused_jilf;
            let _0x2ed191 = null;
            try {
                _0x2ed191 = _0x516196.getItem(_0x1807ec);
            }
            catch (_0x1b765b) {
            }
            if (_0x2ed191 == null) {
                return undefined;
            }
            try {
                return JSON.parse(_0x2ed191);
            }
            catch (_0xe5f0f7) {
                return null;
            }
        }, _0x42bfa4 = _0x51b991 => String(_0x51b991 || '').toLocaleLowerCase('tr').replace(/\s+/g, ' ').trim();
        _0x1a2078.forEach(_0xb145e5 => {
            const _0x2bcc9d = _0xeefab4(_0xb145e5);
            if (_0x2bcc9d === undefined) {
                return;
            }
            _0x4acea5.push(_0xb145e5);
            if (_0x2bcc9d === null) {
                return;
            }
            const _0x37e230 = _0x5b049f[_0xb145e5];
            if (_0x37e230 === undefined) {
                _0x535479[_0xb145e5] = _0x2bcc9d;
                return;
            }
            if (_0xb145e5 === _0x32f781 && _0x37e230 && typeof _0x37e230 === "object" && _0x2bcc9d && typeof _0x2bcc9d === 'object') {
                const _0x18c65d = JSON.parse(JSON.stringify(_0x37e230));
                let _0xf8d535 = false;
                const _0x3f49c8 = Array.isArray(_0x18c65d.records) ? _0x18c65d.records : _0x18c65d.records = [], _0x3018de = _0x2a54ea => (_0x2a54ea.key || _0x2a54ea.dosya || '') + '|' + (_0x2a54ea.numara || '');
                (Array.isArray(_0x2bcc9d.records) ? _0x2bcc9d.records : []).forEach(_0x540cb9 => {
                    let _unused_nru8;
                    _0x540cb9 && !_0x3f49c8.some(_0x32400f => _0x3018de(_0x32400f) === _0x3018de(_0x540cb9)) && (_0x3f49c8.push(_0x540cb9), _0xf8d535 = !false);
                });
                const _0x13fee1 = _0x2bcc9d.settings || {};
                if (Array.isArray(_0x13fee1.kisiler) && _0x13fee1.kisiler.length) {
                    _0x18c65d.settings = _0x18c65d.settings || {};
                    const _0x2d185d = Array.isArray(_0x18c65d.settings.kisiler) ? _0x18c65d.settings.kisiler : _0x18c65d.settings.kisiler = [];
                    _0x13fee1.kisiler.forEach(_0x368ed1 => {
                        let _unused_rvp3;
                        _0x368ed1 && _0x368ed1.ad && !_0x2d185d.some(_0x54f855 => _0x42bfa4(_0x54f855.ad) === _0x42bfa4(_0x368ed1.ad)) && (_0x2d185d.push(_0x368ed1), _0xf8d535 = !false);
                    });
                }
                if (_0xf8d535) {
                    _0x535479[_0xb145e5] = _0x18c65d;
                }
            }
            else {
                _0xb145e5 === _0x32f781 + '.log' && Array.isArray(_0x37e230) && Array.isArray(_0x2bcc9d) && _0x2bcc9d.length && (_0x535479[_0xb145e5] = _0x2bcc9d.concat(_0x37e230).slice(-0x320));
            }
        });
        return { 'set': _0x535479, 'remove': _0x4acea5 };
    }
    async function _0x476575() {
        let _unused_kk48;
        let _0x2f410e = null;
        try {
            _0x2f410e = window.localStorage;
        }
        catch (_0x1ab599) {
        }
        if (!_0x2f410e) {
            return;
        }
        const _0x1a6155 = _0x400dba(_0x5883e2, _0x2f410e);
        if (!_0x1a6155.remove.length) {
            return;
        }
        const _0x4f5178 = _0x30f464();
        if (Object.keys(_0x1a6155.set).length) {
            if (!_0x4f5178) {
                return;
            }
            try {
                await _0x4f5178.set(_0x1a6155.set);
            }
            catch (_0x3053f8) {
                return;
            }
            Object.assign(_0x5883e2, _0x1a6155.set);
        }
        _0x1a6155.remove.forEach(_0x48a49b => {
            let _unused_qk2l;
            try {
                _0x2f410e.removeItem(_0x48a49b);
            }
            catch (_0xa172f6) {
            }
        });
    }
    const _0x1de1cd = _0x29b234 => !!(_0x29b234 && _0x29b234.accepted === !false && _0x29b234.version === _0x17e23a);
    function _0x14d6ac() {
        let _unused_vo94;
        if (location.hostname === 'ebys.meb.gov.tr' || document.getElementById("ek-onay-notu")) {
            return;
        }
        if (!document.body) {
            setTimeout(_0x14d6ac, 0x1f4);
            return;
        }
        const _0x15ec64 = document.createElement("div");
        _0x15ec64.id = "ek-onay-notu";
        _0x15ec64.setAttribute("role", 'region');
        _0x15ec64.setAttribute("aria-label", 'Evrak Asistanı gizlilik onayı');
        _0x15ec64.style.cssText = "position:fixed;left:12px;bottom:12px;z-index:2147483646;width:min(380px,90vw);background:#0F172A;color:#F8FAFC;border:2px solid #FACC15;border-radius:12px;padding:12px;font:14px/1.45 \"Segoe UI\",Tahoma,sans-serif;";
        const _0x2807d2 = _0x1fa14e => {
            const _0x2ae9d5 = document.createElement("div");
            _0x2ae9d5.textContent = _0x1fa14e;
            _0x2ae9d5.style.marginBottom = '8px';
            return _0x2ae9d5;
        }, _0x24353d = document.createElement("div");
        _0x24353d.textContent = "🔒 Evrak Asistanı — Evrak Kayıt";
        _0x24353d.style.cssText = 'font-weight:800;color:#FACC15;margin-bottom:6px;';
        _0x15ec64.appendChild(_0x24353d);
        _0x15ec64.appendChild(_0x2807d2("Evrak Kayıt modülü gizlilik onayı vermeden çalışmaz. Kayıt listesi, geldiği kişi listesi (ad ve TC) ve günlükler yalnızca bu bilgisayarda, eklentinin kendi deposunda tutulur; hiçbir yere gönderilmez."));
        _0x15ec64.appendChild(_0x2807d2('Modülü siz başlattığınızda gelen evrak kayıt formunu doldurur ve Kaydet düğmesinde durur; formu kontrol edip Kaydet’e siz basarsınız. Eklenti Kaydet’e ve sonraki Evet/Onayla/Tamam pencerelerine basmaz; evrak göndermez, imzalamaz, paraflamaz. Resmî bir MEB ürünü değildir.'));
        const _0x4d891c = document.createElement('a');
        _0x4d891c.href = _0x2d320b;
        _0x4d891c.target = "_blank";
        _0x4d891c.rel = "noopener noreferrer";
        _0x4d891c.textContent = "Gizlilik Politikası";
        _0x4d891c.style.cssText = "color:#7DD3FC;display:inline-block;margin-bottom:10px;";
        _0x15ec64.appendChild(_0x4d891c);
        const _0x1ec838 = document.createElement("div");
        _0x1ec838.style.cssText = "display:flex;gap:8px;justify-content:flex-end;";
        const _0x3721b0 = (_0x134b30, _0x5357ad) => {
            const _0xd6ccb4 = document.createElement("button");
            _0xd6ccb4.type = 'button';
            _0xd6ccb4.textContent = _0x134b30;
            _0xd6ccb4.style.cssText = "background:" + _0x5357ad + ";color:#fff;border:1px solid #CBD5E1;padding:7px 12px;border-radius:9px;font-weight:700;cursor:pointer;";
            return _0xd6ccb4;
        }, _0x1cbbd4 = _0x3721b0("Şimdi değil", "#334155"), _0x1ea45f = _0x3721b0("Kabul ediyorum", "#15803D");
        _0x1cbbd4.onclick = () => _0x15ec64.remove();
        _0x1ea45f.onclick = () => {
            try {
                chrome.storage.local.set({ [_0x56145f]: { 'accepted': !false, 'version': _0x17e23a, 'at': new Date().toISOString() } });
            }
            catch (_0x3eac38) {
            }
        };
        _0x1ec838.appendChild(_0x1cbbd4);
        _0x1ec838.appendChild(_0x1ea45f);
        _0x15ec64.appendChild(_0x1ec838);
        document.body.appendChild(_0x15ec64);
    }
    const _0x4a2258 = () => {
        ((() => {
            'use strict';
            let _unused_fzfr;
            if (window.top !== window) {
                return;
            }
            if (document.getElementById("evrak-otonom-host")) {
                return;
            }
            const _0x21096f = _0x36bde4 => {
                let _unused_9ie3;
                let _0x5089a8 = '';
                for (let _0x21c37f = 0x0; _0x21c37f < _0x36bde4.length; _0x21c37f += 0x2000) {
                    _0x5089a8 += String.fromCharCode.apply(null, _0x36bde4.subarray(_0x21c37f, _0x21c37f + 0x2000));
                }
                return _0x5089a8;
            };
            function _0x1f130f(_0x594a97) {
                let _unused_4o4s;
                _0x594a97 = _0x594a97.replace(/^\s*<~/, '').replace(/~>[\s\S]*$/, '').replace(/\s+/g, '');
                let _0x38e3fd = '', _0x3a4875 = [];
                const _0x6e2b12 = _0x28a419 => {
                    let _unused_c7wm;
                    let _0x364171 = 0x0;
                    for (let _0x4e5c9f = 0x0; _0x4e5c9f < 0x5; _0x4e5c9f++) {
                        _0x364171 = _0x364171 * 0x55 + (_0x3a4875[_0x4e5c9f] === undefined ? 0x54 : _0x3a4875[_0x4e5c9f]);
                    }
                    const _0x4ccc3b = [_0x364171 >>> 0x18 & 0xff, _0x364171 >>> 0x10 & 0xff, _0x364171 >>> 0x8 & 0xff, _0x364171 & 0xff];
                    _0x38e3fd += String.fromCharCode.apply(null, _0x4ccc3b.slice(0x0, _0x28a419));
                    _0x3a4875 = [];
                };
                for (const _0x5ac863 of _0x594a97) {
                    if (_0x5ac863 === 'z' && !_0x3a4875.length) {
                        _0x38e3fd += "\0\0\0\0";
                        continue;
                    }
                    _0x3a4875.push(_0x5ac863.charCodeAt(0x0) - 0x21);
                    if (_0x3a4875.length === 0x5) {
                        _0x6e2b12(0x4);
                    }
                }
                if (_0x3a4875.length > 0x1) {
                    const _0x2d1858 = _0x3a4875.length - 0x1;
                    _0x6e2b12(_0x2d1858);
                }
                return _0x38e3fd;
            }
            async function _0x4e6ccc(_0x36ad83) {
                const _0x3b5648 = new Uint8Array(_0x36ad83.length);
                for (let _0x39d3f9 = 0x0; _0x39d3f9 < _0x36ad83.length; _0x39d3f9++) {
                    _0x3b5648[_0x39d3f9] = _0x36ad83.charCodeAt(_0x39d3f9) & 0xff;
                }
                try {
                    const _0x1734f7 = new DecompressionStream("deflate"), _0x2f6eb4 = _0x1734f7.writable.getWriter();
                    _0x2f6eb4.write(_0x3b5648).catch(() => {
                    });
                    _0x2f6eb4.close().catch(() => {
                    });
                    return _0x21096f(new Uint8Array(await new Response(_0x1734f7.readable).arrayBuffer()));
                }
                catch (_0xdafa59) {
                    return '';
                }
            }
            function _0x3ded1c(_0x121cce, _0x2e7133, _0x366bc0, _0x341a57) {
                let _unused_jpbv;
                let _0x354a75 = 0x0;
                for (let _0x435fd3 = _0x2e7133; _0x435fd3 < _0x121cce.length; _0x435fd3++) {
                    if (_0x121cce.startsWith(_0x366bc0, _0x435fd3)) {
                        _0x354a75++;
                        _0x435fd3 += _0x366bc0.length - 0x1;
                    }
                    else {
                        if (_0x121cce.startsWith(_0x341a57, _0x435fd3)) {
                            _0x354a75--;
                            _0x435fd3 += _0x341a57.length - 0x1;
                            if (!_0x354a75) {
                                return _0x121cce.slice(_0x2e7133, _0x435fd3 + 0x1);
                            }
                        }
                    }
                }
                return _0x121cce.slice(_0x2e7133);
            }
            function _0x501635(_0xed18cf, _0x25099b) {
                let _unused_42tv;
                if (!_0xed18cf) {
                    return null;
                }
                const _0x1469d8 = new RegExp('/' + _0x25099b + '(?![A-Za-z0-9])\x5cs*').exec(_0xed18cf);
                if (!_0x1469d8) {
                    return null;
                }
                const _0x1a12b1 = _0x1469d8.index + _0x1469d8[0x0].length;
                if (_0xed18cf.startsWith('<<', _0x1a12b1)) {
                    return _0x3ded1c(_0xed18cf, _0x1a12b1, '<<', '>>');
                }
                if (_0xed18cf[_0x1a12b1] === '[') {
                    return _0x3ded1c(_0xed18cf, _0x1a12b1, '[', ']');
                }
                const _0x5983a5 = /^(\d+\s+\d+\s+R|\/[^\s/<>\[\]()]+|[^\s/<>\[\]()]+)/.exec(_0xed18cf.slice(_0x1a12b1, _0x1a12b1 + 0x64));
                return _0x5983a5 ? _0x5983a5[0x0] : null;
            }
            const _0x14c72c = _0x247a70 => {
                const _0x133d81 = /^\s*(\d+)\s+\d+\s+R/.exec(_0x247a70 || '');
                return _0x133d81 ? +_0x133d81[0x1] : null;
            }, _0x1e7090 = _0x783fe8 => {
                let _unused_o8gt;
                let _0x4a7fd5 = '';
                for (let _0x231f6b = 0x0; _0x231f6b + 0x3 < _0x783fe8.length + 0x1; _0x231f6b += 0x4) {
                    _0x4a7fd5 += String.fromCharCode(parseInt(_0x783fe8.substr(_0x231f6b, 0x4).padEnd(0x4, '0'), 0x10));
                }
                return _0x4a7fd5;
            };
            function _0x476979(_0x3c1ef3) {
                const _0x82020e = new Map();
                let _0x5da934 = 0x0, _0x131a64;
                const _0x5e8808 = /begincodespacerange([\s\S]*?)endcodespacerange/g;
                while (_0x131a64 = _0x5e8808.exec(_0x3c1ef3)) {
                    const _0x7639bf = /<([0-9A-Fa-f]+)>/.exec(_0x131a64[0x1]);
                    if (_0x7639bf) {
                        _0x5da934 = Math.max(_0x5da934, _0x7639bf[0x1].length / 0x2);
                    }
                }
                const _0x2f4004 = /beginbfchar([\s\S]*?)endbfchar/g;
                while (_0x131a64 = _0x2f4004.exec(_0x3c1ef3)) {
                    const _0x38db77 = /<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]*)>/g;
                    let _0xf50a21;
                    while (_0xf50a21 = _0x38db77.exec(_0x131a64[0x1])) {
                        _0x82020e.set(parseInt(_0xf50a21[0x1], 0x10), _0x1e7090(_0xf50a21[0x2]));
                        if (!_0x5da934) {
                            _0x5da934 = _0xf50a21[0x1].length / 0x2;
                        }
                    }
                }
                const _0x3ea55d = /beginbfrange([\s\S]*?)endbfrange/g;
                while (_0x131a64 = _0x3ea55d.exec(_0x3c1ef3)) {
                    const _0x309e19 = /<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*(?:<([0-9A-Fa-f]*)>|\[([^\]]*)\])/g;
                    let _0x388da9;
                    while (_0x388da9 = _0x309e19.exec(_0x131a64[0x1])) {
                        const _0x3e071b = parseInt(_0x388da9[0x1], 0x10), _0x146e66 = Math.min(parseInt(_0x388da9[0x2], 0x10), _0x3e071b + 0xffff);
                        if (!_0x5da934) {
                            _0x5da934 = _0x388da9[0x1].length / 0x2;
                        }
                        if (_0x388da9[0x3] !== undefined) {
                            const _0x3c074a = _0x1e7090(_0x388da9[0x3]);
                            for (let _0xce701f = _0x3e071b; _0xce701f <= _0x146e66; _0xce701f++) {
                                _0x82020e.set(_0xce701f, _0x3c074a.slice(0x0, -0x1) + String.fromCharCode(_0x3c074a.charCodeAt(_0x3c074a.length - 0x1) + (_0xce701f - _0x3e071b)));
                            }
                        }
                        else {
                            const _0x53e500 = [..._0x388da9[0x4].matchAll(/<([0-9A-Fa-f]*)>/g)].map(_0x15df41 => _0x1e7090(_0x15df41[0x1]));
                            _0x53e500.forEach((_0x58f309, _0x29217c) => _0x82020e.set(_0x3e071b + _0x29217c, _0x58f309));
                        }
                    }
                }
                return { 'map': _0x82020e, 'nb': _0x5da934 };
            }
            function _0x3da239(_0xa9b667) {
                const _0x16703c = [];
                let _0x111fa6 = 0x0;
                const _0x3c616f = _0xa9b667.length, _0x2f4c09 = _0xa98256 => _0xa98256 === ' ' || _0xa98256 === '\x0a' || _0xa98256 === '\x0d' || _0xa98256 === '\x09' || _0xa98256 === '\x0c' || _0xa98256 === '\x00', _0x1adf1e = _0x6cbf2b => "()<>[]{}/%".includes(_0x6cbf2b);
                function _0x5ca9ac() {
                    const _0x3994c6 = [];
                    while (_0x111fa6 < _0x3c616f) {
                        while (_0x111fa6 < _0x3c616f && _0x2f4c09(_0xa9b667[_0x111fa6])) {
                            _0x111fa6++;
                        }
                        if (_0xa9b667[_0x111fa6] === ']') {
                            _0x111fa6++;
                            return _0x3994c6;
                        }
                        const _0x440f4f = _0x3f37f3();
                        if (_0x440f4f) {
                            _0x3994c6.push(_0x440f4f);
                        }
                        else {
                            if (_0x111fa6 >= _0x3c616f) {
                                break;
                            }
                        }
                    }
                    return _0x3994c6;
                }
                function _0x3f37f3() {
                    const _0x2fe9c3 = _0xa9b667[_0x111fa6];
                    if (_0x2fe9c3 === '%') {
                        while (_0x111fa6 < _0x3c616f && _0xa9b667[_0x111fa6] !== '\x0a' && _0xa9b667[_0x111fa6] !== '\x0d') {
                            _0x111fa6++;
                        }
                        return null;
                    }
                    if (_0x2fe9c3 === '(') {
                        let _0x2ceca1 = 0x1, _0x1bd2ba = '';
                        _0x111fa6++;
                        while (_0x111fa6 < _0x3c616f && _0x2ceca1) {
                            const _0x42df94 = _0xa9b667[_0x111fa6++];
                            if (_0x42df94 === '\x5c') {
                                const _0x47fd6e = _0xa9b667[_0x111fa6++];
                                if (_0x47fd6e === 'n') {
                                    _0x1bd2ba += '\x0a';
                                }
                                else {
                                    if (_0x47fd6e === 'r') {
                                        _0x1bd2ba += '\x0d';
                                    }
                                    else {
                                        if (_0x47fd6e === 't') {
                                            _0x1bd2ba += '\x09';
                                        }
                                        else {
                                            if (_0x47fd6e === 'b') {
                                                _0x1bd2ba += '\x08';
                                            }
                                            else {
                                                if (_0x47fd6e === 'f') {
                                                    _0x1bd2ba += '\x0c';
                                                }
                                                else {
                                                    if (_0x47fd6e >= '0' && _0x47fd6e <= '7') {
                                                        let _0x37929c = _0x47fd6e;
                                                        while (_0x37929c.length < 0x3 && _0xa9b667[_0x111fa6] >= '0' && _0xa9b667[_0x111fa6] <= '7') {
                                                            _0x37929c += _0xa9b667[_0x111fa6++];
                                                        }
                                                        _0x1bd2ba += String.fromCharCode(parseInt(_0x37929c, 0x8) & 0xff);
                                                    }
                                                    else {
                                                        if (_0x47fd6e === '\x0d') {
                                                            if (_0xa9b667[_0x111fa6] === '\x0a') {
                                                                _0x111fa6++;
                                                            }
                                                        }
                                                        else {
                                                            if (_0x47fd6e === '\x0a') {
                                                            }
                                                            else {
                                                                _0x1bd2ba += _0x47fd6e;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else {
                                if (_0x42df94 === '(') {
                                    _0x2ceca1++;
                                    _0x1bd2ba += _0x42df94;
                                }
                                else {
                                    if (_0x42df94 === ')') {
                                        _0x2ceca1--;
                                        if (_0x2ceca1) {
                                            _0x1bd2ba += _0x42df94;
                                        }
                                    }
                                    else {
                                        _0x1bd2ba += _0x42df94;
                                    }
                                }
                            }
                        }
                        return { 't': 's', 'v': _0x1bd2ba };
                    }
                    if (_0x2fe9c3 === '<') {
                        if (_0xa9b667[_0x111fa6 + 0x1] === '<') {
                            let _0x105902 = 0x0;
                            while (_0x111fa6 < _0x3c616f) {
                                if (_0xa9b667.startsWith('<<', _0x111fa6)) {
                                    _0x105902++;
                                    _0x111fa6 += 0x2;
                                }
                                else {
                                    if (_0xa9b667.startsWith('>>', _0x111fa6)) {
                                        _0x105902--;
                                        _0x111fa6 += 0x2;
                                        if (!_0x105902) {
                                            break;
                                        }
                                    }
                                    else {
                                        _0x111fa6++;
                                    }
                                }
                            }
                            return { 't': 'd' };
                        }
                        const _0x19b64e = _0xa9b667.indexOf('>', _0x111fa6);
                        let _0x354ed4 = _0xa9b667.slice(_0x111fa6 + 0x1, _0x19b64e).replace(/\s+/g, '');
                        if (_0x354ed4.length % 0x2) {
                            _0x354ed4 += '0';
                        }
                        _0x111fa6 = _0x19b64e + 0x1;
                        let _0x178b5e = '';
                        for (let _0x27a4c4 = 0x0; _0x27a4c4 < _0x354ed4.length; _0x27a4c4 += 0x2) {
                            _0x178b5e += String.fromCharCode(parseInt(_0x354ed4.substr(_0x27a4c4, 0x2), 0x10));
                        }
                        return { 't': 's', 'v': _0x178b5e };
                    }
                    if (_0x2fe9c3 === '[') {
                        _0x111fa6++;
                        return { 't': 'a', 'v': _0x5ca9ac() };
                    }
                    if (_0x2fe9c3 === '/') {
                        let _0x3a1d18 = _0x111fa6 + 0x1;
                        while (_0x3a1d18 < _0x3c616f && !_0x2f4c09(_0xa9b667[_0x3a1d18]) && !_0x1adf1e(_0xa9b667[_0x3a1d18])) {
                            _0x3a1d18++;
                        }
                        const _0x214349 = _0xa9b667.slice(_0x111fa6 + 0x1, _0x3a1d18);
                        _0x111fa6 = _0x3a1d18;
                        return { 't': 'n', 'v': _0x214349 };
                    }
                    if (_0x2fe9c3 === ']' || _0x2fe9c3 === ')' || _0x2fe9c3 === '>' || _0x2fe9c3 === '{' || _0x2fe9c3 === '}') {
                        _0x111fa6++;
                        return null;
                    }
                    let _0x15d809 = _0x111fa6;
                    while (_0x15d809 < _0x3c616f && !_0x2f4c09(_0xa9b667[_0x15d809]) && !_0x1adf1e(_0xa9b667[_0x15d809])) {
                        _0x15d809++;
                    }
                    const _0x44701d = _0xa9b667.slice(_0x111fa6, _0x15d809);
                    _0x111fa6 = _0x15d809;
                    if (/^[+-]?(\d+\.?\d*|\.\d+)$/.test(_0x44701d)) {
                        return { 't': "num", 'v': parseFloat(_0x44701d) };
                    }
                    return { 't': 'op', 'v': _0x44701d };
                }
                while (_0x111fa6 < _0x3c616f) {
                    while (_0x111fa6 < _0x3c616f && _0x2f4c09(_0xa9b667[_0x111fa6])) {
                        _0x111fa6++;
                    }
                    if (_0x111fa6 >= _0x3c616f) {
                        break;
                    }
                    const _0x5c6c29 = _0x3f37f3();
                    if (_0x5c6c29) {
                        _0x16703c.push(_0x5c6c29);
                        if (_0x5c6c29.t === 'op' && _0x5c6c29.v === 'BI') {
                            const _0xc32304 = _0xa9b667.indexOf('EI', _0x111fa6);
                            _0x111fa6 = _0xc32304 < 0x0 ? _0x3c616f : _0xc32304 + 0x2;
                        }
                    }
                }
                return _0x16703c;
            }
            const _0x235316 = (_0x353dc3, _0x10d32f) => [_0x353dc3[0x0] * _0x10d32f[0x0] + _0x353dc3[0x1] * _0x10d32f[0x2], _0x353dc3[0x0] * _0x10d32f[0x1] + _0x353dc3[0x1] * _0x10d32f[0x3], _0x353dc3[0x2] * _0x10d32f[0x0] + _0x353dc3[0x3] * _0x10d32f[0x2], _0x353dc3[0x2] * _0x10d32f[0x1] + _0x353dc3[0x3] * _0x10d32f[0x3], _0x353dc3[0x4] * _0x10d32f[0x0] + _0x353dc3[0x5] * _0x10d32f[0x2] + _0x10d32f[0x4], _0x353dc3[0x4] * _0x10d32f[0x1] + _0x353dc3[0x5] * _0x10d32f[0x3] + _0x10d32f[0x5]], _0x54cf10 = /\.(pdf|jpe?g|png)$/i, _0xce9cc1 = /\.(jpe?g|png)$/i;
            async function _0x2eb851(_0x3ed1ed) {
                const _0x1759e6 = await createImageBitmap(_0x3ed1ed), _0xb2a36 = document.createElement("canvas");
                _0xb2a36.width = _0x1759e6.width;
                _0xb2a36.height = _0x1759e6.height;
                const _0x2fc24e = _0xb2a36.getContext('2d');
                _0x2fc24e.fillStyle = "#fff";
                _0x2fc24e.fillRect(0x0, 0x0, _0xb2a36.width, _0xb2a36.height);
                _0x2fc24e.drawImage(_0x1759e6, 0x0, 0x0);
                const _0x4f21c7 = new Uint8Array(await (await new Promise(_0x40d1fc => _0xb2a36.toBlob(_0x40d1fc, 'image/jpeg', 0.92))).arrayBuffer()), _0x448aac = 595.28, _0x1bdc71 = 841.89, _0x4c9dbb = Math.min(_0x448aac / _0xb2a36.width, _0x1bdc71 / _0xb2a36.height), _0x12513d = +(_0xb2a36.width * _0x4c9dbb).toFixed(0x2), _0xe3c5da = +(_0xb2a36.height * _0x4c9dbb).toFixed(0x2), _0x165e4e = +((_0x448aac - _0x12513d) / 0x2).toFixed(0x2), _0x1ab10c = +((_0x1bdc71 - _0xe3c5da) / 0x2).toFixed(0x2), _0x538235 = 'q ' + _0x12513d + " 0 0 " + _0xe3c5da + ' ' + _0x165e4e + ' ' + _0x1ab10c + ' cm /Im0 Do Q', _0x517f07 = _0x43315e => new TextEncoder().encode(_0x43315e), _0x14a2e1 = [], _0x19795e = [];
                let _0x3283e2 = 0x0;
                const _0xfb7dd9 = _0x36e8d7 => {
                    _0x14a2e1.push(_0x36e8d7);
                    _0x3283e2 += _0x36e8d7.length;
                };
                _0xfb7dd9(_0x517f07("%PDF-1.4\n"));
                const _0x324955 = ["<< /Type /Catalog /Pages 2 0 R >>", "<< /Type /Pages /Kids [3 0 R] /Count 1 >>", '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + _0x448aac + ' ' + _0x1bdc71 + "] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>"];
                _0x324955.forEach((_0x30ac70, _0x2fd676) => {
                    _0x19795e.push(_0x3283e2);
                    _0xfb7dd9(_0x517f07(_0x2fd676 + 0x1 + ' 0 obj\x0a' + _0x30ac70 + '\x0aendobj\x0a'));
                });
                _0x19795e.push(_0x3283e2);
                _0xfb7dd9(_0x517f07('4 0 obj\x0a<< /Type /XObject /Subtype /Image /Width ' + _0xb2a36.width + " /Height " + _0xb2a36.height + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + _0x4f21c7.length + " >>\nstream\n"));
                _0xfb7dd9(_0x4f21c7);
                _0xfb7dd9(_0x517f07("\nendstream\nendobj\n"));
                _0x19795e.push(_0x3283e2);
                _0xfb7dd9(_0x517f07("5 0 obj\n<< /Length " + _0x538235.length + " >>\nstream\n" + _0x538235 + "\nendstream\nendobj\n"));
                const _0x1cee79 = _0x3283e2;
                _0xfb7dd9(_0x517f07("xref\n0 6\n0000000000 65535 f \n" + _0x19795e.map(_0x572fd7 => String(_0x572fd7).padStart(0xa, '0') + " 00000 n \n").join('') + ('trailer\x0a<< /Size 6 /Root 1 0 R >>\x0astartxref\x0a' + _0x1cee79 + "\n%%EOF\n")));
                return new File(_0x14a2e1, _0x3ed1ed.name.replace(_0xce9cc1, '') + ".pdf", { 'type': "application/pdf", 'lastModified': _0x3ed1ed.lastModified });
            }
            async function _0x4e4a23(_0x39b820) {
                const _0x27d3a6 = _0x21096f(new Uint8Array(_0x39b820)), _0x4b3d76 = Object.create(null), _0x2dafd4 = /(\d+)\s+(\d+)\s+obj\b/g;
                let _0x59d0bb;
                while (_0x59d0bb = _0x2dafd4.exec(_0x27d3a6)) {
                    const _0x34aa4a = +_0x59d0bb[0x1], _0x39a907 = _0x2dafd4.lastIndex, _0x424fb1 = _0x27d3a6.indexOf("endobj", _0x39a907);
                    if (_0x424fb1 < 0x0) {
                        break;
                    }
                    const _0x112801 = _0x27d3a6.slice(_0x39a907, _0x424fb1), _0x5d3db1 = { 'id': _0x34aa4a, 'dict': _0x112801, 'raw': null, 'cache': null }, _0x13ce74 = />>\s*stream\r?\n/.exec(_0x112801);
                    if (_0x13ce74) {
                        _0x5d3db1.dict = _0x112801.slice(0x0, _0x13ce74.index + 0x2);
                        const _0x36d28b = _0x13ce74.index + _0x13ce74[0x0].length, _0x56186d = _0x112801.lastIndexOf("endstream");
                        _0x5d3db1.raw = _0x112801.slice(_0x36d28b, _0x56186d < 0x0 ? undefined : _0x56186d).replace(/\r?\n$/, '');
                    }
                    _0x4b3d76[_0x34aa4a] = _0x5d3db1;
                    _0x2dafd4.lastIndex = _0x424fb1;
                }
                const _0x18b1ac = async (_0x376506) => {
                    let _unused_e83w;
                    if (!_0x376506 || _0x376506.raw === null) {
                        return '';
                    }
                    if (_0x376506.cache !== null) {
                        return _0x376506.cache;
                    }
                    const _0x1f8e8c = _0x501635(_0x376506.dict, "Filter") || '';
                    let _0x4ae786 = _0x376506.raw;
                    for (const _0x29a8c1 of [..._0x1f8e8c.matchAll(/\/([A-Za-z0-9]+)/g)].map(_0x9e89c8 => _0x9e89c8[0x1])) {
                        if (_0x29a8c1 === 'ASCII85Decode' || _0x29a8c1 === "A85") {
                            _0x4ae786 = _0x1f130f(_0x4ae786);
                        }
                        else {
                            if (_0x29a8c1 === 'FlateDecode' || _0x29a8c1 === 'Fl') {
                                _0x4ae786 = await _0x4e6ccc(_0x4ae786);
                            }
                            else {
                                if (_0x29a8c1 === "ASCIIHexDecode" || _0x29a8c1 === "AHx") {
                                    const _0x117d06 = _0x4ae786.replace(/[^0-9A-Fa-f]/g, '');
                                    _0x4ae786 = '';
                                    for (let _0x4ca143 = 0x0; _0x4ca143 + 0x1 < _0x117d06.length; _0x4ca143 += 0x2) {
                                        _0x4ae786 += String.fromCharCode(parseInt(_0x117d06.substr(_0x4ca143, 0x2), 0x10));
                                    }
                                }
                                else {
                                    _0x4ae786 = '';
                                    break;
                                }
                            }
                        }
                    }
                    _0x376506.cache = _0x4ae786;
                    return _0x376506.cache;
                };
                for (const _0x1b9c15 of Object.values(_0x4b3d76).filter(_0x521385 => /\/Type\s*\/ObjStm/.test(_0x521385.dict))) {
                    const _0x2ff139 = await _0x18b1ac(_0x1b9c15), _0x3db55e = +(/\/N\s+(\d+)/.exec(_0x1b9c15.dict) || [0x0, 0x0])[0x1], _0x500aa4 = +(/\/First\s+(\d+)/.exec(_0x1b9c15.dict) || [0x0, 0x0])[0x1], _0x45a3ad = _0x2ff139.slice(0x0, _0x500aa4).trim().split(/\s+/).map(Number);
                    for (let _0x421df = 0x0; _0x421df < _0x3db55e; _0x421df++) {
                        const _0x390950 = _0x45a3ad[0x2 * _0x421df], _0x50fbd2 = _0x45a3ad[0x2 * _0x421df + 0x1], _0x99cd30 = _0x421df + 0x1 < _0x3db55e ? _0x45a3ad[0x2 * _0x421df + 0x3] : _0x2ff139.length - _0x500aa4;
                        if (!_0x4b3d76[_0x390950]) {
                            _0x4b3d76[_0x390950] = { 'id': _0x390950, 'dict': _0x2ff139.slice(_0x500aa4 + _0x50fbd2, _0x500aa4 + _0x99cd30), 'raw': null, 'cache': null };
                        }
                    }
                }
                const _0x3ba8ba = _0x10778a => {
                    const _0x5e234e = _0x14c72c(_0x10778a);
                    return _0x5e234e ? _0x4b3d76[_0x5e234e] ? _0x4b3d76[_0x5e234e].dict : null : _0x10778a;
                }, _0x3b22a6 = (_0x473d87, _0x1e2373 = 0x0) => {
                    const _0x359ec = _0x4b3d76[_0x473d87];
                    if (!_0x359ec || _0x1e2373 > 0x19) {
                        return null;
                    }
                    if (/\/Kids/.test(_0x359ec.dict)) {
                        const _0x42b8b5 = [...(_0x501635(_0x359ec.dict, 'Kids') || '').matchAll(/(\d+)\s+\d+\s+R/g)].map(_0x4fad19 => +_0x4fad19[0x1]);
                        for (const _0x3d0207 of _0x42b8b5) {
                            const _0x1d3b27 = _0x3b22a6(_0x3d0207, _0x1e2373 + 0x1);
                            if (_0x1d3b27) {
                                return _0x1d3b27;
                            }
                        }
                        return null;
                    }
                    return _0x473d87;
                }, _0x14a457 = Object.values(_0x4b3d76).find(_0x256deb => /\/Type\s*\/Catalog/.test(_0x256deb.dict));
                let _0x49d4e8 = _0x14a457 ? _0x3b22a6(_0x14c72c(_0x501635(_0x14a457.dict, "Pages"))) : null;
                if (!_0x49d4e8) {
                    const _0x3503b7 = Object.values(_0x4b3d76).find(_0x4758bb => /\/Type\s*\/Page(?![A-Za-z])/.test(_0x4758bb.dict));
                    _0x49d4e8 = _0x3503b7 && _0x3503b7.id;
                }
                if (!_0x49d4e8) {
                    return '';
                }
                const _0x17ec09 = (_0x92693c, _0x5cda02) => {
                    let _unused_sdu0;
                    let _0x149ca1 = _0x92693c, _0x23e760 = 0x0;
                    while (_0x149ca1 && _0x23e760++ < 0x19) {
                        const _0x462fe1 = _0x4b3d76[_0x149ca1];
                        if (!_0x462fe1) {
                            return null;
                        }
                        const _0x361771 = _0x501635(_0x462fe1.dict, _0x5cda02);
                        if (_0x361771) {
                            return _0x361771;
                        }
                        _0x149ca1 = _0x14c72c(_0x501635(_0x462fe1.dict, "Parent"));
                    }
                    return null;
                }, _0x219a01 = {};
                async function _0x3bffd6(_0x3134c7) {
                    const _0x213cc6 = {}, _0x29d670 = _0x3ba8ba(_0x501635(_0x3134c7, "Font"));
                    if (!_0x29d670) {
                        return _0x213cc6;
                    }
                    for (const _0x1ec343 of _0x29d670.matchAll(/\/([^\s/<>\[\]()]+)\s+(\d+)\s+\d+\s+R/g)) {
                        const _0x221c54 = +_0x1ec343[0x2];
                        if (!_0x219a01[_0x221c54]) {
                            const _0x5f164b = _0x4b3d76[_0x221c54];
                            let _0x520a6a = null;
                            if (_0x5f164b) {
                                const _0x185ac8 = _0x14c72c(_0x501635(_0x5f164b.dict, "ToUnicode"));
                                if (_0x185ac8 && _0x4b3d76[_0x185ac8]) {
                                    _0x520a6a = _0x476979(await _0x18b1ac(_0x4b3d76[_0x185ac8]));
                                }
                                if (_0x520a6a && !_0x520a6a.nb) {
                                    _0x520a6a.nb = /Type0/.test(_0x5f164b.dict) ? 0x2 : 0x1;
                                }
                            }
                            _0x219a01[_0x221c54] = _0x520a6a;
                        }
                        _0x213cc6[_0x1ec343[0x1]] = _0x219a01[_0x221c54];
                    }
                    return _0x213cc6;
                }
                const _0x3c522f = _0x3ba8ba(_0x17ec09(_0x49d4e8, "Resources")) || '', _0x262855 = await _0x3bffd6(_0x3c522f), _0x3d943b = [];
                async function _0x4e92b9(_0x3c551c, _0x3de1f0, _0x1b2d57, _0x42e48a, _0x524e6a) {
                    const _0x1a204a = _0x3da239(_0x3c551c);
                    let _0x1710d6 = _0x42e48a.slice();
                    const _0xe7d953 = [];
                    let _0x50cd43 = [0x1, 0x0, 0x0, 0x1, 0x0, 0x0], _0x2eedf2 = _0x50cd43.slice(), _0x28cdb9 = 0x0, _0x1db5ca = null, _0x4e82e7 = null;
                    const _0x5f4696 = [], _0x17c1e8 = _0x14356a => {
                        let _unused_xngp;
                        if (!_0x1db5ca) {
                            return _0x14356a.replace(/[^ -~ -ÿ]/g, '');
                        }
                        const _0x53252a = _0x1db5ca.nb || 0x1;
                        let _0x1ac787 = '';
                        for (let _0x3187a5 = 0x0; _0x3187a5 + _0x53252a <= _0x14356a.length; _0x3187a5 += _0x53252a) {
                            let _0x5a6123 = 0x0;
                            for (let _0x4a5901 = 0x0; _0x4a5901 < _0x53252a; _0x4a5901++) {
                                _0x5a6123 = _0x5a6123 * 0x100 + _0x14356a.charCodeAt(_0x3187a5 + _0x4a5901);
                            }
                            const _0xdcad02 = _0x1db5ca.map.get(_0x5a6123);
                            if (_0xdcad02 !== undefined) {
                                _0x1ac787 += _0xdcad02;
                            }
                        }
                        return _0x1ac787;
                    }, _0x54059f = () => {
                        const _0x3bbae7 = _0x235316(_0x50cd43, _0x1710d6);
                        _0x4e82e7 = { 'x': _0x3bbae7[0x4], 'y': _0x3bbae7[0x5], 's': '' };
                        _0x3d943b.push(_0x4e82e7);
                    }, _0x4e124e = (_0x13ecc6, _0xccec27) => {
                        _0x2eedf2 = _0x235316([0x1, 0x0, 0x0, 0x1, _0x13ecc6, _0xccec27], _0x2eedf2);
                        _0x50cd43 = _0x2eedf2.slice();
                        _0x4e82e7 = null;
                    };
                    for (const _0x2b61e3 of _0x1a204a) {
                        if (_0x2b61e3.t !== 'op') {
                            _0x5f4696.push(_0x2b61e3);
                            if (_0x5f4696.length > 0x28) {
                                _0x5f4696.shift();
                            }
                            continue;
                        }
                        const _0x5495d2 = _0x5f4696.filter(_0x464982 => _0x464982.t === "num").map(_0x11a595 => _0x11a595.v), _0x321b02 = _0x5f4696[_0x5f4696.length - 0x1];
                        switch (_0x2b61e3.v) {
                            case 'q':
                                _0xe7d953.push(_0x1710d6.slice());
                                break;
                            case 'Q':
                                if (_0xe7d953.length) {
                                    _0x1710d6 = _0xe7d953.pop();
                                }
                                break;
                            case 'cm':
                                if (_0x5495d2.length >= 0x6) {
                                    _0x1710d6 = _0x235316(_0x5495d2.slice(-0x6), _0x1710d6);
                                }
                                break;
                            case 'BT':
                                _0x50cd43 = [0x1, 0x0, 0x0, 0x1, 0x0, 0x0];
                                _0x2eedf2 = _0x50cd43.slice();
                                _0x4e82e7 = null;
                                break;
                            case 'Tf': {
                                const _0x12a880 = _0x5f4696.filter(_0x1da672 => _0x1da672.t === 'n').pop();
                                _0x1db5ca = _0x12a880 ? _0x3de1f0[_0x12a880.v] || null : null;
                                break;
                            }
                            case 'TL':
                                _0x28cdb9 = _0x5495d2[_0x5495d2.length - 0x1] || 0x0;
                                break;
                            case 'Td':
                                _0x4e124e(_0x5495d2[_0x5495d2.length - 0x2] || 0x0, _0x5495d2[_0x5495d2.length - 0x1] || 0x0);
                                break;
                            case 'TD':
                                _0x28cdb9 = -(_0x5495d2[_0x5495d2.length - 0x1] || 0x0);
                                _0x4e124e(_0x5495d2[_0x5495d2.length - 0x2] || 0x0, _0x5495d2[_0x5495d2.length - 0x1] || 0x0);
                                break;
                            case 'T*':
                                _0x4e124e(0x0, -_0x28cdb9);
                                break;
                            case 'Tm':
                                _0x5495d2.length >= 0x6 && (_0x50cd43 = _0x5495d2.slice(-0x6), _0x2eedf2 = _0x50cd43.slice(), _0x4e82e7 = null);
                                break;
                            case 'Tj':
                                if (_0x321b02 && _0x321b02.t === 's') {
                                    if (!_0x4e82e7) {
                                        _0x54059f();
                                    }
                                    _0x4e82e7.s += _0x17c1e8(_0x321b02.v);
                                }
                                break;
                            case '\x27':
                                _0x4e124e(0x0, -_0x28cdb9);
                                _0x321b02 && _0x321b02.t === 's' && (_0x54059f(), _0x4e82e7.s += _0x17c1e8(_0x321b02.v));
                                break;
                            case '\x22':
                                _0x4e124e(0x0, -_0x28cdb9);
                                _0x321b02 && _0x321b02.t === 's' && (_0x54059f(), _0x4e82e7.s += _0x17c1e8(_0x321b02.v));
                                break;
                            case 'TJ':
                                if (_0x321b02 && _0x321b02.t === 'a') {
                                    if (!_0x4e82e7) {
                                        _0x54059f();
                                    }
                                    for (const _0x30e0f6 of _0x321b02.v) {
                                        if (_0x30e0f6.t === 's') {
                                            _0x4e82e7.s += _0x17c1e8(_0x30e0f6.v);
                                        }
                                        else {
                                            if (_0x30e0f6.t === "num" && _0x30e0f6.v < -0xfa) {
                                                _0x4e82e7.s += ' ';
                                            }
                                        }
                                    }
                                }
                                break;
                            case 'Do': {
                                const _0x471d99 = _0x5f4696.filter(_0x4915af => _0x4915af.t === 'n').pop();
                                if (!_0x471d99 || _0x524e6a > 0x2) {
                                    break;
                                }
                                const _0x12bed5 = _0x3ba8ba(_0x501635(_0x1b2d57, "XObject"));
                                if (!_0x12bed5) {
                                    break;
                                }
                                const _0x1a66a7 = new RegExp('/' + _0x471d99.v.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\s+(\\d+)\\s+\\d+\\s+R").exec(_0x12bed5);
                                if (!_0x1a66a7) {
                                    break;
                                }
                                const _0x5af13b = _0x4b3d76[+_0x1a66a7[0x1]];
                                if (!_0x5af13b || !/\/Subtype\s*\/Form/.test(_0x5af13b.dict)) {
                                    break;
                                }
                                const _0x3340a7 = (/\/Matrix\s*\[([^\]]*)\]/.exec(_0x5af13b.dict) || [0x0, ''])[0x1].trim().split(/\s+/).map(Number), _0x1369cc = _0x3ba8ba(_0x501635(_0x5af13b.dict, 'Resources')) || _0x1b2d57, _0x5f4b95 = Object.assign({}, _0x3de1f0, await _0x3bffd6(_0x1369cc));
                                _0x4e82e7 = null;
                                await _0x4e92b9(await _0x18b1ac(_0x5af13b), _0x5f4b95, _0x1369cc, _0x3340a7.length === 0x6 && _0x3340a7.every(isFinite) ? _0x235316(_0x3340a7, _0x1710d6) : _0x1710d6, _0x524e6a + 0x1);
                                break;
                            }
                        }
                        _0x5f4696.length = 0x0;
                    }
                }
                const _0x1b0336 = _0x17ec09(_0x49d4e8, "Contents") || _0x501635(_0x4b3d76[_0x49d4e8].dict, "Contents") || '', _0x1f3f27 = [..._0x1b0336.matchAll(/(\d+)\s+\d+\s+R/g)].map(_0x3fc1a9 => +_0x3fc1a9[0x1]);
                let _0x28f80e = '';
                for (const _0x2d9cfe of _0x1f3f27) {
                    _0x28f80e += await _0x18b1ac(_0x4b3d76[_0x2d9cfe]) + '\x0a';
                }
                await _0x4e92b9(_0x28f80e, _0x262855, _0x3c522f, [0x1, 0x0, 0x0, 0x1, 0x0, 0x0], 0x0);
                const _0x2db81b = _0x3d943b.filter(_0x1ffe84 => _0x1ffe84.s.trim()), _0x87476d = [];
                _0x2db81b.sort((_0x4871e9, _0x30916e) => _0x30916e.y - _0x4871e9.y);
                for (const _0x42ee63 of _0x2db81b) {
                    const _0x17b74d = _0x87476d.find(_0x59f082 => Math.abs(_0x59f082.y - _0x42ee63.y) < 0x3);
                    if (_0x17b74d) {
                        _0x17b74d.a.push(_0x42ee63);
                    }
                    else {
                        _0x87476d.push({ 'y': _0x42ee63.y, 'a': [_0x42ee63] });
                    }
                }
                return _0x87476d.sort((_0x4f5612, _0x544ba7) => _0x544ba7.y - _0x4f5612.y).map(_0x47ab0a => _0x47ab0a.a.sort((_0x2bd6b4, _0x57d75f) => _0x2bd6b4.x - _0x57d75f.x).map(_0x108c08 => _0x108c08.s.trim()).join(' ').replace(/\s+/g, ' ')).join('\x0a');
            }
            const _0xf5329d = "0|Genel\n10|Mevzuat İşleri\n010.01|Kanunlar\n010.02|Tüzükler\n010.03|Yönetmelikler\n010.04|Yönergeler\n010.05|Tebliğler\n010.06|Genelgeler\n010.06.01|İç Genelgeler\n010.06.02|Dış Genelgeler\n010.06.99|Diğer\n010.07|Talimatlar, Duyurular, Sirkülerler\n010.07.01|Talimatlar\n010.07.02|Duyurular\n010.07.03|Sirkülerler\n010.07.99|Diğer\n010.08|Rehber, Kılavuz\n010.09|Standartlar\n010.99|Diğer\n20|Olurlar, Onaylar\n30|Anlaşma, Sözleşme Ve Protokoller\n030.01|Anlaşmalar\n030.02|Sözleşmeler\n030.03|Protokoller\n030.04|Şartnameler\n030.04.01|İdari\n030.04.02|Teknik\n030.04.99|Diğer\n030.99|Diğer\n40|Faaliyet Raporları\n040.01|Haftalık\n040.02|Aylık\n040.03|Üç Aylık\n040.04|Altı Aylık\n040.05|Yıllık\n040.06|Konsolide\n040.99|Diğer\n41|Brifingler Ve Bilgi Notları\n041.01|Brifingler\n041.02|Bilgi Notları\n041.99|Diğer\n42|İstatistikler\n44|Anketler\n45|Görüşler\n045.01|Teknik Ve Mesleki\n045.02|Hukuki\n045.03|İdari\n045.99|Diğer\n50|Kurullar Ve Toplantılar\n050.01|Kurullar, Senatolar, Meclisler\n050.01.01|Seçim Ve Atama İşleri\n050.01.02|Davetler Ve Gündemler\n050.01.03|Tutanaklar\n050.01.04|Kararlar\n050.01.05|Ödemeler\n050.01.99|Diğer\n050.02|Yönetim Kurulları, Belediye Encümeni\n050.02.01|Seçim Ve Atama İşleri\n050.02.02|Davetler Ve Gündemler\n050.02.03|Tutanaklar\n050.02.04|Kararlar\n050.02.05|Ödemeler\n050.02.99|Diğer\n050.03|Danışma, Disiplin, Koordinasyon Kurulları\n050.03.01|Seçim Ve Atama İşleri\n050.03.02|Davetler Ve Gündemler\n050.03.03|Tutanaklar\n050.03.04|Kararlar\n050.03.05|Ödemeler\n050.03.99|Diğer\n050.04|İhtisas Kurulları\n050.04.01|Seçim Ve Atama İşleri\n050.04.02|Davetler Ve Gündemler\n050.04.03|Tutanaklar\n050.04.04|Kararlar\n050.04.05|Ödemeler\n050.04.99|Diğer\n050.05|Konseyler\n050.05.01|Seçim Ve Atama İşleri\n050.05.02|Davetler Ve Gündemler\n050.05.03|Tutanaklar\n050.05.04|Kararlar\n050.05.05|Ödemeler\n050.05.99|Diğer\n050.06|Komite, Komisyonlar\n050.06.01|Seçim Ve Atama İşleri\n050.06.02|Davetler Ve Gündemler\n050.06.03|Tutanaklar\n050.06.04|Kararlar\n050.06.05|Ödemeler\n050.06.99|Diğer\n050.99|Diğer\n51|Bilimsel Ve Kültürel Toplantılar\n051.01|Kongre\n051.02|Konferans\n051.03|Şura\n051.04|Sempozyum\n051.05|Seminer\n051.06|Bienal\n051.07|Kurultay\n051.08|Çalıştay\n051.09|Panel\n051.10|Kolokyum\n051.99|Diğer\n60|Kalite Yönetim Sistemi\n060.01|Kalite El Kitabı\n060.02|Temel Prosedürler Ve Bağlı İşlemler\n060.04|Talimatlar\n060.05|Formlar\n060.07|İzleme Ve Ölçme İşlemleri\n060.07.01|Müşteri Memnuniyeti (Veri Analizi)\n060.07.02|Tetkik İşlemleri\n060.07.03|İzleme Ve Ölçme Sonuçlarının Analizi (Veri Analizi)\n060.07.99|Diğer\n060.08|İyileştirme İşlemleri\n060.08.01|Düzeltici Faaliyetler\n060.08.02|Önleyici Faaliyetler\n060.08.99|Diğer\n060.09|Bireysel Öneriler\n060.10|Yönetimin Gözden Geçirmesi\n060.11|Hizmet (Ürün) Gerçekleştirme\n060.11.01|Planlama\n060.11.02|Hizmete Bağlı Şartların Belirlenmesi Ve Gözden Geçirilmesi\n060.11.03|Tasarım Ve Geliştirme\n060.11.04|Üretim ve hizmet sağlanması\n060.11.99|Diğer\n060.12|Kalibrasyon\n060.99|Diğer\n100|Eğitim Ve Öğretim İşleri (Genel)\n101|Eğitim Ve Öğretim Programları\n101.01|Okul Öncesi, İlkokul Ve Ortaokul Programları\n101.01.01|Hazırlama/Geliştirme\n101.01.02|Uygulama\n101.01.03|İzleme/Değerlendirme\n101.01.04|Revizyon\n101.02|Genel Ortaöğretim Programları\n101.02.01|Hazırlama/Geliştirme\n101.02.02|Uygulama\n101.02.03|İzleme/Değerlendirme\n101.02.04|Revizyon\n101.03|Mesleki Ortaöğretim Programları\n101.04|Yaygın Eğitim Programları\n101.04.01|Hazırlama/Geliştirme\n101.04.02|Uygulama\n101.04.03|İzleme/Değerlendirme\n101.04.04|Revizyon\n101.05|Özel Eğitim Programları\n101.99|Diğer\n102|Eğitim-Öğretim Yılı Çalışma Takvimi\n103|Ölçme Ve Değerlendirme\n105|Okul, Kurum Açma, Kapatma, Devir, Ad Verme İşleri\n105.01|Okul, Kurum, Program Açma/Kapatma/Devir İşlemleri\n105.02|Alan/Dal Açma/Kapatma/Devir İşlemleri\n105.03|Okullara Ad Verme İşlemleri\n105.04|Pansiyon Açma/Kapatma/Kapasite Belirleme İşlemleri\n105.05|Mülga İşlemleri\n105.06|Halk Katkılarına Ait İşlemler\n105.99|Diğer\n110|Kontenjanların Belirlenmesi\n110.01|Okul Düzeyinde\n110.02|Eğitim Bölgesi Düzeyinde\n110.03|Yatılı İlköğretim Öğrenci\n110.04|Yatılı Öğrenci\n110.05|Mesleki Ve Teknik Ortaöğretim Kurumları Alan/Dal\n110.99|Diğer\n115|Yazılı Ve Görsel Eğitim Materyali (Modül)/Ders Kitapları\n115.01|Yazılı Ve Görsel Eğitim Materyali (Modül)\n115.02|Temel Ders Kitapları\n115.03|Öğretmen El Kitapları\n115.04|Yardımcı Ders Kitapları\n115.05|Meb Ders Kitaplarının Yazılması\n115.06|İş Ve İşlem Yaprakları\n115.99|Diğer\n116|Ders Kitapları Ve Diğer Eğitim Araçlarını İnceleme\n116.01|Meb Ders Kitapları\n116.02|Yabancı Ülke Ders Kitapları\n116.03|Özel Sektör Ders Kitapları\n116.99|Diğer\n117|Ders Araç Ve Gereçleri Hazırlama Çalışmaları\n117.01|Temrin Hazırlama\n117.02|Özel Eğitime Yönelik Ders Araç Ve Gereçleri Hazırlama Çalışm.\n117.03|Laboratuar Hazırlığı\n117.99|Diğer\n120|Ders Planları\n120.01|Ünitelendirilmiş Yıllık Plan\n120.02|Günlük Plan\n120.03|Ünite Planı\n120.04|Ders Planı\n120.99|Diğer\n121|Haftalık Ders Dağıtım Çizelgeleri Ve Programları\n121.01|Haftalık Ders Dağıtım Çizelgeleri\n121.02|Haftalık Ders Programları\n121.99|Diğer\n125|Sınav Komisyonları/Sınavlar\n125.01|Sınav Komisyonları\n125.02|Okul/Kurumda Yapılan Sınavlar\n125.03|Okul/Kurumda Yapılan Ortak Sınavlar\n125.04|Merkezi Sistemle Yapılan Sınavlar\n125.05|Yurtdışı Sınavları\n125.99|Diğer\n130|Telafi Eğitimi\n130.01|Yapılamayan Dersler İçin Düzenlenen Yetiştirme/Telafi Eğitimi\n130.02|Meslek Lisesi Dip. Almak İçin Telafi Eğitimi\n130.03|Denklik İşlemlerinde Telafi Eğitimi\n130.04|Çıraklık Eğitiminde Telafi Eğitimi\n130.05|Çıraklık Eğitiminde Yoğunlaştırılmış Eğitim\n130.06|Ustalık Eğitiminde Yoğunlaştırılmış Eğitim\n130.99|Diğer\n135|Eğitim Kurumlarında Açılan Kurslar\n135.01|Meslek Edindirme Eğitimi Ve Kursları\n135.01.01|Kalfalık\n135.01.02|Ustalık\n135.01.03|Eğitici Ustalık\n135.02|Geliştirme Ve Uyum Kursları\n135.03|Yaygın Eğitim Kursları\n135.04|Yetiştirme Ve Hazırlık Kursları\n135.05|Yurtdışı Mesleki Ve Teknik Eğitim Kursları\n135.06|Özel Sektörle İşbirliği Kursları\n135.07|Aile Eğitimi Kursları\n135.99|Diğer\n136|Okul Sağlığı Çalışmaları\n137|Okuma Kültürü Ve Kütüphane İşleri\n140|Taşımalı Eğitim\n141|Tam Gün Tam Yıl Eğitim Uygulaması\n142|İkili Mesleki Eğitim Uygulaması\n145|Mesleki Açık Öğretim İşlemleri\n150|Yüksek Öğrenim İşleri\n150.01|Yurt Dışında Özel Yüksek Öğrenim Göreceklerin İşlemleri\n150.02|Resmi Burslu Öğrenci İşlemleri (T.C. Vatandaşları)\n150.03|Resmi Burslu Öğrenci İşlemleri (Yabancı Uyruklu)\n150.99|Diğer\n155|Yurt Dışı Eğitim-Öğretim İşleri\n155.01|Tcs (Türk Cumhuriyetleri Sınavı) İşleri\n155.02|Yurt Dışı Türkiye Türkçesi Eğitim Öğretim Merkezi İşleri\n155.03|Yurt Dışında Yaşayan Vatandaşların Çocuklarının Eğitimi\n155.03.01|Türkçe Ve Türk Kültürü Dersleri İle İlgili İşlemler\n155.03.02|Yabancı Dil Olarak Türkçe Dersleri İle İlgili İşlemler\n155.04|Öğrenim Belgelerinin Teyidi\n155.99|Diğer\n160|Özel Eğitim, Rehberlik Ve Danışma Hizmetleri\n160.01|Özel Eğitim Hizmetleri\n160.01.01|Özel Eğitim Sınıfları\n160.01.02|Kaynaştırma Eğitimi\n160.01.03|Bireyselleştirilmiş Eğitim Programları\n160.01.04|Özel Eğitimde Aile Eğitimi Çalışmaları\n160.01.05|Evde Özel Eğitime Muhtaç Öğrencilerle İlgili İşlemler\n160.01.06|Bilim Sanat Merkezleri\n160.02|Rehberlik Ve Danışma Hizmetleri\n160.02.01|Psikolojik Ölçme Araçları\n160.02.02|Rehberlik Programları\n160.02.03|Rehberlik Araştırma Merkezleri Modülü Çalışmaları\n160.02.04|Eğitsel Ve Mesleki Rehberlik Çalışmaları\n160.02.05|Hayat Boyu Rehberlik Çalışmaları\n160.02.06|Kariyer Rehberliği Çalışmaları\n160.02.07|Uyumlu Eğitim Ortamları Oluşturma Çalışmaları\n160.02.08|Psikososyal Koruma Ve Önleme Çalışmaları\n160.02.09|Öğrenci Tanıma Ve Tanılamaya İlişkin Çalışmalar\n160.02.10|Aile Eğitim Ve Rehberlik Çalışmaları\n160.02.11|Psikolojik Danışmanlık Ve Rehberlik\n160.03|Tanıtım Ve Yöneltme Çalışmaları\n160.03.01|Mesleki Rehberlik\n160.04|Şiddet Eylemlerinden Ve Zararlı Maddelerden Korunma\n160.04.01|Şiddet Eylemlerinden Korunma\n160.04.02|Zararlı Maddelerden Korunma\n160.99|Diğer\n165|Eğitime Yardımcı Dernek Ve Kurumlar\n165.01|Okul Aile Birlikleri\n165.02|Sivil Toplum Kuruluşları\n165.02.01|Öğrenci Konseyi\n165.02.02|Veli Konseyi\n165.99|Diğer\n166|Türkiyede Eğitimin Finansmanı ve Eğitim Harcamaları Yönetim Sistemi İşlemleri\n166.01|Okul Aile Birliği ve Okul Öncesi İşlemleri (TEFBİS)\n166.01.01|Okul Aile Birliği\n166.01.02|Okul Öncesi\n166.02|Yetki Tanımlaması\n166.03|Veri Aktarma Talepleri\n166.04|Silme ve Düzeltme Talepleri\n166.05|Özel Okul İşlemleri\n166.99|Diğer\n170|Yerel Yönetimlerdeki Eğitimle İlgili Kararlar\n170.01|İdare Meclisi\n170.02|İl Encümeni\n170.03|Özel Komisyonlar\n170.99|Diğer\n175|Meslek Standartları Ve Tanımları\n175.01|Sektör Komiteleri\n175.02|Meslek Standartları\n175.03|Meslek Tanımları\n175.04|Nitelik Kod Kılavuzu Çalışmaları\n175.99|Diğer\n188|Nöbet Hizmetleri\n188.01|Müdür Yardımcısı Nöbeti\n188.02|Öğretmen Nöbeti\n188.03|Belletici Nöbeti\n188.04|Öğrenci Nöbeti\n188.99|Diğer\n198|Eğitimle İlgili Defter, Dosya, Çizelge Ve Belgeler\n198.01|Defterler\n198.01.01|Diploma Defteri\n198.01.02|Tasdikname Defteri\n198.01.03|Sınıf Geçme Defteri\n198.01.04|Yıllık Devamsızlık Defteri\n198.01.05|Öğrenci Kütük Defteri\n198.01.06|Kalfalık Belge Defteri\n198.01.07|Ustalık Belge Defteri\n198.01.08|Eğitici Ustalık Belge Defteri\n198.01.09|Belge Defteri(Okulda Verilen Kurslarla İlgili Belgelerin Defteri)\n198.02|Mezuniyet/Ayrılma Belgeleri\n198.02.01|Diploma\n198.02.02|Geçici Mezuniyet Belgesi\n198.02.03|Öğrenim Belgesi\n198.02.04|Öğrenim Durum Belgesi\n198.02.05|Tasdikname\n198.02.06|Yüz Yüze Eğitimi Tamamlama Belgesi\n198.03|Sertifika,Kurs/Tamamlama Ve Diğer Belgeler\n198.03.01|Sertifika\n198.03.02|Kurs Belgesi\n198.03.03|Kalfalık Belgesi\n198.03.04|Ustalık Belgesi\n198.03.05|Usta Öğreticilik Belgesi\n198.03.06|Bitirme Belgesi\n198.03.07|Mesleki Eğitimi Tamamlama Belgesi\n198.03.08|İş Yeri Açma Belgesi\n198.03.09|Öğrenci Belgesi\n198.04|Öğrenci Kişisel Dosyaları\n198.05|Resmî Burslu Öğrenci Garanti (Sponsorluk) Belgesi\n198.99|Diğer\n199|Eğitim Öğretim İle İlgili Diğer İşler\n200|Öğrenci İşleri (Genel)\n205|Kayıt-Kabul\n210|Nakil Ve Geçişler\n210.01|Nakiller\n210.02|Okul Türleri Arasında Geçiş\n210.03|Teknik Liseye Geçiş\n210.04|Alana/Dal Değişikliği\n210.99|Diğer\n215|Denklik İşleri\n215.01|Yurtdışı Eğitim Denkliği\n215.02|Mesleki Ve Teknik Eğitim Denkliği\n215.99|Diğer\n220|Devam-Devamsızlık\n225|Ödül Ve Disiplin İşleri\n225.01|Ödül İşleri\n225.01.01|Teşekkür Belgesi\n225.01.02|Takdirname Belgesi\n225.01.03|Onur Belgesi\n225.01.04|Başarı Belgesi\n225.01.05|Üstün Başarı Belgesi\n225.02|Disiplin İşleri\n225.99|Diğer\n230|Öğrenci Askerlik İşlemleri\n235|Yabancı Uyruklu Öğrenciler (İlk Ve Orta Öğretim)\n240|Mezunların İzlenmesi\n245|Yatılılık/Bursluluk İşlemleri\n245.01|İl/İlçe Yatılılık Ve Bursluluk Komisyonu İşlemleri\n245.02|Parasız Yatılılık\n245.03|Paralı Yatılılık\n245.04|Bursluluk\n245.04.01|Devlet Bursları\n245.04.02|Şartlı Nakit Transferi İşlemleri\n245.04.03|Özel Kurum/Kuruluşlarca Verilen Burslar\n245.05|Yarım Yatılılık\n245.99|Diğer\n250|Okul Ve İşletmelerde Meslekî Eğitim/Staj Çalışmaları\n250.01|Öğrenci Sigorta İşlemleri\n250.02|İş Kazaları\n250.03|Meslek Hastalıkları\n250.04|Öğrenci Ve Veli Talepleri\n250.99|Diğer\n299|Öğrenci İşleriyle İlgili Diğer İşler\n300|Sosyal Ve Kültürel Faaliyetler (Genel)\n305|Öğrenci Meclisleri\n305.01|Okul Öğrenci Meclisi\n305.02|İl Öğrenci Meclisi\n305.03|Türkiye Öğrenci Meclisi\n305.99|Diğer\n310|Müsamereler, Yarışmalar\n310.01|Kültürel, Bilgi, Beceri Proje Vb. Yarışmalar\n310.01.01|Özel\n310.01.02|Resmi\n310.02|Halkoyunları Yarışmaları\n310.03|Müzik Yarışmaları\n310.04|Uluslar Arası Halkoyunları, Müzik Yarışmaları Ve Festivalleri\n310.05|Sponsorluk\n310.99|Diğer\n315|Kardeş Okul Uygulamaları\n315.01|Yurt İçi\n315.02|Yurt Dışı\n315.99|Diğer\n316|Dost Aile Uygulamaları\n317|Misafir Öğrenci Uygulamaları\n320|Öğrenci/Çocuk Kulüpleri\n325|Toplum Hizmeti Çalışmaları\n330|Spor Faaliyetleri\n330.01|İlkokul Ve Ortaokullar Arası Spor Yarışmaları\n330.02|Ortaöğretim Kurumları Arası Spor Yarışmaları\n330.03|Dünya Liseler Arası Spor Yarışmaları\n330.04|Sponsorluk\n330.99|Diğer\n335|İzcilik Faaliyetleri\n335.01|İzcilik Kampları\n335.02|İzci Ünitelerinin Kurulması\n335.03|İzci Evleri\n335.04|Arama, Kurtarma, İzci Birliği\n335.05|İl İzci Kurulları\n335.06|İzcilerin Eğitimi\n335.99|Diğer\n340|Öğrenci Eğitim Faaliyetleri (Kamplar)\n340.01|Öğrenci Eğitim Yaz Kampları\n340.02|Öğrenci Eğitim Kış Kampları\n340.03|Uluslar Arası Öğrenci Eğitim Kampları\n340.99|Diğer\n349|Sosyal Ve Kültürel Faaliyetlerle İlgili Diğer İşler\n350|Öğretmen Yetiştirme Ve Eğitimi İşleri (Genel)\n355|Yök'Le İlişkiler\n355.01|Üniversitelerle İlişkiler\n355.02|Eğitim Fakülteleri İle İlişkiler\n355.03|Beden Eğitimi Ve Spor Yüksek Okulu İle İlişkiler\n355.99|Diğer\n360|Öğretmen Yeterlikleri\n360.01|Okul Temelli Meslekî Gelişim (Dünya Bankası Destekli)\n360.02|Ortaöğretim Kademesi Öğretmenlerinin Özel Alan Yeterliklerinin Belirlenmesi (Ab Destekli)\n360.03|Öğretmen Mesleği Genel Yeterlikleri İle İlköğretim Kademesi Öğretmenlerine İlişkin Özel Alan Yeterlikleri\n360.04|Öğretmenliğe Atanacakların Alanlarıyla İlgili İşlemler\n360.05|Yurt Dışından Mezun Olan Öğretmen Adayları İle İlgili İşlemler\n360.99|Diğer\n399|Öğretmen Yetiştirme Ve Eğitimiyle İlgili Diğer İşler\n400|Özel Öğretim Kurumları (Genel)\n405|Özel Okul İşleri\n405.01|Türk Okulları\n405.02|Yabancı Okulları\n405.03|Azınlık Okulları\n405.04|Uluslar Arası Okullar\n405.05|Özel Okullarla İlgili Verilen Görüşler\n405.99|Diğer\n410|Özel Yaygın Eğitim Kurumları\n410.01|Özel Dershane İşleri\n410.02|Sürücü Kursları İşleri\n410.03|Çeşitli Özel Kurslar\n410.04|Uzaktan Öğretim Yapan Kuruluşlar\n410.05|Hizmetiçi Eğitim Merkezleri\n410.06|Öğrenci Etüd Eğitim Merkezleri\n410.07|Özel Eğitim Ve Rehabilitasyon Merkezleri\n410.08|Özel Yurtlar\n410.99|Diğer\n415|Trafik Genel Eğitim Planı\n420|Öğrenim Ücreti İşleri\n425|Ücretsiz Öğrenci/Kursiyer İşleri\n449|Özel Eğitimle İlgili Diğer İşler\n450|Eğitim Teknolojileri İşleri (Genel)\n451|Kalite Kontrol İşleri(Radyo, Tv Prog., Eğitim Yazılımları)\n455|Radyo Ve Televizyon Programlarının Hazırlanması\n460|Ürün Tasarım Ve Planlama İşleri\n460.01|Senaryo Hazırlama Ve Tasarım\n460.02|Videografik Ve Animasyon Hazırlama\n460.03|Eğitim Materyalleri Grafik Tasarımları\n460.04|Eğitim Yazılımı Tasarım Çalışmaları\n460.99|Diğer\n465|Dijital Fotoğraf Arşivi İşleri\n470|Eğitim Materyallerini Çoğaltma, Pazarlama Ve Yayınlama İşleri\n471|Sınav Evrakının Dağıtımı\n475|Soru Hazırlama İşleri\n480|Merkezi Sistem Sınavları\n480.01|Seviye Belirleme Sınavı (Sbs)\n480.02|Devlet Parasız Yatılılık Ve Bursluluk Sınavı (Dpybs)\n480.03|Açık Öğretim Okulları Sınavları (Aöos)\n480.04|Motorlu Taşıt Sürücü Adayları Sınavları (Mtsas)\n480.05|Diğer Sınavlar (Protokollü Sınavlar)\n480.06|Merkezi Sistem Sınavları İle İlgili İtirazlar\n480.99|Diğer\n481|Uzaktan Eğitim Ve E-Öğrenme İşleri\n481.01|Uzaktan Eğitim\n481.02|Elektronik Eğitim Materyalleri\n481.03|E-İçerik Hazırlama\n481.04|Teknoloji Destekli Eğitim\n481.05|Eğitim Bilişm Ağı\n485|Çağrı Merkezi (Call Center)\n485.01|Talepler\n485.02|Şikâyetler\n485.03|Bilişim Teknolojisi Sınıfları Arıza Bildirimleri\n485.99|Diğer\n490|Açık Öğretim Okulları\n490.01|Açık Öğretim Liseleri\n490.02|Açık İlköğretim Okulları\n490.03|Mesleki Açık Öğretim Liseleri\n490.04|Mesleki Ve Teknik Açık Öğretim Okulları\n490.05|Açık Öğretim Ortaokulu\n490.99|Diğer\n495|Açık Öğretim Kurumları Öğrenci Ders Notlarının Hazırlanması Ve Halk Eğitim Merkezi Müdürlükleri\n499|Eğitim Teknolojileriyle İlgili Diğer İşler\n600|Araştırma Ve Planlama İşleri(Genel)\n601|Teşkilatlanma İşleri\n601.01|Kuruluş, Yapılanma\n601.02|Yetkilendirme, Yetki Değişikliği\n601.03|Yönetimi Geliştirme\n601.04|Teşkilat Şemaları Ve Kadrolar\n601.04.01|Teşkilat Şemaları\n601.04.02|Norm Kadro Çalışmaları\n601.04.02.01|Görev/İş Tanımları\n601.04.02.02|Norm Kadro Pozisyonları\n601.04.02.99|Diğer\n601.04.99|Diğer\n601.99|Diğer\n602|Plan Ve Program İşleri\n602.01|Kalkınma Planı\n602.01.01|Hazırlık Çalışmaları\n602.01.02|İzleme Ve Değerlendirme\n602.01.99|Diğer\n602.02|Orta Vadeli Plan/Program\n602.02.01|Hazırlık Çalışmaları\n602.02.02|İzleme Ve Değerlendirme\n602.02.99|Diğer\n602.03|Yıllık Plan/Program\n602.03.01|Hazırlık Çalışmaları\n602.03.02|İzleme Ve Değerlendirme\n602.03.99|Diğer\n602.04|Stratejik Plan\n602.04.01|Veri Toplama\n602.04.02|Analiz Ve Raporlama\n602.04.03|Revizyon\n602.04.99|Diğer\n602.05|Eylem Planları\n602.06|Yönetim/İş Planları\n602.07|Yatırım Programları\n602.07.01|Hazırlık Çalışmaları\n602.07.02|Yatırım Revizyonu\n602.07.03|Ek Ödenek\n602.07.04|Ödenek Aktarma\n602.07.05|Serbest Bırakma\n602.07.06|Maliyet Revizyonu\n602.07.07|Dönem Gerçekleştirme Raporları\n602.07.99|Diğer\n602.08|Performans Programı\n602.08.01|Veri Toplama\n602.08.02|Maliyetlendirme\n602.08.03|İzleme Ve Değerlendirme\n602.08.04|Revize İşlemleri\n602.08.99|Diğer\n602.99|Diğer\n604|Proje İşleri\n604.01|Araştırma Projeleri\n604.01.01|Başvurular Ve Proje Önerileri\n604.01.02|Değerlendirme Ve Onay\n604.01.03|İzleme Ve Raporlandırma\n604.01.04|Değişiklikler Ve Tadilatlar\n604.01.05|Ödemeler Ve Mali İncelemeler\n604.01.06|Tescil/Patent/Mülkiyet İşlemleri\n604.01.99|Diğer\n604.02|Araştırma/Geliştirme Projeleri\n604.02.01|Başvurular Ve Proje Önerileri\n604.02.02|Değerlendirme Ve Onay\n604.02.03|İzleme Ve Raporlandırma\n604.02.04|Değişiklikler Ve Tadilatlar\n604.02.05|Ödemeler Ve Mali İncelemeler\n604.02.06|Tescil/Patent/Mülkiyet İşlemleri\n604.02.99|Diğer\n604.99|Diğer\n605|Araştırma İşleri\n605.01|Veri Toplama\n605.02|Raporlama\n605.99|Diğer\n609|Koordinasyon İşleri\n610|Soru Önergeleri\n611|Çevre İşleri\n611.01|Çevre Yönetimi\n611.02|Çed\n611.03|Denetim\n611.04|İklim Değişikliği\n611.99|Diğer\n612|İç Kontrol\n612.01|İç Kontrol Sistemi Ve Standartlar\n612.01.01|Süreçler\n612.01.02|İzleme Ve Değerlendirme\n612.01.03|İnceleme Ve Raporlama\n612.01.99|Diğer\n612.02|Ön Mali Kontrol\n612.99|Diğer\n619|Araştırma Ve Planlama İle İlgili Diğer İşler\n620|Basın Ve Halkla İlişkiler (Genel)\n621|Basın İşleri\n621.01|Basın Toplantıları\n621.02|Basına Verilen Demeçler\n621.03|Tekzipler\n621.04|Basında Yer Alan Haberler\n621.05|Basın Özetleri\n621.99|Diğer\n622|Talep, Şikayet, Görüşler\n622.01|Talep Ve Şikayetler\n622.02|Görüş Ve Teklifler\n622.03|Bilgi Ve Belge Talepleri\n622.99|Diğer\n639|Basın Ve Halkla İlişkiler Konusunda Diğer İşler\n640|Hukuk İşleri (Genel)\n641|Dava Dosyaları\n641.01|Avrupa İnsan Hakları Mahkemesi\n641.02|Tahkim\n641.02.01|Ulusal\n641.02.02|Uluslar Arası\n641.02.99|Diğer\n641.03|Adli Davalar\n641.03.01|Hukuk\n641.03.02|Ceza\n641.03.03|İcra\n641.03.99|Diğer\n641.04|İdari Davalar\n641.05|Vergi Davaları\n641.99|Diğer\n645|Tebligatlar\n646|Vekaletnameler, Azilnameler\n650|Bilirkişi Ve Ekspertiz\n651|Uzlaşma/ Sulh İşlemleri\n659|Hukukla İlgili Diğer İşler\n660|Teftiş/Denetim İşleri(Genel)\n661|Plan Ve Programları\n661.01|Yıllık\n661.02|Dönemsel\n661.99|Diğer\n662|Görev Emirleri\n663|Denetim,İnceleme,Soruşturma Ve Araştırma\n663.01|Cevaplı\n663.02|Denetim\n663.03|Genel Durum\n663.04|Ön İnceleme\n663.05|İnceleme\n663.06|Basit\n663.07|Soruşturma\n663.08|Araştırma\n663.09|Bilgi\n663.99|Diğer\n667|İhbar Ve Suç Duyuruları\n667.01|İhbar\n667.02|Suç Duyuruları\n667.99|Diğer\n668|Yüksek Denetleme Ve Kit Komisyonu\n668.01|Yüksek Denetleme Kurulu Raporları\n668.01.01|İvedi Durum Raporları\n668.01.02|Özel İnceleme Raporları\n668.01.03|Dönem Raporları\n668.01.04|Yıllık Raporlar\n668.01.05|Kuruluşun Cevabi Raporları\n668.01.99|Diğer\n668.02|Kit Komisyonu Raporları\n668.99|Diğer\n679|Teftiş/Denetim İle İlgili Diğer İşler\n700|Bilgi Sistemleri (Genel)\n702|Yazılım Geliştirme Ve Kodlama Çalışmaları\n702.01|Analiz Ve Tasarım Çalışmaları\n702.02|Kodlama Çalışmaları\n702.03|Test Çalışmaları\n702.99|Diğer\n703|Bilgi İşletim Sistemleri Planlama Ve Değerlendirme\n703.01|Proje Yönetimi\n703.02|Değişiklik Yönetimi\n703.03|Güvenlik Yönetimi\n703.04|Kaynak Yönetimi\n703.05|Konfigürasyon Yönetimi\n703.06|Olağanüstü Durum Yönetimi\n703.07|Problem Yönetimi\n703.99|Diğer\n704|Hatlar\n704.01|İnternet\n704.02|Data Hattı\n704.03|İntranet\n704.99|Diğer\n705|Sistem İle İlgili Talepler\n705.01|Yazılım Talepleri\n705.02|Donanım Talepleri\n705.99|Diğer\n708|Veri Girişi, İşleme Ve Aktarma İşleri\n708.01|Kayıt\n708.02|Düzeltme\n708.03|Silme\n708.04|Aktarma\n708.05|Sorgulama\n708.99|Diğer\n710|E-Uygulamalar\n710.01|Web Sayfası\n710.02|Abonelik\n710.03|E-İmza\n710.04|E-Posta İşlemleri\n710.05|Liste İşlemleri\n710.99|Diğer\n713|Kullanım Ve Erişim Yetkileri\n713.01|Yetki Verilmesi\n713.02|Yetki Kaldırılması\n713.03|Yetki Değişikliği\n713.99|Diğer\n719|Bilgi Sistemleri İle İlgili Diğer İşler\n720|Dış İlişkiler Ve Avrupa Birliği (Genel)\n721|Uluslararası Hukuk\n724|Ülkelerle İlişkiler\n724.01|İkili İlişkiler\n724.01.01|Genel Bilgiler\n724.01.02|Anlaşmalar, Sözleşmeler, Protokoller\n724.01.03|İşbirliği\n724.01.04|Sorunlar\n724.01.05|Yardımlar\n724.01.99|Diğer\n724.02|Çok Taraflı İlişkileri\n724.02.01|Genel Bilgiler\n724.02.02|Anlaşmalar, Sözleşmeler, Protokoller\n724.02.03|İşbirliği\n724.02.04|Sorunlar\n724.02.05|Yardımlar\n724.02.99|Diğer\n724.03|Türk Ve Müslüman Topluluklarla İlişkiler\n724.03.01|Genel Bilgiler\n724.03.02|Anlaşmalar, Sözleşmeler, Protokoller\n724.03.03|İşbirliği\n724.03.04|Sorunlar\n724.03.05|Yardımlar\n724.03.99|Diğer\n724.99|Diğer\n730|Uluslararası Ve Bölgesel Kuruluşlarla İlişkiler\n730.01|Politikalar\n730.02|Mevzuat Ve Üyelik İşlemleri\n730.02.01|Tüzük\n730.02.02|Üyelik İşlemleri\n730.02.03|Katkı Payları\n730.02.99|Diğer\n730.03|Toplantılar\n730.03.01|Genel Kurul\n730.03.02|Yönetim Kurulu\n730.03.03|Komiteler\n730.03.04|Alt Komiteler\n730.03.05|Çalışma Grupları\n730.03.99|Diğer\n730.06|Projeler\n730.06.01|Uluslararası Projeler\n730.06.02|Türkiye'Ye Yönelik Projeler\n730.06.99|Diğer\n730.07|İşbirliği\n730.08|Rapor, İnceleme, Anket Ve İstatistikler\n730.08.01|Raporlar\n730.08.02|İncelemeler\n730.08.03|Anketler\n730.08.04|İstatistikler\n730.08.99|Diğer\n730.09|İrtibat Büroları\n730.10|Bilgi Ve Belge Talepleri\n730.11|Başvuru Ve Şikayetler\n730.12|Denetim\n730.13|Yardımlar\n730.99|Diğer\n740|Avrupa Birliği (Ab) İle İlişkiler (Genel)\n741|Ab Hukuku\n741.01|Türkiye-Ab Ortaklık Hukuku\n741.01.01|Ortaklık Organlarının Kararları\n741.01.02|İçtihad\n741.01.99|Diğer\n741.02|Ab Hukuku Alanındaki Gelişmeler\n741.02.01|Birincil Hukuk\n741.02.02|İkincil Hukuk\n741.02.03|İçtihad\n741.02.99|Diğer\n741.99|Diğer\n742|Ab Karar Alma Mekanizması İle İlişkiler\n742.01|Bakanlar Konseyi\n742.02|Avrupa Komisyonu\n742.03|Avrupa Parlamentosu\n742.04|Avrupa Konseyi\n742.05|Adalet Divanı\n742.06|Sayıştay\n742.07|Ekonomik Ve Sosyal Komite\n742.08|Bölgeler Komitesi\n742.09|Avrupa Merkez Bankası\n742.10|Avrupa Yatırım Bankası\n742.11|Ombudsman\n742.99|Diğer\n743|Gümrük Birliği Ve Ortaklık Organları\n743.01|Ortaklık Konseyi\n743.02|Ortaklık Komitesi\n743.02.01|Tarım Ve Balıkçılık Alt Komitesi\n743.02.01.01|Toplantılar\n743.02.01.02|Çalışma Grupları\n743.02.01.99|Diğer\n743.02.02|İç Pazar Ve Rekabet Alt Komitesi\n743.02.03|Ticaret, Sanayi Ve Akçt Ürünleri Alt Komitesi\n743.02.04|Ekonomik Ve Parasal Konular, Sermaye Hareketleri Ve İstatistik Alt K.\n743.02.05|Teknolojik Yenilik, Eğitim Ve Araştırma Programları Alt Komitesi\n743.02.06|Ulaştırma, Çevre Ve Enerji (Trans-Avrupa Şebekeleri Dahil) Alt Komitesi\n743.02.07|Bölgesel Kalkınma Gelişme, İstihdam Ve Sosyal Politika Alt Komitesi\n743.02.08|Gümrük, Vergilendirme, Uyuşturucu Trafiği Ve Kara Para Aklama Alt K.\n743.02.99|Diğer\n743.03|Karma Parlamento Komisyonu\n743.04|Gümrük İşbirliği Komitesi\n743.05|Gümrük Birliği Ortak Komitesi\n743.06|Karma İstişare Komitesi\n743.07|Ab Teknik Komiteleri Ve Çalışma Grupları\n743.99|Diğer\n744|Ab Katılım Süreci\n744.01|Katılım Ortaklığı Belgesi\n744.02|Ulusal Program\n744.02.01|Hazırlık Çalışmaları\n744.02.02|İzlenmesi\n744.02.99|Diğer\n744.03|İlerleme Raporları\n744.04|Katılım Öncesi Mali İzleme Süreci\n744.05|Katılım Müzakereleri\n744.05.01|Müzakere Süre\n744.05.02|Strateji/Eylem Planı\n744.05.03|Müzakere Pozisyonu\n744.05.04|Mevzuat Taslakları\n744.05.05|Çalışma Grupları\n744.05.99|Diğer\n744.06|Siyasi Kriterler\n744.07|Ekonomik Kriterler\n744.08|İç Koordinasyon Uyum Komitesi\n744.09|Türkiye’Nin Avrupa Birliği İletişim Stratejisi\n744.10|Çeviri Eşgüdüm Çalışmaları\n744.10.01|Ab Müktesebatının Çeviri İşlemleri Ve Eşgüdümü\n744.10.02|Türk Mevzuatının Çeviri İşlemleri Ve Eşgüdümü\n744.10.03|Ab Terminolojisi Veri Tabanı\n744.10.99|Diğer\n744.11|Mevzuat Uyum Ulusal Veri Tabanı\n744.99|Diğer\n745|Topluluk Programları Ve Ajanslar\n745.01|Programlar\n745.01.01|Eğitim, Gençlik Ve Kültür Programları\n745.01.02|Araştırma Ve Teknolojik Gelişme Programları\n745.01.03|Rekabet Edebilirlik Ve Yenilik Çerçeve Programları\n745.01.99|Diğer\n745.02|Ajanslar\n745.99|Diğer\n746|Ab-Türkiye Mali İşbirliği\n746.01|Ipa(Katılım Öncesi Yardım Aracı-Instrument For Pre-Accession)\n746.01.01|Programlama Süreci\n746.01.01.01|Proje Teklifleri\n746.01.01.02|Proje Fişleri (Raporları)\n746.01.01.03|Fiş Değişiklikleri (Revizyon)\n746.01.01.04|İzleme ve Değerlendirme\n746.01.02|Projeler\n746.01.02.01|Proje Teklifleri\n746.01.02.02|Proje Fişleri (Raporları)\n746.01.02.03|Fiş Değişiklikleri (Revizyon)\n746.01.02.04|İzleme Ve Değerlendirme\n746.01.02.99|Diğer\n746.01.03|Abgs’Nin Faydalanıcısı Olduğu Projeler\n746.01.03.01|Proje Teklifleri\n746.01.03.02|Proje Fişleri (Raporları)\n746.01.03.03|Fiş Değişiklikleri (Revizyon)\n746.01.03.04|İzleme Ve Değerlendirme\n746.01.03.99|Diğer\n746.01.04|Sınır Ötesi İşbirliği\n746.01.05|Operasyonel Programlar\n746.01.06|İzleme Komiteleri\n746.01.99|Diğer\n746.02|Çok Faydalanıcılı\n746.99|Diğer\n748|Ab Ve Üye Ülke Teknik Yardımları\n748.01|Ab Teknik Yardımları\n748.01.01|Taıex\n748.01.01.01|Uzman Desteği\n748.01.01.02|İnceleme Gezileri\n748.01.01.03|Seminer/Çalışma Grupları\n748.01.01.99|Diğer\n748.01.02|Eşleştirme (Twinning)\n748.01.02.01|Standart Eşleştirme\n748.01.02.02|Kısa Süreli Eşleştirme\n748.01.02.99|Diğer\n748.01.99|Diğer\n748.02|Üye Ülke Teknik Yardımları\n748.02.01|Matra/G2G.Nl\n748.02.02|Matra-Mtec\n748.02.99|Diğer\n748.99|Diğer\n749|Dış İlişkiler Ve Ab İle İlgili Diğer İşler\n750|Emlak Ve Yapım İşleri (Genel)\n751|Toplulaştırma İşlemleri\n752|Kamulaştırma Ve İrtifak Hakkı\n752.01|Kamulaştırma\n752.01.01|Kamu Yararı Kararı Ve Onay İşleri\n752.01.02|Teknik Çalışmalar\n752.01.03|Bedel Takdir Ve Uzlaşma\n752.01.04|Sorunlar\n752.01.05|Zarar Ve Ziyan\n752.01.06|Ödeme İşleri\n752.01.99|Diğer\n752.02|İrtifak Hakkı İşlemleri\n752.99|Diğer\n753|Kadastro Çalışmaları\n754|İmar İşleri\n755|Yapım (İnşaat) İşleri\n755.01|Etüd-Proje Ve Fizibilite İşleri\n755.02|İhale İşleri\n755.02.01|İzin Ve Onay İşleri\n755.02.02|Yaklaşık Maliyet Hesabı\n755.02.03|İhale İlan İşleri\n755.02.04|Şartnameler\n755.02.05|Başvuru İşlemleri Ve Tutanaklar\n755.02.06|Komisyon İşlemleri\n755.02.07|İtirazlar\n755.02.08|Sözleşme\n755.02.09|Kesin Teminat\n755.02.99|Diğer\n755.03|Uygulama İşleri\n755.03.01|İş Programı\n755.03.02|Ruhsatlandırma\n755.03.03|Hammadde Temini/Malzeme Seçimi\n755.03.04|Keşif Artışı\n755.03.05|Süre Uzatımı Ve Ödenek Dilim Değişikliği\n755.03.06|Birim Fiyat Ve Yeni Fiyat\n755.03.99|Diğer\n755.04|İnceleme Ve Kontrol İşleri\n755.05|Hakedişler Ve Ödemeler\n755.06|Geçici Ve Kesin Kabuller\n755.06.01|Geçici Ve Kesin Kabuller\n755.06.02|Fesih, Tasfiye Ve Devir İşlemleri\n755.06.99|Diğer\n755.07|Kesin Hesap İşlemleri\n755.07.01|Kesin Hesap\n755.07.02|Ssk İlişkisizlik Belgesi\n755.07.03|İş Deneyim Belgesi Verilmesi\n755.07.04|Teminatların İadesi\n755.07.99|Diğer\n755.99|Diğer\n756|Taşınmaz İşlemleri\n756.01|Tahsis, Devir Ve Takas\n756.02|Satış Ve Kiralama\n756.03|Envanter\n756.99|Diğer\n757|Harita Ve Fotoğraf İşleri\n757.01|Talepler\n757.02|Yapım Ve Güncelleme\n757.03|Sayısallaştırma\n757.04|Kayıt Ve Envanter\n757.99|Diğer\n769|Emlak Ve Yapımla İlgili Diğer İşler\n770|Eğitim İşleri (Genel)\n771|Eğitim Planları\n772|Burs İşleri\n772.01|Kontenjan Ve Duyurular\n772.02|Başvuru Ve Değerlendirme\n772.03|Ödemeler\n772.04|Tahsil,Takip, Atama\n772.99|Diğer\n773|Staj İşleri\n773.01|Kontenjan İşlemleri\n773.02|İzleme Ve Değerlendirme\n773.03|Belgelendirme\n773.99|Diğer\n774|Eğitimler, Kurslar\n774.01|Mesleki Yeterlilik Ve Gelişim\n774.01.01|Teklifler\n774.01.02|Program\n774.01.03|Duyuru\n774.01.04|Eğitici Temini\n774.01.05|Kayıt, Katılım Listeleri\n774.01.06|Eğitim Materyali\n774.01.07|Sınav\n774.01.08|Belgelendirme\n774.01.09|Yeterlilik\n774.01.99|Diğer\n774.02|Dil Eğitimi\n774.02.01|Teklifler\n774.02.02|Program\n774.02.03|Duyuru\n774.02.04|Eğitici Temini\n774.02.05|Kayıt, Katılım Listeleri\n774.02.06|Eğitim Materyali\n774.02.07|Sınav\n774.02.08|Belgelendirme\n774.02.09|Yeterlilik\n774.02.99|Diğer\n774.03|Rotasyon\n774.03.01|Teklifler\n774.03.02|Program\n774.03.03|Duyuru\n774.03.04|Eğitici Temini\n774.03.05|Kayıt, Katılım Listeleri\n774.03.06|Eğitim Materyali\n774.03.07|Sınav\n774.03.08|Belgelendirme\n774.03.09|Yeterlilik\n774.03.99|Diğer\n774.04|İntibak/Oryantasyon\n774.04.01|Teklifler\n774.04.02|Program\n774.04.03|Duyuru\n774.04.04|Eğitici Temini\n774.04.05|Kayıt, Katılım Listeleri\n774.04.06|Eğitim Materyali\n774.04.07|Sınav\n774.04.08|Belgelendirme\n774.04.09|Yeterlilik\n774.04.99|Diğer\n774.05|Görevde Yükselme\n774.05.01|Teklifler\n774.05.02|Program\n774.05.03|Duyuru\n774.05.04|Eğitici Temini\n774.05.05|Kayıt, Katılım Listeleri\n774.05.06|Eğitim Materyali\n774.05.07|Sınav\n774.05.08|Belgelendirme\n774.05.09|Yeterlilik\n774.05.99|Diğer\n774.06|Aday Memur\n774.06.01|Teklifler\n774.06.02|Program\n774.06.03|Duyuru\n774.06.04|Eğitici Temini\n774.06.05|Kayıt, Katılım Listeleri\n774.06.06|Eğitim Materyali\n774.06.07|Sınav\n774.06.08|Belgelendirme\n774.06.09|Yeterlilik\n774.06.99|Diğer\n774.07|Kariyer Uzman\n774.07.01|Teklifler\n774.07.02|Program\n774.07.03|Duyuru\n774.07.04|Eğitici Temini\n774.07.05|Kayıt, Katılım Listeleri\n774.07.06|Eğitim Materyali\n774.07.07|Sınav\n774.07.08|Belgelendirme\n774.07.09|Yeterlilik\n774.07.99|Diğer\n774.08|Kişisel Gelişim Ve Motivasyon\n774.08.01|Teklifler\n774.08.02|Program\n774.08.03|Duyuru\n774.08.04|Eğitici Temini\n774.08.05|Kayıt, Katılım Listeleri\n774.08.06|Eğitim Materyali\n774.08.07|Sınav\n774.08.08|Belgelendirme\n774.08.09|Yeterlilik\n774.08.99|Diğer\n774.09|Bilgilendirme-Bilinçlendirme\n774.09.01|Teklifler\n774.09.02|Program\n774.09.03|Duyuru\n774.09.04|Eğitici Temini\n774.09.05|Kayıt, Katılım Listeleri\n774.09.06|Eğitim Materyali\n774.09.07|Sınav\n774.09.08|Belgelendirme\n774.09.09|Yeterlilik\n774.09.99|Diğer\n774.99|Diğer\n779|Rehberlik, Danışmanlık İşleri\n799|Eğitimle İlgili Diğer İşler\n800|İdari Ve Sosyal İşler (Genel)\n801|Taşıt Ve İş Makineleri\n801.01|Taşıt\n801.01.01|Plaka, Ruhsat Ve Muayene İşleri\n801.01.02|Akaryakıt İşleri\n801.01.03|Tahsis, Sevk Ve Kontrol İşleri\n801.01.04|Kaza İşleri\n801.01.99|Diğer\n801.02|İş Makineleri\n801.02.01|Plaka, Ruhsat Ve Muayene İşleri\n801.02.02|Akaryakıt İşleri\n801.02.03|Tahsis, Sevk Ve Kontrol İşleri\n801.02.04|Kaza İşleri\n801.02.99|Diğer\n801.99|Diğer\n802|Ulaştırma Ve Servis İşleri\n803|Resmi Mühür İş Ve İşlemleri\n804|Evrak Kayıt Ve Sevk İşlemleri\n804.01|Gelen-Giden Evrak\n804.02|Kontrollü Evrak İşlemleri\n804.03|Yanlış Evrakın İade İşlemleri\n804.99|Diğer\n805|Belge Yönetimi Ve Arşiv İşlemleri\n805.01|Belge Yönetimi\n805.01.01|Saklama Süreli Dosya Planı\n805.01.02|Kodlama İşlemleri\n805.01.99|Diğer\n805.02|Arşiv Yönetimi\n805.02.01|Devir-Teslim İşlemleri\n805.02.02|Ayıklama Ve İmha İşlemleri\n805.02.02.01|Ayıklama Ve İmha\n805.02.02.02|Uygunluk Görüşü\n805.02.02.99|Diğer\n805.02.03|Tasnif (Sınıflandırma) İşlemleri\n805.02.04|İnceleme Ve Denetleme\n805.02.05|Arşivlerden Yararlanma\n805.02.99|Diğer\n805.03|Tasnif (Sınıflandırma) İşlemleri\n805.04|İnceleme ve Denetleme\n805.05|Arşivlerden Yararlanma\n805.99|Diğer\n806|Kütüphane Ve Dokümantasyon İşleri\n806.01|Derme Geliştirme Ve Derleme İşleri\n806.01.01|Kitaplar\n806.01.02|Süreli Yayınlar\n806.01.03|Tezler\n806.01.04|Yazma Ve Nadir Eserler\n806.01.05|Veritabanları, Elektronik Ürün Ve Yayınlar\n806.01.99|Diğer\n806.02|Kullanıcı Hizmetleri\n806.02.01|Ödünç Verme İşlemleri\n806.02.02|Araştırma Hizmetleri\n806.02.03|Danışma Hizmetleri\n806.02.04|Elektronik Hizmetler\n806.02.99|Diğer\n806.99|Diğer\n807|Bakım-Onarım İşleri\n807.01|Bina Ve Tesisler\n807.02|Tesisat\n807.03|Mekanik\n807.04|Elektronik Ve Teknik Cihaz\n807.05|Taşıt Ve İş Makineleri\n807.99|Diğer\n808|Temizlik İşleri\n809|Taşınır Mal İşlemleri\n809.01|İstek\n809.02|Devir, Giriş-Çıkış İşlemleri\n809.03|Sayım Ve Döküm\n809.04|Kesin Hesap\n809.05|Taşınır Kayıt Kontrol Yetkilisi\n809.99|Diğer\n810|Sigorta İşleri\n810.01|Dahili Sigorta\n810.01.01|Yangın\n810.01.02|Nakliyat\n810.01.03|Kaza\n810.01.04|Mühendislik\n810.01.99|Diğer\n810.02|Harici Sigorta\n810.02.01|Yangın\n810.02.02|Nakliyat\n810.02.03|Kaza\n810.02.04|Mühendislik\n810.02.99|Diğer\n810.99|Diğer\n811|İletişim Ve Haberleşme İşleri\n811.01|Telefon\n811.01.01|Sabit\n811.01.02|Gsm\n811.01.03|Mobil\n811.01.99|Diğer\n811.02|Kablolu Tv\n811.03|Telsiz\n811.04|Faks\n811.05|İnternet\n811.99|Diğer\n812|Çevre Düzenleme İşleri\n813|Sosyal İşler\n813.01|Sosyal Tesisler\n813.01.01|Eğitim Tesisi, Misafirhane Ve Kamp\n813.01.01.01|Müracaat\n813.01.01.02|Tahsis\n813.01.01.03|Tahliye\n813.01.01.99|Diğer\n813.01.02|Lojman\n813.01.02.01|Müracaat\n813.01.02.02|Tahsis\n813.01.02.03|Tahliye\n813.01.02.99|Diğer\n813.01.03|Kreş Ve Gündüz Bakımevi\n813.01.03.01|Müracaat\n813.01.03.02|Tahsis\n813.01.03.03|Tahliye\n813.01.03.99|Diğer\n813.01.04|Spor Tesisi\n813.01.04.01|Müracaat\n813.01.04.02|Tahsis\n813.01.04.03|Tahliye\n813.01.04.99|Diğer\n813.01.05|Yemekhane, Kafeterya Ve Çay Ocağı\n813.01.05.01|Müracaat\n813.01.05.02|Tahsis\n813.01.05.03|Tahliye\n813.01.05.99|Diğer\n813.01.99|Diğer\n813.02|Temsili Ağırlamalar (Yemek, Araç Vb.)\n813.03|Sportif Faaliyetler\n813.99|Diğer\n814|Kampanyalar\n815|Sosyal Yardımlar\n819|İdari Ve Sosyal İşlerle İlgili Diğer İşler\n820|Tanıtım Ve Yayın İşleri (Genel)\n821|Kültür, Tanıtım İşleri\n821.01|Fuar\n821.02|Sergi\n821.03|Festivaller\n821.04|Tur Ve Gezi\n821.05|Yarışma\n821.06|Gösteri Ve Konserler\n821.07|Özel Gün Ve Haftalar\n821.99|Diğer\n823|Reklam Ve İlan İşleri\n823.01|Reklam İşleri\n823.02|İlan İşleri\n823.99|Diğer\n824|Yayın İşleri\n824.01|Kitap\n824.01.01|Teklifler\n824.01.02|Değerlendirmeler\n824.01.03|Yayın Hazırlık İşleri\n824.01.04|Telif İşleri\n824.01.05|İntihal\n824.01.99|Diğer\n824.02|Dergi\n824.02.01|Teklifler\n824.02.02|Değerlendirmeler\n824.02.03|Yayın Hazırlık İşleri\n824.02.04|Telif İşleri\n824.02.05|İntihal\n824.02.99|Diğer\n824.03|Broşür\n824.03.01|Teklifler\n824.03.02|Değerlendirmeler\n824.03.03|Yayın Hazırlık İşleri\n824.03.04|Telif İşleri\n824.03.05|İntihal\n824.03.99|Diğer\n824.04|Matbu Evrak\n824.04.01|Teklifler\n824.04.02|Değerlendirmeler\n824.04.03|Yayın Hazırlık İşleri\n824.04.04|Telif İşleri\n824.04.05|İntihal\n824.04.99|Diğer\n824.05|Takvim Ve Ajanda\n824.05.01|Teklifler\n824.05.02|Değerlendirmeler\n824.05.03|Yayın Hazırlık İşleri\n824.05.04|Telif İşleri\n824.05.05|İntihal\n824.05.99|Diğer\n824.06|Bülten\n824.06.01|Teklifler\n824.06.02|Değerlendirmeler\n824.06.03|Yayın Hazırlık İşleri\n824.06.04|Telif İşleri\n824.06.05|İntihal\n824.06.99|Diğer\n824.07|Resmi Doküman\n824.07.01|Teklifler\n824.07.02|Değerlendirmeler\n824.07.03|Yayın Hazırlık İşleri\n824.07.04|Telif İşleri\n824.07.05|İntihal\n824.07.99|Diğer\n824.08|Ses Ve Görüntü Malzemeleri\n824.08.01|Teklifler\n824.08.02|Değerlendirmeler\n824.08.03|Yayın Hazırlık İşleri\n824.08.04|Telif İşleri\n824.08.05|İntihal\n824.08.99|Diğer\n824.99|Diğer\n825|Basım, Depolama Ve Dağıtım İşleri\n825.01|Basım\n825.02|Depolama\n825.03|Dağıtım\n825.03.01|Yayın Talepleri\n825.03.02|Yardım Ve Bağış\n825.03.03|Abonelik Ve Satış\n825.03.99|Diğer\n825.99|Diğer\n828|Tercüme İşleri\n839|Tanıtım Ve Yayınla İlgili Diğer İşler\n840|Mali İşler (Genel)\n841|Bütçe Hazırlama Ve Uygulama\n841.01|Bütçe Hazırlık Çalışmaları\n841.01.01|Bütçe\n841.01.02|Ek Bütçe\n841.01.03|Geçici Bütçe\n841.01.99|Diğer\n841.02|Bütçe Uygulamaları\n841.02.01|Ödenek Talep Ve Göndermeleri\n841.02.02|Serbest Bırakma\n841.02.03|Ahp/Afp Vizeleri\n841.02.04|Ahp/Afp Revizeleri\n841.02.05|Aktarmalar\n841.02.06|Ek Ödenekler\n841.02.07|Ödenek Devri\n841.02.08|Ödenek İptalleri\n841.02.09|İlama Bağlı Borçlar\n841.02.10|Yedek Ödenekler\n841.02.11|Tenkisler\n841.02.12|Revize İşlemleri\n841.02.13|Akreditif Ve Taahhüt Artıkları\n841.02.14|Avanslar, Krediler, Mahsuplar\n841.02.15|Öz Gelirler\n841.02.16|Gelir Red Ve İadeleri\n841.02.17|Tahakkuk Ve Ödeme İşleri\n841.02.99|Diğer\n841.99|Diğer\n843|Mizan, Bilanço Ve Kesin Hesap İşleri\n843.01|Mizan\n843.02|Bilanço\n843.03|Kesin Hesap\n843.04|Bütçe Dönem Gerçekleştirme Raporları\n843.05|Tablolar\n843.05.01|Finansal Tablolar\n843.05.02|Gelir Tabloları\n843.05.03|Vaziyet Tabloları\n843.05.04|Günlük Ödeme Planları\n843.05.05|Nakit Akım Tabloları\n843.05.99|Diğer\n843.99|Diğer\n845|Sayıştay İncelemeleri\n845.01|Sorgu\n845.02|İlam\n845.03|Raporlama\n845.03.01|Uygunluk Bildirimi\n845.03.02|Performans Raporları\n845.03.99|Diğer\n845.99|Diğer\n846|Emanet İşleri\n846.01|Vergi\n846.02|Kefalet\n846.03|İcra\n846.04|Sendika\n846.99|Diğer\n849|Banka İşlemleri\n849.01|Ödeme Talimatları\n849.02|Repo Ve Faiz İşlemleri\n849.03|Kambiyo İşlemleri\n849.04|Tahsilatlar\n849.05|Mutabakatlar\n849.06|Ekstre Ve Dekontlar\n849.99|Diğer\n850|Kıymetli Evrak İşlemleri\n851|Finansman Ve Fon Yönetimi İşleri\n851.01|Finansman Programları\n851.02|Gelir Gider\n851.03|Kar Tevzii\n851.04|Sermaye\n851.99|Diğer\n853|Kredi İşlemleri\n853.01|Yurtdışı Krediler\n853.01.01|Geri Ödemeler\n853.01.02|Kur Farkları\n853.01.03|Gecikme Faizi\n853.01.99|Diğer\n853.02|Yurtiçi Krediler\n853.03|Hazineye Borçlar\n853.99|Diğer\n855|Borç Ve Alacak İşlemleri\n855.01|Kuruluşun Borç Ve Alacakları\n855.02|Gerçek Ve Tüzel Kişilerin Borç Ve Alacakları\n855.99|Diğer\n856|Harcama Yetkilileri Ve Gerçekleştirme Görevlileri\n857|Saymanlık Ve Sayman Bildirimleri\n858|İdari Yaptırım (Para Cezaları)\n869|Mali Konularda Diğer İşler\n870|Özel Kalem Ve Protokol İşleri (Genel)\n871|Makamın Konuşma Ve Açıklamaları\n872|Randevu Talepleri\n873|Temas Ve Ziyaretler\n873.01|Gezi Ve Ziyaret Programları\n873.02|Yabancı Temsilciler\n873.99|Diğer\n874|Günlük Programlar\n876|Davet Ve Tebrikler\n876.01|Özel Mektuplar\n876.02|Davetiyeler\n876.03|Tebrikler\n876.99|Diğer\n877|Protokol İşleri\n878|Resepsiyonlar\n879|Rezervasyonlar\n880|Törenler\n899|Özel Kalem Ve Protokolle İlgili Diğer İşler\n900|Personel İşleri (Genel)\n901|İş İstekleri\n902|Personel Alımı\n902.01|Alım Talepleri\n902.02|Alım İzinleri\n902.03|Sınavlar\n902.99|Diğer\n903|Personel Özlük İşleri\n903.01|İşe Giriş Belgeleri\n903.02|Atama İşleri\n903.02.01|Asaleten\n903.02.02|Vekaleten\n903.02.03|Tedviren\n903.02.99|Diğer\n903.03|Terfi Ve İntibak İşlemleri\n903.03.01|Terfi İşleri\n903.03.02|İntibak İşleri\n903.03.02.01|Hizmet Değerlendirmesi\n903.03.02.02|Öğrenim Değerlendirmesi\n903.03.02.99|Diğer\n903.03.99|Diğer\n903.04|Hizmet Cetveli Ve Hizmet Belgesi\n903.05|İzin İşleri\n903.05.01|Yıllık\n903.05.02|Sıhhi\n903.05.03|Mazeret\n903.05.04|Ücretsiz\n903.05.05|Yurtdışı\n903.05.99|Diğer\n903.06|Görevden Ayrılma\n903.06.01|Emeklilik\n903.06.02|İstifa\n903.06.03|Görevden Çekilmiş Sayılma\n903.06.04|Görevden Çıkarılma\n903.06.05|Vefat\n903.06.99|Diğer\n903.07|Görevlendirmeler\n903.07.01|Kurumiçi\n903.07.02|Kurumdışı\n903.07.03|Yurtdışı\n903.07.04|Ek Görevler\n903.07.05|Rotasyon\n903.07.99|Diğer\n903.08|Mükafat Ve Cezalar\n903.08.01|Ödül İşleri\n903.08.02|Disiplin İşleri\n903.08.99|Diğer\n903.09|Sicil İşleri\n903.09.01|Sicil Raporları\n903.09.02|Mal Beyannamesi\n903.09.99|Diğer\n903.10|Aile Yardımı Bildirimi\n903.11|Askerlik İşlemleri\n903.12|Hizmet Borçlanması\n903.13|Kimlik Ve Giriş Kartı İşlemleri\n903.14|Sağlık Karnesi\n903.99|Diğer\n907|Kadro Pozisyon İşleri\n907.01|Teklif\n907.02|İptal Ve İhdas\n907.03|Tenkis-Tahsis\n907.04|Vize İşlemleri\n907.99|Diğer\n912|Pasaport İşlemleri\n912.01|Diplomatik\n912.02|Hususi\n912.03|Hizmet\n912.04|Emekli\n912.99|Diğer\n914|Yabancı Uyruklu Personel İstihdamı\n915|Sendikalarla İlgili İşler\n915.01|İşveren Sendikaları\n915.02|Memur Sendikaları\n915.02.01|Üyelik Ve Dayanışma Aidatı\n915.02.02|Kurum İdari Kurulu Ve Yüksek İdari Kurul Toplantıları\n915.02.03|Yetkili Sendika Tespiti\n915.02.04|Temsilcilik\n915.02.99|Diğer\n915.03|İşçi Sendikaları\n915.03.01|Üyelik Ve Dayanışma Aidatı\n915.03.02|Temsilcilik\n915.03.03|İzin İşlemleri\n915.03.04|Toplu Sözleşme Ve Uygulama İşleri\n915.03.04.01|Müzakereler\n915.03.04.02|Uyuşmazlık Hali\n915.03.04.03|Grev - Lokavt\n915.03.04.04|Teşmil İşlemleri\n915.03.04.99|Diğer\n915.03.99|Diğer\n915.99|Diğer\n917|Sosyal Güvence Kapsamında Yapılan İşler\n917.01|Sigorta Primleri Bildirgeleri\n917.02|Tescil İşlemleri (İşe Giriş Bildirgeleri)\n917.03|İşçi Bildirim Listeleri\n917.99|Diğer\n918|Çalışan Sağlığı Ve İş Güvenliği\n918.01|İş Güvenliği\n918.02|Çalışan Sağlığı\n918.02.01|Meslek Hastalıkları\n918.02.02|İş Kazaları\n918.02.99|Diğer\n918.99|Diğer\n920|Performans Değerlendirme\n929|Personelle İlgili Diğer İşler\n930|Satınalma Ve Satış İşleri (Genel)\n933|Firma Bilgileri\n933.01|Yurtiçi\n933.02|Yurtdışı\n933.03|Yasaklı Firmalar\n933.99|Diğer\n934|Satınalma İşleri\n934.01|Mal Ve Malzeme Alımı\n934.01.01|Ön İzin Belgesi\n934.01.02|İhale Onay Belgesi\n934.01.03|Yaklaşık Maliyet Hesabı\n934.01.04|Duyurular\n934.01.05|Kik Onayı\n934.01.06|İhale İlan Tutanağı\n934.01.07|İlan Metni\n934.01.08|Şartnameler\n934.01.09|İhale Evrakının Teslim Alındığına Dair Tutanak\n934.01.10|Zarf Açma Ve Belge Kontrol Tutanağı\n934.01.11|İsteklilerce Teklif Edilen Fiyatlar Tutanağı\n934.01.12|İhale Komisyonu Ara Kararı\n934.01.13|İhale Komisyonu Kesin Kararı\n934.01.14|Yasaklı Olup Olmadığına Dair Kik Teyit Belgesi\n934.01.15|Firmalara Gönderilen Sonuç Bildirimleri\n934.01.16|İtirazlar\n934.01.17|Sözleşme\n934.01.18|Kesin Teminat\n934.01.19|Ödeme İşleri\n934.01.99|Diğer\n934.02|Hizmet\n934.02.01|Ön İzin Belgesi\n934.02.02|İhale Onay Belgesi\n934.02.03|Yaklaşık Maliyet Hesabı\n934.02.04|Duyurular\n934.02.05|Kik Onayı\n934.02.06|İhale İlan Tutanağı\n934.02.07|İlan Metni\n934.02.08|Şartnameler\n934.02.09|İhale Evrakının Teslim Alındığına Dair Tutanak\n934.02.10|Zarf Açma Ve Belge Kontrol Tutanağı\n934.02.11|İsteklilerce Teklif Edilen Fiyatlar Tutanağı\n934.02.12|İhale Komisyonu Ara Kararı\n934.02.13|İhale Komisyonu Kesin Kararı\n934.02.14|Yasaklı Olup Olmadığına Dair Kik Teyit Belgesi\n934.02.15|Firmalara Gönderilen Sonuç Bildirimleri\n934.02.16|İtirazlar\n934.02.17|Sözleşme\n934.02.18|Kesin Teminat\n934.02.19|Ödeme İşleri\n934.02.99|Diğer\n934.03|Gayrimenkul\n934.03.01|Ön İzin Belgesi\n934.03.02|İhale Onay Belgesi\n934.03.03|Yaklaşık Maliyet Hesabı\n934.03.04|Duyurular\n934.03.05|Kik Onayı\n934.03.06|İhale İlan Tutanağı\n934.03.07|İlan Metni\n934.03.08|Şartnameler\n934.03.09|İhale Evrakının Teslim Alındığına Dair Tutanak\n934.03.10|Zarf Açma Ve Belge Kontrol Tutanağı\n934.03.11|İsteklilerce Teklif Edilen Fiyatlar Tutanağı\n934.03.12|İhale Komisyonu Ara Kararı\n934.03.13|İhale Komisyonu Kesin Kararı\n934.03.14|Yasaklı Olup Olmadığına Dair Kik Teyit Belgesi\n934.03.15|Firmalara Gönderilen Sonuç Bildirimleri\n934.03.16|İtirazlar\n934.03.17|Sözleşme\n934.03.18|Kesin Teminat\n934.03.19|Ödeme İşleri\n934.03.99|Diğer\n934.99|Diğer\n939|Müşteri İlişkileri\n939.01|Bayiler\n939.02|Acentalar\n939.99|Diğer\n940|Fiyatların Belirlenmesi-Tarifeler\n941|Satış Talepleri Ve Teyitleri\n942|Satış İşlemleri\n942.01|Yurt Dışı Satışlar\n942.01.01|Direkt Satışlar\n942.01.02|İhracat Sevkiyatları\n942.01.03|İhraç Kayıtlı Satışlar\n942.01.04|Diib Kapsamında Satışlar\n942.01.99|Diğer\n942.02|Yurt İçi Satışlar\n942.02.01|Kontratlı Satışlar\n942.02.02|Cari Satışlar\n942.02.03|İhaleli Satışlar\n942.02.04|Elektronik Ticaret Şeklinde Satışlar\n942.02.99|Diğer\n942.03|Hurda Ve İhtiyaç Fazlası Malzeme Satışları\n942.03.01|İhtiyaç Fazlası Malzeme Satışı\n942.03.02|Ekonomik Ömrünü Tamamlamış Malzeme Satışı\n942.03.99|Diğer\n942.99|Diğer\n944|Gümrük İşlemleri\n945|Akreditif İşlemleri\n946|Ticari Belgeler\n946.01|İrsaliyeler\n946.02|Satış Fişleri\n946.03|Faturalar\n946.04|Yükleme Talimatları\n946.99|Diğer\n947|Stok Kontrol İşlemleri\n947.01|Malzeme Giriş İşlemleri\n947.02|Malzeme Çıkış İşlemleri\n947.03|Malzeme Transfer İşlemleri\n947.04|Malzeme İade İşlemleri\n947.05|Malzemelerin Kayıttan Düşülmesi İşlemleri\n947.99|Diğer\n948|Tanıtım Ve Pazarlama\n948.01|Tasarım Ve Markalama\n948.01.01|Tasarım\n948.01.02|Markalama\n948.01.99|Diğer\n948.02|Pazar Araştırması\n948.02.01|Veri Toplama\n948.02.02|Analiz Ve Değerlendirme\n948.02.99|Diğer\n948.03|Kaçak, Taklit, Sahte Ürün\n948.03.01|Kaçak\n948.03.02|Taklit\n948.03.03|Sahte\n948.03.99|Diğer\n948.99|Diğer\n949|Satınalma ve Satışla İlgili Diğer İşler\n950|Topyekün Savunma Sivil Hizmetleri (Genel)\n951|Güvenlik İşleri\n951.01|İç Güvenlik\n951.01.01|İç Güvenlik Strateji Belgesi\n951.01.02|Eylem Planları\n951.01.03|İstihbarat Raporları\n951.01.04|Bilgilendirme Faaliyetleri\n951.01.05|İşbirliği\n951.01.06|İnceleme Ve Araştırma\n951.01.07|Radyo Ve Televizyon Yayınları\n951.01.08|Ekonomi Ve Sosyal Konular\n951.01.09|Siber Güvenlik\n951.01.10|İklim Güvenliği\n951.01.11|Gıda Güvenliği\n951.01.12|Su Ve Doğal Kaynak Güvenliği\n951.01.13|Enerji Güvenliği\n951.01.14|Bilim Ve Teknoloji Güvenliği\n951.01.15|Sıkıyönetim Ve Olağanüstü Hal\n951.01.16|Acil Durum/Kriz Yönetimi\n951.01.16.01|Dış Tehdit Kaynaklı\n951.01.16.02|Yaygın Şiddet Kaynaklı\n951.01.16.03|Doğal Afet Kaynaklı\n951.01.16.04|Sağlık Kaynaklı\n951.01.16.05|Ekonomik Kaynaklı\n951.01.16.99|Diğer\n951.01.99|Diğer\n951.02|Dış Güvenlik\n951.02.01|Dış Güvenlik Strateji Belgesi\n951.02.02|Eylem Planları\n951.02.03|İstihbarat Raporları\n951.02.04|Bilgilendirme Faaliyetleri\n951.02.05|İşbirliği\n951.02.06|İnceleme Ve Araştırma\n951.02.07|Silahların Kontrolü Ve Yayılmanın Önlenmesi\n951.02.08|Nükleer Enerjinin Barışçıl Kullanımı\n951.02.09|Barışı Destekleme Ve Koruma Harekâtları\n951.02.10|Dış Türkler\n951.02.99|Diğer\n951.03|Terörle Mücadele\n951.03.01|Terörle Mücadele Strateji Belgesi\n951.03.02|Eylem Planları\n951.03.03|İstihbarat Raporları\n951.03.04|İşbirliği Ve Koordinasyon\n951.03.05|Stratejik Bilgi Desteği\n951.03.06|Kamuoyu Bilgilendirme Ve Halkla İletişim\n951.03.07|Sosyal, Ekonomi, Eğitim Ve Kültür Çalışmaları\n951.03.08|Terör Örgütleri\n951.03.08.01|Bölücü Örgütler\n951.03.08.02|Yıkıcı Örgütler\n951.03.08.03|Dini İstismar Eden Örgütler\n951.03.08.04|Uluslararası Örgütler\n951.03.08.99|Diğer\n951.03.09|İnceleme Ve Araştırma\n951.03.10|İzleme Ve Değerlendirme\n951.03.11|Terörle Mücadele Raporu\n951.03.12|İnceleme/Denetleme\n951.03.99|Diğer\n951.04|Koruyucu Güvenlik\n951.04.01|Sabotaja Karşı Koruma Planları\n951.04.02|Nöbetçi Memurluğu İşleri\n951.04.03|Koruyucu Güvenlik Denetleme Sonuç Raporları\n951.04.04|Yabancı Uyruklu Personel İle İlgili İşler\n951.04.05|Mülteciler Ve Sığınmacılar\n951.04.06|Özel Güvenlik Teşkilatı İle İlgili İşler\n951.04.07|Özel Güvenlik Bölgeleri İle İlgili İşler\n951.04.08|İstihbarat Ve Kaçakçılık İle İlgili İşler\n951.04.09|Patlayıcı Maddeler Ve Ateşli Silahlar İle İlgili İşler\n951.04.10|Güvenlik Soruşturmaları Ve Arşiv Araştırması\n951.04.11|Fiziki Emniyet Tedbirleri\n951.04.12|Evrak Güvenliği\n951.04.13|Haberleşme Güvenliği\n951.04.14|Yangın Önleme Ve Korunma\n951.04.15|Önemli Tesis Kriterleri\n951.04.99|Diğer\n951.99|Diğer\n952|Afet Ve Acil Durum Yönetimi\n952.01|Planlama Ve Risk/Zarar Azaltma İle İlgili İşler\n952.01.01|Ulusal Afet Yönetimi Strateji Belgesi\n952.01.02|Ulusal Deprem Strateji Ve Eylem Planı(Udsep-2023)\n952.01.03|Afet Ve Acil Durum Planları\n952.01.04|Risk Ve Zarar Azaltma İşleri\n952.01.04.01|Risk Belirleme\n952.01.04.02|Afet Etüdleri\n952.01.04.03|Genel Hayata Etkililik/Etkisizlik\n952.01.04.04|Afete Maruz Bölge\n952.01.04.05|Jeolojik Ve Jeoteknik Etüdler\n952.01.04.06|Mikrobölgeleme Etüdleri\n952.01.04.07|Meteorolojik Etüdler\n952.01.04.08|İklim Değişikliği\n952.01.04.09|İnsan Kaynaklı Afetler\n952.01.04.10|Tehlike/Risk Haritaları\n952.01.04.11|Yapı Analizleri\n952.01.04.12|Afet Önlemleri\n952.01.04.13|Kentsel Dönüşüm\n952.01.04.14|Afet Tahmini Ve Değerlendirme Çalışmaları\n952.01.04.15|Afet Kültürü Ve Bilinci\n952.01.04.99|Diğer\n952.01.05|Erken Uyarı, Gözlem Ve Tahmin Sistemleri\n952.01.05.01|Erken Uyarı Sistemleri\n952.01.05.02|Gözlem Sistemleri\n952.01.05.03|Tahmin Sistemleri\n952.01.05.99|Diğer\n952.01.99|Diğer\n952.02|Afet Ve Acil Durum Haberleşmesi\n952.02.01|Haberleşme Tesisleri/Merkezleri\n952.02.01.01|Afad Merkezleri\n952.02.01.02|Mobil Haberleşme Merkezleri\n952.02.01.99|Diğer\n952.02.02|Telsiz Sistemleri\n952.02.02.01|Vhf\n952.02.02.02|Uhf\n952.02.02.03|Hf\n952.02.02.99|Diğer\n952.02.03|Uydu Haberleşme Sistemleri\n952.02.03.01|Uydu Telefonları\n952.02.03.02|Upling Sistemleri\n952.02.03.99|Diğer\n952.02.04|Kablolu Ve Gsm Haberleşme Sistemleri\n952.02.04.01|Kablo Altyapılı Sistemler\n952.02.04.02|Gsm Altyapılı Sistemler\n952.02.04.03|Özel Santraller\n952.02.04.99|Diğer\n952.02.05|Kesintisiz Ve Güvenli İletişim\n952.02.06|İletişim Altyapıları\n952.02.06.01|Bilgi Sistemleri İletişim Altyapıları\n952.02.06.02|İkaz Ve Alarm Sistemleri İletişim Altyapıları\n952.02.06.03|Erken Uyarı Sistemleri İletişim Altyapıları\n952.02.06.99|Diğer\n952.02.07|Sistem İnceleme Ve Denetleme\n952.02.07.01|Sistem Test Raporları\n952.02.07.02|Çevrim Sonuçları\n952.02.07.03|Denetleme Raporu\n952.02.07.99|Diğer\n952.02.08|Bilgi Sistemleri\n952.02.09|Afet Ve Acil Durum Sigorta İşleri\n952.02.99|Diğer\n952.03|Afet Ve Acil Durum Müdahale Ve Yardım İşleri\n952.03.01|Başbakanlık Afet Ve Acil Durum Yönetimi Merkezi\n952.03.02|Afet Ve Acil Durum Yönetimi Merkezleri\n952.03.03|Afet Ve Acil Durum İlanı\n952.03.03.01|Deprem, Sel, Fırtına, Heyelan, Çığ\n952.03.03.02|İltica Ve Nüfus Hareketleri\n952.03.03.03|Yangınlar Ve Kazalar\n952.03.03.04|Kbrn Kazaları Ve Olayları\n952.03.03.05|Tehlikeli Ve Salgın Hastalıklar\n952.03.03.99|Diğer\n952.03.04|Duyuru\n952.03.05|Tahliye/Transfer\n952.03.06|Acil Müdahale\n952.03.06.01|İhtiyaç Belirleme Ve Talep/Tahsis\n952.03.06.02|Tahliye/Transfer\n952.03.06.03|Görevlendirme\n952.03.06.99|Diğer\n952.03.07|Haberleşme\n952.03.08|Güvenlik\n952.03.09|İlk Yardım\n952.03.10|Arama-Kurtarma\n952.03.11|Beslenme(İaşe)\n952.03.12|Barınma(İbate)\n952.03.13|Acil Yardım\n952.03.13.01|Ödenek Tahsisi\n952.03.13.02|Ödenek Tahsisi Süre Uzatımı\n952.03.13.03|Yurtiçi Ayni Yardım\n952.03.13.04|Yurtdışı Ayni Yardım\n952.03.13.05|Yurtdışı Nakdi Yardım\n952.03.13.99|Diğer\n952.03.14|Yardım Kampanyası\n952.03.14.01|Yurtiçi\n952.03.14.02|Yurtdışı\n952.03.14.99|Diğer\n952.03.15|Afet Ve Acil Durum Ekip Ve Ekipmanları\n952.03.15.01|Acil Kurtarma Ve Yardım\n952.03.15.02|İlk Yardım\n952.03.15.03|İtfaiye\n952.03.15.04|Sivil Savunma\n952.03.15.99|Diğer\n952.03.16|Gönüllüler Ve Stk'Lar\n952.03.16.01|Gönüllü Teşviki\n952.03.16.02|Akreditasyon (İlkyardım, Arama-Kurtarma Vs.)\n952.03.16.99|Diğer\n952.03.99|Diğer\n952.04|İyileştirme Çalışmaları\n952.04.01|Geçici İskan\n952.04.01.01|Yer Belirleme\n952.04.01.02|Geçici İskan Yapıları\n952.04.01.03|Kira Yardımı\n952.04.01.04|Sosyal, Sağlık Ve Eğitim Hizmetleri\n952.04.01.99|Diğer\n952.04.02|Afetten Zarar Görenlere Karşılıksız Yardım\n952.04.02.01|Sakatlık Ve Ölüm\n952.04.02.02|Konut/İşyeri Yardımı\n952.04.02.99|Diğer\n952.04.03|Kredi Yardımı\n952.04.04|Yerel Yönetimlere Ödenek Aktarımı\n952.04.04.01|Belediyeler\n952.04.04.02|İl Özel İdareleri\n952.04.04.99|Diğer\n952.04.99|Diğer\n952.05|Hasar Tespiti\n952.05.01|Hasar Tespit Raporu\n952.05.01.01|Ön Hasar Tespiti Raporu\n952.05.01.02|Kesin Hasar Tespiti\n952.05.01.03|İtirazlar Hasar Tespiti\n952.05.01.04|Yargı Kararıyla Düzenlenen Hasar Tespit Raporu\n952.05.01.99|Diğer\n952.05.02|Boşaltma, Yıkım\n952.05.99|Diğer\n952.06|Hak Sahipliği\n952.06.01|Talep Ve Taahhütname\n952.06.02|Hak Sahipliği İnceleme Komisyonu\n952.06.03|Hak Sahipliği Tespiti\n952.06.04|Borçlandırma\n952.06.05|Hak Sahipliğinin Sona Ermesi Ve Borcun Muacceliyeti\n952.06.06|Hak Sahipliğine Engel Durumlar\n952.06.07|Artan Konutlar\n952.06.99|Diğer\n952.07|Yerleşim Yeri Tespiti Ve Artan Arsalar\n952.07.01|Yer Seçimi\n952.07.02|Artan Arsalar\n952.07.99|Diğer\n952.99|Diğer\n953|Topyekün Savunma Sivil Hizmetleri\n953.01|Sivil Savunma Hizmetleri\n953.01.01|Sivil Savunma Planlama\n953.01.01.01|İl Ve İlçe Sivil Savunma Planları\n953.01.01.02|Daire Ve Müessese Sivil Savunma Planları\n953.01.01.03|Tahliye Planları\n953.01.01.04|Kabul Planları\n953.01.01.05|Sivil Savunma Arama Kurtarma Birlikleri Harekat ve İntikal Planları\n953.01.01.99|Diğer\n953.01.02|Sivil Savunma Servis Ve Yükümlüleri İşleri\n953.01.03|Sivil Savunma Gönüllüleri İşleri\n953.01.04|Sivil Toplum Kuruluşları (Stk) İle İlgili İşler\n953.01.05|Sivil Savunma Sevk Ve Harekatı İşleri\n953.01.06|Kamu Kurum Ve Kuruluşları İle Sivil Toplum Kuruluşlarının (Stk) Sivil Savunma Harekatı İle İlgili Ko\n953.01.07|Haber Alma Ve Yayma, İkaz Ve Alarm İşleri\n953.01.07.01|Haber Alma Ve Yayma İşleri\n953.01.07.02|İkaz Ve Alarm Merkezleri İle İlgili İşler\n953.01.07.03|Siren Sistemi İle İlgili İşler\n953.01.07.99|Diğer\n953.01.08|Kimyasal, Biyolojik, Radyolojik Ve Nükleer Savunma İşl.\n953.01.08.01|Kimyasal Savunma\n953.01.08.02|Biyolojik Savunma\n953.01.08.03|Radyolojik Ve Nükleer Savunma\n953.01.08.04|Dekontaminasyon (Arındırma) İşleri\n953.01.08.99|Diğer\n953.01.09|Sivil Savunma Araç, Gereç Ve Malzemelere Ait İşler\n953.01.99|Diğer\n953.02|Seferberlik Ve Savaş Hali Hazırlıkları\n953.02.01|Milli Alarm\n953.02.01.01|Alarm Tedbirleri İlanında Yapılacak Faaliyetler\n953.02.01.02|Nato Alarm Sistemi\n953.02.01.03|Alarm Kod Kelimeleri Ve Anlamları\n953.02.01.04|Alarm Kod İşlem Ve Görevlileri\n953.02.01.05|Milli Alarm Sistemi Eğitimleri\n953.02.01.06|Seferberlik İlanı Ve Duyuru İşlemleri\n953.02.01.07|24 Saat Süreli Çalışma Planları\n953.02.01.99|Diğer\n953.02.02|Lojistik\n953.02.02.01|Savaş Görev Planları\n953.02.02.02|Savaş Hasarı Onarım Planları\n953.02.02.03|Araç Seferberliği Ve Erteleme İşleri\n953.02.02.04|Trafikte Kaydı Olmayan Özel Sektör İş Makinelerinin Tespiti\n953.02.02.05|Mal Ve Hizmet Seferberliği İşleri\n953.02.02.06|Kaynak Planlama Faaliyetleri\n953.02.02.07|İl Ve İlçe Kaynak Sayım İşleri\n953.02.02.08|Milli Müdafaa Mükellefiyeti\n953.02.02.09|Ekonomik/Stratejik Tahrip Hedefleri Planlama İşleri\n953.02.02.10|Kriz/Harekat Merkezi İle İlgili İşler\n953.02.02.11|Haritalar\n953.02.02.12|Denetlemeler\n953.02.02.13|Tsk Harekat Kontrolüne Girecek Kamu Kurum Ve Kuruluşları\n953.02.02.14|Tsk Lojistik Seferberlik Dosyası\n953.02.02.99|Diğer\n953.02.03|Personel Seferberlik\n953.02.03.01|Sevk Tehir İşleri\n953.02.03.02|Personel Ve Kadro Erteleme İşleri\n953.02.03.03|Yasal Yaş Sınırları\n953.02.03.04|Sefer Görev Emirleri\n953.02.03.05|İnsan Gücü Planlaması\n953.02.03.06|Bedelli Askerlik\n953.02.03.07|Erteleme Sonuç Raporları\n953.02.03.99|Diğer\n953.02.04|Seferberlik Savaş Hali Planları\n953.02.04.01|Genel Planlar\n953.02.04.02|Özel Planlar\n953.02.04.03|Detay Planlar\n953.02.04.04|Planlama Ve Koordinasyon Kurulu İşleri\n953.02.04.05|Seferberlik Ve Savaş Hali Hazırlıkları Yıllık Faaliyet Raporu\n953.02.04.99|Diğer\n953.02.05|Milli Güvenlik Kurulu Genel Sekreterliği Tetkik Gezileri\n953.02.05.01|Tetkik Gezisi Planlaması\n953.02.05.02|Tetkik Gezisi Sonuç Raporu\n953.02.05.99|Diğer\n953.02.06|Seferberlik Ve Savaş Hali Hazırlıkları Oryantasyon Eğitimi\n953.02.07|Nato Sivil Olağanüstü Hal Planlaması\n953.02.07.01|Planlama Faaliyetleri\n953.02.07.02|Genel Kurul Toplantıları\n953.02.07.03|Sonuç Raporu\n953.02.07.99|Diğer\n953.02.99|Diğer\n953.03|Sığınaklar\n953.03.01|Genel Sığınaklar\n953.03.02|Özel Sığınaklar\n953.03.03|Tespit Ve Denetim İşleri\n953.03.04|Kayıt Ve İstatistik İşleri\n953.03.99|Diğer\n953.99|Diğer\n954|Tatbikatlar\n954.01|Uluslararası Ve Nato Tatbikatları\n954.02|Milli Tatbikatlar\n954.02.01|Güven Serisi Tatbikatları\n954.02.02|Milli Kriz/Harekat Yönetimi Tatbikatları\n954.02.02.01|Güven Serisi Tatbikatlar\n954.02.02.02|Afet/Acil Durum Tatbikatları\n954.02.02.99|Diğer\n954.02.03|Milli Alarm Sistemi Tatbikatı\n954.02.04|Sivil-Asker İşbirliği İle Yapılan Tatbikatlar\n954.02.05|Mal Ve Hizmet Seferberliği Tatbikatları\n954.02.06|Sivil Savunma Tatbikatları\n954.02.06.01|Sivil Savunma Plan Tatbikatı\n954.02.06.02|Sivil Savunma Servis Tatbikatı\n954.02.06.03|Örnek Sivil Savunma Tatbikatı\n954.02.06.04|Arama Ve Kurtarma İntikal Tatbikatı\n954.02.06.99|Diğer\n954.02.99|Diğer\n954.03|Milli Alarm Sistemi Tatbikatı\n954.04|Sivil Asker İşbirliği ile Yapılan Tatbikatlar\n954.05|Mal ve Hizmet Seferberliği Tatbikatları\n954.06|Sivil Savunma Tatbikatları\n954.06.01|Sivil Savunma Plan Tatbikatı\n954.06.02|Sivil Savunma Servis Tatbikatı\n954.06.03|Örnek Sivil Savunma Tatbikatı\n954.06.04|Arama ve Kurtarma İntikal Tatbikatı\n954.99|Diğer\n969|Güvenlik İşleri, Afet Ve Acil Durum Yönetimi Ve Topyekün Savunma Sivil Hizmetleri İle İlgili Diğer İşler", _0x2483c0 = _0x32f781, _0x6381d4 = { 'gonderen': '', 'okul': '', 'kisiKurum': "Kullanıcı", 'gelisTipi': 'Elden', 'rules': "nakil=Nakiller", 'yardimcilar': '', 'havaleRules': '', 'gorevler': '', 'katalog': '', 'learned': {}, 'pace': 1.5, 'listeBekle': 2.5, 'havaleAra': '', 'ozetTel': '', 'ozetSaat': 16, 'dakikaKazanc': 4, 'font': 0xf, 'open': false }, _0x392b5c = () => {
                let _unused_xbe0;
                try {
                    return JSON.parse(_0x2f2f4f.getItem(_0x2483c0)) || {};
                }
                catch (_0x2d1ce8) {
                    return {};
                }
            }, _0x599e9b = Object.assign({}, _0x6381d4, _0x392b5c().settings || {});
            if (!Array.isArray(_0x599e9b.kisiler)) {
                _0x599e9b.kisiler = [];
            }
            // v3.6.71: bozuk kayıtlı veriler paneli kaybettirmesin
            _0x599e9b.kisiler = _0x599e9b.kisiler.filter(k => k && typeof k === 'object' && typeof k.ad === 'string' && k.ad.trim());
            ['rules', 'havaleRules', 'gorevler', 'katalog', 'okul', 'gonderen', 'kisiKurum', 'gelisTipi', 'havaleAra', 'ozetTel'].forEach(a => { if (_0x599e9b[a] != null && typeof _0x599e9b[a] !== 'string') _0x599e9b[a] = Array.isArray(_0x599e9b[a]) ? _0x599e9b[a].join('\n') : String(_0x599e9b[a]); if (_0x599e9b[a] == null) _0x599e9b[a] = _0x6381d4[a] != null ? _0x6381d4[a] : ''; });
            if (typeof _0x599e9b.adresler !== 'string') _0x599e9b.adresler = Array.isArray(_0x599e9b.adresler) ? _0x599e9b.adresler.join('\n') : '';
            if (!_0x599e9b.learned || typeof _0x599e9b.learned !== 'object' || Array.isArray(_0x599e9b.learned)) _0x599e9b.learned = {};
            Object.keys(_0x599e9b.learned).forEach(k => { if (typeof _0x599e9b.learned[k] !== 'string') delete _0x599e9b.learned[k]; });
            if (!_0x599e9b.kisiler.length && _0x599e9b.yardimcilar) {
                _0x599e9b.kisiler = _0x599e9b.yardimcilar.split('\x0a').map(_0x48a27f => _0x48a27f.trim()).filter(Boolean).map(_0x272b1c => ({ 'ad': _0x272b1c, 'on': !false }));
            }
            if (!_0x599e9b.kisiler.length && !_0x599e9b.kisiSeeded) {
                _0x599e9b.kisiler = [];
            }
            _0x599e9b.kisiSeeded = !false;
            _0x599e9b.kisiler.forEach(_0x265e45 => {
                if (_0x265e45.tc == null) {
                    _0x265e45.tc = '';
                }
            });
            const _0x36ce29 = _0x2cd782 => {
                const _0x5b53a0 = (_0x599e9b.kisiler || []).find(_0xbf8eaa => _0x3c029d(_0xbf8eaa.ad) === _0x3c029d(_0x2cd782));
                return _0x5b53a0 && /^\d{11}$/.test(_0x5b53a0.tc || '') ? _0x5b53a0.tc : '';
            }, _0x7c92c3 = _0x195087 => !_0x195087 || /^\d{11}$/.test(_0x195087);
            if (!_0x599e9b.okul) {
                try {
                    const _0xa663d6 = typeof chrome !== "undefined" && chrome.storage ? null : null;
                }
                catch (_0x4570fa) {
                }
                _0x599e9b.okul = '';
            }
            if (!_0x599e9b.adresler) {
                _0x599e9b.adresler = "https://mebbis.meb.gov.tr/Default.aspx";
            }
            const _0x38ecd1 = () => _0x599e9b.adresler.split('\x0a').map(_0x5e9b8c => _0x5e9b8c.trim()).filter(Boolean), _0x4b8741 = _0x9b3fa4 => {
                let _unused_wts2;
                try {
                    return JSON.parse(_0x2f2f4f.getItem(_0x9b3fa4) || "null");
                }
                catch (_0x5a77e2) {
                    return null;
                }
            }, _0x4f8e86 = () => _0x38ecd1().some(_0xeee3e8 => location.href.toLowerCase().startsWith(_0xeee3e8.toLowerCase())), _0x423c3a = () => _0x38ecd1().some(_0x1bba94 => {
                let _unused_jpk2;
                try {
                    return new URL(_0x1bba94).origin === location.origin;
                }
                catch (_0x117b90) {
                    return false;
                }
            }), _0x4ea448 = () => (_0x599e9b.kisiler || []).filter(_0x3925a2 => _0x3925a2.on !== false && _0x3925a2.ad).map(_0x5b1db8 => _0x5b1db8.ad);
            let _0x2a3361 = _0x392b5c().records;
            _0x2a3361 = (Array.isArray(_0x2a3361) ? _0x2a3361 : []).filter(r => r && typeof r === 'object');
            const _0x381096 = () => _0x2f2f4f.setItem(_0x2483c0, JSON.stringify({ 'settings': _0x599e9b, 'records': _0x2a3361 })), _0x3c029d = _0x448e3c => (_0x448e3c || '').replace(/İ/g, 'i').replace(/I/g, 'i').toLowerCase().replace(/ı/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c').replace(/̇/g, '').replace(/\s+/g, ' ').trim(), _0x4e51ef = _0x1ce684 => new Promise(_0x5bc2fe => setTimeout(_0x5bc2fe, _0x1ce684 * (+_0x599e9b.pace > 0x0 ? +_0x599e9b.pace : 0x1)));
            async function _0x5c5b76(_0x273450, _0x5b2bd9 = 0x2710, _0x58f823 = 0xfa) {
                const _0x174cf9 = Date.now();
                while (Date.now() - _0x174cf9 < _0x5b2bd9) {
                    if (_0x228a28) {
                        throw 'stop';
                    }
                    let _0x572c02;
                    try {
                        _0x572c02 = _0x273450();
                    }
                    catch (_0x171447) {
                        _0x572c02 = null;
                    }
                    if (_0x572c02) {
                        return _0x572c02;
                    }
                    await _0x4e51ef(_0x58f823);
                }
                throw new Error("Zaman aşımı");
            }
            function _0x52dd5d(_0x5c0355 = document, _0x3e3c6b = []) {
                let _unused_9d17;
                _0x3e3c6b.push(_0x5c0355);
                _0x5c0355.querySelectorAll("iframe,frame").forEach(_0x1a6b3e => {
                    let _unused_524o;
                    try {
                        const _0x59f710 = _0x1a6b3e.contentDocument;
                        if (_0x59f710 && _0x59f710.documentElement) {
                            _0x52dd5d(_0x59f710, _0x3e3c6b);
                        }
                    }
                    catch (_0x50665d) {
                    }
                });
                return _0x3e3c6b;
            }
            const _0x30d46f = _0x5d833f => {
                let _unused_4b6t;
                if (!_0x5d833f || !_0x5d833f.ownerDocument) {
                    return false;
                }
                if (!(_0x5d833f.offsetWidth || _0x5d833f.offsetHeight || _0x5d833f.getClientRects().length)) {
                    return false;
                }
                const _0x122f21 = _0x5d833f.ownerDocument.defaultView.getComputedStyle(_0x5d833f);
                return _0x122f21.visibility !== 'hidden' && _0x122f21.display !== 'none';
            }, _0x4d6fb0 = () => _0x52dd5d().map(_0x181a42 => _0x181a42.body ? _0x181a42.body.innerText : '').join('\x0a'), _0x40cd39 = _0x4295a8 => _0x3c029d(_0x4d6fb0()).includes(_0x3c029d(_0x4295a8));
            let _0x59122a = '';
            const _0x37c789 = _0x3029ee => {
                let _unused_x5re;
                try {
                    return _0x3029ee.tagName.toLowerCase() + (_0x3029ee.id ? '#' + _0x3029ee.id : '') + (typeof _0x3029ee.className === 'string' && _0x3029ee.className.trim() ? '.' + _0x3029ee.className.trim().split(/\s+/).slice(0x0, 0x2).join('.') : '') + ' \x22' + (_0x3029ee.textContent || _0x3029ee.value || '').trim().replace(/\s+/g, ' ').slice(0x0, 0x28) + '\x22';
                }
                catch (_0x30424b) {
                    return '?';
                }
            };
            function _0x2c5bca(_0x32de4f) {
                let _unused_p5k1;
                if (typeof EA_OTOMATIK_KAYDET !== "undefined" && !EA_OTOMATIK_KAYDET) {
                    const _eaYasak = EA_yasakDugmeMi(_0x32de4f);
                    if (_eaYasak) {
                        if (window.__EA_CLICK_STATS__) window.__EA_CLICK_STATS__.engellenen = (window.__EA_CLICK_STATS__.engellenen || 0) + 1;
                        throw new Error("Güvenlik: mağaza kopyasında eklenti " + _eaYasak + " düğmesine basmaz — " + _eaYasak + "’e siz basın");
                    }
                }

                if (window.__EA_CLICK_STATS__) {
                    const _0x347fdc = _0x3c029d(_0x32de4f && (_0x32de4f.value || _0x32de4f.textContent) || ''), _0x3b1554 = _0x3c029d(_0x32de4f && _0x32de4f.id || ''), _0x3b55a0 = window.__EA_CLICK_STATS__;
                    _0x3b55a0.total = (_0x3b55a0.total || 0x0) + 0x1;
                    (_0x3b55a0.recent = _0x3b55a0.recent || []).push((_0x347fdc || _0x3b1554).slice(0x0, 0x30));
                    if (_0x3b55a0.recent.length > 0x28) {
                        _0x3b55a0.recent.splice(0x0, _0x3b55a0.recent.length - 0x28);
                    }
                    if (_0x347fdc === "kaydet" || _0x3b1554.includes("kaydet")) {
                        _0x3b55a0.kaydet = (_0x3b55a0.kaydet || 0x0) + 0x1;
                    }
                    if (/^gonder|gonder$/.test(_0x347fdc) || _0x3b1554.includes("gonder")) {
                        _0x3b55a0.gonder = (_0x3b55a0.gonder || 0x0) + 0x1;
                    }
                    if (_0x347fdc.includes('imza') || _0x3b1554.includes("imza")) {
                        _0x3b55a0.imza = (_0x3b55a0.imza || 0x0) + 0x1;
                    }
                    if (_0x347fdc.includes("paraf") || _0x3b1554.includes('paraf')) {
                        _0x3b55a0.paraf = (_0x3b55a0.paraf || 0x0) + 0x1;
                    }
                    if (_0x32de4f && (_0x32de4f.type === "submit" || _0x32de4f.getAttribute && _0x32de4f.getAttribute("type") === "submit")) {
                        _0x3b55a0.submit = (_0x3b55a0.submit || 0x0) + 0x1;
                    }
                }
                _0x59122a = _0x37c789(_0x32de4f);
                try {
                    _0x32de4f.scrollIntoView({ 'block': "center" });
                }
                catch (_0x3bfdf4) {
                }
                const _0x3e4608 = _0x32de4f.ownerDocument.defaultView;
                ["pointerover", 'mouseover', "mouseenter", "pointerdown", "mousedown", "pointerup", 'mouseup', "click"].forEach(_0x4adaba => _0x32de4f.dispatchEvent(new MouseEvent(_0x4adaba, { 'bubbles': !false, 'cancelable': !false, 'view': _0x3e4608 })));
            }
            function _0x89cc36(_0x16dd4c) {
                const _0x120eca = _0x16dd4c.ownerDocument.defaultView;
                ["pointerover", "mouseover", "mouseenter", "mousemove"].forEach(_0x3fbc92 => _0x16dd4c.dispatchEvent(new MouseEvent(_0x3fbc92, { 'bubbles': !false, 'view': _0x120eca })));
            }
            function _0x497585(_0x11a49b, _0x152f57) {
                const _0xcc8aa4 = _0x11a49b.tagName === "TEXTAREA" ? _0x11a49b.ownerDocument.defaultView.HTMLTextAreaElement.prototype : _0x11a49b.ownerDocument.defaultView.HTMLInputElement.prototype;
                Object.getOwnPropertyDescriptor(_0xcc8aa4, "value").set.call(_0x11a49b, _0x152f57);
            }
            const _0x2de811 = (_0x45f929, _0x555bd5, _0x4ffd6f = {}) => _0x45f929.dispatchEvent(new Event(_0x555bd5, Object.assign({ 'bubbles': !false }, _0x4ffd6f))), _0x3a4ac8 = (_0x3d588a, _0x1eb7ba, _0x545e70) => _0x3d588a.dispatchEvent(new KeyboardEvent(_0x1eb7ba, { 'bubbles': !false, 'key': _0x545e70 })), _0x7d422f = "label,span,td,th,div,a,button,li,legend,p,b,strong,h1,h2,h3,h4,h5";
            function _0x1129fb(_0x2b0a96, { exact: exact = false } = {}) {
                const _0x216d13 = _0x3c029d(_0x2b0a96), _0x53aeee = [];
                for (const _0x1ae2de of _0x52dd5d()) {
                    const _0x3d1bf8 = [..._0x1ae2de.querySelectorAll(_0x7d422f)].filter(_0x398354 => {
                        let _unused_ad07;
                        if (!_0x30d46f(_0x398354)) {
                            return false;
                        }
                        const _0x23d44f = _0x3c029d(_0x398354.textContent);
                        if (!_0x23d44f || _0x23d44f.length > _0x216d13.length + 0x3c) {
                            return false;
                        }
                        return exact ? _0x23d44f.replace(/[:*\s]+$/, '') === _0x216d13 : _0x23d44f.includes(_0x216d13);
                    });
                    _0x53aeee.push(..._0x3d1bf8.filter(_0x3eb62d => !_0x3d1bf8.some(_0x58dcfa => _0x58dcfa !== _0x3eb62d && _0x3eb62d.contains(_0x58dcfa))));
                }
                return _0x53aeee;
            }
            const _0xd17bf4 = _0x45fe57 => _0x1129fb(_0x45fe57, { 'exact': !false })[0x0] || _0x1129fb(_0x45fe57)[0x0] || null, _0x2d4f67 = "input:not([type=hidden]):not([type=file]):not([type=radio]):not([type=checkbox]):not([type=button]):not([type=submit]),select,textarea,.ui-selectonemenu,.ui-autocomplete,.ui-calendar";
            function _0xde4365(_0x3dbd80) {
                let _unused_aji9;
                return [..._0x3dbd80.querySelectorAll(_0x2d4f67)].filter(_0x2f7f90 => {
                    let _unused_daq5;
                    if (_0x2f7f90.matches("input,select,textarea") && _0x2f7f90.closest(".ui-selectonemenu,.ui-autocomplete,.ui-calendar")) {
                        return false;
                    }
                    return _0x30d46f(_0x2f7f90);
                });
            }
            function _0x27a01e(_0x1d0b50) {
                let _unused_lrl8;
                return _0x1d0b50.closest(".ui-selectonemenu,.ui-autocomplete,.ui-calendar") || _0x1d0b50;
            }
            function _0x520f6b(_0x1514ca) {
                const _0x4d91b1 = _0x1514ca.ownerDocument;
                if (_0x1514ca.htmlFor) {
                    const _0x459fde = _0x4d91b1.getElementById(_0x1514ca.htmlFor);
                    if (_0x459fde && _0x30d46f(_0x27a01e(_0x459fde))) {
                        return _0x27a01e(_0x459fde);
                    }
                }
                const _0x1fae2b = _0x1514ca.getBoundingClientRect(), _0x3ca051 = _0xde4365(_0x4d91b1).filter(_0x5b1966 => _0x1514ca.compareDocumentPosition(_0x5b1966) & Node.DOCUMENT_POSITION_FOLLOWING && !_0x1514ca.contains(_0x5b1966)), _0x5baa5f = _0x274526 => {
                    const _0xb13246 = _0x274526.getBoundingClientRect(), _0x1fb6a8 = Math.abs(_0xb13246.top - _0x1fae2b.top), _0x51eaca = _0xb13246.left - _0x1fae2b.right;
                    return (_0x1fb6a8 < 0x28 ? 0x0 : _0x1fb6a8) * 0x14 + Math.abs(_0x51eaca) + (_0x51eaca < -0x14 ? 0x1f4 : 0x0);
                };
                return _0x3ca051.slice().sort((_0xba263, _0x21cd9b) => _0x5baa5f(_0xba263) - _0x5baa5f(_0x21cd9b))[0x0] || null;
            }
            function _0x195509(_0x150f64, _0x48f770) {
                let _unused_8i0i;
                return _0x1129fb(_0x48f770, { 'exact': !false }).find(_0x5444e8 => _0x5444e8.ownerDocument === _0x150f64.ownerDocument && _0x150f64.compareDocumentPosition(_0x5444e8) & Node.DOCUMENT_POSITION_FOLLOWING && !_0x150f64.contains(_0x5444e8)) || null;
            }
            function _0x400c16(_0x55ecc0, _0x2f8ca3, kodExact) {
                const _0x5d6c70 = _0x3c029d(_0x2f8ca3), _0x86c70b = [..._0x55ecc0.options], _0x40a387 = kodExact ? _0x86c70b.find(o => { const k = EA_KONU_KODU.metindekiKodlar(o.text); const kn = EA_KONU_KODU.kodNorm(kodExact); return k.has(kn) && ![...k].some(x => x !== kn && x.startsWith(kn + '.')); }) : _0x86c70b.find(_0xbb402f => _0x3c029d(_0xbb402f.text) === _0x5d6c70) || _0x86c70b.find(_0x325a61 => _0x3c029d(_0x325a61.text).includes(_0x5d6c70));
                if (!_0x40a387) {
                    throw new Error("Seçenek yok: " + _0x2f8ca3);
                }
                _0x55ecc0.value = _0x40a387.value;
                _0x2de811(_0x55ecc0, "input");
                _0x2de811(_0x55ecc0, 'change');
            }
            async function _0x465985(_0x536f65, _0x22eaf9, kodExact) {
                const _0x1bc7f8 = _0x3c029d(_0x22eaf9);
                _0x2c5bca(_0x536f65.querySelector(".ui-selectonemenu-trigger") || _0x536f65.querySelector(".ui-selectonemenu-label") || _0x536f65);
                const _0x4cda56 = await _0x5c5b76(() => {
                    let _unused_tdwa;
                    for (const _0x2eac76 of _0x52dd5d()) {
                        const _0xb5a775 = _0x536f65.id && _0x2eac76.getElementById(_0x536f65.id + "_panel") || [..._0x2eac76.querySelectorAll(".ui-selectonemenu-panel")].find(_0x30d46f);
                        if (_0xb5a775 && _0x30d46f(_0xb5a775)) {
                            return _0xb5a775;
                        }
                    }
                }, 0x1388), _0x33ed6b = _0x4cda56.querySelector(".ui-selectonemenu-filter");
                _0x33ed6b && (_0x497585(_0x33ed6b, _0x22eaf9), _0x2de811(_0x33ed6b, "input"), _0x3a4ac8(_0x33ed6b, 'keyup', 'a'), await _0x4e51ef(0x1f4));
                const _0x16b482 = [..._0x4cda56.querySelectorAll("li.ui-selectonemenu-item")].filter(_0x30d46f), _0x1a885c = kodExact ? _0x16b482.find(li => EA_satirKoduUyar(li, kodExact)) : _0x16b482.find(_0x5db6d4 => _0x3c029d(_0x5db6d4.getAttribute("data-label") || _0x5db6d4.textContent) === _0x1bc7f8) || _0x16b482.find(_0x3ad172 => _0x3c029d(_0x3ad172.getAttribute("data-label") || _0x3ad172.textContent).includes(_0x1bc7f8));
                if (!_0x1a885c) {
                    _0x2c5bca(_0x536f65);
                    throw new Error("Menüde yok: " + _0x22eaf9);
                }
                _0x2c5bca(_0x1a885c);
                await _0x4e51ef(0x1f4);
            }
            const _0x2b0f50 = '.lovItemTitle,.ui-autocomplete-panel li,.ui-autocomplete-panel tr,.ui-autocomplete-item,.ui-autocomplete-items li,ul[role=listbox] li,[role=option],.ui-menu-item,.tt-suggestion,.autocomplete-suggestion,.dropdown-menu li,.ui-autocomplete li', _0x13a51b = _0x3d3d55 => /^sonuc bulunamam/.test(_0x3c029d(_0x3d3d55)), _0x103b31 = _0x35b08d => new Set([..._0x35b08d.querySelectorAll('li,tr,td,a,span,div')].filter(_0x30d46f)), _0x65fb28 = _0x2955f1 => _0x3c029d((_0x2955f1.closest("li,tr,.ui-autocomplete-item") || _0x2955f1.parentElement || _0x2955f1).textContent), _0x538e5e = _0x197c79 => {
                const _0x6772a4 = (_0x197c79.id || '').split(':');
                return _0x6772a4.length > 0x2 ? _0x6772a4.slice(0x0, -0x1).join(':') : '';
            };
            function _0x14e366(_0x559efd, _0x22745e, _0xe3c1f3) {
                const _0x2f3862 = _0x559efd.ownerDocument, _0x559d12 = _0x559efd.getBoundingClientRect(), _0x4c1ec2 = [..._0x2f3862.querySelectorAll(_0x2b0f50)].filter(_0x30d46f);
                let _0x3b0382 = _0x4c1ec2, _0x5c76ac = "sınıf";
                !_0x3b0382.length && (_0x3b0382 = [..._0x2f3862.querySelectorAll('li,tr,td,a,span,div')].filter(_0xaed513 => _0x30d46f(_0xaed513) && !_0xe3c1f3.has(_0xaed513) && !_0xaed513.closest('label,.ui-tooltip,[role=tooltip]') && _0xaed513.getBoundingClientRect().top >= _0x559d12.top - 0x5), _0x5c76ac = "yeni");
                const _0x56e3b8 = _0x4c1ec2.some(_0x7eb045 => _0x13a51b(_0x7eb045.textContent));
                _0x3b0382 = _0x3b0382.filter(_0x1c5410 => {
                    const _0x3c6961 = (_0x1c5410.textContent || '').trim(), _0xac669d = _0x3c029d(_0x3c6961);
                    if (!_0xac669d || _0x3c6961.length >= 0x104) {
                        return false;
                    }
                    if (_0x13a51b(_0xac669d) || _0x3e6c44(_0x3c6961)) {
                        return false;
                    }
                    if (/autocomplete\s*=|primefaces|function\s*\(/i.test(_0x3c6961)) {
                        return false;
                    }
                    return !false;
                });
                const _0x45666e = _0x538e5e(_0x559efd);
                if (_0x45666e) {
                    const _0x44b877 = _0x3b0382.filter(_0x7d9de7 => (_0x7d9de7.id || '').startsWith(_0x45666e) || _0x7d9de7.closest('[id^=\x22' + _0x45666e + '\x22]'));
                    if (_0x44b877.length) {
                        _0x3b0382 = _0x44b877;
                    }
                }
                const _0x3eea59 = _0x3b0382.filter(_0x341012 => !_0x3b0382.some(_0x683616 => _0x683616 !== _0x341012 && _0x341012.contains(_0x683616)));
                let _0x2701be;
                if (_0x22745e.fuzzy) {
                    _0x2701be = _0x3eea59.map(_0x1401f1 => ({ 'e': _0x1401f1, 's': _0x22745e.fuzzy.filter(_0x2e1146 => _0x65fb28(_0x1401f1).includes(_0x2e1146)).length })).filter(_0x5a5432 => _0x5a5432.s > 0x0).sort((_0x318a88, _0x4ff895) => _0x4ff895.s - _0x318a88.s || _0x3c029d(_0x318a88.e.textContent).length - _0x3c029d(_0x4ff895.e.textContent).length).map(_0x211ae2 => _0x211ae2.e);
                }
                else {
                    if (_0x22745e.any) {
                        const _0x39dc8c = _0x3eea59.filter(_0x568159 => _0x568159.closest('.ui-autocomplete-panel,.ui-overlaypanel,[role=listbox],.ui-dialog .ui-datatable,.lovPanel')), _0x48e486 = _0x39dc8c.length ? _0x39dc8c : _0x3eea59;
                        _0x2701be = _0x48e486.filter(_0x45b81d => {
                            const _0x1a9b1b = _0x45b81d.getBoundingClientRect();
                            return _0x1a9b1b.top >= _0x559d12.top - 0x8 && _0x1a9b1b.top - _0x559d12.bottom < 0x1c2 && _0x1a9b1b.left < _0x559d12.right + 0x78;
                        }).sort((_0x3a181d, _0x21a71f) => _0x3a181d.getBoundingClientRect().top - _0x21a71f.getBoundingClientRect().top);
                    }
                    else {
                        const _0x37691f = _0x3c029d(_0x22745e.value), _0x13415f = _0x22745e.must || [], _0x4fea84 = _0x3b6700 => {
                            const _0x273fc2 = _0x3c029d(_0x3b6700.textContent), _0xa8e748 = _0x65fb28(_0x3b6700);
                            let _0x1c296a = (_0x273fc2 === _0x37691f ? 0x0 : _0x273fc2.startsWith(_0x37691f) ? 0x1 : 0x2) * 0x3e8 + _0x273fc2.length;
                            for (const _0x3a283a of _0x22745e.prefer || []) {
                                if (_0x3a283a && _0xa8e748.includes(_0x3a283a)) {
                                    _0x1c296a -= 0x12c;
                                }
                            }
                            return _0x1c296a;
                        };
                        _0x2701be = _0x3eea59.filter(_0x93f43a => {
                            const _0x45c010 = _0x3c029d(_0x93f43a.textContent);
                            return _0x13415f.every(_0x5059b1 => _0x45c010.includes(_0x5059b1));
                        }).sort((_0x168458, _0x1bfcbd) => _0x4fea84(_0x168458) - _0x4fea84(_0x1bfcbd));
                        if (_0x22745e.exact) {
                            const _0x50e111 = _0x3eea59.filter(_0x182965 => _0x3c029d(_0x182965.textContent.split('[')[0x0]) === _0x3c029d(_0x22745e.exact));
                            _0x2701be = _0x50e111.length || !(_0x22745e.prefer || []).some(_0x3a0f1b => _0x3a0f1b && _0x3c029d(_0x22745e.value || '') === _0x3c029d(_0x3a0f1b)) ? _0x50e111 : _0x2701be;
                        }
                    }
                }
                if (_0x22745e.kodExact) {
                    // v3.6.60: yalnızca kodu birebir aynı olan satır (yanlış desimal kodu seçilmesin)
                    _0x2701be = _0x3eea59.filter(el => EA_satirKoduUyar(el, _0x22745e.kodExact) && (!_0x22745e.baslik || EA_KONU_KODU.baslikTutar(EA_satirMetni(el), _0x22745e.baslik))).sort((a, b) => EA_satirMetni(a).length - EA_satirMetni(b).length);
                }
                return { 'pool': _0x2701be, 'src': _0x5c76ac, 'noRes': _0x56e3b8, 'ham': _0x3eea59.length };
            }
            function _0x17bcf9(_0x19e5a0) {
                const _0x490dce = _0x19e5a0.closest("li,tr") || _0x19e5a0;
                _0x2c5bca(_0x490dce);
                if (_0x490dce !== _0x19e5a0) {
                    _0x2c5bca(_0x19e5a0);
                }
                const _0x40c7c7 = _0x490dce.querySelector("td,span,a");
                if (_0x40c7c7 && _0x40c7c7 !== _0x19e5a0) {
                    _0x2c5bca(_0x40c7c7);
                }
            }
            async function _0x21c241(_0x44692a, _0x4b2a68, _0x310b40, _0x3301fc) {
                const _0x4eddfe = Date.now();
                let _0x4e5962 = null, _0x3f6e06 = 0x0;
                while (Date.now() - _0x4eddfe < _0x3301fc) {
                    if (_0x228a28) {
                        throw "stop";
                    }
                    if (_0x4b2a68.done && _0x4b2a68.done()) {
                        return { 'done': !false };
                    }
                    const _0x23f2be = _0x14e366(_0x44692a, _0x4b2a68, _0x310b40);
                    if (_0x23f2be.pool.length) {
                        const _0x47a8e8 = _0x23f2be.pool.map(_0x5c5068 => _0x3c029d(_0x5c5068.textContent)).join('|');
                        if (_0x47a8e8 === _0x4e5962) {
                            return _0x23f2be;
                        }
                        _0x4e5962 = _0x47a8e8;
                        await _0x4e51ef(0x28a);
                        continue;
                    }
                    _0x4e5962 = null;
                    if (_0x4b2a68.kodExact && _0x23f2be.ham > 0 && ++_0x3f6e06 >= 0x6) {
                        throw new Error("Listede bu kod yok: " + _0x4b2a68.kodExact + " (aranan “" + _0x4b2a68.value + "”)");
                    }
                    if (_0x23f2be.noRes && !_0x4b2a68.any && ++_0x3f6e06 >= 0x7) {
                        throw new Error("Sonuç bulunamadı: " + _0x4b2a68.value);
                    }
                    await _0x4e51ef(0x190);
                }
                return null;
            }
            async function _0x2ebc9c(_0xf1e5fa, _0xfc42b9) {
                const _0x24538c = (_0x175ba6, _0x459ba5, _0x1b26df) => _0xf1e5fa.dispatchEvent(new KeyboardEvent(_0x175ba6, { 'bubbles': !false, 'key': _0x459ba5, 'keyCode': _0x1b26df, 'which': _0x1b26df }));
                if (_0x5f03d4.tcHint) {
                    const _0x497578 = _0x3e4cca => {
                        const _0x12c63e = _0x3e4cca.closest('li,tr,.ui-autocomplete-item') || _0x3e4cca;
                        return ((_0x12c63e.textContent || '') + ' ' + (_0x12c63e.getAttribute('title') || '') + ' ' + (_0x12c63e.getAttribute("data-item-label") || '') + ' ' + (_0x3e4cca.getAttribute('title') || '')).includes(_0x5f03d4.tcHint);
                    }, _0x1151c5 = _0xfc42b9.pool.filter(_0x497578);
                    _0x1151c5.length && (_0xfc42b9.pool = [..._0x1151c5, ..._0xfc42b9.pool.filter(_0x426f86 => !_0x1151c5.includes(_0x426f86))], _0x5b5599('TC eşleşen seçenek öne alındı.'));
                }
                const _0x31a23f = _0xfc42b9.pool.filter(_0x20f065 => _0x3c029d(_0x20f065.textContent) === _0x3c029d(_0xfc42b9.pool[0x0].textContent)).length;
                if (_0x31a23f > 0x1) {
                    _0x5b5599('Uyarı: aynı adlı ' + _0x31a23f + ' seçenek var, ' + (_0x5f03d4.tcHint ? 'TC eşleşmedi; ' : 'TC girilmemiş; ') + 'ilki seçiliyor.', "err");
                }
                for (const _0x2ed1e4 of _0xfc42b9.pool.slice(0x0, 0x3)) {
                    _0x5b5599("Liste öğesi (" + _0xfc42b9.src + "): " + _0x2ed1e4.textContent.trim().slice(0x0, 0x46));
                    const _0x4a68e8 = () => !_0x2ed1e4.isConnected || !_0x30d46f(_0x2ed1e4);
                    _0x17bcf9(_0x2ed1e4);
                    await _0x4e51ef(0x320);
                    if (_0x4a68e8()) {
                        _0x5f03d4.picked = _0x2ed1e4.textContent.trim();
                        _0x5f03d4.pickedEl = _0x2ed1e4;
                        return _0x2ed1e4;
                    }
                    _0x5b5599("Bu öğe seçilemedi (üst grup olabilir), sıradaki deneniyor…");
                }
                const _0x764b4e = _0xfc42b9.pool[0x0], _0x4dd9af = () => !_0x764b4e.isConnected || !_0x30d46f(_0x764b4e);
                _0x17bcf9(_0x764b4e);
                await _0x4e51ef(0x384);
                if (_0x4dd9af()) {
                    _0x5f03d4.picked = _0x764b4e.textContent.trim();
                    return _0x764b4e;
                }
                _0xf1e5fa.focus();
                const _0x5c98eb = [...(_0x764b4e.closest("ul,tbody,div") || _0x764b4e.parentElement || document).querySelectorAll(_0x2b0f50)].filter(_0x30d46f), _0x3e1b80 = Math.max(0x0, _0x5c98eb.indexOf(_0x764b4e));
                for (let _0x3f13e2 = 0x0; _0x3f13e2 <= _0x3e1b80; _0x3f13e2++) {
                    _0x24538c('keydown', "ArrowDown", 0x28);
                    _0x24538c("keyup", "ArrowDown", 0x28);
                    await _0x4e51ef(0x78);
                }
                _0x17bcf9(_0x764b4e);
                await _0x4e51ef(0x384);
                if (_0x4dd9af()) {
                    _0x5f03d4.picked = _0x764b4e.textContent.trim();
                    return _0x764b4e;
                }
                _0x3a4ac8(_0xf1e5fa, "keydown", "Escape");
                _0x3a4ac8(_0xf1e5fa, "keyup", "Escape");
                throw new Error("Listeden seçilemedi (Enter kullanılmadı). Öğe: " + (_0x764b4e.outerHTML || '').slice(0x0, 0xa0));
            }
            async function _0x5a1f35(_0x5b9229, _0x1851a7, _0x11d52b, _0x5c7c99 = {}) {
                const _0x465616 = _0x5b9229.ownerDocument;
                _0x5b9229.focus();
                _0x497585(_0x5b9229, '');
                _0x2de811(_0x5b9229, 'input');
                if (!_0x11d52b) {
                    _0x497585(_0x5b9229, _0x1851a7);
                    _0x2de811(_0x5b9229, 'input');
                    _0x3a4ac8(_0x5b9229, "keyup", '0');
                    _0x2de811(_0x5b9229, "change");
                    _0x3a4ac8(_0x5b9229, "keydown", "Escape");
                    _0x5b9229.blur();
                    await _0x4e51ef(0x12c);
                    return;
                }
                const _0x1fb9d7 = _0x103b31(_0x465616), _0x5b4878 = _0x3c029d(_0x5c7c99.must || _0x1851a7).split(' ').filter(Boolean);
                let _0x2343b8 = '';
                for (const _0x5d2507 of _0x1851a7) {
                    _0x2343b8 += _0x5d2507;
                    _0x497585(_0x5b9229, _0x2343b8);
                    _0x5b9229.dispatchEvent(new InputEvent("input", { 'bubbles': !false, 'data': _0x5d2507 }));
                    _0x3a4ac8(_0x5b9229, 'keydown', _0x5d2507);
                    _0x3a4ac8(_0x5b9229, "keyup", _0x5d2507);
                    await _0x4e51ef(0x5a);
                }
                await _0x4e51ef(0x2bc);
                await EA_listeBekle();
                const _0x332474 = await _0x21c241(_0x5b9229, { 'value': _0x1851a7, 'must': _0x5b4878, 'prefer': _0x5c7c99.prefer, 'fuzzy': _0x5c7c99.fuzzy, 'done': _0x5c7c99.done, 'exact': _0x5c7c99.exact, 'kodExact': _0x5c7c99.kodExact, 'baslik': _0x5c7c99.baslik }, _0x1fb9d7, 0x36b0);
                if (!_0x332474) {
                    throw new Error(_0x5c7c99.kodExact ? 'Listede bu kod yok: ' + _0x5c7c99.kodExact + ' (aranan “' + _0x1851a7 + '”)' : _0x5c7c99.exact ? 'Listede tam ad bulunamadı: ' + _0x5c7c99.exact : "Öneri listesi gelmedi: " + _0x1851a7);
                }
                if (_0x332474.done) {
                    _0x5b5599("Alan siz müdahale edince seçilmiş görünüyor, devam ediliyor.", 'ok');
                    return;
                }
                if (_0x5c7c99.kodExact) {
                    _0x5f03d4.pickedRow = EA_satirMetni(_0x332474.pool[0x0]).trim();
                }
                const _0x5b8027 = await _0x2ebc9c(_0x5b9229, _0x332474);
                if (_0x5c7c99.exact && _0x3c029d((_0x5f03d4.picked || '').split('[')[0x0]) !== _0x3c029d(_0x5c7c99.exact)) {
                    throw new Error("Yanlış kişi seçildi: " + _0x5f03d4.picked);
                }
                return _0x5b8027;
            }
            async function _0x5e08c1(_0x5d1099, _0x3e0671) {
                const _0x5b2e79 = _0x5d1099.ownerDocument, _0x45f3ad = _0x103b31(_0x5b2e79);
                _0x2c5bca(_0x5d1099);
                _0x5d1099.focus();
                _0x5d1099.dispatchEvent(new FocusEvent("focusin", { 'bubbles': !false }));
                _0x5d1099.dispatchEvent(new KeyboardEvent("keydown", { 'bubbles': !false, 'key': "ArrowDown", 'keyCode': 0x28, 'which': 0x28 }));
                const _0x4151c7 = await _0x21c241(_0x5d1099, { 'any': !false, 'value': '' }, _0x45f3ad, 0x2328);
                if (!_0x4151c7) {
                    throw new Error('Alan açılınca liste gelmedi');
                }
                const _0x21303e = _0x3c029d(_0x3e0671 || '').split(' ').filter(_0x1538f5 => _0x1538f5.length > 0x2);
                if (_0x21303e.length) {
                    const _0x5cc18b = _0x4151c7.pool.filter(_0x9da4da => {
                        const _0x10d7ea = _0x65fb28(_0x9da4da);
                        return _0x21303e.every(_0x1af7be => _0x10d7ea.includes(_0x1af7be));
                    });
                    if (_0x5cc18b.length) {
                        _0x4151c7.pool = _0x5cc18b;
                    }
                    else {
                        const puan = el => { const t = _0x65fb28(el); return _0x21303e.filter(w => t.includes(w)).length / _0x21303e.length; };
                        const sirali = _0x4151c7.pool.map(el => ({ el, p: puan(el) })).filter(x => x.p >= 0.6).sort((x, y) => y.p - x.p);
                        if (!sirali.length) {
                            _0x3a4ac8(_0x5d1099, "keydown", "Escape");
                            throw new Error('Açılan listede okul adı yok (“' + _0x3e0671 + '”) — ağaçtan seçilecek');
                        }
                        _0x4151c7.pool = sirali.map(x => x.el);
                    }
                }
                const _0x3aed28 = await _0x2ebc9c(_0x5d1099, _0x4151c7), _0x101aea = (_0x5f03d4.picked || '').split('\x0a')[0x0].trim().slice(0x0, 0x16), _0x29af54 = ((() => {
                    let _unused_gx3h;
                    let _0x5671ea = _0x5d1099, _0x3471df = '';
                    for (let _0x4a8c95 = 0x0; _0x4a8c95 < 0x4 && _0x5671ea; _0x4a8c95++) {
                        _0x5671ea = _0x5671ea.parentElement;
                    }
                    _0x5671ea && (_0x3471df = _0x5671ea.textContent + ' ' + [..._0x5671ea.querySelectorAll('input')].map(_0x457586 => _0x457586.value).join(' '));
                    return _0x3c029d(_0x3471df);
                })());
                if (_0x101aea && !_0x29af54.includes(_0x3c029d(_0x101aea))) {
                    _0x5b5599("Uyarı: Birime Havale seçimi ekranda doğrulanamadı, kontrol edin.", "err");
                }
                return _0x3aed28;
            }
            async function _0x1966bd(_0x352148, _0x10f65f, _0x3754cd, _0x1ccb87) {
                let _unused_vubn;
                if (_0x352148.tagName === "SELECT") {
                    return _0x400c16(_0x352148, _0x10f65f, _0x1ccb87 && _0x1ccb87.kodExact);
                }
                if (_0x352148.classList.contains('ui-selectonemenu')) {
                    return _0x465985(_0x352148, _0x10f65f, _0x1ccb87 && _0x1ccb87.kodExact);
                }
                const _0x12356e = _0x352148.matches("input,textarea") ? _0x352148 : _0x352148.querySelector("input:not([type=hidden])");
                if (!_0x12356e) {
                    throw new Error("Girdi yok");
                }
                return _0x5a1f35(_0x12356e, _0x10f65f, _0x3754cd, _0x1ccb87);
            }
            async function _0x4010a5(_0x58bdad, _0x566f30, { radio: radio = false, list: list = false, must: _0x1d7d73, prefer: _0x502c40, exact: _0x18e90a, kodExact: kodExact } = {}) {
                let _unused_qysp;
                if (!_0x566f30) {
                    throw new Error("Boş değer: " + _0x58bdad + " (ayarlardan doldurun)");
                }
                const _0x5430fc = await _0x5c5b76(() => _0xd17bf4(_0x58bdad), 0x1f40).catch(() => null);
                if (!_0x5430fc) {
                    throw new Error("Etiket bulunamadı: " + _0x58bdad);
                }
                const _0x35a9cd = _0x520f6b(_0x5430fc);
                if (radio) {
                    const _0x24fc8e = _0x195509(_0x5430fc, _0x566f30);
                    if (_0x24fc8e && (!_0x35a9cd || _0x35a9cd.compareDocumentPosition(_0x24fc8e) & Node.DOCUMENT_POSITION_PRECEDING)) {
                        _0x2c5bca(_0x24fc8e);
                        const _0x5609f7 = _0x24fc8e.ownerDocument.getElementById(_0x24fc8e.htmlFor || '');
                        if (_0x5609f7 && _0x5609f7.type === 'radio' && !_0x5609f7.checked) {
                            _0x2c5bca(_0x5609f7);
                        }
                        await _0x4e51ef(0x708);
                        return;
                    }
                }
                if (!_0x35a9cd) {
                    throw new Error("Alan bulunamadı: " + _0x58bdad);
                }
                await _0x1966bd(_0x35a9cd, _0x566f30, list, { 'must': _0x1d7d73, 'prefer': _0x502c40, 'exact': _0x18e90a, 'kodExact': kodExact });
            }
            async function _0x423533(_0x12e87f, _0xad47ac, _0x14325a) {
                let _unused_m6hf;
                let _0x115a76;
                for (const _0x233c54 of [...new Set(_0xad47ac.filter(Boolean))]) {
                    try {
                        await _0x4010a5(_0x12e87f, _0x233c54, _0x14325a);
                        return _0x233c54;
                    }
                    catch (_0x58edb1) {
                        if (_0x58edb1 === "stop") {
                            throw _0x58edb1;
                        }
                        _0x115a76 = _0x58edb1;
                        _0x5b5599('“' + _0x233c54 + "” denemesi olmadı: " + (_0x58edb1.message || _0x58edb1), "err");
                    }
                }
                throw _0x115a76 || new Error("Değer yok: " + _0x12e87f);
            }
            function _0x4ef577(_0x24d007) {
                const _0x5dcf39 = _0x3c029d(_0x24d007);
                for (const _0x4a600c of _0x52dd5d()) {
                    const _0x5535fb = [..._0x4a600c.querySelectorAll('button,a,input[type=button],input[type=submit],.ui-button')].filter(_0x30d46f).find(_0x13c893 => _0x3c029d(_0x13c893.value || _0x13c893.textContent) === _0x5dcf39);
                    if (_0x5535fb) {
                        return _0x5535fb;
                    }
                }
                return null;
            }
            let _0x5f03d4 = {}, _0xef2233 = {};
            const _0xb7ab79 = () => {
                const _0x135a0b = _0x1129fb('Geliş Tipi')[0x0], _0x23995d = _0x1129fb("Konu Kodu")[0x0];
                return _0x135a0b && _0x23995d;
            };
            async function _0x57549f() {
                const _0xcc9a0c = _0x40cd39('Eklenen üst yazı');
                if (_0xb7ab79() && !_0xcc9a0c) {
                    return;
                }
                const _0x15310a = await _0x5c5b76(() => _0xd17bf4('Evrak İşlemleri'), 0x61a8);
                _0x89cc36(_0x15310a);
                _0x2c5bca(_0x15310a);
                await _0x4e51ef(0xa8c);
                const _0x236bc0 = await _0x5c5b76(() => _0x1129fb("Gelen Evrak Kayıt", { 'exact': !false })[0x0] || _0x1129fb('Gelen Evrak Kayıt')[0x0], 0x2710);
                _0x89cc36(_0x236bc0);
                _0x2c5bca(_0x236bc0);
                await _0x5c5b76(_0xb7ab79, 0x61a8);
                await _0x4e51ef(0x7d0);
                if (_0xcc9a0c && _0x40cd39("Eklenen üst yazı")) {
                    const _0x23ac7c = _0x4ef577('Temizle') || _0x4ef577('Yeni');
                    _0x23ac7c && (_0x2c5bca(_0x23ac7c), await _0x4e51ef(0x898));
                    try {
                        await _0x5c5b76(() => !_0x40cd39("Eklenen üst yazı"), 0x1f40);
                    }
                    catch (_0xd2fd3e) {
                        if (_0xd2fd3e === "stop") {
                            throw _0xd2fd3e;
                        }
                        throw new Error("Yeni evrak formu temizlenmedi (önceki üst yazı görünüyor). “Gelen Evrak Kayıt”a elle tıklayıp Tekrar dene’ye basın");
                    }
                }
            }
            const _0x524908 = () => _0x52dd5d().flatMap(_0x4ff98a => [..._0x4ff98a.querySelectorAll('input[type=file]')]);
            async function _0x4c6de9() {
                let _unused_7u2g;
                let _0x1f01d0 = _0x524908()[0x0];
                if (!_0x1f01d0) {
                    const _0x22468a = _0xd17bf4('Üst Yazı Ekle');
                    if (!_0x22468a) {
                        throw new Error("\"Üst Yazı Ekle\" bulunamadı");
                    }
                    _0x2c5bca(_0x22468a);
                    _0x1f01d0 = await _0x5c5b76(() => _0x524908()[0x0], 0x1770);
                }
                const _0x4d2c35 = _0xce9cc1.test(_0x5f03d4.item.file.name) ? await _0x2eb851(_0x5f03d4.item.file) : _0x5f03d4.item.file;
                if (_0x4d2c35 !== _0x5f03d4.item.file) {
                    _0x5b5599(_0x5f03d4.item.file.name + ' resim dosyası; PDF\x27e çevrilip yüklendi: ' + _0x4d2c35.name, 'ok');
                }
                const _0x466fe0 = new DataTransfer();
                _0x466fe0.items.add(_0x4d2c35);
                _0x1f01d0.files = _0x466fe0.files;
                _0x2de811(_0x1f01d0, "input");
                _0x2de811(_0x1f01d0, "change");
                const _0x89945d = () => _0x40cd39("Eklenen üst yazı");
                try {
                    await _0x5c5b76(_0x89945d, 0x2ee0);
                }
                catch (_0x2d2a4c) {
                    if (_0x2d2a4c === "stop") {
                        throw _0x2d2a4c;
                    }
                    const _0x16b9f5 = _0x4ef577("Yükle") || _0x4ef577("Upload") || _0x4ef577('Ekle');
                    if (!_0x16b9f5) {
                        throw new Error("\"Eklenen üst yazı\" görünmedi");
                    }
                    _0x2c5bca(_0x16b9f5);
                    await _0x5c5b76(_0x89945d, 0x4e20);
                }
                await _0x4e51ef(0x1f4);
            }
            function _0x53762f(_0x25bd8e) {
                const _0x50f1aa = _0x3c029d(_0x25bd8e);
                for (const _0x2fe59a of _0x599e9b.rules.split('\x0a')) {
                    const _0x2549a9 = _0x2fe59a.indexOf('=');
                    if (_0x2549a9 < 0x1) {
                        continue;
                    }
                    if (_0x50f1aa.includes(_0x3c029d(_0x2fe59a.slice(0x0, _0x2549a9)))) {
                        return _0x2fe59a.slice(_0x2549a9 + 0x1).trim();
                    }
                }
                return null;
            }
            const _0x41007e = _0x5451d0 => _0x3c029d(_0x5451d0).replace(/[^a-z0-9]/g, '').slice(0x0, 0x5), _0x2f4ffb = new Set(["isler", "islem", 'diger', "genel", "ilgil", "icin", 'olan', 'ile', "veya"]), _0x5f206b = _0x35f532 => [...new Set(_0x3c029d(_0x35f532).split(/[^a-z0-9]+/).filter(_0x52a2a4 => _0x52a2a4.length >= 0x3).map(_0x41007e))], _0x5bc337 = _0x5741b0 => _0x5f206b(_0x5741b0).filter(_0x472b67 => !_0x2f4ffb.has(_0x472b67)), _0x46c02f = _0x365bfd => (_0x365bfd || '').replace(/^[\d.\-\s()\/]+/, '').replace(/\s+\d[\d.]*$/, '').replace(/\s+/g, ' ').trim(), _0x2462a5 = _0x37e839 => {
                const _0x45b54c = _0x37e839.split('.');
                _0x45b54c[0x0] = String(parseInt(_0x45b54c[0x0], 0xa));
                return _0x45b54c.join('.');
            };
            /* ===== EA_KONU_KODU v3.6.60 — desimal dosya kodu eşleştirici (hiyerarşik, .99 = Diğer kuralı) ===== */
            const EA_KONU_KODU = (() => {
              const ARALIKLAR = [[0,99,'Genel Konular'],[100,199,'Eğitim ve Öğretim İşleri'],[200,299,'Öğrenci İşleri'],[300,349,'Sosyal, Sportif ve Kültürel İşler'],[350,399,'Öğretmen Yetiştirme ve Eğitimi'],[400,449,'Özel Öğretim Kurumları İşleri'],[450,499,'Eğitim Teknolojileri İşleri'],[600,619,'Araştırma ve Planlama İşleri'],[620,639,'Basın ve Halkla İlişkiler'],[640,659,'Hukuk İşleri'],[660,679,'Teftiş/Denetim İşleri'],[700,719,'Bilgi Sistemleri'],[720,749,'Dış İlişkiler ve Avrupa Birliği'],[750,769,'Emlak ve Yapım İşleri'],[770,799,'Eğitim İşleri'],[800,819,'İdari ve Sosyal İşler'],[820,839,'Tanıtım ve Yayın İşleri'],[840,869,'Mali İşler'],[870,899,'Özel Kalem ve Protokol İşleri'],[900,929,'Personel İşleri'],[930,949,'Satın Alma ve Satış İşleri'],[950,969,'Güvenlik İşleri, Afet ve Acil Durum']];
              // Konu içinde geçen anahtar kelime → öncelikli ana kod (kullanıcı isteği: staj → 773)
              const IPUCLARI = [[/\bstaj/, '773'], [/\b(cimer|bimer|bilgi edinme)\b/, '622'], [/\bhizmet ?ici\b/, '774'], [/\b(is kaza|is sagligi|is guvenligi|isg\b|meslek hastal)/, '918'], [/^(?!.*tefbis).*\bokul aile birli/, '165']];   // v3.6.73: CİMER/BİMER → 622 Talep, Şikayet, Görüşler
              const ESANLAM = [['etkinl', 'faaliyet'], ['faaliy', 'etkinlik'], ['sporti', 'spor'], ['kutla', 'tören'], ['yarism', 'yarışma'],
                // v3.6.73 — okulda sık gelen konular: CİMER/BİMER şikâyet-başvuru, nakil, izin, devamsızlık
                ['cimer', 'Şikayet Talep'], ['bimer', 'Şikayet Talep'], ['sikay', 'Talep'], ['edinm', 'Bilgi Belge Talep'], ['nakl', 'Nakil'], ['izn', 'İzin'], ['devams', 'Devam'], ['kulub', 'Kulüp'], ['kitab', 'Kitap'], ['birlig', 'Birlik'], ['hastalig', 'Hastalık']];
              const STOP = new Set(['okul','okulu','okulun','okull','okulum','temel','temelli','isler','islem','islemi','alim','alimi','yapil','calis','diger','genel','ilgil','icin','olan','ile','veya','hakki','hakkin','konus','konu','sayi','tarih','ilgi','yazi','yazis','talep','talebi','iliskin','dair','ait','olar','yapil','edilm','olma','olmas','uzere','gore','kapsa','karar']);
              const GENERIC = new Set(['diger','genel','teklifler','program','duyuru','yillik','donemsel','aylik']);
              const tr = s => String(s || '').replace(/İ/g,'i').replace(/I/g,'ı').toLowerCase().replace(/ı/g,'i').replace(/ş/g,'s').replace(/ğ/g,'g').replace(/ü/g,'u').replace(/ö/g,'o').replace(/ç/g,'c').replace(/[âà]/g,'a').replace(/[îì]/g,'i').replace(/[ûù]/g,'u').replace(/̇/g,'');
              const norm = s => tr(s).replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();
              const stopMu = w => STOP.has(w.slice(0,5)) || STOP.has(w);
              const toks = s => [...new Set(norm(s).split(' ').filter(w => w.length >= 3 && !/^\d+$/.test(w) && !stopMu(w)))];
              // Türkçe çekim ekleri (ascii): kurs~kursu~kurslar, nakil~nakiller; ucret≠ucretsiz, temin≠temizlik, diploma≠diplomatik
              const EK = /^(?:l[ae]r|l[ae]ri|s?[iu]|n?[iu]n|n[iu]n|d[ae]n?|t[ae]n?|y?[ae]|y[iu]|n[iu]|n[ae]|nd[ae]n?|m[ae]s?[iu]?|l[iu])*$/;
              const benzer = (a, b) => { if (a === b) return true; const n = Math.min(a.length, b.length); if (n < 4) return false;
                let i = 0; while (i < n && a[i] === b[i]) i++; if (i < 4) return false;
                return EK.test(a.slice(i)) && EK.test(b.slice(i)); };
              const icerir = (Q, t) => { if (Q.has(t)) return true; for (const q of Q) if (benzer(q, t)) return true; return false; };
              const kodNorm = k => { const p = String(k || '').trim().split('.'); if (!/^\d+$/.test(p[0] || '')) return ''; p[0] = String(parseInt(p[0],10)); return p.map((x,i) => i ? x.padStart(2,'0') : x).join('.'); };
              let cache = { raw: null };
              function kur(raw) {
                if (cache.raw === raw) return cache;
                const map = new Map();
                for (const line of String(raw).split('\n')) {
                  const m = /^\s*(\d[\d.]*)\s*[|\t ]\s*(.+?)\s*$/.exec(line); if (!m) continue;
                  const kn = kodNorm(m[1].replace(/\.$/,'')); if (!kn) continue;
                  map.set(kn, { kod: m[1].replace(/\.$/,''), kn, ad: m[2], toks: toks(m[2]), cocuk: [] });   // sonra gelen (Ayarlar/Excel) kazanır
                }
                const list = [...map.values()];
                for (const n of list) {
                  const p = n.kn.split('.'); n.derinlik = p.length; n.ana = parseInt(p[0],10);
                  n.ust = null; for (let i = p.length - 1; i >= 1 && !n.ust; i--) n.ust = map.get(p.slice(0,i).join('.')) || null;
                  if (n.ust) n.ust.cocuk.push(n);
                  n.aralik = ARALIKLAR.find(a => n.ana >= a[0] && n.ana <= a[1]) || null;
                  n.genel = !n.toks.length || norm(n.ad).split(' ').every(w => GENERIC.has(w) || w.length < 3);
                }
                const df = {}; for (const n of list) for (const t of new Set(n.toks.map(t => t.slice(0,5)))) df[t] = (df[t] || 0) + 1;
                const N = list.length, idf = t => Math.log(1 + N / (df[t.slice(0,5)] || 1));
                // ana kod grubunun (ör. 773) tüm başlıklarındaki kelimeler — grup tespiti için
                const grup = new Map();
                for (const n of list) { const g = String(n.ana); if (!grup.has(g)) grup.set(g, new Set()); n.toks.forEach(t => grup.get(g).add(t)); }
                const gdfM = {}; for (const n of list) for (const t of new Set(n.toks.map(t => t.slice(0,5)))) (gdfM[t] = gdfM[t] || new Set()).add(n.ana);
                const gdf = t => (gdfM[t.slice(0,5)] || new Set()).size;
                cache = { raw, map, list, idf, grup, gdf };
                return cache;
              }
              const zincir = n => { const z = []; for (let x = n; x; x = x.ust) z.push(x); return z; };
              const diger = (c, n) => n && (n.cocuk.find(k => /\.99$/.test(k.kn)) || null);
              const aralikDiger = (c, n) => { if (!n || !n.aralik) return null; const k = c.map.get(String(n.aralik[1])); return k && k !== n ? k : null; };
              let GRUP = null;   // anahtar kelimeyle kesinleşen ana grup (ör. iş kazası → 918)
              function puanla(c, n, Q, Qs, qn) {
                const own = n.toks, ustT = []; for (let x = n.ust; x; x = x.ust) ustT.push(...x.toks);
                const top = own.reduce((a,t) => a + c.idf(t), 0) || 1;
                const eslesen = own.filter(t => icerir(Q, t)), es = eslesen.reduce((a,t) => a + c.idf(t), 0);
                const eksik = top - es;
                const ustEs = [...new Set(ustT)].filter(t => !own.includes(t) && icerir(Q, t)).reduce((a,t) => a + c.idf(t), 0);
                const ikincil = own.filter(t => !icerir(Q, t) && icerir(Qs, t)).reduce((a,t) => a + c.idf(t), 0);
                let p = es + 0.6 * ustEs + 0.15 * ikincil - 0.45 * eksik;
                // tek kelimelik başlık, üst başlıklar hiç tutmuyor ve kelime birçok farklı grupta geçiyor → belirsiz
                const belirsiz = own.length === 1 && eslesen.length === 1 && n.ust && !ustT.some(t => icerir(Q, t)) && c.gdf(own[0]) >= 3 && !(GRUP && String(n.ana) === GRUP);   // anahtar kelimeyle grup kesinse belirsiz sayılmaz
                if (belirsiz) p -= 1.5;
                const an = norm(n.ad);
                const ifade = !n.genel && own.length >= 2 && (' ' + qn + ' ').includes(' ' + an + ' ');
                if (ifade) p += 3;
                const oran = es / top;
                const tam = !n.genel && own.length > 0 && !belirsiz && (ifade || oran >= 0.66);
                const kismi = !n.genel && es > 0 && oran >= 0.5;
                return { p, tam, kismi, es, oran };
              }
              /* v3.6.74 — .99 (Diğer) KURALI
                 Seçilen kodun alt seçenekleri varsa → o kodun .99'u (yoksa kendisi).
                 Alt seçeneği olmayan (yaprak) kod ancak konu onu AÇIKÇA gösteriyorsa seçilir:
                   - başlığın kelimeleri konuda var (tam eşleşme),
                   - konudaki katalog kelimeleri bu kod + üst başlıklarıyla karşılanıyor (fazladan konu kelimesi yok),
                   - aynı gruptaki başka bir seçenek de konuya uymuyor (birden çok seçenek uyuyorsa yer belli değil).
                 Değilse en yakın üst grubun .99 (Diğer) kodu. Ör. "İş Sağlığı ve Güvenliği Eğitimi" → 918.99, "Hizmetiçi eğitim" → 774.99. */
              const NOTR = /^(basvu|dilek|istek|talep|evrak|resmi|yazi|bilgi|hakki|isle|ilisk|bildi|gonde|ilet|hk)/;
              function netKarar(raw, konu, kod) {
                const c = kur(raw); const n = c.map.get(kodNorm(kod)); if (!n) return { kod, net: true, neden: '' };
                const ustDiger = x => { for (let u = x.ust; u; u = u.ust) { const d = diger(c, u); if (d && d !== x) return d; } return null; };
                if (/\.99$/.test(n.kn)) return { kod: n.kod, net: true, neden: '' };
                if (n.cocuk.length) { const d = diger(c, n); return d ? { kod: d.kod, ad: d.ad, net: false, neden: n.kod + ' altında birden çok seçenek var, tam yeri belli değil → ' + d.kod + ' Diğer' } : { kod: n.kod, net: true, neden: '' }; }
                const qn = norm(aramaMetni(konu, raw)); const orj = toks(qn); const Q = new Set(orj);
                for (const [a, b] of ESANLAM) for (const q of orj) if (q.startsWith(a)) toks(b).forEach(t => Q.add(t));
                const eskiGrup = GRUP; { const h = IPUCLARI.find(([re]) => re.test(qn)); GRUP = h ? h[1] : eskiGrup; }
                const r = (() => { try { return puanla(c, n, Q, new Set(), qn); } finally { GRUP = eskiGrup; } })();
                if (!c.vocab) { c.vocab = new Set(); for (const x of c.list) x.toks.forEach(t => c.vocab.add(t)); }
                const kapsam = []; for (let x = n; x; x = x.ust) kapsam.push(...x.toks);
                if (n.aralik) kapsam.push(...toks(n.aralik[2]));
                const esAnl = t => { const s = [t]; for (const [a, b] of ESANLAM) if (t.startsWith(a)) s.push(...toks(b)); return s; };
                const bilinen = t => c.vocab.has(t) || [...c.vocab].some(v => benzer(v, t));
                const fazla = orj.filter(t => !NOTR.test(t) && !GENERIC.has(t) && bilinen(t) && !esAnl(t).some(x => kapsam.some(k => benzer(k, x))));
                const kardes = n.ust ? n.ust.cocuk.filter(k => k !== n && !/\.99$/.test(k.kn) && k.toks.some(t => !n.toks.includes(t) && orj.some(q => benzer(q, t)))) : [];
                const adTam = r.tam || (n.toks.length > 0 && n.toks.every(t => icerir(Q, t)));   // “Yıllık” gibi genel kelimeli başlık konuda aynen geçiyorsa
                if (adTam && !fazla.length && !kardes.length) return { kod: n.kod, net: true, neden: '' };
                const d = ustDiger(n);
                if (!d) return { kod: n.kod, net: true, neden: '' };
                const sebep = kardes.length ? 'konu birden çok seçeneğe uyuyor (' + [n, ...kardes].slice(0, 3).map(k => k.ad).join(', ') + ')' : fazla.length ? 'konudaki “' + fazla.join(', ') + '” ' + n.ad + ' başlığında yok' : n.ad + ' tam uyuşmuyor';
                return { kod: d.kod, ad: d.ad, net: false, neden: sebep + ' → ' + d.kod + ' Diğer' };
              }
              /**
               * bul(katalogMetni, birincil, ikincil, metin)
               * birincil: dosya adı / konu; ikincil: PDF'teki "Konu:" satırı; metin: PDF gövdesi (zayıf)
               * Döner: { secim:{kod,ad,kn}, aday:[...sıralı yedekler], neden, puan } ya da null
               */
              function bul(raw, birincil, ikincil, metin, kurallar) {
                GRUP = null;
                const c = kur(raw); if (!c.list.length) return null;
                const qn = norm([aramaMetni(birincil, raw), aramaMetni(ikincil, raw)].filter(Boolean).join(' '));
                const Q = new Set(toks(qn)), Qs = new Set(toks(String(metin || '').slice(0, 2500)));
                // parantez içi (kişi adı olabilir) aramaya girmez; yalnızca zayıf ipucu olarak sayılır
                for (const m of String([birincil, ikincil].filter(Boolean).join(' ')).matchAll(/\(([^()]*)\)/g)) toks(m[1]).forEach(t => Qs.add(t));
                // 1) Konu / dosya adında doğrudan kod yazıyorsa (ör. "773.99 staj ...")
                const kodYazili = /(?:^|\s)(\d{1,3}(?:\.\d{2}){1,3})(?=\s|$)/.exec(String([birincil, ikincil].filter(Boolean).join(' ')));
                if (kodYazili && c.map.get(kodNorm(kodYazili[1]))) { const n = c.map.get(kodNorm(kodYazili[1])); return paket(c, n, [], 'konuda yazılı kod', 99); }
                if (!Q.size) return null;
                // 2) İpucu / kural ile ana grup
                let zorunluGrup = null;
                for (const [re, g] of (kurallar || []).concat(IPUCLARI)) if (re.test(qn)) { zorunluGrup = g; break; }
                GRUP = zorunluGrup;
                // eş anlamlılar (etkinlik ~ faaliyet …)
                for (const [a, b] of ESANLAM) for (const q of [...Q]) if (q.startsWith(a)) toks(b).forEach(t => Q.add(t));
                // aralık (sayfa) başlığı tutuyorsa o aralığa öncelik: ör. "sosyal" → 300-349
                const aralikT = ARALIKLAR.map(a => toks(a[2]));
                const aralikHit = new Set(ARALIKLAR.filter((a, i) => aralikT[i].some(t => icerir(Q, t) && aralikT.filter(x => x.some(y => benzer(y, t))).length <= 2)).map(a => a[0]));
                let best = null, bp = -1e9, bilgi = null;
                for (const n of c.list) {
                  if (zorunluGrup && String(n.ana) !== zorunluGrup) continue;
                  const r = puanla(c, n, Q, Qs, qn);
                  let p = r.p - n.derinlik * 0.15 + (n.aralik && aralikHit.has(n.aralik[0]) ? 0.8 : 0);              // eşitlikte daha genel olan
                  if (p > bp) { bp = p; best = n; bilgi = r; }
                }
                if (!best) return null;
                if (!zorunluGrup && (bp < 2.2 || bilgi.es <= 0)) return null;   // güvenilir eşleşme yok → eski yönteme bırak
                // 3) Hiyerarşi: en derindeki TAM eşleşen düğüm; tam değilse bir üstün .99 (Diğer)'i
                const z = zincir(best);
                const tamNode = z.find(n => puanla(c, n, Q, Qs, qn).tam);
                let secim, neden;
                if (tamNode === best && !best.cocuk.length) { secim = best; neden = 'tam eşleşme'; }
                else if (tamNode) {
                  // v3.6.73 — alt başlık genel bir kelime olsa da konuda açıkça geçiyorsa onu seç (Yıllık İzin → 903.05.01 Yıllık)
                  const adli = tamNode.cocuk.filter(k => !/\.99$/.test(k.kn) && !/^diger$/.test(norm(k.ad))).find(k => { const w = norm(k.ad).split(' ').filter(x => x.length >= 3); return w.length && w.every(x => icerir(Q, x)); });
                  if (adli && !adli.cocuk.length) { secim = adli; neden = tamNode.kod + ' ' + tamNode.ad + ' → ' + adli.ad + ' (konuda geçiyor)'; }
                  else if (tamNode.cocuk.length) { secim = diger(c, tamNode) || tamNode; neden = secim === tamNode ? 'tam eşleşme (alt kod yok)' : tamNode.kod + ' bulundu, alt kod tam bulunamadı → Diğer'; }
                  else { secim = tamNode; neden = 'tam eşleşme'; }
                } else {
                  const kismiNode = z.find(n => puanla(c, n, Q, Qs, qn).kismi);
                  const grupNode = zorunluGrup ? c.map.get(zorunluGrup) : null;
                  const dayanak = kismiNode || grupNode;
                  if (!dayanak) {
                    const a = best.aralik && aralikHit.has(best.aralik[0]) ? best.aralik : (aralikHit.size === 1 ? ARALIKLAR.find(x => aralikHit.has(x[0])) : null);
                    const ad = a && c.map.get(String(a[1]));
                    if (!ad) return null;
                    return paket(c, ad, [c.map.get(String(a[0]))].filter(Boolean), 'tam kod yok → ' + a[2] + ' aralığının Diğer kodu', bp);
                  }                                   // grup bile belli değil → eski yöntem / elle
                  const adliK = dayanak.cocuk.filter(k => !/\.99$/.test(k.kn) && !k.cocuk.length && !/^diger$/.test(norm(k.ad))).find(k => { const w = norm(k.ad).split(' ').filter(x => x.length >= 3); return w.length && w.every(x => icerir(Q, x)); });
                  if (adliK) { secim = adliK; neden = dayanak.kod + ' ' + dayanak.ad + ' → ' + adliK.ad + ' (konuda geçiyor)'; }
                  else secim = (/\.99$/.test(best.kn) && best) || (dayanak.cocuk.length ? diger(c, dayanak) : null) || (dayanak.ust && diger(c, dayanak.ust)) || (dayanak.derinlik === 1 && dayanak.aralik && dayanak.ana === dayanak.aralik[0] ? aralikDiger(c, dayanak) : null) || dayanak;
                  if (!adliK) neden = dayanak.kod + ' kısmen eşleşti, tam kod bulunamadı → ' + (/\.99$/.test(secim.kn) ? 'Diğer' : secim.kod);
                }
                { const nk = netKarar(raw, [birincil, ikincil].filter(Boolean).join(' '), secim.kod); const yeni = !nk.net && c.map.get(kodNorm(nk.kod)); if (yeni && yeni !== secim) { secim = yeni; neden = nk.neden; } }
                if (zorunluGrup) neden += ' (anahtar kelime: ' + zorunluGrup + ')';
                // yedek adaylar (EBYS'te o kod yoksa sırayla denenir)
                const yedek = []; const ekle = n => { if (n && n !== secim && !yedek.includes(n)) yedek.push(n); };
                for (let x = secim.ust; x; x = x.ust) { ekle(diger(c, x)); ekle(x); }
                ekle(aralikDiger(c, c.map.get(String(secim.ana))));
                return paket(c, secim, yedek, neden, bp);
              }
              const sade = n => ({ kod: n.kod, ad: n.ad, kn: n.kn, ust: n.ust ? { kod: n.ust.kod, ad: n.ust.ad } : null });
              function paket(c, n, yedek, neden, puan) { return { secim: sade(n), aday: [n, ...yedek].map(sade), neden, puan: Math.round(puan * 100) / 100 }; }
              /* Liste/klasör seçeneğindeki kodları çıkarır ("Diğer773.99", "773.99 - Diğer", "Diğer [773.99]") */
              function metindekiKodlar(s) {
                const out = new Set(); const re = /(^|[^\d.])(\d{1,3}(?:\.\d{1,2}){0,4})(?![\d])/g; let m;
                const t = String(s || '').replace(/\d{1,3}\s*[-–]\s*\d{1,3}(?![\d.])/g, ' '); while ((m = re.exec(t)))   // (300-349), 100-600 gibi aralıklar kod sayılmaz
    { const k = kodNorm(m[2]); if (k) out.add(k); }
                return out;
              }
              const ayniKod = (a, b) => !!a && !!b && kodNorm(a) === kodNorm(b);
              /* Dosya adında konu var mı? (tarama/foto/numara adlarını eler) */
              function dosyaAdiKonu(ad) {
                let s = String(ad || '').replace(/\.[a-z0-9]{2,5}$/i, '').replace(/[_\-+]+/g, ' ');
                s = s.replace(/\b(e[- ]?)?\d{5,}\b/gi, ' ').replace(/\b\d{1,4}[.\/]\d{1,2}[.\/]\d{1,4}\b/g, ' ').replace(/\(\d+\)/g, ' ').replace(/(^|\s)[\d.]+(?=\s|$)/g, ' ').replace(/\s+/g, ' ').trim();
                const kelime = norm(s).split(' ').filter(w => /[a-z]/.test(w) && w.length >= 3);
                const cop = /^(scan|scanned|tarama|taranmis|img|image|dsc|dcim|pxl|photo|foto|fotograf|resim|ekran|screenshot|whatsapp|wa|belge|evrak|dosya|document|doc|docs|pdf|yeni|new|adsiz|untitled|kopya|copy|sayfa|page|ust|yazi|ustyazi|ek|ekler|cam|camscanner|microsoft|lens|office|download|indir|indirilen|gelen|giden|resmi|yazisi|file|output|print|scn)$/;
                const anlamli = kelime.filter(w => !cop.test(w) && !/^(img|dsc|scan|pxl|vid|wa|doc|dosya|belge|evrak|page|sayfa|image)\d/.test(w));
                if (anlamli.length >= 2 || (anlamli.length === 1 && anlamli[0].length >= 4)) return s;
                return '';
              }
              /* EBYS listesinde görünen bir seçeneği (başlık + üst başlık) konuya göre puanla */
              function metinPuan(raw, konu, baslik, ust) {
                const c = kur(raw); const qn = norm(aramaMetni(konu, raw)); const Q = new Set(toks(qn));
                for (const [a, b] of ESANLAM) for (const q of [...Q]) if (q.startsWith(a)) toks(b).forEach(t => Q.add(t));
                const own = toks(baslik), ustT = toks(ust || '');
                const genel = !own.length || norm(baslik).split(' ').every(w => GENERIC.has(w) || w.length < 3);
                const top = own.reduce((a, t) => a + c.idf(t), 0) || 1;
                const es = own.filter(t => icerir(Q, t)).reduce((a, t) => a + c.idf(t), 0);
                const ustEs = ustT.filter(t => !own.includes(t) && icerir(Q, t)).reduce((a, t) => a + c.idf(t), 0);
                const an = norm(baslik), ifade = !genel && own.length >= 1 && an.length >= 5 && (' ' + qn + ' ').includes(' ' + an + ' ');
                const oran = es / top;
                return { p: es + 0.6 * ustEs - 0.45 * (top - es) + (ifade ? 3 : 0), tam: !genel && (ifade || oran >= 0.66), kismi: !genel && es > 0 && oran >= 0.5, genel, es, ustEs };
              }
              /* Satır metninde bu başlık var mı? (katalog kodu EBYS'te başka konuya ait olmasın) */
              function baslikTutar(satir, baslik) {
                const b = toks(baslik); if (!b.length) return true;
                const S = new Set(toks(satir));
                return b.filter(t => icerir(S, t)).length / b.length >= 0.5;
              }
              /* v3.6.73 — Konu kodu ARAMASI için konuyu sadeleştir: parantez/köşeli parantez içi (kişi adı vb.),
                 evrak sayısı, tarih, sınıf-şube, "hk./hakkında" atılır. Konu alanına yazılan metin DEĞİŞMEZ. */
              function aramaMetni(konu, raw) {
                const orj = String(konu || '').replace(/\s+/g, ' ').trim();
                let s = orj;
                for (let i = 0; i < 4; i++) s = s.replace(/\([^()]*\)|\[[^\[\]]*\]|\{[^{}]*\}/g, ' ');
                s = s.replace(/[(\[{].*$/, ' ').replace(/[)\]}]/g, ' ');
                s = s.replace(/(^|[^\w])E[- ]?\d{5,}(?!\d)/gi, ' ')
                     .replace(/(^|[^\d.])(\d{1,2}[.\/-]\d{1,2}[.\/-]\d{4}|\d{4}[.\/-]\d{1,2}[.\/-]\d{1,2})(?![\d.])/g, ' ')   // tarih (desimal kod 010.06.01 korunur)
                     .replace(/(^|\s)\d{1,2}\s*[-\/.]\s*[A-ZÇĞİÖŞÜa-zçğıöşü](?![A-Za-zÇĞİÖŞÜçğıöşü])\s*(şubesi|sınıfı|sinifi|subesi)?/gi, ' ')
                     .replace(/(^|\s)\d{3,}\s*\/\s*\d+(?!\d)/g, ' ')
                     .replace(/(^|\s)(hk\.?|hakk[ıi]nda|ile ilgili|konulu|say[ıi]l[ıi]|tarihli|ilişkin|dair)(?=\s|$|[.,;:])/gi, ' ')
                     .replace(/[“”"'`’‘«»]+/g, ' ');
                // "Rapor - Ad Soyad", "Şikayet: Ad Soyad" → katalogda hiç karşılığı olmayan parçayı at
                if (raw) {
                  const c = kur(raw); if (!c.vocab) { c.vocab = new Set(); for (const n of c.list) n.toks.forEach(t => c.vocab.add(t)); }
                  const bilinir = p => toks(p).some(t => c.vocab.has(t) || [...c.vocab].some(v => benzer(v, t)) || ESANLAM.some(([a]) => t.startsWith(a)));
                  const par = s.split(/\s+[-–—]\s+|\s*:\s+|\s*\/\s+/).map(x => x.trim()).filter(Boolean);
                  if (par.length > 1) { const k = par.filter(bilinir); if (k.length) s = k.join(' '); }
                }
                s = s.replace(/\s+[-–—:;,.\/]+(?=\s|$)/g, ' ').replace(/^[\s\-–—:;,.\/]+|[\s\-–—:;,.\/]+$/g, '').replace(/\s+/g, ' ').trim();
                return norm(s).replace(/\s/g, '').length >= 3 ? s : orj;
              }
              // Arama kelimeleri: önce desimal katalogda karşılığı olanlar (uzundan kısaya), sonra diğerleri
              const anlamliKelimeler = (konu, raw, secenek) => {
                const w = toks(konu).filter(t => t.length >= 4).sort((a, b) => b.length - a.length);
                if (!raw) return w;
                const c = kur(raw); if (!c.vocab) { c.vocab = new Set(); for (const n of c.list) n.toks.forEach(t => c.vocab.add(t)); }
                const bil = t => c.vocab.has(t) || [...c.vocab].some(v => benzer(v, t));
                const b = w.filter(bil).sort((x, y) => c.idf(y) - c.idf(x));   // nadir (ayırt edici) kelime önce: “Nakli” > “Öğrenci”
                if (secenek === 'bilinen') return b;
                return [...b, ...w.filter(t => !bil(t))];
              };
              const esAnlamlar = konu => { const out = []; for (const t of toks(aramaMetni(konu))) for (const [a, b] of ESANLAM) if (t.startsWith(a)) b.split(' ').forEach(w => { if (!out.includes(w) && !toks(konu).includes(norm(w))) out.push(w); }); return out; };
              return { bul, netKarar, aramaMetni, esAnlamlar, metindekiKodlar, ayniKod, kodNorm, dosyaAdiKonu, norm, metinPuan, baslikTutar, anlamliKelimeler, genelMi: a => !toks(a).length || norm(a).split(' ').every(w => GENERIC.has(w) || w.length < 3) };
            })();
            

            /* ---- v3.6.60 yardımcıları ---- */
            const EA_KAT = () => _0xf5329d + '\n' + (_0x599e9b.katalog || '');
            const EA_uyku = ms => new Promise(r => setTimeout(r, ms));
            const EA_GENEL_AD = a => /^(diger|genel|teklifler|program|duyuru)$/.test(_0x3c029d(a || '').replace(/[^a-z ]/g, '').trim());
            // Yazdıktan sonra okulda yavaş internet için: önce AJAX/“Lütfen bekleyiniz” bitsin, sonra en az listeBekle sn bekle
            async function EA_listeBekle() {
                try { await _0x115206(6000); } catch (e) { if (e === 'stop') throw e; }
                const sn = +_0x599e9b.listeBekle > 0 ? +_0x599e9b.listeBekle : 2.5;
                const bit = Date.now() + Math.min(10, sn) * 1000;
                while (Date.now() < bit) { if (_0x228a28) throw 'stop'; await EA_uyku(150); }
                try { await _0x115206(4000); } catch (e) { if (e === 'stop') throw e; }
            }
            const EA_satirMetni = el => ((el.closest('li,tr,.ui-autocomplete-item') || el.parentElement || el).textContent || '');
            // Seçenek satırı bu kodun kendisi mi? (ör. 773 ararken 773.99 satırını kabul etme)
            /* v3.6.61 — LOV'da seçilmiş satırlar (ör. Kaldırılacak Klasörler / Birime Havale altındaki kutular) */
            const EA_lovSatirlar = idParca => {
                const out = [];
                for (const d of _0x52dd5d()) {
                    d.querySelectorAll('[id*="' + idParca + ':LovSecilenTable"] tr, [id*="' + idParca + '"] .lovSelectedTable tr').forEach(tr => {
                        if (!_0x30d46f(tr) || out.includes(tr)) return;
                        const t = (tr.innerText || tr.textContent || '').replace(/\s+/g, ' ').trim();
                        if (t && !/listelenecek veri/i.test(t)) out.push(tr);
                    });
                }
                return out;
            };
            const EA_satirCikarDugmesi = tr => [...tr.querySelectorAll('button,a,.ui-button,[title]')].find(b => /listeden\s*[çc][ıi]kar|sil|kaldır/i.test((b.textContent || '') + ' ' + (b.getAttribute('title') || '') + ' ' + (b.getAttribute('aria-label') || '')) || /LovSecilenTable:\d+:j_idt/.test(b.id || '')) || tr.querySelector('.ui-icon-close,.ui-icon-trash,[class*=delete],[class*=remove]');
            const EA_metinKodlari = t => { const m = /\[Klas[öo]r\]\s*(\d[\d.]*)/i.exec(String(t || '')); return m ? new Set([EA_KONU_KODU.kodNorm(m[1])]) : EA_KONU_KODU.metindekiKodlar(t); };
            const EA_okulCekirdek = ad => String(ad || '').replace(/\s+/g, ' ').replace(/\s*m[uü]d[uü]rl[uü][gğ][uü]\s*$/i, '').trim();
            const EA_okulTutar = (metin, ad) => { const w = _0x3c029d(EA_okulCekirdek(ad)).split(' ').filter(x => x.length > 2 && x !== 've'); if (!w.length) return false; const t = _0x3c029d(metin); return w.filter(x => t.includes(x)).length / w.length >= 0.85; };
            // Sayfada (ör. Geldiği Kişi kutusunda) "İl İlçe Örnek … Lisesi" geçiyorsa okul adının önündeki ilçeyi alır
            function EA_ilceliOkulAdi(cekirdek) {
                const kel = cekirdek.split(/\s+/).filter(Boolean); if (kel.length < 2) return '';
                const esc = x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                const re = new RegExp('([A-Za-zÇĞİÖŞÜçğıöşü]{3,})\\s+' + kel.map(esc).join('\\s+'), 'i');
                // yalnızca EBYS form kutularında ara (eklenti paneli / menü yazıları karışmasın: “Menü Örnek…” hatası)
                for (const d of _0x52dd5d()) {
                    for (const el of d.querySelectorAll('[id*="geldigiKisiLov"], [id*="LovSecilenTable"], [id*="dagitimBilgileri"]')) {
                        if (el.closest('#ek-kayit-host, [id^="ek-"]')) continue;
                        const m = re.exec(el.innerText || '');
                        if (m && /^[A-ZÇĞİÖŞÜ]/.test(m[1]) && !/^(ve|ile|kurum|okul|il|ilçe|müdürlüğü|mudurlugu|menü|menu|kayıt|havale|birime|konu|evrak|diğer|listeden)$/i.test(m[1]) && !EA_ILLER.includes(_0x3c029d(m[1]))) return m[1] + ' ' + cekirdek;
                    }
                }
                return '';
            }
            const EA_ILLER = 'adana adiyaman afyonkarahisar agri amasya ankara antalya artvin aydin balikesir bilecik bingol bitlis bolu burdur bursa canakkale cankiri corum denizli diyarbakir edirne elazig erzincan erzurum eskisehir gaziantep giresun gumushane hakkari hatay isparta mersin icel istanbul izmir kars kastamonu kayseri kirklareli kirsehir kocaeli konya kutahya malatya manisa kahramanmaras mardin mugla mus nevsehir nigde ordu rize sakarya samsun siirt sinop sivas tekirdag tokat trabzon tunceli sanliurfa usak van yozgat zonguldak aksaray bayburt karaman kirikkale batman sirnak bartin ardahan igdir yalova karabuk kilis osmaniye duzce'.split(' ');
            // "İlçe Örnek … Lisesi Müdürlüğü" → "Örnek … Lisesi" (baştaki il/ilçe ve sondaki Müdürlüğü atılır)
            // Geldiği Kişi / klasör kutusunda "İl İlçe … Müdürlüğü" → "İlçe" (il adından sonraki kelime)
            const EA_sayfaIlcesi = () => {
                for (const d of _0x52dd5d()) {
                    for (const el of d.querySelectorAll('[id*="geldigiKisiLov"], [id*="LovSecilenTable"]')) {
                        for (const sat of String(el.innerText || '').split('\n')) {
                            const w = sat.trim().split(/\s+/);
                            if (w.length > 3 && /m[uü]d[uü]rl[uü][gğ][uü]$/i.test(sat.trim()) && EA_ILLER.includes(_0x3c029d(w[0])) && !EA_ILLER.includes(_0x3c029d(w[1]))) return w[1];
                        }
                    }
                }
                return '';
            };
            const EA_sadeOkulAdi = (ad, prof) => {
                const w = EA_okulCekirdek(ad).split(/\s+/).filter(Boolean);
                const at = new Set([prof && prof.ilce, prof && prof.il, EA_sayfaIlcesi()].filter(Boolean).map(x => _0x3c029d(x)));
                while (w.length > 3 && (EA_ILLER.includes(_0x3c029d(w[0])) || at.has(_0x3c029d(w[0])))) w.shift();
                return w.join(' ');
            };
            const EA_ilsiz = ad => { const w = String(ad || '').trim().split(/\s+/); return w.length > 3 && EA_ILLER.includes(_0x3c029d(w[0])) ? w.slice(1).join(' ') : String(ad || '').trim(); };
            // Okul adı ayarlarda yoksa: Geldiği Kişi / klasör kutusundaki "… Lisesi Müdürlüğü" satırı
            function EA_okulSayfadan() {
                for (const d of _0x52dd5d()) {
                    for (const el of d.querySelectorAll('[id*="geldigiKisiLov"], [id*="kaldirilacakKlasorlerLov"]')) {
                        for (const sat of String(el.innerText || '').split('\n').map(x => x.trim())) {
                            if (/m[uü]d[uü]rl[uü][gğ][uü]\s*$/i.test(sat) && !/il[çc]e|milli e[gğ]itim|kurum/i.test(sat) && sat.length < 120) return sat;
                        }
                    }
                }
                return '';
            }
            const EA_havaleHedef = () => (_0x5f03d4.item && _0x5f03d4.item.havale || _0x599e9b.okul || '').trim();
            const EA_havaleTablodaVar = () => { const r = EA_lovSatirlar('dagitimBilgileriBirimLov'); if (!r.length) return ''; const h = EA_havaleHedef(); const tr = h ? r.find(x => EA_okulTutar(x.innerText || x.textContent, h)) : r[0]; return tr ? (tr.innerText || tr.textContent).replace(/\s+/g, ' ').trim() : ''; };
            const EA_satirKoduUyar = (el, kod) => {
                const kn = EA_KONU_KODU.kodNorm(kod); if (!kn) return false;
                const kodlar = EA_metinKodlari(EA_satirMetni(el));
                if (!kodlar.has(kn)) return false;
                return ![...kodlar].some(k => k !== kn && k.startsWith(kn + '.'));
            };

            /* v3.6.65 — Taranmış evrak OCR: dosyayı arka plana yollar, offscreen belgede Tesseract (tur) ile okunur */
            async function EA_ocrMetin(file) {
                const buf = new Uint8Array(await file.arrayBuffer());
                let ikili = '';
                for (let i = 0; i < buf.length; i += 0x8000) ikili += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
                const veri = btoa(ikili), tur = /\.pdf$/i.test(file.name) || file.type === 'application/pdf' ? 'pdf' : 'img';
                return await new Promise((coz, red) => {
                    let port;
                    try { port = chrome.runtime.connect({ name: 'EA_OCR' }); } catch (e) { return red(e); }
                    const zaman = setTimeout(() => { try { port.disconnect(); } catch (e) {} red(new Error('OCR zaman aşımı (3 dk)')); }, 180000);
                    port.onMessage.addListener(m => { clearTimeout(zaman); try { port.disconnect(); } catch (e) {} m && m.hata && !m.metin ? red(new Error(m.hata)) : coz(m); });
                    port.onDisconnect.addListener(() => { clearTimeout(zaman); red(new Error('OCR bağlantısı kapandı' + (chrome.runtime.lastError ? ': ' + chrome.runtime.lastError.message : ''))); });
                    port.postMessage({ veri, tur, ad: file.name, sayfalar: [1, -1] });
                });
            }
            /* v3.6.60 — Excel (.xlsx) desimal dosya kodları: TÜM sayfalar okunur (A: kod, B: konu) */
            async function EA_xlsxKodlari(file) {
                const buf = new Uint8Array(await file.arrayBuffer()), dv = new DataView(buf.buffer);
                let eocd = -1;
                for (let i = buf.length - 22; i >= Math.max(0, buf.length - 70000); i--) { if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; } }
                if (eocd < 0) throw new Error('Geçerli bir .xlsx değil');
                const adet = dv.getUint16(eocd + 10, true); let o = dv.getUint32(eocd + 16, true);
                const dosyalar = {}, td = new TextDecoder();
                for (let i = 0; i < adet; i++) {
                    if (dv.getUint32(o, true) !== 0x02014b50) break;
                    const yontem = dv.getUint16(o + 10, true), boy = dv.getUint32(o + 20, true), nl = dv.getUint16(o + 28, true), el = dv.getUint16(o + 30, true), cl = dv.getUint16(o + 32, true), lo = dv.getUint32(o + 42, true);
                    dosyalar[td.decode(buf.subarray(o + 46, o + 46 + nl))] = { yontem, boy, lo };
                    o += 46 + nl + el + cl;
                }
                const oku = async ad => {
                    const f = dosyalar[ad]; if (!f) return '';
                    const bas = f.lo + 30 + dv.getUint16(f.lo + 26, true) + dv.getUint16(f.lo + 28, true), veri = buf.subarray(bas, bas + f.boy);
                    if (f.yontem === 0) return td.decode(veri);
                    return await new Response(new Blob([veri]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text();
                };
                const xml = t => new DOMParser().parseFromString(t, 'application/xml');
                const ss = [...xml(await oku('xl/sharedStrings.xml') || '<sst/>').getElementsByTagName('si')].map(si => [...si.getElementsByTagName('t')].map(t => t.textContent).join(''));
                const sayfalar = Object.keys(dosyalar).filter(n => /^xl\/worksheets\/sheet\d+\.xml$/.test(n)).sort((a, b) => parseInt(a.replace(/\D/g, ''), 10) - parseInt(b.replace(/\D/g, ''), 10));
                const satirlar = [];
                for (const sn of sayfalar) {
                    const d = xml(await oku(sn));
                    for (const row of d.getElementsByTagName('row')) {
                        const h = {};
                        for (const c of row.getElementsByTagName('c')) {
                            const sutun = (c.getAttribute('r') || '').replace(/\d+/g, ''), tip = c.getAttribute('t'), v = c.getElementsByTagName('v')[0];
                            let val = tip === 's' ? (ss[+(v && v.textContent)] || '') : tip === 'inlineStr' ? [...c.getElementsByTagName('t')].map(t => t.textContent).join('') : (v ? v.textContent : '');
                            h[sutun] = String(val).trim();
                        }
                        const kod = (h.A || '').replace(/\s+/g, ''), ad = (h.B || '').replace(/\s+/g, ' ').trim();
                        if (/^\d{1,3}(\.\d{1,2}){0,4}$/.test(kod) && ad && !/^\d+\s*-\s*\d+$/.test(h.C || '')) satirlar.push(kod + '|' + ad);   // ANASAYFA (içindekiler) satırları hariç
                    }
                }
                return { satirlar, sayfa: sayfalar.length };
            }
            let _0x42b6ae = { 'raw': null, 'list': null };
            function _0x326eaa() {
                const _0x56ae8b = _0xf5329d + '\x0a' + (_0x599e9b.katalog || '');
                if (_0x42b6ae.raw === _0x56ae8b) {
                    return _0x42b6ae.list;
                }
                const _0x384d4 = [], _0x346f28 = {};
                for (const _0x590654 of _0x56ae8b.split('\x0a').map(_0x4bf4b4 => _0x4bf4b4.trim()).filter(Boolean)) {
                    const _0x3af1a5 = /^(\d[\d.]*)\s*[|\s]\s*(.+)$/.exec(_0x590654), _0x44d816 = _0x3af1a5 ? _0x3af1a5[0x1] : '', _0x4037e9 = _0x3af1a5 ? _0x3af1a5[0x2].trim() : _0x590654, _0xab36c5 = { 'kod': _0x44d816, 'ad': _0x4037e9, 'toks': _0x5bc337(_0x4037e9), 'anc': [] };
                    _0x384d4.push(_0xab36c5);
                    if (_0x44d816) {
                        _0x346f28[_0x2462a5(_0x44d816)] = _0xab36c5;
                    }
                }
                for (const _0xc0e6c7 of _0x384d4) {
                    if (!_0xc0e6c7.kod) {
                        continue;
                    }
                    const _0x1cbe79 = _0x2462a5(_0xc0e6c7.kod).split('.');
                    let _0x36e63f = _0x1cbe79.slice();
                    while (_0x36e63f.length > 0x1) {
                        _0x36e63f.pop();
                        const _0x1ccd02 = _0x346f28[_0x36e63f.join('.')];
                        if (_0x1ccd02) {
                            _0xc0e6c7.anc.push(_0x1ccd02);
                        }
                    }
                    const _0x324604 = parseInt(_0x1cbe79[0x0], 0xa), _0x3b0668 = Math.floor(_0x324604 / 0x64) * 0x64;
                    if (_0x324604 !== _0x3b0668 && _0x346f28[String(_0x3b0668)]) {
                        _0xc0e6c7.anc.push(_0x346f28[String(_0x3b0668)]);
                    }
                }
                _0x42b6ae = { 'raw': _0x56ae8b, 'list': _0x384d4 };
                return _0x384d4;
            }
            function _0x5b1886(_0x292487, _0x1653af, _0x1eda19) {
                const _0x119982 = _0x326eaa(), _0x22a84c = _0x119982.length, _0x3d6736 = {};
                for (const _0x59707e of _0x119982) {
                    for (const _0x142307 of _0x59707e.toks) {
                        _0x3d6736[_0x142307] = (_0x3d6736[_0x142307] || 0x0) + 0x1;
                    }
                }
                const _0x5271ee = _0x1e7a78 => Math.log(_0x22a84c / (_0x3d6736[_0x1e7a78] || 0x1)), _0x49c326 = _0x3c029d(_0x292487 || ''), _0x8d83c6 = _0x3c029d((_0x1eda19 || '').replace(/\.[a-z0-9]+$/i, '').replace(/[_\-]+/g, ' ')), _0x3e2c26 = new Set(_0x5bc337(_0x292487)), _0x26a78e = new Set([..._0x5bc337(_0x1653af || ''), ..._0x5bc337(_0x8d83c6)]), _0x2a5091 = /\bdiger\b/.test(_0x49c326);
                let _0x3fbaf7 = null, _0x3d1869 = 0x0;
                for (const _0x46b7f4 of _0x119982) {
                    const _0x4a4c89 = _0x3c029d(_0x46b7f4.ad);
                    let _0x3eff93 = 0x0;
                    if (_0x46b7f4.kod && (_0x49c326 === _0x3c029d(_0x46b7f4.kod) || _0x49c326.startsWith(_0x3c029d(_0x46b7f4.kod) + ' ') || _0x8d83c6.includes(_0x3c029d(_0x46b7f4.kod)))) {
                        _0x3eff93 += 0xc;
                    }
                    if (_0x4a4c89 && (_0x49c326 === _0x4a4c89 || _0x49c326.startsWith(_0x4a4c89 + ' ') || _0x49c326.includes(' ' + _0x4a4c89 + ' ') || _0x49c326.endsWith(' ' + _0x4a4c89))) {
                        _0x3eff93 += 0xa;
                    }
                    if (_0x4a4c89 && _0x49c326.includes(_0x4a4c89)) {
                        _0x3eff93 += 0x6;
                    }
                    if (_0x4a4c89 && _0x8d83c6 && (_0x8d83c6.includes(_0x4a4c89) || _0x4a4c89.split(' ').filter(_0x71a943 => _0x71a943.length >= 0x4).every(_0x228f39 => _0x8d83c6.includes(_0x228f39)))) {
                        _0x3eff93 += 0x5;
                    }
                    if (_0x2a5091 && /\.99$/.test(_0x46b7f4.kod || '') && _0x46b7f4.anc.length) {
                        const _0x3970b5 = _0x46b7f4.anc[0x0], _0xa17ac4 = _0x3c029d(_0x3970b5.ad);
                        if (_0xa17ac4 && (_0x49c326.includes(_0xa17ac4) || _0x8d83c6.includes(_0xa17ac4))) {
                            _0x3eff93 += 0x9;
                        }
                    }
                    if (_0x46b7f4.toks.length) {
                        const _0x4990a7 = _0x46b7f4.toks.reduce((_0xbe52a8, _0x534d5a) => _0xbe52a8 + _0x5271ee(_0x534d5a), 0x0) || 0x1, _0x1b4ca3 = _0x46b7f4.toks.filter(_0x3ad432 => _0x3e2c26.has(_0x3ad432)), _0x2c5a6c = _0x46b7f4.toks.filter(_0x3d041c => _0x26a78e.has(_0x3d041c) && !_0x3e2c26.has(_0x3d041c)), _0x2a6d7c = _0x1b4ca3.reduce((_0xddee9e, _0x15f242) => _0xddee9e + _0x5271ee(_0x15f242), 0x0), _0x2194bc = _0x2a6d7c / _0x4990a7, _0x1e02bd = _0x46b7f4.anc.reduce((_0x4354b9, _0x144d2b) => _0x4354b9 + _0x144d2b.toks.filter(_0x280057 => _0x3e2c26.has(_0x280057) || _0x26a78e.has(_0x280057)).reduce((_0x3b2c48, _0x583b0c) => _0x3b2c48 + _0x5271ee(_0x583b0c), 0x0), 0x0);
                        if (_0x1b4ca3.length && _0x2194bc >= 0.45 && _0x2a6d7c + _0x1e02bd * 0.5 >= 4.2) {
                            _0x3eff93 += _0x2194bc * 0x5 + _0x2a6d7c * 0x1 + Math.min(0x3, _0x1e02bd * 0.3) + _0x2c5a6c.reduce((_0x31de84, _0x3485af) => _0x31de84 + _0x5271ee(_0x3485af), 0x0) * 0.1;
                        }
                        else {
                            _0x1b4ca3.length === 0x1 && _0x46b7f4.toks.length >= 0x3 && (_0x3eff93 -= 0x2);
                        }
                    }
                    for (const _0x135891 of _0x46b7f4.anc.slice(0x0, 0x2)) {
                        const _0x30d2da = _0x3c029d(_0x135891.ad);
                        if (_0x30d2da && (_0x49c326.includes(_0x30d2da) || _0x8d83c6.includes(_0x30d2da))) {
                            _0x3eff93 += 0x3;
                        }
                    }
                    _0x3eff93 > _0x3d1869 && (_0x3d1869 = _0x3eff93, _0x3fbaf7 = _0x46b7f4);
                }
                if (_0x3d1869 < 5.5) {
                    return null;
                }
                if (_0x3fbaf7 && _0x2a5091 && !/\.99$/.test(_0x3fbaf7.kod || '')) {
                    const _0x1a405b = _0x3fbaf7.kod && !_0x3fbaf7.anc.length ? _0x3fbaf7 : _0x3fbaf7.anc[0x0] || _0x3fbaf7, _0x123b7f = _0x119982.find(_0x4da86b => _0x4da86b.kod === _0x1a405b.kod + ".99") || _0x119982.find(_0x5378e2 => /\.99$/.test(_0x5378e2.kod || '') && _0x5378e2.anc[0x0] === _0x1a405b);
                    if (_0x123b7f) {
                        _0x3fbaf7 = _0x123b7f;
                    }
                }
                return _0x3fbaf7;
            }
            const _0x3d0cb4 = _0x52fc24 => _0x52dd5d().flatMap(_0x313a32 => [..._0x313a32.querySelectorAll('input')]).filter(_0x342790 => _0x342790.type !== "hidden" && _0x342790.type !== "file" && _0x3c029d(_0x342790.id).includes(_0x52fc24) && _0x30d46f(_0x342790));
            function _0x4d2a7f() {
                let _unused_ltn8;
                for (const _0x32a181 of _0x52dd5d()) {
                    const _0x23a584 = [..._0x32a181.querySelectorAll("[id*=\"konuKoduLov\" i]")].filter(_0x23e6df => _0x30d46f(_0x23e6df) && !_0x23e6df.matches("input,.lovItemTitle") && !_0x23e6df.closest(".ui-autocomplete-panel,.ui-overlaypanel"));
                    for (const _0x426f72 of _0x23a584) {
                        const _0xa96d1 = (_0x426f72.innerText || '').split('\x0a').map(_0x348a99 => _0x348a99.trim()).filter(Boolean), _0x59be01 = _0xa96d1.find(_0x8cbea3 => /^\d[\d.]*$/.test(_0x8cbea3)), _0x2b11e1 = _0xa96d1.find(_0x2a4a13 => !/^\d[\d.]*$/.test(_0x2a4a13) && _0x2a4a13.length > 0x2);
                        if (_0x2b11e1 && _0x59be01) {
                            return { 'title': _0x2b11e1, 'code': _0x59be01 };
                        }
                    }
                }
                return null;
            }
            /* v3.6.60 — Konu kodu: önce dosya adı/konu → desimal katalog (Excel'deki tüm sayfalar) → hiyerarşik seçim.
               Tam kod yoksa ilgili grubun .99 (Diğer) kodu; o da yoksa üst kod. Listede yalnızca kodu BİREBİR aynı satır seçilir. */
            function EA_konuAdaylari() {
                const it = _0x5f03d4.item, konu = it.konu || '', kat = EA_KAT(), adaylar = [], ekle = (kod, ad, neden) => {
                    if (!kod || adaylar.some(x => EA_KONU_KODU.ayniKod(x.kod, kod))) return;
                    adaylar.push({ kod, ad: ad || '', neden });
                };
                const ekleU = (kod, ad, neden, ustAd) => { ekle(kod, ad, neden); const x = adaylar.find(y => EA_KONU_KODU.ayniKod(y.kod, kod)); if (x && ustAd && !x.ustAd) x.ustAd = ustAd; };
                const katBul = kod => { const kn = EA_KONU_KODU.kodNorm(kod); for (const l of kat.split('\n')) { const m = /^\s*(\d[\d.]*)\s*[|\t ]\s*(.+?)\s*$/.exec(l); if (m && EA_KONU_KODU.kodNorm(m[1]) === kn) return { kod: m[1], ad: m[2] }; } return null; };
                // 1) Daha önce ELLE düzeltilmiş (kod ile öğrenilmiş) konu
                const ogr = _0x599e9b.learned && (_0x599e9b.learned[_0x3c029d(EA_KONU_KODU.aramaMetni(konu, kat))] || _0x599e9b.learned[_0x3c029d(konu)]);
                const ogrKod = typeof ogr === 'string' && /^\d[\d.]*\|/.test(ogr) ? ogr.split('|') : null;
                if (ogrKod) ekle(ogrKod[0], ogrKod.slice(1).join('|'), 'öğrenilmiş (elle seçilmişti)');
                // 2) Ayarlardaki konu eşleme kuralı: anahtar=773 (ana kod) ya da anahtar=773.01 (tam kod)
                const kural = _0x53762f(konu) || _0x53762f(it.pdfKonu || '');
                const ipucu = [];
                if (kural && /^\d[\d.]*$/.test(kural.trim())) {
                    const k = kural.trim();
                    if (/^\d{1,3}$/.test(k)) ipucu.push([/./, String(parseInt(k, 10))]);
                    else { const kb = katBul(k); ekle(k, kb ? kb.ad : '', 'kural'); }
                }
                // 3) Katalog eşleştirme (dosya adı/konu → PDF “Konu:” satırı → PDF metni)
                const r = EA_KONU_KODU.bul(kat, konu, it.pdfKonu && it.pdfKonu !== konu ? it.pdfKonu : '', it.text || '', ipucu);
                if (r) r.aday.forEach((x, i) => ekleU(x.kod, x.ad, i ? 'yedek (üst/Diğer)' : 'katalog: ' + r.neden, x.ust && x.ust.ad));
                return { adaylar, kural: kural && !/^\d[\d.]*$/.test(kural.trim()) ? kural : '', sonuc: r };
            }
            /* v3.6.63 — EBYS Konu Kodu listesini oku: her satır {el, baslik, kod, ust} */
            function EA_satirCoz(row) {
                const satirlar = String(row.innerText || row.textContent || '').split('\n').map(x => x.trim()).filter(Boolean);
                const tEl = row.querySelector('.lovItemTitle');
                let kod = (satirlar.find(x => /^\d[\d.]*$/.test(x)) || '');
                if (!kod) { const k = [...EA_KONU_KODU.metindekiKodlar(row.textContent)]; kod = k[0] || ''; }
                const baslik = (tEl ? tEl.textContent.trim() : '') || satirlar.find(x => !/^\d[\d.]*$/.test(x)) || '';
                const ust = satirlar.filter(x => x !== baslik && !/^\d[\d.]*$/.test(x)).join(' ');
                return { el: tEl || row, row, baslik, kod, ust };
            }
            async function EA_lovYazVeOku(inp, metin) {
                const doc = inp.ownerDocument;
                inp.focus();
                _0x497585(inp, '');
                _0x2de811(inp, 'input');
                let acc = '';
                for (const ch of metin) {
                    acc += ch;
                    _0x497585(inp, acc);
                    inp.dispatchEvent(new InputEvent('input', { 'bubbles': true, 'data': ch }));
                    _0x3a4ac8(inp, 'keydown', ch);
                    _0x3a4ac8(inp, 'keyup', ch);
                    await _0x4e51ef(0x5a);
                }
                await _0x4e51ef(0x2bc);
                await EA_listeBekle();
                const onek = _0x538e5e(inp);
                let onceki = null, t0 = Date.now(), bosSay = 0;
                while (Date.now() - t0 < 15000) {
                    if (_0x228a28) throw 'stop';
                    let satirlar = [...new Set([...doc.querySelectorAll(_0x2b0f50)].filter(_0x30d46f).map(e => e.closest('li,tr,.ui-autocomplete-item') || e))].filter(r => !r.querySelector('li,tr'));
                    if (onek) { const f = satirlar.filter(r => (r.id || '').startsWith(onek) || r.closest('[id^="' + onek + '"]')); if (f.length) satirlar = f; }
                    if (satirlar.some(r => _0x13a51b(_0x3c029d(r.textContent)))) return [];
                    const imza = satirlar.map(r => r.textContent).join('|');
                    if (satirlar.length && imza === onceki) return satirlar.map(EA_satirCoz).filter(x => x.kod || x.baslik);
                    if (!satirlar.length && ++bosSay > 12) return [];
                    onceki = imza;
                    await _0x4e51ef(0x28a);
                }
                return [];
            }
            async function EA_secVeDogrula(girdi, sec, neden) {
                _0x17bcf9(sec.el);
                await _0x4e51ef(0x3e8);
                try { await _0x115206(6000); } catch (e) { if (e === 'stop') throw e; }
                const ekran = _0x4d2a7f();
                if (ekran && (!sec.kod || EA_KONU_KODU.ayniKod(ekran.code, sec.kod))) {
                    _0x5f03d4.kod = ekran.code;
                    _0x5f03d4.shown = ekran.title;
                    _0x5f03d4.term = ekran.title;
                    _0x5b5599('Konu kodu seçildi (EBYS listesi): ' + ekran.code + ' ' + ekran.title + ' — ' + neden, 'ok');
                    return true;
                }
                return !girdi() && !!ekran;
            }
            async function EA_konuEbysten(girdi, konu) {
                const kat = EA_KAT();
                const orjKonu = konu;
                konu = EA_KONU_KODU.aramaMetni(konu, kat);   // v3.6.73 — “CİMER Şikayeti (Ad Soyad)” → “CİMER Şikayeti”
                if (konu !== String(orjKonu || '').trim()) _0x5b5599('Konu kodu araması için sadeleştirildi: “' + konu + '”');
                const kelimeler = EA_KONU_KODU.anlamliKelimeler(konu, kat);
                // ascii kelimenin konudaki Türkçe yazılışı (sikayeti → Şikayeti); EBYS'e ascii yazılırsa sonuç gelmiyor
                const sozcukler = konu.split(/[^0-9A-Za-zÇĞİÖŞÜçğıöşüÂâÎîÛû]+/).filter(Boolean);
                const turkce = k => sozcukler.find(w => EA_KONU_KODU.norm(w) === k) || sozcukler.find(w => EA_KONU_KODU.norm(w).startsWith(k.slice(0, 5))) || k;
                const aramalar = [];
                const ekleAra = x => { x = String(x || '').trim(); if (x.length >= 3 && !aramalar.some(y => EA_KONU_KODU.norm(y) === EA_KONU_KODU.norm(x))) aramalar.push(x); };
                ekleAra(konu.slice(0, 60));
                const bilinen = EA_KONU_KODU.anlamliKelimeler(konu, kat, 'bilinen');
                bilinen.slice(0, 2).forEach(k => ekleAra(turkce(k).slice(0, 7)));          // desimal katalogda karşılığı olan kelimeler
                EA_KONU_KODU.esAnlamlar(konu).forEach(x => aramalar.length < 4 && ekleAra(x)); // CİMER → Şikayet/Talep, Nakli → Nakil
                kelimeler.filter(k => !bilinen.includes(k)).forEach(k => aramalar.length < 3 && ekleAra(turkce(k).slice(0, 7)));
                let enIyiKismi = null;
                for (const ara of aramalar) {
                    const inp = girdi(); if (!inp) return !!_0x4d2a7f();
                    _0x5b5599('Konu Kodu kutusuna yazılıyor: “' + ara + '”');
                    const sec = await EA_lovYazVeOku(inp, ara);
                    if (!sec.length) { _0x5b5599('“' + ara + '” için EBYS listesi boş.', 'err'); continue; }
                    const puanli = sec.map(x => Object.assign(x, EA_KONU_KODU.metinPuan(kat, konu, x.baslik, x.ust))).sort((a, b) => b.p - a.p);
                    _0x5b5599('EBYS seçenekleri: ' + puanli.slice(0, 4).map(x => x.kod + ' ' + x.baslik + (x.ust ? ' (' + x.ust.slice(0, 25) + ')' : '') + ' ' + x.p.toFixed(1)).join(' | '));
                    const tam = puanli.find(x => x.tam && !x.genel);
                    if (tam) {
                        // grup başlığı tuttu ama alt kodlardan hiçbiri tam değil → o grubun .99 (Diğer) kodu
                        const katSatir = (EA_KAT().split('\n').find(l => { const m = /^\s*(\d[\d.]*)\s*[|]/.exec(l); return m && EA_KONU_KODU.ayniKod(m[1], tam.kod); }) || '');
                        const katCocuklu = katSatir && EA_KONU_KODU.baslikTutar(katSatir, tam.baslik) && EA_KAT().split('\n').some(l => { const m = /^\s*(\d[\d.]*)\s*[|]/.exec(l); return m && EA_KONU_KODU.kodNorm(m[1]).startsWith(EA_KONU_KODU.kodNorm(tam.kod) + '.'); });
                        const listeCocuk = puanli.filter(x => x.kod && tam.kod && EA_KONU_KODU.kodNorm(x.kod).startsWith(EA_KONU_KODU.kodNorm(tam.kod) + '.'));
                        if (tam.kod && (listeCocuk.length || katCocuklu)) {
                            const hedefKod = tam.kod + '.99';
                            let d = listeCocuk.find(x => EA_KONU_KODU.ayniKod(x.kod, hedefKod));
                            if (!d) {
                                _0x3a4ac8(inp, 'keydown', 'Escape');
                                const inp2 = girdi();
                                if (inp2) d = (await EA_lovYazVeOku(inp2, hedefKod)).find(x => EA_KONU_KODU.ayniKod(x.kod, hedefKod));
                            }
                            if (d) return EA_secVeDogrula(girdi, d, tam.kod + ' ' + tam.baslik + ' bulundu, alt kod tam yok → ' + hedefKod + ' Diğer');
                            const inp3 = girdi();
                            if (inp3) {
                                const yeniden = (await EA_lovYazVeOku(inp3, ara)).find(x => EA_KONU_KODU.ayniKod(x.kod, tam.kod));
                                if (yeniden) return EA_secVeDogrula(girdi, yeniden, 'grup kodu (Diğer bulunamadı)');
                            }
                            continue;
                        }
                        // v3.6.74 — .99 kuralı: konu bu seçeneği açıkça göstermiyorsa (birden çok seçenek uyuyor / fazladan konu kelimesi var) grubun Diğer'i
                        const nk = tam.kod ? EA_KONU_KODU.netKarar(kat, konu, tam.kod) : { net: true };
                        if (!nk.net && nk.kod && !EA_KONU_KODU.ayniKod(nk.kod, tam.kod)) {
                            let d = puanli.find(x => EA_KONU_KODU.ayniKod(x.kod, nk.kod));
                            if (!d) {
                                _0x3a4ac8(inp, 'keydown', 'Escape');
                                const inp2 = girdi();
                                if (inp2) d = (await EA_lovYazVeOku(inp2, nk.kod)).find(x => EA_KONU_KODU.ayniKod(x.kod, nk.kod));
                            }
                            if (d) return EA_secVeDogrula(girdi, d, tam.kod + ' ' + tam.baslik + ' yerine ' + nk.neden);
                            _0x5b5599(nk.kod + ' (Diğer) EBYS listesinde bulunamadı; ' + tam.kod + ' seçiliyor.', 'err');
                            const inp3 = girdi();
                            if (inp3) { const y = (await EA_lovYazVeOku(inp3, tam.kod)).find(x => EA_KONU_KODU.ayniKod(x.kod, tam.kod)); if (y) return EA_secVeDogrula(girdi, y, 'başlık konuyla tam eşleşti'); }
                            continue;
                        }
                        return EA_secVeDogrula(girdi, tam, 'başlık konuyla tam eşleşti');
                    }
                    const k = puanli.find(x => x.kismi);
                    if (k && (!enIyiKismi || k.p > enIyiKismi.p)) enIyiKismi = k;
                    // aynı listede o grubun “Diğer”i varsa (üst başlığı konuya uyan)
                    const dig = puanli.find(x => x.genel && /diger/.test(_0x3c029d(x.baslik)) && x.ustEs > 0);
                    if (dig && !k) return EA_secVeDogrula(girdi, dig, 'tam kod yok → grubun Diğer kodu');
                    _0x3a4ac8(inp, 'keydown', 'Escape');
                }
                if (enIyiKismi) {
                    // tam alt kod yok → aynı grubun .99 (Diğer) kodu; yoksa kısmen tutan kodun kendisi
                    const par = String(enIyiKismi.kod || '').split('.');
                    const grupKodlari = [];
                    if (par.length > 1) grupKodlari.push(par.slice(0, -1).join('.') + '.99');
                    grupKodlari.push(par[0] + '.99');
                    for (const gk of [...new Set(grupKodlari)]) {
                        const inp = girdi(); if (!inp) break;
                        const sec = await EA_lovYazVeOku(inp, gk);
                        const hedef = sec.find(x => EA_KONU_KODU.ayniKod(x.kod, gk));
                        if (hedef) return EA_secVeDogrula(girdi, hedef, enIyiKismi.kod + ' ' + enIyiKismi.baslik + ' kısmen tuttu → ' + gk + ' Diğer');
                        _0x3a4ac8(inp, 'keydown', 'Escape');
                    }
                    const inp = girdi();
                    if (inp) {
                        const sec = await EA_lovYazVeOku(inp, enIyiKismi.kod || enIyiKismi.baslik);
                        const hedef = sec.find(x => EA_KONU_KODU.ayniKod(x.kod, enIyiKismi.kod)) || sec.find(x => x.baslik === enIyiKismi.baslik);
                        if (hedef) return EA_secVeDogrula(girdi, hedef, 'kısmen eşleşen kod');
                    }
                }
                return false;
            }
            async function _0x53afba() {
                const _0x39b7ac = () => _0x3d0cb4("konukodulov")[0x0];
                const { adaylar, kural } = EA_konuAdaylari();
                const konu = _0x5f03d4.item.konu || '';
                if (!_0x39b7ac()) {
                    const secili = _0x4d2a7f();
                    if (secili) {
                        const sp = EA_KONU_KODU.metinPuan(EA_KAT(), konu, secili.title, '');
                        const spNk = EA_KONU_KODU.netKarar(EA_KAT(), konu, secili.code);
                        if ((sp.tam || sp.kismi) && (spNk.net || EA_KONU_KODU.ayniKod(spNk.kod, secili.code))) {
                            _0x5b5599('Konu kodu zaten seçili ve konuya uyuyor: ' + secili.title + ' [' + secili.code + ']', 'ok');
                            EA_konuKoduOku();
                            return;
                        }
                        let cik = null;
                        for (const d of _0x52dd5d()) { cik = cik || [...d.querySelectorAll('[id*="konuKoduLov"] button,[id*="konuKoduLov"] a')].filter(_0x30d46f).find(b => /listeden\s*[çc][ıi]kar/i.test(b.textContent + ' ' + (b.getAttribute('title') || '') + ' ' + (b.getAttribute('aria-label') || ''))); }
                        if (!cik) {
                            _0x5b5599('Konu kodu zaten seçili: ' + secili.title + ' [' + secili.code + ']', 'ok');
                            EA_konuKoduOku();
                            return;
                        }
                        _0x5b5599('Ekrandaki ' + secili.code + ' ' + secili.title + ' konuya (“' + konu + '”) uymuyor, çıkarılıyor…');
                        _0x2c5bca(cik);
                        await _0x4e51ef(0x258);
                        try { await _0x115206(6000); await _0x5c5b76(() => _0x39b7ac(), 0x1f40); } catch (e) { if (e === 'stop') throw e; }
                    }
                }
                // 1) Daha önce elle düzeltilmiş (kod|başlık) öğrenilmiş kayıt varsa önce o
                const ogrenilmis = adaylar.filter(x => /öğrenilmiş/.test(x.neden));
                // 2) EBYS'in KENDİ listesi: konuyu yaz, gelen seçenekleri başlığa göre puanla (katalog kodu EBYS'te başka konu olabiliyor)
                if (!ogrenilmis.length && _0x39b7ac()) {
                    try {
                        if (await EA_konuEbysten(_0x39b7ac, konu)) return;
                    } catch (e) {
                        if (e === 'stop') throw e;
                        _0x5b5599('EBYS listesinden seçilemedi: ' + (e.message || e), 'err');
                    }
                    if (!_0x39b7ac() && _0x4d2a7f()) { EA_konuKoduOku(); return; }
                }
                if (!adaylar.length || kural) {
                    _0x5b5599(kural ? 'Konu eşleme kuralı (ad ile): “' + kural + '”' : 'Katalogda güvenilir kod bulunamadı; konu metniyle aranıyor…', kural ? '' : 'err');
                    return EA_konuKoduEski();
                }
                _0x5b5599('Konu kodu adayları: ' + adaylar.slice(0, 5).map(x => x.kod + (x.ad ? ' ' + x.ad : '')).join(' → ') + '  (' + adaylar[0].neden + ')');
                let sonHata = null;
                for (const ad of adaylar.slice(0, 4)) {
                    _0x5f03d4.kod = ad.kod;
                    _0x5f03d4.term = ad.ad || ad.kod;
                    const aramalar = [ad.kod];
                    if (ad.ad && !EA_GENEL_AD(ad.ad)) aramalar.push(ad.ad);
                    else if (ad.ustAd && !EA_GENEL_AD(ad.ustAd)) aramalar.push(ad.ustAd);   // “Diğer” için üst başlıkla ara, kodla süz
                    if (ad.ad && EA_GENEL_AD(ad.ad)) aramalar.push(ad.ad);   // son çare: “Diğer” yaz, yalnızca bu kodlu satırı seç
                    for (const ara of aramalar) {
                        const inp = _0x39b7ac();
                        if (!inp) {
                            // alan metin kutusu değil (ör. açılır menü) → etiket üzerinden seç
                            try {
                                await _0x4010a5("Konu Kodu", ara, { 'list': !false, 'kodExact': ad.kod });
                            } catch (e) {
                                if (e === 'stop') throw e;
                                sonHata = e;
                                _0x5b5599('“' + ara + '” ile ' + ad.kod + ' seçilemedi: ' + (e.message || e), 'err');
                                continue;
                            }
                        } else {
                            try {
                                await _0x5a1f35(inp, ara, !false, { 'done': () => !_0x39b7ac(), 'kodExact': ad.kod, 'baslik': EA_KONU_KODU.genelMi(ad.ad) ? (ad.ustAd || '') : ad.ad, 'prefer': [_0x3c029d(ad.kod)] });
                            } catch (e) {
                                if (e === 'stop') throw e;
                                sonHata = e;
                                _0x5b5599('“' + ara + '” ile ' + ad.kod + ' seçilemedi: ' + (e.message || e), 'err');
                                continue;
                            }
                        }
                        await _0x4e51ef(0x3e8);
                        try { await _0x115206(5000); } catch (e) { if (e === 'stop') throw e; }
                        const ekran = _0x4d2a7f();
                        if (ekran && EA_KONU_KODU.ayniKod(ekran.code, ad.kod)) {
                            _0x5f03d4.kod = ekran.code;
                            _0x5f03d4.shown = ekran.title;
                            _0x5b5599('Konu kodu seçildi: ' + ekran.code + ' ' + ekran.title + ' (' + ad.neden + ')', 'ok');
                            return;
                        }
                        if (ekran && ekran.code) {
                            throw new Error('Yanlış konu kodu göründü (beklenen ' + ad.kod + ', ekranda ' + ekran.code + ') — doğru kodu siz seçin, sonra “Elle yaptım, devam”');
                        }
                        // ekranda okunamadıysa seçilen satırdan doğrula
                        if (_0x5f03d4.pickedRow && EA_KONU_KODU.metindekiKodlar(_0x5f03d4.pickedRow).has(EA_KONU_KODU.kodNorm(ad.kod))) {
                            _0x5f03d4.shown = ad.ad;
                            _0x5b5599('Konu kodu seçildi: ' + ad.kod + ' ' + ad.ad + ' (' + ad.neden + ')', 'ok');
                            return;
                        }
                    }
                    if (!_0x39b7ac() && _0x4d2a7f()) break;
                }
                throw sonHata && /Yanlış konu kodu/.test(sonHata.message || '') ? sonHata : new Error('Konu kodu otomatik seçilemedi (' + adaylar.map(x => x.kod).join(', ') + ' listede bulunamadı) — doğru kodu siz seçin, sonra “Elle yaptım, devam” deyin');
            }
            function EA_konuKoduOku() {
                const e = _0x4d2a7f();
                if (e) {
                    _0x5f03d4.kod = e.code;
                    _0x5f03d4.shown = e.title;
                }
                return e;
            }
            async function EA_konuKoduEski() {
                const _0x59a12e = EA_KONU_KODU.aramaMetni(_0x5f03d4.item.konu, EA_KAT()), _0x90c010 = _0x3c029d(_0x59a12e), _0x39b7ac = () => _0x3d0cb4("konukodulov")[0x0];
                if (!_0x39b7ac()) {
                    const _0xde1cbf = _0x4d2a7f();
                    if (_0xde1cbf) {
                        _0x5b5599('Konu kodu zaten seçili: ' + _0xde1cbf.title + ' [' + _0xde1cbf.code + ']', 'ok');
                        EA_konuKoduOku();
                        return;
                    }
                }
                const _0x48e708 = ((v) => v && !/^\d[\d.]*\|/.test(v) && !EA_GENEL_AD(v) ? v : null)(_0x599e9b.learned && (_0x599e9b.learned[_0x90c010] || _0x599e9b.learned[_0x3c029d(_0x5f03d4.item.konu)]));
                let _0x578d87, _0x3b6912, _0x500dc6 = null;
                if (_0x48e708) {
                    _0x578d87 = _0x48e708;
                    _0x3b6912 = "öğrenilmiş";
                }
                else {
                    if (_0x53762f(_0x59a12e)) {
                        _0x578d87 = _0x53762f(_0x59a12e);
                        _0x3b6912 = 'kural';
                    }
                    else {
                        if (_0x500dc6 = _0x5b1886(_0x59a12e, _0x5f03d4.item.text, _0x5f03d4.item.file && _0x5f03d4.item.file.name)) {
                            _0x578d87 = _0x500dc6.ad;
                            _0x5f03d4.kod = _0x500dc6.kod;
                            _0x3b6912 = "katalog " + _0x500dc6.kod + (_0x500dc6.anc[0x0] ? ' ← ' + _0x500dc6.anc[0x0].ad : '');
                        }
                        else {
                            _0x53762f(_0x5f03d4.item.text || '') ? (_0x578d87 = _0x53762f(_0x5f03d4.item.text), _0x3b6912 = "metin kuralı") : (_0x578d87 = _0x59a12e, _0x3b6912 = "konu");
                        }
                    }
                }
                _0x5f03d4.term = _0x578d87;
                _0x5b5599("Konu kodu araması: “" + _0x578d87 + "” (" + _0x3b6912 + ')');
                const _0x383023 = _0x500dc6 ? [_0x3c029d(_0x500dc6.kod), ..._0x500dc6.anc.slice(0x0, 0x3).map(_0x300e1f => _0x3c029d(_0x300e1f.ad))] : [];
                if (!_0x39b7ac()) {
                    await _0x423533("Konu Kodu", [_0x500dc6 && _0x500dc6.kod, _0x578d87, _0x578d87.split(' ')[0x0]].filter(Boolean), { 'list': !false, 'prefer': _0x383023 });
                    EA_konuKoduOku();
                    return;
                }
                const _0x2ff6df = () => !_0x39b7ac(), _0x4d287d = [...new Set([..._0x5f206b(_0x59a12e), ..._0x5f206b(_0x578d87)])], _0x4c23bd = [...new Set(_0x59a12e.split(/[^A-Za-zÇĞİÖŞÜçğıöşüÂâ]+/).filter(_0x3db80c => _0x3db80c.length >= 0x4))].sort((_0xbccb03, _0x5b3f58) => _0x5b3f58.length - _0xbccb03.length).slice(0x0, 0x2), _0x28df54 = [];
                if (_0x500dc6 && _0x500dc6.kod) {
                    _0x28df54.push([_0x500dc6.kod, { 'must': _0x500dc6.kod, 'prefer': _0x383023, 'exact': _0x500dc6.kod }]);
                }
                _0x28df54.push([_0x578d87, { 'must': _0x578d87, 'prefer': _0x383023 }]);
                if (_0x500dc6 && _0x500dc6.ad && _0x500dc6.ad !== _0x578d87) {
                    _0x28df54.push([_0x500dc6.ad, { 'must': _0x500dc6.ad, 'prefer': _0x383023 }]);
                }
                for (const _0x3c7d2c of _0x4c23bd) {
                    _0x28df54.push([_0x3c7d2c, { 'fuzzy': _0x4d287d }]);
                }
                let _0x5b82d0;
                for (const [_0xb35340, _0x59bba7] of _0x28df54) {
                    const _0x37eda2 = _0x39b7ac();
                    if (!_0x37eda2) {
                        break;
                    }
                    try {
                        await _0x5a1f35(_0x37eda2, _0xb35340, !false, Object.assign({ 'done': _0x2ff6df }, _0x59bba7));
                        _0x5b82d0 = null;
                        break;
                    }
                    catch (_0x381e9a) {
                        if (_0x381e9a === 'stop') {
                            throw _0x381e9a;
                        }
                        _0x5b82d0 = _0x381e9a;
                        _0x5b5599('“' + _0xb35340 + '” ile olmadı: ' + (_0x381e9a.message || _0x381e9a), 'err');
                    }
                }
                if (_0x5b82d0 && _0x39b7ac()) {
                    throw new Error("Konu kodu otomatik seçilemedi — açılan listeden siz seçin, sonra “Elle yaptım, devam” deyin");
                }
                await _0x4e51ef(0xa28);
                EA_konuKoduOku();
            }
            /* v3.6.60 — Kaldırılacak Klasör: konu kodu ile AYNI kodlu klasör (ör. 773.99 → 773.99) */
            async function EA_klasorSec() {
                const ekran = EA_konuKoduOku(), kod = (ekran && ekran.code) || _0x5f03d4.kod;
                if (!kod) {
                    throw new Error('Konu kodu belli değil; Kaldırılacak Klasör seçilmedi');
                }
                const etiket = await _0x5c5b76(() => _0xd17bf4('Kaldırılacak Klasör'), 0x1f40).catch(() => null), alan = etiket && _0x520f6b(etiket), inp = alan && (alan.matches('input') ? alan : alan.querySelector('input:not([type=hidden])'));
                const kn = EA_KONU_KODU.kodNorm(kod);
                for (let tur = 0; tur < 4; tur++) {
                    const yanlis = EA_lovSatirlar('kaldirilacakKlasorlerLov').filter(tr => !EA_metinKodlari(tr.innerText || tr.textContent).has(kn));
                    if (!yanlis.length) break;
                    const b = EA_satirCikarDugmesi(yanlis[0]);
                    if (!b) { _0x5b5599('Farklı kodlu klasör var ama “Listeden Çıkar” bulunamadı: ' + (yanlis[0].innerText || '').replace(/\s+/g, ' ').slice(0, 60), 'err'); break; }
                    _0x5b5599('Konu koduyla uyuşmayan klasör çıkarılıyor: ' + (yanlis[0].innerText || '').replace(/\s+/g, ' ').slice(0, 60));
                    _0x2c5bca(b);
                    await _0x4e51ef(0x258);
                    try { await _0x115206(6000); } catch (e) { if (e === 'stop') throw e; }
                }
                const mevcut = (alan ? (alan.textContent || '') + ' ' + (inp ? inp.value : '') : '') + ' ' + EA_lovSatirlar('kaldirilacakKlasorlerLov').map(tr => tr.innerText || tr.textContent).join(' ');
                if (EA_lovSatirlar('kaldirilacakKlasorlerLov').some(tr => EA_metinKodlari(tr.innerText || tr.textContent).has(kn)) || EA_KONU_KODU.metindekiKodlar(mevcut).has(kn)) {
                    _0x5b5599('Kaldırılacak klasör zaten konu koduyla aynı: ' + kod, 'ok');
                    return;
                }
                const ad = (ekran && ekran.title) || _0x5f03d4.shown || '';
                const aramalar = [...new Set([kod, ad && !EA_GENEL_AD(ad) ? ad : null, _0x5f03d4.term && !EA_GENEL_AD(_0x5f03d4.term) && !/^\d/.test(_0x5f03d4.term) ? _0x5f03d4.term : null].filter(Boolean))];
                let son = null;
                for (const ara of aramalar) {
                    try {
                        _0x5f03d4.pickedRow = '';
                        await _0x4010a5('Kaldırılacak Klasör', ara, { 'list': !false, 'kodExact': kod });
                        _0x5b5599('Kaldırılacak klasör seçildi: ' + ((_0x5f03d4.pickedRow || _0x5f03d4.picked || '').replace(/\s+/g, ' ').trim().slice(0, 70) || kod) + ' (konu kodu ' + kod + ')', 'ok');
                        return;
                    } catch (e) {
                        if (e === 'stop') throw e;
                        son = e;
                        _0x5b5599('Klasör “' + ara + '”: ' + (e.message || e), 'err');
                    }
                }
                throw new Error('Kaldırılacak Klasör: konu kodu ' + kod + ' ile aynı kodlu klasör bulunamadı' + (son ? ' (' + (son.message || son) + ')' : '') + ' — listeden ' + kod + ' klasörünü siz seçin');
            }
            async function _0x14ec7() {
                const _0x8e59c = _0x4d2a7f();
                _0x8e59c && (_0x5f03d4.kod = _0x8e59c.code, _0x5f03d4.shown = _0x8e59c.title);
                const _0xed8c68 = _0x8e59c && _0x8e59c.title || _0x46c02f(_0x5f03d4.picked || '');
                _0xed8c68 && (_0x599e9b.learned = _0x599e9b.learned || {}, _0x599e9b.learned[_0x3c029d(_0x5f03d4.item.konu)] = _0x8e59c && _0x8e59c.code ? _0x8e59c.code + '|' + _0xed8c68 : _0xed8c68, _0x599e9b.learned[_0x3c029d(EA_KONU_KODU.aramaMetni(_0x5f03d4.item.konu, EA_KAT()))] = _0x599e9b.learned[_0x3c029d(_0x5f03d4.item.konu)], _0x381096(), _0x5b5599('Öğrenildi: “' + _0x5f03d4.item.konu + "” → “" + _0xed8c68 + '”' + (_0x5f03d4.kod ? ' [' + _0x5f03d4.kod + ']' : ''), 'ok'));
            }
            function _0x14a98f() {
                const _0x29882c = _0x1129fb("Konu", { 'exact': !false })[0x0];
                if (!_0x29882c) {
                    return null;
                }
                const _0x17b25c = _0x520f6b(_0x29882c);
                if (!_0x17b25c) {
                    return null;
                }
                return _0x17b25c.matches("input,textarea") ? _0x17b25c : _0x17b25c.querySelector('input,textarea');
            }
            async function _0x1e2aff() {
                const _0x135810 = (_0x5f03d4.item.konu || '').trim();
                if (!_0x135810) {
                    throw new Error("Konu metni boş (satırdaki Konu kutusunu doldurun)");
                }
                const _0x586130 = _0x12e5a0 => {
                    const _0x7d739c = String(_0x12e5a0 || '').trim();
                    if (!_0x7d739c) {
                        return false;
                    }
                    if (_0x3c029d(_0x7d739c) === _0x3c029d(_0x135810)) {
                        return !false;
                    }
                    if (_0x7d739c.length >= 0xc && _0x3c029d(_0x135810).startsWith(_0x3c029d(_0x7d739c)) && _0x135810.length - _0x7d739c.length <= 0x8) {
                        return !false;
                    }
                    return false;
                };
                for (let _0x185524 = 0x0; _0x185524 < 0x4; _0x185524++) {
                    const _0x287355 = await _0x5c5b76(_0x14a98f, 0x1f40);
                    if (_0x586130(_0x287355.value)) {
                        return;
                    }
                    await _0x5a1f35(_0x287355, _0x135810, false);
                    await _0x4e51ef(0xe10);
                }
                const _0xdb8f5 = _0x14a98f();
                if (!_0xdb8f5 || !_0x586130(_0xdb8f5.value)) {
                    const _0x103550 = _0xdb8f5 ? _0xdb8f5.value : '?';
                    if (_0x103550 && _0x135810 && _0x3c029d(_0x135810).startsWith(_0x3c029d(_0x103550)) && _0x103550.length + 0x5 < _0x135810.length) {
                        throw new Error("Konu metni kesilmiş görünüyor (“" + _0x103550 + '”) — tam metni kontrol edin: “' + _0x135810.slice(0x0, 0x50) + '”');
                    }
                    throw new Error("Konu alanı “" + _0x135810 + "” olarak kalmadı (şu an: “" + _0x103550 + '”)');
                }
            }
            async function _0x15fbb8() {
                let _unused_hud1;
                await _0x1e2aff();
                _0x5b5599("Konu yazıldı: " + _0x5f03d4.item.konu.slice(0x0, 0x50));
            }
            const _0x6296a6 = _0x456553 => {
                const _0x4474ea = (_0x456553 || '').trim().split(/\s+/);
                return [...new Set([_0x456553, _0x4474ea[_0x4474ea.length - 0x1], _0x4474ea[0x0]])].filter(Boolean);
            };
            async function _0x420cf4() {
                const _0x325a22 = _0xd17bf4('Geldiği Kişi');
                if (!_0x325a22) {
                    return null;
                }
                const _0xb26068 = _0x325a22.ownerDocument, _0xa0b831 = _0x36ac27 => _0x325a22.compareDocumentPosition(_0x36ac27) & Node.DOCUMENT_POSITION_FOLLOWING && !_0x325a22.contains(_0x36ac27), _0x63ef33 = _0x520f6b(_0x325a22), _0x212a0f = (_0x63ef33 || _0x325a22).getBoundingClientRect(), _0x4b97b2 = _0x3fad5c => {
                    const _0x570976 = _0x3fad5c.getBoundingClientRect();
                    return Math.abs(_0x570976.top - _0x212a0f.top) < 0x8c;
                }, _0x4a6600 = _0x3b1432 => _0x3c029d((_0x3b1432 || '').trim()) === _0x3c029d('Kullanıcı'), _0x282d2a = [..._0xb26068.querySelectorAll("label,span,td")].filter(_0x93ee36 => _0x30d46f(_0x93ee36) && _0xa0b831(_0x93ee36) && _0x4b97b2(_0x93ee36) && _0x4a6600(_0x93ee36.textContent))[0x0];
                if (_0x282d2a) {
                    const _0x1e6b7 = _0x282d2a.htmlFor && _0xb26068.getElementById(_0x282d2a.htmlFor) || _0x282d2a.closest('td,div,span')?.["querySelector"]("input[type=radio]") || _0x282d2a.parentElement?.["querySelector"]("input[type=radio]"), _0xdb554b = _0x1e6b7 && _0x1e6b7.name ? [..._0xb26068.querySelectorAll("input[type=radio]")].filter(_0x33dd51 => _0x33dd51.name === _0x1e6b7.name) : [], _0x246b09 = _0xdb554b.find(_0x43d3f5 => _0x43d3f5.checked);
                    if (_0x1e6b7 && _0x1e6b7.checked) {
                        _0x5b5599("Arama türü zaten Kullanıcı.");
                        return null;
                    }
                    _0x2c5bca(_0x282d2a);
                    if (_0x1e6b7 && !_0x1e6b7.checked) {
                        _0x2c5bca(_0x1e6b7);
                    }
                    const _0x421d20 = _0x1e6b7 && _0x1e6b7.closest(".ui-radiobutton");
                    if (_0x421d20 && _0x1e6b7 && !_0x1e6b7.checked) {
                        _0x2c5bca(_0x421d20);
                    }
                    await _0x4e51ef(0x76c);
                    _0x5b5599("Arama türü: Kullanıcı seçildi (radyo).");
                    return _0x246b09 && _0x246b09 !== _0x1e6b7 ? async () => {
                        const _0x58cd16 = _0xb26068.querySelector("label[for=\"" + _0x246b09.id + '\x22]');
                        _0x2c5bca(_0x58cd16 || _0x246b09);
                        if (!_0x246b09.checked) {
                            _0x2c5bca(_0x246b09);
                        }
                        await _0x4e51ef(0x384);
                    } : null;
                }
                const _0xa37e66 = [..._0xb26068.querySelectorAll("select")].find(_0x43d61b => _0xa0b831(_0x43d61b) && _0x4b97b2(_0x27a01e(_0x43d61b)) && [..._0x43d61b.options].some(_0x18d376 => _0x4a6600(_0x18d376.text)) && _0x43d61b !== _0x63ef33);
                if (_0xa37e66) {
                    const _0x1e27c4 = _0xa37e66.value, _0x151523 = [..._0xa37e66.options].find(_0x1b5eda => _0x4a6600(_0x1b5eda.text));
                    if (_0xa37e66.value === _0x151523.value) {
                        return null;
                    }
                    const _0x37f386 = _0xa37e66.closest('.ui-selectonemenu');
                    if (_0x37f386 && _0x30d46f(_0x37f386)) {
                        await _0x465985(_0x37f386, "Kullanıcı");
                    }
                    else {
                        _0xa37e66.value = _0x151523.value;
                        _0x2de811(_0xa37e66, "input");
                        _0x2de811(_0xa37e66, "change");
                    }
                    await _0x4e51ef(0x76c);
                    _0x5b5599("Arama türü: Kullanıcı seçildi (liste).");
                    return async () => {
                        const _0x49ce1e = [..._0xa37e66.options].find(_0x5416bb => _0x5416bb.value === _0x1e27c4);
                        if (_0x37f386 && _0x30d46f(_0x37f386) && _0x49ce1e) {
                            await _0x465985(_0x37f386, _0x49ce1e.text);
                        }
                        else {
                            _0xa37e66.value = _0x1e27c4;
                            _0x2de811(_0xa37e66, "change");
                        }
                        await _0x4e51ef(0x384);
                    };
                }
                const _0x3572ea = [..._0xb26068.querySelectorAll("a,button,li,.ui-button")].find(_0x4e1c97 => _0x30d46f(_0x4e1c97) && _0xa0b831(_0x4e1c97) && _0x4b97b2(_0x4e1c97) && _0x4a6600(_0x4e1c97.textContent));
                if (_0x3572ea) {
                    _0x2c5bca(_0x3572ea);
                    await _0x4e51ef(0x76c);
                    _0x5b5599("Arama türü: Kullanıcı seçildi (sekme).");
                    return null;
                }
                _0x5b5599("Geldiği Kişi yanında “Kullanıcı” seçeneği bulunamadı; TC doğrudan yazılıyor.", "err");
                return null;
            }
            async function _0x254500() {
                /* v3.6.75 — Gönderen kuralı: belgeden okunan isim en fazla GONDEREN_DENEME kez aranır;
                   bulunamazsa Ayarlar'daki varsayılan gönderen otomatik seçilir. Adım tekrar edilirse doğrudan varsayılana geçilir. */
                const GONDEREN_DENEME = 4;
                const varsayilan = String(_0x599e9b.gonderen || '').trim();
                const belgedeki = String(_0x5f03d4.item.gonderen || '').trim();
                if (!belgedeki && !varsayilan) {
                    throw new Error("Gönderen adı yok (Ayarlar → Gönderen / Müdür yardımcıları)");
                }
                await _0x5c5b76(() => _0xd17bf4("Geldiği Kişi"), 0x1f40);
                const ayniKisi = (x, y) => _0x3c029d(x) === _0x3c029d(y);
                // Bir ismi ara: önce TC (varsa), sonra ad terimleri; toplam deneme sayısı sınırlı
                const ara = async (ad, sinir) => {
                    const tc = _0x36ce29(ad);
                    const terimler = _0x6296a6(ad);
                    let kalan = sinir;
                    _0x5f03d4.tcHint = tc;
                    try {
                        if (tc && kalan > 0) {
                            kalan--;
                            _0x5b5599("Geldiği kişi TC ile aranıyor (…" + tc.slice(-0x4) + '), olmazsa adla.');
                            const geriAl = await _0x420cf4();
                            try {
                                await _0x423533("Geldiği Kişi", [tc], { 'list': true, 'exact': ad, 'prefer': [tc] });
                                return true;
                            } catch (e) {
                                if (e === "stop") throw e;
                                geriAl && (await geriAl(), _0x5b5599('Arama türü eski haline getirildi.'));
                                _0x5b5599("TC ile bulunamadı, adla aranıyor.", "err");
                            }
                        }
                        const liste = terimler.slice(0, Math.max(0, kalan));
                        if (!liste.length) return false;
                        try {
                            await _0x423533("Geldiği Kişi", liste, { 'list': true, 'exact': ad });
                            return true;
                        } catch (e) {
                            if (e === "stop") throw e;
                            return false;
                        }
                    } finally {
                        _0x5f03d4.tcHint = '';
                    }
                };
                let secilen = '';
                const belgeDenensin = belgedeki && !(varsayilan && ayniKisi(belgedeki, varsayilan)) && !_0x5f03d4.gonderenBelgeDenendi;
                if (belgeDenensin) {
                    _0x5f03d4.gonderenBelgeDenendi = true;   // adım tekrar edilirse belgedeki isim yeniden denenmez
                    if (await ara(belgedeki, GONDEREN_DENEME)) secilen = belgedeki;
                    else if (varsayilan) _0x5b5599('“' + belgedeki + '” ' + GONDEREN_DENEME + ' denemede bulunamadı → varsayılan gönderen seçiliyor: ' + varsayilan, 'err');
                    else throw new Error('“' + belgedeki + '” bulunamadı ve Ayarlar’da varsayılan gönderen yok');
                } else if (belgedeki && _0x5f03d4.gonderenBelgeDenendi && varsayilan && !ayniKisi(belgedeki, varsayilan)) {
                    _0x5b5599('Belgedeki gönderen daha önce bulunamadı → varsayılan gönderen: ' + varsayilan, 'err');
                }
                if (!secilen) {
                    const hedef = varsayilan || belgedeki;
                    if (!(await ara(hedef, GONDEREN_DENEME))) throw new Error('Geldiği kişi bulunamadı: ' + hedef + ' (Ayarlar → Gönderen adını EBYS’deki gibi yazın)');
                    secilen = hedef;
                }
                _0x5f03d4.gonderenPicked = _0x5f03d4.picked;
                _0x5b5599('Geldiği kişi seçildi: ' + (_0x5f03d4.picked || secilen) + (secilen !== belgedeki && belgedeki ? ' (varsayılan)' : ''), 'ok');
                await _0x517e1e();
            }
            function _0x3e6c44(_0x2d3f97) {
                const _0x12e9c8 = String(_0x2d3f97 || '').trim();
                if (!_0x12e9c8) {
                    return false;
                }
                if (/AutoComplete\s*=/.test(_0x12e9c8) || /PrimeFaces/.test(_0x12e9c8) || /<\/?script/i.test(_0x12e9c8)) {
                    return !false;
                }
                if (/\bfunction\s*\(|\bvar\s+\w|=>\s*\{/.test(_0x12e9c8)) {
                    return !false;
                }
                if (/dagitimBilgileri|LovText|widget\./i.test(_0x12e9c8)) {
                    return !false;
                }
                if (/^D\d+[A-Za-z].*=/.test(_0x12e9c8)) {
                    return !false;
                }
                if (/[=;{}]$/.test(_0x12e9c8) && /[A-Za-z]{6,}/.test(_0x12e9c8)) {
                    return !false;
                }
                return false;
            }
            function _0x316c76(_0x3c7081) {
                const _0x5cef14 = String(_0x3c7081 || '').trim();
                if (!_0x5cef14) {
                    return false;
                }
                if (/^\d{11}$/.test(_0x5cef14)) {
                    return !false;
                }
                if (/^E[-–]?\d/i.test(_0x5cef14)) {
                    return false;
                }
                if (/^\d{1,6}([\/\-.]\d{1,8})*$/.test(_0x5cef14)) {
                    return false;
                }
                return /[A-Za-zÇĞİÖŞÜçğıöşüÂâ]{3,}/.test(_0x5cef14) && !/^\d/.test(_0x5cef14);
            }
            function _0x3f5d3e(_0x5b7bbf) {
                const _0x32bd83 = String(_0x5b7bbf || '').trim();
                if (!_0x32bd83 || _0x32bd83.length > 0x50) {
                    return false;
                }
                if (_0x3e6c44(_0x32bd83) || _0x316c76(_0x32bd83)) {
                    return false;
                }
                return /^(E[-–]?\d[\w./-]{2,}|[\d][\dA-Za-z./-]{0,60})$/i.test(_0x32bd83);
            }
            function _0x500699(_0x3fa98b) {
                const _0x59abbc = String(_0x3fa98b || '').trim();
                if (!_0x59abbc || _0x59abbc.length < 0x3 || _0x59abbc.length > 0xb4) {
                    return false;
                }
                if (_0x3e6c44(_0x59abbc)) {
                    return false;
                }
                if (/[=;{}]/.test(_0x59abbc)) {
                    return false;
                }
                if (/AutoComplete|dagitimBilgileri|LovText|PrimeFaces/i.test(_0x59abbc)) {
                    return false;
                }
                return /[A-Za-zÇĞİÖŞÜçğıöşüÂâ]/.test(_0x59abbc);
            }
            function _0x22744b(_0x1b132c) {
                const _0x550e50 = _0x1b132c.findIndex(_0x81572b => /^sayi\b/.test(_0x3c029d(_0x81572b)));
                if (_0x550e50 < 0x0) {
                    return '';
                }
                let _0x4d0e80 = _0x1b132c[_0x550e50].replace(/^say[ıiİI]\s*:?\s*/i, '').trim();
                if (!_0x4d0e80 || /^sayi$/i.test(_0x3c029d(_0x4d0e80))) {
                    _0x4d0e80 = String(_0x1b132c[_0x550e50 + 0x1] || '').trim();
                }
                const _0x11b5bf = String(_0x4d0e80).match(/E[-–]?\d[\w./-]{2,80}|\d{1,6}(?:[\/\-.]\d{1,12})+/);
                if (_0x11b5bf && _0x3f5d3e(_0x11b5bf[0x0])) {
                    return _0x11b5bf[0x0];
                }
                return _0x3f5d3e(_0x4d0e80) ? _0x4d0e80 : '';
            }
            function _0x15ec55() {
                let _unused_jxnc;
                for (const _0x12efae of _0x52dd5d()) {
                    const _0x24d734 = [..._0x12efae.querySelectorAll("input,textarea")].find(_0x24bb65 => /evrakSayiTextAreaSolTam/i.test(_0x24bb65.id || _0x24bb65.name || ''));
                    if (_0x24d734 && _0x24d734.isConnected) {
                        return _0x24d734;
                    }
                }
                const _0x36d42e = _0xd17bf4("Evrak Sayı") || _0xd17bf4('Evrak Sayısı') || _0x1129fb("Evrak Sayı")[0x0];
                if (!_0x36d42e) {
                    return null;
                }
                const _0x160e84 = _0x520f6b(_0x36d42e);
                if (!_0x160e84) {
                    return null;
                }
                return _0x160e84.matches("input,textarea") ? _0x160e84 : _0x160e84.querySelector("input,textarea");
            }
            async function _0x517e1e() {
                const _0x1ba775 = _0x15ec55();
                if (!_0x1ba775) {
                    return;
                }
                const _0x252b6b = (_0x1ba775.value || '').trim();
                if (!_0x252b6b) {
                    return;
                }
                if (_0x3f5d3e(_0x252b6b)) {
                    return;
                }
                if (!_0x316c76(_0x252b6b) && !_0x3e6c44(_0x252b6b)) {
                    return;
                }
                _0x5b5599("Evrak Sayı alanındaki hatalı değer temizleniyor: “" + _0x252b6b.slice(0x0, 0x28) + '”', "err");
                _0x497585(_0x1ba775, '');
                _0x2de811(_0x1ba775, "input");
                _0x2de811(_0x1ba775, 'change');
                _0x3a4ac8(_0x1ba775, "keyup", '0');
                await _0x4e51ef(0x578);
            }
            async function _0x6507e6() {
                let _unused_stmr;
                await _0x517e1e();
                const _0x397218 = await _0x5c5b76(() => _0x15ec55(), 0x1f40).catch(() => null);
                if (!_0x397218) {
                    _0x5b5599("Evrak Sayı alanı bulunamadı — formu kontrol edin.", 'err');
                    _0x5f03d4.sayiDurum = "yok";
                    return;
                }
                await _0x4e51ef(0x578);
                let _0x28c2d5 = (_0x397218.value || '').trim();
                (_0x3e6c44(_0x28c2d5) || _0x316c76(_0x28c2d5)) && (_0x497585(_0x397218, ''), _0x2de811(_0x397218, "input"), _0x2de811(_0x397218, "change"), _0x28c2d5 = '');
                const _0x4d28d4 = String(_0x5f03d4.item.sayi || '').trim();
                if (_0x3f5d3e(_0x28c2d5)) {
                    _0x5f03d4.sayiDurum = 'ok';
                    _0x5b5599('Evrak Sayı duruyor: ' + _0x28c2d5, 'ok');
                    return;
                }
                if (_0x4d28d4 && _0x3f5d3e(_0x4d28d4)) {
                    const _0x137021 = _0x15ec55() || _0x397218;
                    await _0x5a1f35(_0x137021, _0x4d28d4, false);
                    await _0x4e51ef(0x640);
                    const _0x1142ba = _0x15ec55() || _0x137021;
                    _0x28c2d5 = (_0x1142ba.value || '').trim();
                    if (_0x3f5d3e(_0x28c2d5)) {
                        _0x5f03d4.sayiDurum = 'ok';
                        _0x5b5599('Evrak Sayı yazıldı: ' + _0x28c2d5, 'ok');
                        return;
                    }
                    _0x497585(_0x1142ba, '');
                    _0x2de811(_0x1142ba, "input");
                    _0x2de811(_0x1142ba, 'change');
                    throw new Error('Evrak Sayı yazılamadı (beklenen “' + _0x4d28d4 + '”, şu an “' + _0x28c2d5 + '”) — alanı kontrol edin');
                }
                _0x5f03d4.sayiDurum = "bos";
                _0x5b5599('Evrak Sayı boş; PDF’den güvenilir sayı çıkmadı. Kaydetmeden önce kontrol edin.', "err");
            }
            async function _0x3fe736(_0x2329f2) {
                let _unused_jrdu;
                await _0x4e51ef(0x5dc);
                try { await _0x115206(5000); } catch (e) { if (e === 'stop') throw e; }
                const tablo = EA_havaleTablodaVar();
                if (tablo) {
                    _0x5f03d4.havalePicked = _0x5f03d4.havalePicked || tablo;
                    _0x5b5599('Birime Havale doğrulandı: ' + tablo.slice(0, 70), 'ok');
                    return;
                }
                const _0x356fee = _0x569f58(), _0x5b5305 = (_0x356fee && _0x356fee.isConnected ? _0x356fee : null) || (_0x2329f2 && _0x2329f2.isConnected ? _0x2329f2 : null);
                if (!_0x5b5305) {
                    throw new Error("Birime Havale kutusu kayboldu — kontrol edin");
                }
                const _0x54b888 = (_0x5b5305.value || '').trim();
                if (_0x3e6c44(_0x54b888) || !_0x500699(_0x54b888)) {
                    _0x54b888 && (_0x497585(_0x5b5305, ''), _0x2de811(_0x5b5305, 'input'), _0x2de811(_0x5b5305, "change"), _0x3a4ac8(_0x5b5305, 'keyup', '0'));
                    throw new Error("Birime Havale geçersiz" + (_0x54b888 ? ' (“' + _0x54b888.slice(0x0, 0x30) + '”)' : " (boş)") + " — listeden birimi siz seçin");
                }
                _0x5f03d4.havalePicked = _0x5f03d4.havalePicked || _0x54b888;
                _0x5b5599("Birime Havale doğrulandı: " + _0x54b888.slice(0x0, 0x46), 'ok');
            }
            function _0x569f58() {
                let _unused_gqdq;
                for (const _0x147708 of _0x52dd5d()) {
                    const _0x365410 = [..._0x147708.querySelectorAll('input')].find(_0x295e15 => /dagitimBilgileriBirimLov:LovText$/i.test(_0x295e15.id || '') || /dagitimBilgileriBirimLov.*LovText/i.test(_0x295e15.id || ''));
                    if (_0x365410 && _0x365410.isConnected && _0x365410.type !== "hidden") {
                        return _0x365410;
                    }
                }
                const _0x5c8e76 = _0xd17bf4("Birime Havale");
                if (!_0x5c8e76) {
                    return null;
                }
                const _0x2a6273 = _0x520f6b(_0x5c8e76);
                if (!_0x2a6273) {
                    return null;
                }
                return _0x2a6273.matches('input') ? _0x2a6273 : _0x2a6273.querySelector('input:not([type=hidden])');
            }
            async function _0x400697(_0x24fdac, _0x9cf214) {
                const _0x31f70f = _0x24fdac.ownerDocument, _0x166f46 = _0x24fdac.getBoundingClientRect(), _0x390e4b = _0x47ae5f => {
                    const _0x2019ed = _0x47ae5f.getBoundingClientRect();
                    return Math.abs(_0x2019ed.top - _0x166f46.top) + Math.abs(_0x2019ed.left - _0x166f46.right) * 0.2;
                }, _0xe51c9c = [..._0x31f70f.querySelectorAll('button,a,.ui-button,.ui-icon,img,span[title]')].filter(_0x1f4e98 => _0x30d46f(_0x1f4e98) && _0x24fdac.compareDocumentPosition(_0x1f4e98) & Node.DOCUMENT_POSITION_FOLLOWING && !_0x24fdac.contains(_0x1f4e98) && _0x390e4b(_0x1f4e98) < 0xc8).sort((_0x5a0567, _0x5b1654) => _0x390e4b(_0x5a0567) - _0x390e4b(_0x5b1654)), _0x54f77c = _0xe51c9c.find(_0x434b1a => /agac|tree/.test(_0x3c029d((_0x434b1a.title || '') + ' ' + (_0x434b1a.getAttribute("aria-label") || '') + ' ' + (_0x434b1a.className || '')))) || _0xe51c9c[0x0];
                if (!_0x54f77c) {
                    throw new Error("Ağaç düğmesi bulunamadı");
                }
                _0x5b5599("Ağaç düğmesine tıklanıyor: " + _0x37c789(_0x54f77c));
                _0x2c5bca(_0x54f77c);
                await _0x4e51ef(0x4b0);
                const dugumler = () => [..._0x31f70f.querySelectorAll(".ui-treenode-label,.ui-treenode-content")].filter(_0x30d46f);
                const _0x459644 = await _0x5c5b76(() => { const d = dugumler(); return d.length ? d : null; }, 0x2710), _0x5e2613 = _0x3c029d(_0x9cf214 || '').split(' ').filter(_0x4fb42c => _0x4fb42c.length > 0x2 && !/^(ve|ile)$/.test(_0x4fb42c));
                await EA_listeBekle();
                const etiketMetni = el => _0x3c029d(((el.matches('.ui-treenode-label') ? el : el.querySelector('.ui-treenode-label')) || el).textContent);
                const enIyi = () => {
                    if (!_0x5e2613.length) return null;
                    let best = null, bp = 0;
                    for (const el of dugumler()) {
                        const t = etiketMetni(el), p = _0x5e2613.filter(w => t.includes(w)).length / _0x5e2613.length - Math.max(0, t.split(' ').length - _0x5e2613.length) * 0.01;
                        if (p > bp) { bp = p; best = el; }
                    }
                    return bp >= 0.75 ? best : null;
                };
                let _0x5e6087 = enIyi();
                // ağaçta arama kutusu varsa okul adını yaz
                if (!_0x5e6087) {
                    const filtre = [..._0x31f70f.querySelectorAll('.ui-tree-filter,input.ui-tree-filter,.ui-tree input[type=text]')].find(_0x30d46f);
                    if (filtre && _0x9cf214) {
                        _0x497585(filtre, _0x9cf214);
                        _0x2de811(filtre, 'input');
                        _0x3a4ac8(filtre, 'keyup', 'a');
                        await EA_listeBekle();
                        _0x5e6087 = enIyi();
                    }
                }
                // kapalı düğümleri açarak ara (en çok 4 tur)
                for (let tur = 0; !_0x5e6087 && tur < 4; tur++) {
                    const kapali = [..._0x31f70f.querySelectorAll('.ui-tree-toggler')].filter(t => _0x30d46f(t) && /triangle-1-e|caret-right|plus|chevron-right/.test(t.className) && !/triangle-1-s|caret-down|minus|chevron-down/.test(t.className)).slice(0, 25);
                    if (!kapali.length) break;
                    _0x5b5599('Ağaçta kapalı ' + kapali.length + ' düğüm açılıyor (tur ' + (tur + 1) + ')…');
                    for (const t of kapali) { _0x2c5bca(t); await _0x4e51ef(0xc8); }
                    await EA_listeBekle();
                    _0x5e6087 = enIyi();
                }
                if (!_0x5e6087) {
                    _0x5e6087 = dugumler().find(_0x42cd90 => _0x42cd90.closest(".ui-state-highlight,.ui-treenode-selected") || _0x42cd90.matches('.ui-state-highlight,.ui-treenode-selected'));
                }
                if (!_0x5e6087) {
                    throw new Error("Ağaçta okul düğümü bulunamadı (" + dugumler().length + ' düğüm var)');
                }
                _0x5b5599("Ağaç düğümüne tıklanıyor: " + _0x37c789(_0x5e6087));
                const havaleInp = () => _0x569f58();
                const oncekiDeger = (havaleInp() || {}).value || '';
                const tikHedef = _0x5e6087.matches('.ui-treenode-label') ? _0x5e6087 : (_0x5e6087.querySelector('.ui-treenode-label') || _0x5e6087);
                _0x2c5bca(tikHedef);
                await _0x4e51ef(0x384);
                try { await _0x115206(5000); } catch (e) { if (e === 'stop') throw e; }
                _0x5f03d4.picked = _0x5e6087.textContent.trim();
                if (_0x30d46f(tikHedef) && ((havaleInp() || {}).value || '') === oncekiDeger) {
                    // tek tık seçmediyse çift tıkla
                    tikHedef.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: tikHedef.ownerDocument.defaultView }));
                    await _0x4e51ef(0x384);
                    try { await _0x115206(5000); } catch (e) { if (e === 'stop') throw e; }
                }
                const _0x2164fc = _0x5e6087.closest('.ui-dialog,.ui-overlaypanel,[role=dialog]');
                if (_0x2164fc) {
                    const _0x1ff047 = [..._0x2164fc.querySelectorAll('button,a,.ui-button')].filter(_0x30d46f).find(_0x1d0a0a => ["sec", "tamam", 'uygula', 'onayla'].includes(_0x3c029d(_0x1d0a0a.value || _0x1d0a0a.textContent)));
                    _0x1ff047 && (_0x5b5599('Onay düğmesi: ' + _0x37c789(_0x1ff047)), _0x2c5bca(_0x1ff047));
                }
                await _0x4e51ef(0x2bc);
            }
            const _0x36db90 = _0x368bda => {
                let _unused_ok2y;
                let _0x37434b = _0x368bda;
                for (let _0x6fa97c = 0x0; _0x6fa97c < 0x4 && _0x37434b && _0x37434b.parentElement; _0x6fa97c++) {
                    _0x37434b = _0x37434b.parentElement;
                }
                return _0x37434b ? (_0x37434b.textContent + ' ' + [..._0x37434b.querySelectorAll("input")].map(_0x3b0b47 => _0x3b0b47.value).join(' ')).replace(/\s+/g, ' ') : '';
            }, _0x53a81d = _0x57e12f => {
                const _0x12b942 = /^(.*?M[uü]d[uü]rl[uü][gğ][uü])/i.exec((_0x57e12f || '').trim());
                return _0x12b942 ? _0x12b942[0x1].trim() : '';
            };
            async function _0x58d818() {
                const _0x2d97b4 = _0xd17bf4("Birime Havale"), _0x3cfc9a = _0x2d97b4 && _0x520f6b(_0x2d97b4), _0x2aae1b = _0x3cfc9a && (_0x3cfc9a.matches('input') ? _0x3cfc9a : _0x3cfc9a.querySelector("input:not([type=hidden])")), _0x4f0287 = _0x2aae1b ? _0x36db90(_0x2aae1b) : '';
                if (_0x3e6c44(_0x4f0287) || _0x3e6c44(_0x5f03d4.picked) || _0x3e6c44(_0x2aae1b && _0x2aae1b.value)) {
                    _0x5b5599("Havale bölgesinde betik sızıntısı görüldü; okul adı öğrenilmedi.", "err");
                    return;
                }
                const _0x34174a = _0x53a81d(_0x4f0287) || _0x53a81d(_0x5f03d4.picked) || (_0x500699(_0x2aae1b && _0x2aae1b.value) ? _0x53a81d(_0x2aae1b.value) : '');
                _0x34174a && !_0x3e6c44(_0x34174a) && !_0x599e9b.okul && (_0x599e9b.okul = _0x34174a, _0x381096(), _0x5b5599("Okul adı öğrenildi: " + _0x34174a, 'ok'));
            }
            async function _0x225887() {
                const _0x3892a5 = await _0x5c5b76(() => _0xd17bf4("Birime Havale"), 0x1f40), _0x1ef2ba = _0x520f6b(_0x3892a5), _0x289fb4 = _0x1ef2ba && (_0x1ef2ba.matches("input") ? _0x1ef2ba : _0x1ef2ba.querySelector("input:not([type=hidden])"));
                if (!_0x289fb4) {
                    throw new Error('Birime Havale kutusu bulunamadı');
                }
                (_0x3e6c44(_0x289fb4.value) || _0x289fb4.value && !_0x500699(_0x289fb4.value)) && (_0x5b5599("Birime Havale’deki şüpheli değer temizleniyor: “" + String(_0x289fb4.value).slice(0x0, 0x28) + '”', 'err'), _0x497585(_0x289fb4, ''), _0x2de811(_0x289fb4, "input"), _0x2de811(_0x289fb4, "change"), await _0x4e51ef(0x578));
                let _0x3b1e71 = (_0x5f03d4.item.havale || _0x599e9b.okul || '').trim();
                if (!_0x3b1e71) {
                    _0x3b1e71 = EA_okulSayfadan();
                    if (_0x3b1e71) _0x5b5599('Okul adı ayarlarda yok; sayfadan alındı: ' + _0x3b1e71, 'err');
                }
                if (_0x3b1e71 && _0x3e6c44(_0x3b1e71)) {
                    throw new Error('Havale hedefi geçersiz (ayar/öğrenme bozuk) — Ayarlar’dan okul adını düzeltin');
                }
                let _0x238470;
                const zatenVar = EA_havaleTablodaVar();
                if (zatenVar) {
                    _0x5f03d4.havalePicked = zatenVar;
                    _0x5b5599('Birime Havale zaten seçili: ' + zatenVar.slice(0, 70), 'ok');
                    return;
                }
                if (_0x3b1e71) {
                    const cekirdek = EA_okulCekirdek(_0x3b1e71);
                    const cekirdekIlsiz = EA_ilsiz(cekirdek);
                    // v3.6.69: önce yalnızca okulun adı (il/ilçe öneki olmadan), ilçeli ad yalnızca yedek
                    const prof = (await EA_depoAl(['ebys_okul_profil_v1'])).ebys_okul_profil_v1 || {};
                    const sadeAd = EA_sadeOkulAdi(cekirdek, prof);
                    const ilceli = EA_ilceliOkulAdi(sadeAd);
                    const yazilacak = [...new Set([(_0x599e9b.havaleAra || '').trim(), sadeAd, cekirdekIlsiz, ilceli].filter(Boolean))];
                    _0x5b5599('Birime Havale yazılacak: ' + yazilacak.map(x => '“' + x + '”').join(' / '));
                    for (const metin of yazilacak) {
                        try {
                            const inp = _0x569f58() || _0x289fb4;
                            _0x5b5599('Birime Havale’ye yazılıyor: “' + metin + '”');
                            await _0x5a1f35(inp, metin, !false, { 'must': sadeAd });
                            _0x5f03d4.havalePicked = _0x5f03d4.picked;
                            await _0x3fe736(inp);
                            if (!_0x599e9b.okul && _0x5f03d4.picked && _0x500699(_0x5f03d4.picked)) {
                                _0x599e9b.okul = _0x5f03d4.picked.replace(/\s+/g, ' ').trim();
                                _0x381096();
                                _0x5b5599('Okul adı öğrenildi: ' + _0x599e9b.okul, 'ok');
                            }
                            return;
                        }
                        catch (e) {
                            if (e === 'stop') throw e;
                            _0x238470 = e;
                            _0x5b5599('Havale “' + metin + '”: ' + (e.message || e), 'err');
                        }
                    }
                }
                if (_0x3b1e71) {
                    const _0x4c26c4 = _0x3b1e71.split(/\s+/), _0x538bd1 = _0x4c26c4.slice(0x0, Math.min(0x2, _0x4c26c4.length)).join(' ');
                    for (const _0x4b7a16 of [...new Set([_0x538bd1, _0x3b1e71])]) {
                        try {
                            await _0x5a1f35(_0x289fb4, _0x4b7a16, !false, { 'must': _0x3b1e71 });
                            _0x5f03d4.havalePicked = _0x5f03d4.picked;
                            await _0x3fe736(_0x289fb4);
                            await _0x58d818();
                            return;
                        }
                        catch (_0x2bd598) {
                            if (_0x2bd598 === "stop") {
                                throw _0x2bd598;
                            }
                            _0x238470 = _0x2bd598;
                            _0x5b5599("Havale araması “" + _0x4b7a16 + "”: " + (_0x2bd598.message || _0x2bd598), "err");
                        }
                    }
                }
                try {
                    await _0x5e08c1(_0x289fb4, _0x5f03d4.item.havaleKural ? '' : _0x3b1e71);
                    _0x5f03d4.havalePicked = _0x5f03d4.picked;
                    await _0x3fe736(_0x289fb4);
                    await _0x58d818();
                    return;
                }
                catch (_0x2c9b37) {
                    if (_0x2c9b37 === "stop") {
                        throw _0x2c9b37;
                    }
                    _0x238470 = _0x2c9b37;
                    _0x5b5599('Havale listesi: ' + (_0x2c9b37.message || _0x2c9b37), 'err');
                }
                try {
                    await _0x400697(_0x3892a5, _0x3b1e71);
                    _0x5f03d4.havalePicked = _0x5f03d4.picked;
                    await _0x3fe736(_0x569f58() || _0x289fb4);
                    await _0x58d818();
                    return;
                }
                catch (_0x245fcb) {
                    if (_0x245fcb === "stop") {
                        throw _0x245fcb;
                    }
                    _0x238470 = _0x245fcb;
                }
                throw _0x238470 || new Error("Birime Havale seçilemedi — listeden siz seçin");
            }
            const _0x4a765d = () => {
                const _0x21bf02 = new Date(), _0x524f19 = _0x34ca69 => String(_0x34ca69).padStart(0x2, '0');
                return _0x524f19(_0x21bf02.getDate()) + '.' + _0x524f19(_0x21bf02.getMonth() + 0x1) + '.' + _0x21bf02.getFullYear();
            }, _0x5eea6d = [["Menü: Gelen Evrak Kayıt", _0x57549f], ["Üst yazı ekle", _0x4c6de9], ["Konu kodu", _0x53afba, _0x14ec7], ['Konu (PDF başlığı)', _0x15fbb8], ["Evrak tarihi", () => _0x4010a5('Evrak Tarihi', _0x4a765d())], ["Kişi-Kurum", () => _0x4010a5("Kişi-Kurum", _0x599e9b.kisiKurum, { 'radio': !false })], ["Geldiği kişi", _0x254500], ["Evrak sayı", _0x6507e6], ["Geliş tipi", () => _0x4010a5('Geliş Tipi', _0x599e9b.gelisTipi, { 'radio': !false })], ["Kaldırılacak klasör", EA_klasorSec], ["Birime havale", _0x225887, _0x58d818], ["Kaydet ve numarayı oku", _0x565b1e]], _0x2b939b = /(\S+)\s+numaras[ıiİI]yla\s+kaydedilmi[şŞsS]tir/i;
            function _0x5bf94b() {
                const _0x164ae6 = _0x22e676 => (_0x3c029d(_0x22e676.id).includes("evrak") ? 0x2 : 0x0) + (_0x3c029d(_0x22e676.id).includes("kaydet") ? 0x1 : 0x0) - (_0x22e676.closest(".ui-dialog") ? 0x2 : 0x0), _0x5b19a0 = [];
                for (const _0x270a6c of _0x52dd5d()) {
                    _0x5b19a0.push(...[..._0x270a6c.querySelectorAll("button,a,input[type=button],input[type=submit],.ui-button")].filter(_0x30d46f).filter(_0x3301f0 => _0x3c029d(_0x3301f0.value || _0x3301f0.textContent) === "kaydet"));
                }
                return _0x5b19a0.sort((_0x46b644, _0x18a103) => _0x164ae6(_0x18a103) - _0x164ae6(_0x46b644));
            }
            function _0x20a6c7() {
                const _0x59238c = [];
                for (const _0x38e56f of _0x52dd5d()) {
                    _0x38e56f.querySelectorAll(".ui-messages,.ui-growl-message,.ui-message-error,.ui-messages-error,.ui-messages-warn,.ui-messages-fatal,.ui-state-error,.ui-dialog").forEach(_0x38553e => {
                        let _unused_p5lk;
                        if (!_0x30d46f(_0x38553e)) {
                            return;
                        }
                        const _0x4c2f08 = (_0x38553e.innerText || '').replace(/\s+/g, ' ').trim();
                        if (_0x4c2f08 && _0x4c2f08.length < 0x190 && !_0x2b939b.test(_0x4c2f08) && !_0x59238c.includes(_0x4c2f08)) {
                            _0x59238c.push(_0x4c2f08);
                        }
                    });
                }
                return _0x59238c;
            }
            function _0x6fe78d() {
                let _unused_2uhk;
                for (const _0x3ede93 of _0x52dd5d()) {
                    const _0xaeb668 = [..._0x3ede93.querySelectorAll(".ui-dialog,[role=dialog],.modal,.ui-overlaypanel")].filter(_0x30d46f).filter(_0x351657 => _0x3c029d(_0x351657.innerText || '').includes("benzer"));
                    if (_0xaeb668.length) {
                        return _0xaeb668[_0xaeb668.length - 0x1];
                    }
                }
                for (const _0x3fcd35 of _0x52dd5d()) {
                    if (_0x3fcd35.body && _0x3c029d(_0x3fcd35.body.innerText || '').includes("benzer kay")) {
                        return _0x3fcd35.body;
                    }
                }
                return null;
            }
            async function _0x20fe20(_0x200084) {
                const _0x11edfe = (_0x200084.innerText || '').replace(/\s+/g, ' ').trim();
                _0x5b5599("Benzer kayıt uyarısı: " + _0x11edfe.slice(0x0, 0x15e), "err");
                const _0x18a809 = [..._0x200084.querySelectorAll('button,a,input[type=button],input[type=submit],label,.ui-button,[role=button],[role=radio],[role=option]')].filter(_0x30d46f);
                _0x5b5599('Seçenekler: ' + _0x18a809.map(_0x37c789).join(" | ").slice(0x0, 0x1f4));
                const _0x153aa7 = _0x3eee60 => _0x3c029d(_0x3eee60.value || _0x3eee60.textContent), _0x4edcd2 = _0x2bc968 => !_0x2bc968.querySelector('button,a'), _0x19b0cb = ["sec", "devam", "tamam", "evet", "onayla", "kabul", "kaydet"];
                let _0x25b7c1 = _0x18a809.find(_0x1af5bb => /^benzer kay/.test(_0x153aa7(_0x1af5bb)) && _0x4edcd2(_0x1af5bb)) || _0x18a809.find(_0x40d4f2 => _0x153aa7(_0x40d4f2).includes("benzer") && _0x4edcd2(_0x40d4f2));
                if (!_0x25b7c1) {
                    const _0x1ba12d = [..._0x200084.querySelectorAll(".ui-datatable-data tr,input[type=radio],.ui-radiobutton-box,tbody tr")].filter(_0x30d46f)[0x0];
                    if (!_0x1ba12d) {
                        throw new Error("Benzer kayıt seçeneği bulunamadı");
                    }
                    _0x5b5599("Benzer kayıt satırı seçiliyor: " + _0x37c789(_0x1ba12d));
                    _0x2c5bca(_0x1ba12d);
                    await _0x4e51ef(0x2bc);
                    _0x25b7c1 = _0x18a809.find(_0x36de8c => _0x19b0cb.includes(_0x153aa7(_0x36de8c)));
                    if (!_0x25b7c1) {
                        throw new Error('Benzer kayıt onay düğmesi bulunamadı');
                    }
                }
                _0x5b5599("Benzer kayıt seçiliyor: " + _0x37c789(_0x25b7c1), 'ok');
                _0x2c5bca(_0x25b7c1);
                if (/^(label|input)$/i.test(_0x25b7c1.tagName) && !/button|submit/.test(_0x25b7c1.type || '')) {
                    await _0x4e51ef(0x2bc);
                    const _0x583c2d = _0x18a809.find(_0xc881c7 => _0x19b0cb.includes(_0x153aa7(_0xc881c7)) && _0xc881c7 !== _0x25b7c1);
                    _0x583c2d && (_0x5b5599("Onay düğmesi: " + _0x37c789(_0x583c2d)), _0x2c5bca(_0x583c2d));
                }
            }
            function _0x49c227() {
                let _unused_bt1m;
                try {
                    for (const _0x24b6d8 of _0x52dd5d()) {
                        const _0x2fe587 = _0x24b6d8.querySelector('#bekleyinizStatusDialog,.ui-blockui,.ui-dialog[aria-hidden=false] .ui-widget-overlay');
                        if (_0x2fe587 && _0x30d46f(_0x2fe587)) {
                            return !false;
                        }
                        if (_0x24b6d8.body && /lütfen bekleyiniz/i.test(_0x24b6d8.body.innerText || '')) {
                            const _0x394821 = [..._0x24b6d8.querySelectorAll(".ui-dialog,.ui-overlaypanel")].filter(_0x30d46f).find(_0x138b0e => /lütfen bekleyiniz/i.test(_0x138b0e.innerText || ''));
                            if (_0x394821) {
                                return !false;
                            }
                        }
                    }
                }
                catch (_0xcfef22) {
                }
                try {
                    if (window.jQuery && window.jQuery.active > 0x0) {
                        return !false;
                    }
                }
                catch (_0x5cc7bc) {
                }
                return false;
            }
            async function _0x115206(_0x8ad62e = 0x9c4) {
                const _0x85cea2 = Date.now();
                while (Date.now() - _0x85cea2 < _0x8ad62e) {
                    if (_0x228a28) {
                        throw "stop";
                    }
                    if (!_0x49c227()) {
                        await _0x4e51ef(0x190);
                        if (!_0x49c227()) {
                            return;
                        }
                    }
                    await _0x4e51ef(0x12c);
                }
            }
            function _0x5a1db6() {
                const _0x579152 = [], _0xec0420 = _0x15ec55(), _0x414b65 = _0xec0420 ? String(_0xec0420.value || '').trim() : '';
                if (!_0xec0420 || !_0x414b65) {
                    // v3.6.62: iç yazışmalarda (Kullanıcı) sayı olmayabilir → Kaydet'i engellemez
                    _0x5b5599('Evrak Sayı boş — Kaydet yine de yapılıyor.', 'err');
                }
                else {
                    if (false) {
                    }
                    else {
                        if (!_0x3f5d3e(_0x414b65)) {
                            _0x579152.push("Evrak Sayı geçersiz (“" + _0x414b65.slice(0x0, 0x28) + '”)');
                        }
                    }
                }
                const _0x578ec7 = _0x569f58(), _0x1b0a40 = _0x578ec7 ? String(_0x578ec7.value || '').trim() : '';
                if (EA_havaleTablodaVar()) {
                }
                else if (!_0x578ec7) {
                    _0x579152.push("Birime Havale kutusu yok");
                }
                else {
                    if (_0x3e6c44(_0x1b0a40) || !_0x500699(_0x1b0a40)) {
                        _0x579152.push("Birime Havale geçersiz" + (_0x1b0a40 ? " (“" + _0x1b0a40.slice(0x0, 0x28) + '”)' : " (boş/seçilmemiş)"));
                    }
                    else {
                        if (!_0x5f03d4.havalePicked && _0x1b0a40.length < 0x5) {
                            _0x579152.push('Birime Havale seçimi belirsiz');
                        }
                    }
                }
                const _0xa2416a = _0x14a98f(), _0x1283d7 = _0xa2416a ? String(_0xa2416a.value || '').trim() : '';
                if (!_0xa2416a || !_0x1283d7) {
                    _0x579152.push("Konu metni boş");
                }
                const _0x34df86 = _0x4d2a7f();
                if (!_0x34df86 || !_0x34df86.code) {
                    _0x579152.push("Konu kodu seçili değil / görünmüyor");
                }
                else {
                    if (_0x5f03d4.kod && !EA_KONU_KODU.ayniKod(_0x5f03d4.kod, _0x34df86.code)) {
                        _0x579152.push("Konu kodu uyuşmuyor (beklenen " + _0x5f03d4.kod + ', ekran ' + _0x34df86.code + ')');
                    }
                }
                if (_0x49c227()) {
                    _0x579152.push("AJAX/bekleyiniz sürüyor — form kararlı değil");
                }
                return _0x579152;
            }
            
            /* v3.7.2 — Kaydet durak / vurgu (mağaza) yardımcıları.
             * EA_OTOMATIK_KAYDET true: doğrulanmış formda Kaydet'e 1 kez basılır (kişisel 3.6.75 davranışı).
             * false: düğme vurgulanır, kullanıcının basması beklenir; eklenti Kaydet/Gönder/İmza/Paraf
             * ve kayıt sonrası Evet/Onayla/Tamam/Kapat diyaloglarına basmaz. */
            const EA_elleBeklemeSuresi = () => (typeof window !== "undefined" && window.__EA_TEST__ && window.__EA_TEST_OPTS__ && +window.__EA_TEST_OPTS__.manualWaitMs > 0) ? +window.__EA_TEST_OPTS__.manualWaitMs : 15 * 60 * 1000;
            const EA_sureYazi = ms => ms >= 60000 ? Math.round(ms / 60000) + " dk" : Math.round(ms / 1000) + " sn";
            const EA_elleBeklemeAraligi = () => (typeof window !== "undefined" && window.__EA_TEST__ && window.__EA_TEST_OPTS__ && +window.__EA_TEST_OPTS__.manualPollMs > 0) ? +window.__EA_TEST_OPTS__.manualPollMs : 300;
            function EA_yasakDugmeMi(el) {
                if (!el) return false;
                const t = _0x3c029d(el.value || el.textContent || "");
                const id = _0x3c029d(el.id || "");
                if (t === "kaydet" || id.includes("kaydet")) return "Kaydet";
                if (/^gonder|gonder$/.test(t) || id.includes("gonder")) return "Gönder";
                if (t.includes("imza") || id.includes("imza")) return "İmza";
                if (t.includes("paraf") || id.includes("paraf")) return "Paraf";
                return "";
            }
            function EA_vurgula(btn, not) {
                try {
                    const eski = btn.getAttribute("style");
                    btn.dataset.eaVurgu = "1";
                    btn.style.setProperty("outline", "4px solid #F59E0B", "important");
                    btn.style.setProperty("outline-offset", "3px", "important");
                    btn.style.setProperty("box-shadow", "0 0 0 8px rgba(245,158,11,.35)", "important");
                    try { btn.scrollIntoView({ block: "center" }); } catch (e) {}
                    const d = btn.ownerDocument;
                    const etiket = d.createElement("div");
                    etiket.className = "ea-kaydet-not";
                    etiket.setAttribute("role", "status");
                    etiket.textContent = "👉 " + not;
                    etiket.style.cssText = "position:fixed;z-index:2147483646;background:#F59E0B;color:#111827;font:700 12px 'Segoe UI',Arial,sans-serif;padding:4px 8px;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,.3);pointer-events:none;white-space:nowrap;left:0;top:0;";
                    (d.body || d.documentElement).appendChild(etiket);
                    const yerlestir = () => {
                        try {
                            const r = btn.getBoundingClientRect();
                            const vw = (d.defaultView && d.defaultView.innerWidth) || d.documentElement.clientWidth || 1024;
                            const vh = (d.defaultView && d.defaultView.innerHeight) || d.documentElement.clientHeight || 768;
                            const w = etiket.offsetWidth || 180, h = etiket.offsetHeight || 24;
                            let x = Math.max(4, Math.min(Math.round(r.right - w), vw - w - 4));
                            let y = Math.round(r.top - h - 10);
                            if (y < 4) y = Math.round(r.bottom + 10);
                            y = Math.max(4, Math.min(y, vh - h - 4));
                            etiket.style.left = x + "px";
                            etiket.style.top = y + "px";
                        } catch (e) {}
                    };
                    yerlestir();
                    const win = d.defaultView;
                    if (win) { win.addEventListener("scroll", yerlestir, true); win.addEventListener("resize", yerlestir); }
                    const zaman = setInterval(yerlestir, 500);
                    return () => {
                        try {
                            clearInterval(zaman);
                            if (win) { win.removeEventListener("scroll", yerlestir, true); win.removeEventListener("resize", yerlestir); }
                            etiket.remove();
                            delete btn.dataset.eaVurgu;
                            if (eski === null) btn.removeAttribute("style"); else btn.setAttribute("style", eski);
                        } catch (e) {}
                    };
                } catch (e) { return () => {}; }
            }
            async function EA_kullaniciKaydetBekle(btn, eskiNumara) {
                const sure = EA_elleBeklemeSuresi();
                const NOT = "Kontrol edip Kaydet’e siz basın";
                _0x5b5599("Form hazır (id=" + (btn && btn.id || "-") + "). " + NOT + " — eklenti Kaydet’e basmaz.", "ok");
                let basildi = false;
                const dinle = ev => {
                    if (!ev.isTrusted) return;
                    const hedef = ev.target && ev.target.closest && ev.target.closest("button,a,input[type=button],input[type=submit],.ui-button");
                    if (hedef && (hedef === btn || (_0x5bf94b() || []).includes(hedef))) basildi = true;
                };
                const belgeler = _0x52dd5d();
                belgeler.forEach(d => d.addEventListener("click", dinle, true));
                const kaldir = EA_vurgula(btn, NOT);
                const t0 = Date.now();
                try {
                    while (!basildi) {
                        if (_0x228a28) throw "stop";
                        const m = _0x4d6fb0().match(_0x2b939b);
                        if ((m && m[1] !== eskiNumara) || _0x6fe78d()) break;
                        if (Date.now() - t0 > sure) throw new Error("Kaydet’e basılmadı (" + EA_sureYazi(sure) + " beklendi) — kayıt yapılmadı");
                        await _0x4e51ef(EA_elleBeklemeAraligi());
                    }
                } finally {
                    belgeler.forEach(d => d.removeEventListener("click", dinle, true));
                    kaldir();
                }
                _0x5b5599("Kaydet’e siz bastınız; sonuç bekleniyor…", "ok");
            }

            async function _0x565b1e() {
                let _unused_gife;
                await _0x1e2aff();
                await _0x517e1e();
                await _0x115206(0xaf0);
                let _0x2687aa = _0x5a1db6();
                _0x2687aa.length && (await _0x115206(0x7d0), _0x2687aa = _0x5a1db6());
                if (_0x2687aa.length) {
                    throw new Error("Kaydet öncesi kontrol: " + _0x2687aa.join(" · ") + " — Kaydet’e basılmadı");
                }
                for (let _0x394dd1 = 0x0; _0x394dd1 < 0x3 && _0x2b939b.test(_0x4d6fb0()); _0x394dd1++) {
                    const _0x21ccdb = _0x4ef577("Tamam") || _0x4ef577("Kapat");
                    if (!_0x21ccdb) {
                        break;
                    }
                    if (typeof EA_OTOMATIK_KAYDET === "undefined" || EA_OTOMATIK_KAYDET) {
                        _0x2c5bca(_0x21ccdb);
                    }
                    await _0x4e51ef(0x320);
                }
                const _0x9e1a1d = (_0x4d6fb0().match(_0x2b939b) || [])[0x1] || '';
                if (_0x9e1a1d) {
                    _0x5b5599("Uyarı: ekranda eski kayıt mesajı duruyor (" + _0x9e1a1d + '). Yeni numara bundan farklı olmalı.', "err");
                }
                const _0x1f6498 = _0x4d2a7f(), _0x3e6c95 = _0x14a98f();
                _0x5b5599("Özet → Konu kodu: " + (_0x1f6498 ? _0x1f6498.title + ' [' + _0x1f6498.code + ']' : '?') + ' | Konu: ' + (_0x3e6c95 ? _0x3e6c95.value : '?') + ' | Geldiği kişi: ' + (_0x5f03d4.gonderenPicked || '?') + " | Havale: " + ((_0x5f03d4.havalePicked || (_0x569f58() || {}).value || '?') + '').slice(0x0, 0x46));
                const _0x2d25b7 = await _0x5c5b76(() => {
                    const _0x4a1457 = _0x5bf94b();
                    return _0x4a1457.length ? _0x4a1457 : null;
                }, 0x1770);
                if (_0x5f03d4._kaydetClicked) {
                    throw new Error("Kaydet zaten basıldı; ikinci kez basılmadı");
                }
                if (typeof EA_OTOMATIK_KAYDET !== "undefined" && !EA_OTOMATIK_KAYDET) {
                    await EA_kullaniciKaydetBekle(_0x2d25b7[0x0], _0x9e1a1d);
                    _0x5f03d4._kaydetClicked = !false;
                } else {
                    _0x5b5599("Kaydet düğmesine basılıyor (1 kez, id=" + (_0x2d25b7[0x0].id || '-') + ')');
                    _0x2c5bca(_0x2d25b7[0x0]);
                    _0x5f03d4._kaydetClicked = !false;
                }
                const _0x223c07 = Date.now(), _0x23e59c = new Set();
                for (;;) {
                    if (_0x228a28) {
                        throw 'stop';
                    }
                    const _0xd60752 = _0x4d6fb0().match(_0x2b939b);
                    if (_0xd60752 && _0xd60752[0x1] !== _0x9e1a1d && !_0x2a3361.some(_0x10c1ef => _0x10c1ef.numara === _0xd60752[0x1])) {
                        _0x5f03d4.numara = _0xd60752[0x1];
                        if (_0x5f03d4.benzerTried) {
                            _0x5f03d4.benzer = !false;
                        }
                        break;
                    }
                    const _0x37aa03 = _0x6fe78d();
                    if (_0x37aa03) {
                        if (!_0x5f03d4.benzerTried) {
                            _0x5f03d4.benzerTried = !false;
                            _0x5f03d4.benzerAt = Date.now();
                            try {
                                _0x2f2f4f.setItem(_0x250456, JSON.stringify({ 'key': _0x2eb48b(_0x5f03d4.item.file), 'dosya': _0x5f03d4.item.file.name, 'konu': _0x5f03d4.item.konu, 't': new Date().toTimeString().slice(0x0, 0x8) }));
                            }
                            catch (_0x7d844b) {
                            }
                            await _0x20fe20(_0x37aa03);
                            await _0x4e51ef(0x5dc);
                            continue;
                        }
                        if (Date.now() - _0x5f03d4.benzerAt > 0x2ee0) {
                            throw new Error("Benzer kayıt penceresi kapanmadı (seçim işlemedi)");
                        }
                        await _0x4e51ef(0x1f4);
                        continue;
                    }
                    if (_0x5f03d4.benzerTried) {
                        if (_0xb7ab79() && !_0x40cd39("Eklenen üst yazı")) {
                            _0x5f03d4.benzer = !false;
                            break;
                        }
                        if (Date.now() - _0x5f03d4.benzerAt > 0x61a8) {
                            _0x5f03d4.benzer = !false;
                            _0x5b5599("Benzer kayıt seçildi; yeni form doğrulanamadı, sonucu kontrol edin.", "err");
                            break;
                        }
                        await _0x4e51ef(0x1f4);
                        continue;
                    }
                    const _0x403637 = _0x20a6c7();
                    _0x403637.forEach(_0x112118 => {
                        let _unused_9xc2;
                        !_0x23e59c.has(_0x112118) && (_0x23e59c.add(_0x112118), _0x5b5599("Sayfa mesajı: " + _0x112118.slice(0x0, 0xc8), "err"));
                    });
                    const _0x336429 = _0x403637.filter(_0x4547e5 => !_0x3c029d(_0x4547e5).includes("benzer")).find(_0x255225 => /zorunlu|bos birak|gerekli|girilme|secilme|secmeli|giriniz|seciniz|eksik|gecersiz|hata|uyari/.test(_0x3c029d(_0x255225)));
                    if (_0x336429 && Date.now() - _0x223c07 > 0x1388) {
                        throw new Error("Sistem uyarısı: " + _0x336429.slice(0x0, 0xa0));
                    }
                    const _0x260685 = _0x4ef577("Evet") || _0x4ef577("Onayla");
                    if (_0x260685 && (typeof EA_OTOMATIK_KAYDET === "undefined" || EA_OTOMATIK_KAYDET)) {
                        _0x2c5bca(_0x260685);
                    }
                    if (Date.now() - _0x223c07 > 0xafc8) {
                        throw new Error("Yeni kayıt mesajı gelmedi" + (_0xd60752 ? " (ekranda yalnızca eski numara var: " + _0xd60752[0x1] + ')' : '') + ' — kayıt yapılmamış olabilir');
                    }
                    await _0x4e51ef(0x1f4);
                }
                try {
                    _0x2f2f4f.removeItem(_0x250456);
                }
                catch (_0x3ace03) {
                }
                _0x5b5599(_0x5f03d4.benzer ? "Benzer kayıt seçildi, evrak kaydı tamamlandı" + (_0x5f03d4.numara ? ': ' + _0x5f03d4.numara : '') : 'Evrak numarası: ' + _0x5f03d4.numara, 'ok');
                const _0x1f8428 = _0x5f03d4.benzer ? null : _0x4ef577("Tamam") || _0x4ef577("Kapat");
                if (_0x1f8428 && (typeof EA_OTOMATIK_KAYDET === "undefined" || EA_OTOMATIK_KAYDET)) {
                    _0x2c5bca(_0x1f8428);
                }
                await _0x4e51ef(0x320);
            }
            const _0x2dbded = _0x43c8a1 => /^[\d\s\-–.\/:]+$/.test(_0x43c8a1) || _0x43c8a1.length > 0x14 && new Set(_0x43c8a1.split(/\s+/)).size <= 0x2, _0x5af21e = /m[uü]d[uü]r|yard[iı]mc|[oö][gğ]retmen|rehber|[sş]ef|memur|ba[sş]kan|sube|şube/i;
            function _0x130875(_0x12396a) {
                const _0x25f6de = _0x12396a.slice(-0xc);
                for (let _0x40d32b = _0x25f6de.length - 0x1; _0x40d32b >= 0x0; _0x40d32b--) {
                    if (!_0x5af21e.test(_0x3c029d(_0x25f6de[_0x40d32b]).replace(/ /g, ' ')) && !_0x5af21e.test(_0x25f6de[_0x40d32b])) {
                        continue;
                    }
                    const _0x125be6 = _0x25f6de[_0x40d32b].replace(/\b\S*(m[uü]d[uü]r|yard[iı]mc|[oö][gğ]retmen|rehber)\S*/gi, '').replace(/[\[\]()]/g, '').trim(), _0x396a7f = _0x2c37fe => _0x2c37fe && /^[A-Za-zÇĞİÖŞÜçğıöşüÂâ.\s]{5,40}$/.test(_0x2c37fe) && _0x2c37fe.split(/\s+/).length >= 0x2 && _0x2c37fe.split(/\s+/).length <= 0x4;
                    if (_0x396a7f(_0x125be6)) {
                        return _0x125be6;
                    }
                    if (_0x40d32b > 0x0 && _0x396a7f(_0x25f6de[_0x40d32b - 0x1])) {
                        return _0x25f6de[_0x40d32b - 0x1];
                    }
                }
                return '';
            }
            function _0x2ee3a8(_0x113037) {
                const _0x7fda1f = _0x4ea448(), _0xbea9b0 = _0x113037.map(_0x3c029d), _0x425723 = _0xbea9b0.slice(-0xe).join(' '), _0x42ca82 = _0xbea9b0.join(' '), _0xf02ef = (_0x32a690, _0x167620) => {
                    const _0x323e40 = _0x3c029d(_0x167620).split(' ').filter(_0x192540 => _0x192540.length > 0x1);
                    return _0x323e40.length && _0x323e40.every(_0x3595ea => _0x32a690.includes(_0x3595ea));
                };
                for (const _0x10bac0 of _0x7fda1f) {
                    if (_0xf02ef(_0x425723, _0x10bac0)) {
                        return { 'ad': _0x10bac0, 'kaynak': 'imza/alt satırlar' };
                    }
                }
                for (const _0x49c05d of _0x7fda1f) {
                    if (_0xf02ef(_0x42ca82, _0x49c05d)) {
                        return { 'ad': _0x49c05d, 'kaynak': 'metin' };
                    }
                }
                let _0x5217a5 = null, _0x39c3df = 0x0;
                for (const _0x200467 of (_0x599e9b.gorevler || '').split('\x0a')) {
                    const _0x25ad93 = _0x200467.indexOf('=');
                    if (_0x25ad93 < 0x1) {
                        continue;
                    }
                    const _0x5dc4d4 = _0x200467.slice(_0x25ad93 + 0x1).split(',').map(_0x35f971 => _0x3c029d(_0x35f971)).filter(Boolean), _0x27acd5 = _0x5dc4d4.reduce((_0x419c93, _0x19209d) => _0x419c93 + (_0x42ca82.includes(_0x19209d) ? 0x1 : 0x0), 0x0);
                    _0x27acd5 > _0x39c3df && (_0x39c3df = _0x27acd5, _0x5217a5 = _0x200467.slice(0x0, _0x25ad93).trim());
                }
                if (_0x5217a5) {
                    return { 'ad': _0x5217a5, 'kaynak': "görev eşleşmesi" };
                }
                const _0x512ab3 = _0x130875(_0x113037);
                return _0x512ab3 ? { 'ad': _0x512ab3, 'kaynak': "alttaki isim (listede yok)" } : null;
            }
            function _0x2849ab(_0x126cdb, _0x1b256d) {
                const _0x432c1d = _0x126cdb.split('\x0a').map(_0x1d7799 => _0x1d7799.trim()).filter(_0x59dcd5 => _0x59dcd5 && !_0x2dbded(_0x59dcd5)), _0x4f555a = _0x3c029d(_0x126cdb);
                let _0x34683c = '', _0x54b7b4 = '';
                const _0x11b3b5 = _0x432c1d.findIndex(_0x4b108 => /^konu(su)?\b/.test(_0x3c029d(_0x4b108)) && (_0x4b108.includes(':') || _0x3c029d(_0x4b108).length > 0x6));
                if (_0x11b3b5 >= 0x0) {
                    _0x34683c = _0x432c1d[_0x11b3b5].replace(/^\S+\s*:?\s*/, '').trim();
                    const _0x56ca51 = _0x432c1d[_0x11b3b5 + 0x1] || '';
                    if (!_0x34683c && _0x56ca51) {
                        _0x34683c = _0x56ca51;
                    }
                    else {
                        if (_0x56ca51 && /^[a-zçğıöşü]/.test(_0x56ca51) && !/[.!]$/.test(_0x34683c)) {
                            _0x34683c += ' ' + _0x56ca51;
                        }
                    }
                    _0x54b7b4 = _0x432c1d.slice(_0x11b3b5 + 0x1, _0x11b3b5 + 0x4).filter(_0x56983f => !/^(sayi|ilgi|tarih)/.test(_0x3c029d(_0x56983f))).slice(0x0, 0x2).join(" / ");
                }
                else {
                    const _0x54a200 = _0x432c1d.find(_0x41fa31 => _0x41fa31.split(/\s+/).length >= 0x2 && _0x41fa31.length >= 0x8 && !/^(t\.?c\.?|sayi|tarih|ilgi)\b|valilig|kaymakamlig|mudurlug|^sayfa/.test(_0x3c029d(_0x41fa31)));
                    if (_0x54a200) {
                        _0x34683c = _0x54a200.slice(0x0, 0x5a);
                    }
                }
                const _0x553203 = _0x432c1d.findIndex(_0x30f0e6 => /^sayi\b/.test(_0x3c029d(_0x30f0e6))), _0x47ed12 = _0x432c1d.slice(0x0, _0x553203 > 0x0 ? Math.min(_0x553203, 0x5) : 0x3).join(' '), _0x52e27e = _0x22744b(_0x432c1d), _0x1b607e = _0x2ee3a8(_0x432c1d);
                let _0x2b7be1 = '';
                for (const _0xdfee4d of (_0x599e9b.havaleRules || '').split('\x0a')) {
                    const _0x36f40c = _0xdfee4d.indexOf('=');
                    if (_0x36f40c > 0x0 && _0x4f555a.includes(_0x3c029d(_0xdfee4d.slice(0x0, _0x36f40c).trim()))) {
                        _0x2b7be1 = _0xdfee4d.slice(_0x36f40c + 0x1).trim();
                        break;
                    }
                }
                if (_0x2b7be1 && _0x3e6c44(_0x2b7be1)) {
                    _0x2b7be1 = '';
                }
                const EA_dosyaKonu = EA_KONU_KODU.dosyaAdiKonu(_0x1b256d);
                return { 'konu': EA_dosyaKonu || _0x34683c || _0x1b256d.replace(_0x54cf10, '').replace(/[_\-]+/g, ' ').trim(), 'konuBulundu': !!(EA_dosyaKonu || _0x34683c), 'konuKaynak': EA_dosyaKonu ? 'dosya adı' : _0x34683c ? 'PDF başlığı' : 'dosya adı (tahmin)', 'pdfKonu': _0x34683c, 'gonderen': _0x1b607e && _0x1b607e.ad || _0x599e9b.gonderen, 'gonderenKaynak': _0x1b607e ? _0x1b607e.kaynak : "varsayılan", 'havale': _0x2b7be1 || _0x599e9b.okul, 'havaleKural': !!_0x2b7be1, 'sayi': _0x52e27e, 'kurum': _0x47ed12, 'muhatap': _0x54b7b4, 'imza': _0x130875(_0x432c1d), 'okundu': !!_0x126cdb.trim() };
            }
            const _0x3f60a2 = _0x3fe405 => String(_0x3fe405).padStart(0x2, '0'), _0x166b33 = _0x325003 => _0x325003.getFullYear() + '-' + _0x3f60a2(_0x325003.getMonth() + 0x1) + '-' + _0x3f60a2(_0x325003.getDate()), _0x2eb48b = _0x1f8bd6 => _0x1f8bd6.name + '|' + _0x1f8bd6.size + '|' + _0x1f8bd6.lastModified;
            function _0x513eef(_0x529063) {
                let _unused_5tgi;
                let _0x5f2b3f;
                if (_0x5f2b3f = /^(\d{4})[-._](\d{1,2})[-._](\d{1,2})$/.exec(_0x529063)) {
                    return _0x5f2b3f[0x1] + '-' + _0x3f60a2(_0x5f2b3f[0x2]) + '-' + _0x3f60a2(_0x5f2b3f[0x3]);
                }
                if (_0x5f2b3f = /^(\d{1,2})[-._ ](\d{1,2})[-._ ](\d{4})$/.exec(_0x529063)) {
                    return _0x5f2b3f[0x3] + '-' + _0x3f60a2(_0x5f2b3f[0x2]) + '-' + _0x3f60a2(_0x5f2b3f[0x1]);
                }
                if (_0x5f2b3f = /^(\d{2})(\d{2})(\d{4})$/.exec(_0x529063)) {
                    return _0x5f2b3f[0x3] + '-' + _0x5f2b3f[0x2] + '-' + _0x5f2b3f[0x1];
                }
                return '';
            }
            async function _0x3d484b(_0x13d01, _0x81eaa1) {
                const _0x3de416 = [];
                for await (const [_0x54ffde, _0x248f3f] of _0x13d01.entries()) {
                    if (_0x248f3f.kind === "file" && _0x54cf10.test(_0x54ffde)) {
                        const _0x3ac350 = await _0x248f3f.getFile();
                        if (_0x166b33(new Date(_0x3ac350.lastModified)) === _0x81eaa1) {
                            _0x3de416.push(_0x3ac350);
                        }
                    }
                    else {
                        if (_0x248f3f.kind === 'directory' && _0x513eef(_0x54ffde) === _0x81eaa1) {
                            for await (const [_0x1314c1, _0xbe2925] of _0x248f3f.entries()) {
                                if (_0xbe2925.kind === "file" && _0x54cf10.test(_0x1314c1)) {
                                    _0x3de416.push(await _0xbe2925.getFile());
                                }
                            }
                        }
                    }
                }
                return _0x3de416.sort((_0x172611, _0x447dcc) => _0x172611.lastModified - _0x447dcc.lastModified || _0x172611.name.localeCompare(_0x447dcc.name, 'tr', { 'numeric': !false }));
            }
            const _0x8a5ae1 = _0x5b6a2d => _0x2a3361.find(_0x437f54 => _0x437f54.key === _0x2eb48b(_0x5b6a2d) || !_0x437f54.key && _0x437f54.numara && _0x437f54.dosya === _0x5b6a2d.name && _0x437f54.tarih === _0x4a765d()), _0x4e6ff2 = { 'open': () => new Promise((_0x480a85, _0x1c8951) => {
                    const _0x3f8c03 = indexedDB.open("evrakOtonom", 0x1);
                    _0x3f8c03.onupgradeneeded = () => _0x3f8c03.result.createObjectStore('h');
                    _0x3f8c03.onsuccess = () => _0x480a85(_0x3f8c03.result);
                    _0x3f8c03.onerror = () => _0x1c8951(_0x3f8c03.error);
                }), async 'get'(_0x4f69e4) {
                    const _0x2f2e3f = await this.open();
                    return new Promise((_0x50d304, _0x195c54) => {
                        const _0x27aa84 = _0x2f2e3f.transaction('h').objectStore('h').get(_0x4f69e4);
                        _0x27aa84.onsuccess = () => _0x50d304(_0x27aa84.result);
                        _0x27aa84.onerror = () => _0x195c54(_0x27aa84.error);
                    });
                }, async 'set'(_0x3b0fa6, _0x1dbbfc) {
                    const _0x5ac8b4 = await this.open();
                    return new Promise((_0x9bba65, _0x3f2ee6) => {
                        const _0x5098fd = _0x5ac8b4.transaction('h', 'readwrite');
                        _0x5098fd.objectStore('h').put(_0x1dbbfc, _0x3b0fa6);
                        _0x5098fd.oncomplete = () => _0x9bba65();
                        _0x5098fd.onerror = () => _0x3f2ee6(_0x5098fd.error);
                    });
                } };
            function _0x4dc920() {
                const _0x26042b = _0x188591('#otoDir');
                if (_0x26042b) {
                    _0x26042b.textContent = _0x4f3a1d ? "📁 " + _0x4f3a1d.name : 'Klasör seçilmedi';
                }
            }
            async function _0x1a6f14() {
                let _unused_l8n9;
                try {
                    _0x4f3a1d = await window.showDirectoryPicker({ 'mode': "readwrite" });
                    try {
                        await _0x4e6ff2.set("dir", _0x4f3a1d);
                    }
                    catch (_0x3005e1) {
                    }
                    _0x5b5599('Klasör seçildi: ' + _0x4f3a1d.name, 'ok');
                }
                catch (_0x50b6ef) {
                    _0x5b5599("Klasör seçilmedi.", "err");
                }
                _0x4dc920();
            }
            function _0x2e625a(_0x1c7113) {
                const _0x50dfb1 = _0x188591("#oto_go"), _0x4cbce9 = _0x188591("#oto_cancel");
                if (!_0x50dfb1) {
                    return;
                }
                _0x50dfb1.textContent = _0x1c7113 ? "▶ Kaldığı yerden devam et" : "⚡ EVRAK KAYIT — klasördeki bugünkü PDF/JPEG'leri sırayla kaydet";
                if (_0x4cbce9) {
                    _0x4cbce9.hidden = !_0x1c7113;
                }
                if (_0x1c7113) {
                    _0x566c81("Devam için tıklayın", 'warn');
                }
            }
            async function _0x2c4193(_0x24a913 = {}) {
                let _unused_qoik;
                if (_0x9156cd) {
                    return;
                }
                try {
                    if (!_0x4f3a1d) {
                        await _0x1a6f14();
                        if (!_0x4f3a1d) {
                            return;
                        }
                    }
                    let _0x45fd81 = await _0x4f3a1d.queryPermission({ 'mode': "readwrite" });
                    if (_0x45fd81 !== 'granted') {
                        if (_0x24a913.resume) {
                            _0x2e625a(!false);
                            _0x370e01(!false);
                            _0x5b5599("Yarım kalan toplu işlem var. İzin için “▶ Kaldığı yerden devam et” düğmesine basın.", "err");
                            return;
                        }
                        _0x45fd81 = await _0x4f3a1d.requestPermission({ 'mode': "readwrite" });
                    }
                    if (_0x45fd81 !== 'granted') {
                        return _0x5b5599("Klasör izni verilmedi.", "err");
                    }
                    const _0xba3e1f = _0x4b8741(_0x5497e8), _0x4ca5a6 = _0x24a913.iso || _0xba3e1f && _0xba3e1f.active && _0xba3e1f.iso || _0x188591("#otoTarih").value || _0x166b33(new Date()), _0x544513 = await _0x3d484b(_0x4f3a1d, _0x4ca5a6), _0x3c3d06 = _0x544513.filter(_0x57f388 => _0x8a5ae1(_0x57f388)), _0x47baa6 = _0x544513.filter(_0x2b5401 => !_0x8a5ae1(_0x2b5401) && !_0x47a824.some(_0x3a966e => _0x2eb48b(_0x3a966e.file) === _0x2eb48b(_0x2b5401))), _0x2f6794 = _0x3c3d06.filter(_0x5c7f8e => {
                        const _0x542ca0 = _0x8a5ae1(_0x5c7f8e);
                        return _0x542ca0 && !_0x542ca0.numara;
                    });
                    _0x5b5599('“' + _0x4f3a1d.name + "” klasöründe " + _0x4ca5a6 + " tarihli " + _0x544513.length + ' PDF var: ' + _0x47baa6.length + " yeni, " + _0x3c3d06.length + " daha önce işlenmiş.", _0x47baa6.length ? 'ok' : "err");
                    if (_0x2f6794.length) {
                        _0x5b5599("Dikkat: önceden hata/atlama olan " + _0x2f6794.length + " evrak otomatik tekrarlanmadı (çift kayıt olmasın): " + _0x2f6794.map(_0x47cd40 => _0x47cd40.name).join(', '), 'err');
                    }
                    _0x2e625a(false);
                    if (!_0x47baa6.length && !_0x47a824.some(_0x1cb8dc => _0x1cb8dc.status !== "done" && _0x1cb8dc.status !== 'atla')) {
                        try {
                            _0x2f2f4f.removeItem(_0x5497e8);
                        }
                        catch (_0x3bc884) {
                        }
                        return;
                    }
                    try {
                        _0x2f2f4f.setItem(_0x5497e8, JSON.stringify({ 'active': !false, 'iso': _0x4ca5a6, 'name': _0x4f3a1d.name }));
                    }
                    catch (_0xf7b657) {
                    }
                    for (const _0xeb9e2f of _0x47baa6) {
                        await _0x5dd507(_0xeb9e2f);
                    }
                    await _0x3b48c9({ 'skipEmpty': !false });
                }
                catch (_0x278967) {
                    _0x5b5599('Otomatik başlatma: ' + (_0x278967.message || _0x278967), "err");
                }
            }
            async function _0x5dd507(_0x1d5cd4) {
                const _0xc6120d = { 'file': _0x1d5cd4, 'konu': _0x1d5cd4.name.replace(_0x54cf10, '').replace(/[_\-]+/g, ' ').trim(), 'gonderen': _0x599e9b.gonderen, 'havale': _0x599e9b.okul, 'text': '', 'status': "oku" };
                _0x47a824.push(_0xc6120d);
                _0x225457();
                try {
                    _0xc6120d.text = _0xce9cc1.test(_0x1d5cd4.name) ? '' : await _0x4e4a23(await _0x1d5cd4.arrayBuffer());
                    // v3.6.65: taranmış PDF / fotoğraf → bilgisayarda OCR (Türkçe, çevrimdışı)
                    if (String(_0xc6120d.text || '').replace(/\s+/g, '').length < 40 && _0x599e9b.ocr !== false) {
                        try {
                            _0x5b5599(_0x1d5cd4.name + ': metin yok, OCR ile okunuyor (ilk ve son sayfa)…');
                            const o = await EA_ocrMetin(_0x1d5cd4);
                            if (o && o.metin && o.metin.replace(/\s+/g, '').length >= 20) {
                                _0xc6120d.text = o.metin;
                                _0xc6120d.ocr = !false;
                                _0x5b5599(_0x1d5cd4.name + ': OCR tamam (' + o.sayfa.join(',') + '. sayfa / ' + o.toplam + ', güven %' + o.guven + ', ' + Math.round(o.sure / 1000) + ' sn)', 'ok');
                            } else {
                                _0x5b5599(_0x1d5cd4.name + ': OCR metin bulamadı' + (o && o.hata ? ' — ' + o.hata : ''), 'err');
                            }
                        } catch (e) {
                            _0x5b5599(_0x1d5cd4.name + ': OCR çalışmadı — ' + (e.message || e), 'err');
                        }
                    }
                    const _0x1de1a6 = _0x2849ab(_0xc6120d.text, _0x1d5cd4.name);
                    Object.assign(_0xc6120d, { 'konu': _0x1de1a6.konu, 'pdfKonu': _0x1de1a6.pdfKonu || '', 'gonderen': _0x1de1a6.gonderen, 'havale': _0x1de1a6.havale, 'havaleKural': _0x1de1a6.havaleKural, 'sayi': _0x1de1a6.sayi || '' });
                    _0x5b5599(_0x1d5cd4.name + ': ' + (_0xc6120d.ocr ? "OCR ile okundu" : _0x1de1a6.okundu ? "PDF okundu" : "PDF’den metin çıkmadı (taranmış olabilir)") + " | Konu: " + _0x1de1a6.konu + " (" + _0x1de1a6.konuKaynak + ")" + " | Sayı: " + (_0x1de1a6.sayi || '—') + " | Geldiği kişi: " + (_0x1de1a6.gonderen || '—') + ' (' + _0x1de1a6.gonderenKaynak + ')' + (_0x1de1a6.imza ? " | Alttaki isim: " + _0x1de1a6.imza : '') + (_0x1de1a6.muhatap ? " | Nereye: " + _0x1de1a6.muhatap.slice(0x0, 0x46) : ''), _0x1de1a6.okundu ? 'ok' : "err");
                }
                catch (_0x57088c) {
                    _0x5b5599("PDF okunamadı: " + _0x1d5cd4.name + " — " + _0x57088c.message, "err");
                }
                _0xc6120d.status = '';
                _0x225457();
            }
            let _0x228a28 = false, _0x9156cd = false, _0x317a4d = null;
            const _0x47a824 = [];
            let _0x4f3a1d = null;
            const _0x4ac4b6 = _0x2483c0 + ".log", _0x477b1d = _0x2483c0 + ".run", _0x5497e8 = _0x2483c0 + '.auto', _0x250456 = _0x2483c0 + ".pend", _0x55b20f = ((() => {
                let _unused_9b08;
                try {
                    return JSON.parse(_0x2f2f4f.getItem(_0x4ac4b6)) || [];
                }
                catch (_0x290534) {
                    return [];
                }
            })()), _0x50dc69 = (_0x13d2c5, _0x4e78c7, _0x54f18b, _0x15bf01) => {
                let _unused_xcte;
                try {
                    if (_0x13d2c5) {
                        _0x2f2f4f.setItem(_0x477b1d, JSON.stringify({ 'dosya': _0x13d2c5, 'adim': _0x4e78c7, 'key': _0x54f18b || '', 'konu': _0x15bf01 || '', 't': new Date().toTimeString().slice(0x0, 0x8) }));
                    }
                    else {
                        _0x2f2f4f.removeItem(_0x477b1d);
                    }
                }
                catch (_0x2986a0) {
                }
            };
            function _0x182600(_0x5b1632) {
                let _unused_glrv;
                _0x566c81("Sizi bekliyor", "warn");
                return new Promise(_0x580e9 => {
                    let _unused_os89;
                    _0x317a4d = _0x580e9;
                    _0x188591("#act").style.display = "flex";
                    _0x188591("#actTxt").textContent = '“' + _0x5b1632 + "” adımı yapılamadı. Elle düzeltip seçin:";
                });
            }
            async function _0x2679b2(_0x537cd3, _0x6f1525, _0x1ef922) {
                let _unused_xs4w;
                let _0x48825a = 0x0;
                for (;;) {
                    if (_0x228a28) {
                        throw "stop";
                    }
                    try {
                        _0x5b5599('▶ ' + _0x537cd3);
                        await _0x6f1525();
                        _0x5b5599('✔ ' + _0x537cd3, 'ok');
                        if (/konu kodu|geldiği kişi|klasör|havale/i.test(_0x537cd3)) {
                            await _0x4e51ef(0x7d0);
                        }
                        else {
                            // hızlı adım: yalnızca AJAX bitsin, 0,3 sn yeter
                            try { await _0x115206(3000); } catch (e) { if (e === 'stop') throw e; }
                            await EA_uyku(300);
                        }
                        return;
                    }
                    catch (_0x431890) {
                        if (_0x431890 === 'stop') {
                            throw _0x431890;
                        }
                        _0x5b5599('✖ ' + _0x537cd3 + ': ' + (_0x431890.message || _0x431890), "err");
                        if (++_0x48825a < 0x2) {
                            await _0x4e51ef(0x5dc);
                            continue;
                        }
                        const _0xcb02db = await _0x182600(_0x537cd3);
                        _0x188591('#act').style.display = 'none';
                        _0x566c81("Çalışıyor", "run");
                        if (_0xcb02db === "retry") {
                            _0x48825a = 0x0;
                            continue;
                        }
                        if (_0xcb02db === "skip") {
                            if (_0x1ef922) {
                                try {
                                    await _0x1ef922();
                                }
                                catch (_0x3c1504) {
                                }
                            }
                            return;
                        }
                        if (_0xcb02db === 'next') {
                            throw "next";
                        }
                        throw "stop";
                    }
                }
            }
            function _0x5a56d3(_0x20fda0, _0x5d1e00, _0x1ac22d) {
                let _unused_oqv7;
                _0x2a3361.push({ 'numara': _0x5d1e00 || '', 'konu': _0x20fda0.konu, 'dosya': _0x20fda0.file.name, 'key': _0x2eb48b(_0x20fda0.file), 'tarih': _0x4a765d(), 'saat': new Date().toTimeString().slice(0x0, 0x5), 'durum': _0x1ac22d });
                _0x381096();
                _0x4fe213();
            }
            async function _0x3b48c9(_0x114275 = {}) {
                let _unused_okno;
                if (_0x9156cd) {
                    return;
                }
                if (!(await EA_uzakIzin())) {
                    return;
                }
                let _0x3ddab1 = _0x47a824.filter(_0x3d41c8 => _0x3d41c8.status !== "done" && _0x3d41c8.status !== "atla");
                if (!_0x3ddab1.length) {
                    return _0x5b5599("Kuyruk boş: önce PDF seçin.", 'err');
                }
                const _0x83e568 = _0x3ddab1.filter(_0x3ab0dd => !_0x3ab0dd.gonderen).map(_0x5eb6ac => _0x5eb6ac.file.name);
                if (_0x83e568.length) {
                    if (!_0x114275.skipEmpty) {
                        return _0x5b5599("Geldiği kişi boş: " + _0x83e568.join(', ') + " — satırdan seçin veya Ayarlar’dan varsayılan yazın.", 'err');
                    }
                    _0x5b5599('Geldiği kişisi belli olmayan ' + _0x83e568.length + ' evrak atlandı (satırdan seçip tekrar başlatın): ' + _0x83e568.join(', '), 'err');
                    _0x3ddab1 = _0x3ddab1.filter(_0x5c28c8 => _0x5c28c8.gonderen);
                    if (!_0x3ddab1.length) {
                        return;
                    }
                }
                _0x9156cd = !false;
                _0x228a28 = false;
                _0xa4127a(!false);
                let _0x15b07a = '', _0x5cfc06 = null, _0x4edd46 = 0x0, _0x5627d8 = 0x0, _0x288f1f = 0x0;
                try {
                    for (_0x5cfc06 of _0x3ddab1) {
                        _0x5f03d4 = { 'item': _0x5cfc06, 'index': _0x288f1f++ };
                        _0x5cfc06.status = 'run';
                        _0x225457();
                        _0x5b5599('═══ ' + _0x5cfc06.file.name + ' (' + _0x288f1f + '/' + _0x3ddab1.length + ") ═══");
                        _0xef2233 = {};
                        _0x49423a();
                        let _0x28d17a = false;
                        try {
                            for (const [_0x4b2665, _0x28b29e, _0x512208] of _0x5eea6d) {
                                _0x15b07a = _0x4b2665;
                                _0x50dc69(_0x5cfc06.file.name, _0x4b2665, _0x2eb48b(_0x5cfc06.file), _0x5cfc06.konu);
                                _0xef2233[_0x4b2665] = "run";
                                _0x49423a();
                                _0x566c81("Çalışıyor — " + _0x4b2665, 'run');
                                try {
                                    await _0x2679b2(_0x4b2665, _0x28b29e, _0x512208);
                                    _0xef2233[_0x4b2665] = 'ok';
                                }
                                catch (_0x2e894c) {
                                    _0xef2233[_0x4b2665] = "err";
                                    _0x49423a();
                                    throw _0x2e894c;
                                }
                                _0x49423a();
                            }
                        }
                        catch (_0x4aea50) {
                            if (_0x4aea50 === "next") {
                                _0x28d17a = !false;
                            }
                            else {
                                throw _0x4aea50;
                            }
                        }
                        if (_0x28d17a) {
                            _0x5cfc06.status = "atla";
                            _0x5627d8++;
                            _0x5a56d3(_0x5cfc06, _0x5f03d4.numara, "Atlandı: " + _0x15b07a + " adımında — KAYDEDİLMEMİŞ OLABİLİR");
                            _0x225457();
                            await _0x4cef66(false);
                            _0x5cfc06 = null;
                            continue;
                        }
                        _0x5cfc06.status = "done";
                        _0x4edd46++;
                        _0x5a56d3(_0x5cfc06, _0x5f03d4.numara, _0x5f03d4.benzer ? "Kaydedildi (benzer kayıt seçildi)" + (_0x5f03d4.numara ? '' : " — numara okunamadı") : _0x5f03d4.numara ? "Kaydedildi" : "Numara okunamadı (elle kaydedildiyse numarayı ekleyin)");
                        _0x225457();
                        await _0x4cef66(false);
                        _0x5cfc06 = null;
                    }
                    _0x5b5599('Kuyruk bitti. Kaydedilen: ' + _0x4edd46 + (_0x5627d8 ? ', atlanan: ' + _0x5627d8 : ''), 'ok');
                    await _0x4cef66(!false);
                }
                catch (_0x58a3c0) {
                    if (_0x58a3c0 !== "stop") {
                        _0x5b5599("Hata: " + (_0x58a3c0.message || _0x58a3c0), "err");
                    }
                    else {
                        _0x5b5599('Durduruldu.', "err");
                    }
                    _0x5cfc06 && (_0x5a56d3(_0x5cfc06, _0x5f03d4.numara, (_0x58a3c0 === "stop" ? 'Durduruldu' : "Hata") + ': ' + _0x15b07a + ' adımında — KAYDEDİLMEMİŞ OLABİLİR'), await _0x4cef66(false));
                    _0x47a824.forEach(_0x5f1cdb => {
                        let _unused_osmb;
                        if (_0x5f1cdb.status === "run") {
                            _0x5f1cdb.status = '';
                        }
                    });
                    _0x225457();
                }
                finally {
                    _0x9156cd = false;
                    _0xa4127a(false);
                    _0x50dc69(null);
                    try {
                        _0x2f2f4f.removeItem(_0x5497e8);
                    }
                    catch (_0x3ee1f8) {
                    }
                    if (typeof _0x2e625a === "function") {
                        _0x2e625a(false);
                    }
                    _0x188591("#act").style.display = "none";
                }
            }
            const _0x20627e = _0x4710ca => '\x22' + String(_0x4710ca).replace(/"/g, '\x22\x22') + '\x22', _0x1fcf26 = () => '﻿' + ['Numara;Konu;Dosya;Tarih;Saat;Durum'].concat(_0x2a3361.map(_0x322f98 => [_0x322f98.numara, _0x322f98.konu, _0x322f98.dosya, _0x322f98.tarih, _0x322f98.saat, _0x322f98.durum || ''].map(_0x20627e).join(';'))).join('\x0d\x0a');
            function _0x2ac833(_0x383f80, _0xf50931, _0x3d449a) {
                const _0x2223c1 = document.createElement('a');
                _0x2223c1.href = URL.createObjectURL(new Blob([_0xf50931], { 'type': _0x3d449a || "text/plain;charset=utf-8" }));
                _0x2223c1.download = _0x383f80;
                document.body.appendChild(_0x2223c1);
                _0x2223c1.click();
                _0x2223c1.remove();
            }
            async function _0x4cef66(_0x2147cd) {
                let _unused_tivo;
                if (_0x4f3a1d) {
                    try {
                        const _0x294b87 = await _0x4f3a1d.getFileHandle("evrak_kayit_listesi.csv", { 'create': !false }), _0x1f0899 = await _0x294b87.createWritable();
                        await _0x1f0899.write(_0x1fcf26());
                        await _0x1f0899.close();
                        _0x5b5599('Liste klasöre yazıldı.', 'ok');
                        return;
                    }
                    catch (_0x45bc1d) {
                        _0x5b5599("Klasöre yazılamadı, indiriliyor: " + _0x45bc1d.message, "err");
                    }
                }
                if (_0x2147cd) {
                    _0x2ac833("evrak_kayit_listesi.csv", _0x1fcf26(), 'text/csv;charset=utf-8');
                }
            }
            function _0x1abda4() {
                const _0x4874b7 = ["URL: " + location.href, "Çerçeve sayısı: " + (_0x52dd5d().length - 0x1)];
                _0x52dd5d().forEach((_0x339da7, _0x3a9641) => {
                    let _unused_9w89;
                    _0x4874b7.push("--- doc " + _0x3a9641 + ' ' + (_0x339da7.location && _0x339da7.location.href));
                    const _0x54d02e = [..._0x339da7.querySelectorAll("label,td,th,span,legend")].filter(_0x59bafa => _0x30d46f(_0x59bafa) && _0x59bafa.children.length < 0x2).map(_0x2112eb => (_0x2112eb.textContent || '').trim()).filter(_0x1dac9b => _0x1dac9b && _0x1dac9b.length < 0x28);
                    _0x4874b7.push('ETİKETLER: ' + [...new Set(_0x54d02e)].slice(0x0, 0xc8).join(" | "));
                    [..._0x339da7.querySelectorAll("input,select,textarea,button,.ui-selectonemenu,.ui-autocomplete")].filter(_0xd6ee3e => _0x30d46f(_0xd6ee3e) || _0xd6ee3e.type === "file").slice(0x0, 0xc8).forEach(_0x50a96c => _0x4874b7.push('<' + _0x50a96c.tagName.toLowerCase() + (_0x50a96c.type ? " type=" + _0x50a96c.type : '') + " id=" + _0x50a96c.id + " name=" + (_0x50a96c.name || '') + " class=\"" + (_0x50a96c.className + '').slice(0x0, 0x46) + "\" ph=\"" + (_0x50a96c.placeholder || '') + "\" val=\"" + (_0x50a96c.value || _0x50a96c.textContent || '').trim().slice(0x0, 0x28) + '\x22>'));
                });
                _0x52dd5d().forEach(_0x3bc875 => {
                    let _unused_qwkt;
                    [..._0x3bc875.querySelectorAll(".ui-autocomplete-panel,.ui-selectonemenu-panel,.ui-dialog,[role=listbox],[role=dialog],.ui-overlaypanel")].filter(_0x30d46f).slice(0x0, 0x6).forEach(_0x3e495f => _0x4874b7.push("AÇIK PANEL: " + (_0x3e495f.outerHTML || '').replace(/\s+/g, ' ').slice(0x0, 0x9c4)));
                });
                return _0x4874b7.join('\x0a');
            }
            typeof window !== "undefined" && window.__EA_TEST__ && (window.__EA_KAYIT_GUARDS__ = { 'ozetMetni': EA_ozetMetni, 'ortakHazirla': EA_ortakPaketHazirla, 'ortakUygula': EA_ortakPaketUygula, 'raporHtml': EA_aylikRaporHtml, 'uzakIzin': EA_uzakIzin, 'kayitlar': () => _0x2a3361, 'stepKonuKodu': _0x53afba, 'stepKlasor': EA_klasorSec, 'konuAdaylari': EA_konuAdaylari, 'agacSec': _0x400697, 'KONU_KODU': EA_KONU_KODU, 'pdfAyikla': _0x2849ab, 'xlsx': EA_xlsxKodlari, 'ctx': (o) => (o ? (_0x5f03d4 = o) : _0x5f03d4), 'ayar': () => _0x599e9b, 'seciliKod': _0x4d2a7f, 'isScriptLeakValue': _0x3e6c44, 'looksLikePersonName': _0x316c76, 'isValidEvrakSayi': _0x3f5d3e, 'isPlausibleHavale': _0x500699, 'extractSayiFromLines': _0x22744b, 'norm': _0x3c029d, 'scrubEvrakSayi': _0x517e1e, 'stepEvrakSayi': _0x6507e6, 'assertHavaleValue': _0x3fe736, 'evrakSayiInput': _0x15ec55, 'evrakHavaleInput': _0x569f58, 'ensureKonuMetni': _0x1e2aff, 'stepHavale': _0x225887, 'stepSave': _0x565b1e, 'assertReadyForKaydet': _0x5a1db6, 'settleAjax': _0x115206, 'kaydetButtons': _0x5bf94b, 'typeInto': _0x5a1f35, 'pickListed': _0x5e08c1, 'setNative': _0x497585, 'clickEl': _0x2c5bca, 'buttonByText': _0x4ef577, 'shownKonu': _0x4d2a7f, 'getCtx': () => _0x5f03d4, 'setCtx': _0x493b85 => {
                    let _unused_m2cd;
                    _0x5f03d4 = Object.assign(_0x5f03d4 || {}, _0x493b85 || {});
                }, 'getS': () => _0x599e9b, 'setS': _0x1ad740 => {
                    let _unused_l8h2;
                    Object.assign(_0x599e9b, _0x1ad740 || {});
                }, 'setItemSayi': _0xd54f1f => {
                    let _unused_zgnx;
                    if (!_0x5f03d4.item) {
                        _0x5f03d4.item = {};
                    }
                    _0x5f03d4.item.sayi = _0xd54f1f;
                }, 'setItem': _0x267125 => {
                    let _unused_qsad;
                    _0x5f03d4.item = Object.assign(_0x5f03d4.item || {}, _0x267125 || {});
                }, 'resolveAsk': _0x58db70 => {
                    if (_0x317a4d) {
                        _0x317a4d(_0x58db70);
                    }
                }, 'getAskResolve': () => _0x317a4d, 'setRunning': _0x8c847a => {
                    _0x9156cd = !!_0x8c847a;
                }, 'pageText': _0x4d6fb0, 'docs': _0x52dd5d });
            const _0x493001 = document.createElement("div");
            _0x493001.id = "evrak-otonom-host";
            _0x493001.style.cssText = "position:fixed;left:12px;bottom:12px;z-index:2147483647;";
            const _0x583a1c = _0x493001.attachShadow({ 'mode': "open" }), _0x320af4 = "<svg viewBox=\"0 0 64 64\" width=\"100%\" height=\"100%\"><defs><linearGradient id=\"eg\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#2196f3\"/><stop offset=\"1\" stop-color=\"#0a3a8c\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#eg)\"/><path d=\"M16 11h22l10 10v32H16z\" fill=\"#fff\"/><path d=\"M38 11l10 10H38z\" fill=\"#c8def9\"/><rect x=\"21\" y=\"26\" width=\"22\" height=\"3\" rx=\"1.5\" fill=\"#78a0d7\"/><rect x=\"21\" y=\"33\" width=\"22\" height=\"3\" rx=\"1.5\" fill=\"#78a0d7\"/><rect x=\"21\" y=\"40\" width=\"14\" height=\"3\" rx=\"1.5\" fill=\"#78a0d7\"/><circle cx=\"46\" cy=\"47\" r=\"12\" fill=\"#fff\"/><circle cx=\"46\" cy=\"47\" r=\"9.5\" fill=\"#2eaa5a\"/><path d=\"M41.5 47.5l3.2 3.2 6-6.5\" stroke=\"#fff\" stroke-width=\"2.6\" fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>";
            _0x583a1c.innerHTML = "\n<style>\n:host{all:initial}\n*{box-sizing:border-box;font-family:'Segoe UI',system-ui,Arial,sans-serif}\n[hidden]{display:none!important}\n#fab{width:60px;height:60px;padding:0;border:3px solid #fff;border-radius:50%;background:#0d47a1;cursor:pointer;box-shadow:0 6px 18px #0007;overflow:hidden;transition:transform .15s}\n#fab:hover{transform:scale(1.1)}\n#panel{--fs:15px;display:none;width:480px;height:620px;min-width:340px;min-height:320px;max-width:96vw;max-height:94vh;resize:both;overflow:hidden;\n background:#f4f7fb;color:#18222f;border-radius:16px;box-shadow:0 14px 44px #0008,0 0 0 1px #0b3d9144;font-size:var(--fs);flex-direction:column}\n#hd{background:linear-gradient(135deg,#0d47a1,#1e88e5);color:#fff;padding:10px 12px;display:flex;gap:8px;align-items:center;cursor:move;user-select:none}\n.logo{width:36px;height:36px;flex:none;border-radius:9px;overflow:hidden;box-shadow:0 2px 6px #0005}\n.ttl{flex:1;line-height:1.15}.ttl b{display:block;font-size:1.08em}.ttl small{opacity:.88;font-size:.78em}\n.chip{background:#ffffff2e;border-radius:20px;padding:3px 11px;font-size:.78em;font-weight:700;white-space:nowrap}\n.chip.run{background:#ffb300;color:#3a2a00}.chip.warn{background:#ff5252;color:#fff;animation:pl 1s infinite}.chip.ok{background:#43a047}\n@keyframes pl{50%{opacity:.55}}\n#hd button{background:#ffffff26;color:#fff;border:0;border-radius:8px;padding:4px 9px;font-size:.9em;cursor:pointer}\n#hd button:hover{background:#ffffff4d}\n#tabs{display:flex;background:#dfe8f5;padding:6px 8px 0;gap:4px}\n.tab{flex:1;border:0;background:none;padding:8px 6px;font-size:.95em;font-weight:700;color:#4a6285;cursor:pointer;border-radius:10px 10px 0 0}\n.tab:hover{background:#ffffff66}.tab.on{color:#0d47a1;background:#f4f7fb}\n#body{flex:1;overflow:auto;padding:12px}\nsection{display:flex;flex-direction:column;gap:10px;min-height:100%}\n.card{background:#fff;border-radius:12px;padding:10px;box-shadow:0 1px 5px #0b3d9122}\n.row{display:flex;flex-wrap:wrap;gap:6px}\nbutton.b,label.b{background:#1565c0;color:#fff;border:0;border-radius:10px;padding:8px 13px;font-size:.93em;font-weight:700;cursor:pointer;box-shadow:0 1px 3px #0003;display:inline-block}\nbutton.b:hover,label.b:hover{filter:brightness(1.1)}button.b:disabled{opacity:.5;cursor:default}\n.big{width:100%;padding:13px 14px !important;font-size:1.02em !important;border-radius:12px !important}\n.dirl{flex:1;font-size:.85em;color:#33425b;font-weight:700;min-width:120px}\n#otoTarih{padding:4px 6px;border:1px solid #b5c3d8;border-radius:8px;font-size:.85em}\n.b.g{background:#2e9d52}.b.r{background:#d63c3c}.b.n{background:#5b6f8c}.b.sm{padding:3px 9px;font-size:.8em;border-radius:8px}\n#nums{background:#fff8e1;border:2px solid #ffc107;border-radius:12px;padding:9px 11px}\n#nums h4{margin:0 0 4px;font-size:.78em;letter-spacing:.3px;color:#7a5b00;text-transform:uppercase}\n.num{font-size:1.9em;font-weight:800;color:#c62828;line-height:1.1;word-break:break-all}\n.num small{display:block;font-size:.4em;font-weight:600;color:#444}\n#stepper{display:flex;flex-wrap:wrap;gap:4px}\n.sp{padding:2px 9px;border-radius:12px;font-size:.76em;background:#e3e9f2;color:#5a6b85;font-weight:700}\n.sp.ok{background:#d7f2de;color:#1b6b34}.sp.run{background:#ffe08a;color:#6b4a00}.sp.err{background:#ffd3d3;color:#9b1c1c}\n#q .it{display:flex;flex-direction:column;gap:4px;background:#fff;border-radius:12px;padding:9px;margin-bottom:8px;box-shadow:0 1px 5px #0b3d9122}\n#q .it .top{display:flex;gap:6px;align-items:center}\n#q .it input,#q .it select,.f input,.f textarea{font-size:.95em;padding:6px 8px;border:1px solid #b5c3d8;border-radius:8px;width:100%;background:#fcfdff}\n#q .it input:focus,#q .it select:focus,.f input:focus,.f textarea:focus{outline:2px solid #64b5f6;border-color:#64b5f6}\n#q .fn{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:700;color:#23324a}\n.st{font-weight:800;font-size:.85em}.st.done{color:#2e9d52}.st.run{color:#e08a00}\n#log{flex:1;min-height:150px;background:#0e1621;color:#dfe9f5;border-radius:12px;padding:9px;overflow:auto;font:.86em/1.5 Consolas,'Courier New',monospace;white-space:pre-wrap}\n#log .ok{color:#7ee787}#log .err{color:#ff8b8b}\n#act{display:none;flex-direction:column;gap:6px;background:#ffebee;border:2px solid #d63c3c;border-radius:12px;padding:10px}\nlabel.f,div.f{display:block;margin-top:8px;font-size:.88em;font-weight:700;color:#33425b}\n.card h3{margin:0 0 6px;font-size:.95em;color:#0d47a1}\n.rec{display:flex;gap:10px;align-items:center;background:#fff;border-radius:12px;padding:8px 10px;margin-bottom:6px;box-shadow:0 1px 4px #0b3d9122}\n.rec .n{font-size:1.25em;font-weight:800;color:#c62828;min-width:105px;word-break:break-all}\n.rec .m{flex:1;font-size:.88em;color:#33425b}.rec .m small{display:block;color:#7a8aa3}\n.bd{font-size:.72em;font-weight:800;border-radius:10px;padding:2px 8px;background:#d7f2de;color:#1b6b34;white-space:nowrap}.bd.x{background:#ffd3d3;color:#9b1c1c}\n</style>\n<button id=\"fab\" title=\"Evrak Kayıt Otonom\">" + _0x320af4 + "</button>\n<div id=\"panel\">\n <div id=\"hd\"><span class=\"logo\">" + _0x320af4 + '</span><div class=\x22ttl\x22><b>Evrak Kayıt Otonom</b><small>Gelen Evrak Kayıt asistanı</small></div><span id=\x22chip\x22 class=\x22chip\x22>Hazır</span><button id=\x22fm\x22>A−</button><button id=\x22fp\x22>A+</button><button id=\x22mn\x22>—</button></div>\x0a <div id=\x22tabs\x22><button class=\x22tab on\x22 data-t=\x22islem\x22>📝 İşlem</button><button class=\x22tab\x22 data-t=\x22kayit\x22>📋 Kayıtlar</button><button class=\x22tab\x22 data-t=\x22ayar\x22>⚙ Ayarlar</button></div>\x0a <div id=\x22body\x22>\x0a  <section id=\x22t_islem\x22>\x0a   <div class=\x22card\x22 id=\x22oto\x22>\x0a    <button class=\x22b g big\x22 id=\x22oto_go\x22>⚡ EVRAK KAYIT — klasördeki bugünkü PDF\x27leri sırayla kaydet</button>\x0a    <div class=\x22row\x22 style=\x22margin-top:8px;align-items:center\x22><span id=\x22otoDir\x22 class=\x22dirl\x22>Klasör seçilmedi</span><input type=\x22date\x22 id=\x22otoTarih\x22><button class=\x22b n sm\x22 id=\x22oto_dir\x22>📁 Klasör seç</button><button class=\x22b r sm\x22 id=\x22oto_cancel\x22 hidden>✖ Vazgeç</button></div>\x0a   </div>\x0a   <div id=\x22nums\x22><h4>Son kayıt numaraları — evrak üzerine işlemeyi unutmayın</h4><div id=\x22numList\x22>Henüz kayıt yok.</div></div>\x0a   <div class=\x22row\x22>\x0a    <label class=\x22b n\x22>📄 PDF/JPEG seç<input id=\x22pdf\x22 type=\x22file\x22 accept=\x22application/pdf,.pdf,image/jpeg,.jpg,.jpeg,image/png,.png\x22 multiple hidden></label>\x0a    <button class=\x22b n\x22 id=\x22dirpdf\x22>📂 Klasördeki PDF/JPEG\x27ler</button>\x0a    <button class=\x22b g\x22 id=\x22go\x22>▶ Başlat</button>\x0a    <button class=\x22b r\x22 id=\x22stop\x22>⏹ Durdur</button>\x0a   </div>\x0a   <div id=\x22act\x22><b id=\x22actTxt\x22></b><div class=\x22row\x22>\x0a    <button class=\x22b\x22 data-a=\x22retry\x22>🔁 Tekrar dene</button><button class=\x22b g\x22 data-a=\x22skip\x22>⏭ Elle yaptım, devam</button><button class=\x22b n\x22 data-a=\x22next\x22>⏩ Bu evrağı atla, sıradakine geç</button><button class=\x22b r\x22 data-a=\x22stop\x22>⏹ Durdur</button></div></div>\x0a   <div id=\x22stepper\x22></div>\x0a   <div id=\x22q\x22></div>\x0a   <div id=\x22log\x22></div>\x0a  </section>\x0a  <section id=\x22t_kayit\x22 hidden>\x0a   <div class=\x22row\x22>\x0a    <button class=\x22b\x22 id=\x22csv\x22>⬇ CSV indir</button>\x0a    <button class=\x22b n\x22 id=\x22dir\x22>📁 Kayıtlar klasörü</button>\x0a    <button class=\x22b n\x22 id=\x22clr\x22>🗑 Listeyi sıfırla</button>\x0a   </div>\x0a   <div id=\x22recList\x22></div>\x0a  </section>\x0a  <section id=\x22t_ayar\x22 hidden>\x0a   <div class=\x22card\x22>\x0a    <h3>👥 Müdür yardımcıları / kişiler</h3>\x0a    <small>Geldiği kişi listesi. İşaretliler evrak satırındaki seçimde çıkar. Adı sistemdeki gibi yazın (ör. Ayşe YILMAZ). Aynı adda birden çok kişi çıkarsa doğru kişiyi seçmek için TC kimlik no yazın.</small>\x0a    <div id=\x22kisiList\x22></div>\x0a    <div class=\x22row\x22 style=\x22margin-top:6px\x22><input id=\x22kisiAd\x22 placeholder=\x22Ad SOYAD\x22 style=\x22flex:2;min-width:120px;padding:6px 8px;border:2px solid #33425b;border-radius:8px\x22><input id=\x22kisiTc\x22 placeholder=\x22TC Kimlik No\x22 inputmode=\x22numeric\x22 maxlength=\x2211\x22 style=\x22flex:1;min-width:110px;padding:6px 8px;border:2px solid #33425b;border-radius:8px\x22><button class=\x22b g\x22 id=\x22kisiEkle\x22>➕ Ekle</button></div>\x0a    <small id=\x22kisiUyari\x22 style=\x22color:#b71c1c;font-weight:800\x22></small>\x0a   </div>\x0a   <div class=\x22card\x22>\x0a    <h3>Genel</h3>\x0a    <label class=\x22f\x22>Simgenin kesin çıkacağı adres(ler) (Belgenet menüsü görünen sayfada zaten otomatik çıkar)<textarea id=\x22s_adresler\x22 rows=\x222\x22></textarea></label>\x0a    <label class=\x22f\x22>Varsayılan gönderen (PDF\x27te bulunamazsa)<input id=\x22s_gonderen\x22></label>\x0a    <label class=\x22f\x22>Birime Havale (okul adı — listeden seçilir)<input id=\x22s_okul\x22></label>\x0a    <label class=\x22f\x22>Kişi-Kurum<input id=\x22s_kisiKurum\x22></label>\x0a    <label class=\x22f\x22>Geliş Tipi<input id=\x22s_gelisTipi\x22></label>\x0a    <label class=\x22f\x22 style=\x22display:flex;gap:8px;align-items:center\x22><input type=\x22checkbox\x22 id=\x22s_otoFab\x22 style=\x22width:18px;height:18px\x22> Yüzen simgeye tıklayınca bugünün evraklarını otomatik kaydet</label>\x0a    <label class=\x22f\x22>Yavaşlık çarpanı (1 hızlı · 1.5 önerilen · 2-3 çok yavaş)<input id=\x22s_pace\x22 type=\x22number\x22 step=\x220.1\x22 min=\x220.5\x22 max=\x224\x22></label>\x0a    <label class=\x22f\x22>Liste bekleme süresi, sn (yazdıktan sonra seçenekler gelene kadar · yavaş internette 3-4)<input id=\x22s_listeBekle\x22 type=\x22number\x22 step=\x220.5\x22 min=\x221\x22 max=\x2210\x22></label>\x0a    <label class=\x22f\x22>Birime Havale’ye yazılacak ad (boşsa okul adından: ör. İlçe Örnek Anadolu Lisesi)<input id=\x22s_havaleAra\x22></label>\x0a    <label class=\x22f\x22>Günlük özet telefonu (müdür; boşsa İdareciler’deki “Müdür”)<input id=\x22s_ozetTel\x22 placeholder=\x2205xx xxx xx xx\x22></label>\x0a    <label class=\x22f\x22>Özet hatırlatma saati<input id=\x22s_ozetSaat\x22 type=\x22number\x22 min=\x228\x22 max=\x2223\x22></label>\x0a    <label class=\x22f\x22>Rapor: evrak başına kazanılan dakika<input id=\x22s_dakikaKazanc\x22 type=\x22number\x22 min=\x221\x22 max=\x2230\x22></label>\x0a   </div>\x0a   <div class=\x22card\x22>\x0a    <h3>Eşleme kuralları</h3>\x0a    <label class=\x22f\x22>Konu eşleme (anahtar=Konu Kodu araması)<textarea id=\x22s_rules\x22 rows=\x223\x22></textarea></label>\x0a    <label class=\x22f\x22>Görev eşleme (Ad Soyad = anahtar1, anahtar2)<textarea id=\x22s_gorevler\x22 rows=\x223\x22></textarea></label>\x0a    <label class=\x22f\x22>Havale eşleme (PDF\x27te geçen ifade=Birim adı)<textarea id=\x22s_havaleRules\x22 rows=\x222\x22></textarea></label>\x0a    <label class=\x22f\x22>Konu kataloğu (ek satırlar: kod ad)<textarea id=\x22s_katalog\x22 rows=\x223\x22></textarea></label>\x0a    <div class=\x22row\x22><button class=\x22b n\x22 id=\x22xlskat\x22>📥 Excel’den desimal kodları yükle (tüm sayfalar)</button><input type=\x22file\x22 id=\x22xlsfile\x22 accept=\x22.xlsx\x22 hidden></div>\x0a   </div>\x0a   <div class=\x22card\x22>\x0a    <h3>Araçlar</h3>\x0a    <div class=\x22row\x22>\x0a     <button class=\x22b n\x22 id=\x22logdl\x22>⬇ Log indir</button>\x0a     <button class=\x22b n\x22 id=\x22tani\x22>🔬 Tanı</button>\x0a     <button class=\x22b n\x22 id=\x22kat\x22>📚 Konu listesini kaydet</button>\x0a     <button class=\x22b n\x22 id=\x22lrn\x22>🧹 Öğrenilenleri sil</button>\x0a    </div>\x0a    <div class=\x22row\x22>\x0a     <button class=\x22b n\x22 id=\x22ozetwa\x22>📲 Günlük özet (müdüre)</button>\x0a     <button class=\x22b n\x22 id=\x22rapor\x22>📊 Aylık rapor</button>\x0a    </div>\x0a    <div class=\x22row\x22>\x0a     <button class=\x22b n\x22 id=\x22ortaksync\x22>🔄 Ortak klasörle eşitle</button>\x0a     <button class=\x22b n\x22 id=\x22ortakdl\x22>📤 Ortak paket indir</button>\x0a     <button class=\x22b n\x22 id=\x22ortakal\x22>📥 Paket al</button><input type=\x22file\x22 id=\x22ortakfile\x22 accept=\x22.json\x22 hidden>\x0a    </div>\x0a   </div>\x0a  </section>\x0a </div>\x0a</div>';
            document.documentElement.appendChild(_0x493001);
            const _0x188591 = _0x42bc9a => _0x583a1c.querySelector(_0x42bc9a), _0x4785da = _0x188591('#panel'), _0x2acd7f = _0x188591("#fab");
            function _0x5b5599(_0xe8976e, _0x2a6a48) {
                const _0x80deef = new Date().toTimeString().slice(0x0, 0x8);
                _0x55b20f.push('[' + _0x80deef + '] ' + _0xe8976e);
                if (_0x55b20f.length > 0x320) {
                    _0x55b20f.splice(0x0, _0x55b20f.length - 0x320);
                }
                try {
                    _0x2f2f4f.setItem(_0x4ac4b6, JSON.stringify(_0x55b20f));
                }
                catch (_0x3ecbce) {
                }
                const _0x4a84a2 = document.createElement('div');
                if (_0x2a6a48) {
                    _0x4a84a2.className = _0x2a6a48;
                }
                _0x4a84a2.textContent = '[' + _0x80deef + '] ' + _0xe8976e;
                _0x188591("#log").appendChild(_0x4a84a2);
                _0x188591("#log").scrollTop = 0x3b9aca00;
            }
            function _0x566c81(_0x3f340f, _0x3b0faa) {
                const _0xbb58fa = _0x188591("#chip");
                _0xbb58fa.textContent = _0x3f340f;
                _0xbb58fa.className = "chip " + (_0x3b0faa || '');
            }
            function _0xa4127a(_0x3e06f0) {
                let _unused_9sys;
                _0x188591("#go").disabled = _0x3e06f0;
                _0x566c81(_0x3e06f0 ? 'Çalışıyor' : "Hazır", _0x3e06f0 ? 'run' : '');
            }
            const _0x544379 = ["Menü", "Üst yazı", "Konu kodu", "Konu", "Tarih", 'Kişi-Kurum', 'Geldiği kişi', "Sayı", 'Geliş tipi', "Klasör", 'Havale', "Kaydet"];
            function _0x49423a() {
                const _0x1641ee = _0x188591('#stepper');
                _0x1641ee.innerHTML = '';
                _0x5eea6d.forEach(([_0x219a64], _0xb6af8f) => {
                    const _0x44990f = document.createElement('span');
                    _0x44990f.className = "sp " + (_0xef2233[_0x219a64] || '');
                    _0x44990f.textContent = (_0xef2233[_0x219a64] === 'ok' ? '✔ ' : _0xef2233[_0x219a64] === "err" ? '✖ ' : _0xb6af8f + 0x1 + '. ') + (_0x544379[_0xb6af8f] || _0x219a64);
                    _0x1641ee.appendChild(_0x44990f);
                });
            }
            function _0x1f3c49() {
                const _0x41c65d = _0x188591('#recList');
                _0x41c65d.innerHTML = '';
                if (!_0x2a3361.length) {
                    _0x41c65d.textContent = "Henüz kayıt yok.";
                    return;
                }
                [..._0x2a3361].reverse().forEach(_0x233f40 => {
                    const _0x420bc7 = document.createElement('div');
                    _0x420bc7.className = 'rec';
                    _0x420bc7.innerHTML = '<div class=\x22n\x22></div><div class=\x22m\x22><span></span><small></small></div><span class=\x22bd\x22></span>';
                    _0x420bc7.querySelector('.n').textContent = _0x233f40.numara || '—';
                    _0x420bc7.querySelector(".m span").textContent = _0x233f40.konu || _0x233f40.dosya;
                    _0x420bc7.querySelector("small").textContent = (_0x233f40.tarih || '') + ' ' + (_0x233f40.saat || '') + " · " + (_0x233f40.dosya || '');
                    const _0x4f5361 = _0x420bc7.querySelector('.bd'), _0x315cc4 = !_0x233f40.durum || _0x233f40.durum === "Kaydedildi";
                    _0x4f5361.textContent = _0x315cc4 ? 'Kaydedildi' : _0x233f40.durum.split(':')[0x0].split('(')[0x0].trim();
                    _0x4f5361.className = 'bd' + (_0x315cc4 ? '' : ' x');
                    _0x4f5361.title = _0x233f40.durum || '';
                    _0x41c65d.appendChild(_0x420bc7);
                });
            }
            _0x583a1c.querySelectorAll(".tab").forEach(_0x328b34 => _0x328b34.onclick = () => {
                let _unused_40lo;
                _0x583a1c.querySelectorAll(".tab").forEach(_0x4c8667 => _0x4c8667.classList.toggle('on', _0x4c8667 === _0x328b34));
                ['islem', 'kayit', "ayar"].forEach(_0x1bd87c => _0x188591('#t_' + _0x1bd87c).hidden = _0x1bd87c !== _0x328b34.dataset.t);
                if (_0x328b34.dataset.t === "kayit") {
                    _0x1f3c49();
                }
            });
            function _0x4fe213() {
                const _0x33aeed = _0x2a3361.filter(_0x581120 => _0x581120.numara).slice(-0x5).reverse();
                _0x188591("#numList").innerHTML = _0x33aeed.length ? '' : "Henüz kayıt yok.";
                _0x33aeed.forEach(_0x1c9073 => {
                    const _0x53430f = document.createElement("div");
                    _0x53430f.className = 'num';
                    _0x53430f.innerHTML = "<span></span><small></small>";
                    _0x53430f.firstChild.textContent = _0x1c9073.numara;
                    _0x53430f.lastChild.textContent = _0x1c9073.konu;
                    _0x188591("#numList").appendChild(_0x53430f);
                });
                if (typeof _0x1f3c49 === "function") {
                    _0x1f3c49();
                }
            }
            function _0x1eddae() {
                const _0x368a68 = _0x188591('#kisiList');
                _0x368a68.innerHTML = '';
                _0x599e9b.kisiler.forEach((_0x4da76b, _0x3d194d) => {
                    const _0x37cafe = document.createElement("div");
                    _0x37cafe.style.cssText = 'display:flex;gap:6px;align-items:center;padding:3px 0;border-bottom:1px solid #eee';
                    _0x37cafe.innerHTML = '<input type=\x22checkbox\x22 title=\x22Listede göster\x22 style=\x22width:18px;height:18px\x22><input class=\x22ka\x22 style=\x22flex:2;min-width:110px;padding:5px 7px;border:2px solid #33425b;border-radius:8px;color:#000\x22><input class=\x22kt\x22 placeholder=\x22TC (isteğe bağlı)\x22 inputmode=\x22numeric\x22 maxlength=\x2211\x22 style=\x22flex:1;min-width:105px;padding:5px 7px;border:2px solid #33425b;border-radius:8px;color:#000\x22><button class=\x22b r sm\x22 title=\x22Çıkar\x22>−</button>';
                    const _0x548706 = _0x37cafe.querySelector('input');
                    _0x548706.checked = _0x4da76b.on !== false;
                    const _0x3076db = _0x37cafe.querySelector(".ka"), _0x4e23fa = _0x37cafe.querySelector('.kt');
                    _0x3076db.value = _0x4da76b.ad;
                    _0x4e23fa.value = _0x4da76b.tc || '';
                    const _0x19f0b1 = () => {
                        let _unused_4j70;
                        _0x4e23fa.style.borderColor = _0x7c92c3(_0x4e23fa.value.trim()) ? "#33425b" : '#d32f2f';
                        _0x4e23fa.title = _0x7c92c3(_0x4e23fa.value.trim()) ? '' : "TC 11 haneli olmalı";
                    };
                    _0x19f0b1();
                    _0x548706.onchange = () => {
                        let _unused_anzp;
                        _0x4da76b.on = _0x548706.checked;
                        _0x381096();
                        _0x225457();
                    };
                    _0x3076db.onchange = () => {
                        const _0x593637 = _0x4da76b.ad, _0x4885e7 = _0x3076db.value.trim().replace(/\s+/g, ' ');
                        if (!_0x4885e7) {
                            _0x3076db.value = _0x593637;
                            return;
                        }
                        _0x4da76b.ad = _0x4885e7;
                        _0x47a824.forEach(_0xd7a8c7 => {
                            let _unused_gd72;
                            if (_0xd7a8c7.gonderen === _0x593637) {
                                _0xd7a8c7.gonderen = _0x4885e7;
                            }
                        });
                        if (_0x599e9b.sonGonderen === _0x593637) {
                            _0x599e9b.sonGonderen = _0x4885e7;
                        }
                        _0x381096();
                        _0x225457();
                    };
                    _0x4e23fa.oninput = () => {
                        let _unused_g0cu;
                        _0x4e23fa.value = _0x4e23fa.value.replace(/\D/g, '').slice(0x0, 0xb);
                        _0x19f0b1();
                    };
                    _0x4e23fa.onchange = () => {
                        let _unused_3jzd;
                        _0x4da76b.tc = _0x4e23fa.value.trim();
                        _0x381096();
                        _0x225457();
                        if (!_0x7c92c3(_0x4da76b.tc)) {
                            _0x5b5599("Uyarı: " + _0x4da76b.ad + " için TC 11 haneli değil; TC ile arama yapılmayacak.", "err");
                        }
                    };
                    _0x37cafe.querySelector('button').onclick = () => {
                        let _unused_gu0d;
                        _0x599e9b.kisiler.splice(_0x3d194d, 0x1);
                        _0x381096();
                        _0x1eddae();
                    };
                    _0x368a68.appendChild(_0x37cafe);
                });
                if (!_0x599e9b.kisiler.length) {
                    _0x368a68.textContent = 'Henüz kişi eklenmedi.';
                }
                _0x225457();
            }
            function _0x225457() {
                const _0x170711 = _0x188591('#q');
                _0x170711.innerHTML = '';
                _0x47a824.forEach((_0xc3b3f3, _0x133e29) => {
                    const _0x476e7f = document.createElement("div");
                    _0x476e7f.className = 'it';
                    _0x476e7f.innerHTML = "<div class=\"top\"><span class=\"fn\"></span><span class=\"st\"></span><button class=\"b n sm\" data-k=\"t\">metin</button><button class=\"b n sm\" data-k=\"x\">✕</button></div><input data-f=\"konu\" placeholder=\"Konu\"><select data-f=\"gonderen\"></select><input data-f=\"havale\" placeholder=\"Birime havale (boş = listedeki okulumuz)\">";
                    _0x476e7f.querySelector(".fn").textContent = _0xc3b3f3.file.name;
                    _0x476e7f.querySelector(".fn").title = _0xc3b3f3.file.name;
                    _0x476e7f.querySelectorAll("input").forEach(_0x4f7519 => {
                        let _unused_9p4s;
                        _0x4f7519.value = _0xc3b3f3[_0x4f7519.dataset.f] || '';
                        _0x4f7519.oninput = () => _0xc3b3f3[_0x4f7519.dataset.f] = _0x4f7519.value;
                    });
                    const _0x9be710 = _0x476e7f.querySelector("select"), _0x2106a8 = [..._0x4ea448()];
                    if (_0xc3b3f3.gonderen && !_0x2106a8.includes(_0xc3b3f3.gonderen)) {
                        _0x2106a8.push(_0xc3b3f3.gonderen);
                    }
                    _0x9be710.style.cssText = "font-size:.95em;padding:4px;border:1px solid #888;border-radius:4px;width:100%";
                    if (!_0xc3b3f3.gonderen && _0x599e9b.sonGonderen && _0x2106a8.includes(_0x599e9b.sonGonderen)) {
                        _0xc3b3f3.gonderen = _0x599e9b.sonGonderen;
                    }
                    _0x9be710.innerHTML = '<option value=\x22\x22>— Geldiği kişiyi seçin —</option>' + _0x2106a8.map(_0x28e2a5 => "<option></option>").join('');
                    [..._0x9be710.options].slice(0x1).forEach((_0xa8717, _0x538024) => {
                        const _0x5eb641 = _0x36ce29(_0x2106a8[_0x538024]);
                        _0xa8717.value = _0x2106a8[_0x538024];
                        _0xa8717.textContent = _0x2106a8[_0x538024] + (_0x5eb641 ? ' · TC …' + _0x5eb641.slice(-0x4) : '');
                    });
                    _0x9be710.value = _0xc3b3f3.gonderen || '';
                    _0x9be710.onchange = () => {
                        let _unused_dpq6;
                        _0xc3b3f3.gonderen = _0x9be710.value;
                        _0x9be710.value && (_0x599e9b.sonGonderen = _0x9be710.value, _0x381096());
                    };
                    const _0x4acce6 = _0x476e7f.querySelector(".st");
                    _0x4acce6.textContent = _0xc3b3f3.status === "done" ? '✔' : _0xc3b3f3.status === "run" ? '…' : _0xc3b3f3.status === "oku" ? "okunuyor" : _0xc3b3f3.status === "atla" ? "⏭ atlandı" : '';
                    _0x4acce6.className = "st " + (_0xc3b3f3.status || '');
                    _0x476e7f.querySelector("[data-k=x]").onclick = () => {
                        let _unused_upgs;
                        _0x47a824.splice(_0x133e29, 0x1);
                        _0x225457();
                    };
                    _0x476e7f.querySelector("[data-k=t]").onclick = () => _0x5b5599('── ' + _0xc3b3f3.file.name + " metni ──\n" + (_0xc3b3f3.text || "(metin yok)").slice(0x0, 0x5dc));
                    _0x170711.appendChild(_0x476e7f);
                });
            }
            function _0x298cf0() {
                let _unused_hbdh;
                _0x4785da.style.setProperty("--fs", _0x599e9b.font + 'px');
            }
            function _0x370e01(_0x53b60f) {
                let _unused_gjbw;
                _0x599e9b.open = _0x53b60f;
                _0x381096();
                _0x4785da.style.display = _0x53b60f ? "flex" : "none";
                _0x2acd7f.style.display = _0x53b60f ? 'none' : "block";
            }
            _0x2acd7f.onclick = () => {
                let _unused_gl54;
                _0x370e01(!false);
                if (_0x599e9b.otoFab) {
                    _0x2c4193();
                }
            };
            _0x188591('#mn').onclick = () => _0x370e01(false);
            _0x188591("#fp").onclick = () => {
                let _unused_jztv;
                _0x599e9b.font = Math.min(0x1a, _0x599e9b.font + 0x1);
                _0x298cf0();
                _0x381096();
            };
            _0x188591("#fm").onclick = () => {
                let _unused_owy4;
                _0x599e9b.font = Math.max(0xb, _0x599e9b.font - 0x1);
                _0x298cf0();
                _0x381096();
            };
            ["gonderen", 'okul', "kisiKurum", "gelisTipi", "rules", 'havaleRules', "gorevler", "katalog", "pace", "listeBekle", "havaleAra", "ozetTel", "ozetSaat", "dakikaKazanc", "adresler"].forEach(_0x4d80a6 => {
                const _0x2d8418 = _0x188591("#s_" + _0x4d80a6);
                _0x2d8418.value = _0x599e9b[_0x4d80a6];
                _0x2d8418.oninput = () => {
                    let _unused_9rxb;
                    _0x599e9b[_0x4d80a6] = _0x2d8418.value;
                    _0x381096();
                };
            });
            _0x188591("#pdf").onchange = _0x11b882 => {
                const _0x5cb7c2 = [..._0x11b882.target.files];
                _0x11b882.target.value = '';
                _0x5cb7c2.forEach(_0x5dd507);
                _0x5b5599(_0x5cb7c2.length + ' PDF okunuyor. Konu/Gönderen/Havale alanlarını satırdan düzeltebilirsiniz.');
            };
            _0x188591('#go').onclick = () => _0x3b48c9();
            _0x188591("#oto_go").onclick = () => _0x2c4193();
            _0x188591("#oto_cancel").onclick = () => {
                let _unused_946v;
                try {
                    _0x2f2f4f.removeItem(_0x5497e8);
                }
                catch (_0x4bc5de) {
                }
                _0x2e625a(false);
                _0x566c81('Hazır');
                _0x5b5599("Yarım kalan toplu işlemden vazgeçildi.", "err");
            };
            _0x188591("#oto_dir").onclick = _0x1a6f14;
            _0x188591("#otoTarih").value = _0x166b33(new Date());
            _0x188591('#s_otoFab').checked = !!_0x599e9b.otoFab;
            _0x188591("#s_otoFab").onchange = _0x37991f => {
                let _unused_f6pq;
                _0x599e9b.otoFab = _0x37991f.target.checked;
                _0x381096();
            };
            const _0x189728 = _0x4e6ff2.get("dir").then(_0x2a0900 => {
                let _unused_l46w;
                _0x2a0900 && !_0x4f3a1d && (_0x4f3a1d = _0x2a0900, _0x4dc920(), _0x5b5599("Kayıtlar klasörü hatırlandı: " + _0x2a0900.name + " (ilk kullanımda izin istenebilir)"));
            }).catch(() => {
            });
            _0x188591("#stop").onclick = () => {
                let _unused_wnv4;
                _0x228a28 = !false;
                if (_0x317a4d) {
                    _0x317a4d("stop");
                }
            };
            _0x583a1c.querySelectorAll("#act [data-a]").forEach(_0x1055ec => _0x1055ec.onclick = () => _0x317a4d && _0x317a4d(_0x1055ec.dataset.a));
            _0x188591("#csv").onclick = () => _0x2ac833("evrak_kayit_listesi.csv", _0x1fcf26(), "text/csv;charset=utf-8");
            _0x188591("#logdl").onclick = () => _0x2ac833('evrak_log.txt', _0x55b20f.join('\x0a'));
            /* ================= v3.6.66 — Ek araçlar =================
               1) Uzaktan durum (zorunlu güncelleme / kayıt kapatma)  2) Müdüre günlük WhatsApp özeti
               3) Okul ortak paketi (şablon/kural paylaşımı)           4) Aylık kazanç raporu */
            const EA_SURUM = (() => { try { return chrome.runtime.getManifest().version; } catch (e) { return '0'; } })();
            const EA_surumKarsilastir = (a, b) => { const x = String(a || '0').split('.').map(Number), y = String(b || '0').split('.').map(Number); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0 ? 1 : -1; } return 0; };
            const EA_depoAl = async anahtarlar => { try { return await chrome.storage.local.get(anahtarlar) || {}; } catch (e) { return {}; } };
            const EA_depoYaz = async nesne => { try { await chrome.storage.local.set(nesne); } catch (e) {} };
            const EA_bugun = () => _0x4a765d();
            /* 1) Uzaktan durum: arka plan api.otonomevrak.com/surum.json'u 6 saatte bir okur → ea_uzak_durum_v1 */
            async function EA_uzakDurum() {
                const d = (await EA_depoAl(['ea_uzak_durum_v1'])).ea_uzak_durum_v1;
                const s = d && d.durum;
                if (!s) return { izin: true };
                const kapali = (Array.isArray(s.kapaliSurumler) && s.kapaliSurumler.includes(EA_SURUM)) || (s.enAzSurum && EA_surumKarsilastir(EA_SURUM, s.enAzSurum) < 0) || s.kayitKapali === true;
                const yeni = s.guncelSurum && EA_surumKarsilastir(s.guncelSurum, EA_SURUM) > 0;
                return { izin: !kapali, yeni, s };
            }
            async function EA_uzakIzin() {
                const u = await EA_uzakDurum();
                if (u.yeni) _0x5b5599('🔔 Yeni sürüm var: v' + u.s.guncelSurum + (u.s.indirmeAdresi ? ' — ' + u.s.indirmeAdresi : '') + (u.s.mesaj ? ' — ' + u.s.mesaj : ''), 'err');
                if (!u.izin) {
                    _0x5b5599('⛔ Evrak Kayıt bu sürümde (v' + EA_SURUM + ') geçici olarak kapatıldı: ' + (u.s.mesaj || 'EBYS değişikliği nedeniyle güncelleme gerekiyor.') + (u.s.indirmeAdresi ? ' Güncel sürüm: ' + u.s.indirmeAdresi : ''), 'err');
                    return false;
                }
                return true;
            }
            /* 2) Günlük özet → WhatsApp */
            const EA_tel = t => { let d = String(t || '').replace(/\D/g, ''); if (d.startsWith('0090')) d = d.slice(2); if (d.startsWith('0')) d = '90' + d.slice(1); if (/^5\d{9}$/.test(d)) d = '90' + d; return /^905\d{9}$/.test(d) ? d : ''; };
            const EA_gunFark = iso => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || '')); if (!m) return null; const h = new Date(+m[1], m[2] - 1, +m[3]), b = new Date(); b.setHours(0, 0, 0, 0); return Math.round((h - b) / 864e5); };
            async function EA_ozetMetni() {
                const dep = await EA_depoAl(['ebys_last_scan_v1', 'ebys_deadlines_v1', 'ebys_okul_profil_v1']);
                const tarama = dep.ebys_last_scan_v1 || {}, liste = Array.isArray(tarama.list) ? tarama.list : [], sonTar = dep.ebys_deadlines_v1 || {}, prof = dep.ebys_okul_profil_v1 || {};
                const bugun = EA_bugun(), kayitlar = (_0x2a3361 || []).filter(r => r.tarih === bugun);
                const kaydedilen = kayitlar.filter(r => r.numara), atlanan = kayitlar.length - kaydedilen.length;
                const konuBul = no => { const e = liste.find(x => x.docNo === no); return e ? String(e.subject || '').slice(0, 60) : ''; };
                const yaklasan = [], gecen = [];
                for (const [no, v] of Object.entries(sonTar)) {
                    const f = EA_gunFark(v && v.iso); if (f === null) continue;
                    const kalanda = liste.some(x => x.docNo === no);
                    if (f >= 0 && f <= 7 && (kalanda || !liste.length)) yaklasan.push({ f, no, v });
                    else if (f < 0 && f >= -7 && kalanda) gecen.push({ f, no, v });
                }
                yaklasan.sort((a, b) => a.f - b.f);
                const satir = [];
                satir.push('📋 *Evrak Özeti — ' + bugun + '*');
                if (prof.okulAdi || _0x599e9b.okul) satir.push(prof.okulAdi || _0x599e9b.okul);
                satir.push('');
                satir.push('✅ Bugün kaydedilen: ' + kaydedilen.length + ' evrak' + (atlanan ? ' (kaydedilemeyen: ' + atlanan + ')' : ''));
                kaydedilen.slice(0, 5).forEach(r => satir.push('   • ' + String(r.konu || r.dosya).slice(0, 55) + ' — ' + r.numara));
                if (liste.length) satir.push('📥 Gelen evraklar (son tarama ' + (tarama.at ? new Date(tarama.at).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) : '-') + '): ' + liste.length);
                if (yaklasan.length) {
                    satir.push('⏰ Süresi yaklaşan (7 gün): ' + yaklasan.length);
                    yaklasan.slice(0, 6).forEach(x => satir.push('   • ' + (x.f === 0 ? 'BUGÜN' : x.f + ' gün') + ' — ' + (konuBul(x.no) || x.no) + ' (' + (x.v.display || x.v.iso) + ')'));
                }
                if (gecen.length) satir.push('⚠️ Süresi geçmiş ve hâlâ gelen kutusunda: ' + gecen.length);
                if (!yaklasan.length && !gecen.length) satir.push('🟢 Süresi yaklaşan evrak yok.');
                satir.push('');
                satir.push('— Evrak Asistanı');
                return satir.join('\n');
            }
            async function EA_ozetGonder() {
                _0x5b5599('Günlük özet hazırlanıyor…');
                const metin = await EA_ozetMetni();
                const dep = await EA_depoAl(['ebys_admin_staff_v1']);
                const idareci = (Array.isArray(dep.ebys_admin_staff_v1) ? dep.ebys_admin_staff_v1 : []).find(k => /m[uü]d[uü]r/i.test(k.role || '') && !/yard/i.test(k.role || ''));
                const tel = EA_tel(_0x599e9b.ozetTel) || EA_tel(idareci && idareci.phone);
                // telefon yoksa WhatsApp kişi seçtirir
                const url = 'https://api.whatsapp.com/send?' + (tel ? 'phone=' + tel + '&' : '') + 'text=' + encodeURIComponent(metin);
                const eski = _0x583a1c.querySelector('#ozetModal'); if (eski) eski.remove();
                const m = document.createElement('div');
                m.id = 'ozetModal';
                m.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:Segoe UI,Arial,sans-serif';
                m.innerHTML = '<div style="background:#fff;color:#111;border-radius:12px;padding:16px;width:min(460px,92vw);box-shadow:0 10px 40px #0006">'
                    + '<div style="font-weight:700;font-size:16px;margin-bottom:8px">📲 Günlük özet</div>'
                    + '<div style="font-size:12px;color:#555;margin-bottom:6px">' + (tel ? 'Gidecek: +' + tel : 'Telefon tanımlı değil — WhatsApp’ta kişiyi siz seçeceksiniz (Ayarlar → “Günlük özet telefonu”).') + '</div>'
                    + '<textarea id="ozetMetin" style="width:100%;height:240px;box-sizing:border-box;font-size:13px;padding:8px;border:1px solid #cbd5e1;border-radius:8px"></textarea>'
                    + '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:10px">'
                    + '<button id="ozetKopya" style="padding:8px 12px;border-radius:8px;border:1px solid #cbd5e1;background:#f8fafc;cursor:pointer">📋 Kopyala</button>'
                    + '<a id="ozetWa" target="_blank" rel="noopener" style="padding:8px 12px;border-radius:8px;background:#15803d;color:#fff;text-decoration:none;font-weight:700">WhatsApp’ta aç</a>'
                    + '<button id="ozetKapat" style="padding:8px 12px;border-radius:8px;border:1px solid #cbd5e1;background:#fff;cursor:pointer">Kapat</button></div></div>';
                _0x583a1c.appendChild(m);
                const ta = m.querySelector('#ozetMetin'), wa = m.querySelector('#ozetWa');
                ta.value = metin;
                wa.href = url;
                ta.oninput = () => { wa.href = 'https://api.whatsapp.com/send?' + (tel ? 'phone=' + tel + '&' : '') + 'text=' + encodeURIComponent(ta.value); };
                m.querySelector('#ozetKopya').onclick = async () => { try { await navigator.clipboard.writeText(ta.value); _0x5b5599('Özet panoya kopyalandı.', 'ok'); } catch (e) { ta.select(); document.execCommand && document.execCommand('copy'); } };
                wa.onclick = () => { _0x599e9b.ozetSon = EA_bugun(); _0x381096(); _0x5b5599('WhatsApp açıldı; Gönder’e siz basın.', 'ok'); setTimeout(() => m.remove(), 300); };
                m.querySelector('#ozetKapat').onclick = () => m.remove();
                m.onclick = e => { if (e.target === m) m.remove(); };
                _0x5b5599('Günlük özet hazır (' + metin.split('\n').length + ' satır).', 'ok');
            }
            function EA_ozetHatirlat() {
                const saat = +(_0x599e9b.ozetSaat || 16);
                if (new Date().getHours() >= saat && _0x599e9b.ozetSon !== EA_bugun()) {
                    _0x5b5599('🔔 Günlük özet henüz gönderilmedi — Araçlar’dan “📲 Günlük özet” ile müdüre gönderebilirsiniz.');
                    const b = _0x188591('#ozetwa'); if (b) b.style.boxShadow = '0 0 0 3px #f59e0b';
                }
            }
            /* 3) Okul ortak paketi: şablonlar, kurallar, öğrenilen konu kodları, idareciler (TC numaraları HARİÇ) */
            async function EA_ortakPaketHazirla() {
                const dep = await EA_depoAl(['ebys_reply_templates_v2', 'ebys_admin_staff_v1', 'ebys_okul_profil_v1']);
                return {
                    tip: 'EA_ORTAK_v1', at: new Date().toISOString(), surum: EA_SURUM,
                    okul: (dep.ebys_okul_profil_v1 && dep.ebys_okul_profil_v1.okulAdi) || _0x599e9b.okul || '',
                    sablonlar: dep.ebys_reply_templates_v2 || {},
                    idareciler: (dep.ebys_admin_staff_v1 || []).map(k => ({ id: k.id, name: k.name, role: k.role, phone: k.phone })),
                    kayit: { rules: _0x599e9b.rules || '', havaleRules: _0x599e9b.havaleRules || '', gorevler: _0x599e9b.gorevler || '', katalog: _0x599e9b.katalog || '', learned: _0x599e9b.learned || {}, kisiler: (_0x599e9b.kisiler || []).map(k => ({ ad: k.ad, on: k.on })) }
                };
            }
            const EA_satirBirlesim = (a, b) => { const s = new Set(String(a || '').split('\n').map(x => x.trim()).filter(Boolean)); const ek = String(b || '').split('\n').map(x => x.trim()).filter(x => x && !s.has(x)); return { metin: [...s, ...ek].join('\n'), yeni: ek.length }; };
            async function EA_ortakPaketUygula(p) {
                if (!p || p.tip !== 'EA_ORTAK_v1') throw new Error('Bu dosya Evrak Asistanı ortak paketi değil');
                const say = { sablon: 0, idareci: 0, kural: 0, ogrenilen: 0, kisi: 0 };
                const dep = await EA_depoAl(['ebys_reply_templates_v2', 'ebys_admin_staff_v1']);
                const sab = Object.assign({}, dep.ebys_reply_templates_v2 || {});
                for (const [k, v] of Object.entries(p.sablonlar || {})) if (!(k in sab)) { sab[k] = v; say.sablon++; }
                const idr = Array.isArray(dep.ebys_admin_staff_v1) ? dep.ebys_admin_staff_v1.slice() : [];
                for (const k of p.idareciler || []) if (k && k.name && !idr.some(x => (EA_tel(x.phone) && EA_tel(x.phone) === EA_tel(k.phone)) || _0x3c029d(x.name) === _0x3c029d(k.name))) { idr.push(k); say.idareci++; }
                await EA_depoYaz({ ebys_reply_templates_v2: sab, ebys_admin_staff_v1: idr });
                const ky = p.kayit || {};
                for (const alan of ['rules', 'havaleRules', 'gorevler', 'katalog']) { const r = EA_satirBirlesim(_0x599e9b[alan], ky[alan]); _0x599e9b[alan] = r.metin; say.kural += r.yeni; }
                _0x599e9b.learned = _0x599e9b.learned || {};
                for (const [k, v] of Object.entries(ky.learned || {})) if (!_0x599e9b.learned[k]) { _0x599e9b.learned[k] = v; say.ogrenilen++; }
                _0x599e9b.kisiler = _0x599e9b.kisiler || [];
                for (const k of ky.kisiler || []) if (k && k.ad && !_0x599e9b.kisiler.some(x => _0x3c029d(x.ad) === _0x3c029d(k.ad))) { _0x599e9b.kisiler.push({ ad: k.ad, on: k.on !== false, tc: '' }); say.kisi++; }
                _0x381096();
                ['rules', 'havaleRules', 'gorevler', 'katalog'].forEach(a => { const el = _0x188591('#s_' + a); if (el) el.value = _0x599e9b[a]; });
                return say;
            }
            async function EA_ortakDosyaIzni(h) { try { if ((await h.queryPermission({ mode: 'readwrite' })) === 'granted') return true; return (await h.requestPermission({ mode: 'readwrite' })) === 'granted'; } catch (e) { return false; } }
            async function EA_ortakEsitle() {
                let h = null;
                try { h = await _0x4e6ff2.get('ortakDir'); } catch (e) {}
                if (!h) {
                    _0x5b5599('Ortak klasör seçin: okulda herkesin eriştiği bir klasör (ör. Google Drive / OneDrive / okul ağ klasörü).');
                    try { h = await window.showDirectoryPicker({ mode: 'readwrite' }); await _0x4e6ff2.set('ortakDir', h); } catch (e) { return _0x5b5599('Ortak klasör seçilmedi.', 'err'); }
                }
                if (!(await EA_ortakDosyaIzni(h))) return _0x5b5599('Ortak klasöre izin verilmedi.', 'err');
                const ad = 'evrak_asistani_ortak.json';
                let gelen = null;
                try { gelen = JSON.parse(await (await (await h.getFileHandle(ad)).getFile()).text()); } catch (e) {}
                let mesaj = '“' + h.name + '” klasörü: ';
                if (gelen) {
                    try { const s = await EA_ortakPaketUygula(gelen); mesaj += 'alınan → ' + s.sablon + ' şablon, ' + s.idareci + ' idareci, ' + s.kural + ' kural satırı, ' + s.ogrenilen + ' öğrenilmiş konu, ' + s.kisi + ' kişi. '; }
                    catch (e) { _0x5b5599('Ortak paket okunamadı: ' + (e.message || e), 'err'); }
                }
                const paket = await EA_ortakPaketHazirla();
                const yaz = await (await h.getFileHandle(ad, { create: true })).createWritable();
                await yaz.write(JSON.stringify(paket, null, 1));
                await yaz.close();
                _0x5b5599(mesaj + 'Birleşmiş paket klasöre yazıldı. Şablonların EBYS panelinde görünmesi için sayfayı yenileyin (F5).', 'ok');
            }
            async function EA_ortakDisaAktar() {
                _0x2ac833('evrak_asistani_ortak.json', JSON.stringify(await EA_ortakPaketHazirla(), null, 1), 'application/json');
                _0x5b5599('Ortak paket indirildi (TC numaraları dahil değildir). Diğer idareci “📥 Paket al” ile ekleyebilir.', 'ok');
            }
            /* 4) Aylık rapor */
            function EA_aylikRaporHtml(ayAnahtar) {
                const kayitlar = (_0x2a3361 || []).filter(r => /^\d{2}\.\d{2}\.\d{4}$/.test(r.tarih || ''));
                const ayOf = r => r.tarih.slice(6, 10) + '-' + r.tarih.slice(3, 5);
                const aylar = [...new Set(kayitlar.map(ayOf))].sort().reverse();
                const ay = ayAnahtar || aylar[0] || (new Date().getFullYear() + '-' + String(new Date().getMonth() + 1).padStart(2, '0'));
                const dk = +(_0x599e9b.dakikaKazanc || 4);
                const buAy = kayitlar.filter(r => ayOf(r) === ay), ok = buAy.filter(r => r.numara), hata = buAy.length - ok.length;
                const gunler = {}; ok.forEach(r => { gunler[r.tarih] = (gunler[r.tarih] || 0) + 1; });
                const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
                const kelime = {}; ok.forEach(r => String(r.konu || '').toLocaleLowerCase('tr').split(/[^a-zçğıöşü]+/).filter(w => w.length > 3 && !/hakk|ilgil|ilişk|talep/.test(w)).forEach(w => { kelime[w] = (kelime[w] || 0) + 1; }));
                const enCok = Object.entries(kelime).sort((a, b) => b[1] - a[1]).slice(0, 10);
                const sure = ok.length * dk, saat = (sure / 60).toFixed(1);
                const ayAd = (() => { const [y, m] = ay.split('-'); return ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'][+m - 1] + ' ' + y; })();
                const ozetSatir = aylar.slice(0, 12).map(a => { const k = kayitlar.filter(r => ayOf(r) === a && r.numara).length; return '<tr><td>' + a + '</td><td>' + k + '</td><td>' + ((k * dk) / 60).toFixed(1) + ' saat</td></tr>'; }).join('');
                return '<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>Evrak Asistanı — ' + ayAd + ' raporu</title><style>body{font-family:Segoe UI,Arial,sans-serif;max-width:860px;margin:30px auto;color:#1f2937}h1{color:#0d47a1;margin-bottom:4px}.k{display:inline-block;margin:10px 14px 10px 0;padding:14px 18px;border:1px solid #cbd5e1;border-radius:10px;min-width:150px}.k b{display:block;font-size:28px;color:#0d47a1}table{border-collapse:collapse;width:100%;margin:10px 0 24px}td,th{border:1px solid #e2e8f0;padding:6px 8px;text-align:left}th{background:#f1f5f9}.not{color:#64748b;font-size:12px}@media print{button{display:none}}</style></head><body>'
                    + '<h1>Evrak Asistanı — ' + ayAd + '</h1><div>' + esc(_0x599e9b.okul || '') + '</div>'
                    + '<div class="k">Kaydedilen evrak<b>' + ok.length + '</b></div><div class="k">Tahmini kazanılan süre<b>' + saat + ' saat</b></div><div class="k">Kaydedilemeyen / atlanan<b>' + hata + '</b></div>'
                    + '<p class="not">Süre tahmini: evrak başına ' + dk + ' dakika (Ayarlar’dan değiştirilebilir). Yalnızca Evrak Kayıt modülünün kayıtları sayılır.</p>'
                    + '<h3>Günlere göre</h3><table><tr><th>Tarih</th><th>Kaydedilen</th></tr>' + Object.entries(gunler).sort((a, b) => a[0].split('.').reverse().join('').localeCompare(b[0].split('.').reverse().join(''))).map(([g, n]) => '<tr><td>' + g + '</td><td>' + n + '</td></tr>').join('') + '</table>'
                    + (enCok.length ? '<h3>En sık konular</h3><table><tr><th>Kelime</th><th>Evrak</th></tr>' + enCok.map(([w, n]) => '<tr><td>' + esc(w) + '</td><td>' + n + '</td></tr>').join('') + '</table>' : '')
                    + '<h3>Aylara göre</h3><table><tr><th>Ay</th><th>Kaydedilen</th><th>Tahmini süre</th></tr>' + ozetSatir + '</table>'
                    + '<h3>Bu ayın kayıtları</h3><table><tr><th>Tarih</th><th>Saat</th><th>Konu</th><th>Numara / durum</th></tr>' + buAy.map(r => '<tr><td>' + esc(r.tarih) + '</td><td>' + esc(r.saat) + '</td><td>' + esc(r.konu || r.dosya) + '</td><td>' + esc(r.numara || r.durum) + '</td></tr>').join('') + '</table>'
                    + '<button onclick="print()">🖨 Yazdır / PDF</button><p class="not">Oluşturma: ' + new Date().toLocaleString('tr-TR') + ' · Evrak Asistanı v' + EA_SURUM + '</p></body></html>';
            }
            function EA_aylikRapor() {
                const html = EA_aylikRaporHtml();
                const ay = new Date().toISOString().slice(0, 7);
                _0x2ac833('evrak_asistani_rapor_' + ay + '.html', html, 'text/html;charset=utf-8');
                _0x5b5599('Aylık rapor indirildi (tarayıcıda açıp Yazdır → PDF yapabilirsiniz).', 'ok');
            }
            _0x188591('#ozetwa').onclick = () => EA_ozetGonder().catch(e => _0x5b5599('Özet: ' + (e.message || e), 'err'));
            _0x188591('#ortaksync').onclick = () => EA_ortakEsitle().catch(e => _0x5b5599('Ortak klasör: ' + (e.message || e), 'err'));
            _0x188591('#ortakdl').onclick = () => EA_ortakDisaAktar().catch(e => _0x5b5599('Ortak paket: ' + (e.message || e), 'err'));
            _0x188591('#ortakal').onclick = () => _0x188591('#ortakfile').click();
            _0x188591('#ortakfile').onchange = async ev => {
                const f = ev.target.files[0]; ev.target.value = '';
                if (!f) return;
                try { const s = await EA_ortakPaketUygula(JSON.parse(await f.text())); _0x5b5599('Paket eklendi: ' + s.sablon + ' şablon, ' + s.idareci + ' idareci, ' + s.kural + ' kural satırı, ' + s.ogrenilen + ' öğrenilmiş konu, ' + s.kisi + ' kişi. Sayfayı yenileyin (F5).', 'ok'); }
                catch (e) { _0x5b5599('Paket alınamadı: ' + (e.message || e), 'err'); }
            };
            _0x188591('#rapor').onclick = () => { try { EA_aylikRapor(); } catch (e) { _0x5b5599('Rapor: ' + (e.message || e), 'err'); } };
            setTimeout(() => { try { EA_ozetHatirlat(); EA_uzakDurum().then(u => { if (u.yeni) _0x5b5599('🔔 Yeni sürüm var: v' + u.s.guncelSurum + (u.s.indirmeAdresi ? ' — ' + u.s.indirmeAdresi : ''), 'err'); if (!u.izin) _0x5b5599('⛔ Evrak Kayıt bu sürümde kapalı: ' + (u.s.mesaj || 'güncelleme gerekiyor'), 'err'); }); } catch (e) {} }, 4000);

            _0x188591("#tani").onclick = async () => {
                let _unused_p2qi;
                for (let _0x1b4894 = 0x8; _0x1b4894 > 0x0; _0x1b4894--) {
                    _0x5b5599("Tanı " + _0x1b4894 + " sn sonra… (alana yazıp listeyi açık bırakın)");
                    await _0x4e51ef(0x3e8);
                }
                const _0x56d08c = _0x1abda4();
                _0x5b5599("Tanı hazır, dosya indirildi.", 'ok');
                _0x2ac833('evrak_tani.txt', _0x56d08c);
            };
            _0x188591('#clr').onclick = () => {
                let _unused_z17x;
                window.__ekIki("clr", this) && (_0x2a3361 = [], _0x381096(), _0x4fe213());
            };
            _0x188591("#xlskat").onclick = () => _0x188591("#xlsfile").click();
            _0x188591("#xlsfile").onchange = async ev => {
                const f = ev.target.files[0];
                ev.target.value = '';
                if (!f) return;
                try {
                    const { satirlar, sayfa } = await EA_xlsxKodlari(f);
                    if (!satirlar.length) throw new Error('Excel’de kod satırı bulunamadı (A sütunu kod, B sütunu konu olmalı)');
                    const harita = new Map();
                    for (const l of (_0x599e9b.katalog || '').split('\n')) { const m = /^\s*(\d[\d.]*)\s*[|\t ]\s*(.+)$/.exec(l); if (m) harita.set(EA_KONU_KODU.kodNorm(m[1]), m[1] + '|' + m[2].trim()); else if (l.trim()) harita.set('#' + l, l); }
                    let yeni = 0;
                    for (const l of satirlar) { const k = EA_KONU_KODU.kodNorm(l.split('|')[0]); if (!harita.has(k)) yeni++; harita.set(k, l); }
                    _0x599e9b.katalog = [...harita.values()].join('\n');
                    _0x381096();
                    _0x188591("#s_katalog").value = _0x599e9b.katalog;
                    _0x5b5599(f.name + ': ' + sayfa + ' sayfadan ' + satirlar.length + ' desimal kod okundu (' + yeni + ' yeni). Hepsi hafızaya alındı.', 'ok');
                } catch (e) {
                    _0x5b5599('Excel okunamadı: ' + (e.message || e), 'err');
                }
            };
            _0x188591("#kat").onclick = async () => {
                let _unused_zlfi;
                for (let _0x1b79c7 = 0x8; _0x1b79c7 > 0x0; _0x1b79c7--) {
                    _0x5b5599("Liste kaydı " + _0x1b79c7 + " sn sonra… Konu Kodu kutusuna bir harf yazıp listeyi açık bırakın");
                    await _0x4e51ef(0x3e8);
                }
                const _0x194aff = [];
                _0x52dd5d().forEach(_0x5bb18b => _0x5bb18b.querySelectorAll('.lovItemTitle').forEach(_0x17cf3c => {
                    let _unused_z5p9;
                    if (_0x30d46f(_0x17cf3c)) {
                        _0x194aff.push(_0x17cf3c.textContent.trim());
                    }
                }));
                const _0x1c264d = new Set((_0x599e9b.katalog || '').split('\x0a').map(_0x407609 => _0x3c029d(_0x46c02f(_0x407609)))), _0x3b0e45 = [...new Set(_0x194aff)].filter(_0x10cc8d => !_0x1c264d.has(_0x3c029d(_0x46c02f(_0x10cc8d))));
                _0x599e9b.katalog = ((_0x599e9b.katalog || '') + '\x0a' + _0x3b0e45.join('\x0a')).trim();
                _0x381096();
                _0x188591("#s_katalog").value = _0x599e9b.katalog;
                _0x5b5599(_0x194aff.length + ' öğe görüldü, ' + _0x3b0e45.length + " yeni konu kataloğa eklendi.", _0x3b0e45.length ? 'ok' : 'err');
            };
            _0x188591("#dirpdf").onclick = async () => {
                let _unused_5jea;
                try {
                    if (!_0x4f3a1d) {
                        await _0x1a6f14();
                    }
                    if (!_0x4f3a1d) {
                        return;
                    }
                    let _0x48b68b = 0x0;
                    for await (const [_0x395a97, _0x25d105] of _0x4f3a1d.entries()) {
                        if (_0x25d105.kind !== "file" || !_0x54cf10.test(_0x395a97)) {
                            continue;
                        }
                        const _0x2cfffd = await _0x25d105.getFile();
                        if (_0x47a824.some(_0xce0507 => _0x2eb48b(_0xce0507.file) === _0x2eb48b(_0x2cfffd)) || _0x8a5ae1(_0x2cfffd)) {
                            continue;
                        }
                        await _0x5dd507(_0x2cfffd);
                        _0x48b68b++;
                    }
                    _0x5b5599(_0x48b68b + " PDF klasörden alındı.", 'ok');
                }
                catch (_0x4bd169) {
                    _0x5b5599("Klasörden PDF alınamadı: " + _0x4bd169.message, "err");
                }
            };
            _0x188591("#kisiEkle").onclick = () => {
                const _0x40d8f3 = _0x188591("#kisiAd").value.trim().replace(/\s+/g, ' '), _0x3d24db = _0x188591("#kisiTc").value.replace(/\D/g, ''), _0x17604b = _0x188591("#kisiUyari");
                _0x17604b.textContent = '';
                if (!_0x40d8f3) {
                    _0x17604b.textContent = "Ad Soyad yazın.";
                    return;
                }
                if (_0x599e9b.kisiler.some(_0x5d1e8c => _0x3c029d(_0x5d1e8c.ad) === _0x3c029d(_0x40d8f3) && (_0x5d1e8c.tc || '') === _0x3d24db)) {
                    _0x17604b.textContent = "Bu kişi zaten listede.";
                    return;
                }
                if (!_0x7c92c3(_0x3d24db)) {
                    _0x17604b.textContent = "Uyarı: TC 11 haneli değil. Kaydedildi ama TC ile arama yapılmayacak.";
                }
                _0x599e9b.kisiler.push({ 'ad': _0x40d8f3, 'tc': _0x3d24db, 'on': !false });
                _0x381096();
                _0x188591('#kisiAd').value = '';
                _0x188591("#kisiTc").value = '';
                _0x1eddae();
            };
            _0x188591('#kisiTc').onkeydown = _0x2774fd => {
                let _unused_y47h;
                if (_0x2774fd.key === "Enter") {
                    _0x188591("#kisiEkle").click();
                }
            };
            _0x188591("#kisiAd").onkeydown = _0x54717d => {
                let _unused_v95h;
                if (_0x54717d.key === "Enter") {
                    _0x188591("#kisiEkle").click();
                }
            };
            _0x188591("#lrn").onclick = () => {
                let _unused_h1s2;
                window.__ekIki("lrn", this) && (_0x599e9b.learned = {}, _0x381096(), _0x5b5599("Öğrenilenler silindi.", 'ok'));
            };
            _0x188591("#dir").onclick = _0x1a6f14;
            ((() => {
                const _0x38bdd3 = _0x188591("#hd");
                let _0x378e29, _0x2e2c0c, _0x32f887, _0x36aae3, _0x10c752 = false;
                _0x38bdd3.onmousedown = _0x4268af => {
                    let _unused_2f2y;
                    if (_0x4268af.target.tagName === "BUTTON") {
                        return;
                    }
                    _0x10c752 = !false;
                    _0x378e29 = _0x4268af.clientX;
                    _0x2e2c0c = _0x4268af.clientY;
                    const _0x3364e9 = _0x493001.getBoundingClientRect();
                    _0x32f887 = _0x3364e9.left;
                    _0x36aae3 = _0x3364e9.top;
                    _0x4268af.preventDefault();
                };
                document.addEventListener("mousemove", _0x26f2dc => {
                    let _unused_h2fe;
                    if (!_0x10c752) {
                        return;
                    }
                    _0x493001.style.bottom = 'auto';
                    _0x493001.style.left = Math.max(0x0, _0x32f887 + _0x26f2dc.clientX - _0x378e29) + 'px';
                    _0x493001.style.top = Math.max(0x0, _0x36aae3 + _0x26f2dc.clientY - _0x2e2c0c) + 'px';
                });
                document.addEventListener("mouseup", () => _0x10c752 = false);
            })());
            _0x49423a();
            _0x1f3c49();
            window.addEventListener('beforeunload', () => {
                let _unused_vidd;
                if (!_0x9156cd) {
                    return;
                }
                _0x55b20f.push('[' + new Date().toTimeString().slice(0x0, 0x8) + "] ⚠ Sayfa yenileniyor/kapanıyor! Son tıklanan: " + _0x59122a);
                try {
                    _0x2f2f4f.setItem(_0x4ac4b6, JSON.stringify(_0x55b20f));
                }
                catch (_0xf311c7) {
                }
            });
            try {
                chrome.runtime.onMessage.addListener(_0xdc54bd => {
                    let _unused_tadr;
                    if (_0xdc54bd && _0xdc54bd.evrakToggle) {
                        _0x370e01(_0x4785da.style.display === "none");
                    }
                });
            }
            catch (_0x4a2bf9) {
            }
            _0x298cf0();
            _0x4fe213();
            _0x1eddae();
            if (_0x55b20f.length) {
                _0x55b20f.slice(-0x78).forEach(_0x3ad50c => {
                    const _0x32ff0b = document.createElement('div');
                    _0x32ff0b.style.opacity = '.6';
                    _0x32ff0b.textContent = _0x3ad50c;
                    _0x188591("#log").appendChild(_0x32ff0b);
                });
                const _0x2fbb81 = document.createElement('div');
                _0x2fbb81.textContent = '── önceki oturumun sonu ──';
                _0x188591('#log').appendChild(_0x2fbb81);
            }
            const _0x4ddfab = ((() => {
                let _unused_qwn3;
                try {
                    const _0x3a16f6 = _0x4b8741(_0x477b1d);
                    _0x2f2f4f.removeItem(_0x477b1d);
                    return _0x3a16f6;
                }
                catch (_0x4ca5d6) {
                    return null;
                }
            })()), _0x3b01a2 = () => _0x4f8e86() || _0x3c029d(_0x4d6fb0()).includes("evrak islemleri") || location.hostname === "ebys.meb.gov.tr";
            _0x5b5599("Sayfa adresi: " + location.href);
            if (_0x3b01a2()) {
                _0x370e01(_0x599e9b.open);
            }
            else {
                const _0x230e69 = setInterval(() => {
                    let _unused_kmp9;
                    _0x3b01a2() && (clearInterval(_0x230e69), _0x370e01(_0x599e9b.open));
                }, 0x7d0);
            }
            function _0x5b8b47(_0x3c7fe7) {
                const _0x3057a3 = "⚠ Önceki oturum “" + _0x3c7fe7.dosya + "” için “" + _0x3c7fe7.adim + "” adımında kesildi (sayfa yenilendi/kapandı). Evrak kaydedilmemiş olabilir.";
                _0x5b5599(_0x3057a3, "err");
                _0x2a3361.push({ 'numara': '', 'konu': _0x3c7fe7.konu || '', 'dosya': _0x3c7fe7.dosya, 'key': _0x3c7fe7.key || '', 'tarih': _0x4a765d(), 'saat': (_0x3c7fe7.t || '').slice(0x0, 0x5), 'durum': 'Kesildi: ' + _0x3c7fe7.adim + " adımında (sayfa yenilendi) — KAYDEDİLMEMİŞ OLABİLİR" });
                _0x381096();
                _0x4fe213();
            }
            async function _0x575ecd() {
                const _0x25d96b = _0x4b8741(_0x250456);
                if (!_0x25d96b) {
                    return false;
                }
                try {
                    _0x2f2f4f.removeItem(_0x250456);
                }
                catch (_0x57f0e7) {
                }
                let _0x1e5ff8 = '';
                try {
                    const _0xad7e27 = _0x4d6fb0().match(_0x2b939b);
                    if (_0xad7e27 && !_0x2a3361.some(_0x4e6ddb => _0x4e6ddb.numara === _0xad7e27[0x1])) {
                        _0x1e5ff8 = _0xad7e27[0x1];
                    }
                }
                catch (_0x2275cf) {
                }
                _0x2a3361.push({ 'numara': _0x1e5ff8, 'konu': _0x25d96b.konu, 'dosya': _0x25d96b.dosya, 'key': _0x25d96b.key, 'tarih': _0x4a765d(), 'saat': (_0x25d96b.t || '').slice(0x0, 0x5), 'durum': "Kaydedildi (benzer kayıt seçildi)" + (_0x1e5ff8 ? '' : " — numara okunamadı") });
                _0x381096();
                _0x4fe213();
                _0x5b5599("Benzer kayıt seçimi tamamlandı: " + _0x25d96b.dosya + (_0x1e5ff8 ? " → " + _0x1e5ff8 : ''), 'ok');
                return !false;
            }
            async function _0x415b93(_0x376812) {
                let _unused_6z5o;
                await _0x4e51ef(0x9c4);
                if (await _0x575ecd()) {
                }
                else {
                    if (_0x376812) {
                        const _0x2fd1c4 = /kaydet/i.test(_0x376812.adim) ? _0x6fe78d() : null;
                        if (_0x2fd1c4) {
                            try {
                                _0x2f2f4f.setItem(_0x250456, JSON.stringify({ 'key': _0x376812.key || '', 'dosya': _0x376812.dosya, 'konu': _0x376812.konu || '', 't': _0x376812.t || '' }));
                            }
                            catch (_0x12745b) {
                            }
                            _0x5b5599("Sayfa yenilendi: benzer kayıt uyarısı görünüyor, seçiliyor…", "err");
                            try {
                                await _0x20fe20(_0x2fd1c4);
                                await _0x4e51ef(0xdac);
                                await _0x575ecd();
                            }
                            catch (_0x2c0d20) {
                                try {
                                    _0x2f2f4f.removeItem(_0x250456);
                                }
                                catch (_0x167519) {
                                }
                                _0x5b5599("Benzer kayıt seçilemedi: " + (_0x2c0d20.message || _0x2c0d20), 'err');
                                _0x5b8b47(_0x376812);
                            }
                        }
                        else {
                            _0x5b8b47(_0x376812);
                        }
                    }
                }
                const _0x2ff92e = _0x4b8741(_0x5497e8);
                if (_0x2ff92e && _0x2ff92e.active) {
                    if (!_0x4f3a1d) {
                        _0x5b5599('Yarım kalan toplu işlem var ama klasör hatırlanamadı; ⚡ ile yeniden başlatın.', "err");
                        try {
                            _0x2f2f4f.removeItem(_0x5497e8);
                        }
                        catch (_0x101302) {
                        }
                        return;
                    }
                    _0x5b5599('Yarım kalan toplu işlem kaldığı yerden sürdürülüyor…', 'ok');
                    _0x2c4193({ 'resume': !false, 'iso': _0x2ff92e.iso });
                }
            }
            _0x189728.then(() => _0x415b93(_0x4ddfab));
        })());
    };
    let _0x51d72c = false, _0x18fbcc = false;
    const _0x5ae350 = async () => {
        let _unused_cvly;
        if (_0x51d72c) {
            return;
        }
        let _0x117d48 = {};
        try {
            _0x117d48 = await chrome.storage.local.get(["ebys_evrak_kayit_on_v1", _0x56145f, "ebys_okul_profil_v1"].concat(_0x1a2078)) || {};
        }
        catch (_0x549ff9) {
            return;
        }
        if (_0x117d48.ebys_evrak_kayit_on_v1 === false) {
            return;
        }
        if (!_0x1de1cd(_0x117d48[_0x56145f])) {
            _0x14d6ac();
            if (!_0x18fbcc) {
                _0x18fbcc = !false;
                try {
                    chrome.storage.onChanged.addListener((_0x4cc4e0, _0x302fa2) => {
                        let _unused_blb9;
                        if (_0x302fa2 && _0x302fa2 !== "local") {
                            return;
                        }
                        if (_0x4cc4e0[_0x56145f] && _0x1de1cd(_0x4cc4e0[_0x56145f].newValue)) {
                            const _0x36df7a = document.getElementById("ek-onay-notu");
                            if (_0x36df7a) {
                                _0x36df7a.remove();
                            }
                            _0x5ae350();
                        }
                    });
                }
                catch (_0x85bdb8) {
                }
            }
            return;
        }
        if (_0x51d72c) {
            return;
        }
        _0x51d72c = !false;
        _0x1a2078.forEach(_0x5ce98e => {
            if (_0x117d48[_0x5ce98e] !== undefined) {
                _0x5883e2[_0x5ce98e] = _0x117d48[_0x5ce98e];
            }
        });
        try {
            const _0x234cfd = _0x117d48.ebys_okul_profil_v1 || (await chrome.storage.local.get(["ebys_okul_profil_v1"])).ebys_okul_profil_v1;
            if (_0x234cfd && (_0x234cfd.kayitHavaleVarsayilan || _0x234cfd.okulAdi)) {
                const _0x223ec0 = JSON.parse(_0x5883e2[_0x32f781] || 'null') || {};
                _0x223ec0.settings = Object.assign({}, _0x223ec0.settings || {});
                if (!_0x223ec0.settings.okul) {
                    _0x223ec0.settings.okul = _0x234cfd.kayitHavaleVarsayilan || _0x234cfd.okulAdi;
                    _0x5883e2[_0x32f781] = JSON.stringify(_0x223ec0);
                    try {
                        await chrome.storage.local.set({ [_0x32f781]: _0x223ec0 });
                    }
                    catch (_0x3a9252) {
                    }
                }
            }
        }
        catch (_0x35a739) {
        }
        await _0x476575();
        try {
            _0x4a2258();
        }
        catch (e) {
            // v3.6.71: Evrak Kayıt paneli açılamazsa sessizce kaybolmasın — sol altta hatayı göster
            try {
                console.error('[Evrak Kayıt] panel açılamadı', e);
                const kutu = document.createElement('div');
                kutu.id = 'evrak-otonom-hata';
                kutu.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:2147483647;max-width:420px;background:#7f1d1d;color:#fff;font:13px Segoe UI,Arial,sans-serif;padding:10px 12px;border-radius:10px;box-shadow:0 6px 18px #0007;white-space:pre-wrap;cursor:pointer';
                kutu.textContent = '⚠️ Evrak Kayıt paneli açılamadı (v' + chrome.runtime.getManifest().version + ').\n' + String((e && e.stack) || e).split('\n').slice(0, 3).join('\n') + '\n\n(Tıklayınca kopyalanır — bu metni geliştiriciye gönderin.)';
                kutu.onclick = () => { try { navigator.clipboard.writeText(kutu.textContent); } catch (x) {} };
                (document.body || document.documentElement).appendChild(kutu);
            } catch (x) {}
        }
    };
    _0x5ae350();
}()));
