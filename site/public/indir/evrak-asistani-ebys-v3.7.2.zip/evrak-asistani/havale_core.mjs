// Evrak Asistanı — havale çekirdeği (content.js içindeki kopyayla AYNI kaynak: v34src/havale_core.js)
const HavaleCore = (function() {
    // ---- Evrak Asistanı havale çekirdeği (v3.4): Türkçe eşleştirme, hazır anahtar kelime setleri, kural deposu, yönlendirme, görev dağılımı ayrıştırma.
    // Tek kaynak: hem content.js'e hem setup sayfasına (havale_core.js) aynen gömülür. Gerçek kişi adı / okula özgü kural İÇERMEZ.
    const RULES_KEY = "ebys_havale_rules_v1";
    const RULES_FILE_TYPE = "evrak-asistani-havale-kurallari";
    const KEYWORD_SETS = [
        { id: "isg", label: "İSG / İş Güvenliği", keywords: ["isg", "iş sağlığı", "iş güvenliği", "risk değerlendirmesi", "acil durum", "tatbikat", "yangın", "deprem", "sivil savunma"] },
        { id: "personel", label: "Personel İşleri", keywords: ["personel", "izin", "rapor", "görevlendirme", "atama", "ek ders", "maaş", "özlük", "mesai", "nöbet", "hizmet içi eğitim", "disiplin", "sicil"] },
        { id: "sosyal", label: "Sosyal Etkinlikler / Kulüpler / TÜBİTAK", keywords: ["sosyal etkinlik", "sosyal faaliyet", "kulüp", "tübitak", "proje", "yarışma", "olimpiyat", "gezi", "şenlik", "tiyatro", "sergi", "çevre", "e-twinning", "etwinning", "erasmus", "bilim fuarı", "toplum hizmeti"] },
        { id: "kantin", label: "Kantin / Öğrenci Sözleşmeleri", keywords: ["kantin", "kafeterya", "kira", "ihale", "kantin işletme", "hijyen", "gıda", "beslenme", "sözleşme", "öğrenci sözleşmesi", "veli sözleşmesi"] },
        { id: "ogrenci", label: "Öğrenci İşleri / Devamsızlık / Nakil / Burs", keywords: ["öğrenci işleri", "devamsızlık", "nakil", "burs", "mezuniyet", "diploma", "öğrenci belgesi", "karne", "sınıf geçme"] },
        { id: "sinav", label: "Sınav / Ölçme Değerlendirme", keywords: ["sınav", "ölçme değerlendirme", "ortak sınav", "lgs", "yks", "e-sınav", "sınav görevlisi"] },
        { id: "tasima", label: "Taşımalı Eğitim / Servis", keywords: ["taşımalı eğitim", "taşıma", "servis", "okul servis"] },
        { id: "rehberlik", label: "Rehberlik", keywords: ["rehberlik", "psikolojik danışma", "rehber öğretmen", "ram", "kariyer", "akran zorbalığı"] },
        { id: "bilgiislem", label: "Bilgi İşlem / e-Okul / MEBİS", keywords: ["bilgi işlem", "e-okul", "mebis", "mebbis", "eba", "internet", "bilgisayar", "etkileşimli tahta", "siber"] },
        { id: "tasinir", label: "Taşınır / Demirbaş / Satın Alma / Bütçe", keywords: ["taşınır", "demirbaş", "satın alma", "bütçe", "ödenek", "harcama", "fatura", "muhasebe", "tif", "kbs"] },
        { id: "temizlik", label: "Temizlik / Bakım / Onarım", keywords: ["temizlik", "bakım", "onarım", "tadilat", "tesisat", "bahçe", "ısınma", "yakıt", "kalorifer"] },
        { id: "pansiyon", label: "Pansiyon", keywords: ["pansiyon", "yatılı", "belletmen", "iaşe"] },
        { id: "saglik", label: "Pandemi / Sağlık", keywords: ["pandemi", "salgın", "sağlık", "aşı", "bulaşıcı hastalık", "okul sağlığı", "beyaz bayrak"] }
    ];
    const isObj = v => v !== null && typeof v === "object" && !Array.isArray(v);
    const DIA = { "ç": "c", "ğ": "g", "ı": "i", "ö": "o", "ş": "s", "ü": "u", "â": "a", "î": "i", "û": "u" };
    function fold(s, dia) {
        let t = String(s || "").toLocaleLowerCase("tr").normalize("NFC");
        if (dia !== false) t = t.replace(/[çğıöşüâîû]/g, c => DIA[c]).normalize("NFD").replace(/[\u0300-\u036f]/g, "");
        return t;
    }
    function tokenize(s, dia) { return fold(s, dia).split(/[^0-9a-zçğıöşüâîû]+/).filter(Boolean); }
    function soften(w, dia) {
        if (w.length < 4) return null;
        if (/nk$/.test(w)) return w.slice(0, -1) + "g";
        const last = w.slice(-1);
        const m = { p: "b", t: "d", "ç": "c", k: dia === false ? "ğ" : "g" }[last];
        return m ? w.slice(0, -1) + m : null;
    }
    function compileKeyword(kw, dia) {
        const words = tokenize(kw, dia);
        if (!words.length) return null;
        return { kw: String(kw).trim(), words: words.map(w => ({ w: w, exact: w.length <= 3, stems: [w, soften(w, dia)].filter(Boolean) })) };
    }
    const tokMatch = (tok, w) => (w.exact ? tok === w.w : w.stems.some(s => tok.startsWith(s)));
    function matchCompiled(tokens, c) {
        if (!c) return false;
        const n = c.words.length;
        for (let i = 0; i + n <= tokens.length; i++) {
            let ok = true;
            for (let j = 0; j < n && ok; j++) ok = tokMatch(tokens[i + j], c.words[j]);
            if (ok) return true;
        }
        return false;
    }
    function matchKeyword(text, kw, dia) { return matchCompiled(tokenize(text, dia), compileKeyword(kw, dia)); }
    function splitList(s) { return String(s || "").split(/[,;\n]+/).map(x => x.trim()).filter(Boolean); }
    function uniqFold(list) { const seen = new Set(), out = []; list.forEach(x => { const k = fold(x); if (k && !seen.has(k)) { seen.add(k); out.push(x); } }); return out; }
    let idSeq = 0;
    const newId = () => "r" + Date.now().toString(36) + (++idSeq).toString(36) + Math.random().toString(36).slice(2, 6);
    // ---- kural deposu (doğrulama / temizleme)
    function sanitizeRules(v) {
        const s = isObj(v) ? v : {};
        const str = (x, n) => (typeof x === "string" ? x.slice(0, n).trim() : "");
        const list = (x, n) => (Array.isArray(x) ? x : typeof x === "string" ? splitList(x) : []).filter(y => typeof y === "string").map(y => y.trim().slice(0, 120)).filter(Boolean).slice(0, n || 300);
        const target = t => ({ name: str(isObj(t) ? t.name : "", 120), titles: list(isObj(t) ? t.titles : [], 5) });
        const prio = p => (Number.isFinite(+p) ? Math.max(-99, Math.min(99, Math.round(+p))) : 0);
        const rules = (Array.isArray(s.rules) ? s.rules : []).filter(isObj).slice(0, 200).map(r => ({
            id: str(r.id, 40) || newId(), enabled: r.enabled !== false, role: str(r.role, 80), target: target(r.target),
            type: r.type === "B" ? "B" : "G", keywords: uniqFold(list(r.keywords)), negative: uniqFold(list(r.negative)), priority: prio(r.priority), source: str(r.source, 20)
        })).filter(r => r.target.name || r.target.titles.length);
        const globalBilgi = (Array.isArray(s.globalBilgi) ? s.globalBilgi : []).filter(isObj).slice(0, 20).map(g => ({
            id: str(g.id, 40) || newId(), enabled: g.enabled !== false, role: str(g.role, 80), target: target(g.target)
        })).filter(g => g.target.name || g.target.titles.length);
        const o = isObj(s.options) ? s.options : {};
        return { rules: rules, globalBilgi: globalBilgi, options: { threshold: Math.max(1, Math.min(50, Math.round(+o.threshold) || 3)), foldDiacritics: o.foldDiacritics !== false }, template: sanitizeTemplate(s.template, rules) };
    }
    // ---- v3.6.29: ortak MADDE ŞABLONU (her madde tek konu; birleşik maddeler ayrıldı). Kişi adı İÇERMEZ.
    const ITEM_TEMPLATE = [
        ["isg", "İSG / İş Güvenliği", "isg, iş sağlığı, iş güvenliği, risk değerlendirmesi, ramak kala, iş kazası"],
        ["sivilsavunma", "Sivil Savunma / Acil Durum / Tatbikat", "sivil savunma, acil durum, tatbikat, yangın, deprem, afet"],
        ["personel", "Personel İşleri / Özlük", "personel, özlük, sicil, kişisel dosya, hizmet belgesi"],
        ["izin", "İzin / Rapor", "izin, rapor, sağlık raporu, yıllık izin, mazeret izni"],
        ["gorevlendirme", "Görevlendirme / Atama", "görevlendirme, atama, ders görevi, norm kadro"],
        ["ekders", "Ek Ders / Maaş / Tahakkuk", "ek ders, maaş, yan ödeme, tahakkuk, ücret onay, ödeme tahakkuk, gider gerçekleştirme, gerçekleştirme görevlilik, mali ödeme, kbs"],
        ["nobet", "Nöbet / Mesai", "nöbet, nöbet çizelgesi, mesai, fazla mesai"],
        ["hizmetici", "Hizmet İçi Eğitim / Seminer", "hizmet içi eğitim, seminer, mesleki çalışma, mesleki gelişim"],
        ["disiplin", "Disiplin / Soruşturma", "disiplin, soruşturma, inceleme, şikayet"],
        ["toplanti", "Toplantılar / Kurullar", "toplantı, toplant gündemin, öğretmenler kurulu, zümre, şube öğretmenler kurulu"],
        ["stratejik", "Stratejik Plan / Kalite", "stratejik plan, faaliyet raporu, iç kontrol, kalite"],
        ["sosyal", "Sosyal Etkinlikler", "sosyal etkinlik, sosyal faaliyet, şenlik, tiyatro, sergi, toplum hizmeti, belirli gün"],
        ["kulup", "Öğrenci Kulüpleri", "kulüp, öğrenci kulübü, öğrenci meclisi"],
        ["tubitak", "TÜBİTAK / Bilim Fuarı", "tübitak, bilim fuarı, araştırma projesi, 4006, 2204"],
        ["proje", "Projeler / AR-GE", "proje, arge, araştırma geliştirme, proje araştırma, fikir otobü"],
        ["abproje", "AB Projeleri / Erasmus / eTwinning", "erasmus, e-twinning, etwinning, avrupa, ab projesi, ulusal ajans"],
        ["yarisma", "Yarışmalar / Olimpiyatlar", "yarışma, olimpiyat, ödül, beceri yarışması"],
        ["gezi", "Geziler / İzinli Etkinlikler", "gezi, inceleme gezisi, kamp, gezi izni"],
        ["spor", "Spor / Beden Eğitimi", "beden eğitim, spor, okul sporları, turnuva"],
        ["cevre", "Çevre / Sıfır Atık", "çevre, sıfır atık, geri dönüşüm, enerji tasarrufu"],
        ["web", "Web Sitesi / Sosyal Medya", "web, web sitesi, sosyal medya, haber yayını"],
        ["kantin", "Kantin", "kantin, kafeterya, kantin işletme, kantin denetim"],
        ["sozlesme", "Öğrenci / Veli Sözleşmeleri", "öğrenci sözleşmesi, veli sözleşmesi, sözleşme"],
        ["kiraihale", "Kira / İhale", "kira, ihale, kiralama, kik"],
        ["hijyen", "Hijyen / Gıda / Beslenme", "hijyen, gıda, beslenme, gıda denetim"],
        ["ogrenciisleri", "Öğrenci İşleri", "öğrenci işleri, öğrenci belgesi, kütük defter, not çizelge, kayıt kabul"],
        ["devamsizlik", "Devamsızlık / Özür", "devamsızlık, özür tezkere, devam durumu"],
        ["nakil", "Nakil / Kayıt", "nakil, nakil işlemleri, okula yeni"],
        ["burs", "Burs / Parasız Yatılılık", "burs, pyb, parasız yatılı, bursluluk"],
        ["mezuniyet", "Mezuniyet / Diploma / Denklik", "mezuniyet, diploma, ait denklik, denklik, onur belge"],
        ["karne", "Karne / Sınıf Geçme", "karne, sınıf geçme, sorumluluk sınavı, takdir teşekkür"],
        ["sinav", "Sınavlar / Ölçme Değerlendirme", "sınav, ölçme değerlendirme, ortak sınav, lgs, yks, e-sınav, sınav görevlisi"],
        ["tasima", "Taşımalı Eğitim", "taşımalı eğitim, taşıma, taşımalı"],
        ["servis", "Okul Servisi", "servis, okul servis, öğrenci servis"],
        ["rehberlik", "Rehberlik / Psikolojik Danışma", "rehberlik, psikolojik danışma, rehber öğretmen, danışma servi, akran zorbalığı, kariyer"],
        ["ozelegitim", "Özel Eğitim / BEP / RAM", "bep, ram, özel eğitim, kaynaştırma, destek eğitim"],
        ["dyk", "Destekleme ve Yetiştirme Kursları (DYK)", "dyk, destekleme ve yetiştirme, yetiştirme kursu"],
        ["bilgiislem", "Bilgi İşlem / Donanım / İnternet", "bilgi işlem, internet, bilgisayar, etkileşimli tahta, siber, fatih projesi"],
        ["eokul", "e-Okul", "e-okul, eokul"],
        ["mebbis", "MEBBİS / MEBİS / EBA", "mebbis, mebis, eba, piktes"],
        ["tasinir", "Taşınır / Demirbaş", "taşınır, demirbaş, tif, sayımla, mal yönetmelik, tkys"],
        ["satinalma", "Satın Alma", "satın alma, satınalma, doğrudan temin, yoğaltım malzeme, fotokop maki"],
        ["butce", "Bütçe / Muhasebe / Ödenek", "bütçe, ödenek, harcama, fatura, muhasebe"],
        ["temizlik", "Temizlik / Temiz Okul", "temizlik, temiz-okul, beyaz bayrak"],
        ["bakim", "Bakım / Onarım", "bakım, onarım, tadilat, tesisat"],
        ["bahce", "Bahçe / Çevre Düzenleme", "bahçe, çevre düzenleme, ağaçlandırma"],
        ["isinma", "Isınma / Yakıt", "ısınma, yakıt, kalorifer, doğalgaz"],
        ["pansiyon", "Pansiyon / Yatılılık", "pansiyon, yatılı, belletmen, iaşe"],
        ["saglik", "Okul Sağlığı / Salgın", "okul sağlığı, pandemi, salgın, aşı, bulaşıcı hastalık, sağlık taraması"],
        ["sgk", "SGK / Sigorta", "sgk, sigorta, sigortalılık, işe giriş"],
        ["tefbis", "TEFBİS / Okul Gelirleri", "tefbis, okul gelir, bağış"],
        ["beceri", "İşletmelerde Beceri Eğitimi / Staj", "becer eğitim, işletmelerde beceri, staj, işe yerleştirme, meslek eğitim, teknik eğitimde"],
        ["mtoyk", "Mesleki Kurslar / Yaygın Eğitim", "mtoyk, meslek kurs, yaygın meslek, kurs periyodik, periyodik denetimin"],
        ["atp", "Program / Alan-Dal (ATP)", "atp, anadol teknik, teknik program, alan temrinlik, çerçeve öğretim programı"],
        ["kitap", "Ders Kitabı Dağıtımı", "kitap dağıtımın, ders kitabı, ücretsiz kitap"],
        ["okulaile", "Okul Aile Birliği", "aile birlik, okul aile birliği"],
        ["evrak", "Evrak / Arşiv / Yazı İşleri", "büro memur, gelen-giden evrak, arşiv, örnek dosya, yazılan asıl"],
        ["isku", "İŞKUR / Kamu Yararına Çalışma", "işkur, typ, toplum yararına program"],
        ["stk", "STK / Kurum Dışı İş Birliği", "stk, protokol, iş birliği"],
        ["cocuk", "Çocuk Koruma / Güvenlik", "yaşından küçük, çocuk istismarı, okul güvenliği, koruyucu önleyici"]
    ].map(a => ({ id: a[0], label: a[1], keywords: a[2].split(/\s*,\s*/) }));
    const TPL_SRC = "şablon";
    // şablon: { enabled, items:[{id,label,keywords,custom}], removed:[id], people:[{id,name,titles,assign:{itemId:"G"|"B"},priority,negative,fromRule}] }
    function templateFromRules(rules) {
        const items = ITEM_TEMPLATE.map(x => ({ id: x.id, label: x.label, keywords: x.keywords.slice(), custom: false }));
        const people = [];
        (rules || []).filter(r => r.source !== TPL_SRC).forEach(r => {
            const kws = r.keywords.map(k => fold(k));
            const assign = {}, used = new Set();
            items.forEach(it => { const ik = new Set(it.keywords.map(k => fold(k))); kws.forEach(k => { if (ik.has(k)) { assign[it.id] = r.type; used.add(k); } }); });
            const left = r.keywords.filter(k => !used.has(fold(k)));
            if (left.length) { const cid = "c_" + r.id; items.push({ id: cid, label: (r.role || targetText(r.target)) + " (özel)", keywords: left, custom: true }); assign[cid] = r.type; }
            let p = people.find(x => fold(x.name) === fold(r.target.name) && x.titles.join("|") === r.target.titles.join("|"));
            if (!p) { p = { id: "p_" + r.id, name: r.target.name, titles: r.target.titles.slice(), assign: {}, priority: r.priority, negative: r.negative.slice(), fromRule: [] }; people.push(p); }
            if (r.enabled) { Object.keys(assign).forEach(k => { if (!p.assign[k] || assign[k] === "G") p.assign[k] = assign[k]; }); }
            else p.disabledRules = (p.disabledRules || 0) + 1;
            p.fromRule.push(r.id);
        });
        return { enabled: false, migrated: false, items: items, removed: [], people: people };
    }
    function sanitizeTemplate(t, rules) {
        if (!isObj(t)) return templateFromRules(rules);
        const str = (x, n) => (typeof x === "string" ? x.slice(0, n).trim() : "");
        const list = (x, n) => (Array.isArray(x) ? x : typeof x === "string" ? splitList(x) : []).filter(y => typeof y === "string").map(y => y.trim().slice(0, 120)).filter(Boolean).slice(0, n || 300);
        const seen = new Set();
        const items = (Array.isArray(t.items) ? t.items : []).filter(isObj).map(i => ({ id: str(i.id, 40), label: str(i.label, 80), keywords: uniqFold(list(i.keywords)), custom: !!i.custom }))
            .filter(i => i.id && i.label && !seen.has(i.id) && seen.add(i.id)).slice(0, 300);
        const ids = new Set(items.map(i => i.id));
        const people = (Array.isArray(t.people) ? t.people : []).filter(isObj).slice(0, 100).map(p => {
            const a = {}; if (isObj(p.assign)) Object.keys(p.assign).forEach(k => { if (ids.has(k) && (p.assign[k] === "G" || p.assign[k] === "B")) a[k] = p.assign[k]; });
            const o = { id: str(p.id, 40) || newId(), name: str(p.name, 120), titles: list(p.titles, 5), assign: a, priority: Number.isFinite(+p.priority) ? Math.max(-99, Math.min(99, Math.round(+p.priority))) : 0, negative: uniqFold(list(p.negative)), fromRule: list(p.fromRule, 50) };
            if (+p.disabledRules) o.disabledRules = +p.disabledRules;
            return o;
        }).filter(p => p.name || p.titles.length);
        return { enabled: t.enabled === true, migrated: t.migrated === true, items: items, removed: list(t.removed, 300), people: people };
    }
    // şablon → mevcut kural biçimi (kişi başına Gereği ve Bilgi için birer kural; eşleştirme kodu aynen çalışır)
    function templateToRules(t) {
        const out = [];
        const byId = {}, rm = new Set(t.removed || []); (t.items || []).forEach(i => { if (!rm.has(i.id)) byId[i.id] = i; });
        (t.people || []).forEach(p => {
            ["G", "B"].forEach(ty => {
                const its = Object.keys(p.assign || {}).filter(k => p.assign[k] === ty && byId[k]).map(k => byId[k]);
                if (!its.length) return;
                out.push({ id: "t_" + p.id + "_" + ty, enabled: true, role: its.map(i => i.label).join(", ").slice(0, 80), target: { name: p.name, titles: p.titles.slice() },
                    type: ty, keywords: uniqFold([].concat.apply([], its.map(i => i.keywords))), negative: (p.negative || []).slice(), priority: p.priority || 0, source: TPL_SRC });
            });
        });
        return out;
    }
    // şablonu kurallara uygula: eski şablon kuralları çıkarılır, yenileri eklenir; şablona aktarılmış eski kurallar SİLİNMEZ, yalnızca kapatılır
    function applyTemplate(store) {
        const t = store.template;
        if (!t) return store;
        const wasOn = t.enabled;
        t.enabled = true;
        const from = new Set([].concat.apply([], (t.people || []).map(p => p.fromRule || [])));
        store.rules = store.rules.filter(r => r.source !== TPL_SRC);
        if (!wasOn || !t.migrated) { store.rules.forEach(r => { if (from.has(r.id)) r.enabled = false; }); t.migrated = true; }
        store.rules = store.rules.concat(templateToRules(t));
        return store;
    }
    function isRulesFile(v) { return isObj(v) && (Array.isArray(v.rules) || Array.isArray(v.globalBilgi)); }
    function rulesToFile(store) { return Object.assign({ type: RULES_FILE_TYPE, version: 1, exportedAt: new Date().toISOString() }, sanitizeRules(store)); }
    // ---- kişi çözümleme: ada ve/veya ünvana göre, kişi listesinde TAM OLARAK bir kişi olmalı
    const normP = s => String(s || "").replace(/\s+/g, " ").trim().toLocaleUpperCase("tr");
    const labelOf = p => p.name + (p.title ? " [" + p.title + "]" : "");
    // NEW (v3.6.36): müdür gevşek eşleşme — "Okul Müdürü", "Müdür", "Kurum Müdürü", "Müdür V." ve okul profilindeki müdür adı (yardımcılar hariç)
    let principalName = "";
    function setPrincipal(n) { principalName = String(n || "").trim(); }
    const isMudurTitle = s => { const f = fold(s).replace(/[^a-z ]/g, " ").replace(/\s+/g, " ").trim(); return /\bmudur(u)?\b/.test(f) && !/yard|yrd|bas ?yard/.test(f); };
    function isMudurTarget(t) { return (t.titles || []).some(isMudurTitle); }
    function looseMudur(people) {
        const P = people || [];
        if (principalName) { const pn = fold(principalName).replace(/\s+/g, " "); const h = P.filter(p => fold(p.name).replace(/\s+/g, " ") === pn); if (h.length) return h; }
        const exact = P.filter(p => fold(p.title).replace(/[^a-z]/g, "") === "mudur" || fold(p.title).replace(/[^a-z]/g, "") === "okulmuduru");
        if (exact.length) return exact;
        return P.filter(p => isMudurTitle(p.title));
    }
    function resolveTarget(target, people) {
        const t = target || {};
        const titles = (t.titles || []).map(normP).filter(Boolean);
        const name = normP(t.name);
        if (!name && !titles.length) return { status: "invalid", hits: [] };
        let hits = (people || []).filter(p => (!name || normP(p.name) === name));
        if (titles.length) {
            if (name) { const both = hits.filter(p => titles.includes(normP(p.title))); if (both.length) hits = both; }
            else {
                for (const tt of titles) { const h = (people || []).filter(p => normP(p.title) === tt); if (h.length) { hits = h; break; } else hits = []; }
            }
        }
        if (!hits.length && isMudurTarget(t)) hits = looseMudur(people); // NEW (v3.6.36): Okul Müdürü / Müdür / profil adı gevşek eşleşme
        return { status: hits.length === 1 ? "ok" : hits.length ? "ambiguous" : "notfound", hits: hits, person: hits.length === 1 ? hits[0] : null, label: hits.length === 1 ? labelOf(hits[0]) : "", loose: !!(hits.length && isMudurTarget(t)) };
    }
    function targetText(t) { return [t.name, (t.titles || []).length ? "[" + t.titles.join(" / ") + "]" : ""].filter(Boolean).join(" ") || "-"; }
    // ---- yönlendirme: konu (×3) + gönderen (×1) + evrak metni (×1); eşik altı / eşitlik → öneri yok ("emin değilim")
    function routeDoc(doc, store, people) {
        const st = sanitizeRules(store);
        const dia = st.options.foldDiacritics;
        const F = { konu: tokenize(doc.subject, dia), gonderen: tokenize(doc.gonderen, dia), metin: tokenize(doc.body || "", dia) };
        const W = { konu: 3, gonderen: 1, metin: 1 };
        const scored = [];
        st.rules.filter(r => r.enabled).forEach(r => {
            const why = { konu: [], gonderen: [], metin: [] };
            let score = 0;
            r.keywords.forEach(k => { const c = compileKeyword(k, dia); Object.keys(F).forEach(f => { if (matchCompiled(F[f], c)) { why[f].push(k); score += W[f]; } }); });
            const neg = r.negative.filter(k => { const c = compileKeyword(k, dia); return matchCompiled(F.konu, c) || matchCompiled(F.metin, c); });
            const res = resolveTarget(r.target, people);
            scored.push({ rule: r, score: neg.length ? 0 : score, rawScore: score, negative: neg, why: why, res: res, key: res.label || ("?" + targetText(r.target)) });
        });
        const byPerson = {};
        scored.filter(x => x.rule.type === "G").forEach(x => {
            const cur = byPerson[x.key];
            if (!cur || x.score > cur.score || (x.score === cur.score && x.rule.priority > cur.rule.priority)) byPerson[x.key] = x;
        });
        const cands = Object.values(byPerson).filter(x => x.score > 0).sort((a, b) => (b.score - a.score) || (b.rule.priority - a.rule.priority));
        const thr = st.options.threshold;
        const top = cands[0], second = cands[1];
        let gerek = null, reason = "";
        if (!st.rules.length) reason = "norules";
        else if (!top || top.score < thr) reason = "nomatch";
        else if (second && second.score === top.score && second.rule.priority === top.rule.priority) reason = "tie";
        else if (top.res.status !== "ok") reason = "unresolved";
        else gerek = top;
        const bilgi = [], warnings = [];
        if (top && reason === "unresolved") warnings.push((top.rule.role || targetText(top.rule.target)) + ": kişi listesinde " + (top.res.status === "ambiguous" ? "birden fazla kişi eşleşti" : "bulunamadı"));
        scored.filter(x => x.rule.type === "B" && x.score >= thr).forEach(x => {
            if (x.res.status === "ok") { if (!bilgi.some(b => b.label === x.res.label)) bilgi.push({ label: x.res.label, role: x.rule.role, why: x.why, global: false }); }
            else warnings.push((x.rule.role || targetText(x.rule.target)) + " (Bilgi): kişi listesinde bulunamadı");
        });
        st.globalBilgi.filter(g => g.enabled).forEach(g => {
            const r = resolveTarget(g.target, people);
            if (r.status === "ok") { if (!bilgi.some(b => b.label === r.label)) bilgi.push({ label: r.label, role: g.role, why: null, global: true }); }
            else warnings.push((g.role || targetText(g.target)) + " (her evrakta Bilgi): kişi listesinde " + (r.status === "ambiguous" ? "birden fazla kişi eşleşti" : "bulunamadı") + " — isterseniz aşağıdan + ile Bilgi olarak ekleyin");
        });
        const finalBilgi = bilgi.filter(b => !gerek || b.label !== gerek.res.label);
        return {
            gerek: gerek ? { label: gerek.res.label, role: gerek.rule.role, score: gerek.score, why: gerek.why, ruleId: gerek.rule.id, byPriority: !!(second && second.score === gerek.score) } : null,
            uncertain: !gerek, reason: reason, threshold: thr,
            candidates: cands.slice(0, 2).map(x => ({ label: x.res.label, display: x.res.label || targetText(x.rule.target), role: x.rule.role, score: x.score, why: x.why, resolved: x.res.status === "ok" })),
            bilgi: finalBilgi, warnings: warnings, usedBody: !!doc.body
        };
    }
    function whyText(why) {
        if (!why) return "";
        const n = { konu: "konu", gonderen: "gönderen", metin: "evrak metni" };
        return Object.keys(n).filter(f => why[f] && why[f].length).map(f => n[f] + ": " + why[f].join(", ")).join(" · ");
    }
    // ---- görev metninden anahtar kelime üretimi
    const STOP = new Set(("ve veya ile ilgili ilişkin için gibi her türlü diğer vb vs bu şu o da de ki en çok daha olan olarak tarafından üzere göre kadar ise bir iki üç " +
        "işlerini işlerinin işleri işi işler işlemlerini işlemleri işlemlerinin işlem işlemler yürütmek yürütülmesi yürütme yürütür takip etmek takibi takibini etmek yapmak yapılması yapılmasını yapar " +
        "sağlamak sağlanması hazırlamak hazırlanması hazırlar düzenlemek düzenlenmesi düzenler koordine koordinasyon koordinesini görev görevi görevleri görevler görevlerini sorumlu sorumluluğu " +
        "verilen verilecek yazışmalar yazışmaları yazışma okul okulun okulumuz müdürlük müdürlüğü müdür yardımcısı başyardımcısı yardımcıları ilgili kurul kurulu çalışmaları çalışmalarını " +
        "konularda konusunda alanında bulunmak katılmak kontrol kontrolü denetlemek planlamak planlanması izlemek tutmak tutulması istenen ilgilenmek mevzuat gereği gereken " +
        "eder yapar sağlar saklar tutar sunar verir alır bildirir izler oluşturur getirir belirler gerçekleştirir bulunur istenir yapılır edilir olur olup olduğu olduğun olduğunuz olduğunda " +
        "sorumluluğundaki sorumluluğunuzdaki sorumluluğunu sorumluluğunda sorumluluğuna gerekenlere gerekli gerektirdiği gerektiren tüm bütün aynı son sürekli düzenli günlük aylık yıllık " +
        "kendi kendilerine kendisine kendisi kendileri inci ıncı uncu üncü nci ncı biri birlikte ortak beraber ayrıca durumunda durumu durumunu yönelik dair hakkında sonra önce içerisinde içinde arasında " +
        "sınıf sınıfların sınıfın sınıfları ders dersleri derslerin öğretmen öğretmenler öğretmenlerin öğretmenleri müdürün müdüre müdürüne müdürlüğe müdürlüğüne yardımcısına yardımcıları " +
        "işi iş işlemlerin işlerle işlerinin konu konuları gün günü günlerde ay ayın yıl yılı dönem dönemi bilgi bilgileri belgeleri evrakları yazıları sistem sistemine sistemi " +
        "sunmak sunulması iletmek bildirmek teslim vermek almak yaptırmak etmek eden edilen edilmesi olan olması yer alan çalışmak çalışma paylaşmak hazırlayarak yaparak takip " +
        "yapan veren alan olan gelen giden bulunan yapılan yapılacak edilecek hazırlanacak belirtilen gereğince uygun usulüne usulü " +
        "onay onayı onayına onayını veli velisi velisine velileri koordinatör memur memurlar başkanlık başkanlığı başkanlığını başkanlığın başkanlığında komisyon komisyonu komisyonuna komisyonlara " +
        "ekip ekibi ekipler ekiplere ihtiyaç ihtiyacı ihtiyaçları ihtiyaçlarını tedbir tedbirleri tedbirlerini milli millî eğitim bakanlığı yetkili yetkilisi sorumludur sorumludurlar sonuçlandırır " +
        "okulumuzda okulumuzdaki sonunda başında öğrenci öğrenciler öğrencilerin öğrencileri öğrencinin öğrenciye öğrencilere kayıt kaydı biri birlikte şekilde şekli halinde hâlinde").split(/\s+/));
    const VERBISH_RE = /(mak|mek|maktır|mektir|arak|erek|ıyor|iyor|uyor|üyor|acak|ecek|ılır|ilir|ulur|ülür|ınır|inir|nması|nmesi|lması|lmesi|ılması|ilmesi|ulması|ülmesi|dığı|diği|duğu|düğü|tığı|tiği|tuğu|tüğü|ınız|iniz|unuz|ünüz|masını|mesini|masına|mesine|mada|mede|masından|mesinden|mayan|meyen|ılan|ilen|ulan|ülen|lanan|lenen)$/;
    const ACRONYM_RE = /^[A-ZÇĞİÖŞÜ][A-ZÇĞİÖŞÜ0-9.]{1,}$/;
    const VOW = /[aeıioöuü]$/;
    function stemWord(w) {
        // koşullu, tek katmanlı Türkçe ek budama (aşırı budamaya karşı): çoğul/hâl ekleri, ünlüden sonra iyelik+tamlayan, ünsüzden sonra tek ünlü
        let t = String(w).toLocaleLowerCase("tr");
        const multi = ["lerinin", "larının", "lerinde", "larında", "lerini", "larını", "lerine", "larına", "lerden", "lardan", "ndaki", "ndeki", "leri", "ları", "lerin", "ların", "ler", "lar"];
        for (let guard = 0; guard < 3; guard++) {
            const m = multi.find(x => t.endsWith(x) && t.length - x.length >= 4);
            if (m) { t = t.slice(0, -m.length); continue; }
            const g = ["nın", "nin", "nun", "nün", "sı", "si", "su", "sü", "na", "ne"].find(x => t.endsWith(x) && t.length - x.length >= 4 && VOW.test(t.slice(0, -x.length)));
            if (g) { t = t.slice(0, -g.length); continue; }
            if (/[ıiuü]$/.test(t) && t.length - 1 >= 5 && !VOW.test(t.slice(0, -1))) { t = t.slice(0, -1); continue; }
            break;
        }
        const fin = { "ğ": "k", b: "p", d: "t" }[t.slice(-1)];
        if (fin && t.length >= 4) t = t.slice(0, -1) + fin;
        return t;
    }
    function dutyPhrases(duty) {
        // noktalama ile ayrılan bölümler içinde ardışık içerik kelimelerinden 1–2 kelimelik öbekler (kökleri); fiilimsi/genel kelimeler öbeği böler; kısa kısaltmalar (DYK, TEFBİS…) aynen alınır
        const out = [];
        String(duty).replace(/[“”"]/g, " ").replace(/['’][a-zçğıöşü]+/gi, " ").split(/[,.;:()[\]/!?]+/).forEach(seg => {
            const words = seg.split(/[^0-9A-Za-zÇĞİÖŞÜçğıöşüÂÎÛâîû-]+/).map(w => w.replace(/^-+|-+$/g, "")).filter(Boolean);
            const caps = words.map(w => ACRONYM_RE.test(w));
            let run = [];
            const flush = () => {
                for (let i = 0; i < run.length; i++) {
                    if (i + 1 < run.length && stemWord(run[i].w) !== stemWord(run[i + 1].w)) out.push((run[i].acr ? run[i].w : stemWord(run[i].w)) + " " + (run[i + 1].acr ? run[i + 1].w : stemWord(run[i + 1].w)));
                    if (run[i].acr || run[i].w.length >= 6) out.push(run[i].acr ? run[i].w : stemWord(run[i].w));
                }
                run = [];
            };
            words.forEach((w, i) => {
                const l = w.toLocaleLowerCase("tr");
                // tamamı büyük harf kısa kelime ve komşuları büyük harfle yazılmış sıradan kelimeler değilse → kısaltma
                const acr = caps[i] && w.length >= 2 && w.length <= 7 && !(caps[i - 1] || caps[i + 1]) && !/^(T\.C\.|TC|EBYS|MEB)$/.test(w) && !STOP.has(l);
                if (STOP.has(l) || /^\d/.test(l) || (!acr && (l.length < 3 || VERBISH_RE.test(l)))) flush(); else run.push({ w: acr ? l : l, acr: acr });
            });
            flush();
        });
        return out.filter(p => p.replace(/\s/g, "").length >= 3);
    }
    function isAcronymPhrase(p, duties) { return duties.some(d => new RegExp("(^|[^A-Za-zÇĞİÖŞÜçğıöşü])" + p.toLocaleUpperCase("tr").replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "([^A-Za-zÇĞİÖŞÜçğıöşü]|$)").test(d)); }
    // Vekâlet ("X izinli/raporlu olduğunda görevlerini yürütmek") ve genel kapanış ("müdür tarafından verilen diğer görevler") görevleri anahtar kelime üretmez
    const SKIP_DUTY_RE = /(izinli|raporlu|görevli|yokluğunda)[^.]{0,60}(olması|olduğu|bulunduğu|durumunda|günlerde|vekalet|vekâlet)|vekalet etmek|vekâlet etmek|tarafından verilen.{0,40}diğer görev|verilecek diğer görev|vereceği diğer görev/i;
    function isSkippedDuty(d) { return SKIP_DUTY_RE.test(String(d)); }
    function deriveKeywords(duties, allPersonsDuties, opts) {
        opts = opts || {};
        const use = duties.filter(d => !isSkippedDuty(d));
        const text = use.join("\n");
        const toks = tokenize(text);
        const others = (allPersonsDuties && allPersonsDuties.length >= 3) ? allPersonsDuties.map(ds => tokenize(ds.filter(d => !isSkippedDuty(d)).join("\n"))) : null;
        const common = (k) => { if (!others) return false; const c = compileKeyword(k); return others.filter(t => matchCompiled(t, c)).length >= Math.max(3, Math.ceil(others.length * 0.4)); };
        const nameToks = new Set((opts.names || []).flatMap(n => tokenize(n)).filter(t => t.length >= 3));
        const hasName = (p) => tokenize(p).some(t => nameToks.has(t));
        const sets = [];
        let kws = [];
        KEYWORD_SETS.forEach(s => {
            const hit = s.keywords.filter(k => matchCompiled(toks, compileKeyword(k)) && !common(k));
            if (!hit.length) return;
            const full = hit.length >= Math.max(3, Math.ceil(s.keywords.length * 0.4));
            sets.push({ id: s.id, label: s.label, hits: hit, full: full });
            kws = kws.concat(hit); // setin tamamı otomatik eklenmez; inceleme ekranında tek tıkla eklenebilir
        });
        let phrases = [];
        use.forEach(d => { phrases = phrases.concat(dutyPhrases(d)); });
        phrases = phrases.filter(p => !common(p) && !hasName(p));
        const covered = (p) => kws.some(k => matchKeyword(p, k) || matchKeyword(k, p));
        const maxP = opts.maxPhrases || 12;
        const freq = {};
        phrases.forEach(p => { const k = fold(p); freq[k] = (freq[k] || 0) + 1; });
        const acr = (p) => !/\s/.test(p) && isAcronymPhrase(p, use) ? 1 : 0;
        const ranked = uniqFold(phrases).filter(p => !covered(p)).sort((a, b) => (acr(b) - acr(a)) || (b.split(" ").length - a.split(" ").length) || (freq[fold(b)] - freq[fold(a)]));
        const picked = [];
        ranked.forEach(p => { if (picked.length < maxP && !picked.some(q => matchKeyword(p, q) || matchKeyword(q, p))) picked.push(p); });
        kws = uniqFold(kws.concat(picked));
        return { keywords: kws, sets: sets, skipped: duties.length - use.length };
    }
    // Kişiler arası çakışan anahtar kelimeler (eşit puan / yanlış öneri riski)
    function findOverlaps(persons) {
        const out = [];
        const comp = persons.map(p => (p.keywords || []).map(k => ({ k: k, c: compileKeyword(k), t: tokenize(k) })));
        for (let i = 0; i < persons.length; i++) for (let j = i + 1; j < persons.length; j++) {
            comp[i].forEach(a => comp[j].forEach(b => {
                if (matchCompiled(b.t, a.c) || matchCompiled(a.t, b.c)) out.push({ keyword: a.k, other: b.k, a: i, b: j });
            }));
        }
        return out;
    }
    // ---- görev dağılımı PDF metni → kişi bölümleri (satırlar pdf.js metin içeriğinden konuma göre birleştirilmiş olarak gelir)
    const TITLE_RE = /(Müdür\s*Baş\s*Yardımcısı|Müdür\s*Başyardımcısı|Müdür\s*Yardımcısı|Md\.?\s*Yrd\.?|Okul\s*Müdürü|Müdürü?|Öğretmen|Memur|Sayman|Şef)/i;
    const NAME_STOP = new Set(["SAYIN", "SN", "SN.", "T.C.", "TC", "MÜDÜR", "MÜDÜRÜ", "YARDIMCISI", "BAŞYARDIMCISI", "GÖREV", "GÖREVLERİ", "DAĞILIMI", "EĞİTİM", "ÖĞRETİM", "YILI", "ADI", "SOYADI", "UNVANI", "ÜNVANI", "SIRA", "NO", "OKUL", "LİSESİ", "MÜDÜRLÜĞÜ", "VALİLİĞİ", "KONU", "SAYI", "İLGİ", "TARİH", "EK", "DAĞITIM", "ONAY", "OLUR", "TABLOSU", "LİSTESİ", "KURULU", "İŞLERİ"]);
    function findNamesInLine(text, people) {
        const found = [];
        const T = normP(text);
        (people || []).forEach(p => { const n = normP(p.name); if (n.length >= 5 && T.includes(n)) found.push({ name: p.name, title: p.title || "", known: true, idx: T.indexOf(n), raw: n }); });
        if (found.length) return found;
        const re = /((?:[A-ZÇĞİÖŞÜ][a-zçğıöşü]+\s+){1,2})([A-ZÇĞİÖŞÜ]{2,}(?:\s+[A-ZÇĞİÖŞÜ]{2,})?)(?![a-zçğıöşü])/g;
        let m;
        while ((m = re.exec(text))) {
            const given = m[1].trim().split(/\s+/).filter(w => !NAME_STOP.has(normP(w)) && !TITLE_RE.test(w));
            const sur = m[2].trim().split(/\s+/).filter(w => !NAME_STOP.has(w));
            if (!given.length || !sur.length) continue;
            if (given.some(w => /^(Sayın|Konu|Sayı|İlgi|Tarih|Okul|Lisesi|Müdürlüğü)$/i.test(w))) continue;
            found.push({ name: given.join(" ") + " " + sur.join(" "), title: "", known: false, idx: m.index, raw: normP(given.join(" ") + " " + sur.join(" ")) });
        }
        if (!found.length && TITLE_RE.test(text)) { // TAMAMI BÜYÜK HARF ad + ünvan aynı satırda (ör. "ZEYNEP KARACA  Müdür Yardımcısı")
            const re2 = /\b([A-ZÇĞİÖŞÜ]{2,}(?:\s+[A-ZÇĞİÖŞÜ]{2,}){1,2})\b/g;
            while ((m = re2.exec(text))) { const ws = m[1].split(/\s+/).filter(w => !NAME_STOP.has(w)); if (ws.length >= 2) found.push({ name: ws.slice(0, -1).map(w => w.charAt(0) + w.slice(1).toLocaleLowerCase("tr")).join(" ") + " " + ws[ws.length - 1], title: "", known: false, idx: m.index, raw: normP(ws.join(" ")) }); }
        }
        return found;
    }
    const BULLET_RE = /^\s*(?:[•\-–—*▪●○►✓·■□]|\(?\d{1,2}[.)-]|[a-zçğıöşü][.)])\s+/;
    function splitDuties(lines) {
        const duties = [];
        lines.forEach(l => {
            const t = l.replace(/\s+/g, " ").trim();
            if (!t) return;
            const prev = duties[duties.length - 1];
            if (BULLET_RE.test(t) || !prev || /[.;:]$/.test(prev) && /^[A-ZÇĞİÖŞÜ0-9]/.test(t)) duties.push(t.replace(BULLET_RE, "").trim());
            else duties[duties.length - 1] = prev + " " + t;
        });
        return duties.map(d => d.replace(/\s+/g, " ").trim()).filter(d => d.length >= 4);
    }
    function parseDutyDocument(lines, people) {
        // lines: [{ text, cells?: [...] }] belge sırasıyla. Dönüş: { persons: [{ name, title, known, duties }], unassigned: [...] }
        const sections = []; let cur = null; const pre = [];
        lines.forEach(L => {
            let text = typeof L === "string" ? L : L.text;
            const names = findNamesInLine(text, people);
            if (names.length) {
                const n = names.sort((a, b) => a.idx - b.idx)[0];
                const tm = text.match(TITLE_RE);
                let key = normP(n.name);
                let sec = sections.find(s => normP(s.name) === key);
                if (!sec) { sec = { name: n.name, title: n.title || (tm ? tm[1].replace(/\s+/g, " ") : ""), known: n.known, lines: [] }; sections.push(sec); }
                else if (!sec.title && tm) sec.title = tm[1].replace(/\s+/g, " ");
                cur = sec;
                // satırdan ad, ünvan, sıra no ve "Sayın" çıkarılır; kalan metin görev başlangıcıdır
                let rest = text;
                const idxN = normP(rest).indexOf(n.raw);
                if (idxN >= 0) rest = rest.slice(0, idxN) + " " + rest.slice(idxN + n.raw.length);
                rest = rest.replace(TITLE_RE, " ").replace(/^\s*\d{1,2}[.)]?\s+/, " ").replace(/\b(Sayın|Sn\.)\s*/gi, " ").replace(/^[\s:,\-–]+/, "").trim();
                if (rest && /[a-zçğıöşü]{3,}/.test(rest)) cur.lines.push(rest);
                return;
            }
            if (cur) cur.lines.push(text); else pre.push(text);
        });
        const persons = sections.map(s => ({ name: s.name, title: s.title, known: s.known, duties: splitDuties(s.lines) })).filter(p => p.duties.length || p.known);
        return { persons: persons, preamble: splitDuties(pre) };
    }
    // ---- Kişiye özel görev yazısı ("Konu: Görevleriniz (Ad SOYAD Ünvan)", "Sayın : Ad SOYAD" + ünvan, numaralı görevler)
    function normTitle(t) {
        let s = String(t || "").replace(/[()]/g, " ").replace(/\s+/g, " ").trim();
        if (!s) return "";
        s = s.replace(/yad[ıi]mc[ıi]s[ıi]/gi, "yardımcısı").replace(/YAD[IİI]MC[IİI]S[IİI]/g, "YARDIMCISI");
        s = s.replace(/baş\s+yardımcı/gi, "başyardımcı").replace(/BAŞ\s+YARDIMCI/g, "BAŞYARDIMCI");
        s = s.split(" ").map(w => w.charAt(0).toLocaleUpperCase("tr") + w.slice(1).toLocaleLowerCase("tr")).join(" ");
        s = s.replace(/Başyardımcı/g, "Başyardımcı").replace(/\bVe\b/g, "ve");
        return s;
    }
    const LETTER_TITLE_RE = /(müdür|yard[ıi]mc|yad[ıi]mc|memur|öğretmen|hizmetli|teknisyen|sayman|şef|koordinatör|idari|hizmetleri)/i;
    const NAME_ONLY_RE = /^(?:[A-ZÇĞİÖŞÜ][a-zçğıöşü]+\s+){1,2}[A-ZÇĞİÖŞÜ]{2,}(?:\s+[A-ZÇĞİÖŞÜ]{2,})?$/;
    const FOOTER_RE = /güvenli elektronik imza ile imzalanmıştır|^Doğrulama Kodu|^Kep Adresi|^Telefon No|Bilgi için\s*:/i;
    function isLetter(lines) {
        const T = lines.slice(0, 40).map(l => typeof l === "string" ? l : l.text);
        return T.some(t => /^\s*Sayın\s*[:;]/i.test(t) || /^\s*Sayın\s+\S/i.test(t)) && T.some(t => /Görevleriniz|görevleriniz|göreviniz/i.test(t));
    }
    function parseDutyLetter(lines, people) {
        const L = lines.map(l => typeof l === "string" ? { text: l, cells: [{ x: 0, text: l }], page: 1 } : l);
        let name = "", title = "", role = "", known = false, sayinIdx = -1;
        // 1) "Sayın" satırı (+ sonraki kısa satır ünvan) ve Konu parantezi
        for (let i = 0; i < Math.min(L.length, 40); i++) {
            const t = L[i].text.trim();
            const m = t.match(/^Sayın\s*[:;]?\s*(.*)$/i);
            if (!m) continue;
            sayinIdx = i;
            let rest = m[1].trim();
            const nx = L[i + 1] && L[i + 1].text.trim();
            if (nx && nx.length <= 60 && LETTER_TITLE_RE.test(nx) && !/[.]$/.test(nx) && !/^\d/.test(nx)) title = normTitle(nx);
            const nm = findNamesInLine(rest, people);
            if (nm.length) { name = nm[0].name; known = nm[0].known; if (nm[0].title) title = title || nm[0].title; const after = rest.slice(rest.toLocaleUpperCase("tr").indexOf(nm[0].raw) + nm[0].raw.length).trim(); if (!title && after && LETTER_TITLE_RE.test(after)) title = normTitle(after); }
            else if (rest && NAME_ONLY_RE.test(rest.replace(/[,;:]+$/, ""))) name = rest.replace(/[,;:]+$/, "");
            break;
        }
        const konuI = L.findIndex(l => /^\s*Konu\s*:/i.test(l.text));
        if (konuI >= 0) {
            let k = L[konuI].text.replace(/^\s*Konu\s*:\s*/i, "");
            if (/\([^)]*$/.test(k) && L[konuI + 1]) k += " " + L[konuI + 1].text.trim();
            const pm = k.match(/\(([^)]*)\)/);
            if (pm) {
                const inner = pm[1].trim();
                const nm = findNamesInLine(inner, people);
                if (nm.length) {
                    if (!name) { name = nm[0].name; known = nm[0].known; }
                    const after = inner.slice(inner.toLocaleUpperCase("tr").indexOf(nm[0].raw) + nm[0].raw.length).trim();
                    if (!title && after && LETTER_TITLE_RE.test(after)) title = normTitle(after);
                }
            }
        }
        // 2) görev bölümünün başlığı ("KOORDİNATÖR MÜDÜR YARDIMCISI OLARAK GÖREVLERİNİZ") → görev etiketi
        const head = L.find(l => /GÖREVLERİNİZ/.test(l.text) && /[A-ZÇĞİÖŞÜ]{4,}/.test(l.text.replace(/GÖREVLERİNİZ/, "")));
        if (head) role = normTitle(head.text.replace(/OLARAK|GÖREVLERİNİZ|:/g, " "));
        if (!title && role) title = role;
        if (people && people.length && name) {
            const pk = people.filter(p => normP(p.name) === normP(name));
            if (pk.length === 1) { known = true; name = pk[0].name; if (pk[0].title) { if (title && normP(title) !== normP(pk[0].title)) role = role || title; title = pk[0].title; } }
        }
        // 3) görevler: sıralı numara (1-, 2., 3)) ya da harf (a), b.) ile başlayan maddeler; alt maddeler (a., -, 3-a)) ayrı madde olur
        const duties = []; let started = false, expect = 1, cur = null, inFooter = false, curPage = 0, parentNo = "";
        const topRe = /^\s*(\d{1,2})\s?[-.)]\s*(?=[A-ZÇĞİÖŞÜ0-9"'(“])/;
        const letRe = /^\s*([a-zçğıöşü])[.)]\s+/;
        const subRe = /^\s*(?:[-–•▪]\s+|\d{1,2}\s?-\s?[a-zçğıöşü]\)\s*)/;
        let letterMode = false;
        for (let i = Math.max(0, sayinIdx + 1); i < L.length; i++) {
            const l = L[i]; const t = l.text.trim();
            if (l.page !== curPage) { curPage = l.page; inFooter = false; }
            if (FOOTER_RE.test(t)) { inFooter = true; continue; }
            if (inFooter || !t) continue;
            if (/^\d+\s*\/\s*\d+$/.test(t)) continue;
            if (started && (l.cells || []).length && l.cells.every(c => NAME_ONLY_RE.test(c.text))) break; // imza bloğu
            const tm = t.match(topRe), lm = t.match(letRe), sm = t.match(subRe);
            if (tm && +tm[1] >= expect && +tm[1] <= expect + 2 && (started || +tm[1] === 1) && !letterMode) { started = true; expect = +tm[1] + 1; parentNo = tm[1]; cur = { no: tm[1], text: t.replace(topRe, "").trim() }; duties.push(cur); splitInline(); continue; }
            if (!started && lm && lm[1] === "a") { started = true; letterMode = true; }
            if (lm && started && letterMode) { cur = { no: lm[1], text: t.replace(letRe, "").trim() }; duties.push(cur); continue; }
            if (started && (sm || lm) && cur) { cur = { no: parentNo + "." + (lm ? lm[1] : "-"), text: t.replace(lm ? letRe : subRe, "").trim(), sub: true }; duties.push(cur); continue; }
            if (started && cur) { cur.text += " " + t; if (!letterMode) splitInline(); continue; }
        }
        function splitInline() { // aynı satırda sonraki madde ("… etmek. 16- Ayrıca …" ya da satır sonunda "16-")
            for (let g = 0; g < 5; g++) {
                const re = new RegExp("([.;:])\\s*(" + expect + "|" + (expect + 1) + ")\\s?[-.)](?:\\s+(?=[A-ZÇĞİÖŞÜ0-9\"'(“])|\\s*$)");
                const m = cur.text.match(re);
                if (!m) return;
                const rest = cur.text.slice(m.index + m[0].length);
                cur.text = cur.text.slice(0, m.index + 1);
                expect = +m[2] + 1; parentNo = m[2];
                cur = { no: m[2], text: rest.trim() }; duties.push(cur);
            }
        }
        duties.forEach(d => { d.text = d.text.replace(/\s+/g, " ").replace(/\s+([.,;])/g, "$1").trim(); d.skip = isSkippedDuty(d.text); });
        return { letter: true, name: name, title: title, role: role, known: known, duties: duties.filter(d => d.text.length >= 3) };
    }
    // Başlık satırlı tablo ("Sıra | Adı Soyadı | Unvanı | Görevleri"): hücreler sütun konumuna göre atanır; sarılmış ad/ünvan satırları birleştirilir
    function parseDutyTable(lines, people) {
        const L = lines.filter(l => l && l.items && l.items.length);
        const hi = L.findIndex(l => /ad[ıi]\s*soyad|ad[ıi]\s*-\s*soyad|personel/i.test(l.text) && /görev/i.test(l.text) && l.items.length >= 2);
        if (hi < 0) return null;
        // tablo satırları: başlıktan sonra, aralarında büyük dikey boşluk olmayan satırlar
        const body = []; let lastY = L[hi].y, page = L[hi].page, minGap = 1e9;
        for (let i = hi + 1; i < L.length; i++) {
            const l = L[i];
            if (l.page !== page) { page = l.page; lastY = l.y + 14; if (/görev/i.test(l.text) && /ad[ıi]/i.test(l.text)) { lastY = l.y; continue; } }
            if (FOOTER_RE.test(l.text)) continue;
            const gap = lastY - l.y;
            if (gap > 40 || (minGap < 1e9 && gap > Math.max(20, minGap * 2.4))) break; // tablo bitti (imza vb.)
            if (gap > 2) minGap = Math.min(minGap, gap);
            lastY = l.y; body.push(l);
        }
        if (!body.length) return null;
        // sütun başlangıçları: satırlarda tekrar eden x konumları; başlık öğelerinin (ortalanmış olabilir) solundaki en sık konum seçilir
        const cl = [];
        body.forEach(l => l.items.forEach(it => { const c = cl.find(c => Math.abs(c.x - it.x) <= 3); if (c) c.n++; else cl.push({ x: it.x, n: 1 }); }));
        const hdr = L[hi].items.slice().sort((a, b) => a.x - b.x).filter(h => /\S/.test(h.s));
        const kinds = hdr.map(h => /s[ıi]ra|^no\b|^#/i.test(h.s) ? "no" : /görev/i.test(h.s) && !/unvan|ünvan/i.test(h.s) ? "duty" : /unvan|ünvan|kadro/i.test(h.s) ? "title" : /ad[ıi]|soyad|personel|isim/i.test(h.s) ? "name" : "other");
        const cols = []; let prev = -1e9;
        hdr.forEach((h, i) => {
            const center = h.x + (h.w || 0) / 2;
            const cand = cl.filter(c => c.x > prev + 5 && c.x <= center + 5 && c.n >= 2);
            if (!cand.length) return;
            const best = cand.reduce((a, b) => b.n > a.n ? b : a);
            cols.push({ kind: kinds[i], x: best.x }); prev = best.x;
        });
        if (!cols.some(c => c.kind === "name") || !cols.some(c => c.kind === "duty")) return null;
        const colOf = (x) => { let k = cols[0].kind; cols.forEach(c => { if (x >= c.x - 3) k = c.kind; }); return k; };
        const rows = []; let cur = null;
        const hasNo = cols.some(c => c.kind === "no");
        body.forEach(l => {
            const parts = { no: [], name: [], title: [], duty: [], other: [] };
            l.items.forEach(it => parts[colOf(it.x)].push(it.s.trim()));
            const startsRow = hasNo ? (parts.no.length && /^\d{1,3}[.)]?$/.test(parts.no.join(""))) : (parts.name.length && (!cur || cur.duty.length));
            if (startsRow || !cur) { cur = { name: [], title: [], duty: [] }; rows.push(cur); }
            cur.name.push(...parts.name); cur.title.push(...parts.title); if (parts.duty.length) cur.duty.push(parts.duty.join(" "));
        });
        const persons = [];
        rows.forEach(r => {
            const nameTxt = r.name.join(" ").replace(/\s+/g, " ").trim();
            if (!nameTxt) return;
            const nm = findNamesInLine(nameTxt, people);
            let name = nm.length ? nm[0].name : nameTxt;
            let known = nm.length ? !!nm[0].known : false;
            let title = normTitle(r.title.join(" "));
            if (people && people.length) { const pk = people.filter(p => normP(p.name) === normP(name)); if (pk.length === 1) { known = true; name = pk[0].name; if (pk[0].title) title = pk[0].title; } }
            persons.push({ name, title, known, duties: splitDuties(r.duty) });
        });
        return persons.length ? { persons } : null;
    }
    // Belge türünü seçer: kişiye özel yazı → tek kişi; değilse çok kişili tablo/liste
    function parseDutyPdf(lines, people) {
        if (isLetter(lines)) {
            const r = parseDutyLetter(lines, people);
            return { kind: "letter", persons: [{ name: r.name, title: r.title, role: r.role, known: r.known, duties: r.duties.map(d => d.text), dutyItems: r.duties }] };
        }
        const t = parseDutyTable(lines, people);
        const r = t ? { persons: t.persons, preamble: [] } : parseDutyDocument(lines, people);
        return { kind: r.persons.length ? "table" : "unknown", persons: r.persons.map(p => Object.assign({ role: "", dutyItems: p.duties.map((t, i) => ({ no: String(i + 1), text: t, skip: isSkippedDuty(t) })) }, p)), preamble: r.preamble };
    }
    // pdf.js metin öğeleri → satırlar (sayfa sayfa; y'ye göre gruplanır, x'e göre sıralanır; büyük boşluk hücre ayırır)
    function itemsToLines(pages) {
        const out = [];
        pages.forEach((items, pageIdx) => {
            const rows = [];
            // döndürülmüş öğeler (e-imza / doğrulama damgası vb.) atlanır
            items.filter(it => it && typeof it.str === "string" && it.str.trim() && !(it.transform && (Math.abs(it.transform[1]) > 0.01 || Math.abs(it.transform[2]) > 0.01))).forEach(it => {
                const x = it.transform[4], y = it.transform[5], h = Math.abs(it.transform[3]) || 10;
                let r = rows.find(r => Math.abs(r.y - y) <= Math.max(2, h * 0.4));
                if (!r) { r = { y: y, items: [] }; rows.push(r); }
                r.items.push({ x: x, w: it.width || it.str.length * h * 0.5, s: it.str });
            });
            const pageMaxX = rows.reduce((m, r) => Math.max(m, ...r.items.map(i => i.x)), 0);
            rows.sort((a, b) => b.y - a.y).forEach(r => {
                r.items.sort((a, b) => a.x - b.x);
                const cells = []; let c = null, endX = -1e9;
                r.items.forEach(it => { if (!c || it.x - endX > 14) { c = { x: it.x, s: it.s }; cells.push(c); } else c.s += (it.x - endX > 1.5 && !/\s$/.test(c.s) ? " " : "") + it.s; endX = it.x + it.w; });
                // satır sonunda, sayfanın en sağında tek başına duran 1–3 haneli rakam hücresi: damga/doğrulama gürültüsü
                for (let ci = cells.length - 1; ci > 0; ci--) if (/^-?\d{1,3}-?$/.test(cells[ci].s.trim()) && cells[ci].x >= pageMaxX - 25) cells.splice(ci, 1);
                const text = cells.map(c => c.s.trim()).join("   ");
                if (/^[\d\s\-–—/.]+$/.test(text) && !/^\d+\s*\/\s*\d+$/.test(text.trim())) return; // yalnızca rakam/çizgi: damga gürültüsü
                out.push({ text: text, cells: cells.map(c => ({ x: Math.round(c.x), text: c.s.trim() })), items: r.items.filter(i => i.s.trim()).map(i => ({ x: Math.round(i.x), w: Math.round(i.w), s: i.s })), y: r.y, page: pageIdx + 1 });
            });
        });
        return out;
    }
    return { RULES_KEY, RULES_FILE_TYPE, KEYWORD_SETS, ITEM_TEMPLATE, TPL_SRC, templateFromRules, sanitizeTemplate, templateToRules, applyTemplate, fold, tokenize, compileKeyword, matchKeyword, matchCompiled, splitList, uniqFold, newId, sanitizeRules, isRulesFile, rulesToFile,
        resolveTarget, setPrincipal, targetText, labelOf, routeDoc, whyText, stemWord, dutyPhrases, deriveKeywords, isSkippedDuty, findOverlaps, findNamesInLine, splitDuties, parseDutyDocument, parseDutyTable, normTitle, isLetter, parseDutyLetter, parseDutyPdf, itemsToLines };
})();
export default HavaleCore;
