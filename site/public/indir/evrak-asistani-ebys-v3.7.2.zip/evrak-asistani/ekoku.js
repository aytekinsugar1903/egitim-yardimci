let _unused_keu6;
function _0x3483() {
    const _0xd33aa2 = ['ogretim sekli', 'okul adi', 'sube sayisi', 'Müdür yardımcısı / şube müdürü', 'headerRow', '</sheetData>', 'form', 'Personel sayısı', 'mudur yardimcilari', 'ogretimSekli', 'bilinmiyor', 'il adi', 'imza unvani', '<w:p>', 'getURL', 'round', 'points', 'irtibat telefonu', 'transform', '</w:p>', '20lLhLgp', 'Form alanları: ', 'kurum adresi', '</sheetData></worksheet>', 'push', 'replace', '750639nKgjYQ', 'web sitesi', 'test', 'xl/styles.xml', 'value', 'fax', '\x22([^>]*?)(/>|>([\x5cs\x5cS]*?)</row>)', 'getTextContent', '96697yadctW', 'kurum', 'e posta', 'GlobalWorkerOptions', 'rows', 'adres', 'split', 'kurum turu', 'egitim ogretim yili', 'Kız öğrenci sayısı', 'col', 'join', '</row>', 'fromCodePoint', 'Eski Excel (.xls): metinler yaklaşık okundu; sütun sırası doğrulanmalı.', '<row r=\x22', 'docx', 'val', 'indexOf', 'tel no', 'reduce', 'Kurum kodu', 'startsWith', '<w:p/>', '<?xml version=\x221.0\x22 encoding=\x22UTF-8\x22 standalone=\x22yes\x22?>\x0a', 'Faks', 'ustBirim', 'index', 'sort', 'fromCharCode', 'Şube sayısı', 'slice', 'email', 'kurumun adi', 'kiz ogrenci', 'sheet', 'workerSrc', 'kiz ogrenci sayisi', 'mersis', 'Kurum adı', '27372FqkIya', 'encode', '<w:tcPr>', 'max', '</sst>', 'E-posta', 'Form alanı bulunamadı', '<w:tbl>', '\x22([^>]*?)(?:/>|>[\x5cs\x5cS]*?</c>)', 'odt', 'mevcut', 'row', 'erkek ogrenci', 'word/document.xml', 'derslikSayisi', ' s=\x222\x22', 'hazirlayan', 'some', 'kadrolu ogretmen', '1023KqIRrw', 'subarray', 'sorumlu kisi', '81005yXhqcE', '<Relationships xmlns=\x22http://schemas.openxmlformats.org/package/2006/relationships\x22><Relationship Id=\x22rId1\x22 Type=\x22http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\x22 Target=\x22worksheets/sheet1.xml\x22/><Relationship Id=\x22rId2\x22 Type=\x22http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\x22 Target=\x22styles.xml\x22/><Relationship Id=\x22rId3\x22 Type=\x22http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings\x22 Target=\x22sharedStrings.xml\x22/></Relationships>', 'EBYS_EK', 'Form tablosu bulunamadı', 'sube', 'sorumlu', 'sorumlu mudur yardimcisi', ' — ', '&gt;', 'size', ' t=\x22s\x22><v>', '&lt;', 'set', 'mudurYrd', 'word/document.xml yok', 'title', 'charCodeAt', 'okul telefonu', 'toLowerCase', 'keys', 'match', 'Amir adı (Müdür / İlçe MEM Müdürü)', '85790cTjFos', 'personelSayisi', 'note', 'items', 'muduru', 'Bağlı üst birim', '&quot;', 'detsis no', 'Değer', 'okulAdi', 'kind', 'kiz', 'derslik sayisi', 'erkek', 'kurum tipi', 'getDocument', 'endsWith', 'detsis', 'undefined', '1600UBCaun', 'has', 'Adres', '</t></is></c>', 'yok', 'destroy', 'mudurun adi soyadi', 'okulun adi', 'exec', 'kurumTuru', 'existing', 'amir unvani', 'adresi', 'kizOgrenci', '<fill><patternFill patternType=\x22solid\x22><fgColor rgb=\x22FFFFFF00\x22/><bgColor indexed=\x2264\x22/></patternFill></fill></fills>', 'txt', 'forEach', 'yellow', 'sinif sayisi', 'dikey', 'runtime', 'xlsx', 'subeSayisi', 'includes', 'xl/sharedStrings.xml', 'Eğitim-öğretim yılı', 'bagli birim', 'mersis no', 'map', 'getPage', 'floor', 'str', '</w:t></w:r>', 'Öğretim şekli', 'sheets', 'pipeThrough', 'Erkek öğrenci sayısı', 'ilcesi', '<w:tab/>', 'amir adi', 'find', 'faks', 'text', '</w:t>', 'okul kodu', 'min', 'data', '318kEBSID', 'length', 'fields', 'okul', 'erkek ogrenci sayisi', '18DLKGGa', '7273sYMdzB', 'erkekOgrenci', 'internet adresi', 'normal ikili', '<sheetData>', '&amp;', 'toplam ogrenci', 'utf-8', 'toplam personel', 'Kurum türü', 'belgegecer', 'sube muduru', 'kurum muduru', 'filter', '<w:r><w:t xml:space=\x22preserve\x22>', '<w:tcPr><w:shd w:val=\x22clear\x22 w:color=\x22auto\x22 w:fill=\x22FFFF00\x22/>', '14781DWVcMT', 'telefon numarasi', 'irtibat kisisi', 'pdfjs/pdf.min.mjs', '9481419GavDqD', 'dershane sayisi', 'label', 'ogrenci sayisi', '\x22 borderId=\x220\x22 xfId=\x220\x22 applyFill=\x221\x22/></cellXfs>', 'trim', 'ogretmenSayisi', 'mudur', 'kurum kod', 'ilce adi', '<w:tcPr><w:shd w:val=\x22clear\x22 w:color=\x22auto\x22 w:fill=\x22FFFF00\x22/></w:tcPr>', 'acik adres', 'concat', 'kurum adi', '<c r=\x22', 'decode', 'toplam ogrenci sayisi', 'web'];
    _0x3483 = function () {
        return _0xd33aa2;
    };
    return _0x3483();
}
function _0x1f8a(_0x3448b2, _0x1d4d1f) {
    _0x3448b2 = _0x3448b2 - 0x1ab;
    const _0x3483a2 = _0x3483();
    let _0x1f8aba = _0x3483a2[_0x3448b2];
    return _0x1f8aba;
}
(function (_0x47e35e, _0x556644) {
    const _0x35a952 = _0x47e35e();
    while (!false) {
        try {
            const _0x5269aa = -parseInt("96697yadctW") / 0x1 * (-parseInt("18DLKGGa") / 0x2) + parseInt("750639nKgjYQ") / 0x3 * (parseInt("20lLhLgp") / 0x4) + -parseInt("81005yXhqcE") / 0x5 * (parseInt("318kEBSID") / 0x6) + parseInt("7273sYMdzB") / 0x7 * (parseInt("1600UBCaun") / 0x8) + parseInt("9481419GavDqD") / 0x9 + parseInt("85790cTjFos") / 0xa * (parseInt("1023KqIRrw") / 0xb) + parseInt("27372FqkIya") / 0xc * (-parseInt("14781DWVcMT") / 0xd);
            if (_0x5269aa === _0x556644) {
                break;
            }
            else {
                _0x35a952.push(_0x35a952.shift());
            }
        }
        catch (_0x3b395e) {
            _0x35a952.push(_0x35a952.shift());
        }
    }
}(_0x3483, 0xb1d06), function (_0x41d0c2) {
    'use strict';
    let _unused_7ej8;
    const _0x3f646b = new TextDecoder("utf-8"), _0x4269df = (_0x2a1031, _0x62292) => _0x2a1031[_0x62292] | _0x2a1031[_0x62292 + 0x1] << 0x8, _0xe9fec = (_0x187738, _0x5b181c) => (_0x187738[_0x5b181c] | _0x187738[_0x5b181c + 0x1] << 0x8 | _0x187738[_0x5b181c + 0x2] << 0x10 | _0x187738[_0x5b181c + 0x3] << 0x18) >>> 0x0;
    async function _0x1c1846(_0x25f129) {
        const _0x78de6c = new DecompressionStream('deflate-raw'), _0x599f6c = new Response(new Blob([_0x25f129]).stream().pipeThrough(_0x78de6c));
        return new Uint8Array(await _0x599f6c.arrayBuffer());
    }
    function _0xc4c474(_0x3faf4f) {
        const _0x471b90 = _0x3faf4f instanceof Uint8Array ? _0x3faf4f : new Uint8Array(_0x3faf4f);
        let _0x33dd96 = -0x1;
        for (let _0x3c606c = _0x471b90.length - 0x16; _0x3c606c >= Math.max(0x0, _0x471b90.length - 0x101d0); _0x3c606c--) {
            if (_0xe9fec(_0x471b90, _0x3c606c) === 0x6054b50) {
                _0x33dd96 = _0x3c606c;
                break;
            }
        }
        if (_0x33dd96 < 0x0) {
            throw new Error('ZIP değil');
        }
        const _0x4e765b = _0x4269df(_0x471b90, _0x33dd96 + 0xa);
        let _0x497c31 = _0xe9fec(_0x471b90, _0x33dd96 + 0x10);
        const _0x3670b9 = {};
        for (let _0x12e614 = 0x0; _0x12e614 < _0x4e765b && _0x497c31 + 0x2e <= _0x471b90.length; _0x12e614++) {
            if (_0xe9fec(_0x471b90, _0x497c31) !== 0x2014b50) {
                break;
            }
            const _0x39cae1 = _0x4269df(_0x471b90, _0x497c31 + 0xa), _0x3d4f9e = _0xe9fec(_0x471b90, _0x497c31 + 0x14), _0x3c5595 = _0x4269df(_0x471b90, _0x497c31 + 0x1c), _0x4ab801 = _0x4269df(_0x471b90, _0x497c31 + 0x1e), _0x2360df = _0x4269df(_0x471b90, _0x497c31 + 0x20), _0x977c5e = _0xe9fec(_0x471b90, _0x497c31 + 0x2a), _0x4608c6 = _0x3f646b.decode(_0x471b90.subarray(_0x497c31 + 0x2e, _0x497c31 + 0x2e + _0x3c5595));
            _0x3670b9[_0x4608c6] = async () => {
                const _0x3c2798 = _0x977c5e + 0x1e + _0x4269df(_0x471b90, _0x977c5e + 0x1a) + _0x4269df(_0x471b90, _0x977c5e + 0x1c), _0x562024 = _0x471b90.subarray(_0x3c2798, _0x3c2798 + _0x3d4f9e);
                if (_0x39cae1 === 0x0) {
                    return _0x562024;
                }
                if (_0x39cae1 === 0x8) {
                    return _0x1c1846(_0x562024);
                }
                throw new Error('desteklenmeyen sıkıştırma ' + _0x39cae1);
            };
            _0x497c31 += 0x2e + _0x3c5595 + _0x4ab801 + _0x2360df;
        }
        return _0x3670b9;
    }
    const _0x2c4a6e = _0x373915 => _0x373915.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '\x22').replace(/&apos;/g, '\x27').replace(/&#(\d+);/g, (_0x4a8d6a, _0x572071) => String.fromCodePoint(+_0x572071)).replace(/&#x([0-9a-f]+);/gi, (_0x4c0e66, _0xd0d663) => String.fromCodePoint(parseInt(_0xd0d663, 0x10))).replace(/&amp;/g, '&');
    async function _0x49e453(_0x1a4bd8) {
        const _0x3b5ad8 = _0xc4c474(_0x1a4bd8);
        if (!_0x3b5ad8['word/document.xml']) {
            throw new Error("word/document.xml yok");
        }
        const _0x44bd25 = _0x3f646b.decode(await _0x3b5ad8['word/document.xml']()), _0x597ff9 = [], _0x2c18da = [];
        _0x44bd25.replace(/<w:tbl>([\s\S]*?)<\/w:tbl>/g, (_0x4c8cb6, _0x3a46bd) => {
            const _0x1e99e1 = [];
            _0x3a46bd.replace(/<w:tr[ >][\s\S]*?<\/w:tr>/g, _0x58ab24 => {
                const _0x44543e = [];
                _0x58ab24.replace(/<w:tc>([\s\S]*?)<\/w:tc>/g, (_0x2780a2, _0x3b360) => {
                    let _unused_pxjc;
                    _0x44543e.push(_0x2c4a6e((_0x3b360.match(/<w:t[^>]*>[^<]*<\/w:t>/g) || []).map(_0x1feb86 => _0x1feb86.replace(/<[^>]+>/g, '')).join('')).trim());
                    return '';
                });
                _0x1e99e1.push(_0x44543e);
                return '';
            });
            _0x2c18da.push(_0x1e99e1);
            return '';
        });
        _0x44bd25.replace(/<w:p[ >][\s\S]*?<\/w:p>/g, _0x335231 => {
            const _0x1e1645 = _0x2c4a6e((_0x335231.match(/<w:t[^>]*>[^<]*<\/w:t>|<w:tab\/>/g) || []).map(_0x20b5a1 => _0x20b5a1 === "<w:tab/>" ? '\x09' : _0x20b5a1.replace(/<[^>]+>/g, '')).join(''));
            _0x597ff9.push(_0x1e1645);
            return '';
        });
        return { 'text': _0x597ff9.join('\x0a').replace(/\n{3,}/g, '\x0a\x0a').trim(), 'tables': _0x2c18da };
    }
    function _0xae57ea(_0x20f66e) {
        const _0x2c273a = /^([A-Z]+)/.exec(_0x20f66e || '');
        let _0x2c6517 = 0x0;
        if (!_0x2c273a) {
            return -0x1;
        }
        for (const _0x5b6b79 of _0x2c273a[0x1]) {
            _0x2c6517 = _0x2c6517 * 0x1a + (_0x5b6b79.charCodeAt(0x0) - 0x40);
        }
        return _0x2c6517 - 0x1;
    }
    async function _0x2378f3(_0x476c14, _0x3a677e) {
        const _0x2e17c1 = _0xc4c474(_0x476c14), _0x575d0e = [];
        if (_0x2e17c1['xl/sharedStrings.xml']) {
            const _0x49a85b = _0x3f646b.decode(await _0x2e17c1['xl/sharedStrings.xml']());
            _0x49a85b.replace(/<si>([\s\S]*?)<\/si>/g, (_0x307b3c, _0x1098e2) => {
                let _unused_gko7;
                _0x575d0e.push(_0x2c4a6e((_0x1098e2.match(/<t[^>]*>[^<]*<\/t>/g) || []).map(_0x46d29a => _0x46d29a.replace(/<[^>]+>/g, '')).join('')));
                return '';
            });
        }
        const _0x2c3c1e = [];
        if (_0x2e17c1['xl/workbook.xml']) {
            _0x3f646b.decode(await _0x2e17c1['xl/workbook.xml']()).replace(/<sheet [^>]*name="([^"]*)"/g, (_0x48be9c, _0xa6df15) => {
                let _unused_3rga;
                _0x2c3c1e.push(_0x2c4a6e(_0xa6df15));
                return '';
            });
        }
        const _0xafd63f = Object.keys(_0x2e17c1).filter(_0x54a823 => /^xl\/worksheets\/sheet\d+\.xml$/.test(_0x54a823)).sort((_0x4cd3f9, _0x380689) => parseInt(_0x4cd3f9.match(/\d+/)) - parseInt(_0x380689.match(/\d+/))), _0x3c8b61 = [];
        for (let _0x2fecc2 = 0x0; _0x2fecc2 < _0xafd63f.length && _0x2fecc2 < 0x5; _0x2fecc2++) {
            const _0x5d4f44 = _0x3f646b.decode(await _0x2e17c1[_0xafd63f[_0x2fecc2]]()), _0x5ec1e3 = [];
            _0x5d4f44.replace(/<row([^>]*?)(?:\/>|>([\s\S]*?)<\/row>)/g, (_0x52b2d0, _0x4ed234, _0x51f57b) => {
                const _0x3a96ec = +((_0x4ed234.match(/ r="(\d+)"/) || [])[0x1] || _0x5ec1e3.length + 0x1);
                if (_0x3a96ec > (_0x3a677e || 0x3c)) {
                    return '';
                }
                while (_0x5ec1e3.length < _0x3a96ec - 0x1) {
                    _0x5ec1e3.push([]);
                }
                _0x51f57b = _0x51f57b || '';
                const _0x5f3f1c = [];
                _0x51f57b.replace(/<c ([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g, (_0x17b0f1, _0x2f8503, _0x3a3e6) => {
                    const _0x35167c = (_0x2f8503.match(/r="([A-Z]+\d+)"/) || [])[0x1], _0xde9fbd = (_0x2f8503.match(/t="([^"]+)"/) || [])[0x1];
                    let _0xc9cfc9 = '';
                    if (_0x3a3e6) {
                        if (_0xde9fbd === 'inlineStr') {
                            _0xc9cfc9 = _0x2c4a6e((_0x3a3e6.match(/<t[^>]*>[^<]*<\/t>/g) || []).map(_0x50b34f => _0x50b34f.replace(/<[^>]+>/g, '')).join(''));
                        }
                        else {
                            const _0x475176 = (_0x3a3e6.match(/<v>([^<]*)<\/v>/) || [])[0x1];
                            if (_0x475176 !== undefined) {
                                _0xc9cfc9 = _0xde9fbd === 's' ? _0x575d0e[+_0x475176] || '' : _0x2c4a6e(_0x475176);
                            }
                        }
                    }
                    const _0x4b343e = _0x35167c ? _0xae57ea(_0x35167c) : _0x5f3f1c.length;
                    while (_0x5f3f1c.length < _0x4b343e) {
                        _0x5f3f1c.push('');
                    }
                    _0x5f3f1c[_0x4b343e] = String(_0xc9cfc9).trim();
                    return '';
                });
                _0x5ec1e3.push(_0x5f3f1c);
                return '';
            });
            _0x3c8b61.push({ 'name': _0x2c3c1e[_0x2fecc2] || 'Sayfa' + (_0x2fecc2 + 0x1), 'rows': _0x5ec1e3 });
        }
        return { 'sheets': _0x3c8b61 };
    }
    function _0xf8c1d(_0x47f222) {
        const _0xc44647 = _0x47f222 instanceof Uint8Array ? _0x47f222 : new Uint8Array(_0x47f222), _0x3509df = [];
        for (let _0x566051 = 0x0; _0x566051 + 0x8 < _0xc44647.length && _0x3509df.length < 0x190; _0x566051++) {
            if (_0x4269df(_0xc44647, _0x566051) !== 0xfc) {
                continue;
            }
            const _0x4df7fd = _0x4269df(_0xc44647, _0x566051 + 0x2);
            if (_0x4df7fd < 0x8 || _0x566051 + 0x4 + _0x4df7fd > _0xc44647.length) {
                continue;
            }
            const _0x2a66b2 = _0xe9fec(_0xc44647, _0x566051 + 0x4), _0x42a32d = _0xe9fec(_0xc44647, _0x566051 + 0x8);
            if (!_0x42a32d || _0x42a32d > _0x2a66b2 || _0x42a32d > 0x186a0) {
                continue;
            }
            let _0x31016d = _0x566051 + 0xc;
            const _0x3685c4 = _0x566051 + 0x4 + _0x4df7fd;
            for (let _0x3b631c = 0x0; _0x3b631c < _0x42a32d && _0x31016d + 0x3 <= _0x3685c4; _0x3b631c++) {
                const _0x5e990a = _0x4269df(_0xc44647, _0x31016d), _0x9a14ae = _0xc44647[_0x31016d + 0x2];
                _0x31016d += 0x3;
                let _0x491db6 = 0x0, _0x580dbd = 0x0;
                _0x9a14ae & 0x8 && (_0x491db6 = _0x4269df(_0xc44647, _0x31016d), _0x31016d += 0x2);
                _0x9a14ae & 0x4 && (_0x580dbd = _0xe9fec(_0xc44647, _0x31016d), _0x31016d += 0x4);
                let _0x2e0650 = '';
                if (_0x9a14ae & 0x1) {
                    for (let _0x230e66 = 0x0; _0x230e66 < _0x5e990a && _0x31016d + 0x1 < _0x3685c4; _0x230e66++, _0x31016d += 0x2) {
                        _0x2e0650 += String.fromCharCode(_0x4269df(_0xc44647, _0x31016d));
                    }
                }
                else {
                    for (let _0x1efce8 = 0x0; _0x1efce8 < _0x5e990a && _0x31016d < _0x3685c4; _0x1efce8++, _0x31016d++) {
                        _0x2e0650 += String.fromCharCode(_0xc44647[_0x31016d]);
                    }
                }
                _0x31016d += _0x491db6 * 0x4 + _0x580dbd;
                if (_0x2e0650.trim()) {
                    _0x3509df.push(_0x2e0650.trim());
                }
            }
            break;
        }
        return _0x3509df;
    }
    let _0x2793f0 = null;
    async function _0x563fdc() {
        if (!_0x2793f0) {
            _0x2793f0 = ((async () => {
                const _0x49f4c1 = _0x41d0c2.chrome && chrome.runtime && chrome.runtime.getURL ? chrome.runtime.getURL("pdfjs/pdf.min.mjs") : _0x41d0c2.__EBYS_PDFJS_URL, _0x1f1f89 = await import(_0x49f4c1);
                try {
                    _0x1f1f89.GlobalWorkerOptions.workerSrc = _0x49f4c1.replace(/pdf\.min\.mjs$/, 'pdf.worker.min.mjs');
                }
                catch (_0x5dab9e) {
                }
                return _0x1f1f89;
            })());
        }
        return _0x2793f0;
    }
    async function _0x5892eb(_0x20071e, _0x2b280e) {
        const _0x5a516b = await _0x563fdc(), _0x246b67 = await _0x5a516b.getDocument({ 'data': new Uint8Array(_0x20071e), 'isEvalSupported': false, 'useSystemFonts': false, 'disableFontFace': !false }).promise, _0x229af0 = Math.min(_0x246b67.numPages, _0x2b280e || 0x6), _0x35f752 = [];
        for (let _0x5af135 = 0x1; _0x5af135 <= _0x229af0; _0x5af135++) {
            const _0x11e0c4 = await (await _0x246b67.getPage(_0x5af135)).getTextContent();
            let _0x562e1a = '', _0x3d39d8 = null;
            for (const _0x1ea801 of _0x11e0c4.items) {
                const _0x1fa2cb = _0x1ea801.transform ? Math.round(_0x1ea801.transform[0x5]) : null;
                _0x3d39d8 !== null && _0x1fa2cb !== null && Math.abs(_0x1fa2cb - _0x3d39d8) > 0x2 && (_0x35f752.push(_0x562e1a), _0x562e1a = '');
                _0x562e1a += _0x1ea801.str;
                _0x3d39d8 = _0x1fa2cb;
                _0x1ea801.hasEOL && (_0x35f752.push(_0x562e1a), _0x562e1a = '', _0x3d39d8 = null);
            }
            if (_0x562e1a) {
                _0x35f752.push(_0x562e1a);
            }
        }
        try {
            _0x246b67.destroy();
        }
        catch (_0x236384) {
        }
        return _0x35f752.join('\x0a').replace(/[ \t]+/g, ' ').trim();
    }
    const _0x509c03 = /(istenmektedir|istenmekte|gönderilmesi|gönderilmesini|doldurul|bildirilmesi|bildirilmesini|iletilmesi|iletilmesini|yüklenmesi|hazırlanması|teslim edilmesi|eksiksiz|en geç|tarihine kadar|son gün)/i;
    function _0xca8681(_0xe377bd, _0x2bf7e9) {
        const _0x248d49 = [];
        String(_0xe377bd || '').split(/\n|(?<=[.!?])\s+/).map(_0x24b72c => _0x24b72c.replace(/\s+/g, ' ').trim()).forEach(_0x194b5c => {
            let _unused_ibz7;
            if (_0x194b5c.length >= 0xf && _0x194b5c.length <= 0x12c && _0x509c03.test(_0x194b5c) && !_0x248d49.includes(_0x194b5c) && _0x248d49.length < (_0x2bf7e9 || 0x6)) {
                _0x248d49.push(_0x194b5c);
            }
        });
        return _0x248d49;
    }
    const _0x2f081b = _0x55acf7 => {
        const _0x400146 = String(_0x55acf7 || '').trim();
        return _0x400146.length >= 0x2 && _0x400146.length <= 0x3c && /[A-Za-zÇĞİÖŞÜçğıöşü]/.test(_0x400146) && !/^\d+([.,]\d+)?$/.test(_0x400146);
    };
    function _0x33b627(_0x404ead) {
        let _unused_s3uz;
        let _0x5bb8a7 = -0x1, _0x3cb0c8 = 0x0;
        for (let _0x4e8f11 = 0x0; _0x4e8f11 < Math.min(_0x404ead.length, 0xf); _0x4e8f11++) {
            const _0x3513c3 = (_0x404ead[_0x4e8f11] || []).filter(_0x2f081b).length;
            _0x3513c3 > _0x3cb0c8 && _0x3513c3 >= 0x2 && (_0x5bb8a7 = _0x4e8f11, _0x3cb0c8 = _0x3513c3);
        }
        if (_0x5bb8a7 < 0x0) {
            return null;
        }
        const _0x26f558 = _0x404ead[_0x5bb8a7].map(_0x17ae45 => String(_0x17ae45 || '').trim()), _0x1e9881 = _0x26f558.filter(_0x2f081b).filter((_0x23c506, _0x4dfb1, _0x48f926) => _0x48f926.indexOf(_0x23c506) === _0x4dfb1).slice(0x0, 0x28), _0x1ba57c = _0x404ead.slice(_0x5bb8a7 + 0x1, _0x5bb8a7 + 0x1e), _0x45b778 = _0x1ba57c.filter(_0x1ab6e8 => (_0x1ab6e8 || []).some((_0x53d37f, _0x175cc1) => _0x26f558[_0x175cc1] && String(_0x53d37f || '').trim() && !/^\d+$/.test(String(_0x53d37f).trim()))).length, _0x1a743e = _0x404ead.slice(0x0, _0x5bb8a7).map(_0x3770a4 => (_0x3770a4 || []).filter(Boolean).join(' ')).filter(Boolean).join(" — ").slice(0x0, 0xc8);
        return { 'headerRow': _0x5bb8a7 + 0x1, 'fields': _0x1e9881, 'emptyForm': _0x45b778 === 0x0, 'filledRows': _0x45b778, 'title': _0x1a743e };
    }
    function _0x494c78(_0x41e20e) {
        const _0x7f9044 = /\.([a-z0-9]{2,5})\s*$/i.exec(String(_0x41e20e || '').replace(/[)\s]+$/, ''));
        return _0x7f9044 ? _0x7f9044[0x1].toLowerCase() : '';
    }
    async function _0x30e453(_0x42efa9, _0x17fb97) {
        const _0x248efa = _0x494c78(_0x17fb97), _0x54c19c = _0x42efa9 instanceof Uint8Array ? _0x42efa9 : new Uint8Array(_0x42efa9), _0x378824 = _0x54c19c[0x0] === 0x50 && _0x54c19c[0x1] === 0x4b, _0x5c0030 = _0x54c19c[0x0] === 0x25 && _0x54c19c[0x1] === 0x50 && _0x54c19c[0x2] === 0x44 && _0x54c19c[0x3] === 0x46, _0x4de24d = _0x54c19c[0x0] === 0xd0 && _0x54c19c[0x1] === 0xcf, _0x50296e = { 'kind': _0x248efa, 'text': '', 'form': null, 'sheets': null, 'points': [], 'note': '', 'approx': false };
        if (_0x5c0030 || _0x248efa === 'pdf') {
            _0x50296e.kind = 'pdf';
            _0x50296e.text = await _0x5892eb(_0x54c19c);
            if (!_0x50296e.text) {
                _0x50296e.note = 'PDF\x27te metin katmanı yok (taranmış görüntü olabilir).';
            }
        }
        else {
            if (_0x378824 && (_0x248efa === "docx" || _0x248efa === "odt" || !_0x248efa)) {
                const _0xa399c6 = await _0x49e453(_0x54c19c);
                _0x50296e.kind = "docx";
                _0x50296e.text = _0xa399c6.text;
                const _0x19c65b = _0xa399c6.tables.find(_0x1607a0 => _0x33b627(_0x1607a0));
                if (_0x19c65b) {
                    _0x50296e.form = _0x33b627(_0x19c65b);
                }
                const _0x5ccf8d = _0xa399c6.text.split('\x0a').map(_0x482fe5 => (/^\s*([^:：\t_]{2,50}?)\s*[:：]\s*(_{3,}|\.{4,}|…{2,}|\t+)/.exec(_0x482fe5) || /^\s*([^:：\t_]{2,50}?)\s*[:：].*_{3,}/.exec(_0x482fe5) || [])[0x1]).filter(Boolean).map(_0x42efd4 => _0x42efd4.trim()), _0x3e0a42 = _0xa399c6.tables.find(_0x22e9c8 => _0x22e9c8.filter(_0x36e0b2 => _0x36e0b2.length === 0x2 && _0x2f081b(_0x36e0b2[0x0]) && !_0x36e0b2[0x1]).length >= 0x2);
                if (_0x3e0a42) {
                    const _0x33476d = _0x3e0a42.filter(_0x51b525 => _0x51b525.length === 0x2 && _0x2f081b(_0x51b525[0x0]) && !_0x51b525[0x1]).map(_0x1d348e => _0x1d348e[0x0].replace(/[:：]\s*$/, ''));
                    if (!_0x50296e.form || _0x33476d.length >= _0x50296e.form.fields.length - 0x1) {
                        _0x50296e.form = { 'headerRow': 0x0, 'fields': _0x33476d, 'emptyForm': !false, 'filledRows': 0x0, 'title': '', 'vertical': !false };
                    }
                }
                if (_0x5ccf8d.length) {
                    _0x50296e.form = { 'headerRow': 0x0, 'fields': _0x5ccf8d.concat(_0x50296e.form ? _0x50296e.form.fields.filter(_0x37bb64 => !_0x5ccf8d.includes(_0x37bb64)) : []), 'emptyForm': !false, 'filledRows': 0x0, 'title': '', 'paragraph': !false };
                }
            }
            else {
                if (_0x378824 && (_0x248efa === "xlsx" || _0x248efa === 'xlsm')) {
                    const _0x499f77 = await _0x2378f3(_0x54c19c);
                    _0x50296e.kind = 'xlsx';
                    _0x50296e.sheets = _0x499f77.sheets;
                    for (const _0x31df22 of _0x499f77.sheets) {
                        const _0x515966 = _0x33b627(_0x31df22.rows);
                        if (_0x515966) {
                            _0x515966.sheet = _0x31df22.name;
                            _0x50296e.form = _0x515966;
                            break;
                        }
                    }
                    _0x50296e.text = _0x499f77.sheets.map(_0x580f7b => _0x580f7b.rows.slice(0x0, 0x14).map(_0x411585 => _0x411585.filter(Boolean).join(' | ')).filter(Boolean).join('\x0a')).join('\x0a');
                }
                else {
                    if (_0x4de24d && _0x248efa === 'xls') {
                        const _0x2254da = _0xf8c1d(_0x54c19c);
                        _0x50296e.kind = 'xls';
                        _0x50296e.approx = !false;
                        _0x50296e.text = _0x2254da.join('\x0a');
                        const _0x5138d6 = _0x2254da.filter(_0x2f081b).slice(0x0, 0x28);
                        if (_0x5138d6.length >= 0x2) {
                            _0x50296e.form = { 'headerRow': 0x0, 'fields': _0x5138d6, 'emptyForm': null, 'filledRows': null, 'title': '', 'approx': !false };
                        }
                        _0x50296e.note = "Eski Excel (.xls): metinler yaklaşık okundu; sütun sırası doğrulanmalı.";
                    }
                    else {
                        _0x50296e.note = 'Bu dosya türü okunmuyor (' + (_0x248efa || "bilinmiyor") + ').';
                        return _0x50296e;
                    }
                }
            }
        }
        _0x50296e.points = _0xca8681(_0x50296e.text, 0x4);
        if (_0x50296e.form && _0x50296e.form.fields.length) {
            _0x50296e.points.push("Form alanları: " + _0x50296e.form.fields.slice(0x0, 0x8).join(', ') + (_0x50296e.form.fields.length > 0x8 ? '…' : ''));
        }
        return _0x50296e;
    }
    const _0x30f540 = [["kurumTuru", "Kurum türü", ["kurum turu", "kurum tipi"]], ['okulAdi', "Kurum adı", ["okul adi", "okulun adi", "kurum adi", "kurumun adi", "okul", "kurum", 'okul ismi', 'kurumadi']], ["ustBirim", "Bağlı üst birim", ['ust birim', "bagli birim", 'bagli oldugu birim', 'ust kurum']], ['kurumKodu', "Kurum kodu", ['kurum kodu', "okul kodu", "kurum kod", 'mebbis kodu', 'kurum no']], ['detsis', 'DETSİS / MERSİS no', ["detsis", "mersis", "detsis no", "mersis no"]], ['ilIlce', 'İl / İlçe', ['il ilce', 'il ve ilce', 'ili ilcesi', 'il ilcesi']], ['il', 'İl', ['il', 'ili', "il adi"]], ['ilce', 'İlçe', ['ilce', "ilcesi", "ilce adi"]], ["adres", "Adres", ["adres", "adresi", 'okul adresi', "kurum adresi", "acik adres"]], ['telefon', 'Telefon', ['telefon', 'tel', 'telefon no', "telefon numarasi", "okul telefonu", "irtibat telefonu", "tel no"]], ["faks", "Faks", ['faks', "fax", "belgegecer"]], ['eposta', "E-posta", ["e posta", 'eposta', 'e mail', "email", 'mail', 'elektronik posta', 'e posta adresi']], ['web', 'Web adresi', ['web', 'web adresi', "internet adresi", "web sitesi"]], ["mudur", "Amir adı (Müdür / İlçe MEM Müdürü)", ['mudur', 'okul muduru', "kurum muduru", "mudurun adi soyadi", "muduru", 'kurum amiri', "amir adi"]], ['amirUnvani', 'Amir unvanı', ["amir unvani", 'unvan', "imza unvani"]], ['mudurYrd', "Müdür yardımcısı / şube müdürü", ['mudur yardimcisi', 'mudur yrd', "mudur yardimcilari", "sorumlu mudur yardimcisi", "sube muduru"]], ['irtibatKisi', 'İrtibat kişisi', ['irtibat', "irtibat kisisi", "sorumlu", "sorumlu kisi", 'yetkili', 'dolduran', "hazirlayan"]], ['ogrenciSayisi', 'Öğrenci sayısı', ["ogrenci sayisi", "toplam ogrenci", 'ogrenci mevcudu', "mevcut", "toplam ogrenci sayisi"]], ["kizOgrenci", "Kız öğrenci sayısı", ["kiz", "kiz ogrenci", "kiz ogrenci sayisi"]], ["erkekOgrenci", "Erkek öğrenci sayısı", ["erkek", "erkek ogrenci", "erkek ogrenci sayisi"]], ['ogretmenSayisi', 'Öğretmen sayısı', ['ogretmen sayisi', 'toplam ogretmen', "kadrolu ogretmen", 'ogretmen']], ['personelSayisi', "Personel sayısı", ['personel sayisi', "toplam personel", 'personel']], ["derslikSayisi", 'Derslik sayısı', ["derslik sayisi", 'derslik', "sinif sayisi", "dershane sayisi"]], ["subeSayisi", "Şube sayısı", ["sube sayisi", "sube"]], ["ogretimSekli", "Öğretim şekli", ["ogretim sekli", "normal ikili", 'tam gun yarim gun']], ['egitimYili', "Eğitim-öğretim yılı", ["egitim ogretim yili", 'ogretim yili', 'egitim yili']]], _0x547beb = _0xf35e7 => String(_0xf35e7 || '').toLocaleLowerCase('tr-TR').replace(/ı/g, 'i').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ş/g, 's').replace(/ö/g, 'o').replace(/ç/g, 'c').replace(/[^a-z0-9]+/g, ' ').trim(), _0x34c2d1 = /\b(kulup|kulubu|kolu|danisman|danismani|ogretmenin|ogretmenlerin|velinin|velisi|ogrencinin|ogrencilerin|personelin|katilimci|katilimcinin|gorevlinin|isletme|isletmenin|isletmesi|stajyer|usta|firma|firmanin|sirket|koordinator)\b/, _0x6b17fc = /\d|\b(sinif|sinifi|kiz|erkek|alan|alani|dal|dali|program|brans|subesi|yas|donem)\b/, _0x1699b0 = /\b(alan|dal|sinif|isletme|isletmenin|brans|adi soyadi|ad soyad|tc kimlik|ogrenci adi|ogrencinin)\b|\b\d+\s*(\.|\b)\s*sinif/, _0x445646 = new Set(["okulAdi", 'kurumKodu', 'il', 'ilce', 'ilIlce']), _0x3bdabd = new Set(['ogrenciSayisi', "kizOgrenci", 'erkekOgrenci', "ogretmenSayisi", "personelSayisi", 'derslikSayisi', "subeSayisi"]), _0x5444c7 = new Set(['telefon', 'eposta', "faks", "adres", "web", 'irtibatKisi', "mudurYrd", 'mudur']);
    function _0x2372e1(_0x13e778, _0x384d49, _0x284afb) {
        const _0x95ff27 = _0x5c712e(_0x13e778);
        if (!_0x95ff27) {
            return null;
        }
        const _0x271c84 = _0x547beb(_0x13e778), _0x588f10 = _0x547beb(_0x384d49 || '');
        if (_0x34c2d1.test(_0x271c84) && !_0x445646.has(_0x95ff27)) {
            return null;
        }
        if (_0x3bdabd.has(_0x95ff27) && (_0x6b17fc.test(_0x271c84.replace(/\b(kiz|erkek)\b/, _0x95ff27 === "kizOgrenci" || _0x95ff27 === "erkekOgrenci" ? '' : '$&')) || _0x34c2d1.test(_0x588f10) || _0x6b17fc.test(_0x588f10.replace(/\b(egitim ogretim yili|\d{4}\s*\d{4})\b/g, '')))) {
            return null;
        }
        if ((_0x95ff27 === "kizOgrenci" || _0x95ff27 === "erkekOgrenci") && !/ogrenci/.test(_0x271c84)) {
            return null;
        }
        if (_0x588f10 && _0x34c2d1.test(_0x588f10) && (_0x3bdabd.has(_0x95ff27) || _0x5444c7.has(_0x95ff27))) {
            return null;
        }
        if (_0x284afb === "row") {
            if (!_0x445646.has(_0x95ff27)) {
                if (!(/\b(okul|okulun|kurum|kurumun)\b/.test(_0x271c84) && _0x5444c7.has(_0x95ff27))) {
                    return null;
                }
            }
        }
        return _0x95ff27;
    }
    function _0x3f0ff8(_0x5969f9, _0x5adcba) {
        const _0x576838 = _0x547beb((_0x5969f9 || []).join(' ') + ' ' + (_0x5adcba || ''));
        return _0x1699b0.test(_0x576838);
    }
    function _0x5c712e(_0x45bcd2) {
        const _0x14761c = _0x547beb(_0x45bcd2).replace(/\b(nin|nın|in|ın|un|ün|no|numarasi)\b$/, '').trim();
        if (!_0x14761c || _0x14761c.length > 0x3c) {
            return null;
        }
        if (/\b(formu|listesi|cizelgesi|tablosu|cetveli|raporu)$/.test(_0x14761c)) {
            return null;
        }
        const _0x1f8d5a = _0x14761c.split(' ').length;
        let _0x27fd97 = null, _0x543912 = 0x0;
        for (const [_0x12a741, , _0x55cbd5] of _0x30f540) {
            for (const _0x295b62 of _0x55cbd5) {
                let _0x205014 = 0x0;
                if (_0x14761c === _0x295b62) {
                    _0x205014 = 0x64 + _0x295b62.length;
                }
                else {
                    if (_0x295b62.length >= 0x5 && (_0x14761c.startsWith(_0x295b62 + ' ') || _0x14761c.endsWith(' ' + _0x295b62))) {
                        _0x205014 = 0x3c + _0x295b62.length;
                    }
                    else {
                        if (_0x295b62.length >= 0x5 && _0x1f8d5a <= _0x295b62.split(' ').length + 0x2 && _0x295b62.split(' ').every(_0x16a82f => (' ' + _0x14761c + ' ').includes(' ' + _0x16a82f + ' '))) {
                            _0x205014 = 0x28 + _0x295b62.length;
                        }
                    }
                }
                _0x205014 > _0x543912 && (_0x543912 = _0x205014, _0x27fd97 = _0x12a741);
            }
        }
        return _0x27fd97;
    }
    const _0x58f028 = new TextEncoder(), _0x5d7299 = ((() => {
        const _0x140297 = new Uint32Array(0x100);
        for (let _0x218ce7 = 0x0; _0x218ce7 < 0x100; _0x218ce7++) {
            let _0x46dae6 = _0x218ce7;
            for (let _0x1b1edc = 0x0; _0x1b1edc < 0x8; _0x1b1edc++) {
                _0x46dae6 = _0x46dae6 & 0x1 ? 0xedb88320 ^ _0x46dae6 >>> 0x1 : _0x46dae6 >>> 0x1;
            }
            _0x140297[_0x218ce7] = _0x46dae6 >>> 0x0;
        }
        return _0x140297;
    })()), _0x2c71e0 = _0x9ef897 => {
        let _0xc452fb = 0xffffffff;
        for (let _0x55e263 = 0x0; _0x55e263 < _0x9ef897.length; _0x55e263++) {
            _0xc452fb = _0x5d7299[(_0xc452fb ^ _0x9ef897[_0x55e263]) & 0xff] ^ _0xc452fb >>> 0x8;
        }
        return (_0xc452fb ^ 0xffffffff) >>> 0x0;
    };
    function _0x3c4bc1(_0x43dd42) {
        const _0x23db7d = [], _0xe36232 = [];
        let _0x232fc2 = 0x0;
        const _0x4772b1 = _0x279a4b => [_0x279a4b & 0xff, _0x279a4b >>> 0x8 & 0xff], _0x517c5e = _0x487476 => [_0x487476 & 0xff, _0x487476 >>> 0x8 & 0xff, _0x487476 >>> 0x10 & 0xff, _0x487476 >>> 0x18 & 0xff];
        for (const _0x3357d5 of _0x43dd42) {
            const _0x21657e = _0x58f028.encode(_0x3357d5.name), _0x56d0ff = _0x2c71e0(_0x3357d5.data), _0x26f8ef = _0x3357d5.data.length, _0x14746e = new Uint8Array([].concat(_0x517c5e(0x4034b50), _0x4772b1(0x14), _0x4772b1(0x800), _0x4772b1(0x0), _0x4772b1(0x0), _0x4772b1(0x21), _0x517c5e(_0x56d0ff), _0x517c5e(_0x26f8ef), _0x517c5e(_0x26f8ef), _0x4772b1(_0x21657e.length), _0x4772b1(0x0)));
            _0x23db7d.push(_0x14746e, _0x21657e, _0x3357d5.data);
            _0xe36232.push(new Uint8Array([].concat(_0x517c5e(0x2014b50), _0x4772b1(0x14), _0x4772b1(0x14), _0x4772b1(0x800), _0x4772b1(0x0), _0x4772b1(0x0), _0x4772b1(0x21), _0x517c5e(_0x56d0ff), _0x517c5e(_0x26f8ef), _0x517c5e(_0x26f8ef), _0x4772b1(_0x21657e.length), _0x4772b1(0x0), _0x4772b1(0x0), _0x4772b1(0x0), _0x4772b1(0x0), _0x517c5e(0x0), _0x517c5e(_0x232fc2))), _0x21657e);
            _0x232fc2 += _0x14746e.length + _0x21657e.length + _0x26f8ef;
        }
        const _0x4a0967 = _0xe36232.reduce((_0x29ee60, _0xbfe97) => _0x29ee60 + _0xbfe97.length, 0x0), _0x9fb3b9 = new Uint8Array([].concat(_0x517c5e(0x6054b50), _0x4772b1(0x0), _0x4772b1(0x0), _0x4772b1(_0x43dd42.length), _0x4772b1(_0x43dd42.length), _0x517c5e(_0x4a0967), _0x517c5e(_0x232fc2), _0x4772b1(0x0))), _0x48cd78 = _0x23db7d.concat(_0xe36232, [_0x9fb3b9]), _0x1b6c1b = new Uint8Array(_0x48cd78.reduce((_0x17917d, _0x2ceb7c) => _0x17917d + _0x2ceb7c.length, 0x0));
        let _0x2e822c = 0x0;
        for (const _0x23ca2b of _0x48cd78) {
            _0x1b6c1b.set(_0x23ca2b, _0x2e822c);
            _0x2e822c += _0x23ca2b.length;
        }
        return _0x1b6c1b;
    }
    const _0x1d6b57 = _0x360903 => String(_0x360903).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"), _0x1539db = _0x1ebda9 => {
        let _unused_jro7;
        let _0x584d8f = '';
        _0x1ebda9++;
        while (_0x1ebda9 > 0x0) {
            const _0x2e56d3 = (_0x1ebda9 - 0x1) % 0x1a;
            _0x584d8f = String.fromCharCode(0x41 + _0x2e56d3) + _0x584d8f;
            _0x1ebda9 = Math.floor((_0x1ebda9 - 0x1) / 0x1a);
        }
        return _0x584d8f;
    };
    function _0x5b4b2b(_0x536032, _0x4bb9d4) {
        const _0x391e59 = _0x4bb9d4 || {}, _0x434f54 = [], _0x254a5f = new Set(), _0x3d942c = _0x33b627(_0x536032), _0x1b07ce = [];
        _0x536032.slice(0x0, 0x3c).forEach((_0x581897, _0x42e106) => {
            (_0x581897 || []).forEach((_0x3e4de0, _0x5d2032) => {
                let _unused_w1sg;
                if (_0x2f081b(_0x3e4de0) && /[:：]?\s*$/.test(_0x3e4de0) && _0x2372e1(_0x3e4de0) && !String(_0x581897[_0x5d2032 + 0x1] || '').trim() && _0x581897.filter(Boolean).length <= 0x2) {
                    _0x1b07ce.push({ 'ri': _0x42e106, 'ci': _0x5d2032, 'label': _0x3e4de0 });
                }
            });
        });
        if (_0x1b07ce.length >= Math.max(0x2, _0x3d942c ? _0x3d942c.fields.filter(_0x2372e1).length : 0x0)) {
            _0x1b07ce.forEach(_0xfd3e78 => {
                const _0x1fe0e7 = _0x2372e1(_0xfd3e78.label), _0x37fd63 = _0x391e59[_0x1fe0e7];
                _0x434f54.push({ 'label': _0xfd3e78.label.replace(/[:：]\s*$/, ''), 'key': _0x1fe0e7, 'row': _0xfd3e78.ri + 0x1, 'col': _0xfd3e78.ci + 0x1, 'value': _0x37fd63 ? String(_0x37fd63) : '' });
            });
            _0x536032.slice(0x0, 0x3c).forEach((_0x5b056f, _0x3d6868) => {
                const _0x11ef8d = (_0x5b056f || []).map((_0x36f286, _0x29bace) => [_0x36f286, _0x29bace]).filter(_0x44f77d => String(_0x44f77d[0x0] || '').trim());
                if (_0x11ef8d.length === 0x1 && /[:：]\s*$/.test(_0x11ef8d[0x0][0x0]) && !_0x2372e1(_0x11ef8d[0x0][0x0])) {
                    _0x434f54.push({ 'label': String(_0x11ef8d[0x0][0x0]).replace(/[:：]\s*$/, ''), 'key': null, 'row': _0x3d6868 + 0x1, 'col': _0x11ef8d[0x0][0x1] + 0x1, 'value': '' });
                }
            });
            return { 'layout': "dikey", 'items': _0x434f54 };
        }
        if (!_0x3d942c) {
            return { 'layout': "yok", 'items': [] };
        }
        const _0x587a06 = _0x3d942c.headerRow - 0x1, _0x2ac3d2 = _0x536032[_0x587a06] || [], _0x1ddd2c = _0x3d942c.title || '', _0x4dc9f5 = _0x536032[_0x587a06 + 0x1] || [];
        _0x2ac3d2.forEach((_0x370e08, _0x46024e) => {
            let _unused_02ce;
            if (!_0x2f081b(_0x370e08) || _0x254a5f.has(_0x46024e)) {
                return;
            }
            _0x254a5f.add(_0x46024e);
            if (/^(s\.?\s*no|sn|sira( no)?|no)$/i.test(_0x547beb(_0x370e08))) {
                return;
            }
            const _0x3ac1a5 = String(_0x4dc9f5[_0x46024e] == null ? '' : _0x4dc9f5[_0x46024e]).trim(), _0x4ed4c4 = _0x3f0ff8(_0x2ac3d2, _0x1ddd2c);
            let _0x5f120b = _0x2372e1(_0x370e08, _0x1ddd2c, "row");
            if (_0x5f120b && _0x4ed4c4 && !_0x445646.has(_0x5f120b)) {
                _0x5f120b = null;
            }
            if (_0x5f120b && _0x4ed4c4 && /\b(alan|dal|sinif|isletme)\b/.test(_0x547beb(_0x2ac3d2.join(' ') + ' ' + _0x1ddd2c))) {
                _0x5f120b = null;
            }
            const _0x4a02ba = _0x5f120b ? _0x391e59[_0x5f120b] : '';
            if (_0x3ac1a5) {
                _0x434f54.push({ 'label': String(_0x370e08), 'key': _0x5f120b, 'row': _0x587a06 + 0x2, 'col': _0x46024e, 'value': _0x3ac1a5, 'existing': !false });
                return;
            }
            _0x434f54.push({ 'label': String(_0x370e08), 'key': _0x5f120b, 'row': _0x587a06 + 0x2, 'col': _0x46024e, 'value': _0x4a02ba ? String(_0x4a02ba) : '' });
        });
        // v3.6.68: liste formlarında (S.No ile önceden numaralanmış satırlar) okul sütunlarını her satıra yaz
        const okulSut = _0x434f54.filter(it => it.key && _0x445646.has(it.key) && it.value && !it.existing);
        if (okulSut.length) {
            for (let r = _0x587a06 + 0x2; r < Math.min(_0x536032.length, _0x587a06 + 0x1f5); r++) {
                const satir = _0x536032[r] || [];
                if (!satir.some(v => String(v == null ? '' : v).trim())) continue;
                for (const it of okulSut) {
                    if (String(satir[it.col] == null ? '' : satir[it.col]).trim()) continue;
                    _0x434f54.push({ 'label': it.label, 'key': it.key, 'row': r + 0x1, 'col': it.col, 'value': it.value, 'ekSatir': true });
                }
            }
        }
        return { 'layout': 'yatay', 'items': _0x434f54, 'headerRow': _0x3d942c.headerRow };
    }
    async function _0x25999d(_0x25b5bc, _0x1dcbd7) {
        const _0x16cbb4 = _0xc4c474(_0x25b5bc), _0x11e891 = await _0x2378f3(_0x25b5bc, 0x50);
        let _0x535dde = 0x0, _0x1af125 = null;
        for (; _0x535dde < _0x11e891.sheets.length; _0x535dde++) {
            _0x1af125 = _0x5b4b2b(_0x11e891.sheets[_0x535dde].rows, _0x1dcbd7);
            if (_0x1af125.items.length) {
                break;
            }
        }
        if (!_0x1af125 || !_0x1af125.items.length) {
            return { 'ok': false, 'error': "Form alanı bulunamadı", 'plan': _0x1af125 };
        }
        const _0x4928ee = Object.keys(_0x16cbb4).filter(_0x34d61d => /^xl\/worksheets\/sheet\d+\.xml$/.test(_0x34d61d)).sort((_0x490284, _0x64e207) => parseInt(_0x490284.match(/\d+/)) - parseInt(_0x64e207.match(/\d+/)))[_0x535dde];
        let _0xbd2f7e = _0x3f646b.decode(await _0x16cbb4[_0x4928ee]()), _0x307814 = _0x16cbb4['xl/styles.xml'] ? _0x3f646b.decode(await _0x16cbb4['xl/styles.xml']()) : null, _0x1208db = null;
        if (_0x307814) {
            const _0x320078 = +((_0x307814.match(/<fills count="(\d+)"/) || [])[0x1] || 0x0);
            _0x307814 = _0x307814.replace(/<fills count="(\d+)">([\s\S]*?)<\/fills>/, (_0x192124, _0x6f4856, _0x1f30e1) => '<fills count=\x22' + (+_0x6f4856 + 0x1) + '\x22>' + _0x1f30e1 + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFFFFF00\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>");
            _0x307814 = _0x307814.replace(/<cellXfs count="(\d+)">([\s\S]*?)<\/cellXfs>/, (_0x35e0af, _0xef8939, _0x35b8e1) => {
                let _unused_br55;
                _0x1208db = +_0xef8939;
                return '<cellXfs count=\x22' + (+_0xef8939 + 0x1) + '\x22>' + _0x35b8e1 + '<xf numFmtId=\x220\x22 fontId=\x220\x22 fillId=\x22' + _0x320078 + "\" borderId=\"0\" xfId=\"0\" applyFill=\"1\"/></cellXfs>";
            });
        }
        const _0x168fcb = (_0x138863, _0x214b2a, _0x271640, _0x403ba9) => {
            const _0x30b65c = _0x1539db(_0x214b2a) + _0x138863, _0x20981b = _0x43a22c => "<c r=\"" + _0x30b65c + '\x22' + (_0x403ba9 && _0x1208db !== null ? ' s=\x22' + _0x1208db + '\x22' : _0x43a22c) + (_0x271640 ? ' t=\x22inlineStr\x22><is><t xml:space=\x22preserve\x22>' + _0x1d6b57(_0x271640) + "</t></is></c>" : '/>'), _0x10192f = new RegExp("<c r=\"" + _0x30b65c + "\"([^>]*?)(?:/>|>[\\s\\S]*?</c>)");
            if (_0x10192f.test(_0xbd2f7e)) {
                _0xbd2f7e = _0xbd2f7e.replace(_0x10192f, (_0x4dad38, _0x240489) => _0x20981b((_0x240489.match(/ s="\d+"/) || [''])[0x0]));
                return;
            }
            const _0x1d8303 = new RegExp("<row r=\"" + _0x138863 + "\"([^>]*?)(/>|>([\\s\\S]*?)</row>)");
            if (_0x1d8303.test(_0xbd2f7e)) {
                _0xbd2f7e = _0xbd2f7e.replace(_0x1d8303, (_0xab7d4b, _0xe35111, _0x5db693, _0x3ce4ab) => {
                    let _unused_bvoz;
                    _0x3ce4ab = _0x3ce4ab || '';
                    const _0xc3e4cc = _0x3ce4ab.match(/<c [\s\S]*?(?:\/>|<\/c>)/g) || [];
                    let _0x3c25e6 = _0xc3e4cc.findIndex(_0x489c37 => {
                        const _0x7ad727 = (_0x489c37.match(/r="([A-Z]+)\d+"/) || [])[0x1];
                        return _0x7ad727 && (_0x7ad727.length > _0x1539db(_0x214b2a).length || _0x7ad727.length === _0x1539db(_0x214b2a).length && _0x7ad727 > _0x1539db(_0x214b2a));
                    });
                    if (_0x3c25e6 < 0x0) {
                        _0x3c25e6 = _0xc3e4cc.length;
                    }
                    _0xc3e4cc.splice(_0x3c25e6, 0x0, _0x20981b(''));
                    return "<row r=\"" + _0x138863 + '\x22' + _0xe35111.replace(/ spans="[^"]*"/, '') + '>' + _0xc3e4cc.join('') + '</row>';
                });
                return;
            }
            const _0x586370 = _0xbd2f7e.match(/<row r="(\d+)"/g) || [], _0x4656a5 = _0x586370.map(_0x3cffe3 => +_0x3cffe3.match(/\d+/)[0x0]).find(_0x10f963 => _0x10f963 > _0x138863), _0x452f72 = '<row r=\x22' + _0x138863 + '\x22>' + _0x20981b('') + "</row>";
            if (_0x4656a5) {
                _0xbd2f7e = _0xbd2f7e.replace('<row r=\x22' + _0x4656a5 + '\x22', _0x452f72 + '<row r=\x22' + _0x4656a5 + '\x22');
            }
            else {
                _0xbd2f7e = _0xbd2f7e.replace(/<sheetData\s*\/>/, "<sheetData>" + _0x452f72 + '</sheetData>').replace("</sheetData>", _0x452f72 + '</sheetData>');
            }
        };
        _0x1af125.items.forEach(_0x448659 => {
            let _unused_2nza;
            if (!_0x448659.existing) {
                _0x168fcb(_0x448659.row, _0x448659.col, _0x448659.value, !_0x448659.value);
            }
        });
        const _0x3f8011 = [];
        for (const _0x5141f5 of Object.keys(_0x16cbb4)) {
            if (/^xl\/calcChain\.xml$/.test(_0x5141f5)) {
                continue;
            }
            let _0xa2a36 = await _0x16cbb4[_0x5141f5]();
            if (_0x5141f5 === _0x4928ee) {
                _0xa2a36 = _0x58f028.encode(_0xbd2f7e);
            }
            else {
                if (_0x5141f5 === "xl/styles.xml" && _0x307814) {
                    _0xa2a36 = _0x58f028.encode(_0x307814);
                }
                else {
                    if (_0x5141f5 === '[Content_Types].xml') {
                        _0xa2a36 = _0x58f028.encode(_0x3f646b.decode(_0xa2a36).replace(/<Override PartName="\/xl\/calcChain\.xml"[^>]*\/>/, ''));
                    }
                    else {
                        if (_0x5141f5 === 'xl/_rels/workbook.xml.rels') {
                            _0xa2a36 = _0x58f028.encode(_0x3f646b.decode(_0xa2a36).replace(/<Relationship [^>]*calcChain[^>]*\/>/, ''));
                        }
                    }
                }
            }
            _0x3f8011.push({ 'name': _0x5141f5, 'data': new Uint8Array(_0xa2a36) });
        }
        return { 'ok': !false, 'bytes': _0x3c4bc1(_0x3f8011), 'plan': _0x1af125, 'sheet': _0x11e891.sheets[_0x535dde].name, 'filled': _0x1af125.items.filter(_0x2ab429 => _0x2ab429.value && !_0x2ab429.existing).length, 'filledLabels': _0x1af125.items.filter(_0x3399f1 => _0x3399f1.value && !_0x3399f1.existing).map(_0x14836d => _0x14836d.label + ' = ' + _0x14836d.value), 'existing': _0x1af125.items.filter(_0x53ef33 => _0x53ef33.existing).map(_0x59485b => _0x59485b.label), 'missing': _0x1af125.items.filter(_0x3c271d => !_0x3c271d.value).map(_0xca109 => _0xca109.label) };
    }
    function _0x3e9ac2(_0xe0eab1, _0x38fa3a, _0x2264e3) {
        const _0x3cb940 = _0xe0eab1.map(_0x5a3824 => {
            const _0x1d3538 = _0x2372e1(_0x5a3824), _0xfa739a = _0x1d3538 && _0x38fa3a && _0x38fa3a[_0x1d3538] ? String(_0x38fa3a[_0x1d3538]) : '';
            return { 'l': _0x5a3824, 'v': _0xfa739a };
        }), _0x701bdd = [], _0x2d8ec0 = _0x241ceb => {
            let _unused_3qc7;
            let _0x54d7fe = _0x701bdd.indexOf(_0x241ceb);
            _0x54d7fe < 0x0 && (_0x54d7fe = _0x701bdd.length, _0x701bdd.push(_0x241ceb));
            return _0x54d7fe;
        };
        let _0x145d3e = 0x0;
        const _0x344940 = [], _0x4ce965 = _0x3d1a49 => {
            let _unused_bn7l;
            _0x145d3e++;
            _0x344940.push('<row r=\x22' + _0x145d3e + '\x22>' + _0x3d1a49.map((_0x517d4e, _0x587713) => _0x517d4e.v === '' && !_0x517d4e.y ? '' : "<c r=\"" + _0x1539db(_0x587713) + _0x145d3e + '\x22' + (_0x517d4e.y ? ' s=\x221\x22' : _0x517d4e.b ? " s=\"2\"" : '') + (_0x517d4e.v === '' ? '/>' : " t=\"s\"><v>" + _0x2d8ec0(_0x517d4e.v) + '</v></c>')).join('') + "</row>");
        };
        if (_0x2264e3) {
            _0x4ce965([{ 'v': _0x2264e3, 'b': 0x1 }]);
        }
        _0x4ce965([{ 'v': 'Alan', 'b': 0x1 }, { 'v': "Değer", 'b': 0x1 }]);
        _0x3cb940.forEach(_0x4a64fe => _0x4ce965([{ 'v': _0x4a64fe.l }, { 'v': _0x4a64fe.v, 'y': !_0x4a64fe.v }]));
        const _0x383a92 = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n", _0x15c763 = [['[Content_Types].xml', _0x383a92 + '<Types xmlns=\x22http://schemas.openxmlformats.org/package/2006/content-types\x22><Default Extension=\x22rels\x22 ContentType=\x22application/vnd.openxmlformats-package.relationships+xml\x22/><Default Extension=\x22xml\x22 ContentType=\x22application/xml\x22/><Override PartName=\x22/xl/workbook.xml\x22 ContentType=\x22application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\x22/><Override PartName=\x22/xl/worksheets/sheet1.xml\x22 ContentType=\x22application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\x22/><Override PartName=\x22/xl/styles.xml\x22 ContentType=\x22application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\x22/><Override PartName=\x22/xl/sharedStrings.xml\x22 ContentType=\x22application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml\x22/></Types>'], ['_rels/.rels', _0x383a92 + '<Relationships xmlns=\x22http://schemas.openxmlformats.org/package/2006/relationships\x22><Relationship Id=\x22rId1\x22 Type=\x22http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\x22 Target=\x22xl/workbook.xml\x22/></Relationships>'], ['xl/workbook.xml', _0x383a92 + '<workbook xmlns=\x22http://schemas.openxmlformats.org/spreadsheetml/2006/main\x22 xmlns:r=\x22http://schemas.openxmlformats.org/officeDocument/2006/relationships\x22><sheets><sheet name=\x22Form\x22 sheetId=\x221\x22 r:id=\x22rId1\x22/></sheets></workbook>'], ['xl/_rels/workbook.xml.rels', _0x383a92 + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/><Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings\" Target=\"sharedStrings.xml\"/></Relationships>"], ["xl/styles.xml", _0x383a92 + '<styleSheet xmlns=\x22http://schemas.openxmlformats.org/spreadsheetml/2006/main\x22><fonts count=\x222\x22><font><sz val=\x2211\x22/><name val=\x22Calibri\x22/></font><font><b/><sz val=\x2211\x22/><name val=\x22Calibri\x22/></font></fonts><fills count=\x223\x22><fill><patternFill patternType=\x22none\x22/></fill><fill><patternFill patternType=\x22gray125\x22/></fill><fill><patternFill patternType=\x22solid\x22><fgColor rgb=\x22FFFFFF00\x22/><bgColor indexed=\x2264\x22/></patternFill></fill></fills><borders count=\x221\x22><border/></borders><cellStyleXfs count=\x221\x22><xf numFmtId=\x220\x22 fontId=\x220\x22 fillId=\x220\x22 borderId=\x220\x22/></cellStyleXfs><cellXfs count=\x223\x22><xf numFmtId=\x220\x22 fontId=\x220\x22 fillId=\x220\x22 borderId=\x220\x22 xfId=\x220\x22/><xf numFmtId=\x220\x22 fontId=\x220\x22 fillId=\x222\x22 borderId=\x220\x22 xfId=\x220\x22 applyFill=\x221\x22/><xf numFmtId=\x220\x22 fontId=\x221\x22 fillId=\x220\x22 borderId=\x220\x22 xfId=\x220\x22 applyFont=\x221\x22/></cellXfs></styleSheet>'], ['xl/worksheets/sheet1.xml', _0x383a92 + '<worksheet xmlns=\x22http://schemas.openxmlformats.org/spreadsheetml/2006/main\x22><cols><col min=\x221\x22 max=\x221\x22 width=\x2240\x22 customWidth=\x221\x22/><col min=\x222\x22 max=\x222\x22 width=\x2250\x22 customWidth=\x221\x22/></cols><sheetData>' + _0x344940.join('') + "</sheetData></worksheet>"], ["xl/sharedStrings.xml", _0x383a92 + '<sst xmlns=\x22http://schemas.openxmlformats.org/spreadsheetml/2006/main\x22 count=\x22' + _0x701bdd.length + '\x22 uniqueCount=\x22' + _0x701bdd.length + '\x22>' + _0x701bdd.map(_0x5035b5 => '<si><t xml:space=\x22preserve\x22>' + _0x1d6b57(_0x5035b5) + '</t></si>').join('') + "</sst>"]].map(([_0x1eda00, _0x51e290]) => ({ 'name': _0x1eda00, 'data': _0x58f028.encode(_0x51e290) }));
        return { 'ok': !false, 'bytes': _0x3c4bc1(_0x15c763), 'filled': _0x3cb940.filter(_0x2f0534 => _0x2f0534.v).length, 'missing': _0x3cb940.filter(_0xb3260 => !_0xb3260.v).map(_0x216c5a => _0x216c5a.l) };
    }
    async function _0x44ba7a(_0x73deca, _0x74219a) {
        const _0x22ec87 = _0xc4c474(_0x73deca);
        if (!_0x22ec87['word/document.xml']) {
            return { 'ok': false, 'error': "word/document.xml yok" };
        }
        let _0x259d98 = _0x3f646b.decode(await _0x22ec87["word/document.xml"]());
        const _0x3c3419 = _0x74219a || {}, _0x173ba6 = _0x289a91 => _0x2c4a6e((_0x289a91.match(/<w:t[^>]*>[^<]*<\/w:t>/g) || []).map(_0x283c1d => _0x283c1d.replace(/<[^>]+>/g, '')).join('')).trim(), _0x1f80d9 = (_0x17cd9b, _0x4adad9, _0x5bcadd) => {
            let _unused_8oqp;
            let _0x2e5f18 = _0x17cd9b;
            if (_0x5bcadd) {
                if (/<w:tcPr>/.test(_0x2e5f18)) {
                    _0x2e5f18 = _0x2e5f18.replace(/<w:shd [^>]*\/>/, '').replace("<w:tcPr>", "<w:tcPr><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFF00\"/>");
                }
                else {
                    if (/<w:tcPr\/>/.test(_0x2e5f18)) {
                        _0x2e5f18 = _0x2e5f18.replace('<w:tcPr/>', "<w:tcPr><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFF00\"/></w:tcPr>");
                    }
                    else {
                        _0x2e5f18 = _0x2e5f18.replace(/^<w:tc>/, '<w:tc><w:tcPr><w:shd w:val=\x22clear\x22 w:color=\x22auto\x22 w:fill=\x22FFFF00\x22/></w:tcPr>');
                    }
                }
            }
            if (_0x4adad9) {
                const _0x4c1b7f = "<w:r><w:t xml:space=\"preserve\">" + _0x1d6b57(_0x4adad9) + "</w:t></w:r>";
                if (/<w:p\/>/.test(_0x2e5f18)) {
                    _0x2e5f18 = _0x2e5f18.replace("<w:p/>", '<w:p>' + _0x4c1b7f + "</w:p>");
                }
                else {
                    if (/<w:p[ >]/.test(_0x2e5f18)) {
                        _0x2e5f18 = _0x2e5f18.replace(/(<w:p(?: [^>]*)?>(?:<w:pPr>[\s\S]*?<\/w:pPr>)?)/, '$1' + _0x4c1b7f);
                    }
                    else {
                        _0x2e5f18 = _0x2e5f18.replace('</w:tc>', "<w:p>" + _0x4c1b7f + '</w:p></w:tc>');
                    }
                }
            }
            return _0x2e5f18;
        }, _0x6102e9 = [], _0x15a877 = /(_{3,}|\.{4,}|…{2,}|\t+)/, _0x139c3c = _0xf4cba2 => {
            const _0x32576f = [], _0x484ba2 = /(<w:t(?: [^>]*)?>)([^<]*)(<\/w:t>)|<w:tab\/>/g;
            let _0x3e151a;
            while (_0x3e151a = _0x484ba2.exec(_0xf4cba2)) {
                _0x32576f.push({ 'i': _0x3e151a.index, 'len': _0x3e151a[0x0].length, 'open': _0x3e151a[0x1] || '', 'txt': _0x3e151a[0x1] ? _0x2c4a6e(_0x3e151a[0x2]) : '\x09', 'close': _0x3e151a[0x3] || '', 'tab': !_0x3e151a[0x1] });
            }
            if (!_0x32576f.length) {
                return _0xf4cba2;
            }
            const _0xe59afd = _0x32576f.map(_0x23da64 => _0x23da64.txt).join(''), _0x5de3f5 = /^\s*([^:：\t_]{2,50}?)\s*[:：]\s*(_{3,}|\.{4,}|…{2,}|\t+)\s*$/.exec(_0xe59afd);
            if (!_0x5de3f5) {
                if (/_{3,}/.test(_0xe59afd) && /[:：]/.test(_0xe59afd)) {
                    const _0x77598b = _0xe59afd.split(/[:：]/)[0x0].trim();
                    if (_0x77598b && _0x77598b.length <= 0x32) {
                        _0x6102e9.push({ 'label': _0x77598b, 'key': null, 'value': '' });
                        return _0xf4cba2.replace(/<w:r>|<w:r (?=[^>]*>)/g, _0x29a4c4 => _0x29a4c4).replace(/(<w:r(?: [^>]*)?>)(<w:rPr>)?/g, (_0x2739bf, _0x389d20, _0xf628ec) => _0x389d20 + (_0xf628ec ? '<w:rPr><w:highlight w:val=\x22yellow\x22/>' : '<w:rPr><w:highlight w:val=\x22yellow\x22/></w:rPr>'));
                    }
                }
                return _0xf4cba2;
            }
            const _0x73716b = _0x5de3f5[0x1].trim(), _0x5af20d = _0x2372e1(_0x73716b, '', "label"), _0x33a341 = _0x5af20d && _0x3c3419[_0x5af20d] ? String(_0x3c3419[_0x5af20d]) : '';
            _0x6102e9.push({ 'label': _0x73716b, 'key': _0x5af20d, 'value': _0x33a341 });
            const _0x3f32d7 = _0x5de3f5.index + _0x5de3f5[0x0].lastIndexOf(_0x5de3f5[0x2]), _0x3ae377 = _0x3f32d7 + _0x5de3f5[0x2].length;
            let _0x482ef9 = 0x0, _0xbbce8e = '', _0x3cfee6 = 0x0, _0x3704bb = !false;
            _0x32576f.forEach(_0x4ddd01 => {
                const _0x565358 = _0x482ef9, _0x1504ca = _0x482ef9 + _0x4ddd01.txt.length;
                _0x482ef9 = _0x1504ca;
                const _0x40ab13 = Math.max(_0x565358, _0x3f32d7), _0x50a52e = Math.min(_0x1504ca, _0x3ae377);
                _0xbbce8e += _0xf4cba2.slice(_0x3cfee6, _0x4ddd01.i);
                _0x3cfee6 = _0x4ddd01.i + _0x4ddd01.len;
                if (_0x40ab13 >= _0x50a52e) {
                    _0xbbce8e += _0xf4cba2.slice(_0x4ddd01.i, _0x4ddd01.i + _0x4ddd01.len);
                    return;
                }
                if (_0x33a341) {
                    const _0x3391e8 = _0x4ddd01.txt.slice(0x0, _0x40ab13 - _0x565358) + (_0x3704bb ? (_0x40ab13 > 0x0 && !/\s$/.test(_0xe59afd.slice(0x0, _0x40ab13)) ? ' ' : '') + _0x33a341 : '') + _0x4ddd01.txt.slice(_0x50a52e - _0x565358);
                    _0x3704bb = false;
                    _0xbbce8e += _0x4ddd01.tab ? _0x3391e8 ? '<w:t xml:space=\x22preserve\x22>' + _0x1d6b57(_0x3391e8) + "</w:t>" : '' : '<w:t xml:space=\x22preserve\x22>' + _0x1d6b57(_0x3391e8) + "</w:t>";
                }
                else {
                    _0xbbce8e += _0xf4cba2.slice(_0x4ddd01.i, _0x4ddd01.i + _0x4ddd01.len);
                }
            });
            _0xbbce8e += _0xf4cba2.slice(_0x3cfee6);
            if (!_0x33a341) {
                _0xbbce8e = _0xbbce8e.replace(/(<w:r(?: [^>]*)?>)(<w:rPr>)?/g, (_0xea602a, _0x961b74, _0x2768d7) => _0x961b74 + (_0x2768d7 ? '<w:rPr><w:highlight w:val=\x22yellow\x22/>' : '<w:rPr><w:highlight w:val=\x22yellow\x22/></w:rPr>'));
            }
            return _0xbbce8e;
        };
        _0x259d98 = _0x259d98.split(/(<w:tbl>[\s\S]*?<\/w:tbl>)/).map(_0x1b0a84 => _0x1b0a84.startsWith("<w:tbl>") ? _0x1b0a84 : _0x1b0a84.replace(/<w:p[ >][\s\S]*?<\/w:p>/g, _0x4a2126 => _0x15a877.test(_0x4a2126.replace(/<[^>]+>/g, '')) || /<w:tab\/>/.test(_0x4a2126) ? _0x139c3c(_0x4a2126) : _0x4a2126)).join('');
        _0x259d98 = _0x259d98.replace(/<w:tbl>([\s\S]*?)<\/w:tbl>/g, _0x2bbc2e => {
            const _0x16fcbd = _0x2bbc2e.match(/<w:tr[ >][\s\S]*?<\/w:tr>/g) || [], _0x558cc5 = _0x16fcbd.map(_0x56926e => _0x56926e.match(/<w:tc>[\s\S]*?<\/w:tc>/g) || []), _0x222ce1 = _0x558cc5.map(_0x12f14f => _0x12f14f.map(_0x173ba6)), _0xee8b3a = new Map(), _0x38ab0c = _0x222ce1.map((_0x265f2a, _0x253e9f) => ({ 'r': _0x265f2a, 'ri': _0x253e9f })).filter(_0x3ccb16 => _0x3ccb16.r.length === 0x2 && _0x2f081b(_0x3ccb16.r[0x0]) && !_0x3ccb16.r[0x1]), _0x2e3c41 = _0x33b627(_0x222ce1);
            if (_0x38ab0c.length >= 0x2 && (!_0x2e3c41 || _0x38ab0c.length >= _0x2e3c41.fields.length - 0x1)) {
                _0x38ab0c.forEach(_0x29ac5f => {
                    const _0x433f79 = _0x29ac5f.r[0x0].replace(/[:：]\s*$/, ''), _0x8f311a = _0x2372e1(_0x433f79), _0x1e14ac = _0x8f311a && _0x3c3419[_0x8f311a] ? String(_0x3c3419[_0x8f311a]) : '';
                    _0xee8b3a.set(_0x29ac5f.ri + ',' + 0x1, { 'val': _0x1e14ac, 'yellow': !_0x1e14ac });
                    _0x6102e9.push({ 'label': _0x433f79, 'key': _0x8f311a, 'value': _0x1e14ac });
                });
            }
            else {
                if (_0x2e3c41 && _0x222ce1[_0x2e3c41.headerRow]) {
                    const _0x1f81dc = _0x2e3c41.headerRow - 0x1, _0x2e48b2 = _0x1f81dc + 0x1, _0x46e08a = _0x2e3c41.title || '';
                    _0x222ce1[_0x1f81dc].forEach((_0x55839d, _0x301031) => {
                        let _unused_25x8;
                        if (!_0x2f081b(_0x55839d) || /^(s\.?\s*no|sn|sira( no)?|no)$/i.test(_0x547beb(_0x55839d))) {
                            return;
                        }
                        const _0x2ab323 = (_0x222ce1[_0x2e48b2][_0x301031] || '').trim();
                        let _0x32e4ea = _0x2372e1(_0x55839d, _0x46e08a, "row");
                        if (_0x32e4ea && /\b(alan|dal|sinif|isletme)\b/.test(_0x547beb(_0x222ce1[_0x1f81dc].join(' ') + ' ' + _0x46e08a))) {
                            _0x32e4ea = null;
                        }
                        if (_0x2ab323) {
                            _0x6102e9.push({ 'label': _0x55839d, 'key': _0x32e4ea, 'value': _0x2ab323, 'existing': !false });
                            return;
                        }
                        const _0x50d325 = _0x32e4ea && _0x3c3419[_0x32e4ea] ? String(_0x3c3419[_0x32e4ea]) : '';
                        _0xee8b3a.set(_0x2e48b2 + ',' + _0x301031, { 'val': _0x50d325, 'yellow': !_0x50d325 });
                        _0x6102e9.push({ 'label': _0x55839d, 'key': _0x32e4ea, 'value': _0x50d325 });
                    });
                }
            }
            if (!_0xee8b3a.size) {
                return _0x2bbc2e;
            }
            let _0x11ec47 = -0x1;
            return _0x2bbc2e.replace(/<w:tr[ >][\s\S]*?<\/w:tr>/g, _0x231cc9 => {
                _0x11ec47++;
                let _0x5badc2 = -0x1;
                return _0x231cc9.replace(/<w:tc>[\s\S]*?<\/w:tc>/g, _0x48981c => {
                    let _unused_jp6w;
                    _0x5badc2++;
                    const _0x44682b = _0xee8b3a.get(_0x11ec47 + ',' + _0x5badc2);
                    return _0x44682b ? _0x1f80d9(_0x48981c, _0x44682b.val, _0x44682b.yellow) : _0x48981c;
                });
            });
        });
        if (!_0x6102e9.length) {
            return { 'ok': false, 'error': "Form tablosu bulunamadı" };
        }
        const _0x438921 = [];
        for (const _0x822f35 of Object.keys(_0x22ec87)) {
            _0x438921.push({ 'name': _0x822f35, 'data': _0x822f35 === 'word/document.xml' ? _0x58f028.encode(_0x259d98) : new Uint8Array(await _0x22ec87[_0x822f35]()) });
        }
        return { 'ok': !false, 'bytes': _0x3c4bc1(_0x438921), 'filled': _0x6102e9.filter(_0x91a61e => _0x91a61e.value && !_0x91a61e.existing).length, 'filledLabels': _0x6102e9.filter(_0xf29b4 => _0xf29b4.value && !_0xf29b4.existing).map(_0xfbf496 => _0xfbf496.label + ' = ' + _0xfbf496.value), 'existing': _0x6102e9.filter(_0x5c0f26 => _0x5c0f26.existing).map(_0x42ee00 => _0x42ee00.label), 'missing': _0x6102e9.filter(_0x275453 => !_0x275453.value).map(_0x3b0268 => _0x3b0268.label) };
    }
    const EA_profilZengin = p => {
        const o = Object.assign({}, p || {});
        if (!o.ilIlce && (o.il || o.ilce)) o.ilIlce = [o.il, o.ilce].filter(Boolean).join(' / ');
        // v3.6.69: formdaki okul adı sade olsun: "İlçe Örnek … Lisesi Müdürlüğü" → "Örnek … Lisesi"
        if (o.okulAdi) {
            const katla = x => _0x547beb(x);
            const at = new Set([o.ilce, o.il].filter(Boolean).map(katla));
            const w = String(o.okulAdi).replace(/\s+/g, ' ').trim().replace(/\s*m[uü]d[uü]rl[uü][gğ][uü]\s*$/i, '').split(' ');
            while (w.length > 3 && at.has(katla(w[0]))) w.shift();
            o.okulAdi = w.join(' ');
        }
        if (!o.egitimYili) { const d = new Date(), y = d.getMonth() >= 8 ? d.getFullYear() : d.getFullYear() - 1; o.egitimYili = y + '-' + (y + 1); }
        return o;
    };
    const _eskiFillXlsx = _0x25999d, _eskiFillDocx = _0x44ba7a, _eskiLabels = _0x3e9ac2;
    _0x25999d = (b, p) => _eskiFillXlsx(b, EA_profilZengin(p));
    _0x44ba7a = (b, p) => _eskiFillDocx(b, EA_profilZengin(p));
    _0x3e9ac2 = (f, p, n) => _eskiLabels(f, EA_profilZengin(p), n);
    _0x41d0c2.EBYS_EK = { 'fillDocx': _0x44ba7a, 'PROFILE_FIELDS': _0x30f540, 'matchField': _0x2372e1, 'planFill': _0x5b4b2b, 'fillXlsx': _0x25999d, 'labelsToXlsx': _0x3e9ac2, 'zipStore': _0x3c4bc1, 'fold': _0x547beb, 'unzipIndex': _0xc4c474, 'docxText': _0x49e453, 'xlsxRead': _0x2378f3, 'xlsStrings': _0xf8c1d, 'pdfText': _0x5892eb, 'analyze': _0x30e453, 'requestedLines': _0xca8681, 'formFieldsFromRows': _0x33b627, 'kindOf': _0x494c78 };
}(typeof globalThis !== "undefined" ? globalThis : this));
