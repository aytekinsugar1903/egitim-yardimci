/* Evrak Asistanı v3.7.1 — Günlü takvime düzenli yazı işaretleri ve kısa liste.
 * takvim.js'e dokunmaz. Hücreler td.tv-day[data-iso] olduğu için işaretler oraya eklenir;
 * yaklaşan / geciken yazılar takvimin altında özetlenir.
 * Hiçbir evrak gönderilmez, imzalanmaz, paraflanmaz.
 */
(function () {
  'use strict';
  const P = window.EA_PERIYODIK;
  if (!P) return;

  const CSS = `
.eap-tv-ev{border-left:5px solid #38BDF8;background:#E0F2FE;color:#0F172A;border-radius:4px;padding:2px 4px;margin:0 0 3px;font-size:11px;display:flex;flex-direction:column;gap:1px;}
.eap-tv-ev .eap-k{font-weight:600}
.eap-tv-ev .eap-l{font-size:10.5px;font-weight:700;color:#0369A1}
.eap-tv-ev.eap-red{border-color:#EF4444;background:#FEE2E2}
.eap-tv-ev.eap-red .eap-l{color:#B91C1C}
.eap-tv-ev.eap-orange{border-color:#F59E0B;background:#FEF3C7}
.eap-tv-ev.eap-orange .eap-l{color:#B45309}
.eap-tv-ozet{margin:14px 0 8px;padding:10px 12px;background:var(--card,#fff);border:1px solid var(--line,#E2E8F0);border-radius:10px;font:13px/1.45 "Segoe UI",system-ui,Arial,sans-serif;color:#0F172A}
.eap-tv-ozet h2{font-size:16px;margin:0 0 6px}
.eap-tv-ozet ul{margin:0;padding:0;list-style:none}
.eap-tv-ozet li{display:flex;gap:8px;align-items:baseline;padding:4px 0;border-top:1px solid #EEF2F7}
.eap-tv-ozet li:first-child{border-top:0}
.eap-tv-ozet .eap-tarih{font-variant-numeric:tabular-nums;min-width:5.6em;color:#475569}
.eap-tv-ozet a{color:#0369A1;font-weight:600;text-decoration:none}
.eap-tv-bos{color:#64748B;margin:0}
`;

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function seviye(d) {
    if (d.kod === 'gecikti' || d.kod === 'bugun') return 'eap-red';
    if (d.kod === 'yakin') return 'eap-orange';
    return '';
  }

  function kayitlar(depo, bugun) {
    const out = [];
    depo.kartlar.forEach(k => {
      if (!k.aktif) return;
      P.aktifDonemler(k, bugun).forEach(p => {
        const d = P.durum(k, p, bugun, depo.ayar.ekTatiller);
        if (!d.sonTarih || d.kod === 'gonderildi' || d.kod === 'yok' || d.kod === 'bitti' || d.kod === 'gunyok') return;
        out.push({ k, p, d });
      });
    });
    out.sort((a, b) => a.d.sonTarih.localeCompare(b.d.sonTarih) || a.k.ad.localeCompare(b.k.ad, 'tr'));
    return out;
  }

  function isaretle(kayit) {
    document.querySelectorAll('.eap-tv-ev').forEach(e => e.remove());
    const by = {};
    kayit.forEach(x => { (by[x.d.sonTarih] = by[x.d.sonTarih] || []).push(x); });
    Object.keys(by).forEach(iso => {
      const td = document.querySelector('td.tv-day[data-iso="' + iso + '"]');
      if (!td || td.classList.contains('tv-out')) return;
      by[iso].forEach(x => {
        const ev = document.createElement('div');
        ev.className = 'eap-tv-ev ' + seviye(x.d);
        ev.title = x.k.ad + ' — ' + x.d.etiket + (x.k.kime ? ' — ' + x.k.kime : '');
        ev.innerHTML = '<span class="eap-k">🔁 ' + esc(x.k.ad) + '</span><span class="eap-l">' + esc(x.d.etiket.replace(/^[^\wÇĞİÖŞÜçğıöşü]+/, '')) + '</span>';
        td.appendChild(ev);
      });
    });
  }

  function ozetCiz(kayit) {
    let kutu = document.getElementById('eap-tv-ozet');
    if (!kutu) {
      kutu = document.createElement('section');
      kutu.id = 'eap-tv-ozet';
      kutu.className = 'eap-tv-ozet';
      const kok = document.getElementById('tv-root') || document.body;
      const ay = kok.querySelector('.tv-month:last-of-type');
      if (ay && ay.parentNode) ay.parentNode.insertBefore(kutu, ay.nextSibling);
      else kok.appendChild(kutu);
    }
    const yonet = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL)
      ? chrome.runtime.getURL('periyodik.html') : 'periyodik.html';
    if (!kayit.length) {
      kutu.innerHTML = '<h2>🔁 Düzenli yazılar</h2><p class="eap-tv-bos">Bu dönemde bekleyen düzenli yazı yok. Liste ve öneriler için <a href="' + yonet + '">⚙️ Yönet</a>.</p>';
      return;
    }
    kutu.innerHTML = '<h2>🔁 Düzenli yazılar <a href="' + yonet + '" style="font-weight:600;font-size:13px;">⚙️ Yönet</a></h2><ul>' +
      kayit.map(x => '<li><span class="eap-tarih">' + esc(P.trTarih(x.d.sonTarih)) + '</span><span><b>' + esc(x.k.ad) + '</b> — ' + esc(x.d.etiket) + (x.k.kime ? ' <span style="color:#64748B">(' + esc(x.k.kime) + ')</span>' : '') + '</span></li>').join('') +
      '</ul>';
  }

  let tmr = 0;
  async function yenile() {
    try {
      if (!(await P.onayVarMi())) return;
      const depo = await P.depoOku();
      const bugun = P.bugunIso();
      const k = kayitlar(depo, bugun);
      isaretle(k);
      ozetCiz(k);
    } catch (e) { }
  }
  function planla() {
    clearTimeout(tmr);
    tmr = setTimeout(yenile, 80);
  }

  function basla() {
    if (!document.getElementById('eap-tv-css')) {
      const s = document.createElement('style');
      s.id = 'eap-tv-css';
      s.textContent = CSS;
      document.documentElement.appendChild(s);
    }
    planla();
    const kok = document.getElementById('tv-root') || document.body;
    try {
      new MutationObserver(muts => {
        if (muts.some(m => [...m.addedNodes].some(n => n.nodeType === 1 && !n.classList.contains('eap-tv-ev') && n.id !== 'eap-tv-ozet'))) planla();
      }).observe(kok, { childList: true, subtree: true });
    } catch (e) { }
    document.addEventListener('click', ev => {
      if (ev.target && ev.target.closest && ev.target.closest('#tv-prev,#tv-next,#tv-today')) planla();
    }, true);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', basla);
  else basla();
})();
