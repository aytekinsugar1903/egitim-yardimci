// Evrak Asistanı — taranmış PDF / fotoğraf OCR (offscreen belge). Her şey bu bilgisayarda çalışır; hiçbir şey dışarı gönderilmez.
import * as pdfjsLib from "./pdfjs/pdf.min.mjs";
pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL("pdfjs/pdf.worker.min.mjs");

let isci = null, kapatZamanlayici = null;
const zamanAsimi = (p, ms, ad) => Promise.race([p, new Promise((_, r) => setTimeout(() => r(new Error(ad + " zaman aşımı")), ms))]);
async function ocrIsci() {
  if (isci) return isci;
  isci = await zamanAsimi(Tesseract.createWorker("tur", 1, {
    workerPath: chrome.runtime.getURL("ocr/worker.min.js"),
    corePath: chrome.runtime.getURL("ocr/tess-core/"),
    langPath: chrome.runtime.getURL("ocr/lang"),
    workerBlobURL: false,
    cacheMethod: "none",
  }), 90000, "OCR motoru yükleme");
  await isci.setParameters({ preserve_interword_spaces: "1" });
  return isci;
}
function bosaltPlanla() {
  clearTimeout(kapatZamanlayici);
  kapatZamanlayici = setTimeout(async () => { try { if (isci) await isci.terminate(); } catch (e) {} isci = null; }, 120000);
}
// gri ton + kontrast: tarama gürültüsünü azaltır
function onIsle(c) {
  const x = c.getContext("2d"), v = x.getImageData(0, 0, c.width, c.height), d = v.data;
  for (let i = 0; i < d.length; i += 4) {
    const g = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    const k = g > 165 ? 255 : g < 90 ? 0 : (g - 90) * 3.4;
    d[i] = d[i + 1] = d[i + 2] = k;
  }
  x.putImageData(v, 0, 0);
  return c;
}
const b64ten = (s) => { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };

async function sayfalar(bytes, tur, sayfaSec) {
  const out = [];
  if (tur === "pdf") {
    const pdf = await pdfjsLib.getDocument({ data: bytes }).promise;
    const n = pdf.numPages;
    const istenen = [...new Set((sayfaSec || [1, -1]).map((s) => (s < 0 ? n + 1 + s : s)).filter((s) => s >= 1 && s <= n))];
    for (const no of istenen) {
      const p = await pdf.getPage(no), vp0 = p.getViewport({ scale: 1 });
      const vp = p.getViewport({ scale: Math.min(3, 2400 / Math.max(vp0.width, vp0.height)) });
      const c = document.createElement("canvas");
      c.width = Math.round(vp.width); c.height = Math.round(vp.height);
      const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height);
      await p.render({ canvasContext: x, viewport: vp, intent: "print" }).promise;   // offscreen belgede requestAnimationFrame çalışmaz
      out.push({ no, c });
    }
    return { out, toplam: n };
  }
  const bmp = await createImageBitmap(new Blob([bytes]), { imageOrientation: "from-image" });
  const k = Math.min(2, 2400 / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas");
  c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
  return { out: [{ no: 1, c }], toplam: 1 };
}

async function isle(m) {
  const t0 = Date.now();
  const { out, toplam } = await sayfalar(b64ten(m.veri), m.tur, m.sayfalar);
  const w = await ocrIsci();
  const parcalar = [];
  let guven = 0;
  for (const s of out) {
    const r = await zamanAsimi(w.recognize(onIsle(s.c)), 120000, "Sayfa OCR");
    parcalar.push(r.data.text || "");
    guven += r.data.confidence || 0;
  }
  bosaltPlanla();
  return { metin: parcalar.join("\n"), sayfa: out.map((s) => s.no), toplam, guven: out.length ? Math.round(guven / out.length) : 0, sure: Date.now() - t0 };
}

chrome.runtime.onMessage.addListener((m, sender, send) => {
  if (m && m.tip === "EA_OCR_PING") { send({ pong: true }); return; }
  if (!m || m.tip !== "EA_OCR_IS") return;
  isle(m).then(send, (e) => send({ hata: String((e && e.message) || e) }));
  return true;
});
