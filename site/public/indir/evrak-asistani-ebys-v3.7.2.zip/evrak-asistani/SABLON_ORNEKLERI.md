> v3.6.47: Hazır şablonlar kurumdan bağımsızdır. `{kurumAdi}`, `{kurumumuzca}`, `{amirUnvani}`, `{ustBirim}` yer tutucuları Kurum Ayarları’ndan doldurulur.

# Evrak Asistanı v3.6.41 — Şablon örnekleri

Örnek değerlerle doldurulmuş 4 çıktı (2 üst makama, 2 alt/eşit birime). `........` alanları kullanıcının dolduracağı yerlerdir. Kapanış, yazı yönüne göre `{kapanış:…}` belirtecinden üretilir.

## 1. İstenen Bilgi ve Belgelerin Gönderilmesi — yön: üst makam (arz)

Değerler: konu = Öğrenci Kulüpleri; sayı = E-71234567-100-98765432; tarih = 10.10.2026; gönderen = {ustBirim}

```
İlgi: {ustBirim} 10.10.2026 tarihli ve E-71234567-100-98765432 sayılı yazısı.

İlgi yazı ile istenen Öğrenci Kulüpleri konulu bilgi ve belgeler hazırlanarak ekte sunulmuştur.

Bilgilerinize arz ederim.

Ek: ........ (... sayfa)
```

## 2. Süre Uzatımı Talebi — yön: üst makam (arz)

Değerler: konu = Aylık Faaliyet Raporu; sayı = E-71234567-605-98700011; tarih = 02.10.2026; gönderen = {ustBirim}

```
İlgi: {ustBirim} 02.10.2026 tarihli ve E-71234567-605-98700011 sayılı yazısı.

İlgi yazı ile istenen Aylık Faaliyet Raporu konusundaki çalışmalar devam etmekte olup ........ nedeniyle belirtilen sürede tamamlanamayacaktır. Söz konusu işlemler için ........ tarihine kadar ek süre verilmesi hususunu olurlarınıza arz ederim.
```

## 3. Öğretmenlere Tebliğ Yazısı — yön: alt birim (rica)

Değerler: konu = Hizmet İçi Eğitim Faaliyetleri; sayı = E-71234567-100-98765432; tarih = 10.10.2026; gönderen = İl Milli Eğitim Müdürlüğü

```
İlgi: İl Milli Eğitim Müdürlüğü 10.10.2026 tarihli ve E-71234567-100-98765432 sayılı yazısı.

Hizmet İçi Eğitim Faaliyetleri konulu ilgi yazı ekte gönderilmiştir. Tebliğ-tebellüğ belgesinin imzalanarak ........ tarihine kadar okul idaresine teslim edilmesini rica ederim.

Ek: ........ (... sayfa)
```

## 4. Bilgi / Belge İstenmesi (Eksik Bilgi) — yön: eşit birim (rica)

Değerler: konu = Öğrenci Nakli; sayı = E-71299999-110-98711111; tarih = 08.10.2026; gönderen = Cumhuriyet İlkokulu Müdürlüğü

```
İlgi: Cumhuriyet İlkokulu Müdürlüğü 08.10.2026 tarihli ve E-71299999-110-98711111 sayılı yazısı.

İlgi yazı ile iletilen Öğrenci Nakli konusunun değerlendirilebilmesi için aşağıda belirtilen bilgi ve belgelerin ........ tarihine kadar {kurumumuza} gönderilmesi gerekmektedir.

1- ........
2- ........

Gereğini rica ederim.
```

