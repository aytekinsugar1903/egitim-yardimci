/* Evrak Asistanı service worker girişi (v3.7.1)
 * Mevcut arka plan (background.js) DEĞİŞMEDEN aynen yüklenir; ardından Düzenli Yazılar bildirimleri eklenir. */
try { importScripts('background.js'); } catch (e) { console.error('[Evrak Asistanı] background.js yüklenemedi', e); }
try { importScripts('periyodik_core.js', 'periyodik_bg.js'); } catch (e) { console.warn('[Evrak Asistanı] Düzenli Yazılar arka planı yüklenemedi', e); }
