/* Evrak Asistanı — Düzenli Yazılar: EBYS sayfası tarafı
 * - Üstte küçük "🔁 Düzenli Yazılar" rozeti (bekleyen / geciken sayısı, renkli)
 * - Küçük panel: bu dönemin yazıları, metni kopyala, gönderildi işaretle
 * - Liste tarayıcı: Parafladıklarım (ya da açık olan herhangi bir evrak listesi) sayfa sayfa okunur,
 *   her ay tekrar eden yazılar bulunur, gönderilenler işaretlenir.
 * Hiçbir evrakı göndermez, imzalamaz, paraflamaz. Mevcut Evrak Asistanı koduna dokunmaz.
 */
(function () {
  'use strict';
  if (window.top !== window) return;
  if (window.__eaPeriyodikYuklendi) return;
  window.__eaPeriyodikYuklendi = true;
  const P = self.EA_PERIYODIK;
  if (!P) return;

  const UI_KEY = 'ebys_periyodik_ui_v1';
  const durumRenk = { gecikti: '#F87171', bugun: '#F87171', yakin: '#FB923C', bekliyor: '#93C5FD', gunyok: '#FBBF24', gonderildi: '#22C55E', yok: '#94A3B8', bitti: '#94A3B8' };
  const sira = { gecikti: 0, bugun: 1, yakin: 2, gunyok: 3, bekliyor: 4, gonderildi: 5, yok: 6, bitti: 7 };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const bekle = ms => new Promise(r => setTimeout(r, ms));

  let depo = null, takip = null, ui = { x: null, y: 40, acik: false, w: 430, h: 470 };
  let pill = null, panel = null;
  const tarama = { calisiyor: false, dur: false, mesaj: '' };

  // ---------------- başlangıç ----------------
  async function basla() {
    for (let i = 0; i < 40; i++) { if (await P.onayVarMi()) break; await bekle(3000); }
    if (!(await P.onayVarMi())) return;
    try { await P.eskiHazirTemizle(); } catch (e) { }
    const x = await P.oku([P.KEY, P.TAKIP_KEY, UI_KEY]);
    depo = P.depoTemizle(x[P.KEY]);
    takip = x[P.TAKIP_KEY] || null;
    if (x[UI_KEY] && typeof x[UI_KEY] === 'object') ui = Object.assign(ui, x[UI_KEY]);
    rozetCiz();
    if (ui.acik) panelAc();
    esitleGerekirse();
    setInterval(mevcutPaneleDugmeEkle, 4000);
    setInterval(() => { rozetCiz(); if (panel) panelCiz(); }, 10 * 60 * 1000);
    try {
      chrome.storage.onChanged.addListener((ch, alan) => {
        if (alan !== 'local') return;
        if (ch[P.KEY]) { depo = P.depoTemizle(ch[P.KEY].newValue); rozetCiz(); if (panel) panelCiz(); }
        if (ch[P.TAKIP_KEY]) { takip = ch[P.TAKIP_KEY].newValue || null; rozetCiz(); if (panel) panelCiz(); }
      });
    } catch (e) { }
  }

  /** Şablonları yalnızca değişiklik varsa yazar (ayın değişmesi vb.) */
  async function esitleGerekirse() {
    try {
      const x = await P.oku([P.TPL_KEY, P.TPL_META_KEY]);
      const tpl = x[P.TPL_KEY] && typeof x[P.TPL_KEY] === 'object' ? x[P.TPL_KEY] : {};
      if (!Object.values(tpl).every(v => typeof v === 'string')) return;
      const meta = x[P.TPL_META_KEY] && typeof x[P.TPL_META_KEY] === 'object' ? x[P.TPL_META_KEY] : {};
      const d = JSON.parse(JSON.stringify(depo));
      const r = P.sablonEsitle(d, tpl, meta);
      if (r.degisti) await P.yaz({ [P.KEY]: d, [P.TPL_KEY]: tpl, [P.TPL_META_KEY]: meta });
    } catch (e) { console.warn('[Evrak Asistanı] Düzenli yazı şablonları eşitlenemedi:', e); }
  }

  function uiKaydet() { P.yaz({ [UI_KEY]: ui }); }

  // ---------------- liste: bu dönem ----------------
  function satirlar() {
    const bugun = P.bugunIso(), out = [];
    (depo ? depo.kartlar : []).forEach(k => {
      if (!k.aktif) return;
      P.aktifDonemler(k, bugun).forEach(p => {
        const gelen = P.gelenBul(k, takip, p);
        const d = P.durum(k, p, bugun, depo.ayar.ekTatiller, gelen);
        if (d.kod === 'bitti') return;
        out.push({ k, p, d });
      });
    });
    return out.sort((a, b) => (sira[a.d.kod] - sira[b.d.kod]) || String(a.d.sonTarih).localeCompare(String(b.d.sonTarih)));
  }

  // ---------------- rozet ----------------
  function rozetCiz() {
    if (!depo) return;
    const s = satirlar().filter(x => !['gonderildi', 'yok'].includes(x.d.kod));
    const kirmizi = s.filter(x => ['gecikti', 'bugun'].includes(x.d.kod)).length;
    const turuncu = s.filter(x => x.d.kod === 'yakin').length;
    if (!pill) {
      pill = document.createElement('div');
      pill.id = 'ea-periyodik-rozet';
      pill.title = 'Düzenli (aylık) yazılar — tıklayın. Sürükleyerek taşıyabilirsiniz.';
      document.documentElement.appendChild(pill);
      surukle(pill, pill, (x, y) => { ui.rx = x; ui.ry = y; uiKaydet(); });
      pill.addEventListener('click', e => { if (pill.__surukledi) return; panel ? panelKapat() : panelAc(); });
    }
    const renk = kirmizi ? '#B91C1C' : turuncu ? '#C2410C' : '#1E3A8A';
    const kenar = kirmizi ? '#F87171' : turuncu ? '#FB923C' : '#60A5FA';
    pill.style.cssText = 'position:fixed;z-index:2147483646;' + (ui.rx != null ? 'left:' + ui.rx + 'px;top:' + ui.ry + 'px;' : 'left:50%;transform:translateX(-50%);top:4px;') +
      'background:' + renk + ';color:#fff;border:1px solid ' + kenar + ';border-radius:14px;padding:3px 11px;font:600 13px "Segoe UI",sans-serif;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.35);user-select:none;white-space:nowrap;';
    const yazi = !depo.kartlar.length ? '🔁 Düzenli yazılar: liste yok' :
      kirmizi ? '🔁 Düzenli yazı: ' + kirmizi + ' acil' + (s.length > kirmizi ? ' · ' + (s.length - kirmizi) + ' bekliyor' : '') :
        s.length ? '🔁 Düzenli yazı: ' + s.length + ' bekliyor' : '🔁 Düzenli yazılar ✓';
    pill.textContent = yazi;
  }

  function mevcutPaneleDugmeEkle() {
    try {
      const satir = document.getElementById('ebys-takip-row2');
      if (!satir || satir.querySelector('#btn-ea-periyodik')) return;
      const b = document.createElement('button');
      b.id = 'btn-ea-periyodik';
      b.type = 'button';
      b.textContent = '🔁 Düzenli Yazılar';
      b.title = 'Her ay / 3 ayda bir giden yazılar: takvim, hatırlatma, hazır metin';
      b.style.cssText = 'flex:1;background:#1E3A8A;color:#DBEAFE;border:1px solid #60A5FA;padding:5px 8px;border-radius:8px;font-size:11px;cursor:pointer;';
      b.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); panel ? panelKapat() : panelAc(); });
      satir.appendChild(b);
    } catch (e) { }
  }

  // ---------------- panel ----------------
  function panelAc() {
    if (panel) return;
    panel = document.createElement('div');
    panel.id = 'ea-periyodik-panel';
    const sol = ui.x != null ? ui.x : Math.max(10, (window.innerWidth - ui.w) / 2);
    panel.style.cssText = 'position:fixed;z-index:2147483647;left:' + sol + 'px;top:' + (ui.y || 40) + 'px;width:' + ui.w + 'px;height:' + ui.h + 'px;min-width:340px;min-height:220px;resize:both;overflow:hidden;display:flex;flex-direction:column;' +
      'background:#0F1B33;color:#E2E8F0;border:1px solid #3B82F6;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.5);font:13px "Segoe UI",sans-serif;';
    panel.innerHTML = '<div class="eap-bas" style="display:flex;align-items:center;gap:6px;padding:7px 10px;background:#13294B;border-bottom:1px solid #2D4A7A;cursor:move;border-radius:12px 12px 0 0;">' +
      '<b style="flex:1;color:#BFDBFE;font-size:13.5px;">🔁 Düzenli Yazılar</b>' +
      '<button class="eap-yonet" title="Tüm listeyi aç: ekle, düzenle, yıllık çizelge" style="' + btn('#1D4ED8') + '">⚙️ Yönet</button>' +
      '<button class="eap-kapat" title="Kapat" style="background:none;border:none;color:#94A3B8;font-size:16px;cursor:pointer;">✕</button></div>' +
      '<div class="eap-govde" style="flex:1;overflow:auto;padding:8px 10px;"></div>' +
      '<div class="eap-alt" style="padding:7px 10px;border-top:1px solid #2D4A7A;display:flex;flex-direction:column;gap:5px;"></div>';
    document.documentElement.appendChild(panel);
    surukle(panel, panel.querySelector('.eap-bas'), (x, y) => { ui.x = x; ui.y = y; uiKaydet(); });
    try { new ResizeObserver(() => { if (!panel) return; ui.w = panel.offsetWidth; ui.h = panel.offsetHeight; clearTimeout(panel.__rt); panel.__rt = setTimeout(uiKaydet, 600); }).observe(panel); } catch (e) { }
    panel.querySelector('.eap-kapat').onclick = panelKapat;
    panel.querySelector('.eap-yonet').onclick = () => sayfaAc('');
    ui.acik = true; uiKaydet();
    panelCiz();
  }
  function panelKapat() { if (panel) panel.remove(); panel = null; ui.acik = false; uiKaydet(); }
  function btn(bg) { return 'background:' + bg + ';color:#fff;border:none;padding:4px 9px;border-radius:7px;font-size:12px;cursor:pointer;'; }

  function panelCiz() {
    if (!panel || !depo) return;
    const g = panel.querySelector('.eap-govde');
    const s = satirlar();
    if (!depo.kartlar.length) {
      g.innerHTML = '<div style="color:#CBD5E1;line-height:1.5;">Henüz düzenli yazı listesi yok.<br><br>' +
        '<b>En kolayı:</b> aşağıdaki <b>🔍 Geçmiş yazılardan bul</b> düğmesine basın. Parafladıklarım listesi sayfa sayfa okunur; ' +
        'her ay (ya da 3 ayda bir) aynı konuyla giden yazılar bulunup size önerilir.<br><br>Elle eklemek için <b>⚙️ Yönet</b>.</div>';
    } else if (!s.length) {
      g.innerHTML = '<div style="color:#86EFAC;">Bu dönem bekleyen düzenli yazı yok. 🎉</div>';
    } else {
      g.innerHTML = s.map((x, i) => {
        const d = x.d, k = x.k;
        const gelen = d.gelen ? '<div style="color:#FDE68A;font-size:12px;">📨 Hatırlatma yazısı geldi' + (d.gelen.evrakNo ? ' (' + esc(d.gelen.evrakNo) + ')' : '') + ' — son tarih ' + P.trTarih(d.gelen.sonTarih) + '</div>' : '';
        const islem = d.kod === 'gonderildi' || d.kod === 'yok'
          ? '<button class="eap-geri" data-i="' + i + '" style="' + btn('#475569') + '">↩ Geri al</button>'
          : (k.metin ? '<button class="eap-kopya" data-i="' + i + '" title="Geçen dönemin metni; ay ve tarihler bu döneme göre güncellenir" style="' + btn('#7C3AED') + '">📋 Metni kopyala</button>' : '') +
          '<button class="eap-gonder" data-i="' + i + '" title="Bu dönemin yazısı gönderildi olarak işaretle" style="' + btn('#047857') + '">✅ Gönderildi</button>' +
          '<button class="eap-yok" data-i="' + i + '" title="Bu dönem gönderilmeyecek (ör. tatil ayı)" style="' + btn('#334155') + '">➖ Bu dönem yok</button>';
        return '<div style="background:#16284A;border-left:4px solid ' + (durumRenk[d.kod] || '#60A5FA') + ';border-radius:8px;padding:6px 8px;margin-bottom:6px;">' +
          '<div style="display:flex;gap:6px;align-items:baseline;"><b style="flex:1;color:#F8FAFC;">' + esc(k.ad) + '</b>' +
          '<span style="color:' + (durumRenk[d.kod] || '#93C5FD') + ';font-size:12px;white-space:nowrap;">' + esc(d.etiket) + '</span></div>' +
          '<div style="color:#A9B6CA;font-size:12px;">' + esc(P.ayAdi(x.p)) + ' dönemi' + (d.sonTarih ? ' · son gün ' + P.trTarih(d.sonTarih) : '') + (k.kime ? ' · 🎯 ' + esc(k.kime) : '') + (k.konuKodu ? ' · 🗂 ' + esc(k.konuKodu) : '') + '</div>' +
          gelen +
          '<div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:5px;">' + islem + '</div></div>';
      }).join('');
      g.querySelectorAll('.eap-kopya').forEach(b => b.onclick = () => kopyala(s[+b.dataset.i]));
      g.querySelectorAll('.eap-gonder').forEach(b => b.onclick = () => isaretle(s[+b.dataset.i], 'elle'));
      g.querySelectorAll('.eap-yok').forEach(b => b.onclick = () => isaretle(s[+b.dataset.i], 'yok'));
      g.querySelectorAll('.eap-geri').forEach(b => b.onclick = () => geriAl(s[+b.dataset.i]));
    }
    altCiz();
  }

  function altCiz() {
    if (!panel) return;
    const a = panel.querySelector('.eap-alt');
    if (tarama.calisiyor) {
      a.innerHTML = '<div style="color:#FDE68A;font-size:12px;">⏳ ' + esc(tarama.mesaj) + '</div><button class="eap-dur" style="' + btn('#B91C1C') + '">⏹ Durdur</button>';
      a.querySelector('.eap-dur').onclick = () => { tarama.dur = true; tarama.mesaj = 'Durduruluyor…'; altCiz(); };
      return;
    }
    a.innerHTML = (tarama.mesaj ? '<div style="color:#BBF7D0;font-size:12px;">' + tarama.mesaj + '</div>' : '') +
      '<div style="display:flex;gap:5px;flex-wrap:wrap;">' +
      '<button class="eap-tara" title="Parafladıklarım listesini sayfa sayfa okur; düzenli yazıları bulur ve gönderilenleri işaretler" style="' + btn('#0369A1') + '">🔍 Geçmiş yazılardan bul</button>' +
      '<button class="eap-hizli" title="Yalnız ilk 3 sayfa: bu ay gönderilenleri işaretlemek için" style="' + btn('#155E75') + '">⚡ Gönderilenleri kontrol et</button>' +
      '</div><div style="color:#7C8DA8;font-size:11px;">Açık olan liste okunur; liste açık değilse Parafladıklarım açılır. Hiçbir evrak gönderilmez.</div>';
    a.querySelector('.eap-tara').onclick = () => taramaBaslat(150);
    a.querySelector('.eap-hizli').onclick = () => taramaBaslat(3);
  }

  // ---------------- işlemler ----------------
  async function kopyala(x) {
    const r = P.donemMetni(x.k, x.p);
    let ok = false;
    try { await navigator.clipboard.writeText(r.metin); ok = true; } catch (e) {
      try { const t = document.createElement('textarea'); t.value = r.metin; t.style.cssText = 'position:fixed;left:-9999px;'; document.body.appendChild(t); t.select(); ok = document.execCommand('copy'); t.remove(); } catch (e2) { }
    }
    const deg = r.degisen.length ? ' Güncellenen: ' + r.degisen.slice(0, 6).map(d => esc(d.eski) + ' → <b>' + esc(d.yeni) + '</b>').join(', ') + (r.degisen.length > 6 ? ' …' : '') : ' (metinde ay/tarih bulunamadı, aynen kopyalandı)';
    tarama.mesaj = (ok ? '📋 Kopyalandı: <b>' + esc(x.k.ad) + '</b>.' : '⚠️ Panoya kopyalanamadı.') + deg +
      (ok ? '<br>Cevap Yaz / yeni yazı ekranında editöre yapıştırın (Ctrl+V). Şablon menüsünde de <b>' + esc(x.k.ad) + '</b> adıyla duruyor.' : '');
    altCiz();
  }
  async function isaretle(x, tur) {
    let no = '';
    if (tur === 'elle') {
      no = prompt('“' + x.k.ad + '” — ' + P.ayAdi(x.p) + ' dönemi gönderildi.\nEvrak sayısı (isterseniz, boş bırakabilirsiniz):', '');
      if (no === null) return;
    }
    const d = await P.depoOku();
    const k = d.kartlar.find(c => c.id === x.k.id); if (!k) return;
    k.gonderim[x.p] = { tarih: P.bugunIso(), no: String(no || '').trim(), kaynak: tur, konu: '' };
    await P.depoYaz(d);
    // Günlü takipte bu döneme ait hatırlatma yazısı varsa tamamlandı yap
    if (tur === 'elle' && x.d.gelen && x.d.gelen.id) {
      try {
        const t = await P.oku([P.TAKIP_KEY]); const st = t[P.TAKIP_KEY];
        const it = st && Array.isArray(st.items) ? st.items.find(i => i.id === x.d.gelen.id) : null;
        if (it && it.durum !== 'tamamlandi') { it.durum = 'tamamlandi'; it.tamamlanma = P.bugunIso(); await P.yaz({ [P.TAKIP_KEY]: st }); tarama.mesaj = '✅ İşaretlendi; Günlü Takip\'teki hatırlatma yazısı da tamamlandı yapıldı.'; }
      } catch (e) { }
    }
  }
  async function geriAl(x) {
    const d = await P.depoOku();
    const k = d.kartlar.find(c => c.id === x.k.id); if (!k) return;
    delete k.gonderim[x.p];
    await P.depoYaz(d);
  }

  function sayfaAc(hash) {
    try { chrome.runtime.sendMessage({ type: 'ea-periyodik-ac', hash: hash || '' }, r => { void chrome.runtime.lastError; if (!r || !r.ok) window.open(chrome.runtime.getURL('periyodik.html' + (hash ? '#' + hash : '')), '_blank'); }); }
    catch (e) { try { window.open(chrome.runtime.getURL('periyodik.html' + (hash ? '#' + hash : '')), '_blank'); } catch (e2) { } }
  }

  // ---------------- liste tarayıcı ----------------
  function belgeler() {
    const out = [document];
    document.querySelectorAll('iframe,frame').forEach(f => { try { if (f.contentDocument && f.contentDocument.body) out.push(f.contentDocument); } catch (e) { } });
    return out;
  }
  function gorunur(el) { if (!el) return false; const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  /** Görünür evrak listesinin satırları */
  function listeSatirlari() {
    for (const d of belgeler()) {
      const tbodies = Array.from(d.querySelectorAll('tbody[id$="_data"]')).filter(gorunur);
      for (const tb of tbodies) {
        const rows = Array.from(tb.children).filter(tr => tr.tagName === 'TR' && tr.hasAttribute('data-ri') && !tr.classList.contains('ui-datatable-empty-message'));
        if (rows.length && rows.some(r => /\d{2}\.\d{2}\.\d{4}/.test(r.textContent || ''))) return { tbody: tb, rows };
      }
    }
    return null;
  }
  const metinTemiz = el => el ? (el.textContent || '').replace(/\s+/g, ' ').trim() : '';
  function satirOku(tr) {
    const tum = metinTemiz(tr);
    const q = s => metinTemiz(tr.querySelector(s));
    let konu = (q('h3.ui-inbox-satir1') || q('.rowTitleForInbox') || q('.ui-inbox-satir1')).replace(/^Konu\s*:\s*/i, '');
    if (!konu) { const m = tum.match(/Konu\s*:\s*(.{3,180}?)(?=\s+(Kişisel Arşive|Geldiği Yer|Gideceği Yer|Gönderildiği Yer|\d{2}\.\d{2}\.\d{4})|$)/); if (m) konu = m[1]; }
    const yer = q('.ui-inbox-satir2').replace(/^[^:]{0,30}Yer[^:]{0,10}:\s*/i, '').replace(/^(Kime|Gereği|Dağıtım)\s*:\s*/i, '');
    const tarihler = (tum.match(/\b\d{1,2}\.\d{1,2}\.\d{4}\b/g) || []).map(P.trDenIso).filter(Boolean);
    const tarih = (P.trDenIso(q('.ui-inbox-satir4')) || tarihler[0] || '');
    const no = (tum.match(/E-\d{6,10}-[\d.]+-\d+/) || tum.match(/E-\d{6,10}[-\w.]+\w/) || [])[0] || '';
    if (!konu || !tarih) return null;
    return { konu: konu.slice(0, 200), tarih, yer: yer.slice(0, 160), no };
  }
  function paginator(tb) {
    let el = tb; for (let i = 0; i < 12 && el; i++) { el = el.parentElement; if (el && el.querySelector && el.querySelector('.ui-paginator')) return el.querySelector('.ui-paginator'); }
    return (tb.ownerDocument || document).querySelector('.ui-paginator');
  }
  const pasif = el => !el || el.classList.contains('ui-state-disabled') || el.getAttribute('aria-disabled') === 'true';
  async function degisimiBekle(oncekiIlk, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      await bekle(250);
      if (ortuVar()) continue;
      const l = listeSatirlari();
      const ilk = l && l.rows[0] ? metinTemiz(l.rows[0]).slice(0, 120) : '';
      if (ilk && ilk !== oncekiIlk) { await bekle(600); return true; }
    }
    return false;
  }
  function ortuVar() {
    for (const d of belgeler()) {
      const o = Array.from(d.querySelectorAll('[id*="statusDialog"], [id*="ajaxStatus"], [id*="bekleyiniz" i], .ui-dialog')).find(e => gorunur(e) && /bekleyiniz|yükleniyor/i.test(e.textContent || ''));
      if (o) return true;
    }
    return false;
  }
  async function parafladiklarimAc() {
    if (listeSatirlari()) return true;
    let menu = null;
    for (const d of belgeler()) {
      menu = d.querySelector('[id="leftMenu.islemYaptiklarim.parafladiklarim"], [id*="parafladiklarim" i]');
      if (!menu) menu = Array.from(d.querySelectorAll('a, span, li')).find(e => /^\s*Parafladıklarım\s*$/.test(e.textContent || ''));
      if (menu) break;
    }
    if (!menu) return false;
    tarama.mesaj = 'Parafladıklarım açılıyor…'; altCiz();
    // menü kapalıysa önce "İşlem Yaptıklarım" başlığını aç
    if (!gorunur(menu)) {
      for (const d of belgeler()) {
        const ust = Array.from(d.querySelectorAll('a, span, h3, li')).find(e => /^\s*İşlem Yaptıklarım\s*$/.test(e.textContent || ''));
        if (ust) { try { ust.click(); } catch (e) { } await bekle(1200); break; }
      }
    }
    try { (menu.querySelector('a') || menu).click(); } catch (e) { }
    const t0 = Date.now();
    while (Date.now() - t0 < 20000) { await bekle(400); if (listeSatirlari() && !ortuVar()) { await bekle(800); return true; } }
    return !!listeSatirlari();
  }
  async function sayfaBoyutuEnBuyuk(tb) {
    try {
      const pg = paginator(tb); const sel = pg && pg.querySelector('select.ui-paginator-rpp-options');
      if (!sel) return;
      const en = Array.from(sel.options).map(o => ({ v: o.value, n: parseInt(o.value, 10) })).filter(o => !isNaN(o.n)).sort((a, b) => b.n - a.n)[0];
      if (!en || String(sel.value) === String(en.v)) return;
      const l = listeSatirlari(); const ilk = l && l.rows[0] ? metinTemiz(l.rows[0]).slice(0, 120) : '';
      sel.value = en.v; sel.dispatchEvent(new Event('change', { bubbles: true }));
      await degisimiBekle(ilk, 20000); await bekle(1500);
    } catch (e) { }
  }
  async function ilkSayfayaGit(tb) {
    const pg = paginator(tb); if (!pg) return;
    const f = pg.querySelector('.ui-paginator-first');
    if (f && !pasif(f)) { const l = listeSatirlari(); const ilk = l ? metinTemiz(l.rows[0]).slice(0, 120) : ''; f.click(); await degisimiBekle(ilk, 20000); }
  }

  async function taramaBaslat(maxSayfa) {
    if (tarama.calisiyor) return;
    tarama.calisiyor = true; tarama.dur = false; tarama.mesaj = 'Liste aranıyor…'; altCiz();
    const toplanan = new Map();
    let sayfa = 0, hata = '';
    try {
      if (!(await parafladiklarimAc())) { hata = 'Evrak listesi bulunamadı. EBYS\'de İşlem Yaptıklarım > Parafladıklarım listesini açıp tekrar basın.'; return; }
      let l = listeSatirlari();
      await sayfaBoyutuEnBuyuk(l.tbody);
      l = listeSatirlari(); if (!l) { hata = 'Liste kayboldu; tekrar deneyin.'; return; }
      await ilkSayfayaGit(l.tbody);
      for (sayfa = 1; sayfa <= maxSayfa && !tarama.dur; sayfa++) {
        l = listeSatirlari(); if (!l) break;
        l.rows.forEach(tr => { const s = satirOku(tr); if (s) toplanan.set(s.no || (s.konu + '|' + s.tarih), s); });
        const enEski = [...toplanan.values()].map(s => s.tarih).sort()[0] || '';
        tarama.mesaj = 'Sayfa ' + sayfa + (maxSayfa < 999 ? ' / en çok ' + maxSayfa : '') + ' okundu — ' + toplanan.size + ' yazı' + (enEski ? ' (en eski: ' + P.trTarih(enEski) + ')' : '');
        altCiz();
        const pg = paginator(l.tbody); const ileri = pg && pg.querySelector('.ui-paginator-next');
        if (!ileri || pasif(ileri)) break;
        const ilk = metinTemiz(l.rows[0]).slice(0, 120);
        ileri.click();
        await bekle(2000); // yavaş okul interneti için güvenlik beklemesi
        if (!(await degisimiBekle(ilk, 20000))) { hata = 'Sayfa ' + (sayfa + 1) + ' 20 sn içinde gelmedi; okunanlarla devam edildi.'; break; }
      }
    } catch (e) {
      hata = 'Tarama hatası: ' + (e && e.message || e);
    } finally {
      await taramaBitir([...toplanan.values()], hata, maxSayfa);
    }
  }

  async function taramaBitir(satirlarListe, hata, maxSayfa) {
    try {
      const x = await P.oku([P.ADAY_KEY, P.KEY, P.TEKRAR_KEY, P.PARAF_KEY]);
      const d = P.depoTemizle(x[P.KEY]);
      const eski = x[P.ADAY_KEY] && typeof x[P.ADAY_KEY] === 'object' ? x[P.ADAY_KEY] : {};
      // önceki taramalarla birleştir (en çok 4000 satır)
      const birlesik = new Map();
      (Array.isArray(eski.satirlar) ? eski.satirlar : []).concat(satirlarListe).forEach(s => { if (s && s.konu && s.tarih) birlesik.set(s.no || (s.konu + '|' + s.tarih), s); });
      const tum = [...birlesik.values()].sort((a, b) => b.tarih.localeCompare(a.tarih)).slice(0, 4000);
      const isaretlenen = P.gonderimleriIsle(d, satirlarListe);
      const yoksay = Array.isArray(eski.yoksay) ? eski.yoksay : [];
      const adaylar = P.adayBul(tum, d.kartlar).filter(a => !a.zatenVar && !yoksay.includes(a.id));
      adaylar.forEach(a => { const m = P.parafMetniBul(a, x[P.PARAF_KEY], a.ornekler); if (m) { a.metin = m.metin; a.metinAy = m.ay; } });
      const tekrar = P.tekrarAdaylari(x[P.TEKRAR_KEY]).filter(a => !yoksay.includes(a.id) && !d.kartlar.some(k => P.eslesir(k, a.ornekKonu)) && !adaylar.some(b => P.benzerlik(b.ornekKonu, a.ornekKonu) >= 0.6));
      await P.yaz({ [P.ADAY_KEY]: { satirlar: tum, adaylar: adaylar.concat(tekrar), yoksay, tarama: { tarih: P.bugunIso(), satir: satirlarListe.length } } });
      if (isaretlenen) await P.depoYaz(d);
      tarama.mesaj = (hata ? '⚠️ ' + esc(hata) + '<br>' : '') +
        '✅ ' + satirlarListe.length + ' yazı okundu' + (isaretlenen ? ', <b>' + isaretlenen + '</b> dönem "gönderildi" işaretlendi' : '') + '. ' +
        (adaylar.length + tekrar.length ? '<b>' + (adaylar.length + tekrar.length) + ' düzenli yazı önerisi</b> bulundu → <a href="#" class="eap-oneri" style="color:#7DD3FC;">Önerileri aç</a>' : (maxSayfa <= 3 ? '' : 'Yeni öneri yok.'));
    } catch (e) {
      tarama.mesaj = '⚠️ Sonuç kaydedilemedi: ' + esc(e && e.message || e);
    }
    tarama.calisiyor = false;
    altCiz();
    const a = panel && panel.querySelector('.eap-oneri');
    if (a) a.onclick = ev => { ev.preventDefault(); sayfaAc('oneriler'); };
  }

  // ---------------- sürükleme ----------------
  function surukle(kutu, tutamak, bitti) {
    let sx, sy, ox, oy, hareket = false;
    tutamak.addEventListener('mousedown', e => {
      if (e.button !== 0 || e.target.closest('button,a,input,textarea,select')) return;
      const r = kutu.getBoundingClientRect(); sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top; hareket = false; kutu.__surukledi = false;
      const mm = ev => {
        const dx = ev.clientX - sx, dy = ev.clientY - sy;
        if (!hareket && Math.abs(dx) + Math.abs(dy) < 4) return;
        hareket = true; kutu.__surukledi = true;
        kutu.style.transform = 'none';
        kutu.style.left = Math.max(0, Math.min(window.innerWidth - 60, ox + dx)) + 'px';
        kutu.style.top = Math.max(0, Math.min(window.innerHeight - 24, oy + dy)) + 'px';
      };
      const mu = () => { document.removeEventListener('mousemove', mm, true); document.removeEventListener('mouseup', mu, true); if (hareket) { bitti(parseInt(kutu.style.left, 10), parseInt(kutu.style.top, 10)); setTimeout(() => { kutu.__surukledi = false; }, 50); } };
      document.addEventListener('mousemove', mm, true); document.addEventListener('mouseup', mu, true);
      e.preventDefault();
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', basla); else basla();
})();
