/* Evrak Asistanı — derleme bayrağı (v3.7.2)
 * Bu dosya kayit.js'ten ÖNCE yüklenir.
 * true  = kişisel: evrak kayıt formunu doldurur ve doğrulanmış formda Kaydet'e 1 kez basar.
 * false = mağaza: form hazır olunca Kaydet'te durur, düğmeyi vurgular; Kaydet / Gönder / İmza / Paraf
 *         ve kayıt sonrası Evet/Onayla/Tamam/Kapat pencerelerine basmaz.
 */
var EA_OTOMATIK_KAYDET = false;
