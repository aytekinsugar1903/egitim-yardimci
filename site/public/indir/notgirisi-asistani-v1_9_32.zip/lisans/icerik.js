/* manifest içerik betikleri — yalnız lisans/deneme geçerliyken kaydedilir */
self.EA_ICERIK = [
  {
    "id": "ea-ic-1",
    "matches": [
      "*://e-okul.meb.gov.tr/*",
      "*://*.e-okul.meb.gov.tr/*",
      "*://eokul.meb.gov.tr/*",
      "*://*.eokul.meb.gov.tr/*"
    ],
    "js": [
      "oyss/ana_dunya.js"
    ],
    "persistAcrossSessions": true,
    "allFrames": true,
    "runAt": "document_start",
    "world": "MAIN"
  },
  {
    "id": "ea-ic-2",
    "matches": [
      "*://e-okul.meb.gov.tr/*",
      "*://*.e-okul.meb.gov.tr/*",
      "*://eokul.meb.gov.tr/*",
      "*://*.eokul.meb.gov.tr/*"
    ],
    "js": [
      "oyss/xlsx.js",
      "oyss/oyss.js",
      "oyss/bagla.js",
      "akis.js",
      "ses.js",
      "ses/hap.js",
      "ice/excel.js",
      "ice/cozumle.js",
      "panel.js"
    ],
    "persistAcrossSessions": true,
    "allFrames": true,
    "runAt": "document_idle"
  },
  {
    "id": "ea-ic-3",
    "matches": [
      "*://e-okul.meb.gov.tr/*",
      "*://*.e-okul.meb.gov.tr/*",
      "*://eokul.meb.gov.tr/*",
      "*://*.eokul.meb.gov.tr/*"
    ],
    "js": [
      "oturum.js"
    ],
    "persistAcrossSessions": true,
    "allFrames": true,
    "runAt": "document_idle"
  }
];
