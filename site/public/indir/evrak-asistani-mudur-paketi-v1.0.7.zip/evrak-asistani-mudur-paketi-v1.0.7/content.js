    window.__EA_MUDUR_RO = true; // Müdür Paketi salt okunur kalkanı
/* © 2026 Eyüp ŞEKER — Evrak Asistanı. Tüm hakları saklıdır. */
// ==== Evrak Asistanı v3.6.42 (eski adı: EBYS Otonom Core) ====
// MÜDÜR PAKETİ v1.0.7 (lisans + 48 saat deneme: lisans/ klasörü) — v1.0.6 (kaynak 3.6.59 tabanı + 3.6.60 tarih düzeltmeleri): 1.0.4 + WhatsApp ile paylaş (elle; otomatik gönderim yok) ve Telefon Rehberi; eski varsayılan kurum adı pakette yok (özet karşılaştırması). EBYS'de Kaydet/Gönder/İmza/Paraf/Havale YOK.
//   Tarih/süre okuyucu: 3.6.59 kalıpları + her olmadan "ayın N'ine kadar", dönemlik / 3-6 aylık / çeyrek / yıllık ve "dönemi takip eden ayın N'i". Tüm veriler bu bilgisayarda kalır.
// v3.6.37: +41 hazır şablon (evrakburada listesindeki eksikler; MEB yazışma diliyle, okul profili yer tutucularıyla {okul} {müdür} {il} {ilçe} …),
//   şablon seçiminde kategoriler (+/−) ve anahtar kelimeyle arama; Gereği ilk denemede: tembel yüklenen alan için kararlılık beklemesi,
//   gerçek odak dizisi, gizli LOV diyaloğunu PrimeFaces widget.show() ile açma, sonuç gelmezse 2 kez yeniden yazım; Kapat → kart listeden anında düşer
//   (EBYS'nin kendi Evrak Kapat düğmesiyle kapatılınca da); "açılamadı/kapatılamadı" uyarıları açılır pencere yerine bildirim.
// v3.6.35: İlk Cevap Yardımcısı (ilk başarısızlıkta dostça panel; elle aç-kapa algılanınca otomatik yeniden deneme), Okul Bilgileri okunabilirlik,
//   Havale kuralları tek tık +/− (onay penceresi yok, ↶ Geri al, arama), hafif tasarım cilası, konsol öneki [Evrak Asistanı].
// v3.6.34: Direkt akışı tek awaited promise; kapanış kontrolü onu bekler + taze görünürlük ("Dağıtım uyarısı kapanmadı" yarışı giderildi).
// v3.6.33 (DENEYSEL): "Direkt Gönder" (dağıtım uyarısı) sağlam tıklama — hazır olma beklenir (pencere/düğme/PrimeFaces kuyruğu/jQuery.active/konum sabit),
//   sayfa dünyasında onclick → jQuery trigger → tam fare dizisi; her biri sonrası 8 sn kapanma beklenir; her adım tanı raporunda. Isınma korunur (zararsız).
// v3.6.32 (DENEYSEL): DOCX "ETİKET : ____" satırları doldurulur; okul düzeyi değerler satır bazlı veri tablolarına (alan/dal, sınıf kız/erkek, işletme, liste) ASLA yazılmaz;
//   ilk çalıştırma ısınması (Cevap Yaz penceresi / Editör / Evrak Ekleri ilk açılışta gelmezse bir kez kapat-aç; gönderme/imza yok).
// v3.6.31 (DENEYSEL): "Evrak Ekleri" tablosu yoksa sekme şeridindeki "Evrak Ekleri" sekmesi açılır (tembel AJAX yükleme beklenir), sütunlar başlık METNİNE göre eşlenir,
//   EVRAK türü (indirme kapalı) ekler atlanır, sonra önceki sekmeye dönülür; tanı notu özel (sekme yok / tablo boş / indirme başarısız + neden). DOCX tablo formu yerinde doldurulur (eksikler sarı).
// v3.6.30 (DENEYSEL): 📎 Evrak Ekleri içeriği okunur (PDF/DOCX/XLSX/XLS, yerel); Excel/tablo formlarında alan kontrol listesi + 🏫 Kurum Ayarları profiliyle
//   doldurulmuş kopya (eksikler sarı). Ek indirme yolu gerçek EBYS kaydından çıkarıldı, CANLI EBYS'de doğrulanmadı.
// v3.6.30: 📝 57 hazır şablon Resmî Yazışma Yönetmeliği düzenine göre yeniden yazıldı (İlgi a/b, Ek/Ekler, yöne göre kapanış: üst → arz, alt/eşit → rica) + 8 yeni şablon (65);
//   şablon kütüphanesinde "Yazı yönü" ayarı (Otomatik/Üst/Alt/Eşit) ve şablon başına yön; eski sürümün hazır şablon kopyaları yeni metni gölgelemez.
// v3.6.29: 🧩 Havale madde şablonu — atomik maddeler (Kantin, Taşıma… ayrı), kişi × madde Gereği/Bilgi (+/−), özel madde; mevcut kural biçimine dönüşür, eski kurallar kayıpsız aktarılır.
// v3.6.26: "Dağıtım uyarısı kapanmadı" yanlış alarmı — kapanış kontrolü 2,5 sn boyunca yeniden denenir (akış hızı aynı).
// v3.6.21: Kaydedici yalnızca uyarı penceresi / 60 sn / düğmeye tekrar basınca biter (eski köprü örneği yanıtları yok sayılır), geri sayım; tüm Cevap formu
//   olayları ve görünür olan her liste kaydedilir. Panelde 'Gereği otomatik' anahtarı. Otomatik Gereği: EBYS isteği 20 sn'den uzun sürerse temiz iptal.
//   Klasör → Gereği arası sabit beklemeler kaldırıldı (örtü ~300 ms kapalı kalınca devam, en çok 4 sn).
// v3.6.20: Gereği ağacı TEKLİ seçimli (select AJAX'lı): sayfa dünyasında Tree.selectNode + TEK fireNodeSelectEvent; Tamam'a basılmaz. Kaydedici otomatik denemece ezilmez.
// v3.6.19: 🎥 'Kayıt (Gereği elle seç)' — Gereği'ni elle seçerken pencere HTML'i, olaylar, PrimeFaces istek/yanıtları ve ağaç ayarları pasif kaydedilip panoya kopyalanır;
//   otomatik Gereği denemesinde de istek/yanıt kaydı tanı raporuna eklenir; rapor başlığında sürüm her zaman görünür.
// v3.6.18: Gereği öğesi sayfa dünyasında PrimeFaces Tree nodeClick ile TEK seferde seçilir; örtü sürerken yeniden tıklama yapılmaz.
// v3.6.17: Gereği, Kaldırılacak Klasörler ile birebir aynı kod yolunu kullanır (ayrı Gereği arama/seçim/örtü mantığı kaldırıldı); Seçim Tipi yalnızca Birim değilse değiştirilir.
// v3.6.16: Gereği seçimi TEK tıklama (+ örtü bitince gerekirse tek 'Tamam'); ek yöntemler/yeniden tıklama kaldırıldı (çakışan AJAX örtüyü bitirmiyordu).
// v3.6.16: Gereği arama tetiklemesi insan gibi (input + tek keyup; 'change' ve keydown yok — çakışan AJAX 'Lütfen Bekleyiniz'i bitirmiyordu).
// v3.6.16: ⏹ Durdur düğmesi iç çerçevede çalışan otomasyonda da görünür (yalnızca üst belgede çizilir, çerçeveler durum bildirir, durdurma tüm çerçevelere yayılır).
// v3.6.15: Gereği — EBYS'nin kendi 'Lütfen Bekleyiniz' süresi 15 sn'lik sınıra SAYILMAZ (en çok 60 sn beklenir; örtü açıkken hiçbir şey yazılmaz/tıklanmaz);
//   örtü tespiti kesin (görünür + display≠none + boyut>0 + aria-hidden≠true); ağaçta yaprak eşleşmezse eşleşen üst düğüm seçilir; Gereği başarısızsa
//   editör bulunamadı uyarısı (alert) yerine bildirim; ⏹ Durdur otomasyon boyunca sürekli yerinde tutulur (DOM yenilense de geri eklenir).
// v3.6.14: Gereği için KESİN 15 sn üst sınır (tüm beklemeler bu süreye kırpılır), tek arama (yeniden yazma / ikinci terim / dış 3'lü tekrar yok);
//   ⏹ Durdur düğmesi sayfanın ALT ORTASINDA, sağa-sola sürüklenebilir, konumu hatırlanır; Gereği sonrasında form kapandıysa / önizlemeye geçildiyse başarı sayılır (yanlış ❌ yok).
//   süre dolarsa tanı raporu (Gereği penceresi HTML + bekleme örtüsü bilgisi) ile durur; art arda 3 başarısız evraktan sonra Gereği otomatiği kapanır (başarılı seçim sayacı sıfırlar).
// v3.6.13: Gereği — her adımdan önce "Lütfen Bekleyiniz" (#bekleyinizStatusDialog) kesin olarak kapanana kadar beklenir (≥800 ms kesintisiz gizli, en çok 20 sn);
//   yalnızca kurum adı (" / " öncesi) kullanılır, şube yok sayılır; arama kısa terimle ("… Müdürlüğü" olmadan → "İlçe Milli Eğitim"); başlığı kuruma eşit YAPRAK seçilir ("Birim" değil);
//   liste açılmazsa terim bir kez yeniden yazılır; tanı raporu her LoV penceresinin HTML'ini ayrı ayrı yazar (hatalı alanınki görünür).
// v3.6.12: KÖK NEDEN düzeltmesi — LoV açılır penceresi "form.querySelector(...) || document.querySelector(...)" ile aranıyordu; PrimeFaces pencereyi
//   gösterirken <body>'ye taşıyor, AJAX güncellemesi formun içine GİZLİ bir kopyasını (aynı id) yeniden koyuyor → ilk eşleşme gizli kopya → "öğe yok".
//   Artık tüm çerçevelerde aynı id'li pencerelerin GÖRÜNÜR olanı alınır (findLovDialog; kapatma, Klasör ve Gereği aynı işlevi kullanır).
//   Çoklu seçimli ağaç (Kaldırılacak Klasörler): düğüm tıklanır → sarı vurgu doğrulanır → penceredeki 'Tamam' düğmesine basılır; vurgulu düğüme tekrar tıklanmaz (seçimi kaldırırdı).
//   Gereği ağacında üst düğüm ("Birim") değil, eşleşen YAPRAK seçilir. Direkt Gönder izleyicisi 15 sn.
// v3.6.10: LoV alanları KESİN kimlikle bulunur (konuKoduLov / eklenecekKlasorlerLov / geregiLov); Onay Akışı (akisLov / akisAdimLov) satırına ASLA dokunulmaz;
//   LoV öğesi sırayla öğe / satır / iç hücre / çift tıklama / jQuery / PrimeFaces widget yöntemleriyle seçilir, seçili kutu doğrulanır, işe yarayan yöntem tanı raporuna yazılır
//   (raporda LoV listesinin HTML'i de var); "Direkt Gönder" izleyicisi 15 sn tüm çerçevelerde (üst pencere dahil) çalışır, sayfa dünyasından da tıklar;
//   ⏹ Durdur düğmesi (Cevap Yaz / havale / tarama): bekleyen tüm adımları, yeniden denemeleri ve izleyicileri hemen iptal eder; aynı adım 3 kez başarısızsa otomatik durur.
// v3.6.9: 'Lütfen Bekleyiniz' örtüsü AJAX meşgul sayılır (menü/LoV adımları örtü kalkınca yapılır); Gelen Evraklar menüsü 5 denemeye çıktı;
//   Cevap Yaz: Gereği Seçim Tipi 'Birim' yapılır; Kaldırılacak Klasör ve Gereği adımları 3 kez denenir, adım adım durum bildirimi.
// v3.6.8: Gereği — gönderen "Birim / Şube" biçimindeyse (ör. "İlçe Milli Eğitim Müdürlüğü / Özel Eğitim ve Rehberlik Şube Müdürlüğü") önce tam ad, sonra şube, sonra üst birim aranır;
//   listede yalnızca üst birim varsa o seçilir. Tanı raporu gerçek sürümü yazar.
// v3.6.7: LoV seçimlerinde (Gereği / Kaldırılacak Klasörler) sonuç listesi oturana ve AJAX bitene kadar beklenir, tıklama kayıt olmazsa yeniden denenir (yavaş bağlantı);
//   klasör sonucu "lovItemTitle" öğesi olarak da tanınır (tanı raporundaki gerçek yapıya göre).
// v3.6.6: Cevap Yaz → Kaldırılacak Klasörler konu koduyla BİREBİR aynı kodla doldurulur ve doğrulanır; Gereği "Direkt Gönder" uyarısı ortak izleyiciyle yakalanır;
//   başarısız olursa ekranda kopyalanabilir TANI RAPORU çıkar; şablonlarda (isim) ve (tc) evrak metninden otomatik doldurulur.
// v3.6.5: (1) Gereği uyarısında "Direkt Gönder" daha sağlam yakalanır (uzun yazım / iki düğmeli uyarıda sağdaki düğme); (2) Cevap Yaz → "Kaldırılacak Klasörler" konu kodundan otomatik doldurulur;
//   (3) Tekrarlı (günlü) kurallara "… tarihine kadar" bitiş tarihi eklendi (yazıdan tanınır + elle girilebilir; bitişten sonra tarih üretilmez).
// v3.6.4: Direkt Gönder uyarısı izleyiciyle (gecikmeli de) yakalanır; öğrenilen şablon adları önek/kişi adı olmadan (🎓 işaretli); taramada evrak içi de okunur (günlü evrakları eksiksiz bulur);
//   panel daraltıldı (372px) ve yeni görünüm (gradyan başlık, yapışkan sekmeler, hover/odak efektleri, ince kaydırma çubuğu).
// v3.6.4: Gereği seçilince çıkan dağıtım uyarısında "Direkt Gönder" otomatik seçilir; Otonom konuya uyan şablonu (kendi/öğrenilen/hazır) yazar;
//   günlü evrak: "15 (on beş) gün", "bir hafta/ay içinde", "20 Ekim'e kadar", "Ekim ayı sonuna kadar", "A - B tarihleri arasında" tanınır.
// v3.6.4: Cevap Yaz → Gereği alanına evrakın geldiği yer otomatik seçilir; dönemsel kural (3/6 aylık, "3. dönem (mart-nisan-mayıs)") + dönem sonuna 10 gün kala ön hatırlatma.
// v3.6.4: tekrarlı yazı kuralı ("her ayın 5, 10, 20'si", "ilk/son iş günü", "ay sonu", "her cuma"); havale menüsü bulma/açma sağlamlaştırıldı
//   (çerçeveler, daraltılmış menü, harf duyarsız eşleşme, nedenin ekranda gösterilmesi); gizlilik onayı sürümü setup/takvim/arka planla eşitlendi.
// v3.6.4: 🎓 Parafladıklarımdan şablon öğrenme (geçmiş cevap yazıları bu bilgisayarda çözümlenir, aday şablonlar kullanıcı onayıyla eklenir);
//   hazır resmî yazı şablonları 15 → 57; kartta ⭐ önerilen şablonlar ve şablon arama kutusu. Önceki özelliklerin hiçbiri değiştirilmedi.
// v3.5.2: havale Hızlı Seçim'de seçimlerin uygulanmaması düzeltildi (tablo her tıklamada yenileniyor); başka EBYS ekranından tarama;
//   🤖 tam otomatik havale sırası (form doldurulur, gönderme kullanıcıda) + havale günlüğü; 📗 Excel (.xlsx) + kısa içerik.
// v3.5.1: taramada EBYS 'Miat' bilgisi olan günlü evraklar otomatik takibe alınır (evrak açılmadan); yazıdaki son tarih okuma genişletildi
//   (Türkçe ay adları her yazımla, 'en geç/en son', '… tarihine kadar/dek', '…'e kadar', '… tarihinden önce'; birden çok tarih → en yakın gelecekteki,
//   diğerleri nota; evrak tarihinden önceki tarihler sayılmaz); 'AÇ ➔' ile açılan evrakın son tarihi de okunur; ayar etiketleri okunur renkte.
// v3.5: 📅 Günlü Evrak Takibi — son tarihi belirlenen evraklar (Nitelik/Otonom) en az bilgiyle (evrak sayısı, konu, gönderen, son tarih,
//   ilk görülme, durum, not) takip listesine alınır (otomatik + 'Geri al' ya da elle 'Takibe al'); iş günü geri sayımı; Excel (CSV) ve takvim (.ics)
//   indirme; masaüstü hatırlatmalarını arka plan hizmet çalışanı (background.js: chrome.alarms + chrome.notifications) gösterir.
// v3.4: ⚙️ Havale Kuralları — kullanıcının tanımladığı (ya da görev dağılımı PDF'inden önerilip onayladığı) anahtar kelime kurallarıyla
//   evrak konusu/gönderen (ve istenirse 📖 evrak metni) üzerinden Gereği önerisi; 'her evrakta Bilgi' listesi; 'Neden?' açıklaması.
//   Öneri yalnızca ön seçimdir; v3.3 onay + Tamam sonrası doğrulama aynen geçerli. Kodda kişi adı / okula özgü kural yoktur.
// v3.3: 📨 Havale sekmesi — Birim Evrakları > Teslim Alınmayı Bekleyenler taranır; seçilen evrak için 'Teslim Al ve Havale Et' →
//   'Kişiye Havale - Hızlı Seçim' penceresinde kişiler + Gereği/Bilgi seçilir; Tamam ve Teslim Al Gönder YALNIZCA kullanıcı onayından sonra.
//   Kurum kişi listesi (ad soyad + unvan) yalnızca bu bilgisayarda (chrome.storage.local) önbelleğe alınır; toplu/otomatik havale yoktur.
// v3.2.1: gizlilik politikası adresi eklendi; ürün adı kullanıcıya görünen her yerde "Evrak Asistanı" (iç anahtarlar, mesaj türleri ve [EBYS] konsol öneki aynı).
// v3.2: İlk çalıştırma gizlilik onayı (Chrome Web Mağazası politikası); tüm kalıcı veriler chrome.storage.local'da (sayfanın localStorage'ı kullanılmaz,
//   eski ebys_* anahtarları bir kez taşınıp silinir; idareci listesi TAŞINMAZ, boş başlar); "Gizlilik / Verilerimi sil".
// v3.2: WhatsApp mesajı en aza indirildi (veri minimizasyonu): yalnızca konu + "EBYS'yi kontrol ediniz" bilgi notu (son tarih biliniyorsa tarih ve kalan gün).
// v3.1: WhatsApp gönderimi tıklama anında tam URL ile açılır (boş sekme yok); panel teması biraz açıldı; robot simgesi aşağı alındı, yazısız.
// v3: gerçek EBYS (Belgenet, ebys.meb.gov.tr/edys-web) işaretlemesine göre yeniden hedeflendi —
//   tarama yalnızca "İşlem Bekleyenler > Gelen Evraklar" (menü sayısı ile doğrulama), satır açma (data-rk + seçilebilir hücre),
//   pdf.js önizleme metni (sayfa dünyası köprüsü bridge.js ya da metin katmanı), "Evrak Ekleri" tablosu, "Evrak Kapatma" paneli,
//   Cevap Yaz → Editör düğmesi → "Evrak Editör" CKEditor'u; toplu kapatma kaldırıldı; Tanılama; günlü evrak geri sayımı.
/* global chrome */
(function() {
    'use strict';

    // NEW (v3.2): Gizlilik politikası adresi — yayımlamadan önce gerçek https:// adresiyle değiştirin
    const EBYS_PRIVACY_POLICY_URL = "https://otonomevrak.com/evrak/gizlilik";
    const EBYS_POLICY_VERSION = "2026-10-19a"; // politika metni değişirse artırın → onay yeniden istenir

    // NEW: aynı pencerede ikinci kez yüklenmeye karşı koruma (çift panel / çift dinleyici / çift zamanlayıcı olmasın)
    if (window.__ebysOtonomCoreLoaded) return;
    window.__ebysOtonomCoreLoaded = true;
    // v3.6.44: açılır pencere yok — tüm alert() uyarıları sayfayı kilitlemeyen alt bildirim olarak gösterilir
    const alert = (m) => { try { const t = String(m == null ? "" : m); showToast(t, /^\s*(✅|✔️|🤖)/.test(t) ? "ok" : "warn"); } catch(e) { try { console.warn("[Evrak Asistanı]", m); } catch(x) {} } };

    // =========================================================================
    // NEW (v3.2): UZANTI DEPOLAMASI (chrome.storage.local) + bellek önbelleği
    // Tüm kalıcı veriler yalnızca bu bilgisayarda, uzantının kendi deposunda tutulur; sayfanın (meb.gov.tr) localStorage'ı kullanılmaz.
    // Okumalar eşzamanlıdır (önbellek, başlangıçta bir kez doldurulur); yazmalar önbelleğe + chrome.storage.local'a gider.
    // =========================================================================
    const EXT_CONSENT_KEY = "ebys_consent_v1";
    const EXT_MIGRATED_KEY = "ebys_ls_migrated_v1";
    const EXT_LEGACY_STAFF_KEY = "ebys_admin_staff_v1"; // eski (sayfa localStorage) idareci listesi: ASLA taşınmaz, silinir
    const EXT_MIGRATE_KEYS = ["ebys_reply_templates_v2", "ebys_hidden_builtin_tpl_v1", "ebys_macro_records_v1", "ebys_last_scan_v1", "ebys_deadlines_v1", "ebys_settings_v1"];
    const EXT_IS_TOP = window.self === window.top;
    const extStorage = (() => { try { return (typeof chrome !== "undefined" && chrome && chrome.storage && chrome.storage.local) ? chrome.storage.local : null; } catch(e) { return null; } })();
    const extCache = Object.create(null);
    const extClone = v => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));
    function extHasConsent() {
        const c = extCache[EXT_CONSENT_KEY];
        return !!(c && c.accepted === true && c.version === EBYS_POLICY_VERSION);
    }
    function extStoreGet(key) { return extClone(extCache[key]); }
    function extStoreSet(key, value) {
        extCache[key] = extClone(value);
        if (key !== EXT_CONSENT_KEY && !extHasConsent()) return Promise.resolve(); // onay yoksa kalıcı yazma yapılmaz
        if (!extStorage) return Promise.resolve();
        try {
            return Promise.resolve(extStorage.set({ [key]: extCache[key] })).catch(e => console.warn("[Evrak Asistanı] Depoya yazılamadı:", key, e));
        } catch(e) { console.warn("[Evrak Asistanı] Depoya yazılamadı:", key, e); return Promise.resolve(); }
    }
    function extStoreLoadAll() {
        if (!extStorage) return Promise.resolve({});
        try { return Promise.resolve(extStorage.get(null)).then(r => r || {}, () => ({})); } catch(e) { return Promise.resolve({}); }
    }
    function extLegacyKeys() {
        const out = [];
        try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && /^ebys_/.test(k)) out.push(k); } } catch(e) {}
        return out;
    }
    // Tek seferlik taşıma: şablonlar, gizlenen hazır şablonlar, makrolar, son tarama, son tarihler, ayarlar → chrome.storage.local;
    // ardından sayfa localStorage'ındaki TÜM ebys_* anahtarları silinir. İdareci listesi taşınmaz (boş başlar).
    async function extMigrateLegacyLocalStorage() {
        if (!EXT_IS_TOP) return;
        const toSet = {};
        if (!extCache[EXT_MIGRATED_KEY]) {
            EXT_MIGRATE_KEYS.forEach(k => {
                let raw = null;
                try { raw = localStorage.getItem(k); } catch(e) {}
                if (raw === null || extCache[k] !== undefined) return;
                try { const v = JSON.parse(raw); if (v !== null && typeof v === "object") toSet[k] = v; } catch(e) {}
            });
            toSet[EXT_MIGRATED_KEY] = { at: new Date().toISOString(), keys: Object.keys(toSet) };
        }
        if (Object.keys(toSet).length) {
            Object.keys(toSet).forEach(k => { extCache[k] = extClone(toSet[k]); });
            try { if (extStorage) await extStorage.set(toSet); }
            catch(e) { console.warn("[Evrak Asistanı] Eski veriler taşınamadı (silinmedi):", e); return; }
        }
        extLegacyKeys().forEach(k => { try { localStorage.removeItem(k); } catch(e) {} });
    }
    // NEW (v3.2): "Tüm verilerimi sil" — uzantı deposu tamamen temizlenir (onay kaydı dahil), artık eski anahtarlar da silinir
    async function extDeleteAllData() {
        Object.keys(extCache).forEach(k => delete extCache[k]);
        try { if (extStorage) await extStorage.clear(); } catch(e) { console.warn("[Evrak Asistanı] Depo temizlenemedi:", e); }
        extLegacyKeys().forEach(k => { try { localStorage.removeItem(k); } catch(e) {} });
    }

    // =========================================================================
    // NEW (v3.2): İLK ÇALIŞTIRMA GİZLİLİK ONAYI — onay verilmeden hiçbir özellik (tarama, açma, nitelik, otonom, kapatma, WhatsApp,
    // kalıcı yazma) çalışmaz; yalnızca robot simgesi görünür, tıklanınca onay ekranı yeniden açılır.
    // =========================================================================
    const EXT_PRIVACY_POINTS = [
        "Eklenti yalnızca <b>ebys.meb.gov.tr</b> adresindeki EBYS sayfalarında çalışır. Sizin açtığınız ekrandaki evrak listesini, evrak önizleme metnini ve ek listesini <b>okur</b>. Tarama ve nitelik işlemlerini yalnızca siz başlattığınızda yapar.",
        "Bu paket <b>salt okunur</b>dur. Eklenti EBYS'de hiçbir evrakı <b>kaydetmez, göndermez, imzalamaz, paraflamaz, havale etmez ve cevap yazmaz</b>. Otomatik Kaydet yoktur.",
        "Kaydedilen bilgiler (son tarama listeleri, son tarihler, günlü evrak takip listesi, bildirim ayarları) <b>yalnızca bu bilgisayarda</b>, tarayıcının uzantı deposunda tutulur. Buluta veya başka bir sunucuya <b>hiçbir veri gönderilmez</b>.",
        "📅 Günlü evrak takibi: son tarihi belirlenen evrakların yalnızca <b>evrak sayısı, konusu, gönderen birim (kısa), son tarihi, ilk görülme tarihi, durumu ve sizin notunuz</b> takip listesinde <b>bu bilgisayarda</b> saklanır; evrak metni ve ekler saklanmaz. Takibe alma otomatik (geri alınabilir) ya da isteğe bağlı olarak yalnızca elle yapılır.",
        "🔔 Masaüstü bildirimleri: Chrome açıkken (EBYS sekmesi açık olmasa da) eklentinin arka plan hizmeti takip listesini <b>bu bilgisayarda</b> kontrol eder ve son tarihi yaklaşan/geçen evraklar için Windows/Chrome bildirimi gösterir. Bildirimde yalnızca <b>konu, son tarih ve evrak sayısı</b> bulunur; hiçbir yere gönderilmez. Bildirimleri ayarlardan kapatabilirsiniz.",
        "📊 Excel (.csv) ve 📆 takvim (.ics) dosyaları yalnızca siz düğmeye bastığınızda <b>bu bilgisayara indirilir</b>; bu dosyaları nerede sakladığınız ve kiminle paylaştığınız sizin sorumluluğunuzdadır.",
        "Evrak Asistanı, EBYS kullanıcıları için hazırlanmış bağımsız bir yardımcıdır; <b>resmî bir MEB ürünü değildir</b>. © Eyüp ŞEKER.",
        "📱 Telefon Rehberi ve WhatsApp ile paylaşım: kişi adları ve telefon numaraları <b>yalnızca bu bilgisayarda</b> tutulur; buluta veya başka bir sunucuya gönderilmez. WhatsApp mesajı <b>otomatik gönderilmez</b>; siz kişiyi veya numarayı seçer, metni düzenler ve WhatsApp'ta Gönder'e basarsınız. Evrak PDF'i varsa yalnızca bu bilgisayara indirilir veya cihazın paylaş menüsüyle gönderilir; eklenti dosyayı hiçbir yere yüklemez.",
        "Verilerinizi istediğiniz zaman paneldeki <b>🔒 Gizlilik / Verilerimi sil</b> bölümünden silebilirsiniz."
    ];
    function extPolicyLinkHtml() {
        const u = String(EBYS_PRIVACY_POLICY_URL);
        const safe = u.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
        return /^https:\/\//i.test(u)
            ? '<a class="ebys-policy-link" href="' + safe + '" target="_blank" rel="noopener noreferrer" style="color:#38BDF8;">Gizlilik Politikası</a>'
            : '<span class="ebys-policy-link" style="color:#38BDF8;">Gizlilik Politikası: ' + safe + '</span>';
    }
    function extPrivacyListHtml() {
        return '<ul style="margin:0 0 10px 0; padding-left:18px; display:flex; flex-direction:column; gap:6px;">' + EXT_PRIVACY_POINTS.map(p => "<li>" + p + "</li>").join("") + "</ul>";
    }
    let extMainStarted = false;
    let extMainFn = null;
    function extStartMain() {
        if (extMainStarted || !extMainFn) return;
        extMainStarted = true;
        document.querySelectorAll("#ebys-consent-handle, #ebys-consent-modal").forEach(el => el.remove());
        try { extMainFn(); } catch(e) { console.error("[Evrak Asistanı] Başlatılamadı:", e); }
    }
    let extConsentHealId = null;
    function extCreateConsentHandle() {
        if (!document.body || extMainStarted || document.getElementById("ebys-consent-handle")) return;
        const h = document.createElement("div");
        h.id = "ebys-consent-handle";
        h.innerHTML = '<div style="font-size: 20px; line-height: 1;">🤖</div>';
        h.title = "Evrak Asistanı — kullanmak için gizlilik onayı gerekli";
        h.setAttribute("role", "button");
        h.setAttribute("aria-label", "Evrak Asistanı gizlilik onayını aç");
        h.style.cssText = "position: fixed !important; right: 0px !important; top: 72% !important; transform: translateY(-50%) !important; background: #1F2D4D !important; color: white !important; padding: 10px 8px !important; border-radius: 16px 0 0 16px !important; cursor: pointer !important; z-index: 2147483647 !important; border: 1.5px solid #00F0FF !important; border-right: none !important; opacity: 0.85 !important;";
        h.onclick = extShowConsentModal;
        document.body.appendChild(h);
        if (!extConsentHealId) extConsentHealId = setInterval(() => { if (extMainStarted) { clearInterval(extConsentHealId); extConsentHealId = null; return; } extCreateConsentHandle(); }, 2000);
    }
    function extShowConsentModal() {
        if (!document.body || extMainStarted) return;
        document.querySelectorAll("#ebys-consent-modal").forEach(el => el.remove());
        const m = document.createElement("div");
        m.id = "ebys-consent-modal";
        m.setAttribute("role", "dialog");
        m.setAttribute("aria-modal", "true");
        m.style.cssText = "position:fixed !important; inset:0 !important; background:rgba(0,0,0,0.55) !important; z-index:2147483647 !important; display:flex !important; align-items:center; justify-content:center; font-family:'Segoe UI', Tahoma, sans-serif;";
        m.innerHTML = '<div style="width:min(560px, 92vw); max-height:88vh; overflow-y:auto; background:#1F2D4D; color:#E2E8F0; border:1.5px solid #00F0FF; border-radius:16px; padding:18px; font-size:12.5px; line-height:1.5; box-shadow:0 10px 40px rgba(0,0,0,0.5);">'
            + '<div style="font-weight:800; color:#00F0FF; font-size:15px; margin-bottom:10px;">🔒 Evrak Asistanı — Gizlilik ve Kullanım Onayı</div>'
            + '<div style="margin-bottom:8px;">Eklentiyi kullanmaya başlamadan önce lütfen okuyun:</div>'
            + extPrivacyListHtml()
            + '<div style="margin-bottom:14px;">' + extPolicyLinkHtml() + '</div>'
            + '<div style="display:flex; gap:8px; justify-content:flex-end;">'
            + '<button id="ebys-consent-decline" style="background:#2D3D63; color:#E2E8F0; border:1px solid #A9B6CA; padding:8px 14px; border-radius:10px; font-weight:bold; cursor:pointer;">Kabul etmiyorum</button>'
            + '<button id="ebys-consent-accept" style="background:#15803D; color:white; border:none; padding:8px 14px; border-radius:10px; font-weight:bold; cursor:pointer;">Kabul ediyorum</button>'
            + "</div></div>";
        document.body.appendChild(m);
        m.querySelector("#ebys-consent-accept").onclick = async () => {
            m.remove();
            await extStoreSet(EXT_CONSENT_KEY, { accepted: true, version: EBYS_POLICY_VERSION, at: new Date().toISOString() });
            await extMigrateLegacyLocalStorage();
            extStartMain();
        };
        m.querySelector("#ebys-consent-decline").onclick = async () => {
            m.remove();
            await extStoreSet(EXT_CONSENT_KEY, { accepted: false, version: EBYS_POLICY_VERSION, at: new Date().toISOString() });
            extCreateConsentHandle();
        };
    }
    function extWhenBody(fn) {
        if (document.body) fn();
        else document.addEventListener("DOMContentLoaded", fn, { once: true });
    }
    async function extBootstrap(mainFn) {
        extMainFn = mainFn;
        // Eski idareci listesi (v1'in sabit varsayılan kişileri dahil) hiçbir koşulda taşınmaz/okunmaz: hemen silinir
        if (EXT_IS_TOP) { try { localStorage.removeItem(EXT_LEGACY_STAFF_KEY); } catch(e) {} }
        const all = await extStoreLoadAll();
        Object.keys(all).forEach(k => { extCache[k] = all[k]; });
        try {
            if (extStorage && chrome.storage.onChanged) chrome.storage.onChanged.addListener((changes, area) => {
                if (area && area !== "local") return;
                Object.keys(changes).forEach(k => { if (changes[k] && "newValue" in changes[k]) extCache[k] = extClone(changes[k].newValue); else delete extCache[k]; });
                if (extHasConsent() && !extMainStarted) {
                    if (EXT_IS_TOP) extMigrateLegacyLocalStorage().then(() => extWhenBody(extStartMain));
                    else extStartMain();
                }
            });
        } catch(e) {}
        if (extHasConsent()) {
            await extMigrateLegacyLocalStorage();
            extStartMain();
            return;
        }
        if (!EXT_IS_TOP) return; // alt çerçeveler onay gelene kadar bekler (onChanged)
        extWhenBody(() => {
            if (extMainStarted) return;
            extCreateConsentHandle();
            const c = extCache[EXT_CONSENT_KEY];
            const declinedThisVersion = c && c.accepted === false && c.version === EBYS_POLICY_VERSION;
            if (!declinedThisVersion) extShowConsentModal(); // ilk çalıştırmada (ya da politika değiştiyse) kendiliğinden açılır
        });
    }
    extBootstrap(ebysMain);

    function ebysMain() {

    // =========================================================================
    // YARDIMCI FONKSİYONLAR
    // =========================================================================
    function getAllDocs() {
        const docs = [document];
        // FIX: iç içe (nested) aynı-origin çerçeveler de toplanır; açma/kapatma artık yalnızca üst pencerede yürütülür
        const collect = (d, depth) => {
            if (depth > 4) return;
            try {
                d.querySelectorAll("iframe, frame").forEach(f => {
                    try {
                        const cd = f.contentDocument;
                        if (cd && !docs.includes(cd)) { docs.push(cd); collect(cd, depth + 1); }
                    } catch(e) {}
                });
            } catch(e) {}
        };
        collect(document, 0);
        return docs;
    }

    function broadcastMsg(msgObj) {
        // FIX: her mesaja tekil kimlik (alıcı aynı mesajı iki kez işlemez); hedef yalnızca aynı origin ("/")
        if (!msgObj.msgId) msgObj.msgId = "m" + Date.now() + "_" + Math.random().toString(36).slice(2);
        try { window.postMessage(msgObj, "/"); } catch(e) {}
        try {
            document.querySelectorAll("iframe, frame").forEach(f => {
                try { if (f.contentWindow) f.contentWindow.postMessage(msgObj, "/"); } catch(e) {}
            });
        } catch(e) {}
    }

    // FIX: yalnızca aynı-origin kaynaktan gelen mesajlar kabul edilir
    function isTrustedMessage(e) {
        if (!e || !e.data || typeof e.data !== "object") return false;
        if (!e.source || e.origin !== window.location.origin) return false;
        return true;
    }
    const handledMsgIds = new Set();

    // FIX: HTML kaçışı — evrak/personel/şablon metni innerHTML'e güvenli eklenir
    function escapeHtml(s) {
        return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    }

    // FIX: görünürlük kontrolü — gizli / önceden render edilmiş diyalog ve düğmeler elenir
    function isVisibleOuter(el) { return isVisible(el); } // v3.6.37: yerel gölgeleme için takma ad
    function isVisible(el) {
        try {
            if (!el || !el.getClientRects || el.getClientRects().length === 0) return false;
            const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el);
            return cs.visibility !== "hidden" && cs.display !== "none";
        } catch(e) { return false; }
    }

    // FIX: güvenli okuma — bozuk / "null" / yanlış tipte kayıt varsayılana döner (v3.2: kaynak chrome.storage.local önbelleği)
    const isPlainObject = v => v !== null && typeof v === "object" && !Array.isArray(v);
    const isValidStaff = v => Array.isArray(v) && v.every(s => isPlainObject(s) && typeof s.name === "string" && (typeof s.phone === "string" || typeof s.phone === "number"));
    const isValidTemplates = v => isPlainObject(v) && Object.values(v).every(x => typeof x === "string");
    const isValidMacros = v => isPlainObject(v) && Object.values(v).every(m => isPlainObject(m) && Array.isArray(m.steps));
    function loadJSON(key, defaultValue, isValid) {
        try {
            const v = extStoreGet(key); // CHANGE (v3.2)
            if (v === undefined) return JSON.parse(JSON.stringify(defaultValue));
            if (isValid(v)) return v;
        } catch(e) {}
        console.warn("[Evrak Asistanı] Geçersiz kayıt, varsayılan kullanılıyor:", key);
        return JSON.parse(JSON.stringify(defaultValue));
    }

    // FIX: sayfalama sabitleri (tarama sınırı ve evrak arama sınırı)
    // NEW: tüm sayfalar taranır; güvenlik sınırı 50 sayfa (window.__EBYS_MAX_SCAN_PAGES ile değiştirilebilir)
    const MAX_SCAN_PAGES = Math.max(1, Number(window.__EBYS_MAX_SCAN_PAGES) || 50);
    const MAX_OPEN_PAGES = MAX_SCAN_PAGES;
    const AJAX_TIMEOUT_MS = 10000;      // NEW: AJAX sayfa yenilemesi için azami bekleme
    const PREVIEW_TIMEOUT_MS = 4000;    // NEW: açılan evrakın önizlemesi için azami bekleme
    const REPLY_FORM_DELAY_MS = 1200;   // NEW: "Cevap Yaz" sonrası formun gelmesi için asgari bekleme
    const TEMPLATE_BLANK = "........";  // NEW: okunamayan şablon değişkeni yerine konan boşluk

    function setNativeValue(element, value) {
        try { element.focus(); } catch(e) {}
        try { if (element.select) element.select(); } catch(e) {}
        try {
            const proto = Object.getPrototypeOf(element);
            const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
            if (setter) setter.call(element, value);
            else element.value = value;
        } catch(e) { try { element.value = value; } catch(e2) {} }
        if (element.value !== value) {
            try { element.focus(); element.select(); document.execCommand('selectAll', false, null); document.execCommand('insertText', false, value); } catch(e) {}
        }
        if (element.value !== value) { try { element.value = value; } catch(e) {} }
        ['input', 'change'].forEach(evtName => {
            try { element.dispatchEvent(new Event(evtName, { bubbles: true, cancelable: true })); } catch(e) {}
        });
        return element.value;
    }

    // =========================================================================
    // 1. İDARECİ REHBERİ
    // =========================================================================
    // CHANGE (v3.2): idareci listesi BOŞ başlar ve yalnızca uzantı deposunda (yeni anahtar) tutulur; eski sayfa kaydı (ebys_admin_staff_v1) taşınmaz
    const STAFF_KEY = "ebys_admin_staff_v2";
    let adminStaff = loadJSON(STAFF_KEY, [], isValidStaff); // FIX: güvenli yükleme
    function saveStaffToStorage() { extStoreSet(STAFF_KEY, adminStaff); }

    // =========================================================================
    // 2. GENİŞLETİLMİŞ RESMÎ YAZIŞMA ŞABLONLARI
    // =========================================================================
    // NEW: 15 hazır resmî cevap şablonu (MEB resmî yazışma üslubu). Koddan gelir; silinmez, gizlenip geri alınabilir.
    // Değişkenler: {konu} {sayı} {tarih} {gönderen} — {sayi} / {gonderen} yazımı da kabul edilir; {bugün} = bugünün tarihi
    // v3.6.30: PROFESYONEL RESMÎ YAZI ŞABLONLARI — Resmî Yazışmalarda Uygulanacak Usul ve Esaslar Hakkında Yönetmelik (2020) düzenine göre
    // yeniden yazıldı: "İlgi:" satırı (a/b), kısa gövde, "Ek/Ekler" yer tutucusu ve YÖNE GÖRE KAPANIŞ. {kapanış:tür} belirteci yazı yönüne göre çözülür:
    //   bilgi → üst: "Bilgilerinize arz ederim." / alt-eşit: "Bilgilerinizi rica ederim."; gereg → "Bilgilerinizi ve gereğini arz|rica ederim.";
    //   gerek → "Gereğini arz|rica ederim."; gerek2 → "gereğini arz|rica ederim." (cümle içi); rica → "arz|rica ederim." (cümle içi);
    //   olurtalep → her zaman "olurlarınıza arz ederim." (olur yalnızca üst makamdan istenir).
    // Yön: ayar (Otomatik/Üst/Alt/Eşit) → şablonun varsayılan yönü (ör. tebliğler "alt") → gönderenden tahmin (Bakanlık/Valilik/Kaymakamlık/İl-İlçe MEM → üst; okul → eşit) → üst.
    // Değişkenler: {konu} {sayı} {tarih} {gönderen} — {sayi} / {gonderen} yazımı da kabul edilir; {bugün} = bugünün tarihi
    const BUILTIN_TEMPLATES = {"Standart Bilgi Verme": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile bildirilen {konu} konusu {kurumumuzca} incelenmiş olup gereği yapılmıştır.\n\n{kapanış:bilgi}", "Uygun Görülmedi / Olumsuz": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile talep edilen {konu} hususu {kurumumuzca} değerlendirilmiş, ........ nedeniyle uygun görülmemiştir.\n\n{kapanış:bilgi}", "Komisyon / İnceleme Raporu": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı gereğince oluşturulan komisyon tarafından {konu} hakkında yapılan inceleme sonucunda düzenlenen rapor ekte sunulmuştur.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "Malzeme / Demirbaş Talep": "{kurumumuzda} kullanılmak üzere ihtiyaç duyulan {konu} ile ilgili malzeme listesi ekte sunulmuştur.\n\nSöz konusu malzemelerin temini hususunda {kapanış:gerek2}\n\nEk: ........ (... sayfa)", "Süre Uzatımı Talebi": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile istenen {konu} konusundaki çalışmalar devam etmekte olup ........ nedeniyle belirtilen sürede tamamlanamayacaktır. Söz konusu işlemler için ........ tarihine kadar ek süre verilmesi hususunu {kapanış:olurtalep}", "Görevlendirme / Olur": "İlgi: a) {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n      b) Makam Oluru (........ tarihli).\n\nİlgi (a) yazı ve ilgi (b) Olur gereğince {konu} kapsamında görevlendirilen personelin listesi ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEk: ........ (... sayfa)", "İstenen Bilgi ve Belgelerin Gönderilmesi": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile istenen {konu} konulu bilgi ve belgeler hazırlanarak ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEk: ........ (... sayfa)", "Faaliyet / Etkinlik Raporu": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı gereğince {konu} kapsamında {kurumumuzda} gerçekleştirilen faaliyetlere ilişkin rapor ve görseller ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEkler:\n1- ........\n2- ........", "Olumsuz Bildirim (Durum Bulunmamaktadır)": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile bildirilmesi istenen {konu} konusunda {kurumumuzda} bildirilecek herhangi bir durum bulunmamaktadır.\n\n{kapanış:bilgi}", "Duyuru ve Tebliğ Yapıldı": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\n{konu} konulu ilgi yazı {kurumAdi} personeline duyurulmuş ve tebliğ edilmiştir. Tebliğ-tebellüğ listesi ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEk: ........ (... sayfa)", "Eksik Evrakın Tamamlanması": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile eksikliği bildirilen {konu} konulu belgeler tamamlanarak ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEkler:\n1- ........\n2- ........", "Toplantı / Eğitime Katılım Bildirimi": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile duyurulan {konu} konulu toplantıya/eğitime {kurumumuzu} temsilen katılacak personelin bilgileri ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEk: ........ (... sayfa)", "Ödenek Talebi": "{kurumumuzun} {konu} kapsamındaki ihtiyaçlarının karşılanabilmesi için hazırlanan ihtiyaç listesi ve yaklaşık maliyet cetveli ekte sunulmuştur.\n\nGerekli ödeneğin gönderilmesi hususunda {kapanış:gerek2}\n\nEkler:\n1- ........\n2- ........", "Bakım-Onarım İhtiyacı Bildirimi": "{kurumAdi} binasında {konu} ile ilgili yapılan incelemede bakım-onarım ihtiyacı tespit edilmiştir. Tespit tutanağı ve fotoğraflar ekte sunulmuştur.\n\n{kapanış:gerek}\n\nEkler:\n1- ........\n2- ........", "Personel Bilgilerinin Bildirilmesi": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı gereğince {konu} kapsamında istenen personel bilgileri belirtilen formata işlenerek ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEk: ........ (... sayfa)", "Bilgi / Belge İstenmesi (Eksik Bilgi)": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile iletilen {konu} konusunun değerlendirilebilmesi için aşağıda belirtilen bilgi ve belgelerin ........ tarihine kadar {kurumumuza} gönderilmesi gerekmektedir.\n\n1- ........\n2- ........\n\n{kapanış:gerek}", "Yazının İlgisi Olmadığı / İade": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile gönderilen {konu} konulu evrak {kurumumuzun} görev alanına girmediğinden iade edilmiştir.\n\n{kapanış:bilgi}", "Web Sitesinde Yayımlandı / Panoda Duyuruldu": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\n{konu} konulu ilgi yazı {kurumumuzun} internet sitesinde yayımlanmış ve okul duyuru panosunda ilan edilmiştir.\n\n{kapanış:bilgi}", "Öğrenci ve Velilere Duyuruldu": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\n{konu} konulu ilgi yazı {kurumAdi} öğrencilerine ve velilerine duyurulmuş, gerekli bilgilendirme yapılmıştır.\n\n{kapanış:bilgi}", "Hizmet İçi Eğitim Katılım Bildirimi": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile duyurulan {konu} hizmet içi eğitim faaliyetine katılması uygun görülen personelin listesi ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEk: ........ (... sayfa)", "Olay Bildirimi (Tutanak ve Rapor)": "{kurumumuzda} ........ tarihinde saat ........ sıralarında {konu} ile ilgili bir olay meydana gelmiştir. Olaya ilişkin tutanak ve rapor ekte sunulmuştur.\n\n{kapanış:gereg}\n\nEkler:\n1- ........\n2- ........", "Denetim / Rehberlik Bulgularının Giderildiği": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile bildirilen {konu} konusundaki bulgular giderilmiş olup yapılan işlemlere ilişkin belgeler ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEkler:\n1- ........\n2- ........", "Öğrenci Disiplin Kurulu Kararı Bildirimi": "{kurumAdi} öğrencisi ........ hakkında {konu} nedeniyle toplanan Öğrenci Davranışlarını Değerlendirme Kurulunun ........ tarihli ve ........ sayılı kararı ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEk: ........ (... sayfa)", "Öğrenci Nakil / Kayıt Bildirimi": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile bildirilen {konu} konusundaki öğrencinin nakil/kayıt işlemleri tamamlanmıştır.\n\n{kapanış:bilgi}", "Göreve Başlama Yazısı": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile {kurumumuza} atanan ........ branşı öğretmeni ........ ........ tarihinde görevine başlamıştır.\n\n{kapanış:bilgi}", "Görevden Ayrılma Yazısı": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\n{kurumumuzda} görev yapan ........ branşı öğretmeni ........, ilgi yazı gereğince ........ tarihinde görevinden ayrılmıştır.\n\n{kapanış:bilgi}", "Ücretli Öğretmen Göreve Başlama": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile {kurumumuzda} ek ders ücreti karşılığında görevlendirilen ........ branşı ücretli öğretmen ........ ........ tarihinde görevine başlamıştır.\n\n{kapanış:bilgi}", "Ücretli Öğretmen Görevden Ayrılma": "{kurumumuzda} ek ders ücreti karşılığında görev yapan ........ branşı ücretli öğretmen ........ ........ tarihi itibarıyla görevinden ayrılmıştır.\n\n{kapanış:bilgi}", "İUP / TYP Personeli Göreve Başlama": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı kapsamında {kurumumuzda} görevlendirilen ........ ........ tarihinde göreve başlamıştır.\n\n{kapanış:bilgi}", "Personel İzin Onayı Bildirimi": "{kurumumuzda} görev yapan ........ ........ tarihleri arasında ........ gün ........ izin kullanacaktır. İzin onayı ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEk: ........ (... sayfa)", "Aylıksız İzin Dilekçesi Gönderme": "{kurumumuzda} görev yapan ........ ........ nedeniyle ........ tarihinden itibaren aylıksız izin talep etmektedir. İlgilinin dilekçesi ve ekleri ekte sunulmuştur.\n\n{kapanış:gereg}\n\nEkler:\n1- ........\n2- ........", "Derece-Kademe İlerlemesi (Terfi)": "{kurumumuzda} görev yapan ........ ........ tarihi itibarıyla kademe/derece ilerlemesine hak kazanmıştır. İlgiliye ait hizmet belgesi ekte sunulmuştur.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "Öğretmen İhtiyacı Bildirimi": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\n{kurumumuzun} {konu} kapsamındaki öğretmen ihtiyacı branşlar itibarıyla ekteki çizelgede gösterilmiştir.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "Ek Ders Puantajı Gönderme": "{kurumumuzda} görev yapan öğretmenlerin ........ ayına ait ek ders puantaj çizelgeleri ekte sunulmuştur.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "Toplu Ücret Onayı (Ek Ders Olur)": "{kurumumuzda} ........ eğitim-öğretim yılında ek ders ücreti karşılığında görevlendirilecek personele ait çizelge ekte sunulmuştur.\n\nEk ders görevlendirmelerinin onaylanması hususunu {kapanış:olurtalep}\n\nEk: ........ (... sayfa)", "YEĞİTEK Okul Sorumlusu Görevlendirme": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı gereğince {kurumAdi} bilişim işlerini yürütmek üzere ........ branşı öğretmeni ........ okul sorumlusu olarak görevlendirilmiştir.\n\n{kapanış:bilgi}", "KBS Yetki Değişikliği": "{kurumumuzda} Kamu Harcama ve Muhasebe Bilişim Sistemi (KBS) kullanıcısı olarak görev yapan ........ yerine ........ yetkilendirilecektir. Yetki işlemlerine ilişkin form ekte sunulmuştur.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "TKYS Yetki Değişikliği": "{kurumumuzda} Taşınır Kayıt ve Yönetim Sistemi (TKYS) kullanıcısı olarak görev yapan ........ yerine ........ yetkilendirilecektir. Yetki işlemlerine ilişkin form ekte sunulmuştur.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "e-Okul Yeni Şube Açılması": "{kurumumuzda} ........ sınıf düzeyindeki öğrenci sayısındaki artış nedeniyle e-Okul sisteminde ........ şubesinin açılmasına ihtiyaç duyulmaktadır. Şube ve öğrenci mevcutlarını gösteren çizelge ekte sunulmuştur.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "Öğretmenlere Tebliğ Yazısı": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\n{konu} konulu ilgi yazı ekte gönderilmiştir. Tebliğ-tebellüğ belgesinin imzalanarak ........ tarihine kadar okul idaresine teslim edilmesini {kapanış:rica}\n\nEk: ........ (... sayfa)", "Kurul ve Komisyonlar Tebliği": "{kurumumuzda} ........ eğitim-öğretim yılında oluşturulan kurul ve komisyonlar ile görevlendirilen öğretmenlerin listesi ekte gönderilmiştir.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "Sosyal Kulüpler Tebliği": "{kurumumuzda} ........ eğitim-öğretim yılında kurulan öğrenci kulüpleri ve danışman öğretmenlerin listesi ekte gönderilmiştir.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "Sınıf Rehber Öğretmenleri Tebliği": "{kurumumuzda} ........ eğitim-öğretim yılında şubelere görevlendirilen sınıf rehber öğretmenlerinin listesi ekte gönderilmiştir.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "Belirli Gün ve Haftalar Tebliği": "{kurumumuzda} ........ eğitim-öğretim yılında kutlanacak belirli gün ve haftalar ile sorumlu öğretmenleri gösteren çizelge ekte gönderilmiştir.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "Belletici Öğretmen Görevlendirme Onayı": "{kurumAdi} pansiyonunda ........ tarihleri arasında belletici öğretmen olarak görevlendirilmesi planlanan öğretmenlerin listesi ekte sunulmuştur.\n\nGörevlendirmenin onaylanması hususunu {kapanış:olurtalep}\n\nEk: ........ (... sayfa)", "Doğrudan Temin Onay Belgesi (Olur)": "{kurumumuzun} {konu} ihtiyacının 4734 sayılı Kamu İhale Kanununun 22 nci maddesinin (d) bendi uyarınca doğrudan temin usulüyle karşılanmasına ilişkin onay belgesi ekte sunulmuştur.\n\nAlımın yapılması hususunu {kapanış:olurtalep}\n\nEk: ........ (... sayfa)", "Doğrudan Temin Komisyonu Görevlendirme": "{kurumumuzun} {konu} alımına ilişkin piyasa fiyat araştırması ile muayene ve kabul işlemlerini yürütmek üzere görevlendirilmesi planlanan personelin listesi ekte sunulmuştur.\n\nGörevlendirmenin onaylanması hususunu {kapanış:olurtalep}\n\nEk: ........ (... sayfa)", "Teklif İsteme Yazısı": "{kurumumuzun} {konu} ihtiyacı doğrudan temin usulüyle karşılanacaktır. Ekte listesi bulunan mal/hizmet için ........ tarihine kadar KDV hariç birim fiyatlı teklifinizin {kurumumuza} ulaştırılmasını {kapanış:rica}\n\nEk: ........ (... sayfa)", "Piyasa Fiyat Araştırması Bildirimi": "{kurumumuzun} {konu} alımı için görevlendirilen komisyon tarafından yapılan piyasa fiyat araştırması tutanağı ve alınan teklifler ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEkler:\n1- ........\n2- ........", "Muayene ve Kabul Tutanağı Gönderme": "{kurumumuzun} {konu} alımına ilişkin muayene ve kabul komisyonu tutanağı ile fatura ekte sunulmuştur.\n\n{kapanış:gereg}\n\nEkler:\n1- ........\n2- ........", "Fatura Ödeme Talebi": "{kurumumuza} ait ........ ayı {konu} faturası ekte sunulmuştur.\n\nFatura bedelinin ödenmesi hususunda {kapanış:gerek2}\n\nEk: ........ (... sayfa)", "OAB İhtiyaç ve Harcama Talebi": "{kurumumuzun} {konu} ihtiyacı tespit edilmiş olup ihtiyaç listesi ekte gönderilmiştir. Söz konusu ihtiyacın Okul Aile Birliği bütçesinden karşılanması hususunda {kapanış:gerek2}\n\nEk: ........ (... sayfa)", "OAB Banka Yetkilisi / İmza Sirküleri": "Okul Aile Birliğimizin ........ Şubesindeki hesabında imza yetkisi bulunan yönetim kurulu üyelerine ilişkin karar ve imza sirküleri ekte gönderilmiştir.\n\n{kapanış:gereg}\n\nEkler:\n1- ........\n2- ........", "OAB Ödeme Talimatı": "Okul Aile Birliğimizin ........ Şubesindeki ........ numaralı hesabından ........ adına ........ TL tutarında ödeme yapılmasını {kapanış:rica}\n\nEk: ........ (... sayfa)", "Gezi / Sosyal Etkinlik İzin Talebi": "{kurumAdi} öğrencilerinin katılımıyla ........ tarihinde ........ ilinde/ilçesinde düzenlenmesi planlanan {konu} etkinliğine ilişkin gezi planı, katılımcı listesi ve veli izin belgeleri ekte sunulmuştur.\n\nEtkinliğin yapılması hususunu {kapanış:olurtalep}\n\nEkler:\n1- ........\n2- ........", "Okul Sosyal Medya Hesabı Oluru": "{kurumumuzun} faaliyetlerini kamuoyuyla paylaşmak amacıyla kurumsal sosyal medya hesabı açılması ve hesabın ........ tarafından yönetilmesi planlanmaktadır.\n\nHesabın açılması hususunu {kapanış:olurtalep}", "Güvenli Okul Raporu Gönderme": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı gereğince {kurumumuzda} ........ tarihinde yapılan güvenli okul çalışmalarına ilişkin rapor ve ekleri ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEkler:\n1- ........\n2- ........", "Nöbet Çizelgesi Tebliği": "{kurumumuzda} ........ tarihinden itibaren uygulanacak öğretmen nöbet çizelgesi ekte gönderilmiştir.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "Veli Toplantısı Yapıldı Bildirimi": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı gereğince {kurumumuzda} ........ tarihinde veli toplantısı yapılmıştır. Toplantı tutanağı ve katılım listesi ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEkler:\n1- ........\n2- ........", "OAB Genel Kurul Sonuç Bildirimi": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nOkul Aile Birliğimizin ........ tarihinde yapılan genel kurul toplantısında seçilen yönetim ve denetim kurulu üyelerinin listesi ile toplantı tutanağı ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEkler:\n1- ........\n2- ........", "Sağlık Raporu Bildirimi": "{kurumumuzda} görev yapan ........, ........ tarihleri arasında ........ gün süreli sağlık raporu almıştır. Raporun bir örneği ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEk: ........ (... sayfa)", "Emeklilik Talebi Gönderme": "{kurumumuzda} görev yapan ........ ........ tarihi itibarıyla emekliye ayrılmak istemektedir. İlgilinin dilekçesi ve emeklilik belgeleri ekte sunulmuştur.\n\n{kapanış:gereg}\n\nEkler:\n1- ........\n2- ........", "Sınav Görevlendirmesi Bildirimi": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı ile duyurulan {konu} kapsamında {kurumumuzda} görevlendirilen personelin listesi ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEk: ........ (... sayfa)", "Taşımalı Eğitim Bilgileri Bildirimi": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı gereğince {kurumumuza} taşıma yoluyla gelen öğrencilere ve güzergâhlara ilişkin bilgiler ekte sunulmuştur.\n\n{kapanış:bilgi}\n\nEk: ........ (... sayfa)", "Kurum Bilgileri Güncellendi (MEBBİS)": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi yazı gereğince {kurumumuza} ait {konu} bilgileri MEBBİS ilgili modülünde güncellenmiştir.\n\n{kapanış:bilgi}", "Dönem Sonu Evrak Teslimi Tebliği": "{kurumumuzda} ........ eğitim-öğretim yılı birinci dönem sonu itibarıyla öğretmen dosyalarında bulunması gereken belgelerin tamamlanarak okul idaresine teslim edilmesi gerekmektedir.\n\nBu kapsamda aşağıda belirtilen belgelerin ........ tarihine kadar okul müdür yardımcısına teslim edilmesini {kapanış:rica}\n\n1. Birinci dönem şube öğretmenler kurulu toplantı tutanağı\n2. Birinci dönem zümre öğretmenler kurulu toplantı tutanağı\n3. Yıllık planın birinci dönem uygulama durumu\n4. Sınıf rehber öğretmenleri için birinci dönem rehberlik faaliyet raporu\n5. Proje ve performans çalışmalarına ait değerlendirme ölçekleri\n6. Sınav, proje ve performans notlarının e-Okul'a işlendiğine dair kontrol çıktısı\n7. Ders defterlerinin eksiksiz doldurulduğunun kontrolü\n\nTEBLİĞ EDİLEN PERSONEL\n1- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n2- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n3- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n4- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n5- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n6- Adı Soyadı: ........ / Branşı: ........ / İmza: ........", "Sene Sonu Evrak Teslimi Tebliği": "{kurumumuzda} ........ eğitim-öğretim yılı ders yılı sonu itibarıyla öğretmen dosyalarında bulunması gereken belgelerin tamamlanarak okul idaresine teslim edilmesi gerekmektedir.\n\nBu kapsamda aşağıda belirtilen belgelerin ........ tarihine kadar okul müdür yardımcısına teslim edilmesini {kapanış:rica}\n\n1. Yıllık planların uygulanma durumunu gösteren ders kesim raporu\n2. İkinci dönem şube ve zümre öğretmenler kurulu tutanakları\n3. Yıl sonu zümre öğretmenler kurulu toplantı tutanağı ve değerlendirme raporu\n4. Sınıf rehberlik yıl sonu faaliyet raporu\n5. Proje ve performans çalışmalarına ait değerlendirme ölçekleri\n6. Notların e-Okul'a işlendiğine dair kontrol çıktısı\n7. Ders defterlerinin eksiksiz doldurularak idareye teslimi\n8. Zimmetle teslim alınan kitap, araç-gereç ve demirbaşların teslimi\n\nTEBLİĞ EDİLEN PERSONEL\n1- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n2- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n3- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n4- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n5- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n6- Adı Soyadı: ........ / Branşı: ........ / İmza: ........", "Sene Başı Görevlendirmeleri Toplu Tebliği": "TÜM ÖĞRETMENLERE\n\n{kurumumuzda} ........ eğitim-öğretim yılı sene başı öğretmenler kurulu toplantısında alınan kararlar doğrultusunda yapılan görevlendirmeler aşağıda gösterilmiştir. Görevli öğretmenlerin gerekli iş, işlem ve hazırlıkları zamanında yapmalarını {kapanış:rica}\n\n1) KURUL VE KOMİSYONLAR\n1- Kurul/Komisyon: ........ / Görevi: ........ / Adı Soyadı: ........\n2- Kurul/Komisyon: ........ / Görevi: ........ / Adı Soyadı: ........\n3- Kurul/Komisyon: ........ / Görevi: ........ / Adı Soyadı: ........\n\n2) BELİRLİ GÜN VE HAFTALAR\n1- Gün/Hafta: ........ / Zamanı: ........ / Görevli Öğretmen: ........\n2- Gün/Hafta: ........ / Zamanı: ........ / Görevli Öğretmen: ........\n3- Gün/Hafta: ........ / Zamanı: ........ / Görevli Öğretmen: ........\n\n3) ÖĞRENCİ KULÜPLERİ\n1- Kulüp: ........ / Danışman Öğretmen: ........\n2- Kulüp: ........ / Danışman Öğretmen: ........\n3- Kulüp: ........ / Danışman Öğretmen: ........\n\n4) SINIF / ŞUBE REHBER ÖĞRETMENLERİ\n1- Sınıf/Şube: ........ / Rehber Öğretmen: ........\n2- Sınıf/Şube: ........ / Rehber Öğretmen: ........\n3- Sınıf/Şube: ........ / Rehber Öğretmen: ........\n\nTEBLİĞ EDİLEN PERSONEL\n1- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n2- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n3- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n4- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n5- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n6- Adı Soyadı: ........ / Branşı: ........ / İmza: ........", "Görevden Ayrılma Bilgi Tablosu": "{kurumAdi} kadrosunda görev yapmakta iken ........ ile ........ kadrosuna atanan personelin görevden ayrılma bilgileri aşağıda gösterilmiştir.\n\nKİMLİK BİLGİLERİ\nT.C. Kimlik No: ........\nAdı Soyadı: ........\nBakanlık Atama Alanı: ........\nAtama/Görevlendirme Çeşidi: ........\n\nGÖREVDEN AYRILMA BİLGİLERİ\nEski Görev Yeri: ........\nUnvanı: ........\nAyrılma Tarihi: ........\nYeni Görev Yeri: ........\nYeni Unvanı: ........\nBaşlama Tarihi: ........\n\n{kapanış:gereg}", "Ders Programı Tebliğ-Tebellüğ Tutanağı": "{kurumumuzda} ........ eğitim-öğretim yılında uygulanacak haftalık ders, kurs ve nöbet programları hazırlanmıştır. Programların birer örneği aşağıda imzası bulunan öğretmenlere imza karşılığında teslim edilmiş olup uygulanmasını {kapanış:rica}\n\nTEBLİĞ EDİLEN PERSONEL\n1- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n2- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n3- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n4- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n5- Adı Soyadı: ........ / Branşı: ........ / İmza: ........\n6- Adı Soyadı: ........ / Branşı: ........ / İmza: ........", "Personele Toplantı Duyurusu (OAB ve Veli Toplantısı)": "İlgi karar gereğince Okul Aile Birliği ve Veli Toplantısı ........ günü saat ........'da ekteki gündem maddeleri doğrultusunda {kurumAdi} ........ salonunda yapılacaktır.\n\nAnılan gün ve saatte tüm öğretmenlerin hazırlıklı olarak toplantı salonunda hazır bulunmalarını {kapanış:rica}\n\nEk: ........ (... sayfa)", "KDV İstisna Belgesi (Eğitime %100 Destek)": "Millî Eğitim Bakanlığına bedelsiz teslim edilmek üzere yapılacak bilgisayar, donanım ve yazılım alımlarına ilişkin katma değer vergisi istisna belgesidir.\n\nİSTİSNADAN YARARLANACAK KURUM\nKurum Adı: ........\nVergi Dairesi: ........\nVergi Kimlik No: ........\nFaaliyet Konusu: Eğitim ve öğretim\nAdres: ........\nBelge Düzenleme Tarihi: ........\n\nYukarıda bilgileri yazılı kurum tarafından \"Eğitime %100 Destek Projesi\" kapsamında {okul} Müdürlüğüne bağışlanacak, ekli listede gösterilen cihazların alımında katma değer vergisi istisnası uygulanması uygundur. İşbu belge düzenleme tarihinden itibaren üç ay geçerlidir.\n\nEk: ........ (... sayfa)", "Sosyal Etkinlik Uygunluk Görüşü": "Okul Aile Birliğimiz tarafından ........ tarihinde ........ yerinde düzenlenmesi planlanan ........ etkinliğine ilişkin yönetim kurulu kararı ile sosyal etkinlikler kurulu inceleme tutanağı {kurumumuzca} incelenmiş; etkinliğin mevzuata ve {kurumumuzun} eğitim-öğretim düzenine uygun olduğu değerlendirilmiştir.\n\nMakamınızca da uygun görülmesi hâlinde {kapanış:olurtalep}\n\nEkler:\n1- ........\n2- ........", "Öğrenim Durum Belgesi": "İLGİLİ MAKAMA\n\nÖĞRENCİNİN\nAdı Soyadı: ........\nT.C. Kimlik No: ........\nBaba Adı: ........\nAna Adı: ........\nDoğum Yeri ve Tarihi: ........\nOkul No: ........\nSınıfı/Şubesi: ........\nAlanı/Dalı: ........\nÖğrenim Süresi: ........\nKayıt Tarihi: ........\n\nYukarıda kimlik bilgileri yazılı öğrencinin {okul} bünyesinde öğrenim gördüğü kayıtlarımızdan anlaşılmış olup bu belge ilgilinin isteği üzerine düzenlenmiştir.", "Birleştirilmiş Sınıf Ek Ders Ücret Onayı": "{kurumumuzda} birleştirilmiş sınıf uygulaması yapılmakta olup birleştirilmiş sınıflarda görev yapan öğretmenlere Millî Eğitim Bakanlığı Yönetici ve Öğretmenlerinin Ders ve Ek Ders Saatlerine İlişkin Karar hükümleri gereğince ödenecek ek ders ücretleri aşağıda gösterilmiştir.\n\n1- Adı Soyadı: ........ / Branşı: ........ / Birleştirilen Sınıflar: ........ / Öğrenci Sayısı: ........ / Haftalık Ek Ders: ........ / Başlama Tarihi: ........\n2- Adı Soyadı: ........ / Branşı: ........ / Birleştirilen Sınıflar: ........ / Öğrenci Sayısı: ........ / Haftalık Ek Ders: ........ / Başlama Tarihi: ........\n3- Adı Soyadı: ........ / Branşı: ........ / Birleştirilen Sınıflar: ........ / Öğrenci Sayısı: ........ / Haftalık Ek Ders: ........ / Başlama Tarihi: ........\n\nMakamınızca da uygun görülmesi hâlinde {kapanış:olurtalep}", "Anasınıfı Banka Ödeme Talimatı": "{okul} adına açılmış ........ IBAN numaralı okul öncesi hesabından ........ TL'nin ........ adına ........ Bankası ........ Şubesindeki ........ IBAN numaralı hesaba aktarılmasını {kapanış:rica}", "Ders Denetimi Tebliğ Yazısı": "Ders denetimi; eğitimin belirlenmiş hedeflerine ulaşmak amacıyla öğretme ve öğrenme etkinliklerini sınıf ortamında gözlemlemek, öğretmenin derse hazırlık ve ders dışı tamamlayıcı çalışmalarını incelemek üzere yapılır.\n\nBu amaçla ekteki plan çerçevesinde ........ tarihleri arasında ders denetimleri yapılacaktır. Denetimlerde gözlem formundaki ölçütlerin yanı sıra aşağıdaki hususlar incelenecektir:\n\n- Sınıfların eğitim durumu\n- Zümre ve veli toplantıları\n- BEP'li öğrencilerin BEP planları\n- Günlük planlar\n- Kulüp ve toplum hizmeti çalışmaları ile evrakları\n- Dersliğin ve ders araç-gereçlerinin donatım, bakım ve temizliği\n- Sınıf kitaplığı ve etkinlik köşeleri\n- Ders ve sınıflarla ilgili defter ve dosyalar\n- Sınıf defteri ve öğrenci devamsızlıklarının işlenmesi\n- e-Okul öğrenci bilgilerinin güncelliği\n- Gelen yazıların takibi ve imzalanması\n\n{kapanış:gerek}\n\nTEBLİĞ EDİLEN ÖĞRETMENLER\n1- Adı Soyadı: ........ / Branşı: ........ / Tarih/Saat: ........ / İmza: ........\n2- Adı Soyadı: ........ / Branşı: ........ / Tarih/Saat: ........ / İmza: ........\n3- Adı Soyadı: ........ / Branşı: ........ / Tarih/Saat: ........ / İmza: ........\n4- Adı Soyadı: ........ / Branşı: ........ / Tarih/Saat: ........ / İmza: ........\n5- Adı Soyadı: ........ / Branşı: ........ / Tarih/Saat: ........ / İmza: ........\n6- Adı Soyadı: ........ / Branşı: ........ / Tarih/Saat: ........ / İmza: ........\n7- Adı Soyadı: ........ / Branşı: ........ / Tarih/Saat: ........ / İmza: ........\n8- Adı Soyadı: ........ / Branşı: ........ / Tarih/Saat: ........ / İmza: ........", "Destek Eğitim Odası Öğretmen Görevlendirme Onayı": "İlgi: a) Özel Eğitim Hizmetleri Yönetmeliği.\n      b) ........ tarihli ve ........ sayılı Karar.\n\nİlgi (a) Yönetmeliğin ilgili maddesi ve ilgi (b) Karar doğrultusunda {kurumAdi} kaynaştırma/bütünleştirme yoluyla eğitim alan öğrencilerine yönelik destek eğitim odası ........ eğitim-öğretim yılı çalışma programının ekteki ders programına göre ........ tarihinde başlayıp ........ tarihinde sona ermesi ve aşağıda adı geçen öğretmenlerin görevlendirilmesi {kurumumuzca} uygun görülmektedir.\n\nMakamınızca da uygun görülmesi hâlinde {kapanış:olurtalep}\n\nDESTEK EĞİTİM ODASI GÖREVLENDİRME ÇİZELGESİ\n1- Adı Soyadı: ........ / Branşı: ........ / Haftalık Ders Saati: ........ / Zaman Çizelgesi: ........\n2- Adı Soyadı: ........ / Branşı: ........ / Haftalık Ders Saati: ........ / Zaman Çizelgesi: ........\n3- Adı Soyadı: ........ / Branşı: ........ / Haftalık Ders Saati: ........ / Zaman Çizelgesi: ........\n4- Adı Soyadı: ........ / Branşı: ........ / Haftalık Ders Saati: ........ / Zaman Çizelgesi: ........\n\nEk: ........ (... sayfa)", "Diploma Kayıt Örneği": "İlgilinin dilekçesi üzerine yapılan incelemede; ........ T.C. kimlik numaralı, ........ doğumlu, ........ oğlu/kızı ........'nın {okul}'ndan ........ eğitim-öğretim yılında ........ (........) derece ile ........ tarih ve ........ sayılı diplomayı almaya hak kazandığı {kurumAdi} resmî kayıtlarından anlaşılmıştır.\n\nİşbu diploma kayıt örneği ilgilinin isteği üzerine düzenlenmiştir.", "Eğitsel Değerlendirme İsteği Gönderme": "{kurumAdi} ........ sınıfı öğrencisi ........'e ait Eğitsel Değerlendirme İsteği Formu ve ekleri ekte sunulmuştur. Öğrencinin eğitsel değerlendirme ve tanılamasının yapılarak uygun eğitim tedbirinin belirlenmesine ve işlem sonucunun {kurumumuza} bildirilmesine ihtiyaç duyulmaktadır.\n\n{kapanış:gerek}\n\nEkler:\n1- ........\n2- ........", "Görev Yeri Belgesi": "PERSONELİN\nT.C. Kimlik No: ........\nAdı Soyadı: ........\nBaba Adı: ........\nAna Adı: ........\nDoğum Tarihi/Yeri: ........\nGörev Yeri: {okul}\nUnvanı/Görevi: ........\nKadro Derecesi: ........\nMaaş Derece/Kademesi: ........\nEmekli Sicil No: ........\nSon Öğrenim Durumu: ........\nSon Mezun Olduğu Okul: ........\n\nYukarıda bilgileri yazılı ........ (T.C. Kimlik No: ........) {il} ili {ilçe} ilçesi {okul} personelidir.\n\nİşbu belge ilgilinin isteği üzerine düzenlenmiştir.", "Yönetici Göreve Başlama Yazısı": "İlgi: a) ........ tarihli ve ........ sayılı Makam Onayı.\n      b) {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\nİlgi (a) Onay ve ilgi (b) yazı gereğince ........ iken {kurumumuza} ........ olarak atanan/görevlendirilen ........ (T.C. Kimlik No: ........) ........ tarihinde {kurumumuzdaki} görevine başlamıştır. Atama kararnamesi ve personel nakil bildirimi ekte sunulmuştur.\n\n{kapanış:gereg}\n\nEkler:\n1- ........\n2- ........", "Hizmetli Görev Tebliği": "Aşağıda sıralanan görevler yeni bir görevlendirme yapılıncaya kadar tarafınıza verilmiştir. Görevlerinizi titizlikle yerine getirmenizi ve çalışmalar hakkında okul idaresine bilgi vermenizi rica ederim.\n\nGÖREVLERİ:\n1. Mesai saatlerine uymak; en geç saat ........'da okulda hazır bulunmak, ........'dan önce okuldan ayrılmamak.\n2. Okul müdürü ve müdür yardımcısının izni olmadan okuldan ayrılmamak.\n3. Sınıfların, idari odaların, lavaboların ve diğer bölümlerin temizlik ve düzenini sağlamak.\n4. Sorumlu olduğu kattaki koridor, merdiven, lavabo ve tuvaletleri teneffüslerden sonra temizlemek.\n5. Sorumlu olduğu sınıfları her gün ders bitiminde temizlemek; sıra, kapı ve duvarları silmek.\n6. Tatil günlerinde sorumlu olduğu alanların ayrıntılı temizliğini yapmak.\n7. Okul içi ve dışı eşya taşıma ve yerleştirme işlerini yapmak.\n8. Aylık ve haftalık genel temizliklere katılmak.\n9. Aydınlatma ve ısıtma işlerinde görev almak.\n10. Okul müdürünün mevzuat çerçevesinde vereceği diğer görevleri yerine getirmek.\n\nTEBLİĞ-TEBELLÜĞ\nOkudum, bilgi edindim ve bir suretini elden aldım.\nTarih: ........  Adı Soyadı: ........  Unvanı: Hizmetli  İmza: ........", "Güvenlik Görevlisi Görev Tebliği": "{kurumumuzda} ........ eğitim-öğretim yılı itibarıyla Güvenlik Görevlisi olarak görev ve sorumluluklarınız aşağıda belirtilmiştir.\n\nGÖREVLERİ:\n1. Okul giriş-çıkışlarını kontrol etmek, ziyaretçileri kayıt altına alarak ilgili birime yönlendirmek.\n2. Okul binası, bahçesi ve çevresinin güvenliğini mesai süresince sağlamak.\n3. Öğrencilerin izinsiz okuldan ayrılmasını önlemek.\n4. Şüpheli durum ve kişileri derhâl okul idaresine bildirmek.\n5. Acil durumlarda okul idaresinin talimatları doğrultusunda hareket etmek.\n6. Okul müdürünün mevzuat çerçevesinde vereceği diğer görevleri yerine getirmek.\n\n{kapanış:gereg}\n\nTEBLİĞ-TEBELLÜĞ\nOkudum, bilgi edindim ve bir suretini elden aldım.\nTarih: ........  Adı Soyadı: ........  Unvanı: Güvenlik Görevlisi  İmza: ........", "Bahçe Görevlisi Görev Talimatnamesi Tebliği": "{kurumumuzda} ........ eğitim-öğretim yılı itibarıyla Bahçe Görevlisi olarak görev ve sorumluluklarınız aşağıda belirtilmiştir.\n\nGÖREVLERİ:\n1. Okul bahçesinin temizliğini ve düzenini sağlamak.\n2. Ağaç, çiçek ve yeşil alanların bakım ve sulamasını yapmak.\n3. Bahçedeki oyun alanları ve donanımlarda tespit ettiği arızaları okul idaresine bildirmek.\n4. Kış aylarında giriş yollarındaki kar ve buzlanmaya karşı önlem almak.\n5. Okul müdürünün mevzuat çerçevesinde vereceği diğer görevleri yerine getirmek.\n\n{kapanış:gereg}\n\nTEBLİĞ-TEBELLÜĞ\nOkudum, bilgi edindim ve bir suretini elden aldım.\nTarih: ........  Adı Soyadı: ........  Unvanı: Bahçe Görevlisi  İmza: ........", "Sürekli İşçi Görev Tebliği (696 KHK)": "{kurumumuzda} ........ eğitim-öğretim yılı itibarıyla Sürekli İşçi olarak görev ve sorumluluklarınız aşağıda belirtilmiştir.\n\nGÖREVLERİ:\n1. Mesai saatlerine uymak ve okul idaresinin izni olmadan okuldan ayrılmamak.\n2. Okul idaresince belirlenen alanların temizlik, düzen ve bakım işlerini yapmak.\n3. Eşya taşıma, yerleştirme ve benzeri destek hizmetlerinde görev almak.\n4. Görev sırasında tespit ettiği arıza ve eksiklikleri okul idaresine bildirmek.\n5. Okul müdürünün mevzuat çerçevesinde vereceği diğer görevleri yerine getirmek.\n\n{kapanış:gereg}\n\nTEBLİĞ-TEBELLÜĞ\nOkudum, bilgi edindim ve bir suretini elden aldım.\nTarih: ........  Adı Soyadı: ........  Unvanı: Sürekli İşçi  İmza: ........", "TYP Çalışanı Görev Tebliği": "{kurumumuzda} ........ eğitim-öğretim yılı itibarıyla TYP Çalışanı olarak görev ve sorumluluklarınız aşağıda belirtilmiştir.\n\nGÖREVLERİ:\n1. Mesai saatlerine uymak ve okul idaresinin izni olmadan okuldan ayrılmamak.\n2. Okul idaresince belirlenen alanların temizlik, düzen ve bakım işlerini yapmak.\n3. Eşya taşıma, yerleştirme ve benzeri destek hizmetlerinde görev almak.\n4. Görev sırasında tespit ettiği arıza ve eksiklikleri okul idaresine bildirmek.\n5. Okul müdürünün mevzuat çerçevesinde vereceği diğer görevleri yerine getirmek.\n\n{kapanış:gereg}\n\nTEBLİĞ-TEBELLÜĞ\nOkudum, bilgi edindim ve bir suretini elden aldım.\nTarih: ........  Adı Soyadı: ........  Unvanı: TYP Çalışanı  İmza: ........", "İUP Personeli Görev Tebliği": "{kurumumuzda} ........ eğitim-öğretim yılı itibarıyla İUP Katılımcısı olarak görev ve sorumluluklarınız aşağıda belirtilmiştir.\n\nGÖREVLERİ:\n1. Mesai saatlerine uymak ve okul idaresinin izni olmadan okuldan ayrılmamak.\n2. Okul idaresince belirlenen alanların temizlik, düzen ve bakım işlerini yapmak.\n3. Eşya taşıma, yerleştirme ve benzeri destek hizmetlerinde görev almak.\n4. Görev sırasında tespit ettiği arıza ve eksiklikleri okul idaresine bildirmek.\n5. Okul müdürünün mevzuat çerçevesinde vereceği diğer görevleri yerine getirmek.\n\n{kapanış:gereg}\n\nTEBLİĞ-TEBELLÜĞ\nOkudum, bilgi edindim ve bir suretini elden aldım.\nTarih: ........  Adı Soyadı: ........  Unvanı: İUP Katılımcısı  İmza: ........", "Mazeret İzni Onay Yazısı": "MÜDÜRLÜK MAKAMINA\n\n{kurumumuzda} ........ olarak görev yapmakta olan ........'a ait izin bilgileri aşağıda gösterilmiştir.\n\nKİMLİK BİLGİLERİ\nT.C. Kimlik No: ........\nAdı Soyadı: ........\nHizmet Sınıfı: ........\nGörevi ve Görev Yeri: ........\nKurum Sicil No: ........\n\nİZNİN TÜRÜ VE NEDENİ\nMazeret İzni (gün): ........\nMazeretin Nedeni: ........\n\nAYRILMA VE BAŞLAMA\nİzne Ayrıldığı Tarih: ........\nGöreve Başlama Tarihi: ........\nİzni Geçireceği Adres ve Telefon: ........\n\nİlgilinin dilekçesinde belirttiği mazereti nedeniyle ........ tarihinden itibaren ........ gün mazeret izinli sayılması hususunu {kapanış:olurtalep}", "Raporu Hastalık (Sıhhi) İznine Çevirme": "MÜDÜRLÜK MAKAMINA\n\n{kurumumuzda} ........ olarak görev yapmakta olan ........'a ait izin bilgileri aşağıda gösterilmiştir.\n\nKİMLİK BİLGİLERİ\nT.C. Kimlik No: ........\nAdı Soyadı: ........\nHizmet Sınıfı: ........\nGörevi ve Görev Yeri: ........\nKurum Sicil No: ........\n\nİZNİN TÜRÜ VE NEDENİ\nHastalık İzni (gün): ........\nRaporu Veren Sağlık Kuruluşu: ........\nRapor Tarihi ve Numarası: ........\n\nAYRILMA VE BAŞLAMA\nİzne Ayrıldığı Tarih: ........\nGöreve Başlama Tarihi: ........\nİzni Geçireceği Adres ve Telefon: ........\n\nYukarıda durumu açıklanan personelin ekte sunulan sağlık raporu gereğince ........ tarihinden geçerli olmak üzere ........ gün hastalık izinli sayılması hususunu {kapanış:olurtalep}\n\nEk: ........ (... sayfa)", "Ders Dışı Eğitim (Egzersiz) Çalışması Oluru": "İlgi: {gönderen} {tarih} tarihli ve {sayı} sayılı yazısı.\n\n{kurumAdi} ........ öğretmeni ........'ın ilgi yazı kapsamında ........ eğitim-öğretim yılında yürüteceği ........ ders dışı eğitim (egzersiz) çalışmasına ait öğrenci listesi, yeterlik belgesi ve çalışma planı ekte sunulmuştur.\n\nMakamınızca da uygun görülmesi hâlinde {kapanış:olurtalep}\n\nEkler:\n1- ........\n2- ........", "Devamsızlık Mektubu (İlkokul ve Ortaokul)": "DEVAMSIZLIK MEKTUBU (........ UYARI)\n\nSayın Veli,\n\nVelisi bulunduğunuz {okul} ........ sınıfı ........ şubesi ........ numaralı öğrencisi ........ aşağıda belirtilen günlerde okula devam etmemiştir.\n\n1- Tarih: ........ / Özürlü/Özürsüz: ........ / Gün: ........\n2- Tarih: ........ / Özürlü/Özürsüz: ........ / Gün: ........\n3- Tarih: ........ / Özürlü/Özürsüz: ........ / Gün: ........\n4- Tarih: ........ / Özürlü/Özürsüz: ........ / Gün: ........\n5- Tarih: ........ / Özürlü/Özürsüz: ........ / Gün: ........\n\nÖzürsüz devamsızlık toplamı: ........ gün   Özürlü devamsızlık toplamı: ........ gün\n\n222 sayılı İlköğretim ve Eğitim Kanunu gereğince her veli, çocuğunun okula düzenli devamını sağlamak ve özrü nedeniyle okula gidemeyen çocuğun durumunu en geç üç gün içinde okul idaresine bildirmekle yükümlüdür. Çocuğun okula gönderilmemesi hâlinde idari para cezası uygulanmaktadır.\n\nBu konuda görüşmek üzere okul idaresine başvurmanızı önemle rica ederim.", "Devamsızlık Mektubu (Ortaöğretim - Lise)": "DEVAMSIZLIK MEKTUBU (........ UYARI)\n\nSayın Veli,\n\nVelisi bulunduğunuz {okul} ........ sınıfı ........ şubesi (........ alanı) ........ numaralı öğrencisi ........ aşağıda belirtilen günlerde okula devam etmemiştir.\n\n1- Tarih: ........ / Özürlü/Özürsüz: ........ / Gün: ........\n2- Tarih: ........ / Özürlü/Özürsüz: ........ / Gün: ........\n3- Tarih: ........ / Özürlü/Özürsüz: ........ / Gün: ........\n4- Tarih: ........ / Özürlü/Özürsüz: ........ / Gün: ........\n5- Tarih: ........ / Özürlü/Özürsüz: ........ / Gün: ........\n\nÖzürsüz devamsızlık toplamı: ........ gün   Özürlü devamsızlık toplamı: ........ gün\n\nMillî Eğitim Bakanlığı Ortaöğretim Kurumları Yönetmeliği gereğince öğrencinin bir ders yılında özürsüz ........ günü, toplamda ........ günü aşan devamsızlığı hâlinde sınıf tekrarı söz konusu olacaktır.\n\nBu konuda görüşmek üzere ilgili müdür yardımcısına başvurmanızı önemle rica ederim.", "Öğrenci Belgesi": "ÖĞRENCİ BELGESİ\n\nOKULUN\nİli/İlçesi: {il} / {ilçe}\nAdı: {okul}\n\nÖĞRENCİNİN\nT.C. Kimlik No: ........\nAdı Soyadı: ........\nBaba Adı: ........\nAna Adı: ........\nDoğum Yeri ve Tarihi: ........\nSınıfı/Şubesi: ........\nOkul Numarası: ........\n\nYukarıda açık kimliği yazılı ........ {kurumumuzun} ........ sınıfı ........ şubesinde ........ numara ile kayıtlı olup hâlen devam eden öğrencimizdir.\n\nBu belge, velinin isteği üzerine ........ kurumuna verilmek üzere düzenlenmiştir.", "Memur Görev Tebliği": "Aşağıda sıralanan görevler yeni bir görevlendirme yapılıncaya kadar tarafınıza verilmiştir.\n\nGÖREVLERİ:\n1. Mesai saatlerine uymak ve okul müdürünün izni olmadan okuldan ayrılmamak.\n2. Okul mutemetliği görevini yürütmek.\n3. Gelen ve giden evrakın kayıt ve dosyalama işlerini yapmak.\n4. Evrak arşivleme iş ve işlemlerini zamanında yapmak.\n5. Ödemeler dosyasını düzenlemek; maaş, ek ders ve diğer ödeme bordrolarının onaylı örneklerini dosyalamak.\n6. Okul faturalarını MEBBİS'e işlemek.\n7. Taşınır Kayıt ve Yönetim Sistemi giriş-çıkış ve yıl sonu işlemlerini zamanında yapmak.\n8. Personel izin, göreve başlama ve ayrılma işlemlerini okul müdürünün bilgisi dâhilinde yürütmek.\n9. Personel özlük dosyalarını düzenlemek.\n10. Okul müdürü ve yardımcılarının mevzuat çerçevesinde vereceği diğer görevleri yerine getirmek.\n\n{kapanış:gereg}\n\nTEBLİĞ-TEBELLÜĞ\nOkudum, bilgi edindim ve bir suretini elden aldım.\nTarih: ........  Adı Soyadı: ........  Unvanı: Memur  İmza: ........", "Müdür Yardımcısı Görev Tebliği": "Aşağıda sıralanan görevler yeni bir görevlendirme yapılıncaya kadar tarafınıza verilmiştir.\n\nGÖREVLERİ:\n1. Mesai saatlerine uymak.\n2. EBYS/DYS üzerinden tebliğ edilen yazıların takibini yapmak ve gereğini yerine getirmek.\n3. Görev alanıyla ilgili yıllık çalışma takvimini hazırlamak ve uygulamak.\n4. Nöbet çizelgesini, nöbetçi öğretmenleri ve nöbet defterini takip etmek.\n5. Öğretmenlerin derse giriş-çıkışlarını izlemek; izinli veya raporlu öğretmenin derslerinin yürütülmesini sağlamak.\n6. Okul müdürünün bulunmadığı zamanlarda müdüre vekâlet etmek.\n7. Rehberlik hizmetlerinin uygulanmasını izlemek.\n8. Brifing dosyasını hazırlamak.\n9. İş sağlığı ve güvenliği ile sivil savunma iş ve işlemlerini yürütmek.\n10. Gerçekleştirme görevlisi olarak satın alma iş ve işlemlerini yürütmek.\n11. Okul mührünü muhafaza etmek.\n12. Personel işlerini ve özlük dosyalarını mevzuata uygun olarak yürütmek.\n13. Personel ve öğrenci devam-devamsızlık işlemlerini takip etmek.\n14. Sınıf defterleri ile ders ve yıllık planları incelemek.\n15. Belirli gün ve haftalar, öğrenci kulüpleri ve toplum hizmeti çalışmalarını yürütmek.\n16. Görev alanıyla ilgili kurul ve komisyon toplantılarına başkanlık etmek, tutanakları dosyalamak.\n17. Okul binası ve bahçesinin temizlik, onarım ve güvenlik işlerini takip etmek.\n18. Sene başı, dönem sonu ve sene sonu iş ve işlemlerini yürütmek.\n19. Veli toplantılarını düzenlemek.\n20. Maaş ve ek ders iş ve işlemlerini yürütmek.\n21. Ders dışı eğitim çalışmaları, evde eğitim, BEP ve kurs (İYEP, DYK vb.) işlemlerini yürütmek.\n22. Okul Aile Birliği iş ve işlemlerini yürütmek.\n23. Okul zaman çizelgesi, norm güncelleme ve arşiv işlemlerini yürütmek.\n24. Okul müdürünün mevzuat çerçevesinde vereceği diğer görevleri yerine getirmek.\n\n{kapanış:gereg}\n\nTEBLİĞ-TEBELLÜĞ\nOkudum, bilgi edindim ve bir suretini elden aldım.\nTarih: ........  Adı Soyadı: ........  Unvanı: Müdür Yardımcısı  İmza: ........", "Müdür İzin Yazısı": "PERSONELE AİT İZİN ONAY BELGESİ\n\nKİMLİK BİLGİLERİ\nT.C. Kimlik No: ........\nAdı Soyadı: {müdür}\nHizmet Sınıfı: Eğitim ve Öğretim Hizmetleri\nGörevi ve Yeri: Müdür - {okul}\nKurum Sicil No: ........\n\nİZNİN TÜRÜ\n[ ] Yıllık İzin (toplam ........ gün)  [ ] Mazeret İzni  [ ] Hastalık İzni  [ ] Aylıksız İzin  [ ] Diğer  [ ] Yol Süresi\n\nAYRILMA VE BAŞLAMA\nİzne Ayrıldığı Tarih: ........\nGöreve Başlama Tarihi: ........\nİzne Esas Hizmet Süresi: ........\nİzni Geçireceği Adres ve Telefon: ........\n\nYukarıda belirtilen nedenle ........ gün izinli sayılmam ve bu süre içinde Müdür Yardımcısı ........ (T.C. Kimlik No: ........)'ın Okul Müdürlüğüne vekâlet etmesi hususunu {kapanış:olurtalep}", "Özlük Dosyası Gönderme Yazısı": "{kurumumuzda} ........ olarak görev yapmakta iken ........ ile Müdürlüğünüze ........ olarak atanan ........ T.C. kimlik numaralı ........'a ait özlük dosyası ve muhteviyatı ekte gönderilmiştir.\n\n{kapanış:gereg}\n\nEk: ........ (... sayfa)", "Sendika Üyelik Bildirimi": "{kurumAdi} personelinden ........ (T.C. Kimlik No: ........)'a ait sendika üyelik formu ekte sunulmuştur. Söz konusu personelin sendika üyelik bilgilerinin ilgili sistemlere işlenmesi hususunda {kapanış:gerek2}\n\nEk: ........ (... sayfa)", "Sendika Üyeliğinden Çekilme (İstifa) Bildirimi": "{kurumAdi} personelinden ........ (T.C. Kimlik No: ........)'a ait sendika üyeliğinden çekilme formu ekte sunulmuş olup ıslak imzalı aslı ayrıca gönderilecektir. MEBBİS ve maaş sistemlerinde gerekli işlemlerin yapılması hususunda {kapanış:gerek2}\n\nEk: ........ (... sayfa)", "Yeni Mühür Talep Yazısı": "{kurumumuzda} kullanılmakta olan resmî mührün ........ nedeniyle yenilenmesi gerekmektedir. Darphane ve Damga Matbaası Genel Müdürlüğüne verilecek mühür siparişi için gerekli Valilik Onayının alınması hususunda {kapanış:gerek2}", "Lüzum Kâğıdı (Doğrudan Temin)": "LÜZUM KÂĞIDI\n\nAşağıda cinsi, özellikleri ve miktarı yazılı mal/hizmetin {okul} ihtiyacı için alınmasına lüzum görülmüştür.\n\n1- Malzeme/Hizmet Adı: ........ / Özellikleri: ........ / Miktarı: ........ / Birimi: ........\n2- Malzeme/Hizmet Adı: ........ / Özellikleri: ........ / Miktarı: ........ / Birimi: ........\n3- Malzeme/Hizmet Adı: ........ / Özellikleri: ........ / Miktarı: ........ / Birimi: ........\n4- Malzeme/Hizmet Adı: ........ / Özellikleri: ........ / Miktarı: ........ / Birimi: ........\n5- Malzeme/Hizmet Adı: ........ / Özellikleri: ........ / Miktarı: ........ / Birimi: ........\n\n{kapanış:gerek}\n\nHazırlayan\n........\nMüdür Yardımcısı\n\nUYGUNDUR\n..../..../20....\n{müdür}\n{amirUnvani} (Harcama Yetkilisi)", "Yaklaşık Maliyet İçin Fiyat İsteme": "İLGİLİ FİRMAYA / KİŞİYE\n\n{okul} tarafından satın alınması planlanan, aşağıda cinsi, miktarı ve özellikleri yazılı mal/hizmetin yaklaşık maliyetinin tespitinde kullanılmak üzere 4734 sayılı Kamu İhale Kanunu kapsamında KDV hariç piyasa satış fiyatlarınızın bildirilmesini rica ederim.\n\n1- Cinsi: ........ / Özellikleri: ........ / Miktarı: ........ / Birim Fiyat (KDV hariç): ........ / Toplam (KDV hariç): ........\n2- Cinsi: ........ / Özellikleri: ........ / Miktarı: ........ / Birim Fiyat (KDV hariç): ........ / Toplam (KDV hariç): ........\n3- Cinsi: ........ / Özellikleri: ........ / Miktarı: ........ / Birim Fiyat (KDV hariç): ........ / Toplam (KDV hariç): ........\n4- Cinsi: ........ / Özellikleri: ........ / Miktarı: ........ / Birim Fiyat (KDV hariç): ........ / Toplam (KDV hariç): ........\n5- Cinsi: ........ / Özellikleri: ........ / Miktarı: ........ / Birim Fiyat (KDV hariç): ........ / Toplam (KDV hariç): ........\nKDV Hariç Genel Toplam: ........ TL\n\nDİĞER HUSUSLAR\n1- Teslim süresi: ........ gün\n2- Teslim şekli: Tek partide\n3- Nakliye ve sigorta: Yükleniciye aittir.\n4- Uyulması gereken standartlar: TSE\n5- Teknik şartname: Ektedir.\n6- Bu fiyat bildirimi yaklaşık maliyet tespiti amacıyla istenmektedir.\n\nYaklaşık Maliyet / Piyasa Fiyat Araştırması Görevlileri\nBaşkan: ........ (Müdür Yardımcısı)\nÜye: ........ (Öğretmen)\nÜye: ........ (Öğretmen)\n\nFirma Kaşe ve İmzası / Tarih: ........", "Birim Fiyat Teklif Mektubu": "{okul} MÜDÜRLÜĞÜ DOĞRUDAN TEMİN KOMİSYONU BAŞKANLIĞINA\n\nBİRİM FİYAT TEKLİF MEKTUBU\n\nİşin Adı: ........\nTeklif Sahibinin Adı Soyadı / Ticaret Unvanı: ........\nT.C. Kimlik No (gerçek kişi ise): ........\nVergi Kimlik No: ........\nTebligat Adresi: ........\nTelefon / Faks: ........\nE-posta: ........\n\nİdarenizce doğrudan temin usulüyle alımı yapılacak ........ işine ait tüm belgeler tarafımızca incelenmiş ve herhangi bir ayrım ve sınırlama yapılmaksızın bütün koşullarıyla kabul edilmiştir. Aşağıdaki hususları içeren teklifimizin kabulünü arz ederiz.\n\n1- Teklif fiyata dâhil olması öngörülen bütün masraflar teklifimize dâhildir.\n2- Teklifimiz teklif tarihinden itibaren 30 (otuz) takvim günü geçerlidir.\n3- İdarenin en düşük teklifi seçmek zorunda olmadığını kabul ederiz.\n4- İdarenin çıkarlarına aykırı hiçbir eylem içinde olmayacağımızı taahhüt ederiz.\n5- 4734 sayılı Kanunun 22/d maddesi kapsamında aynı iş için doğrudan veya dolaylı olarak birden fazla teklif vermediğimizi beyan ederiz.\n6- İşi KDV hariç ........ TL (rakamla) / ........ TL (yazıyla) bedel karşılığında yapmayı kabul ve taahhüt ederiz.\n\nBİRİM FİYAT TEKLİF CETVELİ\n1- İş Kalemi/Malın Cinsi: ........ / Miktarı: ........ / Birim Fiyat (KDV hariç): ........ / Tutar: ........\n2- İş Kalemi/Malın Cinsi: ........ / Miktarı: ........ / Birim Fiyat (KDV hariç): ........ / Tutar: ........\n3- İş Kalemi/Malın Cinsi: ........ / Miktarı: ........ / Birim Fiyat (KDV hariç): ........ / Tutar: ........\n\nAdı Soyadı / Firma Kaşesi / İmza: ........  Tarih: ........", "Yaklaşık Maliyet Hesaplama Cetveli": "YAKLAŞIK MALİYET HESAPLAMA CETVELİ\n\n1. Firma: ........  Teklif: ........ TL\n2. Firma: ........  Teklif: ........ TL\n3. Firma: ........  Teklif: ........ TL\n\nMal/Hizmet: ........\nOrtalama (Yaklaşık Maliyet): ........ TL\n\nYaklaşık Maliyet / Piyasa Fiyat Araştırması Görevlileri\nBaşkan: ........ (Müdür Yardımcısı)\nÜye: ........ (Öğretmen)\nÜye: ........ (Öğretmen)\n\nNot: Piyasa fiyat araştırması yapılacak kişi/firma sayısına ve görevlendirilecek personel sayısına ihale yetkilisi karar verir.\n\nUYGUNDUR\n..../..../20....\n{müdür}\n{amirUnvani}", "Piyasa Fiyat Araştırma Tutanağı": "PİYASA FİYAT ARAŞTIRMA TUTANAĞI\n\n1. Firma: ........  Teklif: ........ TL\n2. Firma: ........  Teklif: ........ TL\n3. Firma: ........  Teklif: ........ TL\n\nUYGUN GÖRÜLEN FİRMA\nAdı: ........\nAdresi: ........\nTeklif Ettiği Fiyat: ........ TL\n\n4734 sayılı Kamu İhale Kanununun 22 nci maddesinin (d) bendi uyarınca doğrudan temin usulüyle yapılacak alıma ilişkin piyasa araştırmasında alınan teklifler tarafımızca değerlendirilmiş, yukarıda adı ve adresi belirtilen kişi/firmadan alım yapılması uygun görülmüştür.\n\nPiyasa Fiyat Araştırması Görevlileri\nBaşkan: ........ (Müdür Yardımcısı)\nÜye: ........ (Öğretmen)\nÜye: ........ (Öğretmen)"};
    const BUILTIN_HINTS = {"Standart Bilgi Verme": "bilgi verme cevap inceleme", "Uygun Görülmedi / Olumsuz": "olumsuz uygun değil talep red", "Komisyon / İnceleme Raporu": "komisyon inceleme rapor", "Malzeme / Demirbaş Talep": "malzeme demirbaş talep ihtiyaç", "Süre Uzatımı Talebi": "süre uzatım ek süre", "Görevlendirme / Olur": "görevlendirme olur personel", "İstenen Bilgi ve Belgelerin Gönderilmesi": "bilgi belge istenen gönderilmesi", "Faaliyet / Etkinlik Raporu": "faaliyet etkinlik rapor kutlama anma", "Olumsuz Bildirim (Durum Bulunmamaktadır)": "durum bulunmamaktadır bildirim yok", "Duyuru ve Tebliğ Yapıldı": "duyuru tebliğ duyurulması", "Eksik Evrakın Tamamlanması": "eksik evrak tamamlanması", "Toplantı / Eğitime Katılım Bildirimi": "toplantı eğitim katılım", "Ödenek Talebi": "ödenek ihtiyaç maliyet", "Bakım-Onarım İhtiyacı Bildirimi": "bakım onarım tamir", "Personel Bilgilerinin Bildirilmesi": "personel bilgi liste", "Bilgi / Belge İstenmesi (Eksik Bilgi)": "eksik bilgi belge talep istenmesi tamamlanması", "Yazının İlgisi Olmadığı / İade": "iade ilgisi yok yanlış gönderilen farklı kurum", "Web Sitesinde Yayımlandı / Panoda Duyuruldu": "duyuru web site internet yayımlandı pano afiş", "Öğrenci ve Velilere Duyuruldu": "öğrenci veli duyuru bilgilendirme toplantı", "Hizmet İçi Eğitim Katılım Bildirimi": "hizmet içi eğitim kurs seminer katılım katılımcı", "Olay Bildirimi (Tutanak ve Rapor)": "olay tutanak kaza güvenlik rapor bildirimi", "Denetim / Rehberlik Bulgularının Giderildiği": "denetim teftiş rehberlik bulgu eksiklik giderildi", "Öğrenci Disiplin Kurulu Kararı Bildirimi": "disiplin kurul kararı öğrenci ceza", "Öğrenci Nakil / Kayıt Bildirimi": "nakil kayıt öğrenci kayıt silme geçiş", "Göreve Başlama Yazısı": "göreve başlama başladı atama tayin öğretmen personel", "Görevden Ayrılma Yazısı": "görevden ayrılma ayrıldı tayin nakil ilişik kesme", "Ücretli Öğretmen Göreve Başlama": "ücretli öğretmen göreve başlama görevlendirme", "Ücretli Öğretmen Görevden Ayrılma": "ücretli öğretmen görevden ayrılma", "İUP / TYP Personeli Göreve Başlama": "iup typ işgücü uyum işkur personel göreve başlama", "Personel İzin Onayı Bildirimi": "izin onay yıllık mazeret rapor personel", "Aylıksız İzin Dilekçesi Gönderme": "aylıksız izin dilekçe doğum askerlik", "Derece-Kademe İlerlemesi (Terfi)": "derece kademe terfi ilerleme hizmet cetveli", "Öğretmen İhtiyacı Bildirimi": "öğretmen ihtiyacı norm açık branş kadro", "Ek Ders Puantajı Gönderme": "ek ders puantaj çizelge ücret ay", "Toplu Ücret Onayı (Ek Ders Olur)": "toplu ücret onay ek ders olur görevlendirme", "YEĞİTEK Okul Sorumlusu Görevlendirme": "yeğitek okul sorumlusu bilişim görevlendirme fatih", "KBS Yetki Değişikliği": "kbs kamu harcama bilişim sistemi yetki kullanıcı", "TKYS Yetki Değişikliği": "tkys taşınır kayıt yönetim yetki kullanıcı", "e-Okul Yeni Şube Açılması": "e-okul şube açılması sınıf mevcut", "Öğretmenlere Tebliğ Yazısı": "tebliğ tebellüğ öğretmenlere duyuru imza", "Kurul ve Komisyonlar Tebliği": "kurul komisyon tebliğ görevlendirme", "Sosyal Kulüpler Tebliği": "sosyal kulüp danışman öğretmen tebliğ", "Sınıf Rehber Öğretmenleri Tebliği": "sınıf rehber öğretmen şube görevlendirme tebliğ", "Belirli Gün ve Haftalar Tebliği": "belirli gün hafta kutlama anma program tebliğ", "Belletici Öğretmen Görevlendirme Onayı": "belletici pansiyon nöbet görevlendirme onay", "Doğrudan Temin Onay Belgesi (Olur)": "doğrudan temin onay belgesi olur 22/d alım", "Doğrudan Temin Komisyonu Görevlendirme": "doğrudan temin komisyon görevlendirme piyasa fiyat muayene kabul", "Teklif İsteme Yazısı": "teklif isteme fiyat teklifi firma doğrudan temin", "Piyasa Fiyat Araştırması Bildirimi": "piyasa fiyat araştırma yaklaşık maliyet cetvel", "Muayene ve Kabul Tutanağı Gönderme": "muayene kabul tutanak fatura ödeme teslim", "Fatura Ödeme Talebi": "fatura ödeme elektrik su doğalgaz internet telefon", "OAB İhtiyaç ve Harcama Talebi": "oab aile birliği ihtiyaç harcama talep", "OAB Banka Yetkilisi / İmza Sirküleri": "oab aile birliği banka yetki imza sirküleri", "OAB Ödeme Talimatı": "oab aile birliği ödeme talimat", "Gezi / Sosyal Etkinlik İzin Talebi": "gezi etkinlik izin onay sosyal gezi planı", "Okul Sosyal Medya Hesabı Oluru": "sosyal medya hesap instagram facebook okul tanıtım", "Güvenli Okul Raporu Gönderme": "güvenli okul rapor güvenlik koordinasyon", "Nöbet Çizelgesi Tebliği": "nöbet çizelge nöbetçi öğretmen tebliğ", "Veli Toplantısı Yapıldı Bildirimi": "veli toplantısı yapıldı tutanak", "OAB Genel Kurul Sonuç Bildirimi": "okul aile birliği genel kurul seçim yönetim kurulu", "Sağlık Raporu Bildirimi": "sağlık raporu hastalık izni rapor personel", "Emeklilik Talebi Gönderme": "emeklilik emekli talep dilekçe ayrılış", "Sınav Görevlendirmesi Bildirimi": "sınav görevi görevlendirme bina sınav sorumlusu gözetmen", "Taşımalı Eğitim Bilgileri Bildirimi": "taşımalı eğitim taşıma öğrenci servis güzergah", "Kurum Bilgileri Güncellendi (MEBBİS)": "mebbis kurum bilgileri güncelleme veri girişi modül", "Dönem Sonu Evrak Teslimi Tebliği": "dönem sonu evrak teslim tebliğ öğretmen dosya şube zümre", "Sene Sonu Evrak Teslimi Tebliği": "sene sonu yıl sonu evrak teslim tebliğ ders kesim raporu demirbaş zümre", "Sene Başı Görevlendirmeleri Toplu Tebliği": "sene başı görevlendirme toplu tebliğ kurul komisyon kulüp rehber belirli gün", "Görevden Ayrılma Bilgi Tablosu": "görevden ayrılma bilgi tablosu atama nakil ayrılış", "Ders Programı Tebliğ-Tebellüğ Tutanağı": "ders programı tebliğ tebellüğ tutanak haftalık kurs nöbet", "Personele Toplantı Duyurusu (OAB ve Veli Toplantısı)": "okul aile birliği veli toplantısı duyuru personel öğretmenler kurulu", "KDV İstisna Belgesi (Eğitime %100 Destek)": "kdv istisna belgesi eğitime yüzde yüz destek bağış bilgisayar", "Sosyal Etkinlik Uygunluk Görüşü": "sosyal etkinlik uygunluk görüşü okul aile birliği kurul tutanak", "Öğrenim Durum Belgesi": "öğrenim durum belgesi öğrenci belge ilgili makama", "Birleştirilmiş Sınıf Ek Ders Ücret Onayı": "birleştirilmiş sınıf ek ders ücret onay olur", "Anasınıfı Banka Ödeme Talimatı": "anasınıfı okul öncesi banka ödeme talimat iban aktarım", "Ders Denetimi Tebliğ Yazısı": "ders denetimi tebliğ gözlem sınıf ziyaret müdür", "Destek Eğitim Odası Öğretmen Görevlendirme Onayı": "destek eğitim odası kaynaştırma bütünleştirme öğretmen görevlendirme onay olur", "Diploma Kayıt Örneği": "diploma kayıt örneği mezuniyet belge kayıp", "Eğitsel Değerlendirme İsteği Gönderme": "eğitsel değerlendirme istek formu ram rehberlik araştırma merkezi tanılama özel eğitim", "Görev Yeri Belgesi": "görev yeri belgesi personel çalıştığına dair hizmet", "Yönetici Göreve Başlama Yazısı": "yönetici müdür müdür yardımcısı göreve başlama atama görevlendirme", "Hizmetli Görev Tebliği": "hizmetli görev tebliğ temizlik yardımcı personel", "Güvenlik Görevlisi Görev Tebliği": "güvenlik görevlisi görev tebliğ kapı giriş", "Bahçe Görevlisi Görev Talimatnamesi Tebliği": "bahçe görevlisi talimatname tebliğ peyzaj", "Sürekli İşçi Görev Tebliği (696 KHK)": "sürekli işçi 696 khk görev tebliğ", "TYP Çalışanı Görev Tebliği": "typ toplum yararına program işkur görev tebliğ", "İUP Personeli Görev Tebliği": "iup işgücü uyum programı görev tebliğ", "Mazeret İzni Onay Yazısı": "mazeret izni onay olur izin formu", "Raporu Hastalık (Sıhhi) İznine Çevirme": "sağlık raporu hastalık izni sıhhi izin çevirme olur", "Ders Dışı Eğitim (Egzersiz) Çalışması Oluru": "ders dışı eğitim egzersiz çalışma olur öğrenci listesi", "Devamsızlık Mektubu (İlkokul ve Ortaokul)": "devamsızlık mektubu uyarı veli ilkokul ortaokul 222", "Devamsızlık Mektubu (Ortaöğretim - Lise)": "devamsızlık mektubu uyarı veli lise ortaöğretim", "Öğrenci Belgesi": "öğrenci belgesi devam ediyor kayıtlı belge", "Memur Görev Tebliği": "memur görev tebliğ mutemet evrak arşiv tkys", "Müdür Yardımcısı Görev Tebliği": "müdür yardımcısı görev tebliğ görev dağılımı", "Müdür İzin Yazısı": "müdür izin onay belgesi vekalet yıllık mazeret", "Özlük Dosyası Gönderme Yazısı": "özlük dosyası gönderme atama nakil personel", "Sendika Üyelik Bildirimi": "sendika üyelik bildirimi form giriş mebbis", "Sendika Üyeliğinden Çekilme (İstifa) Bildirimi": "sendika istifa çekilme üyelikten ayrılma", "Yeni Mühür Talep Yazısı": "yeni mühür talep darphane resmi mühür yenileme", "Lüzum Kâğıdı (Doğrudan Temin)": "lüzum kağıdı ihtiyaç doğrudan temin 22/d malzeme", "Yaklaşık Maliyet İçin Fiyat İsteme": "yaklaşık maliyet fiyat isteme piyasa satış fiyatı doğrudan temin firma", "Birim Fiyat Teklif Mektubu": "birim fiyat teklif mektubu doğrudan temin firma teklif cetveli", "Yaklaşık Maliyet Hesaplama Cetveli": "yaklaşık maliyet hesaplama cetveli ortalama fiyat teklif doğrudan temin", "Piyasa Fiyat Araştırma Tutanağı": "piyasa fiyat araştırma tutanağı en uygun teklif firma doğrudan temin 22/d"};
    // NEW (v3.6.37): hazır şablon kategorileri (şablon seçiminde başlıklı gruplar)
    const TPL_CAT_ORDER = ["Genel Yazışmalar", "Tebliğler ve Görevlendirmeler", "Personel ve İzin", "Öğrenci İşleri", "Mali İşler ve Doğrudan Temin"];
    const BUILTIN_TPL_CAT = {"Dönem Sonu Evrak Teslimi Tebliği": "Tebliğler ve Görevlendirmeler", "Sene Sonu Evrak Teslimi Tebliği": "Tebliğler ve Görevlendirmeler", "Sene Başı Görevlendirmeleri Toplu Tebliği": "Tebliğler ve Görevlendirmeler", "Görevden Ayrılma Bilgi Tablosu": "Personel ve İzin", "Ders Programı Tebliğ-Tebellüğ Tutanağı": "Tebliğler ve Görevlendirmeler", "Personele Toplantı Duyurusu (OAB ve Veli Toplantısı)": "Tebliğler ve Görevlendirmeler", "KDV İstisna Belgesi (Eğitime %100 Destek)": "Mali İşler ve Doğrudan Temin", "Sosyal Etkinlik Uygunluk Görüşü": "Öğrenci İşleri", "Öğrenim Durum Belgesi": "Öğrenci İşleri", "Birleştirilmiş Sınıf Ek Ders Ücret Onayı": "Mali İşler ve Doğrudan Temin", "Anasınıfı Banka Ödeme Talimatı": "Mali İşler ve Doğrudan Temin", "Ders Denetimi Tebliğ Yazısı": "Tebliğler ve Görevlendirmeler", "Destek Eğitim Odası Öğretmen Görevlendirme Onayı": "Tebliğler ve Görevlendirmeler", "Diploma Kayıt Örneği": "Öğrenci İşleri", "Eğitsel Değerlendirme İsteği Gönderme": "Öğrenci İşleri", "Görev Yeri Belgesi": "Personel ve İzin", "Yönetici Göreve Başlama Yazısı": "Personel ve İzin", "Hizmetli Görev Tebliği": "Tebliğler ve Görevlendirmeler", "Güvenlik Görevlisi Görev Tebliği": "Tebliğler ve Görevlendirmeler", "Bahçe Görevlisi Görev Talimatnamesi Tebliği": "Tebliğler ve Görevlendirmeler", "Sürekli İşçi Görev Tebliği (696 KHK)": "Tebliğler ve Görevlendirmeler", "TYP Çalışanı Görev Tebliği": "Tebliğler ve Görevlendirmeler", "İUP Personeli Görev Tebliği": "Tebliğler ve Görevlendirmeler", "Mazeret İzni Onay Yazısı": "Personel ve İzin", "Raporu Hastalık (Sıhhi) İznine Çevirme": "Personel ve İzin", "Ders Dışı Eğitim (Egzersiz) Çalışması Oluru": "Öğrenci İşleri", "Devamsızlık Mektubu (İlkokul ve Ortaokul)": "Öğrenci İşleri", "Devamsızlık Mektubu (Ortaöğretim - Lise)": "Öğrenci İşleri", "Öğrenci Belgesi": "Öğrenci İşleri", "Memur Görev Tebliği": "Tebliğler ve Görevlendirmeler", "Müdür Yardımcısı Görev Tebliği": "Tebliğler ve Görevlendirmeler", "Müdür İzin Yazısı": "Personel ve İzin", "Özlük Dosyası Gönderme Yazısı": "Personel ve İzin", "Sendika Üyelik Bildirimi": "Personel ve İzin", "Sendika Üyeliğinden Çekilme (İstifa) Bildirimi": "Personel ve İzin", "Yeni Mühür Talep Yazısı": "Genel Yazışmalar", "Lüzum Kâğıdı (Doğrudan Temin)": "Mali İşler ve Doğrudan Temin", "Yaklaşık Maliyet İçin Fiyat İsteme": "Mali İşler ve Doğrudan Temin", "Birim Fiyat Teklif Mektubu": "Mali İşler ve Doğrudan Temin", "Yaklaşık Maliyet Hesaplama Cetveli": "Mali İşler ve Doğrudan Temin", "Piyasa Fiyat Araştırma Tutanağı": "Mali İşler ve Doğrudan Temin", "Standart Bilgi Verme": "Genel Yazışmalar", "Uygun Görülmedi / Olumsuz": "Genel Yazışmalar", "Komisyon / İnceleme Raporu": "Genel Yazışmalar", "Malzeme / Demirbaş Talep": "Mali İşler ve Doğrudan Temin", "Süre Uzatımı Talebi": "Genel Yazışmalar", "Görevlendirme / Olur": "Tebliğler ve Görevlendirmeler", "İstenen Bilgi ve Belgelerin Gönderilmesi": "Genel Yazışmalar", "Faaliyet / Etkinlik Raporu": "Öğrenci İşleri", "Olumsuz Bildirim (Durum Bulunmamaktadır)": "Genel Yazışmalar", "Duyuru ve Tebliğ Yapıldı": "Tebliğler ve Görevlendirmeler", "Eksik Evrakın Tamamlanması": "Genel Yazışmalar", "Toplantı / Eğitime Katılım Bildirimi": "Genel Yazışmalar", "Ödenek Talebi": "Genel Yazışmalar", "Bakım-Onarım İhtiyacı Bildirimi": "Genel Yazışmalar", "Personel Bilgilerinin Bildirilmesi": "Personel ve İzin", "Bilgi / Belge İstenmesi (Eksik Bilgi)": "Genel Yazışmalar", "Yazının İlgisi Olmadığı / İade": "Genel Yazışmalar", "Web Sitesinde Yayımlandı / Panoda Duyuruldu": "Genel Yazışmalar", "Öğrenci ve Velilere Duyuruldu": "Öğrenci İşleri", "Hizmet İçi Eğitim Katılım Bildirimi": "Genel Yazışmalar", "Olay Bildirimi (Tutanak ve Rapor)": "Genel Yazışmalar", "Denetim / Rehberlik Bulgularının Giderildiği": "Genel Yazışmalar", "Öğrenci Disiplin Kurulu Kararı Bildirimi": "Öğrenci İşleri", "Öğrenci Nakil / Kayıt Bildirimi": "Öğrenci İşleri", "Göreve Başlama Yazısı": "Personel ve İzin", "Görevden Ayrılma Yazısı": "Personel ve İzin", "Ücretli Öğretmen Göreve Başlama": "Personel ve İzin", "Ücretli Öğretmen Görevden Ayrılma": "Personel ve İzin", "İUP / TYP Personeli Göreve Başlama": "Personel ve İzin", "Personel İzin Onayı Bildirimi": "Personel ve İzin", "Aylıksız İzin Dilekçesi Gönderme": "Genel Yazışmalar", "Derece-Kademe İlerlemesi (Terfi)": "Personel ve İzin", "Öğretmen İhtiyacı Bildirimi": "Genel Yazışmalar", "Ek Ders Puantajı Gönderme": "Personel ve İzin", "Toplu Ücret Onayı (Ek Ders Olur)": "Mali İşler ve Doğrudan Temin", "YEĞİTEK Okul Sorumlusu Görevlendirme": "Tebliğler ve Görevlendirmeler", "KBS Yetki Değişikliği": "Personel ve İzin", "TKYS Yetki Değişikliği": "Personel ve İzin", "e-Okul Yeni Şube Açılması": "Öğrenci İşleri", "Öğretmenlere Tebliğ Yazısı": "Tebliğler ve Görevlendirmeler", "Kurul ve Komisyonlar Tebliği": "Tebliğler ve Görevlendirmeler", "Sosyal Kulüpler Tebliği": "Tebliğler ve Görevlendirmeler", "Sınıf Rehber Öğretmenleri Tebliği": "Tebliğler ve Görevlendirmeler", "Belirli Gün ve Haftalar Tebliği": "Tebliğler ve Görevlendirmeler", "Belletici Öğretmen Görevlendirme Onayı": "Tebliğler ve Görevlendirmeler", "Doğrudan Temin Onay Belgesi (Olur)": "Mali İşler ve Doğrudan Temin", "Doğrudan Temin Komisyonu Görevlendirme": "Tebliğler ve Görevlendirmeler", "Teklif İsteme Yazısı": "Mali İşler ve Doğrudan Temin", "Piyasa Fiyat Araştırması Bildirimi": "Mali İşler ve Doğrudan Temin", "Muayene ve Kabul Tutanağı Gönderme": "Mali İşler ve Doğrudan Temin", "Fatura Ödeme Talebi": "Mali İşler ve Doğrudan Temin", "OAB İhtiyaç ve Harcama Talebi": "Mali İşler ve Doğrudan Temin", "OAB Banka Yetkilisi / İmza Sirküleri": "Mali İşler ve Doğrudan Temin", "OAB Ödeme Talimatı": "Mali İşler ve Doğrudan Temin", "Gezi / Sosyal Etkinlik İzin Talebi": "Öğrenci İşleri", "Okul Sosyal Medya Hesabı Oluru": "Genel Yazışmalar", "Güvenli Okul Raporu Gönderme": "Genel Yazışmalar", "Nöbet Çizelgesi Tebliği": "Tebliğler ve Görevlendirmeler", "Veli Toplantısı Yapıldı Bildirimi": "Öğrenci İşleri", "OAB Genel Kurul Sonuç Bildirimi": "Mali İşler ve Doğrudan Temin", "Sağlık Raporu Bildirimi": "Personel ve İzin", "Emeklilik Talebi Gönderme": "Personel ve İzin", "Sınav Görevlendirmesi Bildirimi": "Tebliğler ve Görevlendirmeler", "Taşımalı Eğitim Bilgileri Bildirimi": "Öğrenci İşleri", "Kurum Bilgileri Güncellendi (MEBBİS)": "Genel Yazışmalar"};
    const BUILTIN_TPL_DIR = {"Öğretmenlere Tebliğ Yazısı": "alt", "Kurul ve Komisyonlar Tebliği": "alt", "Sosyal Kulüpler Tebliği": "alt", "Sınıf Rehber Öğretmenleri Tebliği": "alt", "Belirli Gün ve Haftalar Tebliği": "alt", "Teklif İsteme Yazısı": "alt", "OAB İhtiyaç ve Harcama Talebi": "alt", "OAB Banka Yetkilisi / İmza Sirküleri": "alt", "OAB Ödeme Talimatı": "alt", "Nöbet Çizelgesi Tebliği": "alt", "Dönem Sonu Evrak Teslimi Tebliği": "alt", "Sene Sonu Evrak Teslimi Tebliği": "alt", "Sene Başı Görevlendirmeleri Toplu Tebliği": "alt", "Görevden Ayrılma Bilgi Tablosu": "ust", "Ders Programı Tebliğ-Tebellüğ Tutanağı": "alt", "Personele Toplantı Duyurusu (OAB ve Veli Toplantısı)": "alt", "Sosyal Etkinlik Uygunluk Görüşü": "ust", "Birleştirilmiş Sınıf Ek Ders Ücret Onayı": "ust", "Anasınıfı Banka Ödeme Talimatı": "alt", "Ders Denetimi Tebliğ Yazısı": "alt", "Destek Eğitim Odası Öğretmen Görevlendirme Onayı": "ust", "Eğitsel Değerlendirme İsteği Gönderme": "ust", "Yönetici Göreve Başlama Yazısı": "ust", "Hizmetli Görev Tebliği": "alt", "Güvenlik Görevlisi Görev Tebliği": "alt", "Bahçe Görevlisi Görev Talimatnamesi Tebliği": "alt", "Sürekli İşçi Görev Tebliği (696 KHK)": "alt", "TYP Çalışanı Görev Tebliği": "alt", "İUP Personeli Görev Tebliği": "alt", "Mazeret İzni Onay Yazısı": "ust", "Raporu Hastalık (Sıhhi) İznine Çevirme": "ust", "Ders Dışı Eğitim (Egzersiz) Çalışması Oluru": "ust", "Devamsızlık Mektubu (İlkokul ve Ortaokul)": "alt", "Devamsızlık Mektubu (Ortaöğretim - Lise)": "alt", "Memur Görev Tebliği": "alt", "Müdür Yardımcısı Görev Tebliği": "alt", "Müdür İzin Yazısı": "ust", "Sendika Üyelik Bildirimi": "ust", "Sendika Üyeliğinden Çekilme (İstifa) Bildirimi": "ust", "Yeni Mühür Talep Yazısı": "ust", "Lüzum Kâğıdı (Doğrudan Temin)": "ust", "Yaklaşık Maliyet Hesaplama Cetveli": "ust", "Piyasa Fiyat Araştırma Tutanağı": "ust"};
    // v3.6.30: v3.6.29 ve öncesindeki hazır şablon metinleri — kullanıcı deposunda bu metinlerin BİREBİR kopyası varsa (eski sürümün "kaydet" kopyası) yeni metni gölgelemesin diye ayıklanır; düzenlenmiş kayıtlara dokunulmaz.
    const LEGACY_BUILTIN_TEXTS_V3629 = {"Standart Bilgi Verme": "İlgi kayıtlı yazınız ile bildirilen {konu} konulu hususlar incelenmiş olup, gereği mevzuat hükümleri çerçevesinde tamamlanmıştır.\n\nBilgilerinizi ve gereğini arz ederim.", "Uygun Görülmedi / Olumsuz": "İlgi kayıtlı yazınızda talep edilen {konu} hususu müdürlüğümüzce değerlendirilmiş olup, mevcut fiziki ve mevzuat şartları doğrultusunda uygun görülmemiştir.\n\nBilgilerinizi ve gereğini arz ederim.", "Komisyon / İnceleme Raporu": "İlgi kayıtlı yazı gereğince oluşturulan komisyonumuz tarafından {konu} hakkında yapılan incelemeler neticesinde tanzim edilen rapor ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Malzeme / Demirbaş Talep": "Kurumumuz birimlerinde kullanılmak üzere ihtiyaç duyulan {konu} ile ilgili talep yazımız ekte gönderilmektedir.\n\nGereğini ve tensiplerinizi arz ederim.", "Süre Uzatımı Talebi": "İlgi kayıtlı yazınızda belirtilen {konu} konulu işlemlerin eksiksiz ikmal edilebilmesi için ek süreye ihtiyaç duyulmaktadır.\n\nEk süre verilmesi hususunu olurlarınıza arz ederim.", "Görevlendirme / Olur": "İlgi kayıtlı makam oluru gereğince {konu} kapsamında görevlendirilen personel listesi ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "İstenen Bilgi ve Belgelerin Gönderilmesi": "{gönderen} tarafından gönderilen {tarih} tarihli ve {sayı} sayılı ilgi yazı ile istenen {konu} konulu bilgi ve belgeler hazırlanmış olup ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Faaliyet / Etkinlik Raporu": "İlgi yazı gereğince {konu} kapsamında okulumuzda gerçekleştirilen faaliyetlere ilişkin rapor ve görseller ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Olumsuz Bildirim (Durum Bulunmamaktadır)": "{tarih} tarihli ve {sayı} sayılı ilgi yazı ile bildirilmesi istenen {konu} konusunda okulumuzda bildirilmesi gereken herhangi bir durum bulunmamaktadır.\n\nBilgilerinizi ve gereğini arz ederim.", "Duyuru ve Tebliğ Yapıldı": "{konu} konulu ilgi yazı okulumuz personeline duyurulmuş, tebliğ işlemleri tamamlanmış olup tebliğ-tebellüğ listesi ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Eksik Evrakın Tamamlanması": "{tarih} tarihli ve {sayı} sayılı ilgi yazı ile eksikliği bildirilen {konu} konulu evraklar tamamlanarak ekte gönderilmiştir.\n\nBilgilerinizi ve gereğini arz ederim.", "Toplantı / Eğitime Katılım Bildirimi": "{gönderen} tarafından düzenlenen {konu} konulu toplantı/eğitim çalışmasına okulumuzu temsilen katılım sağlayacak personele ait bilgiler ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Ödenek Talebi": "Okulumuzun {konu} kapsamındaki ihtiyaçlarının karşılanabilmesi amacıyla hazırlanan ihtiyaç listesi ve yaklaşık maliyet cetveli ekte sunulmuştur.\n\nGerekli ödeneğin gönderilmesi hususunda gereğini arz ederim.", "Bakım-Onarım İhtiyacı Bildirimi": "Okulumuz binasında {konu} ile ilgili olarak yapılan incelemede bakım-onarım ihtiyacı tespit edilmiş olup, tespit tutanağı ve fotoğraflar ekte sunulmuştur.\n\nGereğini arz ederim.", "Personel Bilgilerinin Bildirilmesi": "{tarih} tarihli ve {sayı} sayılı ilgi yazı gereğince {konu} kapsamında istenen personel bilgileri belirtilen formata işlenerek ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Bilgi / Belge İstenmesi (Eksik Bilgi)": "{tarih} tarihli ve {sayı} sayılı yazınız incelenmiştir.\n\nYazınızda belirtilen {konu} hususunun değerlendirilebilmesi için aşağıda belirtilen bilgi ve belgelerin ........ tarihine kadar Müdürlüğümüze iletilmesi gerekmektedir.\n\n1. ........\n2. ........\n\nBilgilerinizi ve gereğini rica ederim.", "Yazının İlgisi Olmadığı / İade": "{tarih} tarihli ve {sayı} sayılı yazınız incelenmiş olup, söz konusu yazı ........ Müdürlüğünün görev alanına girdiğinden ilgisi nedeniyle iade edilmiştir.\n\nGereğini arz ederim.", "Web Sitesinde Yayımlandı / Panoda Duyuruldu": "{konu} konulu ilgi yazı okulumuz internet sitesinde yayımlanmış, okul panolarında ilan edilmiş ve ilgili personele duyurulmuştur.\n\nBilgilerinizi arz ederim.", "Öğrenci ve Velilere Duyuruldu": "{konu} konulu ilgi yazıda belirtilen hususlar okulumuz öğrencilerine ve velilerine duyurulmuş, gerekli bilgilendirme çalışmaları tamamlanmıştır.\n\nBilgilerinizi arz ederim.", "Hizmet İçi Eğitim Katılım Bildirimi": "{gönderen} tarafından düzenlenen {konu} konulu hizmet içi eğitim faaliyetine okulumuzdan katılım sağlayan personelin listesi ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Olay Bildirimi (Tutanak ve Rapor)": "Okulumuzda ........ tarihinde meydana gelen olayla ilgili düzenlenen tutanak ve olay raporu ekte sunulmuştur. Olayla ilgili gerekli idari ve güvenlik tedbirleri alınmış olup gelişmeler hakkında ayrıca bilgi verilecektir.\n\nBilgilerinizi arz ederim.", "Denetim / Rehberlik Bulgularının Giderildiği": "........ tarihinde yapılan denetim/rehberlik çalışması sonucunda tespit edilen eksikliklerin giderilmesine yönelik işlemler tamamlanmış olup, yapılan düzeltmelere ilişkin belgeler ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Öğrenci Disiplin Kurulu Kararı Bildirimi": "Okulumuz ........ sınıfı öğrencisi ........ hakkında ........ tarihinde toplanan Okul Disiplin Kurulunca alınan karar ve ilgili evrak ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Öğrenci Nakil / Kayıt Bildirimi": "Okulumuz ........ sınıfı ........ numaralı öğrencisi ........'ın nakil işlemleri ilgili mevzuata uygun olarak tamamlanmış olup, öğrenci dosyası ve nakil belgeleri ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Göreve Başlama Yazısı": "Müdürlüğünüzün ........ tarihli ve ........ sayılı oluru ile okulumuza ........ branşında atanan ........ ........ tarihi itibarıyla göreve başlamıştır.\n\nBilgilerinizi ve gereğini arz ederim.", "Görevden Ayrılma Yazısı": "Okulumuzda ........ olarak görev yapan ........ ........ tarihli ve ........ sayılı onay gereğince ........ tarihi itibarıyla okulumuzdaki görevinden ayrılmıştır. Kişinin okulumuzla ilişiği bulunmadığına dair belge ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Ücretli Öğretmen Göreve Başlama": "Müdürlüğünüzün ........ tarihli ve ........ sayılı onayı ile okulumuzda ücretli öğretmen olarak görevlendirilen ........ branş öğretmeni ........ ........ tarihi itibarıyla haftalık ........ ders saati ile göreve başlamıştır.\n\nBilgilerinizi ve gereğini arz ederim.", "Ücretli Öğretmen Görevden Ayrılma": "Okulumuzda ücretli öğretmen olarak görev yapan ........ branş öğretmeni ........ ........ tarihi itibarıyla görevinden ayrılmıştır.\n\nBilgilerinizi ve gereğini arz ederim.", "İUP / TYP Personeli Göreve Başlama": "İŞKUR aracılığıyla İşgücü Uyum Programı kapsamında okulumuzda görevlendirilen ........ ........ tarihi itibarıyla göreve başlamıştır.\n\nBilgilerinizi ve gereğini arz ederim.", "Personel İzin Onayı Bildirimi": "Okulumuzda ........ olarak görev yapan ........'ın ........ tarihleri arasında ........ gün ........ izin kullanması uygun görülmüş olup, izin onay belgesi ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Aylıksız İzin Dilekçesi Gönderme": "Okulumuzda ........ olarak görev yapan ........'ın ........ tarihli aylıksız izin talebine ilişkin dilekçesi ve ekleri ekte sunulmuştur.\n\nSöz konusu talebin değerlendirilerek sonucunun bildirilmesi hususunda gereğini arz ederim.", "Derece-Kademe İlerlemesi (Terfi)": "Okulumuzda ........ olarak görev yapan ........'ın ........ tarihi itibarıyla derece/kademe ilerlemesi yapılması gerekmektedir. Terfi bilgi formu ve onaylı hizmet cetveli ekte sunulmuştur.\n\nGereğini arz ederim.", "Öğretmen İhtiyacı Bildirimi": "Okulumuzun ........ branşında haftalık ........ ders saati öğretmen ihtiyacı bulunmaktadır. Norm kadro durumu ve ders dağılım çizelgesi ekte sunulmuştur.\n\nİhtiyacın karşılanması hususunda gereğini arz ederim.", "Ek Ders Puantajı Gönderme": "Okulumuzda görev yapan öğretmenlere ait ........ ayı ek ders puantaj çizelgeleri ve ekleri düzenlenerek ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Toplu Ücret Onayı (Ek Ders Olur)": "Okulumuzda ........ ayında yürütülen ek ders ve ek görevlere ilişkin toplu ücret onayı ekte sunulmuştur.\n\nOlurlarınıza arz ederim.", "YEĞİTEK Okul Sorumlusu Görevlendirme": "Okulumuzda bilişim teknolojileri hizmetlerinin yürütülmesi amacıyla ........ branş öğretmeni ........ YEĞİTEK Okul Sorumlusu olarak görevlendirilmiştir. Görevlendirme onayı ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "KBS Yetki Değişikliği": "Kamu Harcama ve Muhasebe Bilişim Sistemi (KBS) üzerinde okulumuz adına yetkilendirilmiş kullanıcı bilgilerinde değişiklik yapılması gerekmektedir. ........ yerine ........ yetkilendirilmesi hususunda gereğini arz ederim.", "TKYS Yetki Değişikliği": "Taşınır Kayıt ve Yönetim Sistemi (TKYS) üzerinde okulumuz adına yetkilendirilmiş kullanıcı bilgilerinde değişiklik yapılması gerekmektedir. ........ yerine ........ yetkilendirilmesi hususunda gereğini arz ederim.", "e-Okul Yeni Şube Açılması": "Okulumuzun ........ sınıf düzeyinde ........ öğrenci mevcudu bulunduğundan, e-Okul sisteminde ........ şubesinin açılması hususunda gereğini arz ederim.", "Öğretmenlere Tebliğ Yazısı": "{konu} konulu yazı bilgi ve gereği için okulumuz öğretmenlerine tebliğ edilmek üzere ilişikte sunulmuştur.\n\nTebliğ-tebellüğ belgesinin imzalanarak ........ tarihine kadar okul idaresine teslim edilmesini rica ederim.", "Kurul ve Komisyonlar Tebliği": "Okulumuzda ........ eğitim öğretim yılında görev yapacak kurul ve komisyonlar ekte sunulmuştur.\n\nGörevlendirilen personelin ilgili mevzuat doğrultusunda görevlerini yürütmesini rica ederim.", "Sosyal Kulüpler Tebliği": "Okulumuzda ........ eğitim öğretim yılında faaliyet gösterecek sosyal kulüpler ve kulüp danışman öğretmenleri ekte sunulmuştur.\n\nGörevlendirilen öğretmenlerin kulüp çalışmalarını ilgili yönetmelik hükümlerine göre yürütmelerini rica ederim.", "Sınıf Rehber Öğretmenleri Tebliği": "Okulumuzda ........ eğitim öğretim yılında şube rehber öğretmenliği yapacak öğretmenlerin listesi ekte sunulmuştur.\n\nGörevlendirilen öğretmenlerin görevlerini ilgili mevzuata uygun olarak yürütmelerini rica ederim.", "Belirli Gün ve Haftalar Tebliği": "Okulumuzda ........ eğitim öğretim yılında kutlanacak/anılacak belirli gün ve haftalara ilişkin görev dağılımı ekte sunulmuştur.\n\nGörevlendirilen öğretmenlerin hazırlıklarını zamanında tamamlamasını rica ederim.", "Belletici Öğretmen Görevlendirme Onayı": "Okulumuz pansiyonunda ........ eğitim öğretim yılında nöbet görevi yapmak üzere belletici öğretmen görevlendirmesine ilişkin liste ekte sunulmuştur.\n\nOlurlarınıza arz ederim.", "Doğrudan Temin Onay Belgesi (Olur)": "Okulumuzun ihtiyacı olan ........ alımının 4734 sayılı Kamu İhale Kanunu'nun 22. maddesinin (d) bendi uyarınca doğrudan temin yöntemiyle yapılması için hazırlanan onay belgesi ekte sunulmuştur.\n\nOlurlarınıza arz ederim.", "Doğrudan Temin Komisyonu Görevlendirme": "Okulumuzun ihtiyacı olan ........ alımına ilişkin doğrudan temin işlemlerinin yürütülmesi amacıyla aşağıdaki personel komisyon üyesi olarak görevlendirilmiştir.\n\n1. ........ (Başkan)\n2. ........ (Üye)\n3. ........ (Üye)\n\nBilgilerinizi ve gereğini arz ederim.", "Teklif İsteme Yazısı": "Okulumuzun ihtiyacı olan ........ alımı doğrudan temin yöntemiyle yapılacaktır. Ekte özellikleri belirtilen ürün/hizmet için KDV hariç birim fiyat teklifinizin ........ tarihine kadar okulumuza iletilmesini rica ederim.", "Piyasa Fiyat Araştırması Bildirimi": "Okulumuzun ihtiyacı olan ........ alımı için yapılan piyasa fiyat araştırması sonucunda düzenlenen fiyat araştırma tutanağı ve yaklaşık maliyet cetveli ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim.", "Muayene ve Kabul Tutanağı Gönderme": "Okulumuz tarafından temin edilen ........ ile ilgili Muayene ve Kabul Komisyonunca düzenlenen tutanak ile fatura ekte sunulmuştur.\n\nÖdeme işlemlerinin yapılması hususunda gereğini arz ederim.", "Fatura Ödeme Talebi": "Okulumuzun ........ dönemine ait ........ faturası ekte sunulmuş olup ödenmesi hususunda gereğini arz ederim.", "OAB İhtiyaç ve Harcama Talebi": "Okul Aile Birliğimiz tarafından ........ ihtiyacının karşılanması amacıyla yapılması planlanan harcamaya ilişkin ihtiyaç listesi ve yaklaşık maliyet bilgisi ekte sunulmuştur.\n\nHarcamanın yapılabilmesi için gereğini ve olurlarınıza arz ederim.", "OAB Banka Yetkilisi / İmza Sirküleri": "Okul Aile Birliği hesabı üzerinde işlem yapmaya yetkili kişilerde yapılan değişikliğe ilişkin Yönetim Kurulu kararı ve imza sirküleri ekte sunulmuştur.\n\nGereğini arz ederim.", "OAB Ödeme Talimatı": "Okul Aile Birliği hesabından ........ TL tutarındaki ödemenin ........ adına yapılması hususunda ödeme talimatı ekte sunulmuştur.\n\nGereğini arz ederim.", "Gezi / Sosyal Etkinlik İzin Talebi": "Okulumuz ........ sınıfı öğrencileriyle ........ tarihinde ........ yerine gezi/etkinlik düzenlenmesi planlanmaktadır. Gezi planı, veli izin belgeleri ve görevlendirilen öğretmen listesi ekte sunulmuştur.\n\nSöz konusu etkinliğin yapılabilmesi için gereğini ve olurlarınıza arz ederim.", "Okul Sosyal Medya Hesabı Oluru": "Okulumuzun resmî tanıtımı ve duyuruların yapılması amacıyla ........ platformunda ........ kullanıcı adıyla sosyal medya hesabı açılması planlanmaktadır. Hesabın yönetiminden ........ görevlendirilmiştir.\n\nOlurlarınıza arz ederim.", "Güvenli Okul Raporu Gönderme": "Okulumuzda ........ tarihinde yapılan Güvenli Okul çalışmalarına ilişkin rapor ve ekleri ekte sunulmuştur.\n\nBilgilerinizi ve gereğini arz ederim."};
    // NEW: kullanıcı şablonları uzantı deposunda tutulur (v3.2); mevcut kayıtlar taşınır, ilk kurulumda boş başlar
    let savedReplyTemplates = loadJSON("ebys_reply_templates_v2", {}, isValidTemplates); // FIX: güvenli yükleme
    function saveTemplatesToStorage() { extStoreSet("ebys_reply_templates_v2", savedReplyTemplates); }
    // NEW: eski sürümün kaydettiği, hazır şablonla birebir aynı kayıtlar kullanıcı listesinde çift görünmesin
    const LEGACY_SURE_UZATIMI = "İlgi kayıtlı yazınızda belirtilen {konu} konulu işlemlerin eksiksiz ikmal edilebilmesi için ek süreye ihtiyaç duyulmakta olup, ek süre verilmesi hususunu.\n\nOlur/Tensiplerinize arz ederim.";
    Object.keys(savedReplyTemplates).forEach(k => {
        if (savedReplyTemplates[k] === BUILTIN_TEMPLATES[k] || savedReplyTemplates[k] === LEGACY_BUILTIN_TEXTS_V3629[k] || (k === "Süre Uzatımı Talebi" && savedReplyTemplates[k] === LEGACY_SURE_UZATIMI)) delete savedReplyTemplates[k];
    });
    // NEW: gizlenen hazır şablonlar
    const isValidNameList = v => Array.isArray(v) && v.every(x => typeof x === "string");
    let hiddenBuiltinTemplates = loadJSON("ebys_hidden_builtin_tpl_v1", [], isValidNameList);
    function saveHiddenBuiltinsToStorage() { extStoreSet("ebys_hidden_builtin_tpl_v1", hiddenBuiltinTemplates); }
    // NEW: etkin şablonlar = görünür hazır şablonlar + kullanıcı şablonları (aynı adda kullanıcınınki geçerlidir)
    function getEffectiveTemplates() {
        const out = {};
        Object.keys(BUILTIN_TEMPLATES).forEach(k => { if (!hiddenBuiltinTemplates.includes(k)) out[k] = BUILTIN_TEMPLATES[k]; });
        Object.keys(savedReplyTemplates).forEach(k => { out[k] = savedReplyTemplates[k]; });
        return out;
    }

    // v3.6.30: yazı yönü (kapanış seçimi) — ayar uzantı deposunda: { global: "oto"|"ust"|"alt"|"esit", perTpl: { ad: yön } }
    const TPL_DIR_KEY = "ebys_tpl_dir_v1";
    const TPL_DIRS = ["oto", "ust", "alt", "esit"];
    const isValidTplDir = v => isPlainObject(v) && (v.global === undefined || TPL_DIRS.includes(v.global)) && (v.perTpl === undefined || (isPlainObject(v.perTpl) && Object.values(v.perTpl).every(x => TPL_DIRS.includes(x))));
    let tplDirSettings = loadJSON(TPL_DIR_KEY, { global: "oto", perTpl: {} }, isValidTplDir);
    function saveTplDir() { extStoreSet(TPL_DIR_KEY, tplDirSettings); }
    function detectDirFromSender(g) {
        const t = String(g || "").toLocaleLowerCase("tr-TR");
        if (!t.trim()) return "";
        if (/bakanl|genel müdürl|valilik|valiliği|kaymakaml|il milli eğitim|ilçe milli eğitim|milli eğitim müdürl|başkanlığ|rektörl|daire başkan/.test(t)) return "ust";
        if (/okulu|lisesi|ortaokul|ilkokul|anaokul|merkezi|kolej|müdürlüğü/.test(t)) return "esit";
        return "";
    }
    function resolveTplDir(name, gonderen) {
        const g = tplDirSettings.global || "oto";
        if (g !== "oto") return g;
        const per = tplDirSettings.perTpl && tplDirSettings.perTpl[name];
        if (per && per !== "oto") return per;
        if (BUILTIN_TPL_DIR[name]) return BUILTIN_TPL_DIR[name];
        return detectDirFromSender(gonderen) || "ust";
    }
    const CLOSINGS = {
        bilgi: ["Bilgilerinize arz ederim.", "Bilgilerinizi rica ederim."],
        gereg: ["Bilgilerinizi ve gereğini arz ederim.", "Bilgilerinizi ve gereğini rica ederim."],
        gerek: ["Gereğini arz ederim.", "Gereğini rica ederim."],
        gerek2: ["gereğini arz ederim.", "gereğini rica ederim."],
        rica: ["arz ederim.", "rica ederim."],
        olurtalep: ["olurlarınıza arz ederim.", "olurlarınıza arz ederim."]
    };
    function applyClosingTokens(tpl, dir) {
        const i = dir === "ust" ? 0 : 1;
        return String(tpl).replace(/\{\s*kapan[ıi][şs]\s*:\s*([a-z0-9]+)\s*\}/gi, (m, k) => { const c = CLOSINGS[String(k).toLowerCase()]; return c ? c[i] : m; });
    }

    // =========================================================================
    // 3. MAKRO MOTORU - SEÇİCİ TABANLI GÜÇLENDİRİLMİŞ
    // =========================================================================
    let savedMacros = loadJSON("ebys_macro_records_v1", {}, isValidMacros); // FIX: güvenli yükleme
    let isRecording = false;
    let currentRecordingSteps = [];
    let isPlayingMacro = false;
    let recordingFrameTag = (window.self === window.top) ? "TOP" : "IFRAME";

    function saveMacrosToStorage() {
        extStoreSet("ebys_macro_records_v1", savedMacros);
        if (window.self === window.top) updateMacroDropdown();
    }

    function recordStep(step) {
        if (!isRecording) return;
        currentRecordingSteps.push(step);
        try { window.top.postMessage({ type: "EBYS_MACRO_STEP_ADDED", step: step }, "/"); } catch(e) {} // FIX: yalnızca aynı origin
    }

    let topMacroSteps = [];

    // FIX: eksik fonksiyonlar tanımlandı — ilgili UI öğesi varsa günceller, yoksa sessizce geçer
    function updateMacroDropdown() {
        const sel = document.getElementById("ebys-macro-select");
        if (!sel) return;
        sel.innerHTML = "";
        Object.keys(savedMacros).forEach(name => {
            const o = document.createElement("option");
            o.value = name; o.textContent = name;
            sel.appendChild(o);
        });
    }
    function updateRecordingStatusUI() {
        const el = document.getElementById("ebys-record-status");
        if (el) el.textContent = topMacroSteps.length + " adım";
    }

    window.addEventListener("message", function(e) {
        if (!isTrustedMessage(e)) return; // FIX: origin/kaynak kontrolü
        if (e.data.type === "EBYS_RECORDING_START") {
            if (window.self === window.top) topMacroSteps = [];
            else { isRecording = true; currentRecordingSteps = []; }
            return;
        }
        if (e.data.type === "EBYS_RECORDING_STOP") { isRecording = false; return; }
        if (e.data.type === "EBYS_MACRO_STEP_ADDED" && window.self === window.top) {
            topMacroSteps.push(e.data.step);
            updateRecordingStatusUI();
            return;
        }
    });

    function initMacroRecorderListeners(targetWindow) {
        try {
            const doc = targetWindow.document;
            if (doc.__ebysMacroListenerAdded) return;
            doc.__ebysMacroListenerAdded = true;

            doc.addEventListener("click", function(e) {
                if (!isRecording || isPlayingMacro) return;
                const el = e.target;
                if (!el || !el.closest) return;
                if (el.closest("#ebys-inbox-panel") || el.closest("#ebys-toggle-handle") || el.closest("#ebys-record-floater")) return;
                const text = (el.innerText || el.value || el.getAttribute("title") || "").trim();
                recordStep({
                    type: "click",
                    text: text.substring(0, 60),
                    id: el.getAttribute("id") || "",
                    name: el.getAttribute("name") || "",
                    className: el.className || "",
                    tagName: el.tagName.toLowerCase(),
                    frameOrigin: recordingFrameTag
                });
            }, true);

            doc.addEventListener("change", function(e) {
                if (!isRecording || isPlayingMacro) return;
                const el = e.target;
                if (!el || !el.closest || el.closest("#ebys-inbox-panel")) return;
                const tagName = el.tagName.toLowerCase();
                if (["input", "textarea", "select"].includes(tagName)) {
                    recordStep({
                        type: "fill",
                        val: el.value,
                        tagName: tagName,
                        name: el.getAttribute("name") || "",
                        id: el.getAttribute("id") || "",
                        frameOrigin: recordingFrameTag
                    });
                }
            }, true);
        } catch(err) {}
    }

    function attachListenersToAllFrames() {
        initMacroRecorderListeners(window);
        document.querySelectorAll("iframe, frame").forEach(f => {
            try { if (f.contentWindow) initMacroRecorderListeners(f.contentWindow); } catch(e) {}
            // FIX: çerçeve sonradan (yeniden) yüklenirse dinleyiciler tekrar eklenir
            // NEW: "load" dinleyicisi çerçeve başına bir kez eklenir (kendi kendini onarma sırasında birikmesin)
            try { if (!f.__ebysLoadHooked) { f.__ebysLoadHooked = true; f.addEventListener("load", () => { try { initMacroRecorderListeners(f.contentWindow); } catch(e) {} }); } } catch(e) {}
        });
    }

    let frameObserver = null; // NEW: <body> değişirse yeniden bağlanabilmek için
    try {
        const obs = frameObserver = new MutationObserver(muts => {
            muts.forEach(m => {
                m.addedNodes.forEach(node => {
                    if (node.nodeType === 1) {
                        if (node.tagName === "IFRAME" || node.tagName === "FRAME") {
                            try { if (node.contentWindow) initMacroRecorderListeners(node.contentWindow); } catch(e) {}
                            // FIX: çerçeve yüklenince belge değişir; dinleyiciler yeni belgeye tekrar eklenir
                            node.addEventListener("load", () => { try { initMacroRecorderListeners(node.contentWindow); } catch(e) {} });
                        }
                        if (node.querySelectorAll) {
                            node.querySelectorAll("iframe, frame").forEach(f => {
                                try { if (f.contentWindow) initMacroRecorderListeners(f.contentWindow); } catch(e) {}
                            });
                        }
                    }
                });
            });
        });
        if (document.body) obs.observe(document.body, { childList: true, subtree: true });
        else document.addEventListener("DOMContentLoaded", () => obs.observe(document.body, { childList: true, subtree: true }));
    } catch(e) {}

    // =========================================================================
    // 4. MAKRO OYNATMA
    // =========================================================================
    async function playSelectedMacro(macroName) {
        const macro = savedMacros[macroName];
        if (!macro || !macro.steps || macro.steps.length === 0) {
            alert("Çalıştırılacak işlem adımı bulunamadı.");
            return;
        }

        isPlayingMacro = true;
        const playBtn = document.getElementById("btn-play-macro");
        if (playBtn) { playBtn.disabled = true; playBtn.innerText = "⏳ İŞLENİYOR..."; }

        for (let i = 0; i < macro.steps.length; i++) {
            const step = macro.steps[i];
            await new Promise(res => setTimeout(res, 800));
            const docs = getAllDocs();
            let actionDone = false;

            if (step.type === "click") {
                for (let doc of docs) {
                    let targetEl = null;
                    if (step.id) targetEl = doc.getElementById(step.id);
                    if (!targetEl && step.name) targetEl = doc.querySelector(`[name="${step.name}"]`);
                    if (!targetEl && step.text) {
                        const allEls = doc.querySelectorAll("button, a, span, div, td, tr, li");
                        for (let el of allEls) {
                            if (el.closest("#ebys-inbox-panel")) continue;
                            if ((el.innerText || "").trim().includes(step.text)) { targetEl = el; break; }
                        }
                    }
                    if (targetEl) {
                        const clickTarget = targetEl.closest("button, a, tr") || targetEl;
                        clickTarget.scrollIntoView({ behavior: "smooth", block: "center" });
                        try {
                            clickTarget.click();
                            actionDone = true;
                            break;
                        } catch(e) {}
                    }
                }
            } else if (step.type === "fill") {
                for (let doc of docs) {
                    let inp = null;
                    if (step.id) inp = doc.getElementById(step.id);
                    if (!inp && step.name) inp = doc.querySelector(`[name="${step.name}"]`);
                    if (inp) {
                        setNativeValue(inp, step.val);
                        actionDone = true;
                        break;
                    }
                }
            }
        }

        isPlayingMacro = false;
        if (playBtn) { playBtn.disabled = false; playBtn.innerText = "▶ ÇALIŞTIR"; }
        alert(`🤖 "${macroName}" protokolü tamamlandı.`);
    }

    // =========================================================================
    // 5. EVRAK AÇMA & KAPATMA
    // =========================================================================
    // =========================================================================
    // NEW (v3): GERÇEK EBYS (Belgenet / edys-web) YAPISI — kaydedilmiş gerçek sayfalardan çıkarıldı
    //   Menü    : #leftMenuForm:leftMenuIslemBekleyenEvraklar  a.ui-menuitem-link[onclick*="leftMenu.masamdakiEvraklar.gelenEvraklar"]  "Gelen Evraklar (okunmamış/toplam)"
    //   Tablo   : #mainInboxForm:inboxDataTable  > tbody#…_data > tr[data-ri][data-rk]  (satır içinde iç içe ui-panelgrid tablo; .ui-inbox-satir1..4)
    //   Sayfa   : #mainInboxForm:inboxDataTable_paginator_top (a.ui-paginator-page / -next / -first, select.ui-paginator-rpp-options)
    //   Önizleme: #mainPreviewForm (araç çubuğu: Cevap Yaz / Evrak Kapat …; iframe.onizlemeFrame = pdf.js; table.onizlemeTarih; ekListesiOnizlemeDataTableBase)
    //   Kapatma : fieldset[id$="evrakKapatFieldsetId"] (konuKoduLov, klasorLov_id, notTextArea_id, button[id$="onaysizKapatId"])
    //   Cevap   : #windowCevapEvrakDialog  (sol menü düğmeleri: Bilgileri / Editör …; CKEditor "windowCevapEvrakForm:ckeditorInstance_windowN")
    // =========================================================================
    const INBOX_MENU_TAG = "leftMenu.masamdakiEvraklar.gelenEvraklar";
    function dbg(...a) { try { console.log("[Evrak Asistanı]", ...a); } catch(e) {} }
    // v3.6.10: ⏹ DURDUR altyapısı — AUTO.stop yalnızca bir otomasyon sürerken (depth>0) kurulur; sleep/waitFor hemen "Durduruldu" hatası fırlatır
    const EXT_VERSION = (() => { try { return chrome.runtime.getManifest().version || "3.6.42"; } catch(e) { return "3.6.42"; } })(); // v3.6.41: tek kaynak manifest.json
    let lastAutoRec = "";
    const AUTO = { stop: false, depth: 0 };
    let waitCapUntil = 0, waitHardUntil = 0, gerekFailStreak = 0, lastGerekFailed = false, gerekHang = false, gerekPfTrusted = false; // v3.6.14/15; v3.6.56: gerekHang/gerekPfTrusted
    function capExpired() {
        if (!waitCapUntil) return false;
        const now = Date.now();
        if (now >= waitHardUntil) return true;
        // EBYS örtüsü açıkken sayaç işlemez: örtü kapandıktan sonra listenin gelmesi için en az 6 sn kalır
        if (bekleyinizVisible()) { waitCapUntil = Math.max(waitCapUntil, Math.min(waitHardUntil, now + 6000)); return false; }
        return now >= waitCapUntil;
    }
    const stopErr = () => { const e = new Error("Durduruldu"); e.ebysStop = true; return e; };
    function autoCheck() { if (AUTO.stop) throw stopErr(); }
    const sleep = (ms) => { const t0 = Date.now(), w = ms > 250 ? (function() { try { return stepLabel(stepWhere(4)); } catch(e) { return "?"; } })() : null; return new Promise((r, j) => setTimeout(() => { if (w) { try { stepLog("sleep " + w, t0, "sabit"); } catch(e) {} } (AUTO.stop ? j(stopErr()) : r()); }, ms)); };
    // v3.6.16: ⏹ DURDUR — KÖK NEDEN: otomasyon EBYS'nin iç çerçevesinde (iframe) çalışırken düğüm yalnızca "window.self === window.top" iken
    // çiziliyordu; üst pencerede AUTO.depth = 0 olduğundan düğme ya hiç çıkmıyor ya da üstteki yenileme döngüsünce kaldırılıyordu.
    // Artık: düğme YALNIZCA üst belgede (document.documentElement'e) çizilir; her çerçeve çalışma durumunu üst pencereye bildirir (postMessage, 1 sn kalp atışı);
    // üst pencerede düğmeye basılınca durdurma komutu tüm çerçevelere yayılır. Kaydedilmiş konum görünür alana kırpılır.
    const STOP_FRAME_ID = "f" + Math.random().toString(36).slice(2);
    const stopFrames = {}; // yalnızca üstte: çerçeve kimliği → son kalp atışı
    function postAutoState() {
        if (window.self === window.top) return;
        try { window.top.postMessage({ type: "EBYS_AUTO_STATE", fid: STOP_FRAME_ID, depth: AUTO.depth }, "*"); } catch(e) {}
    }
    function broadcastStop(win) {
        try { for (let k = 0; k < win.frames.length; k++) { try { win.frames[k].postMessage({ type: "EBYS_AUTO_STOP" }, "*"); } catch(e) {} broadcastStop(win.frames[k]); } } catch(e) {}
    }
    window.addEventListener("message", (ev) => {
        const d = ev.data;
        if (!d || typeof d !== "object") return;
        try { if (!/^https:\/\/ebys\.meb\.gov\.tr$/.test(ev.origin) && ev.origin !== location.origin) return; } catch(e) { return; }
        if (d.type === "EBYS_AUTO_STATE" && window.self === window.top && typeof d.fid === "string") {
            if (d.depth > 0) stopFrames[d.fid] = Date.now(); else delete stopFrames[d.fid];
            renderStopBtn();
        } else if (d.type === "EBYS_AUTO_STOP") {
            if (AUTO.depth > 0) AUTO.stop = true;
        }
    });
    function anyAutoRunning() {
        if (AUTO.depth > 0) return true;
        const now = Date.now();
        Object.keys(stopFrames).forEach(k => { if (now - stopFrames[k] > 3500) delete stopFrames[k]; });
        return Object.keys(stopFrames).length > 0;
    }
    function renderStopBtn() {
        if (window.self !== window.top) { postAutoState(); return; }
        try {
            let b = document.getElementById("ebys-stop-btn");
            if (b && !b.isConnected) b = null;
            if (anyAutoRunning()) {
                if (!b) {
                    b = document.createElement("button");
                    b.id = "ebys-stop-btn"; b.type = "button"; b.textContent = "⏹ Durdur";
                    const pos = extStoreGet("ebys_stop_btn_pos_v1");
                    const leftPct = pos && typeof pos.leftPct === "number" && isFinite(pos.leftPct) ? Math.min(95, Math.max(5, pos.leftPct)) : 50;
                    b.style.cssText = "position:fixed; bottom:14px; left:" + leftPct + "%; transform:translateX(-50%); z-index:2147483647; pointer-events:auto; cursor:grab; user-select:none; background:#DC2626; color:#fff; border:2px solid #fff; border-radius:10px; padding:8px 18px; font:bold 14px sans-serif; box-shadow:0 4px 14px rgba(0,0,0,.4);";
                    b.title = "Durdur — sağa/sola sürükleyerek yerini değiştirebilirsiniz";
                    let drag = null, moved = false;
                    b.addEventListener("pointerdown", e => { drag = { x: e.clientX }; moved = false; try { b.setPointerCapture(e.pointerId); } catch(x) {} });
                    b.addEventListener("pointermove", e => {
                        if (!drag) return;
                        if (Math.abs(e.clientX - drag.x) > 4) moved = true;
                        if (moved) b.style.left = Math.min(95, Math.max(5, e.clientX / Math.max(1, window.innerWidth) * 100)) + "%";
                    });
                    b.addEventListener("pointerup", () => { if (drag && moved) { try { extStoreSet("ebys_stop_btn_pos_v1", { leftPct: parseFloat(b.style.left) }); } catch(x) {} } drag = null; });
                    b.onclick = (e) => {
                        if (moved) { moved = false; e.preventDefault(); return; }
                        if (AUTO.depth > 0) AUTO.stop = true;
                        broadcastStop(window);
                        b.textContent = "⏹ Durduruluyor…"; b.disabled = true;
                    };
                }
                // her zaman en üstte ve görünür alanda: <html>'in son çocuğu (PrimeFaces örtüleri body'ye eklenir)
                if (b.parentNode !== document.documentElement || b.nextSibling) document.documentElement.appendChild(b);
                b.style.display = ""; b.style.zIndex = "2147483647";
                const r = b.getBoundingClientRect();
                if (r.right < 20 || r.left > window.innerWidth - 20) b.style.left = "50%";
            } else if (b) b.remove();
        } catch(e) {}
    }
    setInterval(() => { if (window.self === window.top) { if (anyAutoRunning() || document.getElementById("ebys-stop-btn")) renderStopBtn(); } else if (AUTO.depth > 0) postAutoState(); }, 1000);
    async function autoWrap(name, fn) {
        if (AUTO.depth === 0) AUTO.stop = false;
        AUTO.depth++; renderStopBtn();
        if (!autoWrap.keep) autoWrap.keep = setInterval(() => { if (AUTO.depth > 0) renderStopBtn(); else { clearInterval(autoWrap.keep); autoWrap.keep = null; } }, 700);
        try { return await fn(); }
        catch(e) {
            if (e && e.ebysStop) { try { showToast(bekleyinizVisible() ? "⏹ Eklenti durdu. EBYS hâlâ bekliyor; düzelmezse sayfayı yenileyin (F5)." : "⏹ Durduruldu (" + name + "). EBYS formu olduğu gibi bırakıldı.", "warn"); } catch(x) {} return { ok: false, stopped: true, msg: "Durduruldu" }; }
            throw e;
        } finally {
            AUTO.depth = Math.max(0, AUTO.depth - 1);
            if (AUTO.depth === 0) { AUTO.stop = false; try { setScanButtons(false); } catch(x) {} }
            renderStopBtn();
        }
    }
    // Onay Akışı (akisLov / akisAdimLov) ve satırı: hiçbir otomasyon olayı gönderilmez
    function isForbiddenEl(el) {
        try {
            if (!el || !el.closest) return false;
            if (el.closest('[id*="akisLov"], [id*="akisAdimLov"]')) return true;
            const tr = el.closest("tr");
            return !!(tr && tr.querySelector('[id*="akisLov"], [id*="akisAdimLov"]') && !tr.querySelector('[id*="lovDialogId"]'));
        } catch(e) { return false; }
    }

    function parseMenuCount(link) {
        const t = link ? (link.textContent || "") : "";
        let m = t.match(/\(\s*(\d+)\s*\/\s*(\d+)\s*\)/);
        if (m) return { unread: +m[1], total: +m[2] };
        m = t.match(/\(\s*(\d+)\s*\)/);
        return m ? { unread: null, total: +m[1] } : null;
    }
    function getInboxRoot() {
        return document.getElementById("mainInboxForm:inboxDataTable") || document.querySelector('.ui-datatable[id$=":inboxDataTable"], .ui-datatable.ui-inbox-table');
    }
    function getInboxBody() {
        const r = getInboxRoot();
        return r ? (r.querySelector('tbody[id$="inboxDataTable_data"]') || r.querySelector("tbody.ui-datatable-data")) : null;
    }
    function isRealEbys() { return !!(getInboxRoot() || findInboxMenuLink()); }
    function inboxHeaderText() {
        const r = getInboxRoot();
        const h = r && r.querySelector(".ui-inbox-header-title, .ui-datatable-header h2");
        return h ? (h.textContent || "").trim() : "";
    }
    function isMenuSelected(link) {
        return !!link && (link.classList.contains("ui-state-highlight") || link.classList.contains("ui-menuitem-selected") || link.getAttribute("aria-current") === "page");
    }
    // NEW (v3): şu an "İşlem Bekleyenler > Gelen Evraklar" listesinde miyiz?
    function isOnInbox() {
        if (!getInboxRoot()) return false;
        const headerOk = /^Gelen Evraklar/.test(inboxHeaderText());
        const link = findInboxMenuLink();
        return link ? (isMenuSelected(link) && headerOk) : headerOk;
    }
    // NEW (v3.5.2): menü bağlantısı tüm (aynı kökenli) çerçevelerde aranır; daraltılmış menü açılır; başka ekrandan (havale formu / Hızlı Seçim penceresi
    // açıkken) taramada önce bu geçici EBYS ekranları HİÇBİR İŞLEM YAPILMADAN kapatılır (pencere: X, boş havale formu: Vazgeç), sonra menüye 3 denemeyle geçilir.
    let lastNavFailure = "";
    function findMenuLinkByTag(tag, textRe, headerRe) {
        for (const doc of getAllDocs()) {
            try {
                const byTag = doc.querySelector('a[onclick*="' + tag + '"]');
                if (byTag && !isPanelEl(byTag)) return byTag;
                for (const a of doc.querySelectorAll("a.ui-menuitem-link")) {
                    if (isPanelEl(a) || !textRe.test(a.textContent || "")) continue;
                    const menu = a.closest(".ui-menu, .ui-panelmenu");
                    const h = menu && menu.querySelector("h3, .ui-menu-header, .ui-panelmenu-header");
                    if (!headerRe || (h && headerRe.test(h.textContent || ""))) return a;
                }
            } catch(e) {}
        }
        return null;
    }
    function findInboxMenuLink() { return findMenuLinkByTag(INBOX_MENU_TAG, /^\s*Gelen Evraklar(\s|\(|$)/, /İşlem Bekleyen/i); }
    function userClick(el) {
        if (isForbiddenEl(el)) { console.warn("[Evrak Asistanı] Onay Akışı öğesine tıklama engellendi", el && el.id); return; }
        try {
            const lab = ((el && (el.innerText || el.textContent || el.value || el.getAttribute("aria-label") || el.title)) || "").replace(/\s+/g, " ").trim();
            if (/(?:^|\b)(Kaydet|Gönder|İmzala|Imzala|Parafla|Paraf|Teslim Al Gönder|Direkt Gönder|Cevap Yaz)(?:\b|$)/i.test(lab)) {
                console.warn("[Evrak Asistanı – Müdür Paketi] Salt okunur: yazma tıklaması engellendi:", lab);
                return;
            }
        } catch (e) {}
        if (AUTO.stop) throw stopErr();
        try { el.scrollIntoView({ block: "nearest" }); } catch(e) {}
        let o = { bubbles: true, cancelable: true, view: el.ownerDocument.defaultView || window, button: 0 };
        try { const r = el.getBoundingClientRect(); o = Object.assign(o, { clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 }); } catch(e) {}
        const W = o.view;
        try { el.dispatchEvent(new W.PointerEvent("pointerdown", o)); } catch(e) {}
        el.dispatchEvent(new W.MouseEvent("mousedown", o));
        try { el.dispatchEvent(new W.PointerEvent("pointerup", o)); } catch(e) {}
        el.dispatchEvent(new W.MouseEvent("mouseup", o));
        el.dispatchEvent(new W.MouseEvent("click", o));
    }
    // daraltılmış (akordeon) menü başlığını aç
    async function expandMenuFor(link) {
        if (!link || isVisible(link)) return;
        const li = link.closest("li");
        const ul = li && li.parentElement;
        // başlık: önce <h3> (tıklama üst <li>'ye de kabarır), yoksa başlık <li>; panelmenu yapısında başlık bağlantısı
        const pm = link.closest(".ui-panelmenu-panel");
        const head = (ul && (ul.querySelector(":scope > li h3") || ul.querySelector(":scope > li.ui-widget-header"))) || (pm && pm.querySelector(".ui-panelmenu-header a, .ui-panelmenu-header"));
        if (!head) return;
        dbg("Daraltılmış menü açılıyor:", (head.textContent || "").trim().slice(0, 40));
        try { userClick(head); } catch(e) {}
        await waitFor(() => isVisible(link), 2500, 120);
    }
    function visibleEbysDialogTitles() {
        const out = [];
        getAllDocs().forEach(doc => { try { doc.querySelectorAll(".ui-dialog").forEach(x => { if (isPanelEl(x) || !isVisible(x)) return; const t = ((x.querySelector(".ui-dialog-title") || {}).textContent || "").trim(); if (t) out.push(t); }); } catch(e) {} });
        return out;
    }
    function findVazgecButton() {
        const pf = getPreviewForm();
        const b = pf && pf.querySelector('[id$="teslimAlHavaleEtVazgecButton"]');
        if (b && isVisible(b)) return b;
        return findToolbarButton("Vazgeç");
    }
    // geçici EBYS ekranlarını işlem yapmadan kapat: Hızlı Seçim penceresi (X), havale formu (Vazgeç; formda kişi varsa önce sorulur)
    async function leaveEbysTransientUi() {
        if (isQuickOpen()) {
            dbg("Kişiye Havale - Hızlı Seçim penceresi kapatılıyor (X; seçim uygulanmaz).");
            closeQuickDialog();
            await waitFor(() => !isQuickOpen() && !isAjaxBusy(), 4000, 120);
        }
        if (isHavaleFormOpen()) {
            const ac = getPreviewForm() && getPreviewForm().querySelector('textarea[id$="aciklamaInputText"]');
            const dirty = kisiLovRows().length > 0 || !!(ac && ac.value.trim());
            if (dirty && !confirm("EBYS'de doldurulmuş bir havale formu açık.\n\nGelen Evraklar'ı taramak için bu form 'Vazgeç' ile kapatılsın mı?\n(Hiçbir şey gönderilmez; formdaki seçimler kaybolur.)")) {
                return { ok: false, msg: "EBYS'de doldurulmuş bir havale formu açık; tarama için kapatılmadı. Formu EBYS'de gönderin ya da 'Vazgeç'e basıp tekrar tarayın." };
            }
            const v = findVazgecButton();
            if (v) {
                dbg("Havale formu 'Vazgeç' ile kapatılıyor (gönderim yapılmaz).");
                v.click();
                await waitFor(() => !isHavaleFormOpen() && !isAjaxBusy(), AJAX_TIMEOUT_MS, 150);
                await sleep(250);
            }
        }
        return { ok: true };
    }
    async function gotoInbox() {
        lastNavFailure = "";
        if (isOnInbox()) return true;
        const lv = await leaveEbysTransientUi();
        if (!lv.ok) { lastNavFailure = lv.msg; return false; }
        for (let attempt = 0; attempt < 5; attempt++) {
            await waitFor(() => !isAjaxBusy(), 20000, 250); // v3.6.9: 'Lütfen Bekleyiniz' kalkmadan menüye tıklanmaz
            const link = findInboxMenuLink();
            if (!link) { await sleep(800); continue; }
            await expandMenuFor(link);
            dbg("İşlem Bekleyenler > Gelen Evraklar menüsüne geçiliyor (", link.id, ") deneme", attempt + 1);
            try { if (attempt === 0) link.click(); else userClick(link); } catch(e) {}
            const ok = await waitFor(() => isOnInbox() && !isAjaxBusy(), attempt === 0 ? 15000 : 12000, 250);
            if (ok) { await sleep(400); dbg("Gelen Evraklar açıldı."); return true; }
            await leaveEbysTransientUi(); // bu arada açılan pencere / form varsa
        }
        const dl = visibleEbysDialogTitles();
        if (!findInboxMenuLink()) lastNavFailure = /mainInbox\.xhtml/.test(location.pathname) ? "Sol menü bulunamadı (sayfa tam yüklenmemiş olabilir)." : "Bu sayfada EBYS sol menüsü yok (evrak ayrı sayfada / pencerede açık).";
        else lastNavFailure = "Menüye tıklandı ama Gelen Evraklar listesi " + (attempt3s()) + " içinde açılmadı" + (dl.length ? "; ekranda açık EBYS penceresi: '" + dl.slice(0, 2).join("', '") + "' — kapatıp tekrar deneyin" : "") + ".";
        dbg("Gelen Evraklar açılamadı:", lastNavFailure);
        return false;
    }
    const attempt3s = () => "5 denemede";
    // tarama düğmesi(leri) — yeniden çizimde ya da hata sonrasında her zaman düzeltilir
    function setScanButtons(busy) {
        document.querySelectorAll('[id="btn-scan-trigger"]').forEach(b => { b.disabled = !!busy; b.innerText = busy ? "⏳ TARANIYOR..." : "⚡ GELEN EVRAKLARI TARA"; });
    }
    const INBOX_URL = "https://ebys.meb.gov.tr/edys-web/mainInbox.xhtml";
    function scanNavHelpButton(c) {
        if (!c || /mainInbox\.xhtml/.test(location.pathname) || findInboxMenuLink()) return;
        const b = document.createElement("button");
        b.id = "btn-scan-goto-inbox";
        b.textContent = "➡️ EBYS ana sayfasını (Gelen Evraklar) aç ve tara";
        b.style.cssText = "background:#2563EB; color:white; border:none; padding:7px; border-radius:10px; font-weight:bold; cursor:pointer; font-size:11px;";
        b.onclick = () => { try { sessionStorage.setItem("ebys_autoscan", String(Date.now())); } catch(e) {} location.assign(INBOX_URL); };
        const n = c.querySelector("#ebys-scan-menu-notice");
        if (n) n.after(b); else c.prepend(b);
    }
    // ana sayfaya geçişten sonra taramayı kendiliğinden başlat (yalnızca kullanıcı ➡️ düğmesine bastıysa; 2 dk içinde)
    function maybeAutoScanAfterNav() {
        let t = 0;
        try { t = +sessionStorage.getItem("ebys_autoscan") || 0; sessionStorage.removeItem("ebys_autoscan"); } catch(e) {}
        if (!t || Date.now() - t > 120000) return;
        waitFor(() => document.getElementById("btn-scan-trigger") && getInboxRoot(), 20000, 300).then(ok => { if (ok && !isScanningPages) { const b = document.getElementById("btn-scan-trigger"); if (b && !b.disabled) b.click(); } });
    }
    function getInboxRows() {
        const b = getInboxBody();
        if (!b) return [];
        return Array.from(b.children).filter(tr => tr.tagName === "TR" && tr.hasAttribute("data-ri") && !tr.classList.contains("ui-datatable-empty-message"));
    }
    function getInboxPaginator() {
        const r = getInboxRoot();
        return r ? r.querySelector(".ui-paginator") : null;
    }
    // NEW (v3): gerçek satır yapısından evrak bilgisi
    // Müdür 1.0.1: evrağın kimde olduğu — EBYS listesi/önizlemesinden salt okunur. Yazma yok.
    function cleanKimde(s) {
        s = String(s == null ? "" : s).replace(/\s+/g, " ").trim();
        s = s.replace(/\s+(?:Evrak Tarihi|Miat(?:\s*Tarihi)?|Gereği için|Bilgi için|Koordinasyon için|İVEDİ|IVEDİ|ACELE|GÜNLÜDÜR|GUNLUDUR)\b.*$/i, "").trim();
        s = s.replace(/^[:\-–—\s]+|[:\-–—\s]+$/g, "").trim();
        if (s.length < 2 || s.length > 120) return "";
        if (/^E-\d/.test(s) || /^\d{2}[./]\d{2}[./]\d{4}$/.test(s) || /^(Konu|Geldiği Yer|Geldiği yer)$/i.test(s)) return "";
        return s;
    }
    function extractKimdeFromText(full) {
        const t = String(full || "").replace(/\s+/g, " ").trim();
        if (!t) return "";
        const stop = "(?:Evrak Tarihi|Miat(?:\\s*Tarihi)?|Geldiği Yer|Geldiği yer|Konu|Gereği için|Bilgi için|Koordinasyon|Havale Edilen|Teslim Alan|İşlem Yapan|Islem Yapan|Üzerinde|Uzerinde|Kime|Havale Birim|Sayı\\s*:|E-\\d|İVEDİ|IVEDİ|ACELE)";
        const specs = [
            "Havale\\s+Edilen\\s+(?:Kullan[iı]c[iı]|Ki[sş]i|Personel|Memur|Birim)",
            "Havale\\s+Edilen",
            "Teslim\\s+Alan(?:\\s+(?:Kullan[iı]c[iı]|Ki[sş]i))?",
            "(?:Son\\s+)?İşlem\\s+Yapan",
            "(?:Son\\s+)?Islem\\s+Yapan",
            "Üzerinde(?:\\s+Bulunan)?",
            "Uzerinde(?:\\s+Bulunan)?",
            "Kime(?:\\s+Havale(?:\\s+Edildi)?)?",
            "Havale\\s+Birimi?",
            "Havale\\s+Edilen\\s+Yer"
        ];
        for (const lab of specs) {
            const re = new RegExp(lab + "\\s*:\\s*([^:]+?)(?=\\s+" + stop + "|$)", "i");
            const m = t.match(re);
            if (m) { const v = cleanKimde(m[1]); if (v) return v; }
        }
        return "";
    }
    function extractKimdeFromRow(tr) {
        if (!tr) return "";
        const txt = (sel) => { try { const e = tr.querySelector(sel); return e ? (e.textContent || "").replace(/\s+/g, " ").trim() : ""; } catch (e) { return ""; } };
        const sels = [".ui-inbox-havale", ".ui-inbox-satir5", ".havaleEdilen", "[class*='havaleEdilen']", "[id*='havaleEdilen']", "[id*='HavaleEdilen']", "[class*='teslimAlan']", "[id*='teslimAlan']", "[class*='islemYapan']", "[id*='islemYapan']"];
        for (const sel of sels) {
            const raw = txt(sel);
            if (!raw) continue;
            const stripped = raw.replace(/^(Havale\s+Edilen(?:\s+\S+)?|Teslim\s+Alan|İşlem\s+Yapan|Üzerinde|Kime)\s*:\s*/i, "");
            const v = extractKimdeFromText(raw.indexOf(":") >= 0 ? raw : ("Havale Edilen : " + raw)) || cleanKimde(stripped);
            if (v) return v;
        }
        return extractKimdeFromText((tr.textContent || "").replace(/\s+/g, " ").trim());
    }
    function extractKimdeFromPreview() {
        try {
            const pf = typeof getPreviewForm === "function" ? getPreviewForm() : null;
            if (!pf) return "";
            return extractKimdeFromText((pf.textContent || "").replace(/\s+/g, " ").trim().slice(0, 5000));
        } catch (e) { return ""; }
    }
    function applyKimdeFromEbys(d, extraText) {
        if (!d) return "";
        if (d.kimdeKaynak === "gecmis" && d.kimde) return d.kimde; // v1.0.3: Evrak Geçmişi'nden okunan (Gereği) tahminle ezilmez
        const k = extractKimdeFromPreview() || extractKimdeFromText(extraText || "") || extractKimdeFromText(d.rawRowText || "") || "";
        if (k) { d.kimde = k; d.kimdeKaynak = "ebys"; }
        return d.kimde || "";
    }

    function parseInboxRow(tr) {
        const txt = (sel) => { const e = tr.querySelector(sel); return e ? (e.textContent || "").replace(/\s+/g, " ").trim() : ""; };
        const full = (tr.textContent || "").replace(/\s+/g, " ").trim();
        const s3 = txt(".ui-inbox-satir3"), s4 = txt(".ui-inbox-satir4");
        const noM = (s3 + " " + full).match(/E-\d{6,10}-[\d.]+-\d+/) || full.match(/E-\d{6,10}[-\w.]+\w/);
        if (!noM) return null;
        let subject = (txt("h3.ui-inbox-satir1") || txt(".rowTitleForInbox")).replace(/^Konu\s*:\s*/i, "");
        if (!subject) { const km = full.match(/Konu\s*:\s*(.{3,160}?)(?=\s+(Kişisel Arşive|Geldiği Yer|\d{2}\.\d{2}\.\d{4})|$)/); if (km) subject = km[1]; }
        const gonderen = txt(".ui-inbox-satir2").replace(/^Geldiği Yer\s*:\s*/i, "");
        const et = s4.match(/Evrak Tarihi\s*:\s*(\d{2}\.\d{2}\.\d{4})/);
        const kt = s3.match(/(\d{2}\.\d{2}\.\d{4})/);
        const miat = s4.match(/Miat\s*:\s*(\d+)\s*gün/i);
        const miatT = s4.match(/Miat(?:\s*Tarihi)?\s*:\s*(\d{2}\.\d{2}\.\d{4})/i); // NEW (v3.5.1)
        const islem = s4.match(/(Gereği için|Bilgi için|Koordinasyon için)/i);
        const out = {
            docNo: noM[0], rk: tr.getAttribute("data-rk") || "",
            subject: (subject || "Konu belirtilmemiş").substring(0, 160),
            gonderen: gonderen || "-",
            tarih: et ? et[1] : (kt ? kt[1] : ""),
            kayitTarihi: kt ? kt[1] : "",
            miat: miat ? +miat[1] : null,
            miatTarihi: miatT ? miatT[1] : "",
            islem: islem ? islem[1] : "",
            ivedi: /ivedi/i.test(tr.className) || /İVEDİ/.test(full),
            unread: /\bui-inbox(-ivedi)?-unread\b/.test(tr.className),
            rawRowText: full.slice(0, 600),
            kimde: "", kimdeKaynak: ""
        };
        const kimde = extractKimdeFromRow(tr);
        if (kimde) { out.kimde = kimde; out.kimdeKaynak = "ebys"; }
        return out;
    }
    function grabInboxPage() {
        let added = 0;
        getInboxRows().forEach(tr => {
            const d = parseInboxRow(tr);
            if (d && !scannedList.some(x => x.docNo === d.docNo)) { scannedList.push(d); added++; }
        });
        return added;
    }
    function findInboxRow(d) {
        const rows = getInboxRows();
        if (d.rk) { const r = rows.find(tr => tr.getAttribute("data-rk") === d.rk); if (r) return r; }
        return rows.find(tr => (tr.textContent || "").includes(d.docNo)) || null;
    }
    function isRowSelected(tr) {
        return !!tr && (tr.classList.contains("ui-state-highlight") || tr.getAttribute("aria-selected") === "true");
    }
    // NEW (v3): satırı kullanıcı gibi tıkla — PrimeFaces satır seçimi yalnızca seçilebilir bir hücreye (td) yapılan tıklamayı kabul eder;
    // ilk hücre seçim kutusu (td.ui-selection-column), dış hücre "ui-column-unselectable" ve düğmeler satırı AÇMAZ.
    function clickRowLikeUser(tr, attempt) {
        const cands = [".ui-inbox-satir2", ".ui-inbox-satir3", ".ui-inbox-satir4", ".ui-inbox-satir1"].map(s => tr.querySelector("td" + s)).filter(Boolean);
        const generic = Array.from(tr.querySelectorAll("td")).filter(td => !td.classList.contains("ui-selection-column") && !td.classList.contains("ui-column-unselectable") && !td.querySelector("button, .ui-chkbox"));
        const target = cands[attempt % Math.max(1, cands.length)] || generic[0] || tr;
        try { tr.scrollIntoView({ block: "center" }); } catch(e) {}
        const opts = { bubbles: true, cancelable: true, view: window, button: 0 };
        ["mousedown", "mouseup", "click"].forEach(t => { try { target.dispatchEvent(new MouseEvent(t, opts)); } catch(e) {} });
        return target;
    }
    function getPreviewForm() { return document.getElementById("mainPreviewForm"); }
    function findToolbarButton(label) {
        const scope = getPreviewForm() || document;
        for (const b of scope.querySelectorAll("button, a")) {
            if (isPanelEl(b) || /onaysizKapatId$/.test(b.id || "")) continue;
            const lab = (b.getAttribute("aria-label") || (b.querySelector(".ui-button-text") || b).textContent || "").trim();
            if (lab === label && isVisible(b) && !b.classList.contains("ui-state-disabled")) return b;
        }
        return null;
    }
    function isDocPreviewShown() {
        const pf = getPreviewForm();
        if (!pf) return false;
        return !!(findToolbarButton("Cevap Yaz") || findToolbarButton("Evrak Kapat") || pf.querySelector("iframe.onizlemeFrame"));
    }
    // NEW (v3): gerçek listede evrakı bul ve aç; önizleme formu güncellenene kadar bekle
    async function openRealDocument(d) {
        let tr = findInboxRow(d);
        if (!tr) {
            if (!(await gotoInbox())) return { ok: false, reason: "menu" };
            tr = findInboxRow(d);
        }
        if (!tr) {
            await goFirstPage();
            tr = findInboxRow(d);
            const seen = new Set([tableSignature()]);
            for (let p = 1; !tr && p < MAX_OPEN_PAGES; p++) {
                if (!hasNextPage() || !(await goNextPage())) break;
                const sig = tableSignature();
                if (seen.has(sig)) break;
                seen.add(sig);
                tr = findInboxRow(d);
            }
        }
        if (!tr) { dbg("Evrak listede bulunamadı:", d.docNo); return { ok: false, reason: "notfound" }; }
        for (let attempt = 0; attempt < 2; attempt++) {
            const pf0 = getPreviewForm();
            const already = isRowSelected(tr) && isDocPreviewShown();
            let mutated = false;
            const mo = new MutationObserver(() => { mutated = true; });
            try { if (pf0) mo.observe(pf0, { childList: true, subtree: true }); } catch(e) {}
            const target = clickRowLikeUser(tr, attempt);
            dbg("Satır tıklandı:", d.docNo, "hücre:", target.className || target.tagName);
            const ok = await waitFor(() => (mutated || getPreviewForm() !== pf0 || already) && isDocPreviewShown() && !isAjaxBusy(), attempt ? 6000 : 9000, 150);
            mo.disconnect();
            if (ok) { await sleep(400); return { ok: true }; }
            tr = findInboxRow(d) || tr;
        }
        dbg("Satır tıklandı fakat önizleme yüklenmedi:", d.docNo);
        return { ok: false, reason: "preview" };
    }

    // ---- NEW (v3): önizleme metni (pdf.js) — köprü (sayfa dünyası) ya da metin katmanı (DOM)
    let bridgeSeq = 0, bridgeState = { ok: null, at: 0 };
    function bridgeCall(op, args, timeoutMs = 3000) {
        return new Promise(resolve => {
            const id = "b" + (++bridgeSeq) + "_" + Date.now();
            let done = false;
            const onRes = (e) => {
                let r = null; try { r = JSON.parse(e.detail); } catch(err) { return; }
                if (!r || r.id !== id) return;
                done = true; document.removeEventListener("ebys-bridge-res", onRes); resolve(r.result);
            };
            document.addEventListener("ebys-bridge-res", onRes);
            setTimeout(() => { if (!done) { document.removeEventListener("ebys-bridge-res", onRes); resolve(null); } }, timeoutMs);
            try { document.dispatchEvent(new CustomEvent("ebys-bridge-req", { detail: JSON.stringify(Object.assign({ id: id, op: op }, args || {})) })); } catch(e) {}
        });
    }
    async function bridgeAvailable() {
        if (bridgeState.ok !== null && Date.now() - bridgeState.at < 30000) return bridgeState.ok;
        const r = await bridgeCall("ping", {}, 700);
        bridgeState = { ok: !!(r && r.ok), at: Date.now(), info: r };
        return bridgeState.ok;
    }
    function getPreviewFrame() {
        const pf = getPreviewForm();
        const frames = Array.from((pf || document).querySelectorAll("iframe.onizlemeFrame"));
        return frames.find(f => isVisible(f)) || frames[0] || null;
    }
    // pdf.js metin katmanı: span'lar konumlu ve satır sonu içermeyebilir → konuma göre satırlara ayrılır
    function readPdfDomText() {
        const f = getPreviewFrame();
        let doc = null;
        try { doc = f && f.contentDocument; } catch(e) {}
        if (!doc) return "";
        const out = [];
        doc.querySelectorAll(".textLayer").forEach(layer => {
            const items = [];
            layer.querySelectorAll("span").forEach(s => {
                if (s.querySelector("span")) return;
                const t = s.textContent;
                if (!t || !t.trim()) return;
                const r = s.getBoundingClientRect();
                let top = r.height ? r.top : parseFloat(s.style.top), left = r.width ? r.left : parseFloat(s.style.left);
                if (isNaN(top)) top = items.length; if (isNaN(left)) left = 0;
                items.push({ t: t, top: top, left: left, h: r.height || parseFloat(s.style.fontSize) || 10 });
            });
            items.sort((a, b) => (a.top - b.top) || (a.left - b.left));
            let line = [], lineTop = null, lineH = 10;
            const flush = () => { if (line.length) { line.sort((a, b) => a.left - b.left); out.push(line.map(x => x.t).join(" ").replace(/\s+/g, " ").trim()); } line = []; };
            items.forEach(it => {
                if (lineTop !== null && Math.abs(it.top - lineTop) > Math.max(2, lineH * 0.5)) flush();
                if (!line.length) { lineTop = it.top; lineH = it.h; }
                line.push(it);
            });
            flush();
            out.push("");
        });
        return out.join("\n").replace(/\n{3,}/g, "\n\n").trim();
    }
    async function readRealPreview(d) {
        const res = { text: "", verified: false, source: "", evrakTarihi: "" };
        const pf = getPreviewForm();
        const tl = pf && pf.querySelector(".onizlemeTarih");
        const tm = tl && (tl.textContent || "").match(/\d{2}\.\d{2}\.\d{4}/);
        if (tm) res.evrakTarihi = tm[0];
        const useBridge = await bridgeAvailable();
        const t0 = Date.now();
        while (Date.now() - t0 < PREVIEW_TIMEOUT_MS + 4000) {
            let txt = "";
            if (useBridge) {
                const r = await bridgeCall("pdfText", { maxPages: 4 }, 5000);
                if (r && r.ok && r.text) { txt = r.text; res.source = "pdf.js"; }
            }
            if (!txt) { txt = readPdfDomText(); if (txt) res.source = "metin katmanı"; }
            if (txt && txt.replace(/\s/g, "").length > 30) { res.text = txt; break; }
            await sleep(400);
        }
        if (res.text) {
            const shortNo = String(d.docNo).split("-").pop();
            res.verified = res.text.includes(d.docNo) || (shortNo.length >= 6 && res.text.includes(shortNo));
        }
        dbg("Önizleme okundu:", d.docNo, "kaynak=" + (res.source || "-"), "uzunluk=" + res.text.length, "doğrulandı=" + res.verified);
        return res;
    }
    // v3.6.31: "Evrak Ekleri" tablosu GÖRÜNÜR METİNLE bulunur (başlıklar: Ek Sayısı / Ek Türü / Açıklama / Dosya Adı / İndir / Detay); sütunlar başlık metnine göre eşlenir.
    const EK_HDR = { no: /^ek\s*(sayısı|sayisi|no)/i, tur: /^ek\s*türü|^ek\s*turu|^tür/i, aciklama: /^açıklama|^aciklama/i, dosya: /^dosya\s*ad/i, indir: /^indir/i, detay: /^detay/i };
    const ekNorm = t => String(t || "").replace(/\s+/g, " ").trim();
    function findEkTable() {
        for (const doc of getAllDocs()) {
            const byId = doc.querySelector('tbody[id$="ekListesiOnizlemeDataTableBase_data"]');
            const cands = byId ? [byId.closest("table")] : [];
            doc.querySelectorAll("table").forEach(t => { if (!cands.includes(t)) cands.push(t); });
            for (const t of cands) {
                if (!t || isPanelEl(t)) continue;
                const ths = Array.from(t.querySelectorAll("thead th, thead td"));
                if (!ths.length) { if (byId && t === cands[0]) return { table: t, cols: { no: 0, tur: 1, aciklama: 2, dosya: 3, indir: 4, detay: 5 }, doc: doc }; continue; } // başlıksız bilinen tablo: v3 sütun sırası
                const cols = {};
                ths.forEach((th, i) => { const tx = ekNorm(th.textContent); Object.keys(EK_HDR).forEach(k => { if (cols[k] === undefined && EK_HDR[k].test(tx)) cols[k] = i; }); });
                if (cols.dosya !== undefined && (cols.indir !== undefined || cols.tur !== undefined)) return { table: t, cols: cols, doc: doc };
            }
        }
        return null;
    }
    function parseEkTable(found) {
        const { table, cols } = found;
        const body = table.querySelector("tbody") || table;
        const items = [];
        Array.from(body.querySelectorAll(":scope > tr")).forEach(tr => {
            const tds = Array.from(tr.children);
            if (tds.length < 2 || /ui-datatable-empty-message/.test(tr.className)) return;
            const c = k => cols[k] !== undefined && tds[cols[k]] ? ekNorm(tds[cols[k]].textContent) : "";
            const no = c("no"), tur = c("tur"), aciklama = c("aciklama"), dosya = c("dosya");
            const indirTd = cols.indir !== undefined ? tds[cols.indir] : null;
            const btn = (indirTd && indirTd.querySelector("button, a")) || tr.querySelector('button[id$=":indirButton"]');
            const disabled = !btn || btn.disabled || btn.getAttribute("aria-disabled") === "true" || /ui-state-disabled/.test(btn.className || "");
            const boyut = ((indirTd ? indirTd.textContent : "").match(/\(([^)]+)\)/) || [])[1] || "";
            const isEvrak = /^evrak$/i.test(tur);
            items.push({
                name: [no, aciklama, dosya ? "(" + dosya + (boyut ? ", " + boyut : "") + ")" : ""].filter(Boolean).join(" ") || ("Ek-" + (items.length + 1)),
                fileName: dosya, tur: tur, readable: false, text: "", points: aciklama ? [aciklama] : [],
                _btn: disabled ? null : btn, skip: isEvrak && disabled,
                note: isEvrak && disabled ? "EVRAK türü ek (" + (aciklama || "ilgi yazı") + "): EBYS'de indirme kapalı; okunmadı (İlgi Bilgileri/Detay ile görüntülenebilir)."
                    : disabled ? "İndir düğmesi pasif; okunmadı." : "okunmadı"
            });
        });
        return items;
    }
    // Sekme şeridindeki "Evrak Ekleri" sekmesi (tüm çerçevelerde, görünür metinle)
    function findEvrakEkleriTab() {
        for (const doc of getAllDocs()) {
            for (const el of doc.querySelectorAll(".ui-tabs-nav li, .ui-tabview-nav li, [role='tab'], ul.ui-tabs-nav > li")) {
                if (isPanelEl(el)) continue;
                if (/^evrak\s+ekleri(\s*\(\d+\))?$/i.test(ekNorm(el.textContent))) return el;
            }
            for (const a of doc.querySelectorAll("a, span")) { // yedek: yalnızca metin
                if (isPanelEl(a)) continue;
                if (/^evrak\s+ekleri(\s*\(\d+\))?$/i.test(ekNorm(a.textContent)) && a.closest("li, [role='tab']")) return a.closest("li, [role='tab']");
            }
        }
        return null;
    }
    function activeTabOf(tabEl) {
        const nav = tabEl && tabEl.parentElement;
        if (!nav) return null;
        return Array.from(nav.children).find(li => li !== tabEl && (/ui-state-active|ui-tabs-selected/.test(li.className) || li.getAttribute("aria-selected") === "true" || li.getAttribute("aria-expanded") === "true")) || null;
    }
    const clickTab = li => { const a = li.querySelector("a") || li; try { userClick(a); } catch(e) { try { a.click(); } catch(e2) {} } };
    function waitEkTable(maxMs) {
        return new Promise(resolve => {
            const t0 = Date.now(); let done = false, obs = [];
            const finish = v => { if (done) return; done = true; obs.forEach(o => { try { o.disconnect(); } catch(e) {} }); clearInterval(iv); resolve(v); };
            const check = () => {
                const f = findEkTable();
                const busy = (() => { try { return bekleyinizVisible(); } catch(e) { return false; } })();
                if (f && !busy) { const rows = parseEkTable(f); if (rows.length || f.table.querySelector(".ui-datatable-empty-message") || Date.now() - t0 > 1500) return finish(f); }
                if (Date.now() - t0 > maxMs) finish(f || null);
            };
            getAllDocs().forEach(d => { try { const o = new MutationObserver(check); o.observe(d.body || d.documentElement, { childList: true, subtree: true }); obs.push(o); } catch(e) {} });
            const iv = setInterval(check, 250); check();
        });
    }
    // ---- Müdür 1.0.2: Evrak Geçmişi sekmesinden Kimde (Gereği) — SALT OKUNUR (yalnızca sekme geçişi; Kaydet/Gönder/İmza/Paraf yok) ----
    // EBYS "Evrak Geçmişi" tablosu: Gönderen | Teslim Alan | İşlem Süreci | İşlem Tarihi | Açıklama.
    // Kimde = en son "Gereği İçin" havale satırının Teslim Alan'ı ("Bilgi İçin" satırları yok sayılır). Bulunamazsa "" (Bilinmiyor); asla uydurulmaz.
    const GECMIS_HDR = { gonderen: /^gonderen/, teslim: /^teslim\s*alan/, surec: /^islem\s*sureci/, tarih: /^islem\s*tarihi/, aciklama: /^aciklama/ };
    function gecmisKey(s) {
        const m = String(s || "").match(/(\d{1,2})[./](\d{1,2})[./](\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
        if (!m) return "";
        const p = (x, n) => String(x == null ? 0 : x).padStart(n, "0");
        return p(m[3], 4) + p(m[2], 2) + p(m[1], 2) + p(m[4], 2) + p(m[5], 2) + p(m[6], 2);
    }
    function cleanGecmisKisi(s) {
        s = String(s == null ? "" : s).replace(/\s+/g, " ").trim();
        if (s.length < 2 || s.length > 120 || /^E-\d/.test(s) || /^\d{1,2}[./]\d{1,2}[./]\d{4}/.test(s)) return "";
        return s;
    }
    function isGerekSurec(s) { return /geregi\s*icin/.test(trFold(String(s || "")).replace(/\s+/g, " ")); }
    // v1.0.4: Teslim Alan KURUM/müdürlük adıysa (kurum içi posta otomatik havalesi) kişi sayılmaz
    const KURUM_RE = /mudurlug|mudurluk|lisesi|okulu|ilkokulu|ortaokulu|anaokulu|baskanlig|valilig|kaymakamlig|bakanlig|rektorlug|dekanlig|milli egitim|kurumu/;
    const isKurumAdi = s => KURUM_RE.test(trFold(String(s || "")).replace(/\s+/g, " "));
    const isOtomatikHavale = r => /otomatik\s+(olusan\s+)?havale/.test(trFold(String((r && r.aciklama) || "")).replace(/\s+/g, " "));
    function pickGerekFromRows(rows) {
        const gAll = (rows || []).filter(r => r && isGerekSurec(r.surec) && cleanGecmisKisi(r.teslim));
        if (!gAll.length) return { kimde: "", tarih: "", adet: 0, neden: "gerek-yok" };
        const g = gAll.filter(r => !isKurumAdi(r.teslim) && !isOtomatikHavale(r)); // yalnız KİŞİye giden Gereği İçin havale
        if (!g.length) return { kimde: "", tarih: "", adet: 0, neden: "sadece-kurum" };
        const keyed = g.map(r => ({ r: r, k: gecmisKey(r.tarih) }));
        const dated = keyed.filter(x => x.k);
        let pick;
        if (dated.length) { const mx = dated.reduce((a, x) => (x.k > a ? x.k : a), ""); pick = dated.filter(x => x.k === mx).map(x => x.r); }
        else pick = g;
        const names = [];
        pick.forEach(r => { const n = cleanGecmisKisi(r.teslim); if (n && !names.includes(n)) names.push(n); });
        if (!dated.length && names.length > 1) return { kimde: "", tarih: "", adet: 0, neden: "tarih-yok-belirsiz" };
        return { kimde: names.join(", "), tarih: pick[0].tarih || "", adet: names.length, neden: "" };
    }
    // v1.0.4: "Evrak Kapatıldı" satırı (en son) → { tarih: "gg.aa.yyyy", kisi } (Açıklama: "X tarafından kapatılmıştır"); yoksa null
    function pickKapatildiFromRows(rows) {
        const k = (rows || []).filter(r => r && /\bkapatildi\b|\bkapatilmis/.test(trFold(String(r.surec || "")).replace(/\s+/g, " ")));
        if (!k.length) return null;
        const keyed = k.map(r => ({ r: r, k: gecmisKey(r.tarih) })).filter(x => x.k);
        const r = keyed.length ? keyed.reduce((a, x) => (x.k > a.k ? x : a)).r : k[0];
        const ac = String(r.aciklama || "").replace(/\s+/g, " ").trim(), fo = trFold(ac);
        let kisi = "";
        const m = /\s+tarafindan\b/.exec(fo);
        if (m && fo.length === ac.length) kisi = ac.slice(0, m.index).trim();
        if (!kisi) kisi = cleanGecmisKisi(r.gonderen);
        const dm = String(r.tarih || "").match(/\d{1,2}[./]\d{1,2}[./]\d{4}/);
        return { tarih: dm ? dm[0].replace(/\//g, ".") : String(r.tarih || ""), kisi: kisi };
    }
    function gecmisCols(table) {
        let ths = Array.from(table.querySelectorAll("thead th, thead td"));
        if (!ths.length) { const tr0 = table.querySelector("tr"); if (tr0 && tr0.querySelector("th")) ths = Array.from(tr0.children); }
        const cols = {};
        ths.forEach((th, i) => { const tx = trFold(ekNorm(th.textContent)); Object.keys(GECMIS_HDR).forEach(k => { if (cols[k] === undefined && GECMIS_HDR[k].test(tx)) cols[k] = i; }); });
        return (cols.teslim !== undefined && cols.surec !== undefined) ? cols : null;
    }
    function gecmisCellText(td) {
        try { const c = td.cloneNode(true); c.querySelectorAll(".ui-column-title").forEach(e => e.remove()); return ekNorm(c.textContent); } catch (e) { return ekNorm(td && td.textContent); }
    }
    function parseGecmisRows(found) {
        const { table, cols } = found;
        const root = table.closest(".ui-datatable") || table;
        const need = Math.max(cols.teslim, cols.surec, cols.tarih === undefined ? 0 : cols.tarih);
        const rows = [];
        Array.from(root.querySelectorAll("tbody > tr")).forEach(tr => {
            if (/ui-datatable-empty-message/.test(tr.className || "")) return;
            const tds = Array.from(tr.children).filter(x => /^T[DH]$/.test(x.tagName));
            if (tds.length <= need) return;
            const c = k => (cols[k] !== undefined && tds[cols[k]] ? gecmisCellText(tds[cols[k]]) : "");
            rows.push({ gonderen: c("gonderen"), teslim: c("teslim"), surec: c("surec"), tarih: c("tarih"), aciklama: c("aciklama") });
        });
        return rows;
    }
    // tüm çerçevelerde, GÖRÜNÜR "Evrak Geçmişi" tablosu (başlık metniyle); eklenti paneli atlanır
    function findGecmisTable() {
        for (const doc of getAllDocs()) {
            for (const t of doc.querySelectorAll("table")) {
                if (isPanelEl(t)) continue;
                const cols = gecmisCols(t);
                if (cols && isVisible(t)) return { table: t, cols: cols, doc: doc };
            }
        }
        return null;
    }
    const GECMIS_TAB_RE = /^(evrak|havale)\s+gecmisi(\s*\(\d+\))?$/;
    function findEvrakGecmisiTab() {
        const ok = el => GECMIS_TAB_RE.test(trFold(ekNorm(el.textContent)));
        for (const doc of getAllDocs()) {
            for (const el of doc.querySelectorAll(".ui-tabs-nav li, .ui-tabview-nav li, [role='tab'], ul.ui-tabs-nav > li")) {
                if (isPanelEl(el)) continue;
                if (ok(el)) return el;
            }
            for (const a of doc.querySelectorAll("a, span")) { // yedek: yalnızca metin
                if (isPanelEl(a)) continue;
                if (ok(a) && a.closest("li, [role='tab']")) return a.closest("li, [role='tab']");
            }
        }
        return null;
    }
    async function waitGecmisTable(maxMs) {
        const t0 = Date.now();
        return await waitFor(() => {
            const f = findGecmisTable();
            if (!f) return null;
            let busy = false; try { busy = bekleyinizVisible(); } catch (e) {}
            if (busy) return null;
            if (parseGecmisRows(f).length || f.table.querySelector(".ui-datatable-empty-message") || (f.table.closest(".ui-datatable") && f.table.closest(".ui-datatable").querySelector(".ui-datatable-empty-message")) || Date.now() - t0 > 1500) return f;
            return null;
        }, maxMs, 250, "Evrak Geçmişi tablosu");
    }
    // v1.0.4: Evrak Geçmişi sayfalıdır (PrimeFaces paginator; en yeni satırlar önce). Yalnızca sayfa gezinme (okuma) tıklaması yapılır.
    const GECMIS_MAX_SAYFA = 10;
    const gecmisRowSig = rows => rows.length + "|" + rows.slice(0, 3).map(r => [r.surec, r.teslim, r.tarih, r.gonderen].join("~")).join("§");
    function findGecmisPager(found) {
        const root = found && found.table && (found.table.closest(".ui-datatable") || found.table.parentElement);
        const all = root ? Array.from(root.querySelectorAll(".ui-paginator")) : [];
        const pag = all.length ? all[all.length - 1] : null; // alttaki sayfalayıcı
        if (!pag) return null;
        const isDis = el => !el || /ui-state-disabled/.test(el.className || "") || el.getAttribute("aria-disabled") === "true";
        const pages = Array.from(pag.querySelectorAll(".ui-paginator-page"));
        const act = pages.find(p => /ui-state-active/.test(p.className || ""));
        const no = act ? parseInt(act.textContent, 10) : 1;
        return { el: pag, pages: pages, next: pag.querySelector(".ui-paginator-next"), first: pag.querySelector(".ui-paginator-first"), curNo: no > 0 ? no : 1, isDis: isDis };
    }
    function gecmisNextTarget(pg) {
        if (!pg) return null;
        if (pg.next && !pg.isDis(pg.next)) return pg.next;
        return pg.pages.find(x => parseInt(x.textContent, 10) === pg.curNo + 1 && !pg.isDis(x)) || null;
    }
    async function gecmisSayfaBekle(sig0, no0) {
        return await waitFor(() => {
            const f = findGecmisTable(); if (!f) return null;
            let busy = false; try { busy = bekleyinizVisible(); } catch (e) {}
            if (busy) return null;
            const rr = parseGecmisRows(f); if (!rr.length) return null;
            const pg = findGecmisPager(f);
            return (gecmisRowSig(rr) !== sig0 || (pg && pg.curNo !== no0)) ? { f: f, rows: rr } : null;
        }, 8000, 250, "Evrak Geçmişi sayfa değişimi");
    }
    async function gecmisIlkSayfayaDon(sig1) {
        const f = findGecmisTable(); if (!f) return;
        const pg = findGecmisPager(f); if (!pg || pg.curNo === 1) return;
        const hedef = (pg.first && !pg.isDis(pg.first)) ? pg.first : (pg.pages.find(x => parseInt(x.textContent, 10) === 1) || null);
        if (!hedef) return;
        const rows = parseGecmisRows(f);
        userClick(hedef);
        await gecmisSayfaBekle(gecmisRowSig(rows), pg.curNo);
    }
    // Açık evrakın Evrak Geçmişi'ni okur → { ok, kimde, tarih, rows, pages, kapatildi, neden, error }. Yalnızca sekme/sayfa gezinme tıklaması; sonunda 1. sayfaya ve önceki sekmeye dönülür.
    async function readGecmisKimde() {
        let tabEl = null, prev = null, found = findGecmisTable(), moved = false, sig1 = "";
        try {
            if (!found) {
                tabEl = findEvrakGecmisiTab();
                if (!tabEl) return { ok: false, kimde: "", rows: 0, neden: "", error: "'Evrak Geçmişi' sekmesi bulunamadı (önce evrakı açın)." };
                prev = activeTabOf(tabEl);
                clickTab(tabEl);
                found = await waitGecmisTable(8000);
                if (!found && prev) { clickTab(prev); await sleep(1200); clickTab(tabEl); found = await waitGecmisTable(10000); }
                if (!found) return { ok: false, kimde: "", rows: 0, neden: "", error: "'Evrak Geçmişi' sekmesi açıldı ama tablo gelmedi." };
            }
            let rows = parseGecmisRows(found), pages = 1, limited = false, pagerErr = "";
            sig1 = gecmisRowSig(rows);
            let pick = pickGerekFromRows(rows);
            while (!pick.kimde) {
                const pg = findGecmisPager(found), nxt = gecmisNextTarget(pg);
                if (!nxt) break;
                if (pages >= GECMIS_MAX_SAYFA) { limited = true; break; }
                const sig0 = gecmisRowSig(parseGecmisRows(found)), no0 = pg.curNo;
                userClick(nxt); moved = true;
                const nf = await gecmisSayfaBekle(sig0, no0);
                if (!nf) { pagerErr = "sonraki sayfa açılamadı"; break; }
                found = nf.f; rows = rows.concat(nf.rows); pages++;
                pick = pickGerekFromRows(rows);
            }
            return { ok: true, kimde: pick.kimde, tarih: pick.tarih, rows: rows.length, pages: pages, neden: pick.neden, limited: limited, pagerErr: pagerErr, kapatildi: pickKapatildiFromRows(rows), error: "" };
        } finally {
            if (moved) { try { await gecmisIlkSayfayaDon(sig1); } catch (e) {} }
            if (prev && tabEl) { try { clickTab(prev); } catch (e) {} }
        }
    }
    async function readRealAttachmentsAsync() {
        let found = findEkTable(), tabEl = null, prev = null, diag = "";
        if (!found) {
            tabEl = findEvrakEkleriTab();
            if (!tabEl) return { tabFound: false, items: [], timedOut: false, error: "'Evrak Ekleri' sekmesi bulunamadı" };
            prev = activeTabOf(tabEl);
            clickTab(tabEl);
            found = await waitEkTable(8000);
            if (!found && prev) { // v3.6.32: ilk açılışta tembel içerik gelmeyebilir → önceki sekmeye dön, tekrar aç (bir kez)
                showToast("⏳ 'Evrak Ekleri' ilk açılışta yüklenmedi; sekme yeniden açılıyor…", "info");
                clickTab(prev); await sleep(1200); clickTab(tabEl);
                found = await waitEkTable(10000);
            }
            if (!found) diag = "'Evrak Ekleri' sekmesi açıldı ama ek tablosu gelmedi (yeniden deneme dahil)";
        }
        const res = { tabFound: !!found, items: found ? parseEkTable(found) : [], timedOut: !found && !!tabEl, error: diag, _restore: prev };
        if (found && !res.items.length) res.error = "Ek tablosu boş (ek yok)";
        return res;
    }
    // eski eşzamanlı çağrılar için (tablo DOM'daysa)
    function readRealAttachments() {
        const f = findEkTable();
        if (!f) return { tabFound: false, items: [], timedOut: false, error: "ek tablosu DOM'da yok" };
        return { tabFound: true, items: parseEkTable(f), timedOut: false, error: "" };
    }
    // ===================== v3.6.30 (DENEYSEL): EK İÇERİĞİ OKUMA (PDF / DOCX / XLSX / XLS) — yalnızca bu bilgisayarda =====================
    // Kanıt (gerçek EBYS HTML kaydı, ebys-test/real/p3_ekler.html): her ek satırında "…:indirButton" var; onclick'i PrimeFaces.ab ile sunucuya
    // dosyayı seçtirir, sonra gizli iframe'e "dosyaDetayGosterServlet?indir=true&dosya=<ad>" yükler. Biz aynı isteği köprüden (iframe'siz) çalıştırıp
    // aynı adresi aynı kökenden fetch ile okuruz; bayt hiçbir dış sunucuya gitmez, diske de yazılmaz. GERÇEK EBYS'DE DOĞRULANMADI.
    const EK_OKU_KEY = "ebys_ek_oku_v1";
    const EK_MAX_BYTES = 15 * 1024 * 1024, EK_TEXT_MAX = 20000;
    const EK_CACHE = new Map(); // fid → { name, bytes, analysis } (yalnızca bellekte)
    function ekOkuEnabled() { const v = extStoreGet(EK_OKU_KEY); return !(v && v.enabled === false); }
    function ekServletUrl(btn) {
        const oc = (btn && btn.getAttribute("onclick")) || "";
        const m = oc.match(/dosyaDetayGosterServlet\?indir=true&(?:amp;)?dosya=([^'"]+)/);
        if (!m) { const g = oc.match(/['"]([A-Za-z0-9_\/.-]*Servlet\?[^'"]+)['"]/); if (g) { try { return new URL(g[1].replace(/&amp;/g, "&"), location.href).href; } catch(e) {} } return ""; }
        try { return new URL("dosyaDetayGosterServlet?indir=true&dosya=" + encodeURIComponent(m[1].replace(/&amp;/g, "&")), location.href).href; } catch(e) { return ""; }
    }
    async function ekFetchBytes(btn) {
        const url = ekServletUrl(btn);
        if (!url) throw new Error("indirme adresi bulunamadı (onclick: " + String(btn.getAttribute("onclick") || "-").slice(0, 120) + ")");
        if (await bridgeAvailable()) { const r = await bridgeCall("ekPrepare", { btnId: btn.id, timeoutMs: 8000 }, 9000); if (!r || !r.ok) throw new Error("EBYS ek isteği: " + ((r && r.error) || "yanıt yok")); }
        const resp = await fetch(url, { credentials: "same-origin", cache: "no-store" });
        if (!resp.ok) throw new Error("HTTP " + resp.status);
        const len = +(resp.headers.get("content-length") || 0); if (len > EK_MAX_BYTES) throw new Error("dosya çok büyük");
        const buf = new Uint8Array(await resp.arrayBuffer());
        if (buf.length > EK_MAX_BYTES) throw new Error("dosya çok büyük");
        if (buf.length < 8 || (buf[0] === 0x3C && /<html|<!doctype/i.test(new TextDecoder().decode(buf.subarray(0, 200))))) throw new Error("dosya yerine sayfa döndü (oturum/izin)");
        return buf;
    }
    async function enrichRealAttachments(att, docNo) {
        if (!att || !att.items || !att.items.length || !ekOkuEnabled() || typeof EBYS_EK === "undefined") return att;
        const t0 = Date.now();
        for (let i = 0; i < att.items.length && i < MAX_ATTACHMENTS; i++) {
            const it = att.items[i];
            if (it.skip) continue; // EVRAK türü, indirme kapalı (not parseEkTable'da)
            const btn = it._btn;
            const fname = (it.fileName || it.name || "").replace(/\s+/g, " ").trim();
            if (!btn) { if (!/okunmadı;|pasif/.test(it.note)) it.note = "İndir düğmesi bulunamadı; ek okunmadı."; continue; }
            if (Date.now() - t0 > 25000) { it.note = "süre sınırı: ek okunmadı"; att.timedOut = true; continue; }
            try {
                const bytes = await ekFetchBytes(btn);
                const an = await EBYS_EK.analyze(bytes, fname);
                const fid = (docNo || "evrak") + "#" + i;
                EK_CACHE.set(fid, { name: fname, bytes: bytes, analysis: an });
                it.fid = fid; it.kind = an.kind;
                it.text = String(an.text || "").slice(0, EK_TEXT_MAX);
                it.readable = !!it.text;
                it.points = (an.points && an.points.length ? an.points : it.points).slice(0, 5);
                it.form = an.form ? { fields: an.form.fields, emptyForm: an.form.emptyForm, approx: !!an.form.approx, title: an.form.title || "" } : null;
                it.note = an.note || (it.readable ? "" : "metin bulunamadı");
            } catch(e) { it.note = "indirme/okuma başarısız: " + String((e && e.message) || e); }
        }
        return att;
    }
    // v3.6.35: okunabilirlik + hafif tasarım cilası (yalnızca eklenti öğeleri; EBYS CSS'ine karşı !important). İşlev/seçici değişikliği yok.
    function ensureSkin35() {
        if (document.getElementById("ebys-skin-35")) return;
        const st = document.createElement("style"); st.id = "ebys-skin-35";
        st.textContent = `
#ebys-okul-profil-modal, #ebys-havale-rules-modal, #ebys-firstrun-panel, #ebys-inbox-panel { font-family: 'Segoe UI', system-ui, Tahoma, sans-serif !important; -webkit-font-smoothing: antialiased; }
#ebys-okul-profil-modal label { display:block !important; color:#F1F5F9 !important; font-size:12.5px !important; font-weight:600 !important; margin:0 0 8px !important; line-height:1.35 !important; }
#ebys-okul-profil-modal input, #ebys-havale-rules-modal input[type=text], #ebys-havale-rules-modal input:not([type]), #ebys-havale-rules-modal input[type=number], #ebys-havale-rules-modal textarea, #ebys-havale-rules-modal select {
  background:#FFFFFF !important; color:#0F172A !important; -webkit-text-fill-color:#0F172A !important; caret-color:#0F172A !important; border:1px solid #94A3B8 !important; border-radius:7px !important;
  font:500 13px 'Segoe UI', system-ui, sans-serif !important; opacity:1 !important; text-shadow:none !important; }
#ebys-okul-profil-modal input { display:block !important; width:100% !important; margin-top:3px !important; padding:6px 8px !important; height:auto !important; box-sizing:border-box !important; }
#ebys-okul-profil-modal input::placeholder, #ebys-havale-rules-modal input::placeholder, #ebys-havale-rules-modal textarea::placeholder { color:#64748B !important; -webkit-text-fill-color:#64748B !important; opacity:1 !important; }
#ebys-okul-profil-modal input:focus, #ebys-havale-rules-modal input:focus, #ebys-havale-rules-modal textarea:focus, #ebys-havale-rules-modal select:focus { outline:none !important; border-color:#2563EB !important; box-shadow:0 0 0 3px rgba(37,99,235,.35) !important; }
#ebys-havale-rules-modal select option { background:#FFFFFF !important; color:#0F172A !important; }
#ebys-havale-rules-modal .rules-box { font-size:12.5px !important; line-height:1.5 !important; }
#ebys-havale-rules-modal button { font-family:inherit !important; line-height:1.3 !important; }
#ebys-havale-rules-modal .ico { display:inline-flex !important; align-items:center; justify-content:center; width:22px !important; height:22px !important; padding:0 !important; border-radius:6px !important; font:700 14px/1 system-ui,sans-serif !important; cursor:pointer; border:1px solid transparent !important; }
#ebys-havale-rules-modal .ico-add { background:#15803D !important; color:#fff !important; }
#ebys-havale-rules-modal .ico-add-b { background:#1D4ED8 !important; color:#fff !important; }
#ebys-havale-rules-modal .ico-del { background:#7F1D1D !important; color:#FECACA !important; }
#ebys-havale-rules-modal .ico:hover { filter:brightness(1.2); }
#ebys-havale-rules-modal .tpl-free { display:inline-flex; align-items:center; gap:3px; background:#24365C; border:1px solid #3B5482; border-radius:12px; padding:1px 3px 1px 8px; font-size:11.5px; color:#E2E8F0; }
#ebys-firstrun-panel { position:fixed !important; right:16px !important; bottom:76px !important; z-index:2147483647 !important; width:360px; max-width:92vw; background:#F8FAFC !important; color:#0F172A !important; border:1px solid #CBD5E1 !important; border-left:5px solid #2563EB !important; border-radius:12px !important; box-shadow:0 12px 32px rgba(15,23,42,.28) !important; padding:12px 14px !important; font-size:13px !important; line-height:1.45 !important; }
#ebys-firstrun-panel .fr-h { font-weight:700; font-size:14px; margin-bottom:4px; color:#1E3A8A; }
#ebys-firstrun-panel .fr-s { margin:8px 0; padding:6px 8px; background:#E0E7FF; border-radius:8px; font-weight:600; color:#1E3A8A; }
#ebys-firstrun-panel .fr-b { display:flex; gap:6px; flex-wrap:wrap; }
#ebys-firstrun-panel button { font:600 12.5px 'Segoe UI',sans-serif !important; padding:6px 10px !important; border-radius:8px !important; border:1px solid #CBD5E1 !important; background:#FFFFFF !important; color:#0F172A !important; cursor:pointer; }
#ebys-firstrun-panel button.ebys-btn-primary { background:#2563EB !important; border-color:#2563EB !important; color:#FFFFFF !important; }
#ebys-firstrun-panel .fr-n { margin-top:8px; font-size:11.5px; color:#475569; }
#ebys-inbox-panel { font-size:12.5px; }
#ebys-inbox-panel button { border-radius:8px; font-family:inherit; }
#ebys-inbox-panel input::placeholder, #ebys-inbox-panel textarea::placeholder { color:#94A3B8 !important; -webkit-text-fill-color:#94A3B8 !important; opacity:1 !important; }
#ebys-toast { font-family:'Segoe UI', system-ui, sans-serif !important; line-height:1.45 !important; }
`;
        (document.head || document.documentElement).appendChild(st);
    }
    // ---- Okul Bilgileri profili (form doldurma) — yalnızca uzantı deposunda
    const OKUL_PROFIL_KEY = "ebys_okul_profil_v1";
    // v3.6.47 / v1.0.5: eski varsayılan kurum adı pakette yok; özet karşılaştırması (isEskiVarsayilanOkulAdi) ile boşaltılır
    function migrateOkulProfil(P) {
        if (!P || typeof P !== "object") return {};
        const o = Object.assign({}, P);
        if (isEskiVarsayilanOkulAdi(o.okulAdi)) o.okulAdi = "";
        if (o.kurumAdi && !o.okulAdi) o.okulAdi = o.kurumAdi;
        if (!o.kurumTuru) o.kurumTuru = "okul";
        if (!o.amirUnvani) o.amirUnvani = /mem|ilce|il\b/i.test(o.kurumTuru) ? "İlçe Milli Eğitim Müdürü" : "Okul Müdürü";
        if (!Array.isArray(o.mudurYrdList) && o.mudurYrd) o.mudurYrdList = String(o.mudurYrd).split(/\n|;/).map(x => x.trim()).filter(Boolean);
        if (!o.kayitHavaleVarsayilan && o.okulAdi) o.kayitHavaleVarsayilan = o.okulAdi;
        return o;
    }
    function getOkulProfil() {
        const v = extStoreGet(OKUL_PROFIL_KEY);
        const m = migrateOkulProfil((v && typeof v === "object" && !Array.isArray(v)) ? v : {});
        // tek seferlik temizlik: eski sabit ad kayıttaysa sil
        if (v && isEskiVarsayilanOkulAdi(v.okulAdi)) { try { extStoreSet(OKUL_PROFIL_KEY, Object.assign({}, v, { okulAdi: "" })); } catch(e) {} }
        return m;
    }
    function kurumSetupEksik() { return false; } // Müdür Paketi: kurum kodu ve lisans, lisans ekranında (lisans/lisans.html) alınır
    function lisMsg(d) { return (d && d.mesaj) || "Lisans durumu bilinmiyor."; }
    function lisAsk(op, ekstra) { // v1.0.7: ortak lisans (arka plan). Anahtar/deneme işlemleri lisans ekranında yapılır.
      return new Promise(r => { try { chrome.runtime.sendMessage({ type: "ea-lisans", op: (op === "durum" || op === "yenile") ? "durum" : "ac" }, x => { void chrome.runtime.lastError;
        if (x && x.ok) return r({ izin: true, durum: "ac", mesaj: "Lisans ekranı yeni sekmede açıldı; anahtarı veya denemeyi orada girin." });
        r(x && typeof x.izin === "boolean" ? x : { izin: true, durum: "?", mesaj: "Lisans durumu okunamadı." }); }); } catch (e) { r({ izin: true, durum: "?", mesaj: "Lisans durumu okunamadı." }); } }); }
    async function lisGate(aksiyon) { return true; } // v1.0.7: kapı arka planda — içerik betiği yalnız lisans/deneme geçerliyken yüklenir
    function openOkulProfilModal(force) {
        ensureSkin35(); let m = document.getElementById("ebys-okul-profil-modal"); if (m) m.remove();
        m = document.createElement("div"); m.id = "ebys-okul-profil-modal";
        m.style.cssText = "position:fixed !important; top:50% !important; left:50% !important; transform:translate(-50%,-50%) !important; width:520px !important; max-height:85vh; overflow:auto; background:#1F2D4D !important; border:2px solid #FBBF24 !important; border-radius:16px !important; z-index:2147483647 !important; padding:14px !important; color:#E2E8F0 !important; font:12px system-ui,sans-serif !important;";
        const P = getOkulProfil();
        const inp = "width:100%; padding:6px 8px; background:#FFFFFF; border:1px solid #94A3B8; border-radius:7px; color:#0F172A; box-sizing:border-box;";
        const sozOk = P.lisansKabul && P.lisansKabul.surum === ((self.EA_LISANS && EA_LISANS.SOZLESME_SURUMU) || "2026-10-23");
        const fieldsUi = [
            ["kurumTuru", "Kurum türü", "select", [["okul","Okul"],["ilce_mem","İlçe MEM"],["il_mem","İl MEM"],["diger","Diğer"]]],
            ["okulAdi", "Kurum adı", "text"],
            ["ustBirim", "Bağlı üst birim", "text"],
            ["kurumKodu", "Kurum kodu (zorunlu)", "text"],
            ["detsis", "DETSİS / MERSİS no", "text"],
            ["il", "İl", "text"],
            ["ilce", "İlçe", "text"],
            ["adres", "Adres", "text"],
            ["telefon", "Telefon", "text"],
            ["faks", "Faks", "text"],
            ["eposta", "E-posta", "text"],
            ["web", "Web", "text"],
            ["mudur", "Amir adı", "text"],
            ["amirUnvani", "Amir unvanı", "text"],
            ["kayitHavaleVarsayilan", "Gelen Evrak Kayıt — varsayılan havale", "text"]
        ];
        let body = '<div style="display:flex; justify-content:space-between;"><b style="color:#FBBF24;">🏫 Kurum Ayarları</b><button class="op-x" style="background:none;border:none;color:#A9B6CA;cursor:pointer;font-size:16px;">✕</button></div>';
        body += '<div style="font-size:10.5px;color:#94A3B8;margin:4px 0 8px;">Yalnızca bu bilgisayarda saklanır. Başka kurumlara satıldığında buradaki bilgiler o kuruma göre doldurulur. © Eyüp ŞEKER</div>';
        if (force || kurumSetupEksik()) body += '<div style="background:#451A03;border:1px solid #FBBF24;color:#FDE68A;padding:8px;border-radius:8px;margin-bottom:8px;font-weight:600;">İlk kurulum: kurum bilgilerini doldurun, sözleşmeyi onaylayın. 48 saatlik deneme başlar.</div>';
        fieldsUi.forEach(([k,l,t,opts]) => {
            if (t === "select") {
                body += '<label style="display:block;margin-bottom:5px;">' + escapeHtml(l) + '<select data-k="' + k + '" style="' + inp + '">' + opts.map(([v,n]) => '<option value="' + v + '"' + ((P[k]||"okul")===v?' selected':'') + '>' + escapeHtml(n) + '</option>').join("") + '</select></label>';
            } else body += '<label style="display:block;margin-bottom:5px;">' + escapeHtml(l) + '<input data-k="' + k + '" style="' + inp + '"></label>';
        });
        // müdür yrd +/- listesi
        const yrd = Array.isArray(P.mudurYrdList) ? P.mudurYrdList.slice() : (P.mudurYrd ? [P.mudurYrd] : [""]);
        body += '<div style="margin:8px 0 4px;font-weight:700;color:#FBBF24;">Müdür yardımcısı / şube müdürü</div><div class="op-yrd"></div>';
        body += '<button type="button" class="op-yrd-add" style="background:#2D3D63;color:#FDE68A;border:1px solid #FBBF24;padding:4px 10px;border-radius:8px;font-weight:bold;cursor:pointer;margin-bottom:8px;">＋ Satır ekle</button>';
        // v1.0.5: Telefon Rehberi (WhatsApp; yalnız bu bilgisayar)
        body += '<div style="border-top:1px solid #4B5D7A;margin:10px 0 8px;padding-top:8px;"><b style="color:#86EFAC;">📱 Telefon Rehberi</b><div style="font-size:10.5px;color:#94A3B8;margin:3px 0 6px;">WhatsApp ile paylaşım için. Ad, görev ve telefon yalnız bu bilgisayarda saklanır; otomatik mesaj gönderilmez.</div><div class="op-rehber-list" style="display:flex;flex-direction:column;gap:4px;margin-bottom:6px;"></div>';
        body += '<div class="op-rehber-form" style="background:#2D3D63;padding:8px;border-radius:10px;display:flex;flex-direction:column;gap:5px;"><input class="op-rh-ad" placeholder="Ad Soyad" style="' + inp + '"><input class="op-rh-gorev" placeholder="Görev (müdür yrd. / memur vb.)" style="' + inp + '"><input class="op-rh-tel" placeholder="Telefon (05XX XXX XX XX)" style="' + inp + '"><div style="display:flex;gap:6px;"><button type="button" class="op-rh-ekle" style="background:#15803D;color:white;border:none;padding:5px 10px;border-radius:8px;font-weight:bold;cursor:pointer;">＋ Kişi ekle</button><button type="button" class="op-rh-iptal" style="display:none;background:#2D3D63;color:#E2E8F0;border:1px solid #56709A;padding:5px 10px;border-radius:8px;cursor:pointer;">Vazgeç</button></div><div class="op-rh-msg" style="font-size:10.5px;color:#A7F3D0;"></div><div style="font-size:10px;color:#94A3B8;">Numara 90XXXXXXXXXX biçimine çevrilir; yalnızca Türkiye cep (5XX) kabul edilir.</div></div></div>';
        // lisans
        body += '<div style="border-top:1px solid #4B5D7A;margin:10px 0 8px;padding-top:8px;"><b style="color:#FBBF24;">🔑 Lisans / Abonelik</b><div class="op-lis-msg" style="margin:4px 0;color:#A7F3D0;font-size:11px;">Durum yükleniyor…</div>';
        body += '<label style="display:block;margin-bottom:5px;">Lisans anahtarı (EA-XXXX-XXXX-XXXX-XXXX)<input class="op-anahtar" style="' + inp + '" placeholder="Boş bırakılırsa 48 saatlik deneme"></label>';
        body += '<div style="display:flex;gap:6px;margin-bottom:8px;"><button type="button" class="op-lis-yenile" style="flex:1;background:#2D3D63;color:#7DD3FC;border:1px solid #38BDF8;padding:6px;border-radius:8px;font-weight:bold;cursor:pointer;">↻ Doğrula</button><button type="button" class="op-lis-gir" style="flex:1;background:#2563EB;color:white;border:none;padding:6px;border-radius:8px;font-weight:bold;cursor:pointer;">Anahtarı kaydet</button></div>';
        body += '<label style="display:flex;gap:8px;align-items:flex-start;margin:8px 0;background:#0F172A;padding:8px;border-radius:8px;border:1px solid ' + (sozOk?"#22C55E":"#F87171") + ';"><input type="checkbox" class="op-soz" ' + (sozOk?"checked":"") + ' style="margin-top:3px;"><span style="font-size:11px;line-height:1.4;">Evrak Asistanı <b>Lisans Sözleşmesi</b>\'ni okudum ve kabul ediyorum. (<a href="' + (typeof chrome!=="undefined"&&chrome.runtime?chrome.runtime.getURL("lisans.html"):"lisans.html") + '" target="_blank" style="color:#38BDF8;">Sözleşmeyi aç</a>) © Eyüp ŞEKER — yayıncı.</span></label></div>';
        body += '<div style="display:flex;gap:6px;justify-content:flex-end;margin-top:8px;"><span class="op-msg" style="flex:1;color:#86EFAC;"></span><button class="op-save" style="background:#10B981;color:white;border:none;padding:8px 14px;border-radius:8px;font-weight:bold;cursor:pointer;">💾 Kaydet</button></div>';
        m.innerHTML = body;
        document.body.appendChild(m);
        m.querySelectorAll("input[data-k],select[data-k]").forEach(i => { if (i.tagName === "INPUT") i.value = P[i.getAttribute("data-k")] || ""; });
        const yrdBox = m.querySelector(".op-yrd");
        const paintYrd = () => {
            yrdBox.innerHTML = "";
            (yrd.length ? yrd : [""]).forEach((ad, idx) => {
                const row = document.createElement("div"); row.style.cssText = "display:flex;gap:4px;margin-bottom:4px;";
                row.innerHTML = '<input style="' + inp + ';flex:1;" value="' + escapeHtml(ad) + '"><button type="button" style="background:#7F1D1D;color:#FECACA;border:1px solid #F87171;border-radius:8px;padding:0 10px;font-weight:bold;cursor:pointer;">−</button>';
                row.querySelector("input").oninput = e => { yrd[idx] = e.target.value; };
                row.querySelector("button").onclick = () => { yrd.splice(idx, 1); paintYrd(); };
                yrdBox.appendChild(row);
            });
        };
        paintYrd();
        m.querySelector(".op-yrd-add").onclick = () => { yrd.push(""); paintYrd(); };
        // v1.0.5: Telefon Rehberi (anında kaydedilir; Kurum Kaydet'ten bağımsız)
        (function bindRehber() {
            const listEl = m.querySelector(".op-rehber-list");
            const adEl = m.querySelector(".op-rh-ad"), gorevEl = m.querySelector(".op-rh-gorev"), telEl = m.querySelector(".op-rh-tel");
            const msgEl = m.querySelector(".op-rh-msg"), ekleBtn = m.querySelector(".op-rh-ekle"), iptalBtn = m.querySelector(".op-rh-iptal");
            let editId = null;
            const rhMsg = (t, warn) => { if (msgEl) { msgEl.textContent = t || ""; msgEl.style.color = warn ? "#FCA5A5" : "#A7F3D0"; } };
            const temiz = () => { editId = null; adEl.value = ""; gorevEl.value = ""; telEl.value = ""; ekleBtn.textContent = "＋ Kişi ekle"; iptalBtn.style.display = "none"; };
            const paint = () => {
                const list = rehberYukle();
                listEl.innerHTML = "";
                if (!list.length) { listEl.innerHTML = '<div style="color:#94A3B8;font-size:11px;">Henüz kişi yok.</div>'; return; }
                list.forEach(k => {
                    const row = document.createElement("div");
                    row.style.cssText = "display:flex;gap:6px;align-items:center;background:#2D3D63;border:1px solid #4B5D7A;border-radius:8px;padding:5px 6px;";
                    row.innerHTML = '<div style="flex:1;min-width:0;"><b style="color:#F8FAFC;">' + escapeHtml(k.ad) + '</b>' + (k.gorev ? ' <span style="color:#A9B6CA;">— ' + escapeHtml(k.gorev) + '</span>' : '') + '<div style="color:#86EFAC;font-size:10.5px;">' + escapeHtml(formatTrPhone(k.telefon)) + '</div></div>'
                        + '<button type="button" class="op-rh-duz" style="background:#1F2D4D;color:#93C5FD;border:1px solid #60A5FA;border-radius:7px;padding:3px 8px;cursor:pointer;font-size:10.5px;">Düzenle</button>'
                        + '<button type="button" class="op-rh-sil" style="background:#7F1D1D;color:#FECACA;border:none;border-radius:7px;padding:3px 8px;cursor:pointer;font-size:10.5px;">Sil</button>';
                    row.querySelector(".op-rh-duz").onclick = () => { editId = k.id; adEl.value = k.ad; gorevEl.value = k.gorev || ""; telEl.value = formatTrPhone(k.telefon); ekleBtn.textContent = "💾 Kişiyi kaydet"; iptalBtn.style.display = "inline-block"; rhMsg(""); adEl.focus(); };
                    row.querySelector(".op-rh-sil").onclick = () => { if (!confirm(k.ad + " rehberden silinsin mi?")) return; rehberKaydet(rehberYukle().filter(x => x.id !== k.id)); if (editId === k.id) temiz(); paint(); rhMsg("Silindi."); };
                    listEl.appendChild(row);
                });
            };
            ekleBtn.onclick = () => {
                const ad = (adEl.value || "").trim(), gorev = (gorevEl.value || "").trim(), tel = telEl.value;
                const d = rehberKisiDogrula({ id: editId || rehberYeniId(), ad: ad, gorev: gorev, telefon: tel });
                if (!d) { rhMsg(!ad ? "Ad soyad gerekli." : "Geçerli bir Türkiye cep numarası girin (05XX XXX XX XX).", true); return; }
                let list = rehberYukle();
                if (list.some(x => x.telefon === d.telefon && x.id !== d.id)) { rhMsg("Bu numara zaten kayıtlı.", true); return; }
                if (editId) list = list.map(x => x.id === d.id ? d : x); else list.push(d);
                rehberKaydet(list); temiz(); paint(); rhMsg(editId ? "Güncellendi." : "Eklendi.");
            };
            iptalBtn.onclick = () => { temiz(); rhMsg(""); };
            paint();
        })();
        m.querySelector(".op-x").onclick = () => m.remove();
        const refreshLis = () => lisAsk("durum").then(d => { m.querySelector(".op-lis-msg").textContent = lisMsg(d); m.querySelector(".op-lis-msg").style.color = d && d.izin ? "#86EFAC" : "#FCA5A5"; });
        refreshLis();
        m.querySelector(".op-lis-yenile").onclick = () => lisAsk("yenile").then(d => { m.querySelector(".op-lis-msg").textContent = lisMsg(d); refreshLis(); showToast(lisMsg(d), d && d.izin ? "ok" : "warn"); });
        m.querySelector(".op-lis-gir").onclick = () => {
            const a = m.querySelector(".op-anahtar").value.trim();
            if (!a) { showToast("Anahtar girin ya da deneme için boş bırakın.", "warn"); return; }
            lisAsk("anahtar", { anahtar: a }).then(d => { m.querySelector(".op-lis-msg").textContent = d.hata || lisMsg(d); showToast(d.hata || lisMsg(d), d && d.izin ? "ok" : "warn"); });
        };
        m.querySelector(".op-save").onclick = () => {
            if (!m.querySelector(".op-soz").checked) { showToast("⛔ Lisans sözleşmesini onaylamadan kaydedilemez.", "warn"); return; }
            const o = Object.assign({}, P);
            m.querySelectorAll("input[data-k],select[data-k]").forEach(i => { const v = (i.value || "").trim(); if (v) o[i.getAttribute("data-k")] = v.slice(0, 300); else delete o[i.getAttribute("data-k")]; });
            o.mudurYrdList = yrd.map(x => String(x || "").trim()).filter(Boolean);
            o.mudurYrd = o.mudurYrdList.join("; ");
            o.kurumAdi = o.okulAdi || "";
            if (!o.kayitHavaleVarsayilan) o.kayitHavaleVarsayilan = o.okulAdi || "";
            if (!o.kurumKodu) { showToast("⛔ Kurum kodu zorunlu (lisans buna bağlanır).", "warn"); return; }
            if (!o.okulAdi || !o.il) { showToast("⛔ Kurum adı ve il zorunlu.", "warn"); return; }
            o.lisansKabul = { surum: (self.EA_LISANS && EA_LISANS.SOZLESME_SURUMU) || "2026-10-23", at: new Date().toISOString() };
            const kayitP = Promise.resolve(extStoreSet(OKUL_PROFIL_KEY, o)).catch(() => {}); // v3.6.52: lisans isteği kayıttan sonra
            // kayit.js ile paylaş: varsayılan havale
            try { chrome.storage.local.get(["evrakKayitOtonom.v1"], r => { const bag = (r && r["evrakKayitOtonom.v1"]) || {}; const settings = Object.assign({}, bag.settings || {}, { okul: o.kayitHavaleVarsayilan || o.okulAdi }); chrome.storage.local.set({ "evrakKayitOtonom.v1": Object.assign({}, bag, { settings }) }); }); } catch(e) {}
            m.querySelector(".op-msg").textContent = "Kaydedildi.";
            // v3.6.52: KÖK NEDEN DÜZELTMESİ — anahtar kutusu doluyken 💾 Kaydet'e basılınca anahtar yok sayılıp "baslat" (48 saatlik deneme) isteniyordu
            const anah = (m.querySelector(".op-anahtar").value || "").trim();
            kayitP.then(() => anah ? lisAsk("anahtar", { anahtar: anah }) : lisAsk("baslat")).then(d => { if (d && d.hata) { m.querySelector(".op-lis-msg").textContent = d.hata; showToast("⚠️ Kurum kaydedildi; lisans anahtarı: " + d.hata, "warn"); return; } m.querySelector(".op-lis-msg").textContent = lisMsg(d); showToast("✅ Kurum kaydedildi. " + lisMsg(d), d && d.izin ? "ok" : "warn"); if (d && d.izin) setTimeout(() => m.remove(), 900); });
        };
    }
    async function ekFillAndDownload(fid) {
        const c = EK_CACHE.get(fid); if (!c) { showToast("Ek bellekte yok; evrakı yeniden açın.", "warn"); return null; }
        const P = getOkulProfil(), base = c.name.replace(/\.[a-z0-9]+$/i, "");
        let r;
        let ext = "xlsx", mime = XLSX_MIME;
        if (c.analysis.kind === "xlsx") r = await EBYS_EK.fillXlsx(c.bytes, P);
        else if (c.analysis.kind === "docx") { r = await EBYS_EK.fillDocx(c.bytes, P); ext = "docx"; mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"; } // v3.6.31
        else if (c.analysis.form && c.analysis.form.fields.length) r = EBYS_EK.labelsToXlsx(c.analysis.form.fields, P, c.name);
        else { showToast("Bu ekte doldurulacak form alanı bulunamadı.", "warn"); return null; }
        if (!r.ok) { showToast("Form doldurulamadı: " + (r.error || ""), "warn"); return null; }
        const fn = base + " (DOLDURULDU)." + ext;
        takipDownload(fn, r.bytes, mime);
        const box = document.querySelector('.ek-missing[data-fid="' + CSS.escape(fid) + '"]');
        if (box) box.innerHTML = r.missing.length ? '🟨 <b>Eksik (' + r.missing.length + '):</b><br>' + r.missing.map(x => '☐ ' + escapeHtml(x)).join("<br>") : "✅ Tüm alanlar dolduruldu.";
        showToast("📗 " + fn + " indirildi — " + r.filled + " alan dolu, " + r.missing.length + " eksik (sarı).", r.missing.length ? "warn" : "ok");
        return r;
    }
    document.addEventListener("click", (e) => {
        const b = e.target && e.target.closest && e.target.closest(".ek-fill-btn, .ek-profil-btn");
        if (!b) return;
        e.preventDefault(); e.stopPropagation();
        if (b.classList.contains("ek-profil-btn")) openOkulProfilModal(); else ekFillAndDownload(b.getAttribute("data-fid"));
    }, true);

    // NEW (v3): analiz için tek giriş — gerçek EBYS'de pdf.js + ek tablosu, diğerlerinde v2 yolu
    async function readDocForAnalysis(d) {
        if (isRealEbys() && getPreviewForm()) {
            const pv = await readRealPreview(d);
            let att;
            try { att = await readRealAttachmentsAsync(); } catch(e) { att = { tabFound: false, items: [], timedOut: false, error: "ek sekmesi okunamadı: " + String(e && e.message || e) }; } // v3.6.31
            try { att = await enrichRealAttachments(att, d && d.docNo); } catch(e) { console.warn("[Evrak Asistanı] ek okuma:", e); } // v3.6.30
            if (att && att._restore) { try { clickTab(att._restore); } catch(e) {} delete att._restore; } // önceki sekmeye dön
            return { previewText: pv.text, att: att, verified: pv.verified, evrakTarihi: pv.evrakTarihi, source: pv.source };
        }
        const previewText = await waitForPreview(d, PREVIEW_TIMEOUT_MS);
        const att = await readAttachmentsSafe();
        return { previewText: previewText, att: att, verified: !!previewText, evrakTarihi: "", source: previewText ? "önizleme" : "" };
    }

    // ---- NEW (v3): Cevap Yaz penceresi ve gerçek editör
    function isCevapWindowOpen() {
        const d = document.getElementById("windowCevapEvrakDialog");
        if (d && isVisible(d)) return true;
        const m = document.querySelector('[id$="cevapEvrakTabMenuLeft"]');
        return !!(m && isVisible(m));
    }
    function findRealEbysEditor() {
        for (const c of document.querySelectorAll('div.cke[id^="cke_"]')) {
            const name = c.id.slice(4);
            if (/sablon|şablon|konu/i.test(name)) continue;
            const voice = (c.querySelector(".cke_voice_label") || {}).textContent || "";
            if (!/ckeditorInstance_window\d*$/.test(name) && !/Evrak Editör/.test(voice)) continue;
            if (!isVisible(c)) continue;
            const f = c.querySelector("iframe.cke_wysiwyg_frame");
            if (!f) continue; // paylaşılan araç çubuğu kabı (cke_shared/cke_detached) aynı id'yi taşır ama editör değildir
            let body = null;
            try { body = f && f.contentDocument && f.contentDocument.body; } catch(e) {}
            return { kind: "ebys-cke", name: name, el: body && body.isContentEditable ? body : null, ta: document.getElementById(name), doc: document, container: c };
        }
        return null;
    }
    // NEW (v3): editöre yaz — gerçek CKEditor'da önce API (aynı dünya → köprü), sonra iframe gövdesi
    async function injectIntoEditorsSmart(html, plain) { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        const t = findEditorTarget();
        if (!t) return null;
        if (t.kind !== "ebys-cke") return injectIntoEditors(html, plain);
        try {
            const CK = window.CKEDITOR, inst = CK && CK.instances && CK.instances[t.name];
            if (inst && typeof inst.setData === "function") { inst.setData(html); return "ckeditor-api"; }
        } catch(e) {}
        if (await bridgeAvailable()) {
            const r = await bridgeCall("ckSetData", { name: t.name, html: html }, 4000);
            if (r && r.ok) return "ckeditor-api";
        }
        if (t.el) {
            t.el.innerHTML = html;
            ["input", "change", "keyup"].forEach(n => { try { t.el.dispatchEvent(new Event(n, { bubbles: true })); } catch(e) {} });
            try { if (t.ta) t.ta.value = html; } catch(e) {}
            return "iframe-body";
        }
        return null;
    }

    // ---- NEW (v3): gerçek "Evrak Kapat" paneli (diyalog değil, önizleme formunda fieldset)
    // v3.6.26: "Dağıtım uyarısı kapanmadı" yanlış alarmı — kapanış kontrolü 2,5 sn boyunca yeniden denenir (akış hızı aynı).
// v3.6.25: CANLI KÖK NEDEN — AJAX güncellemesi formu yeniden çizince eski (kopuk) 'form' öğesinde seçim hiç görünmüyordu → başarı
    // koşulları zaman aşımına düşüyordu. Önce verilen kapsam, boşsa GÜNCEL belgelerde (tanı raporundaki okuyucuyla aynı yöntem) aranır.
    function lovSelectedTitle(scope, lovId) {
        let r = "";
        try { r = lovSelectedTitleIn(scope, lovId); } catch(e) {}
        if (r) return r;
        try { const cs = cevapScopeEl(); if (cs && cs !== scope) r = lovSelectedTitleIn(cs, lovId); } catch(e) {}
        if (r) return r;
        for (const doc of getAllDocs()) { try { if (doc !== scope) { r = lovSelectedTitleIn(doc, lovId); if (r) return r; } } catch(e) {} }
        return "";
    }
    function lovSelectedTitleIn(scope, lovId) {
        const el = scope.querySelector('[id$="' + lovId + ':LovSecilen"]');
        const t = el && el.querySelector(".lovItemTitle");
        if (t && (t.textContent || "").trim() && isVisible(el)) {
            const det = el.querySelector(".lovItemDetail");
            return (t.textContent || "").trim() + (det && (det.textContent || "").trim() ? " (" + det.textContent.trim() + ")" : "");
        }
        // çoklu seçimli LoV (ör. Kaldırılacak Klasörler): seçimler LovSecilenTable satırlarında
        const tb = scope.querySelector('[id$="' + lovId + ':LovSecilenTable_data"]');
        const tbl = tb && tb.closest(".ui-datatable");
        if (tb && (!tbl || isVisible(tbl))) {
            const rows = Array.from(tb.querySelectorAll(":scope > tr")).filter(r => !r.classList.contains("ui-datatable-empty-message") && (r.textContent || "").trim());
            if (rows.length) return rows.map(r => (r.textContent || "").replace(/\s+/g, " ").trim()).join(", ");
        }
        return "";
    }
    function lovSelectedDetail(scope, lovId) {
        let el = scope.querySelector('[id$="' + lovId + ':LovSecilen"] .lovItemDetail');
        if (!el || !el.isConnected) { for (const doc of getAllDocs()) { try { el = doc.querySelector('[id$="' + lovId + ':LovSecilen"] .lovItemDetail'); if (el) break; } catch(e) {} } }
        return el ? (el.textContent || "").trim() : "";
    }
    // v3.6.52: LoV öğesinin kendi kodu — "[Klasör] 499" / "[Konu Kodu] 499" (Üst Klasör hariç) ya da .lovItemDetail'in tamamı kodsa o
    function lovItemCode(n) {
        const box = (n.closest && (n.closest(".ui-treenode-content") || n.closest("tr, li"))) || n;
        const det = box.querySelector && box.querySelector(".lovItemDetail");
        const dt = det ? (det.textContent || "").replace(/\s+/g, " ").trim() : "";
        if (/^\d+(?:\.\d+)*$/.test(dt)) return dt;
        const m = trFold(box.textContent || "").replace(/\s+/g, " ").match(/\[(?:klasor|konu kodu|kod)\]\s*(\d+(?:\.\d+)*)/);
        if (m) return m[1];
        const m2 = dt.match(/^\[(?:klas[oö]r|konu kodu|kod)\]\s*(\d+(?:\.\d+)*)/i);
        return m2 ? m2[1] : "";
    }
    function lovItemTitleText(n) {
        const box = (n.closest && (n.closest(".ui-treenode-content") || n.closest("tr, li"))) || n;
        const t = (box.querySelector && box.querySelector(".lovItemTitle")) || n;
        return trFold(t.textContent || "").replace(/\s+/g, " ").trim();
    }
    async function fillLov(scope, lovId, query, titleHint) {
        const inp = scope.querySelector('[id$="' + lovId + ':LovText"]');
        if (!inp || !query) return false;
        try { inp.focus(); } catch(e) {}
        setNativeValue(inp, query);
        ["keydown", "keyup"].forEach(type => {
            let ev; try { ev = new KeyboardEvent(type, { bubbles: true, cancelable: true, key: query.slice(-1), code: "Digit0", keyCode: 48, which: 48 }); } catch(e) { ev = new Event(type, { bubbles: true }); }
            try { if (!ev.keyCode) Object.defineProperty(ev, "keyCode", { get: () => 48 }); } catch(e) {}
            inp.dispatchEvent(ev);
        });
        const node = await waitFor(() => {
            const dlg = findLovDialog(scope, lovId);
            if (!dlg || !isVisible(dlg)) return null;
            let nodes = Array.from(dlg.querySelectorAll(".ui-treenode-label, .ui-treenode-content")).filter(n => isVisible(n) && (n.textContent || "").trim());
            // v3.6.52: ağaç yoksa liste/tablo öğeleri (başlık + "[Klasör] kod" aynı kapta)
            if (!nodes.length) nodes = Array.from(dlg.querySelectorAll("tr[data-ri], tr[data-rk], li.ui-autocomplete-item, li[data-item-value]")).filter(n => isVisible(n) && (n.textContent || "").trim());
            if (!nodes.length) nodes = Array.from(dlg.querySelectorAll(".lovItemTitle")).filter(n => isVisible(n) && (n.textContent || "").trim()).map(n => n.parentElement || n);
            lovCaptureHtml(dlg);
            if (!nodes.length) return null;
            const labels = nodes.filter(n => n.classList.contains("ui-treenode-label"));
            const pool = labels.length ? labels : nodes;
            // v3.6.52: KESİN KOD — "499" yazınca "(450-499) [Klasör] 450" ve "[Klasör] 499" birlikte gelir; kodu tam eşit olan seçilir
            const byCode = pool.filter(n => lovItemCode(n) === query);
            if (byCode.length === 1) return byCode[0];
            if (titleHint) { const th = trFold(titleHint).replace(/\s+/g, " ").trim(); const byTitle = (byCode.length ? byCode : pool).filter(n => lovItemTitleText(n) === th); if (byTitle.length === 1) return byTitle[0]; }
            if (byCode.length > 1) return "MULTI";
            const hits = pool.filter(n => (n.textContent || "").includes(query));
            if (hits.length === 1) return hits[0];
            const exact = hits.filter(n => new RegExp("^\\s*" + query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(\\s|-|$)").test(n.textContent || ""));
            if (exact.length === 1) return exact[0];
            if (!hits.length && pool.length === 1) return pool[0];
            return "MULTI";
        }, 6000, 200);
        if (!node || node === "MULTI") { dbg("LoV", lovId, "için tek/eşleşen seçenek bulunamadı:", node ? "birden çok seçenek" : "seçenek yok"); return false; }
        (node.closest(".ui-treenode-content") || node).click();
        return !!(await waitFor(() => lovSelectedTitle(scope, lovId), 5000, 200));
    }
    async function handleCloseReal(d) { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        const docLabel = d && d.docNo ? d.docNo : "açık";
        const btn = findToolbarButton("Evrak Kapat");
        if (!btn) return { ok: false, msg: "Önizlemede 'Evrak Kapat' düğmesi bulunamadı (evrak açık mı?)." };
        btn.click();
        const fs = await waitFor(() => { const f = document.querySelector('fieldset[id$="evrakKapatFieldsetId"]'); return f && isVisible(f) ? f : null; }, 10000, 200);
        if (!fs) return { ok: false, msg: "'Evrak Kapatma' paneli açılmadı." };
        const scope = fs.closest("form") || document;
        let konu = lovSelectedTitle(scope, "konuKoduLov");
        const kodFromNo = ((d && d.docNo ? d.docNo : "").match(/^E-\d+-([\d.]+)-\d+$/) || [])[1] || "";
        if (!konu && kodFromNo) { await fillLov(scope, "konuKoduLov", kodFromNo); konu = lovSelectedTitle(scope, "konuKoduLov"); }
        if (!konu) return { ok: false, msg: "Konu kodu seçili değil ve otomatik seçilemedi. Panel açık bırakıldı; konu kodunu seçip 'Evrak Kapat'a kendiniz basın." };
        let klasor = lovSelectedTitle(scope, "klasorLov_id");
        if (!klasor) {
            const det = lovSelectedDetail(scope, "konuKoduLov"), dm = det.match(/\d+(?:\.\d+)*/); // v3.6.52: yalnızca kod ("[Klasör] 499" → "499")
            const q = (dm ? dm[0] : det) || kodFromNo;
            const konuBaslik = (() => { try { const e = scope.querySelector('[id$="konuKoduLov:LovSecilen"] .lovItemTitle'); return e ? (e.textContent || "").trim() : ""; } catch(e) { return ""; } })();
            if (q) await fillLov(scope, "klasorLov_id", q, konuBaslik);
            klasor = lovSelectedTitle(scope, "klasorLov_id");
        }
        if (!klasor) return { ok: false, msg: "Kaldırılacak klasör otomatik seçilemedi. Panel açık bırakıldı; klasörü seçip 'Evrak Kapat'a kendiniz basın." };
        const ok = scope.querySelector('button[id$="onaysizKapatId"]') || Array.from(fs.querySelectorAll("button")).find(b => (b.textContent || "").trim() === "Evrak Kapat" && isVisible(b));
        if (!ok) return { ok: false, msg: "Kapatma onay düğmesi bulunamadı." };
        if (!confirm(`"${docLabel}" evrakı kapatılacak.\nKonu kodu: ${konu}\nKaldırılacak klasör: ${klasor}\n\nOnaylıyor musunuz?`)) return { ok: false, cancelled: true, msg: "İptal edildi." };
        ok.click();
        dbg("Evrak kapatma onaylandı:", docLabel);
        return { ok: true };
    }
    async function handleCloseDocument(d) { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        if (isRealEbys() && getPreviewForm()) return await handleCloseReal(d);
        const r = await handleCloseGeneric();
        return r ? { ok: true } : { ok: false, msg: "kapatma diyalogu / konu kodu / onay düğmesi bulunamadı" };
    }

    // FIX (v3): sayfalama yalnızca ana listeye ait — gerçek EBYS'de YALNIZCA Gelen Evraklar tablosunun sayfalayıcısı;
    // diğerlerinde bildirim/duyuru panelleri, gizli tablolar, diyaloglar ve panel hariç
    function isExcludedArea(el) {
        return !!(el.closest("#bildirimler") || el.closest(".ui-dialog") || el.closest("#ebys-inbox-panel") || el.closest("#westBoardForm") || el.closest("#eastBoardForm") || el.closest(".mainDashboard") || el.closest('[id*="bildirim" i]'));
    }
    function paginatorScopes() {
        const root = getInboxRoot();
        if (root) return [root];
        return getAllDocs();
    }
    function findPaginatorButton(kind, enabledOnly) {
        for (let scope of paginatorScopes()) {
            for (let b of scope.querySelectorAll(".ui-paginator-" + kind)) {
                if (isExcludedArea(b) || !isVisible(b)) continue;
                if (enabledOnly && b.classList.contains("ui-state-disabled")) continue;
                return b;
            }
        }
        return null;
    }

    // FIX (v3): ana tablolar — gerçek EBYS'de yalnızca Gelen Evraklar gövdesi; diğerlerinde görünür ve bildirim dışı tablolar


    function getMainTables() {
        const out = [];
        for (let doc of getAllDocs()) {
            doc.querySelectorAll(".ui-datatable-data").forEach(t => {
                if (t.closest("#bildirimler") || t.closest(".ui-dialog") || t.closest("#ebys-inbox-panel")) return;
                out.push(t);
            });
        }
        return out;
    }

    function findPaginatorPage(which) {
        for (let doc of getAllDocs()) {
            for (let p of doc.querySelectorAll(".ui-paginator-page")) {
                if (p.closest("#bildirimler") || p.closest(".ui-dialog") || p.closest("#ebys-inbox-panel")) continue;
                if (which === "active") { if (p.classList.contains("ui-state-active")) return p; }
                else if ((p.textContent || "").trim() === String(which)) return p;
            }
        }
        return null;
    }

    // NEW: tablonun parmak izi — AJAX ile içerik değişti mi?
    function tableSignature() {
        const act = findPaginatorPage("active");
        return getMainTables().map(t => {
            const txt = t.innerText || t.textContent || "";
            const rks = Array.from(t.querySelectorAll(":scope > tr[data-rk]")).map(r => r.getAttribute("data-rk")).join(","); // NEW (v3)
            return t.querySelectorAll("tr").length + ":" + txt.length + ":" + rks + ":" + txt.slice(0, 300) + "|" + txt.slice(-150);
        }).join("#") + "@" + (act ? act.textContent : "") + "@" + inboxHeaderText();
    }

    // NEW: PrimeFaces yükleme göstergesi görünür mü?
    function isAjaxBusy() {
        for (let doc of getAllDocs()) {
            for (let el of doc.querySelectorAll(".ui-datatable-loading, .ui-blockui, .ui-blockui-content")) {
                if (!el.closest("#ebys-inbox-panel") && isVisible(el)) return true;
            }
            // v3.6.9: EBYS 'Lütfen Bekleyiniz' örtüsü / durum penceresi
            for (let el of doc.querySelectorAll(".ui-dialog, .ui-overlaypanel, [id*='statusDialog'], [id*='ajaxStatus'], [id*='bekleyiniz' i], .ui-widget-overlay + div")) {
                if (el.closest("#ebys-inbox-panel") || !isVisible(el)) continue;
                const t = (el.textContent || "").replace(/\s+/g, " ").trim();
                if (t.length < 80 && /l[uü]tfen\s*bekleyiniz/i.test(t)) return true;
            }
        }
        return false;
    }

    // NEW: AJAX güncellemesini bekle — içerik değişip yükleme göstergesi kaybolana kadar (MutationObserver + yoklama + zaman aşımı)
    function waitForTableChange(prevSig, timeoutMs = AJAX_TIMEOUT_MS) {
        return new Promise(resolve => {
            const t0 = Date.now();
            let done = false, timer = null;
            const observers = [];
            const ready = () => !isAjaxBusy() && tableSignature() !== prevSig;
            const finish = (ok) => {
                if (done) return;
                done = true;
                observers.forEach(o => { try { o.disconnect(); } catch(e) {} });
                clearTimeout(timer);
                setTimeout(() => resolve(ok), ok ? 150 : 0);
            };
            const poll = () => {
                if (done) return;
                if (ready()) { finish(true); return; }
                if (Date.now() - t0 > timeoutMs) { finish(false); return; }
                timer = setTimeout(poll, 120);
            };
            try {
                getAllDocs().forEach(d => {
                    if (!d.body) return;
                    const o = new MutationObserver(() => { if (!done && ready()) finish(true); });
                    o.observe(d.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ["class", "style"] });
                    observers.push(o);
                });
            } catch(e) {}
            poll();
        });
    }

    async function clickAndWait(el, timeoutMs) {
        const sig = tableSignature();
        el.click();
        return await waitForTableChange(sig, timeoutMs);
    }

    // NEW: sonraki sayfa var mı? (ileri düğmesi ya da bir sonraki sayfa numarası)
    function hasNextPage() {
        if (findPaginatorButton("next", true)) return true;
        const act = findPaginatorPage("active");
        const n = act ? parseInt((act.textContent || "").trim(), 10) : NaN;
        return !isNaN(n) && !!findPaginatorPage(n + 1);
    }

    // NEW: sonraki sayfaya geç (ileri düğmesi yoksa sayfa numarasıyla); sayfa değişmezse false
    async function goNextPage() {
        const next = findPaginatorButton("next", true);
        if (next) return await clickAndWait(next);
        const act = findPaginatorPage("active");
        const n = act ? parseInt((act.textContent || "").trim(), 10) : NaN;
        const link = !isNaN(n) ? findPaginatorPage(n + 1) : null;
        if (link) return await clickAndWait(link);
        return false;
    }

    // NEW: ilk sayfaya dön (ilk düğmesi → "1" bağlantısı → geri düğmesiyle adım adım); başarısızsa false
    async function goFirstPage() {
        const act = findPaginatorPage("active");
        if (act && (act.textContent || "").trim() === "1") return true;
        const first = findPaginatorButton("first", true);
        if (first) return await clickAndWait(first);
        const p1 = findPaginatorPage(1);
        if (p1 && !p1.classList.contains("ui-state-active")) return await clickAndWait(p1);
        for (let i = 0; i < MAX_OPEN_PAGES; i++) {
            const prev = findPaginatorButton("prev", true);
            if (!prev) break;
            if (!(await clickAndWait(prev))) return false;
        }
        return true;
    }

    // NEW: "sayfa başına kayıt" en büyük değere (yalnızca genel modda; gerçek EBYS'de kullanıcının ayarı DEĞİŞTİRİLMEZ)
    async function maximizeRowsPerPage() {
        if (getInboxRoot()) return false;
        for (let doc of getAllDocs()) {
            for (let sel of doc.querySelectorAll("select.ui-paginator-rpp-options")) {
                if (isExcludedArea(sel)) continue;
                const opts = Array.from(sel.options).map(o => ({ v: o.value, n: parseInt(o.value, 10) })).filter(o => !isNaN(o.n));
                if (!opts.length) return false;
                const max = opts.reduce((a, b) => (b.n > a.n ? b : a));
                if (String(sel.value) === String(max.v)) return false;
                const sig = tableSignature();
                sel.value = max.v;
                sel.dispatchEvent(new Event("change", { bubbles: true }));
                return await waitForTableChange(sig);
            }
        }
        return false;
    }

    // NEW (v3): evrak açma — gerçek EBYS'de satır (data-rk) üzerinden, değilse genel yol
    async function findAndOpenDocument(targetNo, d) {
        if (!targetNo || targetNo === "undefined") return false;
        if (isRealEbys()) {
            const meta = d || scannedList.find(x => x.docNo === targetNo) || { docNo: targetNo, rk: "" };
            const r = await openRealDocument(meta);
            lastOpenFailure = r.ok ? "" : r.reason;
            return r.ok;
        }
        return await findAndOpenGeneric(targetNo);
    }
    let lastOpenFailure = "";

    async function findAndOpenGeneric(targetNo) { // v2 genel yol (gerçek EBYS dışı sayfalar)
        if (!targetNo || targetNo === "undefined") return false; // FIX
        const shortNo = targetNo.includes("-") ? targetNo.split("-").pop() : targetNo;
        // FIX: kısa numara yalnızca rakam sınırlarıyla eşleşir (başka bir numaranın parçasına denk gelmesin)
        const shortRe = (shortNo.length > 5 && shortNo !== targetNo)
            ? new RegExp("(^|\\D)" + shortNo.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(\\D|$)") : null;

        // NEW: yalnızca ana tablolarda ara
        function findRowInTables() {
            for (let t of getMainTables()) {
                for (let r of t.querySelectorAll("tr")) {
                    const txt = r.innerText || "";
                    if (txt.includes(targetNo) || (shortRe && shortRe.test(txt))) {
                        r.scrollIntoView({ behavior: "smooth", block: "center" });
                        r.style.backgroundColor = "#fef08a";
                        const clickable = r.querySelector("a, .ui-cell-data, td") || r;
                        clickable.click();
                        setTimeout(() => { r.style.backgroundColor = ""; }, 2000);
                        return true;
                    }
                }
            }
            return false;
        }

        // NEW: önce mevcut sayfa; sonra ilk sayfadan itibaren tüm sayfalar (her geçişte AJAX beklenir, döngü korumalı)
        async function searchAllPages() {
            if (findRowInTables()) return true;
            await goFirstPage();
            if (findRowInTables()) return true;
            const seen = new Set([tableSignature()]);
            for (let p = 1; p < MAX_OPEN_PAGES; p++) {
                if (!hasNextPage()) break;
                if (!(await goNextPage())) break;
                const sig = tableSignature();
                if (seen.has(sig)) break;
                seen.add(sig);
                if (findRowInTables()) return true;
            }
            return false;
        }

        if (await searchAllPages()) return true;

        for (let doc of getAllDocs()) {
            const allLinks = Array.from(doc.querySelectorAll("a, span, td, div.ui-tree-node-content, li"));
            const inboxLink = allLinks.find(el => !el.closest("#ebys-inbox-panel") && (el.innerText || "").trim().startsWith("Gelen Evraklar"));
            if (inboxLink) {
                const sig = tableSignature();
                (inboxLink.querySelector("a") || inboxLink).click();
                await waitForTableChange(sig, 4000); // NEW: sabit 2 sn yerine içerik değişimi beklenir
                if (await searchAllPages()) return true;
                break;
            }
        }
        return false;
    }

    let ebysCloseInProgress = false;

    function findToolbarCloseButton() {
        for (let doc of getAllDocs()) {
            const btns = doc.querySelectorAll("button, a, .ui-button, span.ui-button-text");
            for (let b of btns) {
                if (b.closest("#ebys-inbox-panel")) continue;
                // FIX: gizli düğmeler ve açık kapatma diyalogunun kendi "Evrak Kapat" düğmesi araç çubuğu düğmesi sayılmaz
                if (!isVisible(b)) continue;
                const dl = b.closest(".ui-dialog, [role='dialog']");
                if (dl && (dl.textContent || "").includes("Kaldırılacak")) continue;
                if ((b.innerText || b.textContent || "").trim() === "Evrak Kapat") return { el: b, doc: doc };
            }
        }
        return null;
    }

    // FIX: yalnızca GÖRÜNÜR ve "Kaldırılacak" içeren açık diyalog kabul edilir (gizli, önceden render edilmiş diyaloglar elenir)
    function findCloseDialog() {
        for (let doc of getAllDocs()) {
            for (let dl of doc.querySelectorAll(".ui-dialog, [role='dialog'], .modal")) {
                if (dl.closest("#ebys-inbox-panel")) continue;
                if (!isVisible(dl)) continue;
                if ((dl.textContent || "").includes("Kaldırılacak")) return { doc: doc, el: dl };
            }
        }
        return null;
    }

    function findKonuKodu(scope) {
        try {
            const root = scope && scope.body ? scope.body : scope;
            const bodyText = root ? (root.innerText || "") : "";
            const idx = bodyText.indexOf("Konu Kodu");
            if (idx < 0) return "";
            // FIX: noktalı kodun tamamı alınır (ör. 302.01); tarih biçimli sayılar atlanır
            const nums = bodyText.substr(idx + 9, 500).match(/\d+(?:\.\d+)*/g) || [];
            for (let v of nums) {
                if (/^\d{1,2}\.\d{1,2}\.\d{4}$/.test(v)) continue;
                if (/^\d{2,8}(?:\.\d{1,4})*$/.test(v) && v !== "0") return v;
            }
        } catch(e) {}
        return "";
    }

    function setLoVValue(dialogDoc, lovTextInput, value) {
        setNativeValue(lovTextInput, value);
        try {
            const valInp = dialogDoc.querySelector('[id$="lovValue"], [name$="LoVValue"]');
            if (valInp) { valInp.value = value; valInp.dispatchEvent(new Event('change', { bubbles: true })); }
        } catch(e) {}
        return true;
    }

    // FIX: başarı durumunu döndürür (true = kapatma diyalogunda onay düğmesine basıldı) — v3: genel (diyalog tabanlı) yol
    async function handleCloseGeneric() { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        if (ebysCloseInProgress) return false;
        const found = findToolbarCloseButton();
        if (!found) return false;

        ebysCloseInProgress = true;
        try {
            found.el.click();
            let dlg = null;
            for (let attempt = 0; attempt < 20; attempt++) {
                await new Promise(r => setTimeout(r, 400));
                dlg = findCloseDialog(); // FIX: görünür açık diyalog
                if (dlg) break;
            }
            if (!dlg) return false;

            // FIX: konu kodu önce diyalog içinde, yoksa (eskisi gibi) diyalogun bulunduğu belgede aranır
            const konuKoduValue = findKonuKodu(dlg.el) || findKonuKodu(dlg.doc);
            const LOV_SEL = '[id$=":lovText"], [id$="lovText"], [name$="LoVText"]';
            // FIX: LoV alanı önce açık diyalogun içinde aranır; yoksa yalnızca görünür alanlar kabul edilir
            let lovTextInput = dlg.el.querySelector(LOV_SEL);
            if (!lovTextInput) {
                for (let doc of getAllDocs()) {
                    lovTextInput = Array.from(doc.querySelectorAll(LOV_SEL)).find(i => !i.closest("#ebys-inbox-panel") && isVisible(i)) || null;
                    if (lovTextInput) break;
                }
            }

            if (konuKoduValue && lovTextInput) {
                setLoVValue(dlg.el, lovTextInput, konuKoduValue); // FIX: gizli LoV değeri de diyalog içinden
                await new Promise(r => setTimeout(r, 600));
                // FIX: onay düğmesi YALNIZCA açık diyalogun içinde aranır (araç çubuğundaki "Evrak Kapat" tekrar tıklanmaz)
                const allBtns = Array.from(dlg.el.querySelectorAll("button, a, .ui-button"));
                for (let b of allBtns) {
                    if (!isVisible(b)) continue;
                    const txt = (b.textContent || "").trim();
                    if (txt === "Evrak Kapat" || txt === "Kaydet" || txt === "Tamam") {
                        b.click();
                        return true;
                    }
                }
            }
            return false;
        } catch(err) {
            console.error("[Evrak Asistanı] Kapatma hatası:", err);
            return false;
        } finally {
            ebysCloseInProgress = false;
        }
    }

    // =========================================================================
    // 6. EDİTÖR ENJEKSİYONU
    // =========================================================================
    // NEW: panelin kendi öğeleri mi? (panel, modallar, bildirim)
    function isPanelEl(el) {
        return !!(el && el.closest && (el.closest("#ebys-inbox-panel") || el.closest("#ebys-template-modal") || el.closest("#ebys-staff-modal") || el.closest("#ebys-toast") || el.closest("#ebys-takip-detay") || el.closest("#ebys-diag-box") || el.closest("#ebys-havale-confirm") || el.closest("#ebys-havale-rules-modal") || el.closest("#ebys-takip-toast") || el.closest("#ebys-wa-paylas") || el.closest("#ebys-okul-profil-modal"))); // v3.3: havale onay; v3.4: kural; v3.5: takip bildirimi; v1.0.5: WhatsApp seçici + Kurum Ayarları
    }

    // NEW: konu / başlık alanı mı? (bu alanlara ASLA metin yazılmaz)
    function isSubjectField(el) {
        try {
            if (!el || el.nodeType !== 1) return false;
            const attrs = [el.id, el.getAttribute("name"), el.getAttribute("placeholder"), el.getAttribute("aria-label"), el.getAttribute("title")].filter(Boolean).join(" ");
            if (/konu|subject|ba[sş]l[iı]k/i.test(attrs)) return true;
            const doc = el.ownerDocument;
            if (el.id) {
                const lb = doc.querySelector('label[for="' + CSS.escape(el.id) + '"]');
                if (lb && /konu|ba[sş]l[iı]k/i.test(lb.textContent || "")) return true;
            }
            const wrap = el.closest("label");
            if (wrap && /konu/i.test(wrap.textContent || "")) return true;
            const row = el.closest("tr, .ui-grid-row, .form-group");
            if (row && /^\s*konu/i.test(row.textContent || "")) return true;
        } catch(e) {}
        return false;
    }

    // NEW: doğru editör gövdesini bul — öncelik: CKEditor API > CKEditor iframe gövdesi > contenteditable > gövde textarea'sı.
    // <input> hiçbir zaman seçilmez; konu/başlık alanları, gizli alanlar ve panelin kendi alanları elenir.
    function findEditorTarget() {
        const real = findRealEbysEditor(); // NEW (v3): gerçek Cevap Yaz → Editör (CKEditor "Evrak Editör")
        if (real) return real;
        const docs = getAllDocs();
        for (let doc of docs) {
            let CK = null;
            try { CK = doc.defaultView && doc.defaultView.CKEDITOR; } catch(e) {}
            if (!CK || !CK.instances) continue;
            for (let k of Object.keys(CK.instances)) {
                const inst = CK.instances[k];
                if (!inst || typeof inst.setData !== "function") continue;
                if (/konu|subject|ba[sş]l[iı]k|sablon|şablon/i.test(inst.name || k)) continue; // FIX (v3): şablon önizleme editörü hedef değildir
                const el = inst.element && inst.element.$;
                const cont = inst.container && inst.container.$;
                if (el && isSubjectField(el)) continue;
                if (cont && (!isVisible(cont) || isSubjectField(cont))) continue;
                return { kind: "ckeditor-api", inst: inst, doc: doc };
            }
        }
        for (let doc of docs) {
            for (let f of doc.querySelectorAll("iframe")) {
                if (isPanelEl(f) || !isVisible(f) || isSubjectField(f)) continue;
                let fd = null;
                try { fd = f.contentDocument; } catch(e) {}
                if (!fd || !fd.body) continue;
                if (fd.body.isContentEditable || String(fd.designMode).toLowerCase() === "on") return { kind: "iframe-body", el: fd.body, doc: fd };
            }
        }
        for (let doc of docs) {
            for (let el of doc.querySelectorAll("[contenteditable]")) {
                if (el.tagName === "BODY" || !el.isContentEditable) continue;
                if (el.parentElement && el.parentElement.isContentEditable) continue;
                if (isPanelEl(el) || !isVisible(el) || isSubjectField(el)) continue;
                return { kind: "contenteditable", el: el, doc: doc };
            }
        }
        for (let doc of docs) {
            for (let t of doc.querySelectorAll("textarea")) {
                if (isPanelEl(t) || t.disabled || t.readOnly || !isVisible(t) || isSubjectField(t)) continue;
                if (/editor|edit[oö]r|icerik|içerik|cevap|metin|govde|gövde/i.test((t.id || "") + " " + (t.getAttribute("name") || ""))) return { kind: "textarea", el: t, doc: doc };
            }
        }
        return null;
    }

    // NEW: editöre yaz — yalnızca findEditorTarget() hedefine; yazılan hedef türünü döndürür (bulunamazsa null)
    function injectIntoEditors(bodyHtml, plainText) { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        const target = findEditorTarget();
        if (!target) return null;
        try {
            if (target.kind === "ckeditor-api") {
                target.inst.setData(bodyHtml);
            } else if (target.kind === "iframe-body" || target.kind === "contenteditable") {
                target.el.innerHTML = bodyHtml;
                ["input", "change", "keyup"].forEach(n => { try { target.el.dispatchEvent(new Event(n, { bubbles: true })); } catch(e) {} });
            } else {
                setNativeValue(target.el, plainText);
            }
            return target.kind;
        } catch(err) {
            console.error("[Evrak Asistanı] Editöre yazma hatası:", err);
            return null;
        }
    }

    // FIX (v3): gerçek EBYS'de "Editör" bir sekme değil, Cevap Yaz penceresinin sol menüsündeki düğmedir
    function findEditorTabEl() {
        for (let doc of getAllDocs()) {
            for (let b of doc.querySelectorAll('[id$="cevapEvrakTabMenuLeft"] button, [id*="TabMenuLeft"] button')) {
                if (isPanelEl(b) || !isVisible(b)) continue;
                const lab = (b.getAttribute("aria-label") || (b.querySelector(".ui-button-text") || b).textContent || "").trim();
                if (lab === "Editör") return b;
            }
        }
        for (let doc of getAllDocs()) {
            for (let li of doc.querySelectorAll(".ui-tabs-nav li, .ui-tabs-header, [role='tab']")) {
                if (isPanelEl(li) || !isVisible(li)) continue;
                if ((li.innerText || li.textContent || "").trim().includes("Editör")) return li;
            }
        }
        return null;
    }
    function clickEditorTab() {
        const li = findEditorTabEl();
        if (!li) return false;
        (li.querySelector("a") || li).click();
        return true;
    }

    // NEW: görünür "Cevap Yaz" / "Cevapla" düğmesi (tüm aynı-origin belgelerde)
    function clickReplyButton() { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        const real = isRealEbys() ? findToolbarButton("Cevap Yaz") : null; // NEW (v3): önizleme araç çubuğundaki gerçek düğme
        if (real) { real.click(); return true; }
        for (let doc of getAllDocs()) {
            for (let el of doc.querySelectorAll("button, a, span, .ui-button-text")) {
                if (isPanelEl(el)) continue;
                const txt = (el.innerText || el.getAttribute("title") || "").trim().toLocaleLowerCase("tr-TR");
                if (txt === "cevap yaz" || txt === "cevapla") {
                    const target = el.closest("button, a") || el;
                    if (!isVisible(target)) continue;
                    target.click();
                    return true;
                }
            }
        }
        return false;
    }

    // NEW: koşul sağlanana kadar bekle (sonucu döndürür; zaman aşımında null)
    // v3.6.24: zaman günlüğü — her bekleme (ad/satır, başlangıç, süre, nasıl bitti); rapor + konsol
    const STEPLOG = []; let STEP_T0 = Date.now();
    function stepWhere(depth) { try { const l = (new Error().stack || "").split("\n")[depth || 3] || ""; const m = l.match(/at\s+(?:async\s+)?([\w$.]+)?\s*\(?.*?:(\d+):\d+\)?$/); return m ? (m[1] || "?") + ":" + m[2] : l.trim().slice(0, 60); } catch(e) { return "?"; } }
    function stepLog(name, t0, how) {
        const ms = Date.now() - t0;
        if (ms < 250 && how === "ok") return;
        const e = { at: ((t0 - STEP_T0) / 1000).toFixed(2), name, ms, how };
        STEPLOG.push(e); if (STEPLOG.length > 300) STEPLOG.shift();
        try { console.debug("[Evrak Asistanı ⏱]", e.at + "s", name, ms + "ms", how); } catch(x) {}
    }
    // v3.6.55: dağıtım zip'i karartıldığı için yığın adları _0x… olur; okunur etiket = son adım adı + sıra no (ya da açık etiket)
    let CUR_STEP = "başlangıç", CUR_N = 0;
    function stepLabel(where) { return (!where || /_0x|^\?|^[a-z]\b|:1$/.test(where)) ? CUR_STEP + " #" + (++CUR_N) : where; }
    function stepMark(name) { CUR_STEP = String(name).slice(0, 40); CUR_N = 0; STEPLOG.push({ at: ((Date.now() - STEP_T0) / 1000).toFixed(2), name: "▶ " + name, ms: 0, how: "" }); try { console.debug("[Evrak Asistanı ⏱] ▶", name); } catch(e) {} }
    function stepReport() { return "Zaman günlüğü (≥250 ms bekleyişler; t=akış başından sn):\n" + STEPLOG.map(e => (e.how === "" ? "" : "  ") + "t=" + e.at + " " + e.name + (e.how === "" ? "" : " — " + e.ms + " ms, " + e.how)).join("\n"); }
    async function waitFor(fn, timeoutMs, stepMs = 150, label) {
        const t0 = Date.now(), where = label || stepLabel(stepWhere(3));
        for (;;) {
            if (AUTO.stop) { stepLog("waitFor " + where, t0, "durduruldu"); throw stopErr(); }
            if (capExpired()) { stepLog("waitFor " + where, t0, "sınır doldu"); return null; } // v3.6.14: Gereği 15 sn sınırı (v3.6.15: EBYS örtüsü süresince uzar, en çok 60 sn)
            let v = null;
            try { v = fn(); } catch(e) {}
            if (v) { stepLog("waitFor " + where, t0, "ok"); return v; }
            if (Date.now() - t0 >= timeoutMs) { stepLog("waitFor " + where + " (" + timeoutMs + ")", t0, "ZAMAN AŞIMI"); return null; }
            await new Promise(r => setTimeout(r, stepMs));
        }
    }

    // NEW: panoya kopyala — navigator.clipboard; olmazsa execCommand('copy') yedeği
    async function copyToClipboard(text) {
        try {
            if (navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
                const ok = await Promise.race([
                    navigator.clipboard.writeText(text).then(() => true, () => false),
                    new Promise(r => setTimeout(() => r(false), 1500))
                ]);
                if (ok) return true;
            }
        } catch(e) {}
        try {
            const ta = document.createElement("textarea");
            ta.value = text;
            ta.setAttribute("readonly", "");
            ta.id = "ebys-clipboard-temp";
            ta.style.cssText = "position:fixed; top:-1000px; left:-1000px; opacity:0;";
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            let ok = false;
            try { ok = document.execCommand("copy"); } catch(e) {}
            ta.remove();
            return !!ok;
        } catch(e) { return false; }
    }

    const EDITOR_KIND_LABELS = { "ebys-cke": "Evrak Editör", "ckeditor-api": "CKEditor", "iframe-body": "CKEditor gövdesi", "contenteditable": "düzenlenebilir alan", "textarea": "metin alanı" };

    // NEW (v3): cevap akışı — gerçek EBYS: Cevap Yaz → (Bilgileri) → Editör düğmesi → yeni CKEditor hazır olana kadar bekle → yalnızca "Evrak Editör" gövdesine yaz.
    // Konu alanları hiçbir zaman hedef alınmaz; metin ayrıca panoya kopyalanır.
    // v3.6.32: oturum başına bir kez ısınma (sessionStorage: sekme kapanınca sıfırlanır; kalıcı depoya yazılmaz)
    let warmupMem = false;
    function warmupDone() { try { return warmupMem || sessionStorage.getItem("ebys_warmup_v1") === "1"; } catch(e) { return warmupMem; } }
    function markWarmup() { warmupMem = true; try { sessionStorage.setItem("ebys_warmup_v1", "1"); } catch(e) {} }
    function closeCevapWindow() {
        for (const d of getAllDocs()) {
            const dlg = d.getElementById("windowCevapEvrakDialog") || Array.from(d.querySelectorAll(".ui-dialog")).find(x => isVisible(x) && /cevap/i.test(x.id || ""));
            const x = dlg && dlg.querySelector(".ui-dialog-titlebar-close");
            if (x) { try { userClick(x); } catch(e) { try { x.click(); } catch(e2) {} } return true; }
        }
        return false;
    }
    // v3.6.35: İLK CEVAP YARDIMCISI — tarayıcı oturumundaki ilk Cevap Yaz başarısız olursa alarm yerine sakin bir panel: kullanıcı Cevap Yaz'ı
    // bir kez elle açıp kapatır; eklenti bunu algılar (açıldı → kapandı) ve akışı OTOMATİK yeniden dener. Tanı raporu panelde isteğe bağlı.
    // Gönder/İmzala/Parafla'ya asla dokunulmaz; durum yalnızca sessionStorage'da (sekme kapanınca sıfırlanır).
    const FR_KEY = "ebys_firstcevap_v1"; let frMem = false, frCapture = null, frWatch = null;
    function firstCevapPending() { if (frMem) return false; try { return sessionStorage.getItem(FR_KEY) !== "1"; } catch(e) { return true; } }
    function markFirstCevap() { frMem = true; try { sessionStorage.setItem(FR_KEY, "1"); } catch(e) {} }
    // v3.6.53: EBYS boşta mı — 'Lütfen Bekleyiniz' en az holdMs kesintisiz kapalı (en çok maxMs beklenir)
    // v3.6.53: pencere kapatılırken çıkan "Kaydetmek ister misiniz? Evet/Hayır/İptal" (saveOnCloseWindowConfirm) görünür mü — YANITLANMAZ
    function saveConfirmVisible() {
        for (const d of getAllDocs()) {
            try {
                for (const el of d.querySelectorAll('[id*="saveOnCloseWindowConfirm"], .ui-confirm-dialog')) {
                    if (!isVisible(el)) continue;
                    if (/saveOnCloseWindowConfirm/.test(el.id || "") || /kaydet/i.test(el.textContent || "")) return true;
                }
            } catch(e) {}
        }
        return false;
    }
    async function ebysIdleFor(holdMs, maxMs) {
        const t0 = Date.now(); let since = 0;
        while (Date.now() - t0 < maxMs) {
            autoCheck();
            if (bekleyinizStrict()) since = 0; else { if (!since) since = Date.now(); if (Date.now() - since >= holdMs) return true; }
            await new Promise(r => setTimeout(r, 150));
        }
        return false;
    }
    // v3.6.53: TAKILMA BEKÇİSİ — Cevap Yaz akışı asla sonsuz beklemez: 'Lütfen Bekleyiniz' örtüsü HANG_OVERLAY_MS kesintisiz kalırsa ya da
    // akış toplam süreyi aşarsa ⏹ Durdur ile aynı temiz durdurma yapılır (hiçbir düğmeye basılmaz), kullanıcıya F5 / elle devam söylenir.
    const HANG_OVERLAY_MS = 25000, FIRST_TOTAL_MS = 120000;
    let lastHang = "";
    function startHangGuard(totalMs, ovMs) {
        const t0 = Date.now(); let ovSince = 0;
        const g = { why: "" };
        g.id = setInterval(() => {
            if (bekleyinizStrict()) { if (!ovSince) ovSince = Date.now(); } else ovSince = 0;
            if (ovSince && Date.now() - ovSince > (ovMs || HANG_OVERLAY_MS)) g.why = "örtü";
            else if (totalMs && Date.now() - t0 > totalMs) g.why = "süre";
            if (g.why) { lastHang = g.why; clearInterval(g.id); stepMark("Takılma bekçisi: durduruldu (" + g.why + ")"); if (AUTO.depth > 0) AUTO.stop = true; }
        }, 500);
        g.end = () => clearInterval(g.id);
        return g;
    }
    function hangToast() {
        if (lastHang === "örtü") showToast("⏹ EBYS 'Lütfen Bekleyiniz' ekranında çok uzun kaldı; eklenti durdu, hiçbir şeye basmadı. Sayfayı F5 ile yenileyip Cevap Yaz'ı yeniden deneyin. Metin panoda.", "warn");
        else if (lastHang === "süre") showToast("⏹ Cevap Yaz otomatiği süre sınırını aştı ve durdu (hiçbir şeye basılmadı). Gereği/editörü elle tamamlayabilirsiniz; metin panoda.", "warn");
    }
    async function runReplyFlow(...a) { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        const first = isRealEbys() && firstCevapPending();
        lastHang = "";
        if (!first) { const g0 = startHangGuard(0, 90000); /* sonraki Cevap Yaz'larda yalnızca çok uzun (90 sn) örtü */ try { return await autoWrap("Cevap Yaz", () => runReplyFlow_(...a)); } finally { g0.end(); if (lastHang) hangToast(); } }
        markFirstCevap(); frCapture = []; let res = null, diags;
        const g1 = startHangGuard(FIRST_TOTAL_MS);
        try { res = await autoWrap("Cevap Yaz", () => runReplyFlow_(...a)); }
        finally { g1.end(); diags = frCapture || []; frCapture = null; }
        if (res && res.aborted) return res; // v3.6.55: temiz durma — yeniden deneme / yardım paneli yok
        if (lastHang) { hangToast(); stepMark("İlk Cevap Yardımcısı açıldı (takılma)"); startFirstRunAssist(a, diags); return Object.assign({}, res || {}, { firstRunDeferred: true, hang: lastHang }); }
        let failed = !res || !res.kind || diags.length > 0 || lastGerekFailed;
        // v3.6.52: Gereği seçilemediyse ya da editör açılamadıysa kullanıcıdan elle aç-kapa istemeden ÖNCE eklenti bunu bir kez kendisi yapar
        // (✕ ile kapat → kapandığı doğrulanır → Cevap Yaz yeniden → akış yeniden). Pencere kapanmazsa hiçbir şeye basılmaz, yardımcı panel açılır.
        if (failed && !(res && (res.stopped || res.aborted)) && (!res || !res.kind || lastGerekFailed) && !AUTO.stop) {
            try {
                stepMark("İlk Cevap: otomatik kapat-aç yeniden deneme");
                let closed = null;
                if (!isCevapWindowOpen()) closed = true;
                else if (await ebysIdleFor(1500, 8000)) {
                    closeCevapWindow();
                    closed = await waitFor(() => (!isCevapWindowOpen() && !bekleyinizStrict()) || (saveConfirmVisible() ? "ONAY" : null), 8000, 200);
                    if (closed === "ONAY") { // EBYS "kaydedilsin mi?" soruyor — eklenti ASLA yanıtlamaz; kullanıcı Hayır deyince kendisi devam eder
                        stepMark("Kapatma onayı soruldu — kullanıcı bekleniyor");
                        showToast("ℹ️ EBYS 'kaydedilsin mi?' diye soruyor. Lütfen 'Hayır'a basın; pencere kapanınca eklenti Cevap Yaz'ı kendisi yeniden açıp devam edecek.", "info");
                        closed = await waitFor(() => !isCevapWindowOpen() && !saveConfirmVisible() && !bekleyinizStrict(), 120000, 300);
                    }
                }
                else stepMark("Yeniden deneme atlandı: EBYS meşgul (örtü)");
                if (closed) {
                    await sleep(1200);
                    frCapture = [];
                    const g2 = startHangGuard(FIRST_TOTAL_MS);
                    try { res = await autoWrap("Cevap Yaz", () => runReplyFlow_(...a)); }
                    finally { g2.end(); diags = frCapture || []; frCapture = null; }
                    if (lastHang) hangToast();
                    failed = !res || !res.kind || diags.length > 0 || lastGerekFailed;
                }
            } catch(e) { if (e && e.ebysStop) throw e; console.warn("[Evrak Asistanı] ilk cevap otomatik yeniden deneme:", e); }
        }
        if (failed) { stepMark("İlk Cevap Yardımcısı açıldı"); startFirstRunAssist(a, diags); return Object.assign({}, res || {}, { firstRunDeferred: true }); }
        return res;
    }
    function stopFirstRunAssist() { if (frWatch) { clearInterval(frWatch); frWatch = null; } document.querySelectorAll("#ebys-firstrun-panel").forEach(x => x.remove()); }
    function startFirstRunAssist(args, diags) {
        stopFirstRunAssist(); ensureSkin35();
        const p = document.createElement("div");
        p.id = "ebys-firstrun-panel"; p.setAttribute("role", "status");
        p.innerHTML = '<div class="fr-h">👋 İlk kullanım: EBYS\'yi hazırlayalım</div>'
            + '<div class="fr-t">İlk seferde EBYS\'yi hazırlamak için bu evrakı bir kez elle cevaplayın / <b>Cevap Yaz</b>\'ı açıp kapatın; sonra otomatik devam edecek.</div>'
            + '<div class="fr-s"></div>'
            + '<div class="fr-b"><button class="fr-retry ebys-btn-primary">🔄 Şimdi yeniden dene</button>' + (diags.length ? '<button class="fr-diag">🔧 Tanı raporu</button>' : '') + '<button class="fr-close">Kapat</button></div>'
            + '<div class="fr-n">Bu bir hata değildir; EBYS ilk açılışta pencerelerini geç yüklüyor. Hiçbir şey gönderilmez/imzalanmaz. Elle gönderdiyseniz paneli kapatın.</div>';
        document.body.appendChild(p);
        const status = (t) => { const e = p.querySelector(".fr-s"); if (e) e.textContent = t; };
        let state = isCevapWindowOpen() ? "close0" : "open", busy = false; const t0 = Date.now();
        status(state === "close0" ? "① Açık cevap penceresini kapatın (✕)…" : "① Cevap Yaz'ı açın…");
        const resume = async (why) => {
            if (busy) return; busy = true; if (frWatch) { clearInterval(frWatch); frWatch = null; }
            status("✅ " + why + " — otomatik devam ediliyor…"); stepMark("İlk Cevap Yardımcısı: devam (" + why + ")");
            await sleep(1500); await waitFor(() => !bekleyinizStrict() && !isCevapWindowOpen(), 8000, 150);
            p.remove();
            try { const r = await runReplyFlow(...args); reportReplyResult(r, []); } catch(e) { if (!(e && e.ebysStop)) console.warn("[Evrak Asistanı] ilk cevap yeniden deneme:", e); }
        };
        frWatch = setInterval(() => {
            if (!p.isConnected || Date.now() - t0 > 15 * 60000) { stopFirstRunAssist(); return; }
            if (AUTO.depth > 0 || busy) return;
            const o = isCevapWindowOpen();
            if (state === "close0" && !o) { state = "open"; status("① Cevap Yaz'ı açın…"); }
            else if (state === "open" && o) { state = "close"; status("② Pencere açıldı ✔ — şimdi kapatın (✕)…"); }
            else if (state === "close" && !o) resume("EBYS hazır");
        }, 400);
        p.querySelector(".fr-retry").onclick = () => resume("Yeniden deneniyor");
        p.querySelector(".fr-close").onclick = stopFirstRunAssist;
        const dgb = p.querySelector(".fr-diag"); if (dgb) dgb.onclick = () => showDiagBox(diags.join("\n\n=====\n\n"));
    }
    async function runReplyFlow_(html, plain, opts) { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        STEPLOG.length = 0; STEP_T0 = Date.now(); stepMark("Cevap akışı başladı");
        try { return await runReplyFlow__(html, plain, opts); }
        finally { stepMark("Cevap akışı bitti"); try { console.debug("[Evrak Asistanı ⏱]\n" + stepReport()); } catch(e) {} }
    }
    // v3.6.47: Gereği = evrakın geldiği yer. fromUs: Cevap Yaz'ı uzantı açtı. Elle açılmış pencerede yalnızca Gereği boşsa çağrılır.
    const GEREK_READY_MS = 20000;
    async function runGerekStep(opts, fromUs) {
        if (fromUs && opts && opts.gonderen && gerekAutoOn() && !gerekOnlyOn()) showToast("ℹ️ 'Gereği otomatik' kapalı: Gereği'ni elle seçin.", "info");
        if (opts && opts.gonderen && gerekAutoOn() && gerekOnlyOn()) {
            try {
                showToast("⏳ Adım 2/3: Gereği = evrakın geldiği yer (" + opts.gonderen + ") seçiliyor…", "info"); stepMark("Gereği başladı");
                let g = null;
                if (gerekFailStreak >= 3) g = { ok: false, why: "art arda 3 evrakta seçilemediği için Gereği otomatiği bu oturumda kapalı (sayfayı yenileyince açılır)", nodiag: true };
                else {
                    for (let tr = 0, trMax = frCapture ? 1 : 3; tr < trMax; tr++) { // v3.6.17: Klasör ile aynı 3 deneme; v3.6.53: oturumun ilk Cevap Yaz'ında 1 (yeniden deneme yeni pencerede)
                        // v3.6.24: adım arası — gerçek örtü ~300 ms kapalı → devam (en çok 6 sn). Geniş isAjaxBusy() ile 20 sn bekleme kaldırıldı
                        // (başka çerçevedeki kalıcı .ui-blockui vb. öğe yanlış "meşgul" gösterip 20 sn bekletebiliyordu); nedeni günlüğe yazılır.
                        await stepSettle(6000, "Klasör→Gereği");
                        if (isAjaxBusy()) stepMark("bilgi: isAjaxBusy=true (" + ajaxBusyWhy() + ") — beklenmedi");
                        g = await fillGerekFromSender(opts.gonderen);
                        if (g.ok) break;
                        if (g.hang) break; // v3.6.56: seçimden sonra örtü 25 sn → YENİDEN DENEME YOK
                        if (g.hidden) break; // v3.6.53: gizli liste → aynı pencerede yeniden deneme yok (EBYS'yi kilitlemesin)
                        dbg("Gereği denemesi", tr + 1, "başarısız:", g.why); await sleep(300); await stepSettle(3000, "Gereği yeniden");
                    }

                    gerekFailStreak = g.ok ? 0 : gerekFailStreak + 1; stepMark("Gereği bitti (" + (g.ok ? "ok" : "hata") + ")");
                }
                if (g.hang) { gerekHang = true; stepMark("Gereği: takılma — akış durduruldu"); return; } // v3.6.56: uyarıyı runReplyFlow__ verir
                if (g.ok && g.warn) showToast("⚠️ Gereği seçildi ancak: " + g.warn + ". Sağ alttaki tanı raporunu bana iletin.", "warn");
                else if (g.ok && !g.skipped) showToast("✅ Gereği: " + opts.gonderen + " seçildi.", "ok");
                else if (!g.ok) { showToast("⛔ Gereği 3 denemede seçilemedi, bu adım durduruldu: " + g.why + ". Bilgileri sekmesinden seçebilirsiniz.", "warn"); if (g.nodiag) {} else showDiagBox(cevapDiagReport("Gereği: " + g.why)); }
            } catch(e) { console.warn("[Evrak Asistanı] Gereği doldurulamadı:", e); }
        }
    }
    // v3.6.55: Cevap Yaz akışını TEMİZ durdur — hiçbir EBYS düğmesine basılmaz, kullanıcıya neden ve ne yapacağı söylenir
    function abortReply(copied, replyClicked, msg) {
        stepMark("Durduruldu: " + msg.slice(0, 60));
        showToast("⏹ " + msg, "warn");
        return { kind: null, copied: copied, replyClicked: replyClicked, aborted: true, msg: msg };
    }
    async function runReplyFlow__(html, plain, opts) { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        const copied = await copyToClipboard(plain);
        if (isRealEbys()) {
            let replyClicked = false;
            gerekHang = false;
            // v3.6.55: EBYS zaten 'Lütfen Bekleyiniz'de takılıysa HİÇBİR adım başlatılmaz
            if (bekleyinizStrict() && !(await ebysIdleFor(800, 10000))) return abortReply(copied, false, "EBYS 'Lütfen Bekleyiniz' ekranında bekliyor (önceki istek bitmedi). Eklenti hiçbir şey yapmadı. Sayfayı F5 ile yenileyip Cevap Yaz'ı yeniden deneyin.");
            const before = findRealEbysEditor();
            if (!before && !isCevapWindowOpen()) {
                replyClicked = clickReplyButton();
                if (replyClicked) {
                    let ready = await waitFor(() => isCevapWindowOpen() && findEditorTabEl(), warmupDone() ? 15000 : GEREK_READY_MS, 100, "Cevap Yaz penceresi açılıyor"); // v3.6.47: oturumun ilk açılışında 20 sn
                    // v3.6.32: İLK ÇALIŞTIRMA ISINMASI — tarayıcı açıldıktan sonraki ilk Cevap Yaz'da EBYS'nin tembel yüklenen PrimeFaces pencereleri
                    // hazır olmayabiliyor (kullanıcı elle bir kez açıp kapatınca düzeliyordu). Oturumda bir kez: pencereyi kapat → bekle → yeniden aç.
                    // Gönder/İmzala/Parafla'ya ASLA dokunulmaz; yalnızca Cevap Yaz ve pencerenin ✕ kapatma düğmesi kullanılır.
                    // v3.6.53: pencere hazırsa ısınma (kapat-aç) YAPILMAZ — 3.6.52'de hazır pencereyi kapatmak EBYS'yi bekletiyordu
                    if (!ready && !warmupDone() && !bekleyinizStrict()) { // v3.6.55: örtü varken kapat-aç yapılmaz
                        markWarmup();
                        showToast("⏳ İlk çalıştırma: EBYS cevap penceresi henüz hazır değil. Pencere bir kez kapatılıp yeniden açılıyor (gönderme/imza yapılmaz)…", "info"); stepMark("Isınma: kapat-aç");
                        closeCevapWindow();
                        await waitFor(() => !isCevapWindowOpen() && !bekleyinizStrict(), 6000, 150);
                        await sleep(1500);
                        await ebysIdleFor(800, 15000); // v3.6.53: yeniden açmadan önce örtü kalksın
                        replyClicked = clickReplyButton();
                        ready = replyClicked && await waitFor(() => isCevapWindowOpen() && findEditorTabEl(), 20000, 100, "Cevap Yaz penceresi (ısınma sonrası)");
                        if (ready) showToast("✅ Cevap penceresi hazır (ısınma tamam).", "ok");
                    }
                    // v3.6.55: pencere hazır olmadıysa Klasör/Gereği/Editör'e GEÇİLMEZ — temiz durulur
                    if (!ready) return abortReply(copied, replyClicked, (bekleyinizStrict() ? "EBYS 'Lütfen Bekleyiniz' ekranında kaldı" : "Cevap Yaz penceresi 20 sn içinde hazır olmadı") + "; eklenti durdu, başka adım yapmadı. Gerekirse sayfayı F5 ile yenileyip yeniden deneyin. Metin panoda.");
                }
                // NEW (v3.6.5): Kaldırılacak Klasörler = konu kodunun klasörü (yalnızca Cevap Yaz'ı biz açtıysak, alan boşsa)
                if (replyClicked && gerekAutoOn()) {
                    try {
                        showToast("⏳ Adım 1/3: Kaldırılacak Klasörler (konu koduyla aynı) seçiliyor…", "info"); stepMark("Klasör başladı");
                        let k = null;
                        for (let tr = 0; tr < 3; tr++) {
                            if (tr === 0) await stepSettle(6000, "Cevap Yaz→Klasör"); else await waitFor(() => !isAjaxBusy(), 20000, 100); // v3.6.24
                            k = await fillKlasorFromKonuKodu(opts && opts.docNo);
                            if (k.ok) break;
                            dbg("Klasör denemesi", tr + 1, "başarısız:", k.why); await sleep(300); await stepSettle(3000, "Klasör yeniden");
                        }
                        stepMark("Klasör bitti (" + (k && k.ok ? "ok" : "hata") + ")");
                        if (k.ok && !k.skipped) showToast("✅ Kaldırılacak klasör: " + k.code + " (konu koduyla aynı) seçildi.", "ok");
                        else if (!k.ok) { showToast("⛔ Kaldırılacak klasör 3 denemede seçilemedi, bu adım durduruldu: " + k.why + ".", "warn"); if (k.diag !== false) showDiagBox(cevapDiagReport("Klasör: " + k.why)); }
                    } catch(e) { console.warn("[Evrak Asistanı] Kaldırılacak klasör doldurulamadı:", e); }
                }
                // v3.6.47: Gereği adımı ayrı işleve alındı; Cevap Yaz elle açıldıysa da (Gereği boşsa) çalışır
                if (replyClicked) await runGerekStep(opts, true);
            if (gerekHang) return abortReply(copied, replyClicked, "Gereği seçildikten sonra EBYS 25 sn'den uzun 'Lütfen Bekleyiniz'de kaldı. Eklenti durdu, başka hiçbir şeye dokunmadı. Lütfen Gereği'ni elle seçin (örtü kapanmazsa sayfayı F5 ile yenileyin). Metin panoda."); // v3.6.56
            } else if (isCevapWindowOpen() && opts && opts.gonderen && gerekAutoOn() && gerekOnlyOn()) {
                // v3.6.47: Cevap Yaz zaten açık (elle açılmış ya da önceki adım) → pencere hazır olana dek (en çok 20 sn) bekle; Gereği BOŞSA doldur
                const rdy = await waitFor(() => isCevapWindowOpen() && cevapScopeEl() && !bekleyinizStrict(), GEREK_READY_MS, 150, "Açık Cevap Yaz penceresi hazır mı");
                if (!rdy) return abortReply(copied, false, "Açık Cevap Yaz penceresi 20 sn içinde hazır olmadı" + (bekleyinizStrict() ? " ('Lütfen Bekleyiniz' sürüyor)" : "") + "; eklenti durdu, başka adım yapmadı. Gerekirse F5 ile yenileyin. Metin panoda."); // v3.6.55
                if (rdy && !lovSelectedTitle(cevapScopeEl() || document, "geregiLov")) await runGerekStep(opts, false);
            }
            if (gerekHang) return abortReply(copied, replyClicked, "Gereği seçildikten sonra EBYS 25 sn'den uzun 'Lütfen Bekleyiniz'de kaldı. Eklenti durdu, başka hiçbir şeye dokunmadı. Lütfen Gereği'ni elle seçin (örtü kapanmazsa sayfayı F5 ile yenileyin). Metin panoda."); // v3.6.56
            let target = findRealEbysEditor();
            if (!target) {
                const tab = findEditorTabEl();
                if (tab) {
                    dbg("Cevap Yaz → Editör düğmesine basılıyor"); stepMark("Editör sekmesi");
                    (tab.querySelector && tab.tagName !== "BUTTON" ? (tab.querySelector("a") || tab) : tab).click();
                }
                target = await waitFor(() => { const t = findRealEbysEditor(); return t && t.el && !bekleyinizStrict() ? t : null; }, 15000, 100, "Editör yükleniyor"); // v3.6.24: geniş isAjaxBusy yerine gerçek örtü
                if (!target) { // v3.6.32: editör ilk açılışta gelmediyse bir kez Editör sekmesine yeniden bas
                    const tab2 = findEditorTabEl();
                    if (tab2) { showToast("⏳ Editör ilk açılışta yüklenmedi; Editör sekmesi yeniden açılıyor…", "info"); stepMark("Isınma: Editör yeniden"); await sleep(1200); (tab2.querySelector && tab2.tagName !== "BUTTON" ? (tab2.querySelector("a") || tab2) : tab2).click();
                        target = await waitFor(() => { const t = findRealEbysEditor(); return t && t.el && !bekleyinizStrict() ? t : null; }, 20000, 100, "Editör yükleniyor (2. deneme)"); }
                }
                if (target) await sleep(200); // v3.6.23: 400→200 — CKEditor örneği hazırlanırken kısa bekleme
            }
            stepMark("Editöre yazılıyor");
            const kind = findEditorTarget() ? await injectIntoEditorsSmart(html, plain) : null;
            dbg("Editöre yazma sonucu:", kind || "editör bulunamadı");
            return { kind: kind, copied: copied, replyClicked: replyClicked };
        }
        const replyClicked = clickReplyButton();
        if (replyClicked) await sleep(REPLY_FORM_DELAY_MS);
        const appeared = await waitFor(() => findEditorTabEl() || findEditorTarget(), 6000);
        if (clickEditorTab()) await sleep(300);
        const target = await waitFor(() => findEditorTarget(), appeared ? 6000 : 1000);
        const kind = target ? await injectIntoEditorsSmart(html, plain) : null;
        return { kind: kind, copied: copied, replyClicked: replyClicked };
    }

    // =========================================================================
    // 7. MESSAGE HANDLER
    // =========================================================================
    window.addEventListener("message", async function(event) {
        // FIX: origin/kaynak kontrolü + mesaj kimliğiyle tekrar işlemeyi engelleme
        if (!isTrustedMessage(event)) return;
        const t = event.data.type;
        if (event.data.msgId) {
            if (handledMsgIds.has(event.data.msgId)) return;
            handledMsgIds.add(event.data.msgId);
        }
        // FIX: açma/kapatma yalnızca üst pencerede yürütülür (getAllDocs tüm aynı-origin çerçeveleri kapsar);
        // betik her çerçevede çalışsa bile aynı satıra / düğmeye iki kez tıklanmaz
        const isTopFrame = window.self === window.top;
        if (t === "EBYS_OPEN_SPECIFIC_ROW" && isTopFrame) await findAndOpenDocument(String(event.data.docNo).trim());
        if (t === "EBYS_CLOSE_DOCUMENT" && isTopFrame) await handleCloseDocument(null);
        // FIX: cevap düğmesi / editör sekmesi / editöre yazma da yalnızca üst pencerede (tüm aynı-origin çerçeveler taranır; çift işlem olmaz)
        if (t === "EBYS_TRIGGER_REPLY_BUTTON" && isTopFrame) clickReplyButton();
        if (t === "EBYS_CLICK_EDITOR_TAB" && isTopFrame) clickEditorTab();
        if (t === "EBYS_INJECT_EDITOR_TEXT" && isTopFrame) {
            for (let attempt = 0; attempt < 4; attempt++) {
                if (await injectIntoEditorsSmart(event.data.html, event.data.plain)) return;
                await new Promise(r => setTimeout(r, 600));
            }
        }
    });

    attachListenersToAllFrames();

    if (window.self !== window.top) return;
    if (document.getElementById("ebys-inbox-panel")) return;

    let scannedList = [];
    let isScanningPages = false;

    // =========================================================================
    // NEW (v3): GÜNLÜ EVRAK — SON TARİH VE GERİ SAYIM (Europe/Istanbul)
    // =========================================================================
    const TR_MONTH_NAMES = ["ocak", "şubat", "mart", "nisan", "mayıs", "haziran", "temmuz", "ağustos", "eylül", "ekim", "kasım", "aralık"];
    // NEW (v3.5.1): ay adları büyük/küçük harf ve Türkçe karaktersiz yazımla da tanınır (KASIM, Kasim, AĞUSTOS, Agustos)
    const TR_MONTH_KEYS = ["ocak", "subat", "mart", "nisan", "mayis", "haziran", "temmuz", "agustos", "eylul", "ekim", "kasim", "aralik"];
    function trFold(s) { return String(s || "").toLocaleLowerCase("tr-TR").replace(/ı/g, "i").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ş/g, "s").replace(/ö/g, "o").replace(/ç/g, "c").replace(/[âà]/g, "a").replace(/[îì]/g, "i").replace(/[ûù]/g, "u").replace(/\u0307/g, ""); }
    const TR_NUM_WORDS = { "bir": 1, "iki": 2, "üç": 3, "dört": 4, "beş": 5, "altı": 6, "yedi": 7, "sekiz": 8, "dokuz": 9, "on": 10, "on beş": 15, "yirmi": 20, "otuz": 30 };
    // sabit tarihli resmî tatiller (dinî bayramlar her yıl değiştiği için dahil değildir)
    const FIXED_HOLIDAYS = ["01-01", "04-23", "05-01", "05-19", "07-15", "08-30", "10-29"];
    const pad2 = (n) => String(n).padStart(2, "0");
    function utcDate(y, m, d) { const dt = new Date(Date.UTC(y, m - 1, d)); return (dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d) ? dt : null; }
    function parseTrDate(s) {
        s = String(s || "").trim();
        let m = s.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})$/);
        if (m) return utcDate(+m[3], +m[2], +m[1]);
        m = s.match(/^(\d{1,2})\s+(\S+)\s+(\d{4})$/);
        if (m) { const mi = TR_MONTH_NAMES.indexOf(m[2].toLocaleLowerCase("tr-TR")); if (mi >= 0) return utcDate(+m[3], mi + 1, +m[1]); }
        m = s.match(/^(\d{1,2})\s*([^\d\s./]+)\s*(\d{4})$/); // NEW (v3.5.1): KASIM / Kasim / bitişik yazım
        if (m) { const mi = TR_MONTH_KEYS.indexOf(trFold(m[2])); if (mi >= 0) return utcDate(+m[3], mi + 1, +m[1]); }
        return null;
    }
    function isoOf(dt) { return dt.getUTCFullYear() + "-" + pad2(dt.getUTCMonth() + 1) + "-" + pad2(dt.getUTCDate()); }
    function fromIso(s) { const m = String(s || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? utcDate(+m[1], +m[2], +m[3]) : null; }
    function fmtTrDate(dt) { return pad2(dt.getUTCDate()) + "." + pad2(dt.getUTCMonth() + 1) + "." + dt.getUTCFullYear(); }
    function istanbulTodayIso() {
        try { return new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Istanbul", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date()); }
        catch(e) { const n = new Date(Date.now() + 3 * 3600000); return n.getUTCFullYear() + "-" + pad2(n.getUTCMonth() + 1) + "-" + pad2(n.getUTCDate()); }
    }
    function isBusinessDay(dt) {
        const wd = dt.getUTCDay();
        if (wd === 0 || wd === 6) return false;
        return !FIXED_HOLIDAYS.includes(pad2(dt.getUTCMonth() + 1) + "-" + pad2(dt.getUTCDate()));
    }
    const addDaysUtc = (dt, n) => new Date(dt.getTime() + n * 86400000);
    function addBusinessDays(dt, n) { let d = dt, c = 0; while (c < n) { d = addDaysUtc(d, 1); if (isBusinessDay(d)) c++; } return d; }
    // son tarih: açık tarih ("en geç 15.10.2026", "15.10.2026 tarihine kadar") ya da göreli ("5 gün içinde", "3 iş günü içinde" → evrak tarihinden)
    function computeDeadline(sonTarihText, docDateText) {
        const s = String(sonTarihText || "").trim();
        if (!s) return null;
        const exp = parseTrDate(s);
        if (exp) return { iso: isoOf(exp), display: fmtTrDate(exp), kind: "kesin", basis: "Yazıda belirtilen son tarih" };
        const am = !/g[üu]n/i.test(s) && s.toLocaleLowerCase("tr-TR").match(/^(\d{1,2})\s+ay\b/); // NEW (v3.6.4): "N ay içinde"
        if (am) {
            const b0 = parseTrDate(docDateText); if (!b0) return null;
            const tot = b0.getUTCMonth() + (+am[1]), yy = b0.getUTCFullYear() + Math.floor(tot / 12), mo = (tot % 12) + 1;
            const dl0 = utcDate(yy, mo, Math.min(b0.getUTCDate(), lastDayOfMonth(yy, mo)));
            return dl0 ? { iso: isoOf(dl0), display: fmtTrDate(dl0), kind: "takvim günü", basis: am[1] + " ay, evrak tarihinden (" + fmtTrDate(b0) + ") itibaren" } : null;
        }
        const m = s.toLocaleLowerCase("tr-TR").match(/(\d{1,3}|on beş|bir|iki|üç|dört|beş|altı|yedi|sekiz|dokuz|on|yirmi|otuz)\s+(iş\s+)?günü?/);
        if (!m) return null;
        const n = /^\d+$/.test(m[1]) ? +m[1] : TR_NUM_WORDS[m[1]];
        const base = parseTrDate(docDateText);
        if (!n || !base) return null;
        const business = !!m[2];
        const dl = business ? addBusinessDays(base, n) : addDaysUtc(base, n);
        return { iso: isoOf(dl), display: fmtTrDate(dl), kind: business ? "iş günü" : "takvim günü", basis: n + (business ? " iş günü" : " gün") + ", evrak tarihinden (" + fmtTrDate(base) + ") itibaren" };
    }
    // NEW (v3.5.1): yazıdaki TÜM son tarih ifadeleri; evrak tarihinden önceki tarihler (ör. İlgi'deki "… tarihli") atılır.
    // Seçim: bugünden itibaren en yakın son tarih (hiçbiri gelecekte değilse en geç olanı); diğerleri { others } olarak döner (GG.AA.YYYY).
    function findDeadlineDates(rawText, docDateText) {
        const F = trFold(String(rawText || "").replace(/[\u00A0\t ]+/g, " "));
        const MON = "(?:ocak|subat|mart|nisan|mayis|haziran|temmuz|agustos|eylul|ekim|kasim|aralik)";
        const D = "((?<!\\d)\\d{1,2}\\s*[./]\\s*\\d{1,2}\\s*[./]\\s*\\d{4}(?!\\d)|(?<!\\d)\\d{1,2}\\s*" + MON + "\\s*\\d{4}(?!\\d))";
        const TM = "(?:\\s*,?\\s*(?:saat\\s*)?\\d{1,2}[.:]\\d{2})?";
        const AP = "\\s*['’`]?\\s*";
        const res = [
            new RegExp("en\\s+(?:gec|son)\\s+(?:olarak\\s+)?" + D, "g"),
            new RegExp("son\\s+(?:basvuru|gonderim|gonderme|teslim|bildirim)\\s+tarihi\\s*:?\\s*" + D, "g"),
            new RegExp(D + TM + AP + "(?:(?:tarihine|tarihi|gunune|gunu)(?:\\s+(?:mesai\\s+bitimine|saat\\s*\\d{1,2}[.:]\\d{2}" + AP + "(?:ya|ye|a|e)?))?\\s+(?:kadar|dek)|(?:ya|ye|a|e)\\s+(?:kadar|dek)|(?:tarihinden|gununden)\\s+once)", "g")
        ];
        const docDate = parseTrDate(docDateText);
        const seen = new Map();
        res.forEach(re => { let m; while ((m = re.exec(F))) { const dt = parseDlDate(m[1]); if (dt && !(docDate && dt < docDate)) seen.set(isoOf(dt), dt); } });
        // NEW (v3.6.4): yılsız tarih ("20 Ekim'e kadar"), "Ekim ayı sonuna kadar", "20.10.2026 - 25.10.2026 tarihleri arasında" (bitiş)
        const baseD = docDate || fromIso(istanbulTodayIso());
        let mm;
        const reNoYear = new RegExp("(?<!\\d)(\\d{1,2})\\s*(" + MON + ")(?!\\s*\\d)" + AP + "(?:(?:ya|ye|a|e|ine|una)\\s*)?(?:tarihine\\s+)?(?:kadar|dek)", "g");
        while ((mm = reNoYear.exec(F))) { const mo = TR_MONTH_KEYS.indexOf(mm[2]) + 1; let dt = utcDate(baseD.getUTCFullYear(), mo, +mm[1]); if (dt && dt < baseD) dt = utcDate(baseD.getUTCFullYear() + 1, mo, +mm[1]); if (dt && !(docDate && dt < docDate)) seen.set(isoOf(dt), dt); }
        const reEnd = new RegExp("(?:(" + MON + ")\\s+ay(?:i|in|inin)?\\s+sonuna|(?<!her\\s)(?<![a-z])ay\\s+sonuna|(?<!her\\s)(" + MON + ")\\s+sonuna)\\s+kadar", "g");
        while ((mm = reEnd.exec(F))) { const nm = mm[1] || mm[2]; const mo = nm ? TR_MONTH_KEYS.indexOf(nm) + 1 : baseD.getUTCMonth() + 1; const yy = baseD.getUTCFullYear() + (mo < baseD.getUTCMonth() + 1 ? 1 : 0); const dt = utcDate(yy, mo, lastDayOfMonth(yy, mo)); if (dt) seen.set(isoOf(dt), dt); }
        const reRange = new RegExp(D + "\\s*(?:-|–|ile|ila)\\s*" + D + "\\s+tarihleri\\s+arasinda", "g");
        while ((mm = reRange.exec(F))) { const dt = parseDlDate(mm[2]); if (dt && !(docDate && dt < docDate)) seen.set(isoOf(dt), dt); }
        // v3.6.60: "ayın 10'una kadar" / "bu ayın 10'una kadar" / "ayın 15'i mesai bitimine kadar" — "her" yoksa tekil son tarih (yazı ayı; gün geçtiyse sonraki ay). "dönemi takip eden ayın …" hariç.
        const reAyin = new RegExp("(?<!her\\s)(?<!takip\\s+eden\\s)(?:bu\\s+)?ayin\\s+((?:\\d{1,2}\\s*['’`]?\\s*(?:i|u|si|su|ine|una|une|unu|sine|suna|sune|inde|unda|sinde|sunda)?\\s*(?:,|ve|ile|-|ila|veya|\\/)?\\s*){1,6})(?:\\s+(?:tarihine|gunune))?(?:\\s+mesai\\s+bitimine)?\\s+(?:kadar|dek)", "g");
        while ((mm = reAyin.exec(F))) {
            const near = F.slice(Math.max(0, mm.index - 28), mm.index);
            if (/her\s+$/.test(near) || /takip\s+eden\s+$/.test(near)) continue;
            const nums = (mm[1].match(/\d{1,2}/g) || []).map(Number).filter(n => n >= 1 && n <= 31);
            nums.forEach(n => {
                let y = baseD.getUTCFullYear(), mo = baseD.getUTCMonth() + 1;
                let dt = utcDate(y, mo, Math.min(n, lastDayOfMonth(y, mo)));
                if (dt && dt < baseD) { mo++; if (mo > 12) { mo = 1; y++; } dt = utcDate(y, mo, Math.min(n, lastDayOfMonth(y, mo))); }
                if (dt && !(docDate && dt < docDate)) seen.set(isoOf(dt), dt);
            });
        }
        const all = Array.from(seen.keys()).sort();
        if (!all.length) return { chosen: "", chosenIso: "", others: [] };
        const today = istanbulTodayIso();
        const fut = all.filter(x => x >= today);
        const pickIso = fut.length ? fut[0] : all[all.length - 1];
        return { chosen: fmtTrDate(seen.get(pickIso)), chosenIso: pickIso, others: all.filter(x => x !== pickIso).slice(0, 3).map(x => fmtTrDate(seen.get(x))) };
    }
    // NEW (v3.6.4): göreli süre ifadeleri — "15 (on beş) gün içinde", "bir hafta içinde", "2 ay içinde", "10 iş günü zarfında", "7 gün süre", "yirmi beş gün" …
    function findRelativeDeadline(text) {
        const F = trFold(String(text || "").replace(/[\u00A0\t ]+/g, " "));
        const NW = "(?:bir|iki|uc|dort|bes|alti|yedi|sekiz|dokuz|on|yirmi|otuz|kirk|elli|altmis|yetmis|seksen|doksan)";
        const W = { bir: 1, iki: 2, uc: 3, dort: 4, bes: 5, alti: 6, yedi: 7, sekiz: 8, dokuz: 9, on: 10, yirmi: 20, otuz: 30, kirk: 40, elli: 50, altmis: 60, yetmis: 70, seksen: 80, doksan: 90 };
        const re = new RegExp("(?<![\\d.\\w])(?:her\\s+)?\\(?(\\d{1,3}|" + NW + "(?:\\s+" + NW + "){0,2})\\)?\\s*(?:\\([^)]{1,25}\\))?\\s*(is\\s+gunu|takvim\\s+gunu|gunu|gun|hafta|ay)\\s*(?:icinde|icerisinde|zarfinda|sure(?:si|yle|ile)?\\b|sonuna\\s+kadar)", "g");
        let m;
        while ((m = re.exec(F))) {
            if (/^her\s/.test(m[0])) continue;
            let n = /^\d+$/.test(m[1]) ? +m[1] : m[1].split(/\s+/).reduce((a, w) => a + (W[w] || 0), 0);
            if (!(n > 0)) continue;
            const u = m[2].replace(/\s+/g, " ");
            if (u.startsWith("is")) return n + " iş günü içinde";
            if (u === "hafta") return (n * 7) + " gün içinde";
            if (u === "ay") { if (n <= 12) return n + " ay içinde"; continue; }
            if (n <= 366) return n + " gün içinde";
        }
        return "";
    }
    function parseDlDate(s) {
        s = String(s || "").replace(/\s+/g, "");
        let m = s.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})$/);
        if (m) return utcDate(+m[3], +m[2], +m[1]);
        m = s.match(/^(\d{1,2})([a-z]+)(\d{4})$/);
        if (m) { const mi = TR_MONTH_KEYS.indexOf(m[2]); if (mi >= 0) return utcDate(+m[3], mi + 1, +m[1]); }
        return null;
    }
    // NEW (v3.5.1): Gelen Evraklar satırındaki EBYS miadı → son tarih (evrak açılmadan). "Miat Tarihi: GG.AA.YYYY" varsa o; yoksa "Miat: N gün" → evrak tarihi + N takvim günü.
    function miatDeadlineOf(d) {
        if (!d) return null;
        const mt = d.miatTarihi ? parseTrDate(d.miatTarihi) : null;
        if (mt) return { iso: isoOf(mt), display: fmtTrDate(mt), kind: "miat", basis: "EBYS'de girilen miat tarihi" };
        const n = Number(d.miat);
        if (!(n > 0) || n > 366) return null;
        const base = parseTrDate(d.tarih) || parseTrDate(d.kayitTarihi);
        if (!base) return null;
        const dl = addDaysUtc(base, n);
        return { iso: isoOf(dl), display: fmtTrDate(dl), kind: "miat", basis: "EBYS Miat: " + n + " gün, evrak tarihinden (" + fmtTrDate(base) + ") itibaren" };
    }
    function countdownOf(dl) {
        const d = fromIso(dl && dl.iso), today = fromIso(istanbulTodayIso());
        if (!d || !today) return null;
        const diff = Math.round((d.getTime() - today.getTime()) / 86400000);
        const plain = diff > 0 ? diff + " gün kaldı" : diff === 0 ? "bugün son gün" : (-diff) + " gün geçti";
        const label = diff > 0 ? "⏳ " + plain : diff === 0 ? "⏰ Bugün son gün" : "⚠️ " + plain;
        const color = diff <= 2 ? "#F87171" : diff <= 5 ? "#FB923C" : "#86EFAC";
        return { diff: diff, plain: plain, label: label, color: color, level: diff <= 2 ? "red" : diff <= 5 ? "orange" : "green" };
    }
    // kalıcı kayıt: son tarihler evrak numarasına göre saklanır (yeniden yükleme/yeniden taramada geri gelir)
    const isValidDeadlineStore = v => isPlainObject(v) && Object.values(v).every(x => isPlainObject(x) && typeof x.iso === "string");
    let deadlineStore = loadJSON("ebys_deadlines_v1", {}, isValidDeadlineStore);
    // v1.0.3: Evrak Geçmişi'nden okunan Kimde (Gereği) — evrak no → kişi; yeniden taramada kaybolmaz
    const KIMDE_KEY = "ebys_kimde_gecmis_v1";
    let kimdeStore = loadJSON(KIMDE_KEY, {}, v => isPlainObject(v) && Object.values(v).every(x => isPlainObject(x) && typeof x.kimde === "string"));
    function saveDeadline(docNo, dl) {
        if (!docNo) return;
        if (dl) deadlineStore[docNo] = { iso: dl.iso, display: dl.display, kind: dl.kind, basis: dl.basis, savedAt: istanbulTodayIso() };
        else delete deadlineStore[docNo];
        const keys = Object.keys(deadlineStore);
        if (keys.length > 300) keys.sort((a, b) => String(deadlineStore[a].iso).localeCompare(String(deadlineStore[b].iso))).slice(0, keys.length - 300).forEach(k => delete deadlineStore[k]);
        extStoreSet("ebys_deadlines_v1", deadlineStore);
    }
    function getDeadline(d) { return (d && d.info && d.info.deadline) || (d && deadlineStore[d.docNo]) || miatDeadlineOf(d) || null; } // CHANGE (v3.5.1): yazıdan okunan yoksa EBYS miadı
    function renderCountdown(d) { renderCountdownV34(d); try { renderTakipCardBtn(d); } catch(e) {} } // NEW (v3.5): kartta 📅 Takibe al / Takipte
    function renderCountdownV34(d) {
        const card = findCardEl(d.docNo);
        const el = card && card.querySelector(".card-countdown");
        if (!el) return;
        const dl = getDeadline(d), cd = dl && countdownOf(dl);
        if (!cd) { el.style.display = "none"; el.textContent = ""; return; }
        el.textContent = cd.label + " • Son tarih: " + dl.display;
        el.title = dl.basis || "";
        el.setAttribute("data-level", cd.level);
        el.style.cssText = "display:block; font-size:11px; font-weight:800; padding:3px 8px; border-radius:8px; background:#1F2D4D; border:1px solid " + cd.color + "; color:" + cd.color + ";";
    }
    let lastCountdownDay = "";
    function refreshCountdowns() {
        lastCountdownDay = istanbulTodayIso();
        scannedList.forEach(renderCountdown);
    }

    // =========================================================================
    // NEW (v3): TANILAMA — canlı sitede neyin bulunduğunu raporlar (kişisel veri değil, kimlik/sayı bilgisi)
    // =========================================================================
    async function runDiagnostics() {
        const L = [];
        const add = (k, v) => L.push("• " + k + ": " + v);
        add("Sürüm", "Evrak Asistanı v" + EXT_VERSION); // v3.6.53: sabit "v3.6.4" yerine manifest sürümü
        add("Adres", location.host + location.pathname);
        add("Zaman (TR)", istanbulTodayIso());
        const link = findInboxMenuLink();
        add("Gelen Evraklar menüsü", link ? `bulundu (id=${link.id || "-"}, seçili=${isMenuSelected(link)}, sayı=${JSON.stringify(parseMenuCount(link))})` : "BULUNAMADI");
        const root = getInboxRoot();
        const rows = getInboxRows();
        add("Gelen Evraklar tablosu", root ? `id=${root.id || "-"}, başlık="${inboxHeaderText()}", bu sayfadaki satır=${rows.length}, data-rk'li=${rows.filter(r => r.getAttribute("data-rk")).length}, sayı okunabilen=${rows.filter(r => parseInboxRow(r)).length}` : "BULUNAMADI");
        add("Şu an Gelen Evraklar'da mı", String(isOnInbox()));
        { const pl = findParafMenuLink(); add("Parafladıklarım menüsü (şablon öğrenme)", pl ? "bulundu (id=" + (pl.id || "-") + ", onclick=" + String(pl.getAttribute("onclick") || "").slice(0, 90) + ")" : "BULUNAMADI"); } // NEW (v3.6)
        const pag = getInboxPaginator();
        if (pag) {
            const pages = pag.querySelectorAll(".ui-paginator-page").length, act = pag.querySelector(".ui-paginator-page.ui-state-active"), rpp = pag.querySelector("select.ui-paginator-rpp-options");
            add("Sayfalama", `id=${pag.id || "-"}, sayfa bağlantısı=${pages}, aktif=${act ? act.textContent.trim() : "-"}, ileri etkin=${!!findPaginatorButton("next", true)}, sayfa başına=${rpp ? rpp.value : "-"}`);
        } else add("Sayfalama", "yok");
        const others = Array.from(document.querySelectorAll(".ui-datatable-data")).filter(t => !root || !root.contains(t)).map(t => (t.id || "(id yok)") + "[" + t.children.length + (isVisible(t) ? "" : ", gizli") + "]");
        add("Taranmayan diğer tablolar", others.join(", ").slice(0, 600) || "-");
        const pf = getPreviewForm();
        add("Önizleme formu", pf ? `var; açık evrak=${isDocPreviewShown()}; Cevap Yaz=${!!findToolbarButton("Cevap Yaz")}; Evrak Kapat=${!!findToolbarButton("Evrak Kapat")}` : "yok");
        const fr = getPreviewFrame();
        if (fr) {
            let acc = false, layers = 0;
            try { const dd = fr.contentDocument; acc = !!dd; layers = dd ? dd.querySelectorAll(".textLayer").length : 0; } catch(e) {}
            add("Önizleme çerçevesi", `class=${fr.className}, görünür=${isVisible(fr)}, erişilebilir=${acc}, textLayer=${layers}, DOM metin uzunluğu=${readPdfDomText().length}`);
        } else add("Önizleme çerçevesi", "yok");
        bridgeState = { ok: null, at: 0 };
        const br = (await bridgeAvailable()) ? bridgeState.info : null;
        add("Köprü (sayfa dünyası: CKEditor/pdf.js)", br ? `çalışıyor; CKEditor=${br.ck}; örnekler=${(br.ckInstances || []).join(", ") || "-"}; pdf.js=${br.pdf}` : "YANIT YOK (bridge.js yüklenmemiş olabilir)");
        const ek = pf && pf.querySelector('tbody[id$="ekListesiOnizlemeDataTableBase_data"]');
        add("Evrak Ekleri tablosu", ek ? `satır=${ek.querySelectorAll(":scope > tr[data-ri]").length}` : "yok");
        const fs = document.querySelector('fieldset[id$="evrakKapatFieldsetId"]');
        if (fs) { const sc = fs.closest("form") || document; add("Evrak Kapatma paneli", `görünür=${isVisible(fs)}; konu kodu seçili=${!!lovSelectedTitle(sc, "konuKoduLov")}; klasör seçili=${!!lovSelectedTitle(sc, "klasorLov_id")}; onay düğmesi=${!!sc.querySelector('button[id$="onaysizKapatId"]')}`); }
        else add("Evrak Kapatma paneli", "açık değil");
        if (isCevapWindowOpen()) {
            const tabs = Array.from(document.querySelectorAll('[id$="cevapEvrakTabMenuLeft"] button')).map(b => (b.textContent || "").trim()).join("/");
            const eds = Array.from(document.querySelectorAll('div.cke[id^="cke_"]')).map(c => c.id.slice(4) + (isVisible(c) ? "" : "(gizli)")).join(", ");
            const t = findEditorTarget();
            add("Cevap Yaz penceresi", `açık; sekmeler=${tabs || "-"}; CKEditor kapları=${eds || "-"}; hedef=${t ? t.kind + (t.name ? ":" + t.name : "") : "yok"}`);
        } else add("Cevap Yaz penceresi", "açık değil");
        // NEW (v3.3): Havale akışı — kişi adı yazılmaz, yalnızca bulunan öğeler ve sayılar
        const tl = findTeslimMenuLink();
        add("Teslim Alınmayı Bekleyenler menüsü", tl ? `bulundu (id=${tl.id || "-"}, seçili=${isMenuSelected(tl)}, sayı=${JSON.stringify(parseMenuCount(tl))})` : "BULUNAMADI");
        add("Şu an Teslim Alınmayı Bekleyenler'de mi", String(isOnTeslim()));
        add("Sol menüde görünen başlıklar", listMenuLabels().slice(0, 40).join(" | ") || "yok"); // NEW (v3.6.4)
        if (isOnTeslim()) { const pr = rows.map(parseTeslimRow).filter(Boolean); add("Teslim listesi (bu sayfa)", `satır=${rows.length}, okunabilen=${pr.length}, sayısı (E-…) olan=${pr.filter(x => x.docNo).length}, seçili satır=${rows.filter(isTeslimRowSelected).length}`); }
        add("Teslim Al ve Havale Et düğmesi (önizleme)", findToolbarButton("Teslim Al ve Havale Et") ? "var" : "yok");
        add("Havale formu", isHavaleFormOpen() ? `açık; Kişiye Havale satırı=${!!document.querySelector('[id$="dagitimBilgileriKullaniciLov:LovSecilenTable"]')}; Hızlı Seçim düğmesi=${!!findHizliBtn()}; formdaki kişi=${kisiLovRows().length}; Teslim Al Gönder=${!!findToolbarButton("Teslim Al Gönder")}; Vazgeç=${!!findToolbarButton("Vazgeç")}` : (havaleFormEl() ? "DOM'da var, görünmüyor" : "açık değil"));
        const qd = quickDialog();
        if (qd) {
            const qr = quickRows(); const cnt = { G: 0, B: 0, S: 0, "": 0 };
            qr.forEach(r => { const v = quickActive(r); cnt[v] = (cnt[v] || 0) + 1; });
            add("Kişiye Havale - Hızlı Seçim penceresi", `id=${qd.id || "-"}; görünür=${isVisible(qd)}; kişi satırı=${qr.length}; Gereği/Bilgi düğmeli=${qr.filter(r => r.btns.some(b => b.v === "G") && r.btns.some(b => b.v === "B")).length}; seçili Gereği=${cnt.G}, Bilgi=${cnt.B}, Koordine=${cnt.S}, seçimsiz=${cnt[""]}; arama kutusu=${!!qd.querySelector('input[id$=":filter"]')}; sayfa=${quickPageCount()}; Tamam düğmesi=${!!findQuickTamam(true)}`);
        } else add("Kişiye Havale - Hızlı Seçim penceresi", "yok");
        add("Havale paneli", `teslim bekleyen (son tarama)=${havaleList.length}, kayıtlı kişi=${(havalePeople.people || []).length}, favori=${havaleFav.length}`);
        { const rs = getRulesStore(); add("Havale kuralları", `kural=${rs.rules.length} (etkin=${rs.rules.filter(r => r.enabled).length}), her evrakta Bilgi=${rs.globalBilgi.length}, eşik=${rs.options.threshold}, kurulum sayfası=${(() => { try { return !!chrome.runtime.getURL("setup.html"); } catch(e) { return false; } })()}`); } // NEW (v3.4)
        add("Günlü takip", takipDiagLine(await takipBg("ebys-takip-status"))); // NEW (v3.5): yalnızca sayılar
        add("Panel", `taranan evrak=${scannedList.length}, kayıtlı son tarih=${Object.keys(deadlineStore).length}`);
        const text = L.join("\n");
        console.log("[Evrak Asistanı] Tanılama raporu\n" + text);
        showDiagModal(text);
        return text;
    }
    function showDiagModal(text) {
        let m = document.getElementById("ebys-diag-modal");
        if (!m) {
            m = document.createElement("div");
            m.id = "ebys-diag-modal";
            m.style.cssText = "position:fixed !important; top:50% !important; left:50% !important; transform:translate(-50%,-50%) !important; width:620px; max-width:95vw; background:#1F2D4D !important; border:2px solid #FBBF24 !important; border-radius:16px; z-index:2147483647 !important; padding:14px; color:#E0E7FF; font:12px 'Segoe UI',sans-serif;";
            m.innerHTML = '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;"><b style="color:#FBBF24;">🩺 TANILAMA RAPORU</b><button id="btn-close-diag" style="background:none; border:none; color:#A9B6CA; font-size:16px; cursor:pointer;">✕</button></div><textarea id="ebys-diag-text" readonly style="width:100%; height:300px; box-sizing:border-box; background:#2D3D63; color:#E2E8F0; border:1px solid #56709A; border-radius:8px; font:11px monospace;"></textarea><div style="margin-top:8px; display:flex; gap:6px;"><button id="btn-copy-diag" style="background:#FBBF24; color:#111; border:none; padding:6px 12px; border-radius:8px; font-weight:bold; cursor:pointer;">📋 Kopyala</button><span style="font-size:10.5px; color:#A9B6CA; align-self:center;">Rapor kişisel veri değil, sayfada bulunan öğelerin kimliklerini içerir. Konsolda da [Evrak Asistanı] önekiyle yazıldı.</span></div>';
            document.body.appendChild(m);
            document.getElementById("btn-close-diag").onclick = () => { m.style.display = "none"; };
            document.getElementById("btn-copy-diag").onclick = async () => { const ok = await copyToClipboard(document.getElementById("ebys-diag-text").value); showToast(ok ? "✔️ Tanılama raporu panoya kopyalandı." : "⚠️ Kopyalanamadı; metni seçip kopyalayın.", ok ? "ok" : "warn"); };
        }
        document.getElementById("ebys-diag-text").value = text;
        m.style.display = "block";
    }


    // =========================================================================
    // 8. ÖNİZLEME OKUMA + ANALİZ
    // =========================================================================
    // NEW: önizleme metni — docMeta verilirse YALNIZCA o evrakın numarasını içeren önizleme döner (eski evrakın önizlemesi okunmaz)
    function readDeepDocumentPreview(docMeta) {
        const no = docMeta && docMeta.docNo ? String(docMeta.docNo) : "";
        const shortNo = no.includes("-") ? no.split("-").pop() : "";
        let best = "", bestMatch = "";
        for (let d of getAllDocs()) {
            const containers = Array.from(d.querySelectorAll(".textLayer, #viewer, .page, #previewPane, .evrak-onizleme, .ui-panel-content, [id*='onizleme'], [class*='onizleme']"));
            // NEW: çerçevedeki önizleme belgesinin gövdesi (editör gövdeleri ve tablo/form içeren uygulama çerçeveleri hariç)
            if (d !== document && d.body && !d.body.isContentEditable && String(d.designMode).toLowerCase() !== "on" && !d.querySelector(".ui-datatable, form, .ui-tabs")) containers.push(d.body);
            for (let c of containers) {
                if (c.tagName === "IFRAME" || c.isContentEditable || isPanelEl(c)) continue;
                const txt = c.innerText || "";
                if (!(txt.includes("DAĞITIM") || txt.includes("T.C.") || txt.includes("Sayı"))) continue;
                if (txt.length > best.length) best = txt;
                if (no && (txt.includes(no) || (shortNo.length > 5 && txt.includes(shortNo))) && txt.length > bestMatch.length) bestMatch = txt;
            }
        }
        return docMeta ? bestMatch : best;
    }

    function analyzeOfficialDocumentExpert(rawDocText, meta) {
        const text = rawDocText || meta.rawRowText;
        let nitelik = "Bilgi Amaçlı";
        let hitapKurali = "arz ederim."; // FIX: cümle ortasında küçük harf ("gereğini arz ederim")
        if (/gereğini rica ederim/i.test(text)) { hitapKurali = "arz ederim."; nitelik = "Resmî Cevap / Gereği Yapılacak"; }
        const cleanSub = meta.subject.replace(/^(Konu:|\s*)+/i, "").trim();
        // FIX: HTML sürümünde konu kaçışlanır; düz metin ayrı üretilir
        const customIntro = 'İlgi kayıtlı yazınız ile bildirilen <b>' + escapeHtml(cleanSub) + '</b> konulu hususlar müdürlüğümüzce incelenmiştir.';
        const customIntroPlain = 'İlgi kayıtlı yazınız ile bildirilen ' + cleanSub + ' konulu hususlar müdürlüğümüzce incelenmiştir.';
        const pureEditorHtml = '<p>' + customIntro + '</p><p>Bahse konu yazıda talep edilen hususlara ilişkin iş ve işlemler kurumumuzca tamamlanmış olup, tanzim edilen bilgi ve belgeler ekte sunulmuştur.</p><p>Bilgilerinizi ve gereğini ' + hitapKurali + '</p>';
        const pureEditorPlain = customIntroPlain + '\n\nBahse konu yazıda talep edilen hususlara ilişkin iş ve işlemler kurumumuzca tamamlanmış olup, tanzim edilen bilgi ve belgeler ekte sunulmuştur.\n\nBilgilerinizi ve gereğini ' + hitapKurali;
        // FIX: gönderen bilinmiyorsa "- tarafından" ifadesi kullanılmaz
        const hasSender = !!meta.gonderen && meta.gonderen !== "-";
        const ozet = hasSender ? meta.gonderen + ' tarafından iletilen "' + cleanSub + '" konulu evraktır.' : '"' + cleanSub + '" konulu evraktır.';
        return { tarih: meta.tarih || "", gonderen: hasSender ? meta.gonderen : "İlgili Resmî Makam", nitelik, ozet, editorHtml: pureEditorHtml, editorPlain: pureEditorPlain };
    }

    // FIX: gönderen sütunu — kurum adı kalıbına uyan, numara/konu olmayan ilk hücre; bulunamazsa ""
    function detectSender(row, docNo) {
        const kurumRe = /(müdürlüğü|valilik|valiliği|bakanlığı|başkanlığı|kaymakamlığı|rektörlüğü|belediyesi|\bMEM\b|\bMEB\b|okulu|lisesi|dairesi|kurumu|merkezi|komutanlığı)/i;
        for (let td of row.querySelectorAll("td")) {
            const c = (td.innerText || td.textContent || "").trim().replace(/\s+/g, " ");
            if (!c || c.length > 150 || c.includes(docNo) || /konu\s*:/i.test(c)) continue;
            if (kurumRe.test(c)) return c;
        }
        return "";
    }

    function grabCurrentPageDocs() {
        if (getInboxRoot()) return grabInboxPage(); // NEW (v3): gerçek Gelen Evraklar satırları
        let addedCount = 0;
        getMainTables().forEach(t => { // FIX (v3): gizli/bildirim tabloları ve iç içe satırlar taranmaz
            Array.from(t.children).filter(r => r.tagName === "TR").forEach(r => {
                const text = (r.innerText || "").trim();
                if (!text || text.length < 15 || text.includes("Kayıt bulunamadı")) return;
                const match = text.match(/E-\d{6,10}[-\w.]+/i) || text.match(/\b\d{8,10}\b/);
                if (!match) return;
                const docNo = match[0];
                let subject = "", gonderen = "-", tarih = "";
                const lines = text.split(/[\n\t]/).map(l => l.trim()).filter(Boolean);
                for (let l of lines) { if (l.toLowerCase().includes("konu:")) { subject = l.replace(/.*konu:\s*/i, "").trim(); break; } }
                if (!subject) { for (let l of lines) { if (l.length > 10 && !l.includes(docNo)) { subject = l; break; } } }
                const tMatch = text.replace(docNo, " ").match(/(?<![\d.-])\d{2}([./-])\d{2}\1\d{4}(?!\d)/);
                if (tMatch) tarih = tMatch[0];
                gonderen = detectSender(r, docNo) || "-";
                if (!scannedList.some(d => d.docNo === docNo)) {
                    scannedList.push({ docNo, subject: (subject || "Konu belirtilmemiş").substring(0, 110), gonderen, tarih, rawRowText: text });
                    addedCount++;
                }
            });
        });
        return addedCount;
    }

    // NEW (v3): son tarama listesi kalıcı (sayfa yenilense de kartlar ve geri sayımlar geri gelir)
    const LAST_SCAN_KEY = "ebys_last_scan_v1";
    function saveLastScan() {
        try {
            const list = scannedList.map(d => ({ docNo: d.docNo, rk: d.rk || "", subject: d.subject, gonderen: d.gonderen, tarih: d.tarih, kayitTarihi: d.kayitTarihi || "", miat: d.miat == null ? null : d.miat, miatTarihi: d.miatTarihi || "", islem: d.islem || "", ivedi: !!d.ivedi, kimde: d.kimde || "", kimdeKaynak: d.kimdeKaynak || "" }));
            extStoreSet(LAST_SCAN_KEY, { at: Date.now(), list: list });
        } catch(e) {}
    }
    function loadLastScan() {
        const v = loadJSON(LAST_SCAN_KEY, null, x => isPlainObject(x) && Array.isArray(x.list) && x.list.every(d => isPlainObject(d) && typeof d.docNo === "string"));
        return v;
    }

    // NEW (v3): tarama — gerçek EBYS'de YALNIZCA "İşlem Bekleyenler > Gelen Evraklar" satırları (gerekirse menüye geçilir; evrak açılmaz, önizleme/ek okunmaz).
    // Bulunan sayı menüdeki sayıyla karşılaştırılır.
    async function scanAllPagesSequentially(...a) { return autoWrap("Tarama", () => scanAllPagesSequentially_(...a)); }
    async function scanAllPagesSequentially_() {
        if (isScanningPages) return;
        if (havaleBusy || havaleScanning) { showToast("⏳ Havale işlemi sürüyor; bitmesini bekleyin.", "warn"); return; } // NEW (v3.3)
        if (hqActive()) { showToast("⏳ Havale sırası açık. Önce 📨 Havale sekmesinde ⏹ Durdur'a basın.", "warn"); return; } // NEW (v3.5.2)
        isScanningPages = true;
        document.querySelectorAll('[id^="ebys-scan-"], #btn-scan-goto-inbox').forEach(n => n.remove()); // NEW (v3.5.2): eski uyarılar kalmasın
        const prevList = scannedList;
        const byId = (id) => document.getElementById(id);
        const setBadge = () => { const b = byId("ebys-count-badge"); if (b) b.innerText = scannedList.length + " EVRAK"; };
        let limitHit = false, stuck = false, menuFail = false, real = false, menuCount = null;
        const deepCtx = { done: 0, found: 0, added: 0, fail: 0 }; deepStop = false; // NEW (v3.6.4)
        const deepPage = async (from) => { if (real && deepScanOn()) { try { await deepReadDocs(scannedList.slice(from), deepCtx); } catch(e) { console.warn("[Evrak Asistanı] Evrak içi okuma hatası:", e); } } };
        setScanButtons(true);
        try {
            scannedList = [];
            real = isRealEbys();
            if (real) {
                dbg("Tarama başladı (gerçek EBYS modu).");
                if (!(await gotoInbox())) { menuFail = true; return; }
            } else {
                await maximizeRowsPerPage();
            }
            if (!(await goFirstPage())) stuck = true;
            let _from = scannedList.length;
            grabCurrentPageDocs();
            setBadge();
            await deepPage(_from); // NEW (v3.6.4)
            const seen = new Set([tableSignature()]);
            let pageIndex = 1;
            while (!stuck && hasNextPage()) {
                if (pageIndex >= MAX_SCAN_PAGES) { limitHit = true; break; }
                if (!(await goNextPage())) { stuck = true; break; }
                const sig = tableSignature();
                if (seen.has(sig)) { stuck = true; break; }
                seen.add(sig);
                pageIndex++;
                _from = scannedList.length;
                grabCurrentPageDocs();
                setBadge();
                await deepPage(_from); // NEW (v3.6.4)
            }
            { const dn = document.getElementById("ebys-deep-notice"); if (dn) dn.remove();
              if (deepCtx.done || deepCtx.fail) showToast("🔍 " + deepCtx.done + " evrağın içi okundu; " + deepCtx.found + " günlü/tekrarlı evrak bulundu" + (deepCtx.added ? " (" + deepCtx.added + " yeni takip kaydı)" : "") + (deepCtx.fail ? ". " + deepCtx.fail + " evrak okunamadı" : "") + (deepStop ? " (durduruldu)" : "") + ".", deepCtx.found ? "ok" : "warn"); }
            if (real) {
                menuCount = parseMenuCount(findInboxMenuLink());
                dbg("Tarama bitti:", scannedList.length, "evrak,", pageIndex, "sayfa; menü sayısı:", menuCount ? menuCount.total : "-");
                if (pageIndex > 1) await goFirstPage(); // kullanıcıyı ilk sayfaya geri getir
            }
        } catch(err) {
            console.error("[Evrak Asistanı] Tarama hatası:", err);
            stuck = true;
        } finally {
            isScanningPages = false;
            setScanButtons(false); // NEW (v3.5.2): her durumda (yeniden çizilmiş panelde de) sıfırla
            [400, 1500].forEach(ms => setTimeout(() => { if (!isScanningPages) setScanButtons(false); }, ms));
            if (menuFail && prevList && prevList.length) scannedList = prevList; // önceki liste kaybolmasın
            hasScanned = true;
            if (!menuFail) saveLastScan();
            renderPanelList();
            if (!menuFail) { try { takipOnScan(); } catch(e) {} } // NEW (v3.5.1)
            setBadge();
            const c = byId("ebys-cards-container");
            const addNotice = (id, text, ok) => {
                if (!c) return;
                const n = document.createElement("div");
                n.id = id;
                n.style.cssText = ok ? "background:#064E3B; color:#A7F3D0; border:1px solid #10B981; padding:8px; border-radius:10px; font-size:11px;" : "background:#78350F; color:#FDE68A; border:1px solid #F59E0B; padding:8px; border-radius:10px; font-size:11px;";
                n.textContent = text;
                c.prepend(n);
            };
            if (menuFail) { addNotice("ebys-scan-menu-notice", "⚠️ 'İşlem Bekleyenler > Gelen Evraklar' menüsü bulunamadı ya da açılamadı; tarama yapılmadı." + (lastNavFailure ? " " + lastNavFailure : "") + " (🩺 Tanılama ile rapor alabilirsiniz.)"); scanNavHelpButton(c); }
            if (limitHit) addNotice("ebys-scan-limit-notice", "⚠️ Tarama " + MAX_SCAN_PAGES + " sayfa sınırına ulaştı; sonraki sayfalardaki evraklar listelenmedi.");
            if (stuck) addNotice("ebys-scan-stuck-notice", "⚠️ Sayfa geçişi beklenen sürede tamamlanmadı; liste eksik olabilir. Taramayı tekrar deneyin.");
            if (real && !menuFail && menuCount) {
                if (menuCount.total === scannedList.length) addNotice("ebys-scan-count-ok", "✔️ Gelen Evraklar: " + scannedList.length + " / " + menuCount.total + " evrak tarandı (menüdeki sayı ile aynı).", true);
                else addNotice("ebys-scan-count-mismatch", "⚠️ Menüde " + menuCount.total + " evrak görünüyor, taramada " + scannedList.length + " evrak bulundu. Liste eksik/fazla olabilir; taramayı tekrar deneyin.");
            }
        }
    }

    // =========================================================================
    // 9. TOPLU İŞLEMLER VE YEDEKLEME (JSON EXPORT/IMPORT)
    // =========================================================================

    // FIX (v3): evrak açılamazsa görünür uyarı ve false — nedeni (menü / listede yok / önizleme gelmedi) belirtilir
    // NEW (v3.6.37): kapatılan evrak sağdaki listeden ANINDA kaldırılır (durum + DOM + kayıtlı son tarama), sayaç güncellenir; yeniden yükleme gerekmez.
    let lastOpenedDocNo = "";
    function removeDocFromPanel(docNo, verify) {
        docNo = String(docNo || "").trim(); if (!docNo) return false;
        const before = scannedList.length;
        scannedList = scannedList.filter(x => x.docNo !== docNo);
        const card = findCardEl(docNo);
        if (card) { card.style.transition = "opacity .2s ease, max-height .25s ease"; card.style.overflow = "hidden"; card.style.maxHeight = card.offsetHeight + "px"; requestAnimationFrame(() => { card.style.opacity = "0"; card.style.maxHeight = "0"; }); setTimeout(() => { try { card.remove(); } catch(e) {} if (!scannedList.length) { try { renderPanelList(); } catch(e) {} } }, 260); }
        const b = document.getElementById("ebys-count-badge"); if (b) b.innerText = scannedList.length + " EVRAK";
        if (before !== scannedList.length) saveLastScan();
        if (lastOpenedDocNo === docNo) lastOpenedDocNo = "";
        // EBYS kapatmayı reddederse (satır listede kalırsa) kart geri gelmesin diye değil, KULLANICI bilsin diye: 4 sn sonra kontrol
        if (verify && isRealEbys()) setTimeout(() => { try { if (findInboxRow({ docNo: docNo, rk: "" })) showToast("ℹ️ \"" + docNo + "\" EBYS listesinde hâlâ görünüyor; 🔄 Tara ile listeyi yenileyebilirsiniz.", "info"); } catch(e) {} }, 4000);
        return before !== scannedList.length;
    }
    // EBYS'nin kendi "Evrak Kapat" (onaysız kapat) düğmesine ELLE basıldığında da: AJAX bitince panel kapandıysa açık evrak listeden düşer
    document.addEventListener("click", (ev) => {
        try {
            const b = ev.target && ev.target.closest && ev.target.closest('button[id$="onaysizKapatId"]');
            if (!b || !ev.isTrusted) return;
            const no = lastOpenedDocNo || (() => { // panelden açılmadıysa: seçili satır / önizleme metnindeki evrak no
                try { const sr = getInboxRows().find(isRowSelected); const t = ((sr && sr.textContent) || "") + " " + (((getPreviewForm && getPreviewForm()) || {}).textContent || "");
                      const hit = scannedList.find(x => x.docNo && t.includes(x.docNo)); return hit ? hit.docNo : ""; } catch(e) { return ""; } })();
            if (!no) return;
            setTimeout(async () => {
                await waitFor(() => !isAjaxBusy() && !bekleyinizStrict(), 15000, 200);
                const fs = document.querySelector('fieldset[id$="evrakKapatFieldsetId"]');
                if (!fs || !isVisible(fs)) { if (removeDocFromPanel(no, false)) showToast("✔️ \"" + no + "\" kapatıldı; listeden kaldırıldı.", "ok"); }
            }, 300);
        } catch(e) {}
    }, true);
    async function openDocOrWarn(docOrNo) {
        const d = typeof docOrNo === "object" && docOrNo ? docOrNo : (scannedList.find(x => x.docNo === String(docOrNo).trim()) || { docNo: String(docOrNo).trim(), rk: "" });
        const ok = await findAndOpenDocument(String(d.docNo).trim(), d);
        if (ok) lastOpenedDocNo = String(d.docNo).trim(); // v3.6.37
        if (!ok) {
            const why = { menu: "Gelen Evraklar menüsü açılamadı.", notfound: "Evrak Gelen Evraklar listesinde yok (kapatılmış/havale edilmiş olabilir; yeniden tarayın).", preview: "Satır seçildi fakat evrak önizlemesi yüklenmedi." }[lastOpenFailure] || "Evrak listede bulunamadı / açılamadı.";
            showToast(`⚠️ "${d.docNo}" açılamadı. ${why} Yanlış evrak üzerinde işlem yapılmaması için işlem iptal edildi.`, "warn"); // v3.6.37: açılır pencere yok
        }
        return ok;
    }

    // =========================================================================
    // NEW: BİLDİRİM, AKILLI NİTELİK RAPORU VE ŞABLON DEĞİŞKENLERİ
    // =========================================================================
    // NEW: engellemeyen kısa bildirim
    function showToast(msg, kind) {
        if (frCapture && (kind === "warn" || kind === "error")) { msg = String(msg).replace(/^(⛔|⚠️)\s*/, "ℹ️ İlk kullanım: "); kind = "info"; } // v3.6.35: ilk çalıştırmada alarm yok
        let t = document.getElementById("ebys-toast");
        if (!t) { t = document.createElement("div"); t.id = "ebys-toast"; document.body.appendChild(t); }
        const bg = kind === "warn" ? "#B45309" : kind === "error" ? "#B91C1C" : "#047857";
        t.style.cssText = "position:fixed !important; right:16px !important; bottom:16px !important; max-width:400px; z-index:2147483647 !important; padding:10px 14px; border-radius:12px; font:12px 'Segoe UI',sans-serif; color:white; white-space:pre-line; box-shadow:0 4px 16px rgba(0,0,0,.4); background:" + bg + " !important;";
        t.textContent = msg;
        t.style.display = "block";
        clearTimeout(showToast.timer);
        showToast.timer = setTimeout(() => { t.style.display = "none"; }, 8000);
    }

    // NEW: cevap akışı sonucunu kullanıcıya bildir
    function reportReplyResult(res, missing) {
        if (res && res.firstRunDeferred) return; // v3.6.35: İlk Cevap Yardımcısı paneli gösteriliyor
        if (res && res.aborted) return; // v3.6.55: neden zaten bildirildi
        if (!res.kind && lastGerekFailed) { showToast("⚠️ Gereği seçilemediği için metin editöre yazılmadı" + (res.copied ? "; metin panoya kopyalandı." : "."), "warn"); return; }
        if (!res.kind) {
            alert("⚠️ Cevap editörü bulunamadı; metin hiçbir alana yazılmadı.\n" + (res.copied ? "Metin panoya kopyalandı; editöre kendiniz yapıştırabilirsiniz." : "Metin panoya da kopyalanamadı."));
            return;
        }
        let msg = "✔️ Metin editöre yazıldı (" + (EDITOR_KIND_LABELS[res.kind] || res.kind) + ")" + (res.copied ? " ve panoya kopyalandı." : "; panoya kopyalanamadı.");
        if (missing && missing.length) {
            msg += "\n⚠️ Belgeden okunamayan alan(lar): " + missing.join(", ") + " — metinde \"" + TEMPLATE_BLANK + "\" olarak bırakıldı, lütfen kontrol ediniz.";
            console.warn("[Evrak Asistanı] Şablon değişkenleri doldurulamadı:", missing);
        }
        showToast(msg, missing && missing.length ? "warn" : "ok");
    }

    // NEW: açılan evrakın önizlemesi gelene kadar bekle; gelmezse ""
    async function waitForPreview(docMeta, timeoutMs = PREVIEW_TIMEOUT_MS) {
        const txt = await waitFor(() => readDeepDocumentPreview(docMeta), timeoutMs, 200);
        if (!txt) return "";
        await new Promise(r => setTimeout(r, 300)); // metin katmanı tamamlanırken kısa bekleme
        const again = readDeepDocumentPreview(docMeta);
        return again.length > txt.length ? again : txt;
    }

    // NEW: önizleme metninden nitelik çıkarımı (sayı, konu, tarih, gönderen makam, aciliyet/süre, talep özeti)
    const TR_MONTHS = "Ocak|Şubat|Mart|Nisan|Mayıs|Haziran|Temmuz|Ağustos|Eylül|Ekim|Kasım|Aralık";
    const DATE_SRC = "(\\d{1,2}[./]\\d{1,2}[./]\\d{4}|\\d{1,2}\\s+(?:" + TR_MONTHS + ")\\s+\\d{4})";
    function extractDocAttributes(rawText) {
        const text = String(rawText || "").replace(/\r/g, "").replace(/[ \t\u00A0]+/g, " ");
        const lines = text.split("\n").map(l => l.trim()).filter(Boolean);
        const res = { sayi: "", konu: "", tarih: "", gonderen: "", aciliyet: "Belirlenemedi", acil: false, sonTarih: "", sonTarihDiger: [], talepOzeti: "", previewVerified: lines.length > 0 };
        if (!lines.length) return res;
        const DATE = new RegExp(DATE_SRC, "i");
        const sm = text.match(/(?:Sayı|SAYI|Sayi)\s*:?\s*(E-\d{6,10}[-\w.]*\w)/);
        if (sm) res.sayi = sm[1];
        const km = text.match(/(?:^|\n)\s*(?:Konu|KONU)\s*:\s*([^\n]{3,250})/);
        if (km) res.konu = km[1].trim();
        // Tarih: önce Sayı satırı, sonra "Tarih:" etiketi, sonra başlık bölgesi (İlgi satırı ve süre ifadeleri hariç)
        const strip = (l) => (res.sayi ? l.split(res.sayi).join(" ") : l);
        const sayiLine = lines.find(l => /^(Sayı|SAYI|Sayi)\s*:/.test(l));
        let dm = sayiLine ? strip(sayiLine).match(DATE) : null;
        if (!dm) { const tl = lines.find(l => /^(Tarih|TARİH)\s*:/.test(l)); dm = tl ? tl.match(DATE) : null; }
        if (!dm) {
            const ki = lines.findIndex(l => /^(Konu|KONU)\s*:/.test(l));
            for (let l of lines.slice(0, ki >= 0 ? ki + 1 : 8)) {
                if (/^(İlgi|İLGİ|Ilgi)\s*:/.test(l) || /en geç|kadar/i.test(l)) continue;
                const m = strip(l).match(DATE);
                if (m) { dm = m; break; }
            }
        }
        if (dm) res.tarih = dm[1];
        // Gönderen makam: "T.C." satırından sonraki başlık satırları
        const tc = lines.findIndex(l => /^T\.\s?C\.?$/.test(l));
        if (tc >= 0) {
            const parts = [];
            for (let i = tc + 1; i < lines.length && parts.length < 3; i++) {
                const l = lines[i];
                if (/^(Sayı|SAYI|Sayi|Konu|KONU|Tarih|TARİH|İlgi|İLGİ)\s*:/.test(l) || l.length > 80 || /^\d/.test(l)) break;
                parts.push(l);
            }
            res.gonderen = parts.join(" ").trim();
        }
        // Aciliyet: İVEDİ / GİZLİ / KİŞİYE ÖZEL / HİZMETE ÖZEL / ACELE + süre ifadeleri
        const W = "(?:^|[^A-Za-zÇĞİÖŞÜçğıöşü])", WE = "(?=$|[^A-Za-zÇĞİÖŞÜçğıöşü])";
        const flags = [];
        if (new RegExp(W + "(İVEDİ|İvedi|ivedi)" + WE).test(text) || /ivedilikle/i.test(text)) flags.push("İVEDİ");
        const gm = text.match(new RegExp(W + "(GİZLİ|KİŞİYE ÖZEL|HİZMETE ÖZEL)" + WE));
        if (gm) flags.push(gm[1]);
        if (new RegExp(W + "(ACELE|GÜNLÜDÜR)" + WE).test(text)) flags.push("ACELE");
        // CHANGE (v3.5.1): açık tarihli tüm son tarih ifadeleri (ay adları her yazımla); en yakın gelecekteki seçilir, diğerleri ayrıca tutulur
        const dlx = findDeadlineDates(text, res.tarih);
        const dl3 = text.match(/(\d{1,3}|bir|iki|üç|dört|beş|altı|yedi|sekiz|dokuz|on|on beş|otuz)\s+(?:iş\s+)?günü?\s+(?:içinde|içerisinde|zarfında)/i);
        const relDl = findRelativeDeadline(text); // NEW (v3.6.4)
        if (dlx.chosen) { res.sonTarih = dlx.chosen; res.sonTarihDiger = dlx.others; }
        else if (relDl || dl3) res.sonTarih = relDl || dl3[0].replace(/\s+/g, " ");
        res.kisaIcerik = res.sonTarih ? deadlineExcerpt(text, res.tarih) : ""; // NEW (v3.5.2): yalnızca son tarih cümle(ler)i
        if (res.sonTarih) flags.push((dlx.chosen ? "Son tarih: " : "Süre: ") + res.sonTarih + (res.sonTarihDiger.length ? " (diğer: " + res.sonTarihDiger.join(", ") + ")" : ""));
        res.tekrar = findRecurringRule(text); // NEW (v3.6.4): aylık/haftalık tekrar eden istek
        if (res.tekrar) { const un = findRuleUntil(text); if (un) res.tekrar = Object.assign({}, res.tekrar, { until: un }); } // NEW (v3.6.5): "… tarihine kadar"
        if (res.tekrar) flags.push("🔁 " + ruleText(res.tekrar));
        res.acil = flags.length > 0;
        res.aciliyet = flags.length ? flags.join(" • ") : "Normal";
        // Talep özeti: Konu satırından sonra, DAĞITIM'dan önce; anahtar ifade içeren ilk iki cümle (kapanış kalıbı hariç)
        let body = text;
        const kp = body.search(/(?:^|\n)\s*(?:Konu|KONU)\s*:/);
        if (kp >= 0) { const nl = body.indexOf("\n", kp + 2); body = nl > 0 ? body.slice(nl) : ""; }
        const dp = body.search(/\n\s*(?:DAĞITIM|Dağıtım)\s*:/);
        if (dp > 0) body = body.slice(0, dp);
        const sentences = body.replace(/\s*\n\s*/g, " ").split(/(?<=[.!?])\s+(?=[A-ZÇĞİÖŞÜ0-9"“(])/).map(s => s.trim()).filter(s => s.length > 15);
        const KEY = /(talep|istenmekte|istenilmekte|gerekmekte|rica ederim|rica olunur|arz ederim|gönderilmesi|bildirilmesi|iletilmesi|yapılması|sağlanması|hazırlanması|beklenmektedir)/i;
        const CLOSING = /^(Bilgilerinizi|Bilgilerini|Gereğini|Bilgi ve gereğini)[^.]{0,60}(rica|arz) ederim\.?$/i;
        res.talepOzeti = sentences.filter(s => KEY.test(s) && !CLOSING.test(s) && !/^(İlgi|İLGİ)\s*:/.test(s)).slice(0, 2).join(" ").slice(0, 400);
        return res;
    }

    // =========================================================================
    // NEW: EKLER (Ekler / Gelen Ekler) — ek adları + okunabiliyorsa ek metni
    // Ek okuma hiçbir zaman ana akışı (aç → analiz → cevap) bozmaz: toplam süre sınırı, öğe başı süre sınırı, try/catch.
    // =========================================================================
    const ATTACH_TIMEOUT_MS = 8000;       // NEW: tüm eklerin okunması için azami süre
    const ATTACH_ITEM_TIMEOUT_MS = 2500;  // NEW: tek ekin önizlemesi için azami bekleme
    const MAX_ATTACHMENTS = 10;
    const ATTACH_FILE_RE = /\.(pdf|docx?|xlsx?|odt|ods|txt|html?|rtf|jpe?g|png|tiff?|udf|eyp|zip|rar)(\s|$|\))/i;
    const ATTACH_EMPTY_RE = /(ek bulunmamaktadır|ek bulunamadı|eki bulunmamaktadır|kayıt bulunamadı|ek yok)/i;

    // NEW: "Ekler" / "Gelen Ekler" sekmesi ya da akordeon başlığı (panel dışı, görünür)
    function findAttachmentTab() {
        for (let doc of getAllDocs()) {
            for (let el of doc.querySelectorAll(".ui-tabs-nav li, .ui-tabview-nav li, [role='tab'], .ui-accordion-header")) {
                if (isPanelEl(el) || !isVisible(el)) continue;
                const txt = (el.innerText || el.textContent || "").trim().replace(/\s+/g, " ");
                if (/^(gelen\s+|evrak\s+)?ekler?(\s*\(\d+\))?$/i.test(txt) || /^(gelen\s+)?ekler\b/i.test(txt)) return el;
            }
        }
        return null;
    }
    // NEW: sekmenin içerik paneli (href / aria-controls / aynı sekme grubundaki görünür panel)
    function getAttachmentPanel(tab) {
        const doc = tab.ownerDocument;
        try {
            const a = tab.querySelector("a[href^='#']");
            const id = (a && a.getAttribute("href").slice(1)) || tab.getAttribute("aria-controls");
            if (id) { const p = doc.getElementById(id); if (p && isVisible(p)) return p; }
        } catch(e) {}
        if (tab.classList.contains("ui-accordion-header")) { const n = tab.nextElementSibling; if (n && isVisible(n)) return n; }
        const group = tab.closest(".ui-tabs, .ui-tabview");
        if (group) {
            for (let p of group.querySelectorAll(".ui-tabs-panel, .ui-tabview-panel, [role='tabpanel']")) { if (isVisible(p)) return p; }
        }
        return null;
    }
    // NEW: ek listesindeki öğeler (en içteki satır/öğe; iç içe tekrar yok)
    function findAttachmentItems(panel) {
        if (!panel) return null;
        const txtAll = panel.innerText || "";
        const cands = Array.from(panel.querySelectorAll(".ui-datalist-item, li, tr")).filter(el => {
            if (!isVisible(el) || el.closest("[id*='nizleme'], .ek-onizleme")) return false;
            const t = (el.innerText || "").trim();
            return t.length > 0 && t.length < 300 && (ATTACH_FILE_RE.test(t) || /^ek[-\s]?\d+/i.test(t));
        });
        const items = cands.filter(el => !cands.some(o => o !== el && el.contains(o)));
        if (items.length) return { items: items };
        if (ATTACH_EMPTY_RE.test(txtAll)) return { items: [], empty: true };
        return null;
    }
    // NEW: ek önizleme alanı (liste dışında; iframe/embed/object/canvas/metin katmanı)
    function findAttachmentPreviewEl(panel) {
        const doc = panel.ownerDocument;
        const sel = "[id*='nizleme'], .ek-onizleme, .textLayer, iframe, embed, object, canvas";
        const inPanel = Array.from(panel.querySelectorAll(sel)).filter(el => isVisible(el));
        if (inPanel.length) return inPanel[0].closest("[id*='nizleme'], .ek-onizleme") || inPanel[0];
        const out = Array.from(doc.querySelectorAll("[id*='ekOnizleme'], [id*='ekGoruntule'], .ek-onizleme")).find(el => isVisible(el) && !isPanelEl(el));
        return out || null;
    }
    function readPreviewElement(el) {
        const res = { text: "", binary: false, sig: "" };
        if (!el) return res;
        const parts = [el];
        if (el.tagName === "IFRAME") parts.length = 0;
        el.querySelectorAll && el.querySelectorAll("iframe").forEach(f => parts.push(f));
        if (el.tagName === "IFRAME") parts.push(el);
        let text = "", srcs = "";
        parts.forEach(p => {
            try {
                if (p.tagName === "IFRAME") {
                    srcs += "|" + (p.getAttribute("src") || p.getAttribute("srcdoc") || "").slice(0, 200);
                    const d = p.contentDocument;
                    if (d && d.body) {
                        text += "\n" + (d.body.innerText || "");
                        if (d.querySelector("embed, object, canvas")) res.binary = true;
                    } else res.binary = true; // farklı origin / okunamayan görüntüleyici
                } else {
                    text += "\n" + (p.innerText || "");
                    p.querySelectorAll && p.querySelectorAll("embed, object, canvas").forEach(b => { res.binary = true; srcs += "|" + (b.getAttribute("src") || b.getAttribute("data") || b.id || "canvas"); });
                }
            } catch(e) { res.binary = true; }
        });
        if (/^(EMBED|OBJECT|CANVAS)$/.test(el.tagName)) { res.binary = true; srcs += "|" + (el.getAttribute("src") || el.getAttribute("data") || el.id || "x"); }
        res.text = text.replace(/[ \t\u00A0]+/g, " ").replace(/\n\s*\n+/g, "\n").trim();
        res.sig = res.text.length + ":" + res.text.slice(0, 200) + srcs;
        return res;
    }
    // NEW: ek metninden ana noktalar (talep içeren cümleler / numaralı maddeler)
    function attachmentKeyPoints(text) {
        const KEY = /(talep|istenmekte|istenilmekte|gerekmekte|gerekir|rica|gönderilmesi|bildirilmesi|yapılması|sağlanması|hazırlanması|doldurulması|beklenmektedir|zorunludur)/i;
        const lines = String(text || "").split("\n").map(l => l.trim()).filter(l => l.length > 8);
        const pts = [];
        for (let l of lines) {
            for (let s of l.split(/(?<=[.!?])\s+(?=[A-ZÇĞİÖŞÜ0-9])/)) {
                s = s.trim();
                if (s.length > 8 && (KEY.test(s) || /^\d+[.)-]\s/.test(s)) && !pts.includes(s)) pts.push(s.length > 160 ? s.slice(0, 157) + "..." : s);
                if (pts.length >= 3) return pts;
            }
        }
        return pts;
    }

    async function readAttachments() {
        const result = { tabFound: false, items: [], timedOut: false, error: "" };
        const deadline = Date.now() + ATTACH_TIMEOUT_MS;
        const left = () => Math.max(0, deadline - Date.now());
        let tab = null, prevTab = null;
        try {
            tab = findAttachmentTab();
            if (!tab) return result;
            result.tabFound = true;
            const cnt = (tab.innerText || "").match(/\((\d+)\)/);
            if (cnt && cnt[1] === "0") return result; // "Ekler (0)": tıklamaya gerek yok
            const group = tab.closest(".ui-tabs-nav, .ui-tabview-nav, [role='tablist']");
            if (group) prevTab = Array.from(group.querySelectorAll("li, [role='tab']")).find(t => t !== tab && (t.classList.contains("ui-state-active") || t.classList.contains("ui-tabs-selected") || t.getAttribute("aria-selected") === "true")) || null;
            (tab.querySelector("a") || tab).click();
            const found = await waitFor(() => { const p = getAttachmentPanel(tab); const r = findAttachmentItems(p); return r ? Object.assign({ panel: p }, r) : null; }, Math.min(left(), 4000), 150);
            if (!found) { result.timedOut = true; result.error = "Ek listesi yüklenmedi"; return result; }
            if (found.empty) return result;
            const items = found.items.slice(0, MAX_ATTACHMENTS);
            let prevSig = readPreviewElement(findAttachmentPreviewEl(found.panel)).sig, prevReadable = false;
            for (let i = 0; i < items.length; i++) {
                const itemEl = items[i];
                const name = ((itemEl.innerText || "").trim().split("\n")[0] || ("Ek-" + (i + 1))).replace(/\s+/g, " ").slice(0, 120);
                const entry = { name: name, readable: false, text: "", points: [], note: "" };
                result.items.push(entry);
                if (left() <= 0) { entry.note = "Süre sınırı nedeniyle okunmadı."; result.timedOut = true; continue; }
                try {
                    const link = itemEl.querySelector("a, button, .ui-commandlink") || itemEl;
                    link.click();
                    const changed = await waitFor(() => { const r = readPreviewElement(findAttachmentPreviewEl(found.panel)); return (r.sig && r.sig !== prevSig && (r.text.length > 0 || r.binary)) ? r : null; }, Math.min(left(), ATTACH_ITEM_TIMEOUT_MS), 150);
                    let pv = changed;
                    if (pv) { await new Promise(r => setTimeout(r, 200)); const again = readPreviewElement(findAttachmentPreviewEl(found.panel)); if (again.text.length >= pv.text.length) pv = again; prevSig = pv.sig; }
                    const text = pv ? pv.text.replace(name, "").trim() : "";
                    if (pv && text.length >= 20) {
                        entry.readable = true;
                        entry.text = text.slice(0, 4000);
                        entry.points = attachmentKeyPoints(entry.text);
                    } else if ((pv && pv.binary) || /\.pdf/i.test(name)) {
                        entry.note = "PDF/görüntü metni sayfada okunamadı; yalnızca adı listelendi.";
                    } else {
                        entry.note = (prevReadable && !pv) ? "Önizleme zamanında yüklenmedi." : "Önizleme metni okunamadı.";
                    }
                    prevReadable = entry.readable;
                } catch(e) { entry.note = "Ek okunamadı."; }
            }
        } catch(err) {
            result.error = String(err && err.message || err);
            console.warn("[Evrak Asistanı] Ekler okunamadı:", err);
        } finally {
            // önceki sekmeye (ör. "Evrak / Üst Yazı") geri dön — ana akış kaldığı yerden devam eder
            try { if (prevTab && isVisible(prevTab)) (prevTab.querySelector("a") || prevTab).click(); } catch(e) {}
        }
        return result;
    }
    // NEW: ek okuma her durumda süre sınırıyla döner (asla akışı kilitlemez)
    async function readAttachmentsSafe() {
        const fallback = { tabFound: false, items: [], timedOut: true, error: "zaman aşımı" };
        try {
            return await Promise.race([readAttachments(), new Promise(r => setTimeout(() => r(fallback), ATTACH_TIMEOUT_MS + 1500))]);
        } catch(e) { return { tabFound: false, items: [], timedOut: false, error: String(e) }; }
    }

    // NEW: önizleme (öncelikli) + tablo satırı (yedek) + ekler verilerinin birleşimi; (v3) satırdaki İVEDİ/Miat ve son tarih/geri sayım
    function buildDocInfo(d, previewText, att, extra) {
        const a = extractDocAttributes(previewText);
        const items = (att && att.items) || [];
        const fromAtt = items.filter(x => x.readable).map(x => extractDocAttributes(x.text));
        const pick = (k) => { for (let f of fromAtt) { if (f[k]) return f[k]; } return ""; };
        const ekPoints = [];
        items.forEach(x => x.points.forEach(p => { if (ekPoints.length < 3) ekPoints.push(p); }));
        const ekOzeti = ekPoints.join(" ");
        let talep = a.talepOzeti || "";
        if (ekOzeti) talep = (talep ? talep + " " : "") + "Ek(ler)de: " + ekOzeti;
        if (talep.length > 600) talep = talep.slice(0, 597) + "...";
        const rowSubject = d.subject && d.subject !== "Konu belirtilmemiş" ? d.subject : "";
        const rowSender = d.gonderen && d.gonderen !== "-" ? d.gonderen : "";
        // NEW (v3): satırdaki İVEDİ işareti ve Miat bilgisi aciliyete eklenir
        let aciliyet = a.aciliyet, acil = a.acil;
        const extraFlags = [];
        if (d.ivedi && !/İVEDİ/.test(aciliyet)) extraFlags.push("İVEDİ");
        if (d.miat > 0) extraFlags.push("Miat: " + d.miat + " gün");
        if (extraFlags.length) { aciliyet = (aciliyet && aciliyet !== "Normal" && aciliyet !== "Belirlenemedi" ? aciliyet + " • " : "") + extraFlags.join(" • "); acil = true; }
        if (!a.previewVerified && !extraFlags.length) aciliyet = "Belirlenemedi";
        const tarih = a.tarih || (extra && extra.evrakTarihi) || d.tarih || pick("tarih");
        // NEW (v3): son tarih (günlü evrak) — açık tarih ya da evrak tarihinden itibaren gün / iş günü
        const sonTarih = a.sonTarih || pick("sonTarih");
        const tekrar = a.tekrar || pick("tekrar") || null; // NEW (v3.6.4)
        let deadline = computeDeadline(sonTarih, tarih);
        if (tekrar) deadline = recurringDeadline(tekrar) || deadline; // tekrarlı yazıda sıradaki tarih esas alınır
        const kisiText = [previewText || "", rowSubject].concat(items.filter(x => x.readable && x.text).map(x => x.text)).join("\n");
        const infoObj = {
            tekrar: tekrar,
            sayi: a.sayi || d.docNo || "",
            konu: a.konu || rowSubject || pick("konu"),
            tarih: tarih,
            gonderen: a.gonderen || rowSender || pick("gonderen"),
            aciliyet: aciliyet, acil: acil, sonTarih: sonTarih,
            sonTarihDiger: a.sonTarih ? (a.sonTarihDiger || []) : [], // NEW (v3.5.1)
            kisaIcerik: a.kisaIcerik || "", // NEW (v3.5.2)
            deadline: deadline,
            talepOzeti: talep,
            previewVerified: a.previewVerified,
            noVerified: extra ? !!extra.verified : !!a.previewVerified,
            source: extra && extra.source ? extra.source : "",
            ekler: items.map(x => ({ name: x.name, readable: x.readable, points: x.points, note: x.note, fid: x.fid || "", kind: x.kind || "", form: x.form || null })),
            ekHata: (att && att.error) || "", ekBolumu: !!(att && att.tabFound), ekZamanAsimi: !!(att && att.timedOut), ekOzeti: ekOzeti
        };
        // kişi/TC bilgisi yalnızca bellekte tutulur (numaralandırılamaz özellik: JSON'a/depoya yazılmaz)
        try { Object.defineProperty(infoObj, "kisiler", { value: extractKisiler(kisiText), enumerable: false, writable: true }); } catch(e) {}
        return infoObj;
    }
    function metaFromInfo(d) {
        const i = d.info || buildDocInfo(d, "");
        return Object.assign({}, d, { subject: i.konu || d.subject || "", gonderen: i.gonderen || "-", tarih: i.tarih || "" });
    }

    const tplCatOpen = {}; // NEW (v3.6.37): şablon kategorisi aç/kapa durumu (yalnız bu sekmede)
    function findCardEl(docNo) {
        for (let c of document.querySelectorAll("#ebys-cards-container .ebys-doc-card")) { if (c.getAttribute("data-docno") === docNo) return c; }
        return null;
    }

    // NEW: kartta ek sayısı ve eklerin ana noktaları
    function ekHtml(i) {
        const list = i.ekler || [];
        if (!i.ekBolumu && !list.length) return '<div class="attr-ekler">📎 <b>Ekler:</b> ' + (i.ekHata ? "⚠️ " + escapeHtml(i.ekHata) : i.ekZamanAsimi ? "⚠️ zaman aşımı, okunamadı" : "ek bölümü bulunamadı") + '</div>';
        let h = '<div class="attr-ekler">📎 <b>Ekler (<span class="attr-ek-sayi">' + list.length + '</span>):</b>' + (list.length ? '' : ' ek yok') + (i.ekZamanAsimi ? ' <span style="color:#FBBF24;">⚠️ bir kısmı süre sınırı nedeniyle okunamadı</span>' : '');
        list.forEach(x => {
            h += '<div class="attr-ek-item" style="margin-left:10px;">• ' + escapeHtml(x.name) + (x.readable
                ? (x.points.length ? ' — <i>' + escapeHtml(x.points.join(" ")) + '</i>' : ' — (metin okundu)')
                : ' — <span style="color:#FBBF24;">⚠️ ' + escapeHtml(x.note) + '</span>') + '</div>';
            // v3.6.30: form eki → alan kontrol listesi + profil ile doldurulmuş kopya
            if (x.form && x.form.fields && x.form.fields.length) {
                const P = getOkulProfil();
                const rowsH = x.form.fields.map(fl => { const k = EBYS_EK.matchField(fl); const v = k && P[k]; return (v ? "☑ " : "☐ ") + escapeHtml(fl) + (v ? ' <span style="color:#86EFAC;">= ' + escapeHtml(String(v).slice(0, 40)) + '</span>' : ' <span style="color:#FBBF24;">(elle)</span>'); });
                h += '<div class="ek-form" style="margin:3px 0 4px 18px; padding:5px 7px; background:#16233F; border-left:3px solid #FBBF24; border-radius:6px;">📋 <b>' + (x.form.emptyForm === false ? "Tablo alanları" : "Doldurulacak form") + ' (' + x.form.fields.length + ' alan)' + (x.form.approx ? " — yaklaşık" : "") + ':</b><br>' + rowsH.join("<br>")
                    + (x.fid ? '<div style="margin-top:4px; display:flex; gap:4px;"><button class="ek-fill-btn" data-fid="' + escapeHtml(x.fid) + '" style="background:#065F46;color:#A7F3D0;border:none;border-radius:6px;padding:3px 7px;font-size:10.5px;cursor:pointer;">📗 Doldurulmuş kopyayı indir</button><button class="ek-profil-btn" style="background:#2D3D63;color:#FDE68A;border:none;border-radius:6px;padding:3px 7px;font-size:10.5px;cursor:pointer;">🏫 Okul bilgileri</button></div><div class="ek-missing" data-fid="' + escapeHtml(x.fid) + '" style="margin-top:3px; color:#FDE68A;"></div>' : '') + '</div>';
            }
        });
        return h + '</div>';
    }
    // NEW: nitelik raporu kartta gösterilir (tüm metinler kaçışlanır) — v3: son tarih / geri sayım
    function renderCardAttributes(d) {
        const card = findCardEl(d.docNo);
        const box = card && card.querySelector(".card-attr-box");
        if (!box || !d.info) return;
        const i = d.info;
        const dl = i.deadline, cd = dl && countdownOf(dl);
        box.innerHTML =
            '<div class="attr-tarih">📅 <b>Tarih:</b> ' + escapeHtml(i.tarih || "—") + '</div>' +
            '<div class="attr-gonderen">🏛️ <b>Gönderen:</b> ' + escapeHtml(i.gonderen || "—") + '</div>' +
            '<div class="attr-aciliyet">🚨 <b>Aciliyet:</b> <span style="font-weight:bold; color:' + (i.acil ? "#F87171" : "#86EFAC") + ';">' + escapeHtml(i.aciliyet) + '</span></div>' +
            (dl ? '<div class="attr-sontarih">⏳ <b>Son tarih:</b> ' + escapeHtml(dl.display) + (cd ? ' — <span style="font-weight:bold; color:' + cd.color + ';">' + escapeHtml(cd.plain) + '</span>' : '') + ' <span style="color:#A9B6CA;">(' + escapeHtml(dl.basis) + ')</span></div>'
                : (i.sonTarih ? '<div class="attr-sontarih">⏳ <b>Süre:</b> ' + escapeHtml(i.sonTarih) + ' <span style="color:#FBBF24;">(evrak tarihi okunamadığı için son gün hesaplanamadı)</span></div>' : '')) +
            '<div class="attr-talep">📝 <b>Talep Özeti:</b> ' + escapeHtml(i.talepOzeti || "—") + '</div>' +
            ekHtml(i) +
            (i.previewVerified ? (i.noVerified ? '' : '<div class="attr-warn2" style="color:#FBBF24;">⚠️ Önizleme metninde bu evrakın sayısı bulunamadı; bilgileri kontrol ediniz.</div>')
                : '<div class="attr-warn" style="color:#FBBF24;">⚠️ Önizleme metni okunamadı; liste satırındaki bilgiler kullanıldı.</div>');
        box.style.display = "block";
        const subj = card.querySelector(".card-subject");
        if (subj && i.previewVerified && i.noVerified && i.konu) subj.textContent = "📌 " + i.konu;
        card.style.borderColor = i.acil || (cd && cd.diff <= 2) ? "#F87171" : "rgba(0,240,255,0.2)";
        renderCountdown(d);
    }

    // NEW (v3): evrakı aç → gerçek önizlemeyi (pdf.js) ve ek tablosunu oku → nitelikleri kartta göster; son tarihi kalıcı kaydet
    async function analyzeCardDoc(d) {
        if (!(await openDocOrWarn(d))) return null;
        const r = await readDocForAnalysis(d);
        d.info = buildDocInfo(d, r.previewText, r.att, r);
        applyKimdeFromEbys(d, r.previewText || "");
        saveDeadline(d.docNo, d.info.deadline);
        takipOnDeadline(d); // NEW (v3.5): günlü evrak takibi (otomatik + Geri al / ya da yalnızca kart düğmesi)
        takipOnRecurring(d); // NEW (v3.6.4): tekrarlı (aylık/haftalık) yazı kuralı
        renderCardAttributes(d);
        return { previewText: r.previewText, att: r.att };
    }


    // NEW (v3.6.6): evrak metninden kişi (ad soyad) ve T.C. kimlik no — şablonlardaki (isim) / (tc) için. Yalnızca geçerli (sağlama doğru) 11 haneli numaralar alınır.
    function tcValid(s) {
        if (!/^[1-9]\d{10}$/.test(s)) return false;
        const d = s.split("").map(Number);
        if ((((d[0] + d[2] + d[4] + d[6] + d[8]) * 7 - (d[1] + d[3] + d[5] + d[7])) % 10 + 10) % 10 !== d[9]) return false;
        return d.slice(0, 10).reduce((x, y) => x + y, 0) % 10 === d[10];
    }
    const NAME_STOP = new Set(("t c tc turkiye cumhuriyeti milli egitim mudurlugu mudurlugune mudurlugunun mudurluğu okul okulu okulumuz lisesi ortaokulu ilkokulu anadolu mesleki teknik valiligi kaymakamligi sube subesi " +
        "kimlik no numarasi numarali sayin bay bayan ogretmen ogretmeni ogrenci ogrencisi mudur muduru yardimcisi personel memur vatandas sayi konu tarih ilgi hk hakkinda adi soyadi adres telefon ek evrak gizli gunlu ivedi " +
        "ocak subat mart nisan mayis haziran temmuz agustos eylul ekim kasim aralik ilce il merkez bakanlik bakanligi genel mudurlugu dairesi baskanligi saglik rapor raporu").split(" "));
    function nameRuns(str) {
        const out = [], words = String(str).match(/\p{Lu}[\p{L}'’]*|[^\p{L}'’]+/gu) || [];
        let cur = [];
        const flush = () => { if (cur.length >= 2 && cur.length <= 4) out.push(cur.join(" ")); cur = []; };
        for (let i = 0; i < words.length; i++) {
            const w = words[i];
            if (/^\p{Lu}/u.test(w)) { if (w.length >= 2 && !NAME_STOP.has(trFold(w))) cur.push(w); else flush(); }
            else if (/^[ \u00A0]+$/.test(w)) { /* boşluk: aynı koşuya devam */ }
            else flush();
        }
        flush();
        return out;
    }
    function extractKisiler(text) {
        const T = String(text || "").replace(/[\u00A0\t]+/g, " ").replace(/\r/g, "");
        const out = [], keyOf = n => trFold(n).replace(/\s+/g, " ");
        const addP = (isim, tc) => {
            if (!isim && !tc) return;
            const ex = out.find(p => (tc && p.tc === tc) || (isim && p.isim && keyOf(p.isim) === keyOf(isim)));
            if (ex) { if (!ex.isim && isim) ex.isim = isim; if (!ex.tc && tc) ex.tc = tc; return; }
            if (out.length < 6) out.push({ isim: isim || "", tc: tc || "" });
        };
        const re = /(?<!\d)\d{11}(?!\d)/g; let m;
        while ((m = re.exec(T))) {
            if (!tcValid(m[0])) continue;
            const before = T.slice(Math.max(0, m.index - 110), m.index).replace(/\s*\n\s*/g, " ").replace(/(?:[\s(,:;\-–.]*(?:T\.?\s?C\.?)?\s*(?:Kimlik)?\s*(?:No|Numaras[ıi]|Numaral[ıi])?\s*[:.\-–]?\s*\(?)$/i, "");
            const bn = nameRuns(before).pop();
            let nm = bn || "";
            if (!nm) { const after = T.slice(m.index + 11, m.index + 11 + 80).replace(/^[\s),;:\-–]+/, "").replace(/\s*\n\s*/g, " "); const first = nameRuns(after.split(/[.;,\n(]/)[0])[0]; nm = first || ""; }
            addP(nm, m[0]);
        }
        const lre = /(?:Ad[ıi]\s*(?:ve\s*)?Soyad[ıi]|Ad\s*Soyad|[İI]smi|Ad[ıi]\s*[-–]\s*Soyad[ıi])\s*[:：]\s*([^\n]{3,70})/gi;
        while ((m = lre.exec(T))) { const n = nameRuns(m[1].split(/\s{2,}|T\.?\s?C\.?|\d/)[0])[0]; if (n) addP(n, ""); }
        return out;
    }
    const PAREN_NAME_KEYS = new Set(["isim", "ad soyad", "adi soyadi", "adi ve soyadi", "isim soyisim", "ad soyisim", "isim ve soyisim"]);
    const PAREN_TC_KEYS = new Set(["tc", "t c", "tc no", "t c no", "tc kimlik no", "t c kimlik no", "tc kimlik numarasi", "t c kimlik numarasi", "kimlik no", "kimlik numarasi", "tckn", "tc kimlik"]);

    // NEW: şablon değişkenleri — {konu} {sayı}/{sayi} {tarih} {gönderen}/{gonderen} {bugün} {ekler} {ek sayısı} {ek özeti} {talep} + (v3) {kalan gün} {son tarih};
    // boş/bilinmeyen değişken "........" olur ve bildirilir
    function normalizeVarName(s) {
        return String(s).trim().replace(/\s+/g, " ").toLocaleLowerCase("tr-TR").replace(/ı/g, "i").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ş/g, "s").replace(/ö/g, "o").replace(/ç/g, "c");
    }
    function fillTemplateVars(tpl, info, opts) {
        tpl = applyClosingTokens(tpl, (opts && opts.dir) || resolveTplDir(opts && opts.name, info && info.gonderen)); // v3.6.30
        const today = new Date().toLocaleDateString("tr-TR", { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "Europe/Istanbul" });
        const ekler = info.ekler || [];
        const dl = info.deadline || null, cd = dl && countdownOf(dl); // NEW (v3)
        const kis0 = (info.kisiler && info.kisiler[0]) || {};
        const anyTc = (info.kisiler || []).map(p => p.tc).find(Boolean) || "", anyName = (info.kisiler || []).map(p => p.isim).find(Boolean) || "";
        const values = { isim: kis0.isim || anyName, "ad soyad": kis0.isim || anyName, tc: kis0.tc || anyTc, "tc no": kis0.tc || anyTc, "tc kimlik no": kis0.tc || anyTc, konu: info.konu, sayi: info.sayi, tarih: info.tarih, gonderen: info.gonderen, bugun: today,
            ekler: ekler.map(x => x.name).join(", "), "ek sayisi": info.ekBolumu || ekler.length ? String(ekler.length) : "", ekozeti: info.ekOzeti, "ek ozeti": info.ekOzeti, talep: info.talepOzeti,
            "kalan gun": cd ? cd.plain : "", "son tarih": dl ? dl.display : "" };
        // NEW (v3.6.37): okul profili yer tutucuları — {okul} {müdür} {müdür yardımcısı} {il} {ilçe} {kurum kodu} {adres} {telefon} {e-posta}
        try {
            const OP = getOkulProfil() || {};
            const ad = OP.okulAdi || OP.kurumAdi || "";
            const tur = OP.kurumTuru || "okul";
            // v3.6.47: kurum türüne göre "Okulumuzca / Müdürlüğümüzce" vb.
            const isMem = /mem|ilce|il\b|mudurluk|kaymakam|valilik/i.test(tur);
            const ca = isMem ? "Müdürlüğümüzce" : "Okulumuzca";
            const da = isMem ? "Müdürlüğümüzde" : "Okulumuzda";
            const un = isMem ? "Müdürlüğümüzün" : "Okulumuzun";
            const ua = isMem ? "Müdürlüğümüze" : "Okulumuza";
            const uu = isMem ? "Müdürlüğümüzü" : "Okulumuzu";
            const ud = isMem ? "Müdürlüğümüzdeki" : "Okulumuzdaki";
            const udn = isMem ? "Müdürlüğümüzden" : "Okulumuzdan";
            const ul = isMem ? "Müdürlüğümüzle" : "Okulumuzla";
            const amir = OP.amirUnvani || (isMem ? "İlçe Milli Eğitim Müdürü" : "Okul Müdürü");
            Object.assign(values, {
                okul: ad, "okul adi": ad, kurum: ad, "kurum adi": ad, kurumadi: ad,
                mudur: OP.mudur, "okul muduru": OP.mudur, "mudur yardimcisi": OP.mudurYrd, "mudur yrd": OP.mudurYrd,
                "amir adi": OP.mudur, amirunvani: amir, "amir unvani": amir,
                "ust birim": OP.ustBirim, ustbirim: OP.ustBirim,
                il: OP.il, ilce: OP.ilce, "kurum kodu": OP.kurumKodu, adres: OP.adres, telefon: OP.telefon,
                "e-posta": OP.eposta, eposta: OP.eposta, faks: OP.faks, web: OP.web, detsis: OP.detsis,
                kurumumuzca: ca, kurumumuzda: da, kurumumuzun: un, kurumumuza: ua, kurumumuzu: uu,
                kurumumuzdaki: ud, kurumumuzdan: udn, kurumumuzla: ul
            });
        } catch(e) {}
        values.eksayisi = values["ek sayisi"];
        values.kalangun = values["kalan gun"];
        values.sontarih = values["son tarih"];
        const labels = { konu: "konu", sayi: "sayı", tarih: "tarih", gonderen: "gönderen", bugun: "bugün", ekler: "ekler", "ek sayisi": "ek sayısı", eksayisi: "ek sayısı", ekozeti: "ek özeti", "ek ozeti": "ek özeti", talep: "talep",
            "kalan gun": "kalan gün", kalangun: "kalan gün", "son tarih": "son tarih", sontarih: "son tarih",
            okul: "okul adı (🏫 Okul Bilgileri)", "okul adi": "okul adı (🏫 Okul Bilgileri)", kurum: "okul adı (🏫 Okul Bilgileri)", mudur: "müdür adı (🏫 Okul Bilgileri)", "okul muduru": "müdür adı (🏫 Okul Bilgileri)", "mudur yardimcisi": "müdür yardımcısı (🏫 Okul Bilgileri)", "mudur yrd": "müdür yardımcısı (🏫 Okul Bilgileri)", il: "il (🏫 Okul Bilgileri)", ilce: "ilçe (🏫 Okul Bilgileri)" };
        const missing = [];
        const text = String(tpl).replace(/\{\s*([^{}\n]{1,30}?)\s*\}/g, (m, name) => {
            const key = normalizeVarName(name);
            const v = values[key];
            if (v !== undefined && v !== null && String(v).trim()) return String(v).trim();
            const label = labels[key] || name;
            if (!missing.includes(label)) missing.push(label);
            return TEMPLATE_BLANK;
        });
        // v3.6.6: parantezli yer tutucular — (isim) (ad soyad) / (tc) (tc no) (tc kimlik no) … yalnızca bu bilinen adlar; diğer parantezlere dokunulmaz
        const personName = kis0.isim || anyName, personTc = kis0.tc || anyTc;
        const text2 = text.replace(/\(\s*([^()\n]{1,30}?)\s*\)/g, (m, name) => {
            const key = normalizeVarName(name).replace(/[._\-\/]+/g, " ").replace(/\s+/g, " ").trim();
            const isN = PAREN_NAME_KEYS.has(key), isT = PAREN_TC_KEYS.has(key);
            if (!isN && !isT) return m;
            const v = isN ? personName : personTc;
            if (v) return v;
            const label = isN ? "isim" : "T.C. kimlik no";
            if (!missing.includes(label)) missing.push(label);
            return TEMPLATE_BLANK;
        });
        const notes = [];
        if ((info.kisiler || []).length > 1 && text2 !== text) notes.push("Evrakta " + info.kisiler.length + " kişi bulundu; şablona ilki yazıldı: " + (personName || "-"));
        return { text: text2, missing: missing, notes: notes };
    }

    function exportDataBackup() {
        const backupData = {
            templates: savedReplyTemplates,
            macros: savedMacros,
            staff: adminStaff,
            hiddenBuiltins: hiddenBuiltinTemplates, // NEW
            tplMeta: tplMeta, // NEW (v3.6): öğrenilen şablonların konu örnekleri
            tplDir: tplDirSettings, // v3.6.30: yazı yönü ayarları
            havaleRules: HC.rulesToFile(getRulesStore()), // NEW (v3.4)
            takip: getTakip(), takipAyarlar: getTakipSettings(), // NEW (v3.5): günlü evrak takip listesi ve bildirim ayarları
            telefonRehber: rehberYukle(), // v1.0.5
            exportDate: new Date().toLocaleDateString("tr-TR")
        }
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData, null, 2));
        const downloadAnchor = document.createElement('a');
        downloadAnchor.setAttribute("href", dataStr);
        downloadAnchor.setAttribute("download", `evrak_asistani_yedek_${Date.now()}.json`);
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        downloadAnchor.remove();
    }

    function importDataBackup(event) {
        const input = event.target;
        const file = input.files && input.files[0];
        if (!file) return;
        const fileReader = new FileReader();
        fileReader.onload = (e) => {
            input.value = ""; // FIX: aynı dosya tekrar seçilebilsin
            let parsed = null;
            try { parsed = JSON.parse(e.target.result); } catch(err) {}
            // FIX: önce TAMAMI doğrulanır; geçersizse hiçbir şey yazılmaz
            const valid = isPlainObject(parsed)
                && (parsed.templates !== undefined || parsed.macros !== undefined || parsed.staff !== undefined || parsed.havaleRules !== undefined || parsed.takip !== undefined)
                && (parsed.templates === undefined || isValidTemplates(parsed.templates))
                && (parsed.macros === undefined || isValidMacros(parsed.macros))
                && (parsed.staff === undefined || isValidStaff(parsed.staff))
                && (parsed.hiddenBuiltins === undefined || isValidNameList(parsed.hiddenBuiltins)) // NEW
                && (parsed.tplMeta === undefined || isPlainObject(parsed.tplMeta)) // NEW (v3.6)
                && (parsed.havaleRules === undefined || HC.isRulesFile(parsed.havaleRules)) // NEW (v3.4)
                && (parsed.takip === undefined || TK.isValidStore(parsed.takip)) && (parsed.takipAyarlar === undefined || TK.isValidSettings(parsed.takipAyarlar)) // NEW (v3.5)
                && (parsed.telefonRehber === undefined || Array.isArray(parsed.telefonRehber)); // v1.0.5
            if (!valid) { alert("❌ Geçersiz yedek dosyası!"); return; }
            try {
                if (parsed.templates) { savedReplyTemplates = parsed.templates; saveTemplatesToStorage(); }
                if (parsed.macros) { savedMacros = parsed.macros; saveMacrosToStorage(); }
                if (parsed.staff) { adminStaff = parsed.staff; saveStaffToStorage(); }
                if (parsed.telefonRehber) rehberKaydet(parsed.telefonRehber); // v1.0.5
                if (parsed.hiddenBuiltins) { hiddenBuiltinTemplates = parsed.hiddenBuiltins; saveHiddenBuiltinsToStorage(); } // NEW
                if (parsed.tplMeta) { tplMeta = parsed.tplMeta; extStoreSet(TPL_META_KEY, tplMeta); } // NEW (v3.6)
                if (parsed.tplDir && isValidTplDir(parsed.tplDir)) { tplDirSettings = parsed.tplDir; saveTplDir(); } // v3.6.30
                if (parsed.havaleRules) saveRulesStore(parsed.havaleRules); // NEW (v3.4)
                if (parsed.takipAyarlar) saveTakipSettings(parsed.takipAyarlar); // NEW (v3.5)
                if (parsed.takip) saveTakip(parsed.takip); // NEW (v3.5)
            } catch(err) {
                alert("❌ Geçersiz yedek dosyası!");
                return;
            }
            alert("✅ Yedek başarıyla yüklendi!");
            renderTplListModal(); renderStaffListModal(); // FIX: açık modallar da yenilenir
            renderPanelList();
            refreshTakipUi(); // NEW (v3.5)
        };
        fileReader.onerror = () => { input.value = ""; alert("❌ Geçersiz yedek dosyası!"); };
        fileReader.readAsText(file, "UTF-8");
    }

    // =========================================================================
    // 10. MODALLAR VE ARAYÜZ (UI)
    // =========================================================================
    function openTemplateManagerModal() {
        let modal = document.getElementById("ebys-template-modal");
        if (!modal) {
            modal = document.createElement("div");
            modal.id = "ebys-template-modal";
            modal.style.cssText = "position:fixed !important; top:50% !important; left:50% !important; transform:translate(-50%, -50%) !important; width:520px !important; background:#1F2D4D !important; border:2px solid #00F0FF !important; border-radius:20px !important; z-index:2147483647 !important; padding:18px !important; color:#E0E7FF !important; font-family:'Segoe UI', sans-serif !important;";
            modal.innerHTML = '<div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #2D3D63; padding-bottom:8px; margin-bottom:12px;"><div style="font-weight:800; color:#00F0FF; font-size:13px;">📝 RESMÎ ŞABLON KÜTÜPHANESİ</div><button id="btn-close-tpl-modal" style="background:none; border:none; color:#A9B6CA; font-size:16px; cursor:pointer;">✕</button></div><div id="tpl-list-box" style="max-height:260px; overflow-y:auto; display:flex; flex-direction:column; gap:6px; margin-bottom:12px;"></div><div style="background:#2D3D63; padding:10px; border-radius:12px;"><input type="text" id="new-tpl-title" placeholder="Yeni Şablon Başlığı" style="width:100%; padding:6px; background:#1F2D4D; border:1px solid #56709A; border-radius:6px; color:white; margin-bottom:6px; box-sizing:border-box;"><textarea id="new-tpl-body" placeholder="Metin içeriği... ({konu}, {sayı}, {tarih}, {gönderen}, {ekler}, {ek sayısı}, {ek özeti}; kapanış: {kapanış:bilgi} / {kapanış:gereg} / {kapanış:gerek})" style="width:100%; height:70px; padding:6px; background:#1F2D4D; border:1px solid #56709A; border-radius:6px; color:white; resize:none; box-sizing:border-box;"></textarea><button id="btn-save-tpl" style="margin-top:6px; background:#10B981; color:white; border:none; padding:6px 12px; border-radius:8px; font-weight:bold; cursor:pointer;">💾 Şablonu Kaydet</button></div>';
            document.body.appendChild(modal);
            document.getElementById("btn-close-tpl-modal").onclick = () => modal.style.display = "none";
            document.getElementById("btn-save-tpl").onclick = () => {
                const t = document.getElementById("new-tpl-title").value.trim();
                const b = document.getElementById("new-tpl-body").value.trim();
                if (t && b) {
                    savedReplyTemplates[t] = b; saveTemplatesToStorage();
                    document.getElementById("new-tpl-title").value = ""; document.getElementById("new-tpl-body").value = ""; // NEW
                    renderTplListModal();
                }
            };
        }
        renderTplListModal();
        modal.style.display = "block";
    }

    // NEW: kütüphane — "Kendi Şablonlarım" (eklenir/silinir) + "Hazır Şablonlar" (gizlenir/geri alınır)
    function renderTplListModal() {
        const box = document.getElementById("tpl-list-box");
        if (!box) return;
        box.innerHTML = "";
        const rowCss = "display:flex; justify-content:space-between; align-items:center; background:#2D3D63; padding:6px 10px; border-radius:8px; gap:6px;";
        const btnCss = (bg, fg) => "background:" + bg + "; color:" + fg + "; border:none; padding:2px 6px; border-radius:4px; font-size:10px; cursor:pointer; white-space:nowrap;";
        const head = (txt) => { const h = document.createElement("div"); h.style.cssText = "font-size:11px; font-weight:800; color:#38BDF8; margin-top:4px;"; h.textContent = txt; box.appendChild(h); };
        // v3.6.30: yazı yönü — kapanışı belirler (üst → "arz ederim", alt/eşit → "rica ederim")
        const DIR_LABELS = { oto: "Otomatik", ust: "Üst makama", alt: "Alt birime", esit: "Eşit birime" };
        const dirOpts = (cur, withDefault) => TPL_DIRS.map(d => '<option value="' + d + '"' + (d === cur ? " selected" : "") + '>' + (d === "oto" && withDefault ? "Yön: varsayılan" : DIR_LABELS[d]) + '</option>').join("");
        const dirBar = document.createElement("div");
        dirBar.style.cssText = "display:flex; align-items:center; gap:6px; font-size:10.5px; color:#BFDBFE; background:#16233F; padding:6px 8px; border-radius:8px;";
        dirBar.innerHTML = '<b>Yazı yönü:</b><select id="tpl-dir-global" style="background:#1F2D4D; color:white; border:1px solid #56709A; border-radius:6px; font-size:10.5px;">' + dirOpts(tplDirSettings.global || "oto", false) + '</select><span style="color:#94A3B8;">Otomatik: şablonun varsayılanı, yoksa gönderen (İl/İlçe MEM, Valilik… → üst; okul → eşit). Üst → "arz ederim", alt/eşit → "rica ederim".</span>';
        box.appendChild(dirBar);
        dirBar.querySelector("select").onchange = (e) => { tplDirSettings.global = e.target.value; saveTplDir(); };
        const addDirSel = (row, k) => {
            const sel = document.createElement("select");
            sel.className = "tpl-dir-sel"; sel.title = "Bu şablonun yazı yönü (kapanış)";
            sel.style.cssText = "background:#1F2D4D; color:#E2E8F0; border:1px solid #56709A; border-radius:4px; font-size:10px; max-width:96px;";
            const cur = (tplDirSettings.perTpl && tplDirSettings.perTpl[k]) || "oto";
            sel.innerHTML = dirOpts(cur, true);
            sel.onchange = () => { tplDirSettings.perTpl = tplDirSettings.perTpl || {}; if (sel.value === "oto") delete tplDirSettings.perTpl[k]; else tplDirSettings.perTpl[k] = sel.value; saveTplDir(); };
            const btns = row.lastElementChild; if (btns) btns.insertBefore(sel, btns.firstChild);
        };
        const userKeys = Object.keys(savedReplyTemplates);
        head("✍️ Kendi Şablonlarım (" + userKeys.length + ")");
        if (!userKeys.length) { const e = document.createElement("div"); e.style.cssText = "font-size:10.5px; color:#94A3B8; padding:2px 10px;"; e.textContent = "Henüz kendi şablonunuz yok; aşağıdan ekleyebilirsiniz."; box.appendChild(e); }
        userKeys.forEach(k => {
            const row = document.createElement("div");
            row.className = "tpl-user-row"; row.setAttribute("data-tname", k);
            row.style.cssText = rowCss;
            row.title = savedReplyTemplates[k];
            row.innerHTML = `<span style="font-size:11px; color:#E2E8F0;">📄 ${escapeHtml(k)}</span><span style="display:flex; gap:4px;"><button class="tpl-edit" style="${btnCss("#1E3A8A", "#93C5FD")}">✏️ Düzenle</button><button class="tpl-del" style="${btnCss("#7F1D1D", "#F87171")}">Sil</button></span>`;
            row.querySelector(".tpl-del").onclick = () => { delete savedReplyTemplates[k]; saveTemplatesToStorage(); renderTplListModal(); };
            row.querySelector(".tpl-edit").onclick = () => tplEditForm(row, k, savedReplyTemplates[k], false);
            addDirSel(row, k);
            box.appendChild(row);
        });
        const builtinKeys = Object.keys(BUILTIN_TEMPLATES);
        head("🏛️ Hazır Şablonlar (" + builtinKeys.length + ")");
        builtinKeys.forEach(k => {
            const hidden = hiddenBuiltinTemplates.includes(k);
            const shadowed = savedReplyTemplates[k] !== undefined;
            const row = document.createElement("div");
            row.className = "tpl-builtin-row" + (hidden ? " is-hidden" : ""); row.setAttribute("data-tname", k);
            row.style.cssText = rowCss + (hidden ? " opacity:0.45;" : "");
            row.title = BUILTIN_TEMPLATES[k];
            row.innerHTML = `<span style="font-size:11px; color:#E2E8F0;">🏛️ ${escapeHtml(k)}${shadowed ? ' <i style="color:#FBBF24;">(kendi sürümünüz kullanılıyor)</i>' : ""}</span><span style="display:flex; gap:4px;"><button class="tpl-edit" style="${btnCss("#1E3A8A", "#93C5FD")}">✏️ Düzenle</button><button class="tpl-hide" style="${hidden ? btnCss("#14532D", "#86EFAC") : btnCss("#4B5D7A", "#CBD5E1")}">${hidden ? "↩ Geri Al" : "🙈 Gizle"}</button></span>`;
            row.querySelector(".tpl-edit").onclick = () => tplEditForm(row, k, shadowed ? savedReplyTemplates[k] : BUILTIN_TEMPLATES[k], true);
            row.querySelector(".tpl-hide").onclick = () => {
                if (hidden) hiddenBuiltinTemplates = hiddenBuiltinTemplates.filter(x => x !== k);
                else hiddenBuiltinTemplates.push(k);
                saveHiddenBuiltinsToStorage();
                renderTplListModal();
            };
            addDirSel(row, k);
            box.appendChild(row);
        });
    }

    // NEW (v3.6.23): şablon düzenleme — satırın yerinde ad + metin formu (Kaydet / İptal), aynı depoya yazılır.
    // Hazır şablon düzenlenirse aynı adla "kendi sürümünüz" olarak saklanır (kendi sürümü silinince hazır metin geri gelir).
    // NEW (v3.6.24): kart menüsündeki ✏️ → kütüphaneyi açar ve o şablonun düzenleme formunu doğrudan gösterir
    function openTemplateEditor(name) {
        openTemplateManagerModal();
        const box = document.getElementById("tpl-list-box");
        if (!box) return;
        const row = Array.from(box.querySelectorAll(".tpl-user-row, .tpl-builtin-row")).find(r => r.getAttribute("data-tname") === name);
        if (!row) return;
        const isUser = row.classList.contains("tpl-user-row");
        if (!isUser && savedReplyTemplates[name] === undefined && BUILTIN_TEMPLATES[name] === undefined) return;
        tplEditForm(row, name, isUser ? savedReplyTemplates[name] : (savedReplyTemplates[name] !== undefined ? savedReplyTemplates[name] : BUILTIN_TEMPLATES[name]), !isUser);
        const f = box.querySelector(".tpl-edit-form"); if (f) try { f.scrollIntoView({ block: "center" }); } catch(e) {}
    }
    function tplEditForm(row, oldName, oldBody, isBuiltin) {
        const inCss = "width:100%; padding:6px; background:#1F2D4D; border:1px solid #56709A; border-radius:6px; color:white; box-sizing:border-box;";
        const f = document.createElement("div");
        f.className = "tpl-edit-form";
        f.style.cssText = "background:#2D3D63; padding:8px 10px; border-radius:8px; display:flex; flex-direction:column; gap:6px; border:1px solid #38BDF8;";
        f.innerHTML = `<input type="text" class="tpl-edit-title" style="${inCss}"${isBuiltin ? ' disabled title="Hazır şablonun adı değiştirilemez"' : ""}><textarea class="tpl-edit-body" style="${inCss} height:110px; resize:vertical;"></textarea><div style="display:flex; gap:6px; justify-content:flex-end; align-items:center;"><span class="tpl-edit-msg" style="font-size:10.5px; color:#F87171; margin-right:auto;"></span><button class="tpl-edit-cancel" style="background:#4B5D7A; color:#E2E8F0; border:none; padding:5px 10px; border-radius:6px; cursor:pointer;">İptal</button><button class="tpl-edit-save" style="background:#10B981; color:white; border:none; padding:5px 12px; border-radius:6px; font-weight:bold; cursor:pointer;">💾 Kaydet</button></div>`;
        f.querySelector(".tpl-edit-title").value = oldName;
        f.querySelector(".tpl-edit-body").value = oldBody || "";
        row.replaceWith(f);
        f.querySelector(".tpl-edit-body").focus();
        f.querySelector(".tpl-edit-cancel").onclick = () => renderTplListModal();
        f.querySelector(".tpl-edit-save").onclick = () => {
            const msg = f.querySelector(".tpl-edit-msg");
            const name = isBuiltin ? oldName : f.querySelector(".tpl-edit-title").value.trim();
            const body = f.querySelector(".tpl-edit-body").value.trim();
            if (!name || !body) { msg.textContent = "Ad ve metin boş olamaz."; return; }
            if (name !== oldName && (savedReplyTemplates[name] !== undefined || BUILTIN_TEMPLATES[name] !== undefined)) { msg.textContent = "Bu adla bir şablon zaten var."; return; }
            if (name !== oldName) {
                delete savedReplyTemplates[oldName];
                try { if (tplMeta && tplMeta[oldName]) { tplMeta[name] = tplMeta[oldName]; delete tplMeta[oldName]; extStoreSet(TPL_META_KEY, tplMeta); } } catch(e) {}
            }
            if (isBuiltin && body === BUILTIN_TEMPLATES[oldName]) delete savedReplyTemplates[oldName];
            else savedReplyTemplates[name] = body;
            saveTemplatesToStorage();
            renderTplListModal();
            try { showToast("✅ Şablon kaydedildi: " + name, "ok"); } catch(e) {}
        };
    }

    function openStaffManagerModal() {
        let modal = document.getElementById("ebys-staff-modal");
        if (!modal) {
            modal = document.createElement("div");
            modal.id = "ebys-staff-modal";
            modal.style.cssText = "position:fixed !important; top:50% !important; left:50% !important; transform:translate(-50%, -50%) !important; width:480px !important; background:#1F2D4D !important; border:2px solid #22C55E !important; border-radius:20px !important; z-index:2147483647 !important; padding:18px !important; color:#E0E7FF !important; font-family:'Segoe UI', sans-serif !important;";
            const inp = "flex:1; padding:6px; background:#1F2D4D; border:1px solid #56709A; border-radius:6px; color:white; min-width:0;";
            modal.innerHTML = '<div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #2D3D63; padding-bottom:8px; margin-bottom:12px;"><div style="font-weight:800; color:#22C55E; font-size:13px;">👥 İDARECİ KADROSU (WhatsApp)</div><button id="btn-close-staff-modal" style="background:none; border:none; color:#A9B6CA; font-size:16px; cursor:pointer;">✕</button></div>'
                + '<div id="staff-list-box" style="max-height:220px; overflow-y:auto; display:flex; flex-direction:column; gap:6px; margin-bottom:12px;"></div>'
                + '<div style="background:#2D3D63; padding:10px; border-radius:12px;"><div style="display:flex; gap:6px; margin-bottom:6px;"><input type="text" id="st-name" placeholder="Ad Soyad" style="' + inp + '"><input type="text" id="st-role" placeholder="Unvan" style="' + inp + '"></div>'
                + '<div style="display:flex; gap:6px;"><input type="text" id="st-phone" placeholder="Cep Telefonu (05XX XXX XX XX)" style="' + inp + '"><button id="btn-add-st" title="İdareci ekle" style="background:#16A34A; color:white; border:none; padding:6px 12px; border-radius:6px; font-weight:bold; cursor:pointer;">➕ Ekle</button></div>'
                + '<div style="font-size:10px; color:#A9B6CA; margin-top:6px;">Numara otomatik olarak 90XXXXXXXXXX biçimine çevrilir; yalnızca cep telefonu (5XX) kabul edilir.</div></div>';
            document.body.appendChild(modal);
            document.getElementById("btn-close-staff-modal").onclick = () => modal.style.display = "none";
            document.getElementById("btn-add-st").onclick = () => {
                const name = document.getElementById("st-name").value.trim();
                const role = document.getElementById("st-role").value.trim();
                const phoneRaw = document.getElementById("st-phone").value.trim();
                // NEW: doğrulama + normalizasyon + mükerrer kontrolü
                if (!name) { alert("❌ Ad Soyad giriniz."); return; }
                const phone = normalizeTrPhone(phoneRaw);
                if (!phone) { alert("❌ Geçersiz cep telefonu numarası: " + phoneRaw + "\nÖrnek: 05XX XXX XX XX"); return; }
                if (adminStaff.some(s => normalizeTrPhone(s.phone) === phone)) { alert("⚠️ Bu numara zaten kayıtlı: " + formatTrPhone(phone)); return; }
                adminStaff.push({ id: "st_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6), name, role: role || "Müdür Yardımcısı", phone });
                saveStaffToStorage();
                ["st-name", "st-role", "st-phone"].forEach(id => { document.getElementById(id).value = ""; });
                renderStaffListModal();
            };
        }
        renderStaffListModal();
        modal.style.display = "block";
    }

    function renderStaffListModal() {
        const box = document.getElementById("staff-list-box");
        if (!box) return;
        box.innerHTML = "";
        if (!adminStaff.length) {
            box.innerHTML = '<div id="staff-empty-msg" style="font-size:11px; color:#94A3B8; text-align:center; padding:12px; border:1px dashed #4B5D7A; border-radius:10px;">Henüz idareci eklenmedi. Aşağıdan ➕ ile ekleyebilirsiniz.</div>';
            return;
        }
        adminStaff.forEach((st) => {
            const row = document.createElement("div");
            row.className = "staff-row"; // NEW
            row.style.cssText = "display:flex; justify-content:space-between; align-items:center; background:#2D3D63; padding:6px 10px; border-radius:8px;";
            const np = normalizeTrPhone(st.phone);
            row.innerHTML = `<span style="font-size:11px; color:#E2E8F0;"><b>👤 ${escapeHtml(st.name)}</b> (${escapeHtml(st.role)})<br><span class="staff-phone" style="color:${np ? "#A9B6CA" : "#F87171"};">📱 ${escapeHtml(np ? formatTrPhone(np) : String(st.phone) + " (geçersiz numara)")}</span></span><button title="Kaldır" style="background:#7F1D1D; color:#F87171; border:none; padding:2px 8px; border-radius:4px; font-size:12px; cursor:pointer;">➖</button>`;
            // NEW: kimliğe göre silme (dizin kayması olmaz)
            row.querySelector("button").onclick = () => { adminStaff = adminStaff.filter(s => s !== st); saveStaffToStorage(); renderStaffListModal(); };
            box.appendChild(row);
        });
    }



    async function injectTemplateToDoc(docMeta, templateName, btnEl, preRes) { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        const rawTpl = getEffectiveTemplates()[templateName];
        if (!rawTpl) return;
        const origLabel = btnEl.innerText;
        btnEl.disabled = true;
        try {
            // FIX: evrak açılamazsa şablon YAZILMAZ; (v3) değişkenler gerçek önizleme + ek tablosu + satırdan doldurulur
            const res0 = preRes || await analyzeCardDoc(docMeta);
            if (!res0) return;
            const filled = fillTemplateVars(rawTpl, docMeta.info, { name: templateName, dir: resolveTplDir(templateName, (docMeta.info && docMeta.info.gonderen) || senderOfDoc(docMeta)) });
            const textPrepared = filled.text;
            const htmlPrepared = textPrepared.split("\n\n").map(p => '<p>' + escapeHtml(p).replace(/\n/g, "<br>") + '</p>').join("");
            const res = await runReplyFlow(htmlPrepared, textPrepared, { gonderen: senderOfDoc(docMeta), docNo: docMeta.docNo });
            reportReplyResult(res, filled.missing);
            if (filled.notes && filled.notes.length) showToast("ℹ️ " + filled.notes.join(" "), "warn");
            if (res.kind) {
                try { tplMetaRemember(templateName, (docMeta.info && docMeta.info.konu) || docMeta.subject || ""); } catch(e) {} // NEW (v3.6)
                btnEl.innerText = "✔️ Yazıldı!";
                setTimeout(() => { btnEl.innerText = origLabel; }, 2000);
            }
        } finally {
            btnEl.disabled = false;
        }
    }

    // NEW: Türkiye cep telefonu → 90XXXXXXXXXX (12 hane, 905… ; +90 / 0090 / 90 / 0 / 5XXXXXXXXX biçimleri kabul); geçersizse null
    function normalizeTrPhone(raw) {
        let p = String(raw == null ? "" : raw).replace(/\D/g, "");
        if (p.startsWith("00")) p = p.slice(2);
        if (p.length === 12 && p.startsWith("90")) p = p.slice(2);
        else if (p.length === 11 && p.startsWith("0")) p = p.slice(1);
        return /^5\d{9}$/.test(p) ? "90" + p : null;
    }
    function formatTrPhone(n) {
        const p = normalizeTrPhone(n);
        return p ? "+90 " + p.slice(2, 5) + " " + p.slice(5, 8) + " " + p.slice(8, 10) + " " + p.slice(10, 12) : String(n || "");
    }
    // FIX (v3.1): metin kısaltma UTF-16 vekil çiftlerini bölmez (bölünmüş emoji encodeURIComponent'te URIError atar)
    function safeTruncate(s, max) {
        const arr = Array.from(String(s == null ? "" : s));
        return arr.length > max ? arr.slice(0, max - 1).join("").trimEnd() + "…" : arr.join("");
    }
    // CHANGE (v3.2): WhatsApp mesajı EN AZ veriyle — yalnızca konu ve "EBYS'yi kontrol ediniz" bilgi notu.
    // Evrak no, gönderen, tarih, aciliyet, ekler, özet/içerik GÖNDERİLMEZ (veri minimizasyonu).
    // Son tarih biliniyorsa (Nitelik/Otonom analizi ya da kayıtlı son tarih) tarih + kalan gün eklenir; yoksa genel satır.
    function buildWhatsAppText(docMeta) {
        const konu = safeTruncate(String((docMeta.info && docMeta.info.konu) || docMeta.subject || "-").replace(/\s+/g, " ").trim() || "-", 300);
        const dl = getDeadline(docMeta), cd = dl && countdownOf(dl);
        const note = dl && dl.display
            ? `Lütfen ${dl.display} tarihine kadar EBYS'yi kontrol ediniz.${cd ? " (" + cd.label + ")" : ""}`
            : "Lütfen EBYS'yi kontrol ediniz.";
        return "📌 Bilgi Notu\nKonu: " + konu + "\n" + note;
    }
    // FIX (v3.1): api.whatsapp.com/send hem WhatsApp Web'i hem masaüstü uygulamasını doğrudan açar (wa.me ek bir yönlendirme yapar)
    function buildWhatsAppUrl(phone, text) {
        return "https://api.whatsapp.com/send?phone=" + phone + "&text=" + encodeURIComponent(text);
    }
    // FIX (v3.1): tıklama işleyicisinin İÇİNDE, eşzamanlı olarak tam URL ile yeni sekme açılır (boş sekme ön-açma yok, bekleme yok).
    // Tarayıcı açılır pencereyi engellerse kartta tıklanabilir bağlantı gösterilir ve mesaj panoya kopyalanır.
    function sendWhatsAppNotice(docMeta, adminObj) {
        const phone = normalizeTrPhone(adminObj.phone); // FIX: numara her gönderimde doğrulanır → 90XXXXXXXXXX
        if (!phone) {
            alert(`❌ "${adminObj.name}" için kayıtlı telefon numarası geçersiz: ${adminObj.phone}`);
            return false;
        }
        let text = "", url = "";
        try {
            text = buildWhatsAppText(docMeta);
            url = buildWhatsAppUrl(phone, text);
        } catch (e) {
            console.error("[Evrak Asistanı] WhatsApp mesajı hazırlanamadı:", e);
            alert("⚠️ WhatsApp mesajı hazırlanamadı.");
            return false;
        }
        let w = null;
        try { w = window.open(url, "_blank"); } catch (e) { w = null; }
        if (w) {
            try { w.opener = null; } catch (e) {}
            dbg("WhatsApp açıldı:", phone, "metin uzunluğu=" + text.length, "URL uzunluğu=" + url.length);
            return true;
        }
        copyToClipboard(text);
        const card = findCardEl(docMeta.docNo);
        const menu = card && card.querySelector(".card-wa-menu");
        if (menu) {
            menu.querySelectorAll(".wa-fallback-link").forEach(x => x.remove());
            const a = document.createElement("a");
            a.className = "wa-fallback-link";
            a.href = url; a.target = "_blank"; a.rel = "noopener noreferrer";
            a.textContent = "📲 WhatsApp'ı aç (" + adminObj.name + ")";
            a.style.cssText = "display:block; background:#15803D; color:white; text-decoration:none; padding:5px 8px; border-radius:6px; font-size:10.5px; font-weight:bold;";
            menu.appendChild(a);
            menu.style.display = "flex";
        }
        showToast("⚠️ Tarayıcı yeni sekmeyi engelledi. Karttaki \"WhatsApp'ı aç\" bağlantısına tıklayın (mesaj panoya da kopyalandı).", "warn");
        return false;
    }
    // FIX (v3.1): karttan idareciye gönder — artık analiz BEKLENMEZ; mevcut bilgilerle hemen gönderilir
    function sendDocToAdmin(d, adminObj) { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        return sendWhatsAppNotice(d, adminObj);
    }

    // ===================== v1.0.5: TELEFON REHBERİ + WhatsApp ile paylaş (otomatik gönderim YOK) =====================
    // Rehber yalnız chrome.storage.local'da (bu bilgisayar). WhatsApp mesajı otomatik gönderilmez; kullanıcı metni düzenler, wa.me açılır, Gönder'e kendisi basar.
    const REHBER_KEY = "ebys_telefon_rehber_v1";
    const ESKI_OKUL_ADI_SHA256 = "ca7fdc4d41f1cb847d88a99c5ca9b04c82587343fb421884fc4a8b0b9c61b54b"; // satış öncesi varsayılan adın özeti (ad pakette yok)
    function sha256hexUtf8(str) {
        function rrot(n, x) { return (n >>> x) | (n << (32 - x)); }
        const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
        const bytes = [];
        const s = String(str == null ? "" : str);
        for (let i = 0; i < s.length; i++) {
            let c = s.charCodeAt(i);
            if (c < 0x80) bytes.push(c);
            else if (c < 0x800) bytes.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f));
            else if (c >= 0xd800 && c <= 0xdbff) {
                const c2 = s.charCodeAt(++i);
                const u = 0x10000 + ((c & 0x3ff) << 10) + (c2 & 0x3ff);
                bytes.push(0xf0 | (u >> 18), 0x80 | ((u >> 12) & 0x3f), 0x80 | ((u >> 6) & 0x3f), 0x80 | (u & 0x3f));
            } else bytes.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f));
        }
        const bitLen = bytes.length * 8;
        bytes.push(0x80);
        while ((bytes.length % 64) !== 56) bytes.push(0);
        const hi = Math.floor(bitLen / 0x100000000), lo = bitLen >>> 0;
        bytes.push((hi >>> 24) & 255, (hi >>> 16) & 255, (hi >>> 8) & 255, hi & 255, (lo >>> 24) & 255, (lo >>> 16) & 255, (lo >>> 8) & 255, lo & 255);
        let H0 = 0x6a09e667, H1 = 0xbb67ae85, H2 = 0x3c6ef372, H3 = 0xa54ff53a, H4 = 0x510e527f, H5 = 0x9b05688c, H6 = 0x1f83d9ab, H7 = 0x5be0cd19;
        for (let i = 0; i < bytes.length; i += 64) {
            const W = new Array(64);
            for (let t = 0; t < 16; t++) W[t] = (bytes[i + t * 4] << 24) | (bytes[i + t * 4 + 1] << 16) | (bytes[i + t * 4 + 2] << 8) | bytes[i + t * 4 + 3];
            for (let t = 16; t < 64; t++) {
                const s0 = rrot(W[t - 15], 7) ^ rrot(W[t - 15], 18) ^ (W[t - 15] >>> 3);
                const s1 = rrot(W[t - 2], 17) ^ rrot(W[t - 2], 19) ^ (W[t - 2] >>> 10);
                W[t] = (W[t - 16] + s0 + W[t - 7] + s1) >>> 0;
            }
            let a = H0, b = H1, c = H2, d = H3, e = H4, f = H5, g = H6, h = H7;
            for (let t = 0; t < 64; t++) {
                const S1 = rrot(e, 6) ^ rrot(e, 11) ^ rrot(e, 25);
                const ch = (e & f) ^ (~e & g);
                const temp1 = (h + S1 + ch + K[t] + W[t]) >>> 0;
                const S0 = rrot(a, 2) ^ rrot(a, 13) ^ rrot(a, 22);
                const maj = (a & b) ^ (a & c) ^ (b & c);
                const temp2 = (S0 + maj) >>> 0;
                h = g; g = f; f = e; e = (d + temp1) >>> 0; d = c; c = b; b = a; a = (temp1 + temp2) >>> 0;
            }
            H0 = (H0 + a) >>> 0; H1 = (H1 + b) >>> 0; H2 = (H2 + c) >>> 0; H3 = (H3 + d) >>> 0;
            H4 = (H4 + e) >>> 0; H5 = (H5 + f) >>> 0; H6 = (H6 + g) >>> 0; H7 = (H7 + h) >>> 0;
        }
        const hex = n => ("00000000" + n.toString(16)).slice(-8);
        return hex(H0) + hex(H1) + hex(H2) + hex(H3) + hex(H4) + hex(H5) + hex(H6) + hex(H7);
    }
    function isEskiVarsayilanOkulAdi(ad) {
        return typeof ad === "string" && ad.length > 0 && sha256hexUtf8(ad) === ESKI_OKUL_ADI_SHA256;
    }
    function rehberAdNorm(s) {
        return String(s == null ? "" : s).toLocaleLowerCase("tr-TR").replace(/\s+/g, " ").trim();
    }
    function rehberKimdeEsle(liste, kimdeAdi) {
        const q = rehberAdNorm(kimdeAdi);
        if (!q) return null;
        const arr = Array.isArray(liste) ? liste : [];
        const exact = arr.filter(k => rehberAdNorm(k.ad || k.name) === q);
        if (exact.length) return exact[0];
        const part = arr.filter(k => { const n = rehberAdNorm(k.ad || k.name); return n && (n.includes(q) || q.includes(n)); });
        return part.length === 1 ? part[0] : null;
    }
    function rehberKisiDogrula(k) {
        if (!k || typeof k !== "object") return null;
        const ad = String(k.ad || k.name || "").trim().replace(/\s+/g, " ").slice(0, 80);
        const gorev = String(k.gorev || k.role || "").trim().replace(/\s+/g, " ").slice(0, 80);
        const telefon = normalizeTrPhone(k.telefon || k.phone);
        if (!ad || !telefon) return null;
        const id = String(k.id || "").trim();
        return { id: id, ad: ad, gorev: gorev, telefon: telefon };
    }
    function rehberListeDogrula(v) {
        if (!Array.isArray(v)) return [];
        const out = [], seen = Object.create(null);
        for (const k of v) {
            const d = rehberKisiDogrula(k);
            if (!d || seen[d.telefon]) continue;
            if (!d.id) d.id = "r" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8);
            seen[d.telefon] = 1;
            out.push(d);
        }
        return out;
    }
    function waTarihYaz(v) {
        const s = String(v == null ? "" : v).trim();
        if (!s) return "";
        if (/^\d{4}-\d{2}-\d{2}/.test(s) && typeof TK !== "undefined" && TK && typeof TK.fmtTr === "function") return TK.fmtTr(s) || s;
        return s;
    }
    function waPaylasMetin(evrak) {
        evrak = evrak || {};
        const no = String(evrak.evrakNo || evrak.docNo || evrak.sayi || "-").replace(/\s+/g, " ").trim() || "-";
        const tarih = waTarihYaz(evrak.tarih || evrak.kayitTarihi) || "-";
        let konu = String(evrak.konu || evrak.subject || "-").replace(/\s+/g, " ").trim() || "-";
        if (konu.length > 300) konu = konu.slice(0, 299).trimEnd() + "…";
        const son = waTarihYaz(evrak.sonTarih || evrak.son_tarih || evrak.miatTarihi);
        const kimde = String(evrak.kimde || "").replace(/\s+/g, " ").trim() || "Bilinmiyor";
        let t = "Evrak No: " + no + "\nTarih: " + tarih + "\nKonu: " + konu;
        if (son) t += "\nSon tarih: " + son;
        t += "\nKimde: " + kimde + "\n\nBu evrakla ilgili bilgi notudur. Lütfen EBYS'yi kontrol ediniz.";
        return t;
    }
    function waMeUrl(phone, text) {
        const p = normalizeTrPhone(phone);
        if (!p) return null;
        return "https://wa.me/" + p + "?text=" + encodeURIComponent(String(text == null ? "" : text));
    }
    function rehberYukle() { return rehberListeDogrula(extStoreGet(REHBER_KEY) || []); }
    function rehberKaydet(list) {
        const d = rehberListeDogrula(list);
        extStoreSet(REHBER_KEY, d);
        return d;
    }
    function rehberYeniId() { return "r" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8); }
    function waEvrakOf(src) {
        if (!src || typeof src !== "object") return { evrakNo: "", tarih: "", konu: "", sonTarih: "", kimde: "" };
        const no = src.evrakNo || src.docNo || "";
        let son = src.sonTarih || src.miatTarihi || "";
        if (!son && typeof getDeadline === "function") { try { const dl = getDeadline(src); if (dl && (dl.display || dl.iso)) son = dl.display || dl.iso; } catch (e) {} }
        return { evrakNo: no, docNo: no, tarih: src.tarih || src.kayitTarihi || "", konu: src.konu || src.subject || "", sonTarih: son, kimde: src.kimde || "" };
    }
    function waPdfErisilebilirMi(evrak) {
        const no = evrak && String(evrak.evrakNo || evrak.docNo || "");
        try {
            if (typeof ozSon !== "undefined" && ozSon) {
                const aday = [ozSon.sayi].concat(ozSon.tumSayi || []).filter(Boolean).map(String);
                if (!no || aday.some(s => s === no || (no && String(s).endsWith(no.split("-").pop() || "____")))) return true;
            }
        } catch (e) {}
        try { if (typeof ozFrameKey === "function" && ozFrameKey()) return true; } catch (e) {}
        try {
            if (typeof EK_CACHE !== "undefined" && EK_CACHE && EK_CACHE.size) {
                for (const v of EK_CACHE.values()) {
                    if (!v) continue;
                    const nm = String(v.name || "");
                    if ((v.bytes || /\.pdf/i.test(nm)) && (!no || nm.indexOf(no) >= 0)) return true;
                }
            }
        } catch (e) {}
        try {
            const nodes = document.querySelectorAll("iframe.onizlemeFrame, embed[type*='pdf' i], object[type*='pdf' i], embed[src*='.pdf' i], object[data*='.pdf' i], a[href*='.pdf' i], a[download*='.pdf' i]");
            for (const el of nodes) {
                if (!el) continue;
                const u = el.getAttribute("src") || el.getAttribute("data") || el.getAttribute("href") || el.getAttribute("download") || "";
                if (u && (!no || u.indexOf(no) >= 0 || (el.innerText || "").indexOf(no) >= 0)) return true;
                if (el.tagName === "IFRAME" && el.classList.contains("onizlemeFrame") && el.offsetWidth > 0) return true;
            }
        } catch (e) {}
        return false;
    }
    async function waPdfGet(evrak) {
        const no = evrak && String(evrak.evrakNo || evrak.docNo || "evrak");
        const adYap = (konu) => ((no || "evrak").replace(/[^\w.-]+/g, "_") + (konu ? "_" + String(konu).replace(/[\\/:*?\"<>|\n\r\t]+/g, " ").replace(/\s+/g, "_").slice(0, 40) : "") + ".pdf").replace(/_+/g, "_");
        try {
            if (typeof bridgeCall === "function") {
                const r = await bridgeCall("pdfData", {}, 15000);
                if (r && r.ok && r.b64) {
                    const bin = atob(r.b64);
                    const a8 = new Uint8Array(bin.length);
                    for (let i = 0; i < bin.length; i++) a8[i] = bin.charCodeAt(i);
                    return { name: adYap(evrak && evrak.konu), bytes: a8 };
                }
            }
        } catch (e) {}
        try {
            if (typeof EK_CACHE !== "undefined" && EK_CACHE) {
                for (const v of EK_CACHE.values()) {
                    if (v && v.bytes && /\.pdf/i.test(v.name || "x.pdf")) return { name: v.name || adYap(), bytes: v.bytes };
                }
            }
        } catch (e) {}
        return null;
    }
    function waCanShareFile(file) {
        try { return !!(file && navigator.canShare && navigator.canShare({ files: [file] })); } catch (e) { return false; }
    }
    function openWaPaylas(src) {
        const evrak = waEvrakOf(src);
        const old = document.getElementById("ebys-wa-paylas"); if (old) { try { document.removeEventListener("keydown", old._esc, true); } catch (e) {} old.remove(); }
        const liste = rehberYukle();
        const esles = rehberKimdeEsle(liste, evrak.kimde);
        const host = document.createElement("div");
        host.id = "ebys-wa-paylas"; host.setAttribute("role", "dialog"); host.setAttribute("aria-modal", "true"); host.setAttribute("aria-label", "WhatsApp ile paylaş");
        host.style.cssText = "position:fixed !important; inset:0 !important; z-index:2147483647 !important; background:rgba(8,15,30,.62); display:flex; align-items:center; justify-content:center; padding:10px; font-family:'Segoe UI',sans-serif;";
        const inp = "width:100%; padding:6px 8px; background:#FFFFFF; border:1px solid #94A3B8; border-radius:7px; color:#0F172A; box-sizing:border-box; font:12px 'Segoe UI',sans-serif;";
        const btn = "border-radius:8px; padding:6px 10px; font-weight:700; cursor:pointer; font-size:11.5px; font-family:inherit;";
        const kisiHtml = liste.length
            ? liste.map(k => {
                const chk = esles && esles.id === k.id ? " checked" : "";
                return '<label class="wa-kisi" style="display:flex; gap:8px; align-items:flex-start; padding:5px 6px; border:1px solid #4B5D7A; border-radius:8px; background:#2D3D63; cursor:pointer;"><input type="radio" name="wa-hedef" value="' + escapeHtml(k.id) + '"' + chk + ' style="margin-top:3px;"><span><b style="color:#F8FAFC;">' + escapeHtml(k.ad) + '</b>' + (k.gorev ? ' <span style="color:#A9B6CA;">— ' + escapeHtml(k.gorev) + '</span>' : '') + '<div style="color:#86EFAC; font-size:10.5px;">' + escapeHtml(formatTrPhone(k.telefon)) + '</div></span></label>';
            }).join("")
            : '<div style="color:#FDE68A; font-size:11px;">Rehber boş. Aşağıya numara yazabilir veya Kurum Ayarları › Telefon Rehberi\'nden kişi ekleyebilirsiniz.</div>';
        const elleChk = esles ? "" : " checked";
        const pdfVar = waPdfErisilebilirMi(evrak);
        host.innerHTML = '<div class="wa-kutu" style="width:min(460px,94vw); max-height:92vh; overflow:auto; background:#1F2D4D; color:#E2E8F0; border:1.5px solid #22C55E; border-radius:14px; padding:14px; font:12px \'Segoe UI\',sans-serif; box-shadow:0 10px 40px rgba(0,0,0,.6); display:flex; flex-direction:column; gap:8px;">'
            + '<div style="display:flex; justify-content:space-between; align-items:center;"><b style="color:#86EFAC; font-size:13px;">💬 WhatsApp ile paylaş</b><button type="button" class="wa-kapat" style="background:none;border:1px solid #A9B6CA;color:#E2E8F0;border-radius:8px;padding:2px 10px;cursor:pointer;">✕</button></div>'
            + '<div style="font-size:10.5px; color:#CBD5E1; line-height:1.4;">Gönderim otomatik değildir. WhatsApp açılır; metni kontrol edip <b>Gönder</b>\'e siz basarsınız. Numaralar yalnız bu bilgisayarda tutulur.</div>'
            + '<div style="font-weight:700; color:#FDE68A;">Kişi seçin veya numara yazın</div>'
            + '<div class="wa-liste" style="display:flex; flex-direction:column; gap:5px; max-height:160px; overflow:auto;">' + kisiHtml + '</div>'
            + '<label class="wa-kisi" style="display:flex; gap:8px; align-items:center; padding:5px 6px; border:1px solid #4B5D7A; border-radius:8px; background:#2D3D63; cursor:pointer;"><input type="radio" name="wa-hedef" id="wa-elle" value="elle"' + elleChk + '><span style="flex:1; min-width:0;"><span style="color:#E2E8F0;">Başka numara</span><input type="text" id="wa-elle-no" placeholder="05XX XXX XX XX" style="' + inp + '; margin-top:4px;"></span></label>'
            + '<label style="display:block; font-weight:700; color:#FDE68A;">Mesaj <span style="font-weight:400; color:#94A3B8;">(göndermeden önce düzenleyebilirsiniz)</span><textarea id="wa-metin" rows="8" style="' + inp + '; margin-top:4px; min-height:120px; resize:vertical; font:12px ui-monospace,monospace;"></textarea></label>'
            + '<div class="wa-pdf-not" style="font-size:10.5px; color:#A9B6CA; line-height:1.4;">' + (pdfVar ? "Evrakın PDF'i bu sayfada erişilebilir görünüyor. WhatsApp bağlantıya dosya eklemez; indirip sohbete sürükleyin. Telefonda Paylaş menüsü kullanılabilir." : "Bu evrakın PDF'i şu an sayfada açık/erişilebilir değil; yalnız metin paylaşılır.") + '</div>'
            + '<div style="display:flex; gap:6px; flex-wrap:wrap;">'
            + '<button type="button" id="wa-ac" style="' + btn + ' flex:1; background:#15803D; color:#fff; border:none;">💬 WhatsApp\'ta aç</button>'
            + (pdfVar ? '<button type="button" id="wa-pdf" style="' + btn + ' background:#1F2D4D; color:#93C5FD; border:1px solid #60A5FA;">📄 PDF\'i indir</button>' : "")
            + (pdfVar ? '<button type="button" id="wa-share" style="' + btn + ' display:none; background:#1F2D4D; color:#FDE68A; border:1px solid #FBBF24;">📤 Paylaş</button>' : "")
            + '<button type="button" class="wa-kapat" style="' + btn + ' background:#2D3D63; color:#E2E8F0; border:1px solid #56709A;">Kapat</button></div>'
            + '<div id="wa-msg" style="font-size:10.5px; color:#A7F3D0; min-height:1em;"></div>'
            + '<div style="font-size:10px; color:#94A3B8;">Salt okunur: EBYS\'de kayıt, havale, imza veya paraf yapılmaz. © Eyüp ŞEKER</div></div>';
        document.body.appendChild(host);
        const $ = s => host.querySelector(s);
        const msg = t => { const el = $("#wa-msg"); if (el) el.textContent = t || ""; };
        $("#wa-metin").value = waPaylasMetin(evrak);
        const kapat = () => { try { document.removeEventListener("keydown", host._esc, true); } catch (e) {} host.remove(); };
        host._esc = ev => { if (ev.key === "Escape") { ev.stopPropagation(); kapat(); } };
        document.addEventListener("keydown", host._esc, true);
        host.onclick = ev => { if (ev.target === host) kapat(); };
        host.querySelectorAll(".wa-kapat").forEach(b => { b.onclick = kapat; });
        const elleNo = $("#wa-elle-no");
        if (elleNo) elleNo.addEventListener("focus", () => { const r = $("#wa-elle"); if (r) r.checked = true; });
        const hedefTelefon = () => {
            const sec = host.querySelector("input[name='wa-hedef']:checked");
            if (!sec || sec.value === "elle") return (elleNo && elleNo.value) || "";
            const k = liste.find(x => x.id === sec.value);
            return k ? k.telefon : "";
        };
        let sonDosya = null;
        const dosyaHazirla = async () => {
            const pdf = await waPdfGet(evrak);
            if (!pdf || !pdf.bytes) return null;
            try { return new File([pdf.bytes], pdf.name || "evrak.pdf", { type: "application/pdf" }); } catch (e) {
                try { return new Blob([pdf.bytes], { type: "application/pdf" }); } catch (x) { return null; }
            }
        };
        const pdfBtn = $("#wa-pdf"), shareBtn = $("#wa-share");
        if (shareBtn) {
            // Paylaş yalnızca canShare({files}) destekleniyorsa görünür (çoğunlukla mobil)
            (async () => {
                try {
                    const dummy = new File([new Uint8Array([0x25, 0x50, 0x44, 0x46])], "evrak.pdf", { type: "application/pdf" });
                    if (waCanShareFile(dummy)) shareBtn.style.display = "inline-block";
                } catch (e) {}
            })();
        }
        if (pdfBtn) pdfBtn.onclick = async ev => {
            ev.preventDefault(); ev.stopPropagation();
            pdfBtn.disabled = true; msg("⏳ PDF indiriliyor…");
            try {
                const pdf = await waPdfGet(evrak);
                if (!pdf || !pdf.bytes) { msg("📄 PDF bu sayfada alınamadı. Evrakı EBYS'de açıp önizleme geldikten sonra yeniden deneyin."); showToast("📄 PDF erişilemedi.", "warn"); return; }
                sonDosya = pdf;
                if (typeof takipDownload === "function") takipDownload(pdf.name || "evrak.pdf", pdf.bytes, "application/pdf");
                else {
                    const url = URL.createObjectURL(new Blob([pdf.bytes], { type: "application/pdf" }));
                    const a = document.createElement("a"); a.href = url; a.download = pdf.name || "evrak.pdf"; document.body.appendChild(a); a.click(); a.remove();
                    setTimeout(() => URL.revokeObjectURL(url), 30000);
                }
                msg("📄 PDF indirildi: " + (pdf.name || "evrak.pdf") + " — WhatsApp sohbetine sürükleyin.");
                showToast("📄 PDF indirildi. Sohbete sürükleyin.", "ok");
            } catch (e) { msg("📄 PDF indirilemedi."); showToast("📄 PDF indirilemedi.", "warn"); }
            finally { pdfBtn.disabled = false; }
        };
        if (shareBtn) shareBtn.onclick = async ev => {
            ev.preventDefault(); ev.stopPropagation();
            shareBtn.disabled = true; msg("⏳ Dosya hazırlanıyor…");
            try {
                let file = sonDosya && sonDosya.bytes ? new File([sonDosya.bytes], sonDosya.name || "evrak.pdf", { type: "application/pdf" }) : await dosyaHazirla();
                if (!file || !waCanShareFile(file)) { msg("Bu cihazda dosya paylaşımı desteklenmiyor. PDF'i indirip sohbete sürükleyin."); return; }
                await navigator.share({ files: [file], title: evrak.evrakNo || "Evrak", text: $("#wa-metin").value || "" });
                msg("📤 Paylaşım menüsü açıldı. Gönderimi siz onaylarsınız.");
            } catch (e) {
                if (e && e.name === "AbortError") msg("Paylaşım iptal edildi.");
                else { msg("Paylaşılamadı. PDF'i indirip sohbete sürükleyin."); showToast("📤 Paylaşılamadı.", "warn"); }
            } finally { shareBtn.disabled = false; }
        };
        $("#wa-ac").onclick = ev => {
            ev.preventDefault(); ev.stopPropagation();
            const phone = hedefTelefon();
            const norm = normalizeTrPhone(phone);
            if (!norm) { msg("⛔ Geçerli bir Türkiye cep numarası girin (05XX XXX XX XX)."); showToast("⛔ Geçersiz telefon numarası.", "warn"); return; }
            const text = $("#wa-metin").value;
            const url = waMeUrl(norm, text);
            if (!url) { msg("⛔ WhatsApp bağlantısı oluşturulamadı."); return; }
            let w = null;
            try { w = window.open(url, "_blank", "noopener,noreferrer"); } catch (e) { w = null; }
            if (w) { try { w.opener = null; } catch (e) {} msg("💬 WhatsApp açıldı. Gönderime siz basın."); showToast("💬 WhatsApp açıldı. Gönderime siz basın.", "ok"); return; }
            try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text); } catch (e) {}
            let a = host.querySelector(".wa-yedek-link");
            if (!a) { a = document.createElement("a"); a.className = "wa-yedek-link"; a.target = "_blank"; a.rel = "noopener noreferrer"; a.style.cssText = "display:block; margin-top:6px; background:#15803D; color:white; text-decoration:none; padding:6px 8px; border-radius:8px; font-size:11.5px; font-weight:bold; text-align:center;"; host.querySelector(".wa-kutu").appendChild(a); }
            a.href = url; a.textContent = "💬 WhatsApp'ı buradan aç";
            msg("⚠️ Tarayıcı yeni sekmeyi engelledi. Yukarıdaki bağlantıya tıklayın (metin panoya kopyalandı).");
            showToast("⚠️ Yeni sekme engellendi. Bağlantıya tıklayın.", "warn");
        };
        try { if (typeof temaTara === "function") temaTara(); } catch (e) {}
        return host;
    }
    function bindWaPaylasBtn(el, src) {
        if (!el) return;
        el.addEventListener("click", ev => { ev.preventDefault(); ev.stopPropagation(); openWaPaylas(src); });
    }
    // ===================== /v1.0.5 WhatsApp =====================

    // =========================================================================
    // 11. ANA KONTROL PANELİ (UI)
    // =========================================================================
    let isPanelOpen = false; // NEW: panel açık/kapalı durumu yeniden çizimlerde korunur
    let hasScanned = false;  // NEW: tarama yapıldıysa kartlar yeniden çizimde geri yüklenir
    function ensureSkin() { // NEW (v3.6.4): panel görünümü (yalnızca eklenti panelini etkiler)
        ensureSkin35(); if (document.getElementById("ebys-skin")) return;
        const st = document.createElement("style"); st.id = "ebys-skin";
        st.textContent = `#ebys-inbox-panel { box-shadow: -14px 0 44px rgba(0,0,0,.5), inset 0 0 0 1px rgba(0,240,255,.12) !important; backdrop-filter: blur(12px); }
#ebys-inbox-panel *, #ebys-inbox-panel *::before, #ebys-inbox-panel *::after { box-sizing: border-box; }
#ebys-inbox-panel button, #ebys-inbox-panel label { transition: transform .12s ease, filter .12s ease, box-shadow .12s ease, background .15s ease; }
#ebys-inbox-panel button:hover:not(:disabled) { filter: brightness(1.16); transform: translateY(-1px); box-shadow: 0 5px 14px rgba(0,0,0,.38); }
#ebys-inbox-panel button:active:not(:disabled) { transform: translateY(0); filter: brightness(.95); box-shadow: none; }
#ebys-inbox-panel button:disabled { opacity: .55; cursor: not-allowed !important; }
#ebys-inbox-panel ::-webkit-scrollbar { width: 7px; height: 7px; }
#ebys-inbox-panel ::-webkit-scrollbar-track { background: transparent; }
#ebys-inbox-panel ::-webkit-scrollbar-thumb { background: rgba(0,240,255,.32); border-radius: 8px; }
#ebys-inbox-panel ::-webkit-scrollbar-thumb:hover { background: rgba(0,240,255,.55); }
#ebys-inbox-panel .ebys-doc-card { border-radius: 14px !important; border: 1px solid rgba(148,163,184,.24) !important; box-shadow: 0 6px 16px rgba(0,0,0,.3); transition: border-color .15s ease, box-shadow .15s ease, transform .15s ease; }
#ebys-inbox-panel .ebys-doc-card:hover { border-color: rgba(0,240,255,.6) !important; box-shadow: 0 10px 24px rgba(0,0,0,.42); }
#ebys-inbox-panel #ebys-tabs { position: sticky; top: -12px; z-index: 5; margin: -12px -12px 0; padding: 12px 12px 8px; background: linear-gradient(180deg, rgba(18,30,58,1) 75%, rgba(18,30,58,0)); }
#ebys-inbox-panel .ebys-tab-btn { letter-spacing: .1px; }
#ebys-inbox-panel input[type=text], #ebys-inbox-panel input[type=number], #ebys-inbox-panel textarea, #ebys-inbox-panel select { outline: none; transition: border-color .15s ease, box-shadow .15s ease; }
#ebys-inbox-panel input:focus, #ebys-inbox-panel textarea:focus, #ebys-inbox-panel select:focus { border-color: #00F0FF !important; box-shadow: 0 0 0 2px rgba(0,240,255,.2); }
.ebys-tpl-menu-anim { animation: ebysFade .14s ease; }
@keyframes ebysFade { from { opacity: 0; transform: translateY(-3px); } to { opacity: 1; transform: none; } }
`;
        (document.head || document.documentElement).appendChild(st);
    }
    // ===================== v1.0.4: TEMA — Renkli (varsayılan, hiçbir şey değişmez) / Açık / Koyu =====================
    // Panel, ayrıntı/takvim penceresi ve bildirimler (toast) için. Seçim yalnız bu bilgisayarda (chrome.storage.local) saklanır.
    // Renkli tasarımın satır içi renkleri dokunulmadan kalır; Açık/Koyu seçilince bu öğelerin renkleri ton (hue) korunarak yeniden eşlenir,
    // yazı rengi arka planına göre en az 4,5:1 karşıtlığa getirilir. Süresi geçen kırmızı her temada kırmızı kalır ve okunur.
    const TEMA_KEY = "ebys_tema_v1";
    const TEMA_LISTE = [["renkli", "Renkli (varsayılan)"], ["acik", "Açık"], ["koyu", "Koyu"]];
    const TEMA_KOK_SEL = "#ebys-inbox-panel, #ebys-toggle-handle, #ebys-takip-detay, #ebys-toast, #ebys-takip-toast, #ebys-xlsx-offer, #ebys-privacy-modal, #ebys-diag-modal";
    const TEMA_PROPS = ["color", "background-color", "background-image", "border-top-color", "border-right-color", "border-bottom-color", "border-left-color", "outline-color", "box-shadow"];
    let temaAktif = "renkli", temaBodyEl = null, temaSheet = null;
    const temaKayit = new WeakMap(), temaGozlem = new WeakMap();
    const temaBodyObs = typeof MutationObserver === "function" ? new MutationObserver(() => { try { temaTara(); } catch (e) {} }) : null;

    function temaRenkOku(v) {
        v = String(v == null ? "" : v).trim().toLowerCase();
        if (!v || v === "none" || v === "initial" || v === "inherit") return null;
        if (v === "transparent") return { r: 0, g: 0, b: 0, a: 0 };
        if (v === "white") return { r: 255, g: 255, b: 255, a: 1 };
        if (v === "black") return { r: 0, g: 0, b: 0, a: 1 };
        let m = v.match(/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:[\s,/]+([\d.]+%?))?\s*\)$/);
        if (m) { const a = m[4] === undefined ? 1 : (/%$/.test(m[4]) ? parseFloat(m[4]) / 100 : parseFloat(m[4])); return { r: +m[1], g: +m[2], b: +m[3], a: a }; }
        m = v.match(/^#([0-9a-f]{3,8})$/);
        if (m) {
            let h = m[1]; if (h.length === 3 || h.length === 4) h = h.split("").map(x => x + x).join("");
            if (h.length !== 6 && h.length !== 8) return null;
            return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: h.length === 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1 };
        }
        return null;
    }
    function temaYaz(c) { const r = Math.round(c.r), g = Math.round(c.g), b = Math.round(c.b); return c.a >= 0.999 ? "rgb(" + r + ", " + g + ", " + b + ")" : "rgba(" + r + ", " + g + ", " + b + ", " + (Math.round(c.a * 1000) / 1000) + ")"; }
    function temaHsl(c) {
        const r = c.r / 255, g = c.g / 255, b = c.b / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
        let h = 0, s = 0;
        if (d > 0) { s = d / (1 - Math.abs(2 * l - 1)); h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h = (h * 60 + 360) % 360; }
        return { h: h, s: s, l: l, a: c.a };
    }
    function temaRgb(h, s, l, a) {
        s = Math.max(0, Math.min(1, s)); l = Math.max(0, Math.min(1, l));
        const k = n => (n + h / 30) % 12, A = s * Math.min(l, 1 - l), f = n => l - A * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
        return { r: f(0) * 255, g: f(8) * 255, b: f(4) * 255, a: a == null ? 1 : a };
    }
    function temaLum(c) { const f = x => { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); }
    function temaOran(a, b) { const x = temaLum(a), y = temaLum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
    function temaKarisim(fg, bg) { const a = fg.a == null ? 1 : fg.a; return { r: fg.r * a + bg.r * (1 - a), g: fg.g * a + bg.g * (1 - a), b: fg.b * a + bg.b * (1 - a), a: 1 }; }
    const temaKirmizi = h => (h.s > 0.3 && (h.h <= 14 || h.h >= 346));
    // arka plan türü: "acik" (açık yüzey), "vurgu" (doygun düğme/rozet), "perde" (yarı saydam karartma), "koyu" (koyu lacivert yüzey)
    function temaTur(c) { const h = temaHsl(c); if (c.a < 0.9 && h.l < 0.15) return "perde"; if (h.l > 0.62) return "acik"; if (h.s >= 0.6 && h.l >= 0.18) return "vurgu"; return "koyu"; }
    // arka plan rengini temaya göre eşle
    function temaBgEsle(c, tema) {
        const h = temaHsl(c), t = temaTur(c);
        if (t === "perde") return c;
        if (c.a < 0.5 && (tema === "acik" || t !== "vurgu")) return c; // ince saydam katmanlar olduğu gibi kalır
        if (tema === "acik") { if (t !== "koyu") return c; return temaRgb(h.h, Math.min(h.s, 0.5) * 0.5, Math.max(0.82, Math.min(0.99, 0.99 - 0.3 * h.l)), c.a); }
        if (t === "koyu") return temaRgb(h.h, h.s * 0.3, 0.075 + 0.55 * h.l, c.a);
        if (t === "vurgu") return temaRgb(h.h, h.s * (temaKirmizi(h) ? 0.85 : 0.6), h.l * 0.9, c.a);
        return temaRgb(h.h, 0.1, 0.2, c.a); // açık yüzey (ör. beyaz giriş kutusu) → koyu yüzey
    }
    // yazı rengi: bölge türü (özgün arka plan) + eşlenmiş arka plan bgT'ye göre, en az 4,5:1
    function temaYaziEsle(c, tur, bgT, tema) {
        const h = temaHsl(c); let l = h.l, s = h.s;
        if (tema === "acik") {
            if (tur !== "koyu") return c;
            if (l > 0.5) l = Math.min(1 - l, 0.42);
            let o = temaRgb(h.h, s, l, c.a), n = 0;
            while (temaOran(o, bgT) < 4.5 && n++ < 40) { l = Math.max(0, l - 0.02); o = temaRgb(h.h, s, l, c.a); }
            return o;
        }
        if (tur === "acik" && l < 0.5) l = 1 - l; // açık zeminde koyu yazı → koyu temada açık yazı
        l = Math.min(l, 0.88); s = s * (temaKirmizi(h) ? 0.9 : 0.55);
        let o = temaRgb(h.h, s, l, c.a), n = 0;
        while (temaOran(o, bgT) < 4.5 && n++ < 40) { l = Math.min(0.97, l + 0.02); o = temaRgb(h.h, s, l, c.a); }
        return o;
    }
    function temaKenarEsle(c, tur, tema) {
        const h = temaHsl(c);
        if (tema === "acik") { if (tur !== "koyu") return c; return temaRgb(h.h, h.s, Math.max(0.3, Math.min(0.8, 1 - h.l)), c.a); }
        if (tur === "acik") return temaRgb(h.h, h.s * 0.4, Math.max(0.25, 1 - h.l), c.a);
        return temaRgb(h.h, h.s * (temaKirmizi(h) ? 0.9 : 0.55), h.l, c.a);
    }
    const TEMA_RENK_RE = /rgba?\([^)]*\)|#[0-9a-fA-F]{3,8}\b/g;
    function temaMetinRenkleri(str) { const out = []; String(str || "").replace(TEMA_RENK_RE, m => { const c = temaRenkOku(m); if (c) out.push(c); return m; }); return out; }

    function temaUst(el) { // en yakın kayıtlı üst öğenin bölge türü + eşlenmiş arka planı
        for (let p = el.parentElement; p; p = p.parentElement) { const r = temaKayit.get(p); if (r && r.bgT) return { tur: r.tur, bgT: r.bgT }; }
        return { tur: "koyu", bgT: temaBgEsle({ r: 22, g: 34, b: 62, a: 1 }, temaAktif) };
    }
    function temaGeriAl(el) {
        const rec = temaKayit.get(el); if (!rec) return;
        TEMA_PROPS.forEach(p => {
            if (rec.themed[p] === undefined) return;
            if (el.style.getPropertyValue(p) !== rec.themed[p]) return; // sayfa kendisi değiştirmiş
            if (rec.orig[p] !== undefined) el.style.setProperty(p, rec.orig[p], rec.prio[p] || ""); else el.style.removeProperty(p);
        });
        temaKayit.delete(el);
    }
    // tek öğe: satır içi renkleri temaya göre eşler; arka plan değiştiyse true (alt öğeler yeniden işlenir)
    let temaSayac = { t: 0, n: 0 }, temaKilit = false;
    function temaEl(el) {
        if (!el || el.nodeType !== 1 || !el.style || /^(SCRIPT|STYLE)$/.test(el.tagName)) return false;
        { // emniyet: saniyede aşırı işlem (olası döngü) → tema gözlemcileri durdurulur, sayfa donmaz
            const now = Date.now();
            if (now - temaSayac.t > 1000) { temaSayac.t = now; temaSayac.n = 0; }
            if (++temaSayac.n > 20000 && !temaKilit) {
                temaKilit = true;
                try { console.warn("[Evrak Asistanı – Müdür Paketi] Tema: olası döngü, tema gözlemi durduruldu", el.id || el.className || el.tagName, el.getAttribute("style")); } catch (e) {}
                try { document.querySelectorAll(TEMA_KOK_SEL).forEach(k => { const o = temaGozlem.get(k); if (o) o.disconnect(); temaGozlem.delete(k); }); if (temaBodyObs) temaBodyObs.disconnect(); } catch (e) {}
            }
            if (temaKilit) return false;
        }
        let rec = temaKayit.get(el);
        if (temaAktif === "renkli") { if (rec) temaGeriAl(el); return false; }
        if (!rec) rec = { orig: {}, prio: {}, themed: {}, tur: "koyu", bgT: null };
        TEMA_PROPS.forEach(p => {
            const v = el.style.getPropertyValue(p);
            if (rec.themed[p] !== undefined && v === rec.themed[p]) return; // yazdığımız değer, değişmemiş
            delete rec.themed[p];
            if (v) { rec.orig[p] = v; rec.prio[p] = el.style.getPropertyPriority(p); } else { delete rec.orig[p]; delete rec.prio[p]; }
        });
        const hadSynth = rec.orig.color === undefined && rec.themed.color !== undefined; // yapay (miras) renk düzeltmesi yazmıştık
        const O = rec.orig, ust = temaUst(el), prevBg = rec.bgT ? temaYaz(rec.bgT) + rec.tur : "";
        let tur = ust.tur, bgT = ust.bgT;
        const yaz = (p, val) => { // yalnız değer farklıysa yaz; kaydı güncelle
            if (el.style.getPropertyValue(p) !== val) el.style.setProperty(p, val, rec.prio[p] || "");
            rec.themed[p] = el.style.getPropertyValue(p);
        };
        // --- arka plan (renk + gradyan) ---
        const bc = temaRenkOku(O["background-color"]), toks = temaMetinRenkleri(O["background-image"]);
        const rep = (bc && bc.a >= 0.5) ? bc : toks.find(c => c.a >= 0.5) || null;
        const fc = temaRenkOku(O.color);
        const esle = (c) => { // eşlenmiş arka plan (Açık'ta doygun düğmelerde yazıyla en az 4,5:1 olacak kadar koyulaştırılır)
            const m = temaBgEsle(c, temaAktif);
            if (!rep || !koyulat || temaTur(c) !== "vurgu") return m;
            const h = temaHsl(m); return temaRgb(h.h, h.s, h.l * koyulat, m.a);
        };
        let koyulat = 1;
        if (temaAktif === "acik" && rep && temaTur(rep) === "vurgu" && fc && fc.a >= 0.9 && Array.from(el.childNodes).some(n => n.nodeType === 3 && n.textContent.trim())) {
            const h0 = temaHsl(rep);
            while (temaOran(fc, temaRgb(h0.h, h0.s, h0.l * koyulat, 1)) < 4.5 && koyulat > 0.62) koyulat -= 0.04;
        }
        if (rep) { tur = temaTur(rep); bgT = temaKarisim(esle(rep), ust.bgT); }
        else if (bc && bc.a > 0) bgT = temaKarisim(esle(bc), ust.bgT);
        else if (toks.length) bgT = temaKarisim(esle(toks[0]), ust.bgT);
        if (O["background-color"] !== undefined && bc) yaz("background-color", temaYaz(esle(bc)));
        if (O["background-image"] !== undefined) yaz("background-image", O["background-image"].replace(TEMA_RENK_RE, m => { const c = temaRenkOku(m); return c ? temaYaz(esle(c)) : m; }));
        rec.tur = tur; rec.bgT = bgT;
        // --- yazı ---
        if (O.color !== undefined && fc) yaz("color", temaYaz(temaYaziEsle(fc, tur, bgT, temaAktif)));
        else {
            let want = null; // kendi arka planı + kendi yazısı var, rengi miras alıyor: karşıtlık yetmezse düzelt (üst öğenin rengine göre; döngü olmaz)
            if (rep && Array.from(el.childNodes).some(n => n.nodeType === 3 && n.textContent.trim()) && el.parentElement) {
                try {
                    const inh = temaRenkOku((el.ownerDocument.defaultView || window).getComputedStyle(el.parentElement).color);
                    if (inh && temaOran(inh, bgT) < 4.5) want = temaYaz(temaYaziEsle(inh, "acik", bgT, "koyu"));
                } catch (e) {}
            }
            if (want) yaz("color", want);
            else if (hadSynth) { if (el.style.getPropertyValue("color") === rec.themed.color) el.style.removeProperty("color"); delete rec.themed.color; }
        }
        // --- kenar / çerçeve / dış çizgi ---
        ["border-top-color", "border-right-color", "border-bottom-color", "border-left-color", "outline-color"].forEach(p => {
            const c = O[p] !== undefined ? temaRenkOku(O[p]) : null;
            if (c) yaz(p, temaYaz(temaKenarEsle(c, tur, temaAktif)));
        });
        // --- gölge: açık temada daha hafif ---
        if (O["box-shadow"] !== undefined) {
            const sh = temaAktif === "acik" ? O["box-shadow"].replace(/rgba\(\s*0,\s*0,\s*0,\s*([\d.]+)\s*\)/g, (m, a) => "rgba(15, 23, 42, " + Math.round(parseFloat(a) * 0.4 * 100) / 100 + ")") : O["box-shadow"];
            yaz("box-shadow", sh);
        }
        temaKayit.set(el, rec);
        return prevBg !== (temaYaz(rec.bgT) + rec.tur);
    }
    function temaAgac(kok) { // kök + torunlar, belge sırasıyla
        if (!kok || kok.nodeType !== 1) return;
        const ch = temaEl(kok);
        kok.querySelectorAll("[style]").forEach(e => { temaEl(e); });
        return ch;
    }
    function temaCss() {
        const a = temaAktif; if (a === "renkli") return "";
        const S = temaBgEsle({ r: 18, g: 30, b: 58, a: 1 }, a), sc = "rgba(" + Math.round(S.r) + "," + Math.round(S.g) + "," + Math.round(S.b) + ",";
        const P = '#ebys-inbox-panel[data-ea-tema="' + a + '"]';
        return P + " { color-scheme:" + (a === "acik" ? "light" : "dark") + "; box-shadow:" + (a === "acik" ? "-10px 0 30px rgba(15,23,42,.22), inset 0 0 0 1px rgba(14,116,144,.25)" : "-12px 0 36px rgba(0,0,0,.45), inset 0 0 0 1px rgba(148,163,184,.12)") + " !important; }\n"
            + P + " #ebys-tabs { background: linear-gradient(180deg, " + sc + "1) 75%, " + sc + "0)) !important; }\n"
            + P + " .ebys-doc-card { border-color:" + (a === "acik" ? "rgba(71,85,105,.35)" : "rgba(148,163,184,.2)") + " !important; box-shadow:" + (a === "acik" ? "0 2px 8px rgba(15,23,42,.12)" : "0 4px 12px rgba(0,0,0,.28)") + "; }\n"
            + P + " .ebys-doc-card:hover { border-color:" + (a === "acik" ? "rgba(14,116,144,.7)" : "rgba(125,211,252,.55)") + " !important; }\n"
            + P + " ::-webkit-scrollbar-thumb { background:" + (a === "acik" ? "rgba(71,85,105,.35)" : "rgba(148,163,184,.32)") + "; }\n"
            + P + " select option { background:" + (a === "acik" ? "#FFFFFF" : "#1B2029") + "; color:" + (a === "acik" ? "#0F172A" : "#E5E7EB") + "; }\n";
    }
    function temaCssYaz() {
        const css = temaCss();
        try {
            if (typeof CSSStyleSheet === "function" && "adoptedStyleSheets" in document) {
                if (!temaSheet) temaSheet = new CSSStyleSheet();
                temaSheet.replaceSync(css);
                const list = Array.from(document.adoptedStyleSheets).filter(x => x !== temaSheet);
                document.adoptedStyleSheets = css ? list.concat([temaSheet]) : list;
                const old = document.getElementById("ebys-tema-css"); if (old) old.remove();
                return;
            }
        } catch (e) {}
        let st = document.getElementById("ebys-tema-css");
        if (!st) { st = document.createElement("style"); st.id = "ebys-tema-css"; (document.head || document.documentElement).appendChild(st); }
        st.textContent = css;
    }
    function temaIsle(kayitlar) {
        const seen = new Set();
        kayitlar.forEach(rc => {
            const olist = [];
            if (rc.type === "attributes") olist.push(rc.target);
            else rc.addedNodes.forEach(n => { if (n.nodeType === 1) olist.push(n); });
            olist.forEach(n => {
                if (seen.has(n)) return; seen.add(n);
                const ch = temaEl(n);
                if (rc.type === "childList" || ch) { try { n.querySelectorAll("[style]").forEach(e => { temaEl(e); }); } catch (e) {} }
            });
        });
    }
    function temaKokBagla(kok) {
        kok.setAttribute("data-ea-tema", temaAktif);
        temaAgac(kok);
        if (temaGozlem.has(kok) || typeof MutationObserver !== "function") return;
        const ob = new MutationObserver(recs => { if (temaAktif !== "renkli") { try { temaIsle(recs); } catch (e) {} } });
        ob.observe(kok, { subtree: true, childList: true, attributes: true, attributeFilter: ["style"] });
        temaGozlem.set(kok, ob);
    }
    function temaTara() { // görünen tema kökleri (panel, ayrıntı, bildirimler…) — yeni çıkanlara temayı uygular
        if (temaAktif === "renkli") return;
        document.querySelectorAll(TEMA_KOK_SEL).forEach(k => { if (!temaGozlem.has(k) || k.getAttribute("data-ea-tema") !== temaAktif) temaKokBagla(k); });
        if (temaBodyObs && document.body && temaBodyEl !== document.body) { temaBodyObs.disconnect(); temaBodyObs.observe(document.body, { childList: true }); temaBodyEl = document.body; }
    }
    function temaUygula(id) { // tüm köklere uygula (Renkli: eski haline döndür)
        temaAktif = TEMA_LISTE.some(t => t[0] === id) ? id : "renkli";
        document.querySelectorAll(TEMA_KOK_SEL).forEach(k => {
            temaKayit.has(k) && temaGeriAl(k); k.querySelectorAll("[style]").forEach(e => temaGeriAl(e));
            if (temaAktif === "renkli") k.removeAttribute("data-ea-tema");
        });
        temaCssYaz();
        if (temaAktif === "renkli") { if (temaBodyObs) temaBodyObs.disconnect(); temaBodyEl = null; return; }
        document.querySelectorAll(TEMA_KOK_SEL).forEach(k => temaKokBagla(k));
        temaTara();
    }
    function temaYukle() { const v = extStoreGet(TEMA_KEY); return v && TEMA_LISTE.some(t => t[0] === v.tema) ? v.tema : "renkli"; }
    function temaSec(id) {
        extStoreSet(TEMA_KEY, { tema: TEMA_LISTE.some(t => t[0] === id) ? id : "renkli" });
        temaUygula(id);
        const sel = document.getElementById("ebys-tema-sec"); if (sel && sel.value !== temaAktif) sel.value = temaAktif;
    }
    function temaBaslat() { // paneli kurarken: kayıtlı temayı yükle, seçiciyi bağla
        const sel = document.getElementById("ebys-tema-sec");
        const id = temaYukle();
        if (sel) { sel.value = id; sel.onchange = () => temaSec(sel.value); }
        temaUygula(id);
    }

    function createUI() {
        if (!document.body) return;
        // NEW: yarım kalmış parçaları temizle — panel/simge asla çiftlenmez
        document.querySelectorAll("#ebys-toggle-handle, #ebys-inbox-panel").forEach(el => el.remove());
        const toggleHandle = document.createElement("div");
        toggleHandle.id = "ebys-toggle-handle";
        toggleHandle.innerHTML = '<div style="font-size: 20px; line-height: 1;">🤖</div>'; // FIX (v3.1): yalnızca simge
        toggleHandle.title = "Evrak Asistanı — paneli aç/kapat";
        toggleHandle.setAttribute("role", "button");
        toggleHandle.setAttribute("aria-label", "Evrak Asistanı panelini aç/kapat");
        // FIX (v3.1): dikey ortada değil, ekranın ~%72'sinde (sağ alttaki tarayıcı öğelerinin üstünde)
        toggleHandle.style.cssText = "position: fixed !important; right: 0px !important; top: 72% !important; transform: translateY(-50%) !important; background: #1F2D4D !important; color: white !important; padding: 10px 8px !important; border-radius: 16px 0 0 16px !important; cursor: pointer !important; z-index: 2147483647 !important; border: 1.5px solid #00F0FF !important; border-right: none !important;";

        const panel = document.createElement("div");
        panel.id = "ebys-inbox-panel";
        panel.style.cssText = "position: fixed !important; right: -450px !important; top: 12px !important; width: 372px !important; height: calc(100vh - 24px) !important; background: linear-gradient(165deg, rgba(14,24,48,0.985), rgba(30,44,78,0.985)) !important; border: 1px solid rgba(0,240,255,0.6) !important; border-radius: 18px 0 0 18px !important; z-index: 2147483646 !important; font-family: 'Segoe UI', sans-serif !important; display: flex !important; flex-direction: column !important; transition: right 0.3s !important; color: #E0E7FF !important; overflow: hidden !important; font-size: 12px !important;";

        panel.innerHTML = `
            <div style="background: linear-gradient(90deg, rgba(0,240,255,0.16), rgba(45,61,99,0.9) 55%); padding: 11px 12px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(0,240,255,0.35);">
                <div style="font-weight: 800; color: #00F0FF; font-size: 13px; flex:1; min-width:0;">🤖 EVRAK ASİSTANI – MÜDÜR PAKETİ <span style="font-size:9px; color:#7DD3FC; font-weight:600;">v${EXT_VERSION}</span> <span id="ebys-count-badge" style="display:inline-block; margin-left:4px; background:#1F2D4D; border:1px solid #00F0FF; color:#00F0FF; padding:1px 6px; border-radius:8px; font-size:10px;">0 EVRAK</span></div><!-- FIX: eksik sayaç rozeti eklendi -->
                <div style="display:flex; gap:6px; flex-shrink:0;"><!-- FIX: rozet eklenince düğmeler sıkışmasın -->
                    <button id="btn-export-backup" title="Yedek İndir" style="background:#0284C7; color:white; border:none; padding:4px 8px; border-radius:8px; font-size:10px; cursor:pointer;">📤</button>
                    <label title="Yedek Yükle" style="background:#059669; color:white; padding:4px 8px; border-radius:8px; font-size:10px; cursor:pointer; display:flex; align-items:center;">📥<input type="file" id="import-file-input" style="display:none;" accept=".json"></label>
                    <button id="btn-close-slider" title="Paneli gizle" style="background:none; border:1px solid #00F0FF; color:#00F0FF; padding:4px 10px; border-radius:10px; font-weight:bold; cursor:pointer;">▶</button>
                </div>
            </div>
            <div style="padding: 12px; flex: 1; overflow-y: auto; display: flex; flex-direction: column; gap: 10px;">
                <div id="ebys-tabs" role="tablist" style="display:flex; gap:6px;"><!-- NEW (v3.3): sekmeler -->
                    <button id="ebys-tab-btn-gelen" class="ebys-tab-btn" data-tab="gelen" role="tab" style="flex:1; background:#56709A; color:#FFFFFF; border:1px solid #00F0FF; padding:7px 4px; border-radius:10px; font-weight:bold; cursor:pointer; font-size:11.5px; white-space:nowrap;">📥 Gelen</button>
                    <button id="ebys-tab-btn-takip" class="ebys-tab-btn" data-tab="takip" role="tab" style="flex:1; background:#2D3D63; color:#A9B6CA; border:1px solid #4B5D7A; padding:7px; border-radius:10px; font-weight:bold; cursor:pointer; font-size:11.5px;">📅 Günlü Takip</button>
                </div>
                <div id="ebys-tema-row" style="display:flex; align-items:center; gap:6px; color:#A9B6CA; font-size:10.5px;"><label for="ebys-tema-sec" style="font-weight:600; white-space:nowrap;">🎨 Tema</label><select id="ebys-tema-sec" title="Panel teması — bu bilgisayarda hatırlanır" style="flex:1; min-width:0; background:#2D3D63; color:#E2E8F0; border:1px solid #56709A; border-radius:8px; padding:3px 6px; font-size:11px; cursor:pointer;"><option value="renkli">Renkli (varsayılan)</option><option value="acik">Açık</option><option value="koyu">Koyu</option></select></div>
                <div id="ebys-setup-hint" style="display:none;"></div><!-- NEW (v3.4): kural yokken ilk kurulum ipucu -->
                <div style="display:flex; gap:6px; flex-wrap:wrap;">
                <button id="btn-diag" title="Sayfada bulunan menü/tablo/sayfalama/önizleme öğelerini raporlar (yazma yok)" style="flex:1; background:#2D3D63; color:#FBBF24; border:1px solid #FBBF24; padding:6px; border-radius:10px; font-weight:bold; cursor:pointer; font-size:11px;">🩺 Tanılama</button>
                <button id="btn-okul-profil" title="Kurum bilgileri ve Telefon Rehberi (yalnız bu bilgisayar)" style="flex:1; background:#2D3D63; color:#FDE68A; border:1px solid #FBBF24; padding:6px; border-radius:10px; font-weight:bold; cursor:pointer; font-size:11px;">🏫 Kurum Ayarları</button>
                <button id="btn-privacy" title="Gizlilik politikası ve tüm verileri silme" style="flex:1; background:#2D3D63; color:#C4B5FD; border:1px solid #A78BFA; padding:6px; border-radius:10px; font-weight:bold; cursor:pointer; font-size:11px;">🔒 Gizlilik / Verilerimi sil</button>
                </div>
                <div style="color:#93C5FD; font-size:10.5px; line-height:1.35; background:#13233F; border:1px solid #1E3A5F; border-radius:8px; padding:6px 8px;">Salt okunur Müdür Paketi: evrak tarama ve günlü takip. EBYS'de kayıt, cevap, havale, paraf veya imza yoktur.</div>
                <div id="ebys-tab-gelen" role="tabpanel" style="display:flex; flex-direction:column; gap:10px;">
                <button id="btn-scan-trigger" style="width:100%; background:linear-gradient(135deg, #2563EB, #1D4ED8); color:white; border:none; padding:10px; border-radius:12px; font-weight:800; cursor:pointer;">⚡ GELEN EVRAKLARI TARA</button>
                <label style="display:flex; gap:6px; align-items:center; color:#CBD5E1; font-size:10.5px; margin-top:-4px;"><input type="checkbox" id="chk-deep"> 🔍 Taramada evrak içini de oku (günlü evrakları eksiksiz bul)</label><!-- NEW (v3.6.4) -->
                <div id="ebys-cards-container" style="display:flex; flex-direction:column; gap:8px; margin-top:4px;">
                    <div style="text-align:center; color:#94A3B8; padding:30px; border:1px dashed #4B5D7A; border-radius:12px;">Tarama bekleniyor...</div>
                </div>
                </div>
                <div id="ebys-tab-havale" role="tabpanel" style="display:none;"></div>
                <div id="ebys-tab-takip" role="tabpanel" style="display:none; flex-direction:column; gap:8px;"><!-- NEW (v3.5): Günlü Takip -->
                    <div id="ebys-takip-container" style="display:flex; flex-direction:column; gap:8px;"></div>
                    <div id="ebys-tekrar-box" style="display:flex; flex-direction:column; gap:4px; font-size:11px; color:#CBD5E1;"></div><!-- NEW (v3.6.4) -->
                </div>
            </div>
        `;

        document.body.appendChild(toggleHandle);
        document.body.appendChild(panel);
        try { ensureSkin(); } catch(e) {}

        // NEW: açık/kapalı durumu modül düzeyinde tutulur (yeniden çizimde korunur)
        const applyOpenState = () => {
            panel.style.right = isPanelOpen ? "0px" : "-450px";
            toggleHandle.style.right = isPanelOpen ? "372px" : "0px";
        };
        const togglePanel = () => { isPanelOpen = !isPanelOpen; applyOpenState(); if (isPanelOpen) { refreshCountdowns(); } };
        if (isPanelOpen) applyOpenState();
        toggleHandle.onclick = togglePanel;
        document.getElementById("btn-close-slider").onclick = togglePanel;
        document.getElementById("btn-scan-trigger").onclick = async () => { if (await lisGate("Tarama")) return scanAllPagesSequentially(); };
        document.getElementById("btn-diag").onclick = () => { runDiagnostics(); };
        document.getElementById("btn-okul-profil").onclick = () => openOkulProfilModal();
        document.getElementById("btn-privacy").onclick = openPrivacyModal;
        try { temaBaslat(); } catch (e) { console.warn("[Evrak Asistanı – Müdür Paketi] Tema uygulanamadı:", e); } // v1.0.4
        bindTabButtons(); // v1.0.3: sekme düğmeleri (Gelen / Günlü Takip) — 1.0.0'da bindHavaleTab() çağrısı silinince bağlanmaz olmuştu
        bindTakipTab();
        { const cd = document.getElementById("chk-deep"); if (cd) { cd.checked = deepScanOn(); cd.onchange = () => extStoreSet(DEEP_KEY, { on: !!cd.checked }); } }
        document.getElementById("btn-export-backup").onclick = exportDataBackup;
        document.getElementById("import-file-input").onchange = importDataBackup;
        // NEW (v3): sayfa yenilendiyse son tarama listesi geri yüklenir (kartlar + kayıtlı son tarihler/geri sayımlar)
        let restoredAt = null;
        if (!hasScanned && !isScanningPages) {
            const last = loadLastScan();
            if (last && last.list.length) { scannedList = last.list; hasScanned = true; restoredAt = last.at; }
        }
        // NEW: önceki durumu geri yükle (rozet, kartlar, süren tarama)
        if (hasScanned) {
            const badge = document.getElementById("ebys-count-badge");
            if (badge) badge.innerText = scannedList.length + " EVRAK";
            renderPanelList();
            if (restoredAt) {
                const c = document.getElementById("ebys-cards-container");
                const n = document.createElement("div");
                n.id = "ebys-restored-notice";
                n.style.cssText = "background:#1E293B; color:#A9B6CA; border:1px dashed #475569; padding:6px 8px; border-radius:10px; font-size:10.5px;";
                n.textContent = "🕘 Son tarama (" + new Date(restoredAt).toLocaleString("tr-TR", { timeZone: "Europe/Istanbul", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) + ") geri yüklendi — güncel liste için yeniden tarayın.";
                if (c) c.prepend(n);
            }
        }
        if (isScanningPages) {
            const sb = document.getElementById("btn-scan-trigger");
            if (sb) { sb.disabled = true; sb.innerText = "⏳ TARANIYOR..."; }
        }
    }

    // NEW: kendi kendini onarma — Belgenet/PrimeFaces DOM'u yeniden çizer ya da <body>'yi değiştirirse panel ve robot simgesi geri gelir.
    // Tek MutationObserver (html + body, yalnızca childList) ve tek hafif zamanlayıcı; tekrar kurulmaz, sızıntı yapmaz.
    let healScheduled = false;
    let observedBody = null;
    let healIntervalId = null;
    const uiMissing = () => !document.getElementById("ebys-inbox-panel") || !document.getElementById("ebys-toggle-handle");
    const healObserver = new MutationObserver(() => { if (uiMissing() || document.body !== observedBody) scheduleHeal(); });
    function observeForHealing() {
        healObserver.disconnect();
        healObserver.observe(document.documentElement, { childList: true });
        if (document.body) healObserver.observe(document.body, { childList: true });
        observedBody = document.body;
    }
    function scheduleHeal() {
        if (healScheduled) return;
        healScheduled = true;
        setTimeout(healUI, 120);
    }
    function healUI() {
        healScheduled = false;
        if (!document.body) return;
        if (document.body !== observedBody) {
            observeForHealing();
            try { if (frameObserver) { frameObserver.disconnect(); frameObserver.observe(document.body, { childList: true, subtree: true }); } } catch(e) {}
            try { attachListenersToAllFrames(); } catch(e) {}
        }
        if (uiMissing()) createUI();
    }
    function startSelfHealing() {
        if (healIntervalId) return;
        observeForHealing();
        healIntervalId = setInterval(() => {
            if (uiMissing() || document.body !== observedBody) healUI();
            try { temaTara(); } catch (e) {} // v1.0.4: yeni çıkan pencere/bildirimlere tema
            if (istanbulTodayIso() !== lastCountdownDay) refreshCountdowns(); // NEW (v3): gün değişince geri sayım yenilenir
        }, 2000);
    }

    // =========================================================================
    // 12. EVRAK KARTLARI RENDER
    // =========================================================================
    // v1.0.3: kart meta satırı — Kimde Evrak Geçmişi'nden okunduysa "(Gereği)" ile gösterilir
    function cardMetaText(d) {
        return [d.tarih ? "📅 " + escapeHtml(d.tarih) : "", d.gonderen && d.gonderen !== "-" ? "🏛️ " + escapeHtml(d.gonderen) : "",
            d.kimde ? "👤 <b class=\"card-kimde\" style=\"color:#E2E8F0;\">" + escapeHtml(d.kimde) + "</b>" + (d.kimdeKaynak === "gecmis" ? " (Gereği)" : "") : "👤 <span class=\"card-kimde\">bilinmiyor</span>",
            kapatildiMetni(kimdeStore[d.docNo] && kimdeStore[d.docNo].kapatildi) ? "🔒 " + escapeHtml(kapatildiMetni(kimdeStore[d.docNo].kapatildi)) : "",
            d.ivedi ? '<b style="color:#F87171;">İVEDİ</b>' : "", d.miat > 0 ? "Miat: " + escapeHtml(String(d.miat)) + " gün" : ""].filter(Boolean).join(" · ");
    }
    function renderCardMeta(d) {
        const card = findCardEl(d.docNo), m = card && card.querySelector(".card-row-meta");
        if (m) m.innerHTML = cardMetaText(d);
    }
    function renderPanelList() {
        const container = document.getElementById("ebys-cards-container");
        if (!container) return;
        container.innerHTML = "";
        if (scannedList.length === 0) {
            container.innerHTML = '<div style="text-align:center; color:#EF4444; padding:15px; border:1px solid #EF4444; border-radius:10px;">Evrak bulunamadı.</div>';
            return;
        }

        lastCountdownDay = istanbulTodayIso();
        scannedList.forEach((d) => {
            kimdeApplyStored(d); // v1.0.3: Evrak Geçmişi'nden okunan Kimde
            const card = document.createElement("div");
            card.className = "ebys-doc-card"; // NEW
            card.setAttribute("data-docno", d.docNo); // NEW
            card.style.cssText = "background:#2D3D63; border:1px solid rgba(0,240,255,0.2); border-radius:12px; padding:10px; display:flex; flex-direction:column; gap:6px; cursor:pointer;";
            card.title = "Karta tıklayın: son tarih takvimi, evrak bilgisi ve kimde (Gereği)";
            card.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <span style="color:#00F0FF; font-weight:bold; font-size:11px;">📄 ${escapeHtml(d.docNo)}</span>
                    <button class="btn-direct-open" style="background:rgba(0,240,255,0.1); border:1px solid #00F0FF; color:#00F0FF; padding:2px 8px; border-radius:6px; font-size:10px; cursor:pointer;">AÇ ➔</button>
                </div>
                <div class="card-subject" style="color:#F8FAFC; font-size:11.5px; line-height:1.3;">📌 ${escapeHtml(d.subject)}</div>
                <div class="card-row-meta" style="color:#A9B6CA; font-size:10.5px; line-height:1.3;">${cardMetaText(d)}</div>
                <div class="card-countdown" style="display:none;"></div>
                <div style="display:flex; gap:4px; margin-top:4px; flex-wrap:wrap;">
                    <button class="btn-card-ozet" style="flex:1; background:#1F2D4D; color:#CBD5E1; border:1px solid #56709A; padding:5px; border-radius:8px; font-size:10px; cursor:pointer;">🔍 Nitelik</button>
                    <button class="btn-card-takvim" title="Son tarih takvimi, evrak bilgisi ve kimde (Gereği)" style="flex:1; background:#1F2D4D; color:#93C5FD; border:1px solid #60A5FA; padding:5px; border-radius:8px; font-size:10px; cursor:pointer;">📅 Takvim / Kimde</button>
                    <button class="btn-card-kimde" title="Evrak Geçmişi'nden Gereği İçin son havale edileni salt okunur oku" style="flex:1; background:#1F2D4D; color:#86EFAC; border:1px solid #22C55E; padding:5px; border-radius:8px; font-size:10px; cursor:pointer;">👤 Kimde oku</button>
                    <button class="btn-card-wapp" title="WhatsApp ile paylaş (otomatik gönderilmez)" style="flex:1; background:#1F2D4D; color:#86EFAC; border:1px solid #22C55E; padding:5px; border-radius:8px; font-size:10px; cursor:pointer;">💬 WhatsApp</button>
                </div>
                <div class="card-attr-box" style="display:none; background:#1F2D4D; padding:8px; border-radius:8px; font-size:10.5px; color:#CBD5E1; line-height:1.45;"></div>
                <div class="card-ozet-box" style="display:none; background:#1F2D4D; padding:8px; border-radius:8px; font-size:10.5px; color:#A9B6CA; margin-top:4px;"></div>
            `;

            // FIX (kart): evrak doğrudan açılır ve sonuç beklenir; bulunamazsa uyarı verilir, işlem yapılmaz
            card.querySelector(".btn-direct-open").onclick = async () => { if (await openDocOrWarn(d)) takipOnOpen(d); }; // CHANGE (v3.5.1): açılan evrakın son tarihi de okunur
            const ozetBox = card.querySelector(".card-ozet-box");
            // v1.0.3: karta (düğmeler ve açılır kutular dışında) tıklama + "📅 Takvim / Kimde" → ayrıntı penceresi; "👤 Kimde oku" → Evrak Geçmişi'nden salt okunur okuma
            card.addEventListener("click", (ev) => { const tg = ev.target; if (tg && tg.closest && tg.closest("button, input, select, textarea, a, label, .card-attr-box, .card-ozet-box, #ea-onizleme-ozet")) return; openDocDetay(d); });
            card.querySelector(".btn-card-takvim").onclick = (ev) => { ev.stopPropagation(); openDocDetay(d); };
            bindWaPaylasBtn(card.querySelector(".btn-card-wapp"), d);
            card.querySelector(".btn-card-kimde").onclick = async (ev) => {
                ev.stopPropagation();
                const b = ev.currentTarget; if (b.disabled) return;
                b.disabled = true; const t0 = b.textContent; b.textContent = "⏳ Okunuyor…";
                try {
                    showToast("⏳ Evrak EBYS'de açılıp Evrak Geçmişi okunuyor (salt okunur)…", "ok");
                    const res = await kimdeOkuEbys(d.docNo);
                    showToast((res.ok && res.kimde ? "👤 Kimde (Gereği): " + res.kimde + "\n" + kimdeSonucMetni(res) : "👤 Bilinmiyor — " + kimdeSonucMetni(res).replace(/^⚠️ /, "")) + (res.ok && res.kapatildi ? "\n🔒 " + kapatildiMetni(res.kapatildi) : ""), res.ok && res.kimde ? "ok" : "warn");
                } catch (e) { showToast("⚠️ Kimde okunamadı: " + ((e && e.message) || e), "error"); }
                finally { b.disabled = false; b.textContent = t0; }
            };
            card.querySelector(".btn-card-ozet").onclick = async () => {
                if (ozetBox.style.display === "block") { ozetBox.style.display = "none"; return; }
                // NEW: önizleme beklenir; nitelik raporu (tarih, gönderen, aciliyet, talep özeti) kartta gösterilir
                const res = await analyzeCardDoc(d);
                if (!res) return;
                const analysis = analyzeOfficialDocumentExpert(res.previewText, metaFromInfo(d));
                const box = (findCardEl(d.docNo) || card).querySelector(".card-ozet-box");
                box.innerHTML = `<b>Nitelik:</b> ${escapeHtml(analysis.nitelik)}<br><b>Özet:</b> ${escapeHtml(analysis.ozet)}`; // FIX: kaçış
                box.style.display = "block";
            };

            container.appendChild(card);
            if (d.info) renderCardAttributes(d); // NEW: yeniden çizimde nitelik raporu korunur
            else renderCountdown(d);              // NEW (v3): kayıtlı son tarih varsa geri sayım gösterilir
        });
    }

    // NEW (v3.2): Gizlilik / Verilerimi sil penceresi
    function openPrivacyModal() {
        document.querySelectorAll("#ebys-privacy-modal").forEach(el => el.remove());
        const m = document.createElement("div");
        m.id = "ebys-privacy-modal";
        m.setAttribute("role", "dialog");
        m.style.cssText = "position:fixed !important; inset:0 !important; background:rgba(0,0,0,0.5) !important; z-index:2147483647 !important; display:flex !important; align-items:center; justify-content:center; font-family:'Segoe UI', Tahoma, sans-serif;";
        m.innerHTML = '<div style="width:min(540px, 92vw); max-height:88vh; overflow-y:auto; background:#1F2D4D; color:#E2E8F0; border:1.5px solid #A78BFA; border-radius:16px; padding:18px; font-size:12.5px; line-height:1.5;">'
            + '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;"><div style="font-weight:800; color:#C4B5FD; font-size:15px;">🔒 Gizlilik / Verilerimi sil</div><button id="btn-privacy-close" style="background:none; border:1px solid #A9B6CA; color:#E2E8F0; border-radius:8px; padding:2px 10px; cursor:pointer;">✕</button></div>'
            + extPrivacyListHtml()
            + '<div style="margin-bottom:14px;">' + extPolicyLinkHtml() + '</div>'
            + '<button id="btn-delete-all-data" style="width:100%; background:#B91C1C; color:white; border:none; padding:9px; border-radius:10px; font-weight:800; cursor:pointer;">🗑️ Tüm verilerimi sil</button>'
            + '<div style="font-size:11px; color:#A9B6CA; margin-top:6px;">İdareci listesi, telefon rehberi, şablonlar, makrolar, son tarama listeleri, son tarihler, günlü evrak takip listesi ve bildirim ayarları, havale kişi listesi, favoriler ve havale kuralları, ayarlar ve onay kaydı bu bilgisayardan silinir; kurulu hatırlatma alarmları ve bildirimler de kaldırılır. Sayfa yenilenir ve onay yeniden sorulur.</div>'
            + "</div>";
        document.body.appendChild(m);
        m.onclick = (e) => { if (e.target === m) m.remove(); };
        m.querySelector("#btn-privacy-close").onclick = () => m.remove();
        m.querySelector("#btn-delete-all-data").onclick = async () => {
            if (!confirm("Tüm eklenti verileriniz (idareci listesi, telefon rehberi, şablonlar, makrolar, son tarama listeleri, son tarihler, günlü evrak takip listesi ve bildirim ayarları, havale kişi listesi, favoriler ve havale kuralları, ayarlar ve onay kaydı) bu bilgisayardan kalıcı olarak silinecek.\n\nEmin misiniz?")) return;
            await extDeleteAllData();
            await takipBg("ebys-takip-reset"); // NEW (v3.5): hatırlatma alarmları ve gösterilen bildirimler kaldırılır
            adminStaff = []; savedReplyTemplates = {}; hiddenBuiltinTemplates = []; savedMacros = {}; deadlineStore = {}; scannedList = [];
            havalePeople = { at: 0, people: [] }; havaleFav = []; havaleDone = {}; havaleList = []; havaleScanned = false; // NEW (v3.3)
            m.remove();
            alert("✅ Tüm verileriniz silindi. Sayfa yenilenecek.");
            try { location.reload(); } catch(e) {}
        };
    }

    // =========================================================================
    // NEW (v3.6): PARAFLADIKLARIMDAN ŞABLON ÖĞRENME
    // "İşlem Yaptıklarım > Parafladıklarım" listesindeki geçmiş cevap yazılarının metnini (yalnızca okur) bu bilgisayarda çözümler:
    //   Konu / İlgi / muhatap satırları ayrılır, cevap gövdesi alınır, evrak sayısı-tarihi-konusu {sayı}/{tarih}/{konu} değişkenine çevrilir,
    //   TC no / e-posta / IBAN gibi kişisel veriler silinir; birbirine benzeyen yazılar öbeklenir, her öbekten bir aday şablon çıkar.
    // Aday hiçbir zaman kendiliğinden eklenmez: kullanıcı adı ve metni düzenler, "Ekle" der. Eklenen şablonun konu örnekleri (tplMeta)
    // kartta ⭐ Önerilen şablon seçiminde kullanılır. Evrak açmaz, kapatmaz, havale etmez; yalnızca listeden satır seçip önizlemeyi okur.
    // =========================================================================
    const PARAF_MENU_TAG = "leftMenu.islemYaptiklarim.parafladiklarim"; // gerçek etiket doğrulanamadıysa menü metniyle de aranır
    const PARAF_DOCS_KEY = "ebys_paraf_docs_v1";       // okunan cevap yazıları (anahtar → {k: konu, b: genelleştirilmiş gövde, at})
    const PARAF_DISMISS_KEY = "ebys_paraf_dismiss_v1"; // "Yoksay" denen adayların imzaları
    const TPL_META_KEY = "ebys_tpl_meta_v1";           // şablon adı → {konular: [...], adet}
    const PARAF_MAX_STORED = 500;
    let parafDocs = loadJSON(PARAF_DOCS_KEY, {}, isPlainObject);
    let parafDismissed = loadJSON(PARAF_DISMISS_KEY, [], v => Array.isArray(v) && v.every(x => typeof x === "string"));
    let tplMeta = loadJSON(TPL_META_KEY, {}, isPlainObject);
    const parafState = { running: false, stop: false, msg: "", log: [] };

    const PARAF_STOP_RE = /^(Ek|EK|Ekler|EKLER)\s*[:\-]|^(Dağıtım|DAĞITIM|Gereği|GEREĞİ|Bilgi|BİLGİ)\s*:?\s*$|e-?imzalıdır|güvenli elektronik imza|Belge Doğrulama|Bu belge.{0,60}imzalanmıştır|https?:\/\/|www\.|^(Adres|Elektronik Ağ|e-?posta|Tel|Faks|Ayrıntılı bilgi|Bilgi için)\s*:/i;
    const PARAF_CLOSING_RE = /(arz|rica)\s+ederim\.?\s*$/i;
    const PARAF_CLOSING_START_RE = /(Bilgilerinizi|Bilgilerinize|Gereğini|Bilgi ve gereğini|Gereği için|Arz ederim|Rica ederim|Olurlarınıza|Tensiplerinize|Müsaadelerinize)/;
    const isCapsLine = l => { const letters = l.replace(/[^A-Za-zÇĞİÖŞÜçğıöşüÂÎÛâîû]/g, ""); return letters.length >= 3 && l.length <= 100 && l === l.toLocaleUpperCase("tr-TR"); };

    // Önizleme metninden "Konu" + cevap gövdesi
    function parafExtractBody(rawText) {
        const text = String(rawText || "").replace(/\r/g, "").replace(/[ \t\u00A0]+/g, " ");
        const lines = text.split("\n").map(l => l.trim());
        const ki = lines.findIndex(l => /^(Konu|KONU)\s*:/.test(l));
        if (ki < 0) return null;
        let konu = lines[ki].replace(/^(Konu|KONU)\s*:\s*/, "").trim();
        let i = ki + 1;
        // konu sonraki satıra taşmış olabilir (önceki satır dolu uzunluktaysa ya da devam satırı küçük harfle başlıyorsa)
        while (i < lines.length && lines[i] && konu.length < 260 && !/^(İlgi|İLGİ|Ilgi|Sayı|SAYI)\s*:/.test(lines[i]) && !isCapsLine(lines[i]) && (/^[a-zçğıöşü(\-–]/.test(lines[i]) || lines[i - 1].length > 55)) { konu += " " + lines[i]; i++; }
        // muhatap (BÜYÜK HARF / parantez) ve boş satırlar
        while (i < lines.length && (!lines[i] || isCapsLine(lines[i]) || /^\(.*\)$/.test(lines[i]))) i++;
        // İlgi bloğu
        if (i < lines.length && /^(İlgi|İLGİ|Ilgi)\s*:/.test(lines[i])) {
            i++;
            while (i < lines.length && lines[i] && (/^[a-zA-Z0-9]\)\s/.test(lines[i]) || /^[a-zçğıöşü(]/.test(lines[i]) || !/[.:;)]$/.test(lines[i - 1]))) i++;
        }
        const out = [];
        for (; i < lines.length; i++) {
            const l = lines[i];
            if (!l) continue;
            if (PARAF_STOP_RE.test(l)) break;
            out.push(l);
            if (PARAF_CLOSING_RE.test(l)) break; // kapanış cümlesinden sonrası imza bloğu
            if (out.join(" ").length > 2800) break;
        }
        if (!out.length) return null;
        const maxLen = Math.max.apply(null, out.map(x => x.length));
        let body = "";
        out.forEach((l, idx) => {
            body += (body ? " " : "") + l;
            const brk = /[.!?:]$/.test(l) && l.length < maxLen * 0.85 && idx < out.length - 1;
            if (brk) body += "\n\n";
        });
        body = body.replace(/ ?\n\n ?/g, "\n\n").trim();
        // kapanış cümlesi ayrı paragraf
        const cm = body.match(/(^|[.!?]\s+)((?:Bilgilerinizi|Bilgilerinize|Gereğini|Bilgi ve gereğini|Gereği için|Arz ederim|Rica ederim|Olurlarınıza|Tensiplerinize)[^.]{0,120}(?:arz|rica) ederim\.?)\s*$/);
        if (cm) { const at = body.length - cm[2].length; if (at > 0 && body.slice(Math.max(0, at - 2), at) !== "\n\n") body = body.slice(0, at).replace(/\s+$/, "") + "\n\n" + cm[2]; }
        return { konu: konu.trim(), body: body };
    }

    // Kişisel veri silme + değişkenleştirme
    function parafGeneralize(body, konu) {
        let t = String(body || "");
        const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        if (konu && konu.length >= 8) {
            try { t = t.replace(new RegExp(esc(konu).replace(/\s+/g, "\\s+"), "gi"), "{konu}"); } catch(e) {}
        }
        t = t.replace(/\bE-\d{6,10}-[\d.]+-\d+\b/g, "{sayı}").replace(/\bE-\d{6,10}[-\w.]*\w\b/g, "{sayı}");
        const D = "(?:\\d{1,2}[./]\\d{1,2}[./]\\d{4}|\\d{1,2}\\s+(?:" + TR_MONTHS + ")\\s+\\d{4})";
        t = t.replace(new RegExp(D + "(\\s+tarihli)", "gi"), "{tarih}$1").replace(new RegExp(D, "gi"), TEMPLATE_BLANK);
        t = t.replace(/\bTR\d{2}(?:\s?\d{4}){4,6}(?:\s?\d{1,2})?\b/gi, TEMPLATE_BLANK)           // IBAN
             .replace(/\b\d{11}\b/g, TEMPLATE_BLANK)                                                  // TC kimlik / telefon
             .replace(/\b0?\s?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2}\b/g, TEMPLATE_BLANK)       // telefon
             .replace(/[\w.+-]+@[\w-]+(\.[\w-]+)+/g, TEMPLATE_BLANK);                                 // e-posta
        t = t.replace(/\{sayı\}(\s*,?\s*\{sayı\})+/g, "{sayı}");
        return t.trim();
    }

    const parafTokens = s => new Set(trFold(String(s || "").replace(/\{[^}]*\}/g, " ")).split(/[^a-z0-9]+/).filter(w => w.length >= 3));
    function diceOf(a, b) { if (!a.size || !b.size) return 0; let n = 0; a.forEach(x => { if (b.has(x)) n++; }); return (2 * n) / (a.size + b.size); }
    const parafSig = text => trFold(text.replace(/\{[^}]*\}/g, " ")).split(/[^a-z0-9]+/).filter(Boolean).slice(0, 14).join("-");
    const personWordRe = w => /^[A-ZÇĞİÖŞÜ][a-zçğıöşü]+$|^[A-ZÇĞİÖŞÜ]{2,}$/.test(w);
    function parafIsPerson(s) { // "Ayşe YILMAZ", "Musa AŞ", "Aleyna ILDIRI ve Armina ILDIRI": son sözcük büyük harfli soyadı
        const parts = String(s).split(/\s+ve\s+|\s*,\s*|\s*&\s*/).map(x => x.trim()).filter(Boolean);
        return parts.length > 0 && parts.every(p => { const w = p.split(/\s+/); return w.length >= 2 && w.length <= 4 && w.every(personWordRe) && /^[A-ZÇĞİÖŞÜ]{2,}$/.test(w[w.length - 1]); });
    }
    function cleanKonuForName(k) {
        let t = String(k || "").replace(/E-\d[\w.-]+/g, "").replace(/\d{1,2}[./]\d{1,2}[./]\d{4}/g, "").replace(/\s+/g, " ").trim();
        t = t.replace(/\([^)]*$/, "").trim();
        const pm = t.match(/^(.*?)\s*\(([^)]+)\)\s*(.*)$/);
        if (pm) { const head = pm[1].trim(), inner = pm[2].trim(), tail = pm[3].trim(); if (parafIsPerson(inner)) t = (head + " " + tail).trim(); else if (parafIsPerson(head)) t = (inner + " " + tail).trim(); }
        else if (parafIsPerson(t)) t = "";
        return t.replace(/^[\s\-–:.,]+|[\s\-–:.,]+$/g, "");
    }

    // Kayıtlı yazılardan aday şablonlar (öbekleme)
    function parafBuildCandidates() {
        const items = Object.keys(parafDocs).map(k => ({ key: k, konu: parafDocs[k].k || "", body: parafDocs[k].b || "" })).filter(x => x.body.length >= 40 && /[A-Za-zÇĞİÖŞÜçğıöşü]{3}/.test(x.body));
        items.forEach(x => { x.tok = parafTokens(x.body); });
        const clusters = [];
        items.forEach(x => {
            let best = null, bestS = 0;
            clusters.forEach(c => { const s = diceOf(x.tok, c.rep.tok); if (s > bestS) { bestS = s; best = c; } });
            if (best && bestS >= 0.6) best.members.push(x); else clusters.push({ rep: x, members: [x] });
        });
        const existing = getEffectiveTemplates();
        const existingSigs = new Set(Object.values(existing).map(parafSig));
        const out = [];
        clusters.forEach(c => {
            let med = c.members[0], medS = -1;
            const cap = c.members.slice(0, 60);
            cap.forEach(a => { let s = 0; cap.forEach(b => { if (a !== b) s += diceOf(a.tok, b.tok); }); if (s > medS) { medS = s; med = a; } });
            const sig = parafSig(med.body);
            if (!sig || parafDismissed.includes(sig) || existingSigs.has(sig)) return;
            const konular = []; c.members.forEach(m => { const k = cleanKonuForName(m.konu); if (k && !konular.includes(k) && konular.length < 8) konular.push(k); });
            let name = konular.slice().sort((a, b) => a.length - b.length)[0] || med.body.split(/\s+/).slice(0, 6).join(" ");
            name = name.length > 56 ? name.slice(0, 56).replace(/\s+\S*$/, "") : name; // önek yok: şablon aramada kolay bulunsun
            out.push({ sig: sig, name: name, text: med.body, adet: c.members.length, konular: konular });
        });
        out.sort((a, b) => b.adet - a.adet);
        return out;
    }


    // NEW (v3.6.4): daha önce eklenmiş "Öğrenilen: …" adlarından önek ve kişi adı temizlenir (çakışırsa (2) eklenir)
    (function parafMigrateNames() {
        try {
            const olds = Object.keys(savedReplyTemplates).filter(k => /^Öğrenilen:\s*/i.test(k));
            if (!olds.length) return;
            olds.forEach(k => {
                let nn = cleanKonuForName(k.replace(/^Öğrenilen:\s*/i, "")) || k.replace(/^Öğrenilen:\s*/i, "").trim();
                nn = nn.length > 56 ? nn.slice(0, 56).replace(/\s+\S*$/, "") : nn;
                let cand = nn, i = 2;
                while (cand !== k && (savedReplyTemplates[cand] !== undefined || BUILTIN_TEMPLATES[cand] !== undefined)) cand = nn + " (" + i++ + ")";
                if (cand === k) return;
                savedReplyTemplates[cand] = savedReplyTemplates[k]; delete savedReplyTemplates[k];
                if (tplMeta[k]) { tplMeta[cand] = Object.assign({}, tplMeta[k], { ogr: true }); delete tplMeta[k]; } else tplMeta[cand] = { konular: [], adet: 0, ogr: true };
            });
            saveTemplatesToStorage(); extStoreSet(TPL_META_KEY, tplMeta);
        } catch(e) { console.warn("[Evrak Asistanı] Şablon adları düzeltilemedi:", e); }
    })();
    // ---- menü / liste
    function findParafMenuLink() { return findMenuLinkByTag(PARAF_MENU_TAG, /^\s*Parafla(dıklarım|diklarim)(\s|\(|$)/i, null); }
    function isOnParaf() {
        if (!getInboxRoot()) return false;
        const headerOk = /^Parafla/i.test(inboxHeaderText());
        const link = findParafMenuLink();
        return link ? (isMenuSelected(link) && headerOk) || headerOk : headerOk;
    }
    async function gotoParaf() {
        if (isOnParaf()) return true;
        const lv = await leaveEbysTransientUi();
        if (!lv.ok) { parafState.msg = lv.msg; return false; }
        for (let attempt = 0; attempt < 3; attempt++) {
            const link = findParafMenuLink();
            if (!link) { await sleep(800); continue; }
            await expandMenuFor(link);
            dbg("İşlem Yaptıklarım > Parafladıklarım menüsüne geçiliyor (", link.id || "-", ") deneme", attempt + 1);
            try { if (attempt === 0) link.click(); else userClick(link); } catch(e) {}
            if (await waitFor(() => isOnParaf() && !isAjaxBusy(), attempt === 0 ? 9000 : 7000, 200)) { await sleep(400); return true; }
        }
        parafState.msg = findParafMenuLink() ? "Parafladıklarım menüsüne tıklandı ama liste açılmadı; EBYS'de elle açıp tekrar deneyin." : "Sol menüde 'Parafladıklarım' bulunamadı (EBYS ana sayfasında olmalısınız; 🩺 Tanılama ile menüyü kontrol edin).";
        return false;
    }
    function parseParafRow(tr) {
        const full = (tr.textContent || "").replace(/\s+/g, " ").trim();
        const txt = (sel) => { const e = tr.querySelector(sel); return e ? (e.textContent || "").replace(/\s+/g, " ").trim() : ""; };
        const docNo = (full.match(/E-\d{6,10}-[\d.]+-\d+/) || full.match(/E-\d{6,10}[-\w.]+\w/) || [])[0] || "";
        const rk = tr.getAttribute("data-rk") || "";
        let subject = (txt("h3.ui-inbox-satir1") || txt(".rowTitleForInbox")).replace(/^Konu\s*:\s*/i, "");
        if (!subject) { const km = full.match(/Konu\s*:\s*(.{3,160}?)(?=\s+(Kişisel Arşive|Geldiği Yer|\d{2}\.\d{2}\.\d{4})|$)/); if (km) subject = km[1]; }
        if (!docNo && !rk && !subject) return null;
        return { docNo: docNo, rk: rk, subject: subject, key: docNo || (rk ? "RK-" + rk : "T-" + full.slice(0, 80)) };
    }
    function findParafRow(it) {
        const rows = getInboxRows();
        if (it.rk) { const r = rows.find(tr => tr.getAttribute("data-rk") === it.rk); if (r) return r; }
        return rows.find(tr => { const p = parseParafRow(tr); return p && p.key === it.key; }) || null;
    }
    async function parafOpenRow(it) {
        let tr = findParafRow(it);
        for (let attempt = 0; attempt < 2 && tr; attempt++) {
            const pf0 = getPreviewForm();
            let mutated = false;
            const mo = new MutationObserver(() => { mutated = true; });
            try { if (pf0) mo.observe(pf0, { childList: true, subtree: true }); } catch(e) {}
            clickRowLikeUser(tr, attempt);
            const ok = await waitFor(() => (mutated || getPreviewForm() !== pf0 || isRowSelected(tr)) && isDocPreviewShown() && !isAjaxBusy(), attempt ? 6000 : 9000, 150);
            mo.disconnect();
            if (ok) { await sleep(500); return true; }
            tr = findParafRow(it) || tr;
        }
        return false;
    }
    function parafLog(msg) { parafState.log.push(msg); if (parafState.log.length > 80) parafState.log.shift(); parafRender(); }

    async function parafRun(limit) { if (window.__EA_MUDUR_RO !== false) { try { showToast && showToast("⚠️ Müdür Paketi salt okunur: bu işlem kaldırıldı.", "warn"); } catch(e) {} return { ok: false, msg: "Müdür Paketi salt okunur: bu işlem kaldırıldı.", cancelled: true }; }
        if (parafState.running) return;
        parafState.running = true; parafState.stop = false; parafState.msg = ""; parafState.log = [];
        parafRender();
        let read = 0, skipped = 0, failed = 0, consecutiveFail = 0, lastText = "";
        try {
            if (!(await gotoParaf())) { parafLog("⚠️ " + (parafState.msg || "Parafladıklarım açılamadı.")); return; }
            await goFirstPage();
            const seenSig = new Set();
            for (let page = 0; page < MAX_SCAN_PAGES && !parafState.stop && read < limit; page++) {
                const rows = getInboxRows().map(parseParafRow).filter(Boolean);
                if (!rows.length) { parafLog("ℹ️ Bu sayfada satır bulunamadı."); break; }
                for (const it of rows) {
                    if (parafState.stop || read >= limit) break;
                    if (parafDocs[it.key]) { skipped++; continue; }
                    parafState.msg = "Okunuyor: " + (read + 1) + " / " + limit + " — " + (it.subject || it.key).slice(0, 60);
                    parafRender();
                    if (!(await parafOpenRow(it))) { failed++; consecutiveFail++; parafLog("⚠️ Açılamadı: " + (it.subject || it.key).slice(0, 50)); if (consecutiveFail >= 5) { parafLog("⛔ Art arda 5 evrak açılamadı; durduruldu. Parafladıklarım ekranında önizleme açılıyor mu kontrol edin (🩺 Tanılama)."); parafState.stop = true; } continue; }
                    let pv = null, ok = false;
                    for (let t = 0; t < 3 && !ok; t++) {
                        pv = await readRealPreview({ docNo: it.docNo || "" });
                        ok = !!pv.text && pv.text !== lastText && (!it.docNo || pv.text.includes(it.docNo) || pv.text.includes(String(it.docNo).split("-").pop()));
                        if (!ok) await sleep(700);
                    }
                    if (!ok || !pv.text) { failed++; consecutiveFail++; parafLog("⚠️ Metin okunamadı/eşleşmedi: " + (it.subject || it.key).slice(0, 50)); if (consecutiveFail >= 8) { parafState.stop = true; parafLog("⛔ Art arda 8 evrağın metni okunamadı; durduruldu (taranmış PDF olabilir)."); } continue; }
                    consecutiveFail = 0; lastText = pv.text;
                    const ex = parafExtractBody(pv.text);
                    if (!ex || ex.body.length < 40) { parafDocs[it.key] = { k: "", b: "", at: Date.now() }; skipped++; continue; } // gövdesi çıkmayan evrak bir daha okunmasın
                    parafDocs[it.key] = { k: ex.konu.slice(0, 200), b: parafGeneralize(ex.body, ex.konu), at: Date.now() };
                    read++;
                }
                // sınır ve kaydet
                const keys = Object.keys(parafDocs);
                if (keys.length > PARAF_MAX_STORED) keys.sort((a, b) => (parafDocs[a].at || 0) - (parafDocs[b].at || 0)).slice(0, keys.length - PARAF_MAX_STORED).forEach(k => delete parafDocs[k]);
                extStoreSet(PARAF_DOCS_KEY, parafDocs);
                if (parafState.stop || read >= limit) break;
                if (!hasNextPage()) break;
                const sig = tableSignature();
                if (seenSig.has(sig)) break;
                seenSig.add(sig);
                if (!(await goNextPage())) break;
            }
            parafLog("✅ Bitti: " + read + " yeni yazı okundu, " + skipped + " atlandı (daha önce okunmuş / gövdesiz), " + failed + " okunamadı.");
        } catch(e) {
            parafLog("❌ Hata: " + (e && e.message ? e.message : e));
        } finally {
            parafState.running = false; parafState.msg = "";
            extStoreSet(PARAF_DOCS_KEY, parafDocs);
            try { await gotoInbox(); } catch(e) {}
            parafRender();
        }
    }

    function parafAddCandidate(c, nameOverride, textOverride) {
        let name = (nameOverride || c.name).trim() || c.name;
        const taken = getEffectiveTemplates();
        let n = name, i = 2;
        while (taken[n] !== undefined) { n = name + " (" + i++ + ")"; }
        name = n;
        savedReplyTemplates[name] = (textOverride || c.text).trim();
        saveTemplatesToStorage();
        tplMeta[name] = { konular: c.konular.slice(0, 8), adet: c.adet, ogr: true }; // ogr: öğrenilmiş (listede 🎓)
        extStoreSet(TPL_META_KEY, tplMeta);
    }

    // ---- arayüz
    function openParafModal() {
        let m = document.getElementById("ebys-paraf-modal");
        if (!m) {
            m = document.createElement("div");
            m.id = "ebys-paraf-modal";
            m.setAttribute("role", "dialog");
            m.style.cssText = "position:fixed !important; inset:0 !important; background:rgba(0,0,0,0.5) !important; z-index:2147483647 !important; display:flex !important; align-items:center; justify-content:center; font-family:'Segoe UI', Tahoma, sans-serif;";
            m.innerHTML = '<div style="width:min(760px, 94vw); max-height:90vh; display:flex; flex-direction:column; background:#1F2D4D; color:#E2E8F0; border:1.5px solid #38BDF8; border-radius:16px; padding:16px; font-size:12px; line-height:1.45;">'
                + '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;"><div style="font-weight:800; color:#38BDF8; font-size:14px;">🎓 Parafladıklarımdan Şablon Öğren</div><button id="btn-paraf-close" style="background:none; border:1px solid #A9B6CA; color:#E2E8F0; border-radius:8px; padding:2px 10px; cursor:pointer;">✕</button></div>'
                + '<div style="color:#A9B6CA; font-size:11px; margin-bottom:8px;">İşlem Yaptıklarım &gt; Parafladıklarım listesindeki geçmiş yazılarınızın metnini bu bilgisayarda okur (evrak açmaz/kapatmaz/havale etmez), benzer cevapları öbekler ve aday şablon çıkarır. Evrak sayısı, tarih ve konu değişkene çevrilir; TC no, telefon, e-posta, IBAN silinir. <b>Hiçbir aday siz onaylamadan eklenmez</b>; eklemeden önce metni kontrol edin.</div>'
                + '<div style="display:flex; gap:6px; align-items:center; flex-wrap:wrap; margin-bottom:6px;"><label style="color:#CBD5E1;">En çok <input id="paraf-limit" type="number" min="10" max="500" value="150" style="width:64px; padding:3px; background:#13233F; border:1px solid #56709A; border-radius:6px; color:white;"> yeni yazı</label>'
                + '<button id="btn-paraf-start" style="background:#2563EB; color:white; border:none; padding:6px 12px; border-radius:8px; font-weight:bold; cursor:pointer;">▶ Taramayı başlat</button>'
                + '<button id="btn-paraf-stop" style="background:#B45309; color:white; border:none; padding:6px 12px; border-radius:8px; font-weight:bold; cursor:pointer;">⏹ Durdur</button>'
                + '<button id="btn-paraf-reset" title="Okunmuş yazıların kayıtlarını siler (şablonlarınız silinmez)" style="background:#475569; color:white; border:none; padding:6px 10px; border-radius:8px; cursor:pointer;">🗑️ Okunanları sıfırla</button></div>'
                + '<label style="display:flex; gap:6px; align-items:center; color:#CBD5E1; margin-bottom:6px;"><input type="checkbox" id="paraf-live"> <span><b>Çalışırken öğren:</b> Cevap Yaz penceresinde Kaydet/Parafla/İmzala/Gönder düğmesine bastığımda yazdığım cevabı da öğren (yalnızca bu bilgisayarda)</span></label>'
                + '<label style="display:flex; gap:6px; align-items:center; color:#CBD5E1; margin-bottom:6px;"><input type="checkbox" id="paraf-gerek"> <span><b>Gereği otomatik:</b> Cevap Yaz açılırken "Gereği" alanına evrakın geldiği yeri seç (alan boşsa ve tek eşleşme varsa)</span></label>'
                + '<div id="paraf-status" style="color:#FDE68A; min-height:16px; margin-bottom:4px;"></div>'
                + '<div id="paraf-log" style="max-height:70px; overflow-y:auto; background:#13233F; border-radius:8px; padding:4px 8px; color:#A9B6CA; font-size:10.5px; margin-bottom:6px;"></div>'
                + '<div style="font-weight:800; color:#86EFAC; margin-bottom:4px;">Aday şablonlar <span id="paraf-count"></span></div>'
                + '<div id="paraf-cands" style="overflow-y:auto; flex:1; display:flex; flex-direction:column; gap:8px;"></div>'
                + '<div style="display:flex; gap:6px; margin-top:8px; justify-content:flex-end;"><button id="btn-paraf-addsel" style="background:#16A34A; color:white; border:none; padding:7px 12px; border-radius:8px; font-weight:bold; cursor:pointer;">➕ Seçilenleri şablon olarak ekle</button><button id="btn-paraf-dismiss" style="background:#7F1D1D; color:#FCA5A5; border:none; padding:7px 12px; border-radius:8px; cursor:pointer;">🙈 Seçilenleri yoksay</button></div>'
                + '</div>';
            document.body.appendChild(m);
            m.addEventListener("click", e => { if (e.target === m) m.style.display = "none"; });
            m.querySelector("#paraf-live").onchange = (e) => { extStoreSet(LIVE_LEARN_KEY, { on: !!e.target.checked }); };
            m.querySelector("#paraf-gerek").onchange = (e) => { extStoreSet(GEREK_AUTO_KEY, { on: !!e.target.checked }); };
            m.querySelector("#btn-paraf-close").onclick = () => { m.style.display = "none"; };
            m.querySelector("#btn-paraf-start").onclick = () => { const v = Math.max(10, Math.min(500, parseInt(m.querySelector("#paraf-limit").value, 10) || 150)); parafRun(v); };
            m.querySelector("#btn-paraf-stop").onclick = () => { parafState.stop = true; parafLog("⏹ Durdurma istendi; geçerli evrak bitince duracak."); };
            m.querySelector("#btn-paraf-reset").onclick = () => { if (parafState.running) return; parafDocs = {}; extStoreSet(PARAF_DOCS_KEY, parafDocs); parafRender(); };
            const picked = () => Array.from(m.querySelectorAll(".paraf-cand")).filter(el => el.querySelector(".paraf-chk").checked);
            m.querySelector("#btn-paraf-addsel").onclick = () => {
                const cands = parafBuildCandidates();
                const sel = picked();
                if (!sel.length) { showToast("Önce eklenecek adayları işaretleyin.", "warn"); return; }
                let n = 0;
                sel.forEach(el => { const c = cands.find(x => x.sig === el.getAttribute("data-sig")); if (!c) return; parafAddCandidate(c, el.querySelector(".paraf-name").value, el.querySelector(".paraf-text").value); n++; });
                showToast("✔️ " + n + " şablon eklendi (📝 Şablonlar ve kartlardaki 📋 Şablon menüsünde görünür).", "ok");
                parafRender(); try { renderTplListModal(); } catch(e) {}
            };
            m.querySelector("#btn-paraf-dismiss").onclick = () => {
                const sel = picked();
                sel.forEach(el => { const s = el.getAttribute("data-sig"); if (s && !parafDismissed.includes(s)) parafDismissed.push(s); });
                extStoreSet(PARAF_DISMISS_KEY, parafDismissed.slice(-300));
                parafRender();
            };
        }
        m.style.display = "flex";
        m.querySelector("#paraf-live").checked = liveLearnOn();
        m.querySelector("#paraf-gerek").checked = gerekAutoOn();
        parafRender();
    }
    function parafRender() {
        const m = document.getElementById("ebys-paraf-modal");
        if (!m || m.style.display === "none") return;
        const st = m.querySelector("#paraf-status");
        st.textContent = parafState.running ? "⏳ " + (parafState.msg || "Çalışıyor...") : "Kayıtlı yazı: " + Object.keys(parafDocs).filter(k => parafDocs[k].b).length + " (en çok " + PARAF_MAX_STORED + " tutulur).";
        m.querySelector("#paraf-log").innerHTML = parafState.log.map(l => "<div>" + escapeHtml(l) + "</div>").join("") || '<div style="color:#64748B;">Henüz işlem yok.</div>';
        m.querySelector("#btn-paraf-start").disabled = parafState.running;
        m.querySelector("#btn-paraf-reset").disabled = parafState.running;
        const box = m.querySelector("#paraf-cands");
        // kullanıcı bir metni düzenlerken yeniden çizim yapma
        if (box.contains(document.activeElement) && /^(TEXTAREA|INPUT)$/.test(document.activeElement.tagName) && !parafState.running) return;
        const keep = {};
        box.querySelectorAll(".paraf-cand").forEach(el => { keep[el.getAttribute("data-sig")] = { chk: el.querySelector(".paraf-chk").checked, name: el.querySelector(".paraf-name").value, text: el.querySelector(".paraf-text").value }; });
        const cands = parafBuildCandidates();
        m.querySelector("#paraf-count").textContent = "(" + cands.length + ")";
        box.innerHTML = "";
        if (!cands.length) { box.innerHTML = '<div style="color:#94A3B8; border:1px dashed #4B5D7A; border-radius:10px; padding:14px; text-align:center;">Aday yok. ▶ Taramayı başlatın; yazılarınız okununca burada görünür.</div>'; return; }
        cands.forEach(c => {
            const k = keep[c.sig] || {};
            const el = document.createElement("div");
            el.className = "paraf-cand";
            el.setAttribute("data-sig", c.sig);
            el.style.cssText = "background:#2D3D63; border-radius:10px; padding:8px; display:flex; flex-direction:column; gap:4px;";
            el.innerHTML = '<div style="display:flex; gap:6px; align-items:center;"><input type="checkbox" class="paraf-chk"><input type="text" class="paraf-name" style="flex:1; padding:4px; background:#13233F; border:1px solid #56709A; border-radius:6px; color:white;"><span style="color:#86EFAC; white-space:nowrap;">' + c.adet + ' yazı</span></div>'
                + '<textarea class="paraf-text" rows="5" style="width:100%; box-sizing:border-box; padding:6px; background:#13233F; border:1px solid #56709A; border-radius:6px; color:white; resize:vertical;"></textarea>'
                + '<div style="color:#A9B6CA; font-size:10.5px;">Örnek konular: ' + escapeHtml(c.konular.slice(0, 3).join(" • ") || "—") + '</div>';
            el.querySelector(".paraf-chk").checked = !!k.chk;
            el.querySelector(".paraf-name").value = k.name !== undefined ? k.name : c.name;
            el.querySelector(".paraf-text").value = k.text !== undefined ? k.text : c.text;
            box.appendChild(el);
        });
    }

    // ---- NEW (v3.6): ÇALIŞIRKEN ÖĞREN — kullanıcı Cevap Yaz penceresinde Kaydet/Parafla/İmzala/Gönder gibi bir düğmeye bastığında
    // editördeki kendi yazdığı cevap (kişisel veriler silinmiş, değişkenleştirilmiş) öğrenme havuzuna eklenir; şablon kullanıldığında
    // şablonun konu örnekleri de güncellenir. Kapatılabilir (🎓 penceresindeki onay kutusu). Hiçbir şey gönderilmez, evrak üzerinde işlem yapılmaz.
    const LIVE_LEARN_KEY = "ebys_live_learn_v1";
    const liveLearnOn = () => { const v = extStoreGet(LIVE_LEARN_KEY); return !(v && v.on === false); };
    const LIVE_BTN_RE = /(Kaydet|Parafla|İmzala|Imzala|Onaya|Gönder|Gonder|Tamam)/i;
    let liveLastHash = "", liveLastAt = 0;
    function selectedRowSubject() {
        try { const tr = getInboxRows().find(isRowSelected); const p = tr && parseInboxRow(tr); return p && p.subject && p.subject !== "Konu belirtilmemiş" ? p.subject : ""; } catch(e) { return ""; }
    }
    function liveCapture() {
        if (!liveLearnOn() || !extHasConsent() || !isCevapWindowOpen()) return false;
        const t = findRealEbysEditor();
        const raw = t && t.el ? String(t.el.innerText || "").replace(/\r/g, "").replace(/\u00A0/g, " ").replace(/[ \t]+/g, " ") : "";
        const text = raw.split("\n").map(l => l.trim()).join("\n").replace(/\n{3,}/g, "\n\n").trim();
        if (text.length < 40 || !/[A-Za-zÇĞİÖŞÜçğıöşü]{3}/.test(text)) return false;
        const konu = selectedRowSubject();
        const body = parafGeneralize(text, konu);
        const sig = parafSig(body);
        const hash = sig + "|" + body.length;
        if (!sig || (hash === liveLastHash && Date.now() - liveLastAt < 300000)) return false;
        liveLastHash = hash; liveLastAt = Date.now();
        if (Object.values(getEffectiveTemplates()).some(x => parafSig(x) === sig)) return false; // değiştirilmemiş şablon: zaten kayıtlı
        parafDocs["CANLI-" + hash.slice(0, 60) + "-" + Date.now().toString(36)] = { k: konu.slice(0, 200), b: body, at: Date.now() };
        const keys = Object.keys(parafDocs);
        if (keys.length > PARAF_MAX_STORED) keys.sort((a, b) => (parafDocs[a].at || 0) - (parafDocs[b].at || 0)).slice(0, keys.length - PARAF_MAX_STORED).forEach(k => delete parafDocs[k]);
        extStoreSet(PARAF_DOCS_KEY, parafDocs);
        try { showToast("🎓 Yazdığınız cevap öğrenme havuzuna eklendi.", "ok"); } catch(e) {}
        parafRender();
        return true;
    }
    document.addEventListener("click", ev => {
        try {
            const b = ev.target && ev.target.closest ? ev.target.closest("button, a, .ui-button") : null;
            if (!b || isPanelEl(b) || !liveLearnOn()) return;
            const lab = (b.getAttribute("aria-label") || b.textContent || "").trim();
            if (lab.length > 40 || !LIVE_BTN_RE.test(lab)) return;
            liveCapture();
        } catch(e) {}
    }, true);
    // şablon kullanıldığında şablonun konu örneklerini genişlet (hazır şablonlar dahil)
    function tplMetaRemember(name, konu) {
        const k = cleanKonuForName(konu);
        if (!name || !k) return;
        const m0 = isPlainObject(tplMeta[name]) ? tplMeta[name] : { konular: [], adet: 0 };
        m0.konular = Array.isArray(m0.konular) ? m0.konular : [];
        if (!m0.konular.includes(k)) m0.konular = m0.konular.concat([k]).slice(-8);
        m0.adet = (m0.adet || 0) + 1;
        tplMeta[name] = m0;
        extStoreSet(TPL_META_KEY, tplMeta);
    }

    // ---- ⭐ kartta önerilen şablonlar: öğrenilen konu örnekleri + hazır şablon anahtar kelimeleri

    // =========================================================================
    // NEW (v3.6.4): TEKRARLI (AYLIK / HAFTALIK) YAZILAR — "her ayın 5'i, 10'u ve 20'sine kadar", "her ayın ilk/son iş günü", "her ay sonu",
    // "her pazartesi" gibi ifadeler tanınır. Kural kaydedilir; her kural için yaklaşan 2 tarih, mevcut günlü takip listesine (📅) ayrı kayıt olarak
    // eklenir (bildirim / takvim / Excel çıktıları aynen çalışır). Tarih hafta sonu ya da resmî tatile denk gelirse bir ÖNCEKİ iş günü esas alınır.
    // =========================================================================
    const TEKRAR_KEY = "ebys_tekrar_v1"; // { rules: [{ id, konu, gonderen, rule, ilk, aktif }] }
    const WEEKDAYS = { pazartesi: 1, sali: 2, carsamba: 3, persembe: 4, cuma: 5, cumartesi: 6, pazar: 0 };
    const WEEKDAY_NAMES = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"];
    const isValidRule = r => isPlainObject(r) && (Array.isArray(r.days) || Array.isArray(r.endMonths) || typeof r.special === "string" || Number.isInteger(r.weekday));
    const MONTH_DISP = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
    const isValidTekrar = v => isPlainObject(v) && Array.isArray(v.rules) && v.rules.every(x => isPlainObject(x) && typeof x.id === "string" && typeof x.konu === "string" && isValidRule(x.rule));
    let tekrarStore = loadJSON(TEKRAR_KEY, { rules: [] }, isValidTekrar);
    function saveTekrar() { extStoreSet(TEKRAR_KEY, tekrarStore); try { renderTekrarBox(); } catch(e) {} }

    function ruleKey(r) { if (Array.isArray(r.endMonths)) return "e:" + r.endMonths.join(",") + (r.followDay ? ":f" + r.followDay : ""); return r.special ? "s:" + r.special : Number.isInteger(r.weekday) ? "w:" + r.weekday : "d:" + (r.days || []).join(","); }
    const untilSuffix = r => (r && /^\d{4}-\d{2}-\d{2}$/.test(r.until || "") && fromIso(r.until)) ? " — " + fmtTrDate(fromIso(r.until)) + " tarihine kadar" : "";
    function ruleText(r) { return ruleTextBase(r) + untilSuffix(r); }
    function ruleTextBase(r) {
        if (Array.isArray(r.endMonths)) { const base = (r.label || "dönemsel") + " — dönem sonu: " + r.endMonths.map(x => MONTH_DISP[x - 1]).join(", "); return r.followDay ? base + " (dönemi takip eden ayın " + r.followDay + ". günü)" : base + " (son " + (r.lead || 10) + " gün kala hatırlatma)"; }
        if (r.special === "ilk-is-gunu") return "her ayın ilk iş günü";
        if (r.special === "son-is-gunu") return "her ayın son iş günü";
        if (r.special === "ay-sonu") return "her ay sonu";
        if (Number.isInteger(r.weekday)) return "her " + WEEKDAY_NAMES[r.weekday].toLocaleLowerCase("tr-TR");
        const d = (r.days || []).map(x => x + "");
        return "her ayın " + (d.length > 1 ? d.slice(0, -1).join(", ") + " ve " + d[d.length - 1] + ". günleri" : d[0] + ". günü") + (r.window ? " (aralığın son günü)" : "");
    }
    // v3.6.5: yazıdan kuralın bitiş tarihi: "… 30.06.2027 tarihine kadar", "15 Haziran 2027'ye kadar", "Haziran 2027 sonuna kadar", "2027 yılı sonuna kadar",
    // "01.09.2026 - 30.06.2027 tarihleri arasında". Yalnızca yakınında tekrar ifadesi (her ay/hafta, aylık, dönem…) varsa; birden çoksa en geç olan.
    function findRuleUntil(rawText) {
        const F = trFold(String(rawText || "").replace(/[\u00A0\t ]+/g, " "));
        const MON = "(ocak|subat|mart|nisan|mayis|haziran|temmuz|agustos|eylul|ekim|kasim|aralik)";
        const cands = [];
        const add = (iso, idx, len, strict) => {
            if (!fromIso(iso)) return;
            const near = F.slice(Math.max(0, idx - 140), idx + len + 140);
            if (!/her\s+ay|her\s+hafta|her\s+(?:pazartesi|sali|carsamba|persembe|cuma)|aylik|haftalik|donem|tekrar|surekli|sure(?:yle|since)|boyunca/.test(near)) return;
            // tek başına "… tarihine kadar" çoğu zaman bir son tarihtir; kural bitişi sayılması için devam/geçerlilik ya da "itibaren" bağlamı aranır
            if (strict && !(/itibaren|baslamak\s+uzere/.test(F.slice(Math.max(0, idx - 45), idx)) || /^[^.]{0,60}?(devam|gecerli|surekli|boyunca|sureyle|sure\s+ile|olmak\s+uzere)/.test(F.slice(idx + len, idx + len + 70)))) return;
            cands.push(iso);
        };
        const p2 = n => String(n).padStart(2, "0");
        let m, re;
        re = /(\d{1,2})[./](\d{1,2})[./](20\d{2})\s*(?:tarihine|tarihinden|gunune)?\s*(?:kadar|dek)\b/g;
        while ((m = re.exec(F))) add(m[3] + "-" + p2(m[2]) + "-" + p2(m[1]), m.index, m[0].length, true);
        re = /(\d{1,2})[./](\d{1,2})[./](20\d{2})\s*[-–]\s*(\d{1,2})[./](\d{1,2})[./](20\d{2})\s*tarihleri\s*arasinda/g;
        while ((m = re.exec(F))) add(m[6] + "-" + p2(m[5]) + "-" + p2(m[4]), m.index, m[0].length);
        re = new RegExp("(\\d{1,2})\\s+" + MON + "\\s+(20\\d{2})\\s*(?:['’`]?\\s*(?:tarihine|ya|ye|a|e|tarihinden|gunune))?\\s*(?:kadar|dek)\\b", "g");
        while ((m = re.exec(F))) add(m[3] + "-" + p2(TR_MONTH_KEYS.indexOf(m[2]) + 1) + "-" + p2(m[1]), m.index, m[0].length, true);
        re = new RegExp(MON + "\\s+(?:ayi\\s+)?(20\\d{2})\\s*(?:ayi\\s+)?sonuna\\s+(?:kadar|dek)\\b", "g");
        while ((m = re.exec(F))) { const mo = TR_MONTH_KEYS.indexOf(m[1]) + 1, y = +m[2]; add(y + "-" + p2(mo) + "-" + p2(lastDayOfMonth(y, mo)), m.index, m[0].length); }
        re = /(20\d{2})\s*(?:yili|yil)\s*sonuna\s+(?:kadar|dek)\b/g;
        while ((m = re.exec(F))) add(m[1] + "-12-31", m.index, m[0].length);
        return cands.length ? cands.sort().pop() : "";
    }
    // Yazı metninden tekrar kuralı
    function findRecurringRule(rawText) {
        const F = trFold(String(rawText || "").replace(/[\u00A0\t ]+/g, " "));
        let m;
        if (/her\s+ay(?:in)?\s+(?:ilk|1\.?)\s+is\s+gun/.test(F)) return { special: "ilk-is-gunu" };
        if (/her\s+ay(?:in)?\s+son\s+is\s+gun/.test(F)) return { special: "son-is-gunu" };
        if (/her\s+ay\s+sonu|her\s+ayin\s+sonu(?:na)?\s+kadar|her\s+ay\s+sonuna\s+kadar|ay\s+sonlarinda\s+her\s+ay/.test(F)) return { special: "ay-sonu" };
        m = F.match(/(?:her\s+ay(?:in)?|aylik\s+olarak\s+(?:her\s+ayin)?|ayin)\s+((?:\d{1,2}\s*(?:['’`]?\s*(?:i|u|si|su|ine|una|sine|suna|inde|unda|sinde|sunda|ine kadar|e|a))?\s*(?:,|ve|ile|-|ila|veya|\/)?\s*){1,6})/);
        if (m && /her\s+ay/.test(F.slice(Math.max(0, m.index - 2), m.index + 12))) {
            const seg = m[1];
            const trailing = F.slice(m.index + m[0].length, m.index + m[0].length + 30);
            if (!/\d\s*['’`]/.test(seg) && !/^\s*\.?\s*(?:gun(?:u|leri|lerinde|une|unde)\b|kadar|dek|arasinda|icinde|zarfinda|itibariyle|tarih|olmak uzere)/.test(trailing)) return null; // "her ay 5 kişi" gibi sayılar kural sayılmaz
            const nums = (seg.match(/\d{1,2}/g) || []).map(Number).filter(n => n >= 1 && n <= 31);
            const uniq = Array.from(new Set(nums)).sort((a, b) => a - b);
            if (uniq.length) {
                const win = /\b\d{1,2}\b[^.;]{0,25}\b(?:ile|ila|-)\s*\d{1,2}[^.;]{0,25}\barasinda/.test(F.slice(m.index, m.index + 120));
                return win && uniq.length >= 2 ? { days: [uniq[uniq.length - 1]], window: true } : { days: uniq.slice(0, 6) };
            }
        }
        m = F.match(/her\s+(?:hafta(?:nin)?\s+)?(pazartesi|sali|carsamba|persembe|cuma)(?:\s+gunu)?(?:\s+(?:gunu\s+)?mesai\s+bitimine)?\s+(?:kadar|gunu|gunleri)/);
        if (m) return { weekday: WEEKDAYS[m[1]] };
        return periodRuleFrom(F);
    }
    // dönemsel istekler: "3 aylık / 6 aylık / üçer aylık dönemler", "2026 3. dönem (Mart-Nisan-Mayıs)" → dönem sonu + son 10 gün kala hatırlatma
    function periodRule(L, endMonth, label) {
        if (!(L >= 1 && L <= 12) || 12 % L) return { endMonths: [endMonth], lead: 10, label: label };
        const ends = []; for (let k = 0; k < 12 / L; k++) ends.push(((endMonth - 1 + k * L) % 12) + 1);
        return { endMonths: ends.sort((a, b) => a - b), lead: 10, label: label };
    }
    function periodRuleFrom(F) {
        const MON = "(?:ocak|subat|mart|nisan|mayis|haziran|temmuz|agustos|eylul|ekim|kasim|aralik)";
        const wordLen = { uc: 3, ucer: 3, ucaylik: 3, alti: 6, altiser: 6, dort: 4, dorter: 4, iki: 2, ikiser: 2 };
        const parseLen = (s) => { if (/^\d+$/.test(s)) return +s; return wordLen[s] || 0; };
        const monthsFromSpan = (span) => (String(span || "").match(new RegExp(MON, "g")) || []).map(x => TR_MONTH_KEYS.indexOf(x) + 1).filter(x => x > 0);
        const isConsecutive = (ms) => { for (let i = 1; i < ms.length; i++) { const d = (ms[i] - ms[i - 1] + 12) % 12; if (d !== 1) return false; } return ms.length >= 2; };
        const isEvenlySpaced = (ms) => {
            if (ms.length < 2) return false;
            const s = ms.slice().sort((a, b) => a - b);
            const d = (s[1] - s[0] + 12) % 12; if (!d) return false;
            for (let i = 1; i < s.length; i++) if ((s[i] - s[i - 1] + 12) % 12 !== d) return false;
            if ((s[0] + 12 - s[s.length - 1]) % 12 !== d) return false;
            return true;
        };
        const fol = F.match(/(?:donemi?\s+)?takip\s+eden\s+ayin\s+(\d{1,2})/);
        if (fol && +fol[1] >= 1 && +fol[1] <= 31) {
            let base = null;
            const wL = F.match(/\b(\d{1,2}|uc(?:er)?|alti(?:ser)?|dort(?:er)?|iki(?:ser)?)\s+ay(?:lik|da\s+bir)/);
            if (wL) { const L = parseLen(wL[1]); if ([2, 3, 4, 6].includes(L)) base = periodRule(L, L, L + " aylık"); }
            if (!base) {
                const ms = monthsFromSpan(F);
                if (ms.length >= 2) base = { endMonths: Array.from(new Set(ms)).sort((a, b) => a - b), lead: 10, label: ms.length + " aylık dönem (" + ms.map(x => MONTH_DISP[x - 1]).join("-") + ")" };
            }
            if (!base) base = { endMonths: [1, 6], lead: 10, label: "dönem sonu" };
            return Object.assign({}, base, { followDay: +fol[1], label: (base.label || "dönem") + " — takip eden ayın " + fol[1] + ". günü" });
        }
        const re = new RegExp("((?:" + MON + "\\s*(?:,|-|ile|ve|/|–)?\\s*){2,6})", "g");
        let m;
        while ((m = re.exec(F))) {
            const near = F.slice(Math.max(0, m.index - 45), m.index + m[0].length + 45);
            if (!/(donem|aylarinda|her\s+yil|bildir|rapor|gonder)/.test(near) && !/aylarinda/.test(F.slice(m.index, m.index + m[0].length + 24))) continue;
            const ms = monthsFromSpan(m[1]);
            if (ms.length >= 2) {
                const named = /aylarinda/.test(near + " " + F.slice(m.index, m.index + m[0].length + 24)) || (isEvenlySpaced(ms) && !isConsecutive(ms));
                if (named) return { endMonths: Array.from(new Set(ms)).sort((a, b) => a - b), lead: 10, label: ms.length + " aylık dönem (" + ms.map(x => MONTH_DISP[x - 1]).join("-") + ")" };
                return periodRule(ms.length, ms[ms.length - 1], ms.length + " aylık dönem (" + ms.map(x => MONTH_DISP[x - 1]).join("-") + ")");
            }
        }
        const ctx = /(donem|rapor|bildir|gonder|iletil|faaliyet|puantaj|degerlendirme|talep|istenil|her\s+\d+\s+ayda|donemlik|ceyrek|yariyil|yillik)/.test(F);
        const w = F.match(/\b(\d{1,2}|uc(?:er)?|alti(?:ser)?|dort(?:er)?|iki(?:ser)?)\s+ay(?:lik|da\s+bir)\b/);
        if (w && (ctx || /her\s+\d+\s+ayda\s+bir|her\s+(?:uc(?:er)?|alti(?:ser)?)\s+ay/.test(F))) {
            const L = parseLen(w[1]);
            if ([2, 3, 4, 6].includes(L)) return periodRule(L, L, L + " aylık");
        }
        if (/her\s+ceyrek(?:in)?\s+sonu|ceyrek\s+sonlarinda|\bher\s+ceyrek\b|\bceyrek(?:lik)?\s+(?:sonu|rapor|bildir)/.test(F)) return { endMonths: [3, 6, 9, 12], lead: 10, label: "çeyrek sonu" };
        if (/(?:her\s+)?donem(?:in)?\s+sonu|donem\s+sonlarinda|\bdonemlik\b/.test(F)) return { endMonths: [1, 6], lead: 10, label: "dönem sonu" };
        if (/(?:her\s+)?yariyil(?:in)?\s+sonu|\bher\s+yariyil\b|\byariyil\s+sonu/.test(F)) return { endMonths: [1, 6], lead: 10, label: "yarıyıl sonu" };
        const ym = F.match(/her\s+yil\s+(ocak|subat|mart|nisan|mayis|haziran|temmuz|agustos|eylul|ekim|kasim|aralik)(?:\s+ayi(?:nda|nin)?)?/);
        if (ym) { const mo = TR_MONTH_KEYS.indexOf(ym[1]) + 1; if (mo) return { endMonths: [mo], lead: 10, label: "her yıl " + MONTH_DISP[mo - 1] }; }
        if (/(?:her\s+)?yil(?:in)?\s+sonu|\byillik(?:\s+(?:olarak|rapor|faaliyet|bildir|donem))?/.test(F) && !/her\s+ay/.test(F) && !/ay\s+sonu/.test(F)) return { endMonths: [12], lead: 10, label: "yıl sonu" };
        return null;
    }
    const lastDayOfMonth = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
    function prevBusinessDay(dt) { let d = dt; for (let i = 0; i < 10 && !isBusinessDay(d); i++) d = addDaysUtc(d, -1); return d; }
    function firstBusinessDay(y, m) { let d = utcDate(y, m, 1); while (!isBusinessDay(d)) d = addDaysUtc(d, 1); return d; }
    function lastBusinessDay(y, m) { return prevBusinessDay(utcDate(y, m, lastDayOfMonth(y, m))); }
    // fromIso'dan (dahil) itibaren en yakın `count` tarih → [{iso, shifted}]
    // v3.6.5: kuralın bitiş tarihi ("… tarihine kadar"): rule.until (YYYY-MM-DD); sonrasında tarih üretilmez
    function ruleOccurrences(rule, fromIsoStr, count) {
        if (rule && /^\d{4}-\d{2}-\d{2}$/.test(rule.until || "")) {
            return ruleOccurrencesRaw(rule, fromIsoStr, count + 8).filter(o => o.iso <= rule.until).slice(0, count);
        }
        return ruleOccurrencesRaw(rule, fromIsoStr, count);
    }
    function ruleOccurrencesRaw(rule, fromIsoStr, count) {
        const start = fromIso(fromIsoStr); if (!start || !rule) return [];
        if (Array.isArray(rule.endMonths)) {
            const mains = [];
            for (let yy = start.getUTCFullYear(); yy <= start.getUTCFullYear() + 2; yy++) rule.endMonths.slice().sort((a, b) => a - b).forEach(mo => {
                let raw;
                if (rule.followDay >= 1 && rule.followDay <= 31) {
                    let mo2 = mo + 1, yy2 = yy; if (mo2 > 12) { mo2 = 1; yy2++; }
                    raw = utcDate(yy2, mo2, Math.min(rule.followDay, lastDayOfMonth(yy2, mo2)));
                } else raw = utcDate(yy, mo, lastDayOfMonth(yy, mo));
                const bd = prevBusinessDay(raw); mains.push({ iso: isoOf(bd), shifted: bd.getTime() !== raw.getTime() });
            });
            const outP = [];
            mains.filter(x => x.iso >= fromIsoStr).slice(0, count).forEach(M => {
                outP.push(M);
                const pre = prevBusinessDay(addDaysUtc(fromIso(M.iso), -(rule.lead || 10))), pi = isoOf(pre);
                if (pi >= fromIsoStr && pi < M.iso) outP.push({ iso: pi, shifted: false, pre: true });
            });
            return outP.sort((a, b) => a.iso.localeCompare(b.iso));
        }
        const out = [], seen = new Set();
        const push = (dt, shifted) => { const iso = isoOf(dt); if (iso >= fromIsoStr && !seen.has(iso)) { seen.add(iso); out.push({ iso: iso, shifted: shifted }); } };
        if (Number.isInteger(rule.weekday)) {
            for (let i = 0; i < 28 && out.length < count; i++) { const d = addDaysUtc(start, i); if (d.getUTCDay() === rule.weekday) { const bd = prevBusinessDay(d); push(bd, bd.getTime() !== d.getTime()); } }
            return out.sort((a, b) => a.iso.localeCompare(b.iso)).slice(0, count);
        }
        let y = start.getUTCFullYear(), mo = start.getUTCMonth() + 1;
        for (let k = 0; k < 14 && out.length < count + 6; k++) {
            if (rule.special === "ilk-is-gunu") push(firstBusinessDay(y, mo), false);
            else if (rule.special === "son-is-gunu") push(lastBusinessDay(y, mo), false);
            else if (rule.special === "ay-sonu") { const raw = utcDate(y, mo, lastDayOfMonth(y, mo)); const bd = prevBusinessDay(raw); push(bd, bd.getTime() !== raw.getTime()); }
            else (rule.days || []).forEach(n => { const raw = utcDate(y, mo, Math.min(n, lastDayOfMonth(y, mo))); const bd = prevBusinessDay(raw); push(bd, bd.getTime() !== raw.getTime()); });
            mo++; if (mo > 12) { mo = 1; y++; }
        }
        return out.sort((a, b) => a.iso.localeCompare(b.iso)).slice(0, count);
    }
    // doküman bilgisine: yaklaşan tarih (bugünden itibaren)
    function recurringDeadline(rule) {
        const occ = ruleOccurrences(rule, istanbulTodayIso(), 1).find(o => !o.pre);
        if (!occ) return null;
        const dt = fromIso(occ.iso);
        return { iso: occ.iso, display: fmtTrDate(dt), kind: "tekrarlı", basis: "Tekrarlı yazı: " + ruleText(rule) + (occ.shifted ? " (tarih hafta sonu/tatile denk geldiği için önceki iş günü)" : ""), rule: rule };
    }
    // kural kaydı (aynı konu + aynı kural ikinci kez eklenmez) → kayıt, yeni mi
    const tekrarSigOf = (konu, rule) => trFold(String(konu || "").replace(/\d{1,2}[./]\d{1,2}[./]\d{4}/g, " ").replace(/E-\d[\w.-]+/g, " ")).replace(/[^a-z]+/g, " ").trim().slice(0, 90) + "|" + ruleKey(rule);
    function tekrarUpsert(konu, gonderen, rule) {
        const k = TK.clean(String(konu || "").replace(/^🔁\s*/, ""), 160);
        if (!k || !isValidRule(rule)) return { rec: null, isNew: false };
        const sig = tekrarSigOf(k, rule);
        let rec = tekrarStore.rules.find(r => r.sig === sig);
        if (rec) { if (rule.until && !rec.rule.until) { rec.rule = Object.assign({}, rec.rule, { until: rule.until }); saveTekrar(); } return { rec: rec, isNew: false }; }
        rec = { id: "r" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), sig: sig, konu: k, gonderen: TK.clean(gonderen || "", 80), rule: rule, ilk: istanbulTodayIso(), aktif: true };
        tekrarStore.rules.push(rec);
        if (tekrarStore.rules.length > 60) tekrarStore.rules.shift();
        saveTekrar();
        return { rec: rec, isNew: true };
    }
    // her kural için yaklaşan 2 tarihi takip listesine ekle (silinen kayıt bir daha eklenmez); geçmiş açık kayıtlara dokunulmaz
    function tekrarSync() {
        try {
            if (!extHasConsent() || !tekrarStore.rules.length) return 0;
            let st = getTakip(), n = 0;
            const today = takipToday();
            tekrarStore.rules.filter(r => r.aktif !== false).forEach(r => {
                ruleOccurrences(r.rule, today, 2).forEach(o => {
                    const rec = { evrakNo: "TEKRAR-" + r.id + "-" + o.iso + (o.pre ? "-on" : ""), konu: "🔁 " + r.konu + (o.pre ? " — dönem sonuna son " + (r.rule.lead || 10) + " gün" : ""), gonderen: r.gonderen, sonTarih: o.iso,
                        not: "Tekrarlı yazı: " + ruleText(r.rule) + (o.pre ? " [ön hatırlatma]" : "") + (o.shifted ? " (hafta sonu/tatil → önceki iş günü)" : "") };
                    const res = TK.upsertFromDoc(st, rec, { autoAdd: true, today: today });
                    if (res.action === "added") { st = res.store; n++; }
                });
            });
            if (n) saveTakip(st);
            return n;
        } catch(e) { console.warn("[Evrak Asistanı] Tekrarlı yazı eşitlenemedi:", e); return 0; }
    }
    // evrak analizinde tekrar kuralı bulunduysa kaydet
    function takipOnRecurring(d) {
        try {
            const r = d && d.info && d.info.tekrar;
            if (!r || !extHasConsent()) return;
            const res = tekrarUpsert(d.info.konu || d.subject, d.info.gonderen || d.gonderen, r);
            if (!res.rec) return;
            const n = tekrarSync();
            if (res.isNew) showToast("🔁 Tekrarlı yazı kaydedildi: " + ruleText(r) + ". Yaklaşan tarihler 📅 Günlü Takip'e işlendi.\nYönetmek için: 📅 Günlü Takip > 🔁 Tekrarlı yazılar.", "ok");
        } catch(e) { console.warn("[Evrak Asistanı] Tekrarlı yazı kaydedilemedi:", e); }
    }
    function renderTekrarBox() {
        const box = document.getElementById("ebys-tekrar-box");
        if (!box) return;
        const css = "background:#2D3D63; border-radius:8px; padding:5px 8px; display:flex; justify-content:space-between; align-items:center; gap:6px;";
        let h = '<div style="font-weight:800; color:#FBBF24; margin-top:6px;">🔁 Tekrarlı yazılar (' + tekrarStore.rules.length + ')</div>'
            + '<div style="color:#A9B6CA; font-size:10.5px;">Her ay / hafta istenen yazılar ("her ayın 5, 10, 20\'si", "ilk iş günü" gibi) yazıdan tanınır; yaklaşan 2 tarih takibe işlenir. Hafta sonu/tatil → önceki iş günü.</div>';
        tekrarStore.rules.forEach(r => {
            const occ = ruleOccurrences(r.rule, istanbulTodayIso(), 1).find(o => !o.pre);
            h += '<div class="tekrar-row" data-id="' + escapeHtml(r.id) + '" style="' + css + '"><span style="font-size:10.5px; color:#E2E8F0;">' + escapeHtml(TK.clean(r.konu, 70)) + '<br><span style="color:#93C5FD;">' + escapeHtml(ruleText(r.rule)) + (occ ? " • sıradaki: " + escapeHtml(TK.fmtTr(occ.iso)) : (r.rule.until ? " • süresi doldu" : "")) + '</span></span><button class="tekrar-del" style="background:#7F1D1D; color:#FCA5A5; border:none; border-radius:6px; padding:2px 8px; cursor:pointer;">Sil</button></div>';
        });
        h += '<div style="display:flex; gap:4px; flex-wrap:wrap; margin-top:4px;"><input id="tekrar-konu" placeholder="Konu (ör. Aylık yoklama bildirimi)" style="flex:2; min-width:120px; padding:4px; background:#13233F; border:1px solid #56709A; border-radius:6px; color:white;">'
            + '<input id="tekrar-gun" placeholder="5,10,20 / ilk iş günü / ay sonu / cuma / 3 aylık / 6 aylık / mart nisan mayıs" style="flex:2; min-width:120px; padding:4px; background:#13233F; border:1px solid #56709A; border-radius:6px; color:white;">'
            + '<input id="tekrar-until" type="date" title="Kural bu tarihe kadar geçerli (boş = süresiz)" style="min-width:120px; padding:4px; background:#13233F; border:1px solid #56709A; border-radius:6px; color:white;">'
            + '<button id="tekrar-add" style="background:#16A34A; color:white; border:none; border-radius:6px; padding:4px 10px; cursor:pointer; font-weight:bold;">➕ Ekle</button></div>';
        box.innerHTML = h;
        box.querySelectorAll(".tekrar-del").forEach(b => { b.onclick = () => { const id = b.closest(".tekrar-row").getAttribute("data-id"); tekrarStore.rules = tekrarStore.rules.filter(r => r.id !== id); saveTekrar(); }; });
        const add = box.querySelector("#tekrar-add");
        if (add) add.onclick = () => {
            const konu = box.querySelector("#tekrar-konu").value.trim(), gun = box.querySelector("#tekrar-gun").value.trim();
            const rule = findRecurringRule("her ayın " + gun) || findRecurringRule(gun + " dönem bildirim") || findRecurringRule("dönem " + gun + " bildirim") || findRecurringRule("her " + gun + " günü kadar") || findRecurringRule("her ay " + gun)
                || (/^\d{1,2}([\s,;/-]+\d{1,2})*$/.test(gun) ? { days: Array.from(new Set(gun.match(/\d{1,2}/g).map(Number).filter(n => n >= 1 && n <= 31))).sort((a, b) => a - b) } : null);
            if (!konu || !rule) { showToast("Konu ve geçerli bir tekrar yazın (örn. 5,10,20 ya da ilk iş günü).", "warn"); return; }
            const untilV = (box.querySelector("#tekrar-until") || {}).value || "";
            tekrarUpsert(konu, "", /^\d{4}-\d{2}-\d{2}$/.test(untilV) ? Object.assign({}, rule, { until: untilV }) : rule); tekrarSync(); refreshTakipUi();
        };
    }
    setInterval(() => { try { tekrarSync(); } catch(e) {} }, 30 * 60 * 1000);
    setTimeout(() => { try { tekrarSync(); renderTekrarBox(); } catch(e) {} }, 2500);

    // =========================================================================
    // NEW (v3.6.4): CEVAP YAZ → "Gereği" alanına evrakın GELDİĞİ YER otomatik seçilir (yalnızca eklenti Cevap Yaz'ı kendisi açtıysa, alan boşsa,
    // tek ve kesin eşleşme varsa; belirsizlikte hiçbir şey seçilmez, kullanıcıya bildirilir). Metin yazma akışı bundan etkilenmez.
    // =========================================================================
    const GEREK_AUTO_KEY = "ebys_gerek_auto_v1";
    const gerekAutoOn = () => { const v = extStoreGet(GEREK_AUTO_KEY); return !(v && v.on === false); };
    const GEREK_ONLY_KEY = "ebys_gerek_only_auto_v1"; // v3.6.21: yalnızca Gereği otomatiği (Klasör etkilenmez)
    const gerekOnlyOn = () => { const v = extStoreGet(GEREK_ONLY_KEY); return !(v && v.on === false); };
    // v3.6.21: kısa yerleşme — örtü ~300 ms kesintisiz kapalı olunca devam (en çok capMs)
    // v3.6.24: adlandırma çakışması düzeltildi (havale'deki quickSettle bunu gölgeliyordu) + YALNIZCA gerçek 'Lütfen Bekleyiniz' örtüsüne bakar
    function bekleyinizStrict() {
        for (const d of direktDocs()) {
            try {
                const b = d.getElementById("bekleyinizStatusDialog");
                if (!b || !isVisible(b) || b.getAttribute("aria-hidden") === "true") continue;
                const cs = (b.ownerDocument.defaultView || window).getComputedStyle(b), r = b.getBoundingClientRect();
                if (cs.display !== "none" && cs.visibility !== "hidden" && r.width > 0 && r.height > 0) return true;
            } catch(e) {}
        }
        return false;
    }
    function ajaxBusyWhy() { // isAjaxBusy() true ise hangi öğe — süre raporu için
        try {
            for (let doc of getAllDocs()) {
                for (let el of doc.querySelectorAll(".ui-datatable-loading, .ui-blockui, .ui-blockui-content")) if (!el.closest("#ebys-inbox-panel") && isVisible(el)) return describeEl(el);
                for (let el of doc.querySelectorAll(".ui-dialog, .ui-overlaypanel, [id*='statusDialog'], [id*='ajaxStatus'], [id*='bekleyiniz' i], .ui-widget-overlay + div")) {
                    if (el.closest("#ebys-inbox-panel") || !isVisible(el)) continue;
                    const t = (el.textContent || "").replace(/\s+/g, " ").trim();
                    if (t.length < 80 && /l[uü]tfen\s*bekleyiniz/i.test(t)) return describeEl(el);
                }
            }
        } catch(e) {}
        return "";
    }
    async function stepSettle(capMs, label) {
        const t0 = Date.now(); let since = 0;
        while (Date.now() - t0 < (capMs || 4000)) {
            if (AUTO.stop) throw stopErr();
            if (bekleyinizStrict()) since = 0; else { if (!since) since = Date.now(); if (Date.now() - since >= 300) { stepLog("stepSettle " + (label || ""), t0, "ok"); return true; } }
            await new Promise(r => setTimeout(r, 50));
        }
        stepLog("stepSettle " + (label || "") + " (" + capMs + ")", t0, "ZAMAN AŞIMI");
        return !bekleyinizStrict();
    }
    const senderOfDoc = d => (d && d.gonderen && d.gonderen !== "-") ? String(d.gonderen).replace(/\s+/g, " ").trim() : "";
    function cevapScopeEl() {
        const d = document.getElementById("windowCevapEvrakDialog");
        if (d && isVisible(d)) return d;
        const m = document.querySelector('[id$="cevapEvrakTabMenuLeft"]');
        return m && isVisible(m) ? (m.closest(".ui-dialog") || document) : null;
    }
    function findLeftTabButton(label) {
        for (const doc of getAllDocs()) {
            for (const b of doc.querySelectorAll('[id$="cevapEvrakTabMenuLeft"] button, [id*="TabMenuLeft"] button')) {
                if (isPanelEl(b) || !isVisible(b)) continue;
                const lab = (b.getAttribute("aria-label") || (b.querySelector(".ui-button-text") || b).textContent || "").trim();
                if (lab === label) return b;
            }
        }
        return null;
    }
    function findGerekInput(scope) {
        const exact = scope.querySelector('input[id$=":geregiLov:LovText"]');
        if (exact) return exact;
        const inputs = Array.from(scope.querySelectorAll('input[id$=":LovText"]'));
        for (const inp of inputs) {
            const row = inp.closest("tr") || (inp.parentElement && inp.parentElement.parentElement);
            const t = trFold((row && row.textContent) || "").trim();
            if (/^geregi(?!\s*secim)/.test(t)) return inp;
        }
        return inputs.find(i => /gere[gk]/i.test(i.id)) || null;
    }
    let lastPromptInfo = "", direktBusy = false;
    const DLG_SEL = ".ui-dialog, .ui-confirm-dialog, [role=dialog]";
    function describeEl(el) { return el.tagName.toLowerCase() + (el.id ? "#" + el.id : "") + (typeof el.className === "string" && el.className.trim() ? "." + el.className.trim().split(/\s+/).slice(0, 3).join(".") : ""); }
    function describeDialog(dl) {
        if (!dl) return "-";
        const bts = Array.from(dl.querySelectorAll("button, a, input[type=button], .ui-button")).filter(isVisible).slice(0, 8)
            .map(bt => describeEl(bt) + ' "' + (bt.value || bt.textContent || "").replace(/\s+/g, " ").trim().slice(0, 40) + '"');
        return describeEl(dl) + ' metin="' + (dl.textContent || "").replace(/\s+/g, " ").trim().slice(0, 160) + '" düğmeler=[' + bts.join(" | ") + "]";
    }
    function directTextOk(el) {
        const t = trFold(el.value || el.textContent || "").replace(/\s+/g, " ").trim();
        return t.length <= 60 && !/mulki/.test(t) && /(direkt|direk|dogrudan)/.test(t) && /gonder/.test(t);
    }
    function direktDocs() {
        const ds = getAllDocs().slice();
        try { const td = window.top.document; if (td && !ds.includes(td)) { ds.push(td); td.querySelectorAll("iframe, frame").forEach(f => { try { const cd = f.contentDocument; if (cd && !ds.includes(cd)) ds.push(cd); } catch(e) {} }); } } catch(e) {}
        return ds;
    }
    function findDirektGonder() {
        const pick = (inDialogOnly) => {
            const hits = [];
            for (const doc of direktDocs()) {
                let els; try { els = doc.querySelectorAll("button, a, label, span, li, td, div.ui-button, input[type=button], input[type=submit], .ui-button-text"); } catch(e) { continue; }
                for (const el of els) {
                    if (isPanelEl(el) || !isVisible(el) || !directTextOk(el)) continue;
                    if (inDialogOnly && !el.closest(DLG_SEL)) continue;
                    hits.push(el);
                }
            }
            return hits.length ? hits[hits.length - 1] : null; // en içteki eleman
        };
        const el = pick(true) || pick(false);
        if (el) return el.closest("button, a, label, li, .ui-button") || el;
        // yedek: iki seçenekli uyarı ("Mülki İdare Kanalı ile Gönder" | "Direkt Gönder") → "Mülki" olmayan, en sağdaki gönder düğmesi
        for (const doc of getAllDocs()) {
            let dlgs; try { dlgs = doc.querySelectorAll(DLG_SEL); } catch(e) { continue; }
            for (const dl of dlgs) {
                if (isPanelEl(dl) || !isVisible(dl)) continue;
                const dt = trFold(dl.textContent || "");
                if (!(/mulki/.test(dt) || /lutfen\s+secim/.test(dt)) || !/gonder/.test(dt)) continue;
                const bs = Array.from(dl.querySelectorAll("button, a.ui-button, input[type=button], .ui-button")).filter(bt => {
                    if (isPanelEl(bt) || !isVisible(bt)) return false;
                    const bx = trFold(bt.value || bt.textContent || "").replace(/\s+/g, " ").trim();
                    return bx && bx.length <= 60 && /gonder/.test(bx) && !/mulki/.test(bx);
                });
                if (bs.length) return bs.sort((x, y) => y.getBoundingClientRect().left - x.getBoundingClientRect().left)[0];
            }
        }
        return null;
    }
    // ekranda takılı kalmış dağıtım uyarısı (Mülki / "Lütfen seçim yapınız")
    function stuckPromptDialog() {
        for (const doc of getAllDocs()) {
            let dlgs; try { dlgs = doc.querySelectorAll(DLG_SEL); } catch(e) { continue; }
            for (const dl of dlgs) {
                if (isPanelEl(dl) || !isVisible(dl)) continue;
                const dt = trFold(dl.textContent || "");
                if (/mulki/.test(dt) || /lutfen\s+secim/.test(dt)) return dl;
            }
        }
        return null;
    }
    // v3.6.33: "Direkt Gönder" (dağıtım kanalı seçimi) — SAĞLAM tıklama. Gerçek EBYS ilk çalıştırmada (real_report_3632) düğmeye basılıyor ama
    // mulkiIdareKanaliOneriDialog kapanmıyordu: pencere/düğme PrimeFaces tarafından henüz bağlanmamışken tıklanıyordu. Şimdi:
    //  1) hazır olma beklenir: pencere görünür, düğme etkin ve DOM'da, EBYS örtüsü yok, PrimeFaces.ajax kuyruğu boş + jQuery.active=0, konum 400 ms sabit, +300 ms;
    //  2) yöntemler sırayla (her biri sonrası pencerenin kapanması 8 sn beklenir): sayfa dünyasında düğmenin kendi onclick'i (PrimeFaces.ab) →
    //     jQuery trigger('click') → tam fare olay dizisi (sayfa dünyası) + yerel tıklama; her deneme öncesi hazır olma yeniden beklenir;
    //  3) her adım tanı raporuna yazılır ("Direkt Gönder günlüğü"). Ana formdaki Kaydet/Parafla/İmzala/Gönder'e asla dokunulmaz.
    let direktLog = [];
    function direktLogPush(t) { const line = ((Date.now() - STEP_T0) / 1000).toFixed(2) + "s " + t; direktLog.push(line); if (direktLog.length > 60) direktLog.shift(); dbg("[Direkt]", line); }
    async function direktWaitReady(dg, dlgEl, tok, maxMs) {
        const t0 = Date.now(); let lastRect = "", stableAt = 0, st = null;
        while (Date.now() - t0 < maxMs) {
            if (AUTO.stop) throw stopErr();
            const attached = dg.isConnected && isVisible(dg) && (!dlgEl || isVisible(dlgEl));
            const disabled = dg.disabled || dg.getAttribute("aria-disabled") === "true" || /ui-state-disabled/.test(dg.className || "");
            const busy = (() => { try { return bekleyinizStrict(); } catch(e) { return false; } })();
            st = (await bridgeAvailable()) ? await bridgeCall("direktState", { tok: tok }, 800) : null;
            const qOk = !st || (st.qEmpty && !st.jqActive);
            let rect = ""; try { const r = (dlgEl || dg).getBoundingClientRect(); rect = [r.left, r.top, r.width, r.height].map(Math.round).join(","); } catch(e) {}
            if (rect !== lastRect) { lastRect = rect; stableAt = Date.now(); }
            if (!attached) return { ok: false, gone: true, st };
            if (!disabled && !busy && qOk && Date.now() - stableAt >= 400) { await sleep(300); return { ok: true, ms: Date.now() - t0, st }; }
            await sleep(120);
        }
        return { ok: false, timeout: true, st };
    }
    // v3.6.34: Direkt akışı TEK bir promise (direktPromise); her kapanış kontrolü bunu bekler. Promise ilk await'ten ÖNCE eşzamanlı atanır (yarış yok).
    let direktPromise = null, direktClosedAt = 0;
    function tryClickDirekt() {
        if (direktPromise) return direktPromise;
        if (direktBusy) return Promise.resolve(false);
        const dg = findDirektGonder();
        if (!dg) return Promise.resolve(false);
        direktBusy = true;
        direktPromise = tryClickDirektRun(dg).then(r => { if (r) direktClosedAt = Date.now(); return r; }, e => { direktLogPush("hata: " + (e && e.message || e)); return false; })
            .finally(() => { direktBusy = false; direktPromise = null; });
        return direktPromise;
    }
    // uyarı gelebilir: görünmesini (en çok appearMs) bekle; çalışan/yeni Direkt akışını sonuna kadar AWAIT et
    async function awaitDirektFlow(appearMs) {
        const t0 = Date.now();
        while (Date.now() - t0 < appearMs) {
            if (AUTO.stop) break;
            if (direktPromise) { await direktPromise; break; }
            if (findDirektGonder()) { await tryClickDirekt(); break; }
            await sleep(100);
        }
        while (direktPromise) await direktPromise; // izleyici yeni bir deneme başlattıysa onu da bekle
    }
    // v3.6.34: Gereği sonrası dağıtım uyarısı kapanış kontrolü (tek Direkt promise'ini bekler; test edilebilir ayrı işlev)
    async function gerekCloseCheck(gStart) {
        let warn = "";
        // v3.6.34: tek Direkt promise'i beklenir (uyarı seçimden ~0,8 sn sonra gelebilir → 2,5 sn görünme penceresi), sonra TAZE görünürlük kontrolü.
        await awaitDirektFlow(2500);
        { const tClose = Date.now();
          while (Date.now() - tClose < 2500) {
            if (direktPromise) { await awaitDirektFlow(0); continue; }
            if (!stuckPromptDialog() || direktClosedAt >= gStart) { warn = ""; break; } // "bizim tıklamamızla kapandı" = başarı
            warn = "Dağıtım uyarısı kapanmadı";
            await sleep(100);
          }
        }
        if (warn) { // kesmeden devam: uyarı sonradan kapanırsa sessizce geçilir, yalnızca hâlâ açıksa rapor
            await awaitDirektFlow(0);
            if (!stuckPromptDialog() || direktClosedAt >= gStart) warn = "";
        }
        direktLogPush("kapanış kontrolü: " + (warn ? "uyarı HÂLÂ açık" : "uyarı yok/kapandı") + (direktClosedAt >= gStart ? " (bizim tıklamamızla kapandı)" : ""));
        return warn;
    }
    async function tryClickDirektRun(dg) {
        try {
            const dlgEl = dg.closest(DLG_SEL);
            // güvenlik: hedef bir uyarı PENCERESİ içinde ve metni "Direkt…Gönder" (Mülki değil) olmalı; ana form düğmelerine dokunulmaz
            if (!dlgEl || !(directTextOk(dg) || /DirektGonder$/i.test(dg.id || ""))) { direktLogPush("hedef reddedildi (pencere dışında ya da metin uymuyor): " + describeEl(dg)); return false; }
            lastPromptInfo = describeDialog(dlgEl) + " | tıklanan: " + describeEl(dg);
            const tok = "dg" + (++pickSeq); dg.setAttribute("data-ebys-pick", tok);
            const gone = () => !dg.isConnected || !isVisible(dg) || !isVisible(dlgEl);
            const strategies = [
                { name: "sayfa: düğmenin onclick'i (PrimeFaces.ab)", run: async () => bridgeCall("direktClick", { tok, strategy: "onclick" }, 2500) },
                { name: "sayfa: jQuery trigger('click')", run: async () => bridgeCall("direktClick", { tok, strategy: "jq" }, 2500) },
                { name: "sayfa: tam fare olay dizisi + yerel tıklama", run: async () => { const r = await bridgeCall("direktClick", { tok, strategy: "mouse" }, 2500); if (!r || !r.clicked) { try { userClick(dg); } catch(e) { dg.click(); } } return r || { clicked: true, via: "yerel" }; } }
            ];
            if (!(await bridgeAvailable())) strategies.unshift({ name: "yerel tıklama (köprü yok)", run: async () => { userClick(dg); return { clicked: true }; } });
            for (let i = 0; i < strategies.length; i++) {
                const S = strategies[i];
                const rd = await direktWaitReady(dg, dlgEl, tok, i === 0 ? 10000 : 6000);
                if (rd.gone) { direktLogPush("pencere kendiliğinden kapandı"); return true; }
                direktLogPush("deneme " + (i + 1) + " hazır=" + (rd.ok ? "evet (" + rd.ms + " ms)" : "HAYIR (zaman aşımı)") + " durum=" + JSON.stringify(rd.st || {}));
                let r = null; try { r = await S.run(); } catch(e) { r = { error: String(e && e.message || e) }; }
                direktLogPush("deneme " + (i + 1) + ": " + S.name + " → " + JSON.stringify(r || { yanıt: "yok" }));
                if (await waitFor(gone, 8000, 100)) { direktLogPush("✅ pencere kapandı (deneme " + (i + 1) + ")"); lastPromptInfo += " | yöntem: " + S.name; return true; }
                direktLogPush("pencere 8 sn içinde kapanmadı");
            }
            return gone();
        } finally {}
    }

    // ---- v3.6.6: TANI RAPORU (otomatik seçim başarısız olursa ekranda kopyalanabilir kutu)
    function cevapDiagReport(reason) {
        const L = ["Evrak Asistanı " + (function() { try { return chrome.runtime.getManifest().version || EXT_VERSION; } catch(e) { return EXT_VERSION + " (eklenti bağlamı yenilenmeli: sayfayı F5)"; } })() + " tanı raporu", "Neden: " + reason];
        try {
            const scope = cevapScopeEl() || document;
            Array.from(scope.querySelectorAll('input[id$=":LovText"]')).forEach(inp => {
                const form = inp.closest("form") || scope;
                let row = "", el = inp;
                for (let i = 0; i < 7 && el.parentElement; i++) { el = el.parentElement; if (el.querySelectorAll('input[id$=":LovText"]').length > 1) break; row = (el.textContent || "").replace(/\s+/g, " ").trim(); }
                L.push("LoV id=" + inp.id + " | satır: " + row.slice(0, 70) + " | seçili: " + (lovSelectedTitle(form, inp.id.replace(/:LovText$/, "").split(":").pop()) || "-").slice(0, 90));
            });
            for (const doc of getAllDocs()) doc.querySelectorAll(DLG_SEL).forEach(dl => { if (!isPanelEl(dl) && isVisible(dl)) L.push("Pencere: " + describeDialog(dl)); });
            if (lastPromptInfo) L.push("Son uyarı: " + lastPromptInfo);
            if (lastPickInfo) L.push("Seçim yöntemi: " + lastPickInfo);
            if (direktLog.length) L.push("--- Direkt Gönder günlüğü (v3.6.35) ---\n" + direktLog.join("\n")); // v3.6.33
            try { if (STEPLOG.length) L.push(stepReport()); } catch(e) {}
            if (lastAutoRec) L.push("--- Gereği istek/olay kaydı ---\n" + lastAutoRec.slice(-6000));
            for (const d of direktDocs()) { try { d.querySelectorAll('#bekleyinizStatusDialog, .ui-blockui, .ui-datatable-loading, [id*="statusDialog"], [id*="ajaxStatus"]').forEach(el => { if (!isPanelEl(el)) L.push("Örtü: " + describeEl(el) + " görünür=" + isVisible(el) + " stil=" + String(el.getAttribute("style") || "").slice(0, 80) + " html=" + (el.outerHTML || "").replace(/\s+/g, " ").slice(0, 200)); }); } catch(e) {} }
            const gd = findLovDialog(document, "geregiLov");
            if (gd) L.push("Gereği penceresi HTML: " + (gd.outerHTML || "").replace(/\s+/g, " ").slice(0, 1500));
            L.push("Gereği penceresi: " + (gd ? (isVisible(gd) ? "görünür" : "gizli") + " id=" + gd.id : "YOK"));
            Object.keys(lovHtmlById).forEach(k => L.push("LoV liste HTML [" + k + "]: " + lovHtmlById[k]));
            if (!Object.keys(lovHtmlById).length && lastLovHtml) L.push("LoV liste HTML: " + lastLovHtml);
        } catch(e) { L.push("rapor hatası: " + (e && e.message)); }
        return L.join("\n");
    }
    function showDiagBox(text) {
        if (frCapture) { frCapture.push(text); console.debug("[Evrak Asistanı] ilk çalıştırma tanı raporu (panelde):", text); return; } // v3.6.35
        try {
            console.warn("[Evrak Asistanı]", text);
            let box = document.getElementById("ebys-diag-box");
            if (box) box.remove();
            box = document.createElement("div");
            box.id = "ebys-diag-box";
            box.style.cssText = "position:fixed; right:12px; bottom:12px; z-index:2147483647; width:420px; max-width:92vw; background:#1E293B; color:#E2E8F0; border:1px solid #F59E0B; border-radius:10px; padding:8px; font:11px/1.4 sans-serif; box-shadow:0 6px 24px rgba(0,0,0,.5);";
            box.innerHTML = '<div style="font-weight:bold; color:#FBBF24; margin-bottom:4px;">🔧 Otomatik seçim tamamlanamadı — tanı raporu</div>'
                + '<textarea readonly style="width:100%; height:130px; box-sizing:border-box; background:#0F172A; color:#E2E8F0; border:1px solid #475569; border-radius:6px; font:10.5px monospace;"></textarea>'
                + '<div style="display:flex; gap:6px; margin-top:4px;"><button class="dg-copy" style="background:#2563EB; color:#fff; border:none; border-radius:6px; padding:4px 10px; cursor:pointer;">Kopyala</button><button class="dg-close" style="background:#475569; color:#fff; border:none; border-radius:6px; padding:4px 10px; cursor:pointer;">Kapat</button></div>';
            box.querySelector("textarea").value = text;
            box.querySelector(".dg-copy").onclick = () => { copyToClipboard(text).then(ok => { box.querySelector(".dg-copy").textContent = ok ? "Kopyalandı ✔" : "Kopyalanamadı"; }); };
            box.querySelector(".dg-close").onclick = () => box.remove();
            document.body.appendChild(box);
        } catch(e) {}
    }
    function gerekTypeHuman(inp, query) {
        try { inp.focus(); } catch(e) {}
        try {
            const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(inp), "value");
            if (setter && setter.set) setter.set.call(inp, query); else inp.value = query;
        } catch(e) { inp.value = query; }
        try { inp.dispatchEvent(new Event("input", { bubbles: true })); } catch(e) {}
        const ch = query.slice(-1), up = ch.toLocaleUpperCase("tr-TR");
        const kc = /[A-Z]/.test(up) ? up.charCodeAt(0) : /[0-9]/.test(ch) ? ch.charCodeAt(0) : 65;
        let ev; try { ev = new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: ch, keyCode: kc, which: kc }); } catch(e) { ev = new Event("keyup", { bubbles: true }); }
        try { if (ev.keyCode !== kc) Object.defineProperty(ev, "keyCode", { get: () => kc }); if (ev.which !== kc) Object.defineProperty(ev, "which", { get: () => kc }); } catch(e) {}
        inp.dispatchEvent(ev);
    }
    async function gerekSelectOnce(findNode, verify, dlgGet) {
        const tried = [];
        if (verify()) return { ok: true, tried };
        if (!(await waitBekleyinizGone())) { lastPickInfo = "Gereği: örtü kapanmadı, tıklanmadı"; return { ok: false, tried }; }
        const n = findNode();
        if (!n) { lastPickInfo = "Gereği: öğe yok"; return { ok: false, tried: ["öğe yok"] }; }
        if (isForbiddenEl(n)) return { ok: false, tried: ["Onay Akışı engeli"] };
        const c = (n.closest && n.closest(".ui-treenode-content")) || n;
        autoCheck();
        if (!nodeHighlighted(c)) { c.click(); tried.push("tek tıklama"); } else tried.push("zaten vurgulu");
        await sleep(400);
        await waitBekleyinizGone(); // seçim AJAX'ı bitsin
        if (await waitFor(() => verify(), 2500, 250)) { lastPickInfo = "Gereği: tek tıklamayla seçildi"; return { ok: true, tried }; }
        const d = dlgGet();
        const b = d && isVisible(d) ? lovOkButton(d) : null;
        if (b && !bekleyinizVisible()) {
            b.click(); tried.push("Tamam");
            await sleep(400);
            await waitBekleyinizGone();
        }
        const ok = !!(await waitFor(() => verify(), 6000, 250));
        lastPickInfo = "Gereği: " + (ok ? "seçildi (" : "seçilemedi (") + tried.join(" + ") + ")";
        return { ok, tried };
    }
    async function gerekTryLov(form, inp, lovId, query, full, retyped) {
        if (!(await waitBekleyinizGone())) return "none"; // örtü açıkken yazılmaz
        // v3.6.16: insan gibi yaz — odak, değer (yalnızca 'input' olayı; 'change' YOK: Gereği'nde change ayrı bir AJAX başlatıp otomatik tamamlama isteğiyle
        // çakışıyor ve 'Lütfen Bekleyiniz' bitmiyordu), son harf için TEK keyup (gerçek tuş kodu). Klasör/Konu yolu değişmedi.
        gerekTypeHuman(inp, query);
        const targets = (Array.isArray(full) ? full : [full]).map(x => trFold(x)).filter(Boolean);
        let result = null;
        const finder = () => {
            const dlg = findLovDialog(form, lovId);
            if (!dlg || !isVisible(dlg)) return null;
            const nodes = Array.from(dlg.querySelectorAll(".ui-treenode-label, .ui-treenode-content, .lovItemTitle, tr[data-ri], tr[data-rk], li.ui-autocomplete-item")).filter(n => isVisible(n) && (n.textContent || "").trim());
            if (!nodes.length) return null;
            const labels = nodes.filter(n => n.classList.contains("ui-treenode-label") || n.classList.contains("lovItemTitle"));
            let pool = labels.length ? labels : nodes;
            // v3.6.12: üst düğüm ("▾ Birim") değil yaprak — her öğe kendi düğümünün içerik kabına göre değerlendirilir
            const allPool = pool;
            const leafPool = pool.filter(n => { const li = n.closest("li.ui-treenode"); return li && li.classList.contains("ui-treenode-leaf"); });
            if (leafPool.length) pool = leafPool;
            const parentFallback = () => { if (pool === allPool) return null; pool = allPool.filter(n => !leafPool.includes(n)); return true; };
            lovCaptureHtml(dlg);
            const nz = x => trFold(String(x || "")).replace(/\s+/g, " ").trim();
            const titleOf = n => { const t = n.querySelector && n.querySelector(".lovItemTitle"); return nz(t ? t.textContent : n.textContent); };
            for (let pass = 0; pass < 2; pass++) {
            if (pass === 1 && !parentFallback()) break;
            for (const target of targets) {
                const exactT = pool.filter(n => titleOf(n) === nz(target));
                if (exactT.length === 1) return exactT[0];
                const hits = pool.filter(n => nz(n.textContent).includes(nz(target)) || titleOf(n).includes(nz(target)));
                if (hits.length === 1) return hits[0];
                if (hits.length > 1) {
                    const sorted = hits.slice().sort((a, b) => (a.textContent || "").length - (b.textContent || "").length);
                    const s0 = trFold(sorted[0].textContent).trim();
                    if (s0.length <= target.length + 6 && trFold(sorted[1].textContent).trim().length > s0.length) return sorted[0];
                    result = "multi"; // bu hedefte belirsiz → sıradaki hedefi dene
                }
            }
            }
            return null;
        };
        let node = await waitFor(() => { const d = findLovDialog(form, lovId); return (d && isVisible(d)) ? (finder() || null) : (bekleyinizVisible() ? null : null); }, 10000, 250);
        if (!node) {
            await waitBekleyinizGone();
            const d = findLovDialog(form, lovId);
            if (false && (!d || !isVisible(d)) && !retyped) { dbg("Gereği listesi açılmadı → terim yeniden yazılıyor:", query); return gerekTryLov(form, inp, lovId, query, full, true); }
            node = await waitFor(finder, 10000, 250);
        }
        if (!node) return result || "none";
        // v3.6.7: liste oturana ve AJAX bitene kadar bekle, düğümü yeniden bul (yavaş bağlantıda DOM yenilenebilir)
        await sleep(900);
        await waitFor(() => !isAjaxBusy(), 8000, 200);
        let clickTarget = node.closest(".ui-treenode-content") || node;
        { const n2 = finder(); if (n2) clickTarget = n2.closest(".ui-treenode-content") || n2; }
        // v3.6.10: seçim yöntemleri sırayla denenir; "Direkt Gönder" uyarısı için 15 sn'lik genel izleyici başlatılır
        startDirektWatch(15000);
        let ok = false;
        {
            // v3.6.16: Gereği'nde TEK seçim eylemi (insan gibi tek tıklama) → örtü bitene kadar bekle → gerekirse TEK "Tamam"; yeniden tıklama / ek yöntem YOK
            const pr = await gerekSelectOnce(() => { const n = finder(); return n ? (n.closest(".ui-treenode-content") || n) : null; }, () => !!lovSelectedTitle(form, lovId) || direktBusy || !!findDirektGonder(), () => findLovDialog(form, lovId));
            if (pr.ok) ok = !!(await waitFor(() => lovSelectedTitle(form, lovId), 70000, 300)); // uyarı tıklanınca seçim yazılır
        }
        return ok ? "ok" : "none";
    }
    // NEW (v3.6.6): Cevap Yaz → "Kaldırılacak Klasörler" = Konu Kodu ile BİREBİR aynı kod. Kod önce Konu Kodu kutusundan okunur (yoksa evrak numarasındaki
    // konu kodu kullanılır ve Konu Kodu da onunla seçilir); klasör seçildikten sonra kod karşılaştırılır, farklıysa uyarılır.
    const lovIdOfInput = inp => inp.id.replace(/:LovText$/, "").split(":").pop();
    function findLovInputByLabel(scope, re, idRe) {
        const inputs = Array.from(scope.querySelectorAll('input[id$=":LovText"]'));
        for (const inp of inputs) {
            if (/akis(Adim)?Lov/i.test(inp.id)) continue;
            let el = inp;
            for (let i = 0; i < 8 && el.parentElement; i++) {
                el = el.parentElement;
                if (el.querySelectorAll('input[id$=":LovText"]').length > 1) break; // başka satıra taştı
                if (re.test(trFold(el.textContent || "").replace(/\s+/g, " ").trim())) return inp;
            }
        }
        return inputs.find(i => idRe.test(i.id) && !/akis/i.test(i.id)) || null;
    }
    const codeRegex = c => new RegExp("(^|[^0-9.])" + String(c).replace(/\./g, "\\.") + "(?![0-9]|\\.[0-9])");
    async function fillKlasorFromKonuKodu(docNo) {
        const scope = cevapScopeEl();
        if (!scope) return { ok: false, why: "Cevap Yaz penceresi bulunamadı" };
        const tab = findLeftTabButton("Bilgileri");
        if (tab) { tab.click(); await sleep(400); }
        const kInp = await waitFor(() => scope.querySelector('input[id$=":eklenecekKlasorlerLov:LovText"]') || findLovInputByLabel(scope, /^kaldirilacak\s*klasor/, /eklenecekKlasor/i), 8000, 200);
        if (!kInp) return { ok: false, why: "'Kaldırılacak Klasörler' alanı bulunamadı" };
        const form = kInp.closest("form") || scope, kId = lovIdOfInput(kInp);
        const cInp = scope.querySelector('input[id$=":konuKoduLov:LovText"]') || findLovInputByLabel(scope, /^konu\s*kodu/, /konuKodu/i);
        const cId = cInp ? lovIdOfInput(cInp) : "";
        const readCode = () => {
            if (!cInp) return "";
            const det = lovSelectedDetail(form, cId).match(/\d+(?:\.\d+)*/);
            if (det) return det[0];
            const t = lovSelectedTitle(form, cId);
            const m = t && t.match(/(?<![\d.])\d{2,3}(?:\.\d+){0,3}(?![\d])/);
            return m ? m[0] : "";
        };
        let code = await waitFor(() => readCode() || null, 6000, 250);
        if (!code) {
            const fromNo = ((docNo || "").match(/^E-\d+-([\d.]+)-\d+$/) || [])[1] || "";
            if (fromNo && cInp) { await fillLov(form, cId, fromNo); code = readCode() || fromNo; }
        }
        if (!code) return { ok: false, why: "Konu kodu okunamadı" };
        const sel = () => lovSelectedTitle(form, kId);
        const same = () => codeRegex(code).test(sel());
        if (sel()) return same() ? { ok: true, skipped: true, code: code } : { ok: false, why: "Klasör kodu konu koduyla (" + code + ") aynı değil — mevcut klasör elle düzeltilmeli", diag: true };
        const inp = form.querySelector('[id$="' + kId + ':LovText"]') || kInp;
        try { inp.focus(); } catch(e) {}
        setNativeValue(inp, code);
        ["keydown", "keyup"].forEach(type => {
            let ev; try { ev = new KeyboardEvent(type, { bubbles: true, cancelable: true, key: code.slice(-1), code: "Digit0", keyCode: 48, which: 48 }); } catch(e) { ev = new Event(type, { bubbles: true }); }
            try { if (!ev.keyCode) Object.defineProperty(ev, "keyCode", { get: () => 48 }); } catch(e) {}
            inp.dispatchEvent(ev);
        });
        const re = codeRegex(code);
        let multi = false;
        const dlgOf = () => findLovDialog(form, kId);
        // sonuç öğeleri: önce .lovItemTitle (başlık + "[Klasör] kod" ayrıntısı aynı kapta), yoksa ağaç düğümleri
        const findItem = () => {
            const dlg = dlgOf();
            if (!dlg || !isVisible(dlg)) return null;
            let cands = [];
            dlg.querySelectorAll(".lovItemTitle").forEach(t => { if (isVisible(t)) { const bx = t.closest(".ui-treenode-content") || t.closest("tr, li.ui-autocomplete-item, li[data-item-value]") || t.parentElement; cands.push({ el: t, txt: ((bx && bx.textContent) || t.textContent || "") }); } });
            if (!cands.length) dlg.querySelectorAll(".ui-treenode-label, .ui-treenode-content").forEach(t => { if (isVisible(t) && (t.textContent || "").trim()) cands.push({ el: t.closest(".ui-treenode-content") || t, txt: t.textContent || "" }); });
            if (!cands.length) dlg.querySelectorAll("tr[data-ri], tr[data-rk], li.ui-autocomplete-item, li[data-item-value]").forEach(t => { if (isVisible(t) && (t.textContent || "").trim()) cands.push({ el: t, txt: t.textContent || "" }); });
            lovCaptureHtml(dlg);
            const hits = cands.filter(c => re.test(c.txt));
            if (!hits.length) return null;
            const exactC = hits.filter(c => lovItemCode(c.el) === code); // v3.6.52: "[Klasör] kod" tam eşit olan öncelikli
            const klas = exactC.length ? exactC : hits.filter(c => new RegExp("klasor\\]?\\s*" + code.replace(/\./g, "\\.") + "(?![0-9])").test(trFold(c.txt)));
            const pool = klas.length ? klas : hits;
            multi = pool.length > 1;
            return pool.slice().sort((x, y) => x.txt.length - y.txt.length)[0].el;
        };
        const node = await waitFor(findItem, 20000, 250);
        if (!node) return { ok: false, why: "'" + code + "' kodlu klasör listede bulunamadı", diag: true };
        // liste oturana ve AJAX bitene kadar bekle; yavaş bağlantıda tıklama kayıt olmayabilir → yeniden dene
        await sleep(400); // v3.6.25: 900→400
        await waitFor(() => !isAjaxBusy(), 8000, 200);
        const pr = await lovClickStrategies(findItem, () => !!sel(), "Klasör", dlgOf);
        if (!pr.ok) return { ok: false, why: "klasör seçilemedi (" + code + "); denenen: " + pr.tried.join(", "), diag: true };
        if (!same()) return { ok: false, why: "seçilen klasör kodu konu koduyla (" + code + ") aynı değil: " + sel().slice(0, 60), diag: true };
        return { ok: true, code: code, multi: multi };
    }
    // ---- v3.6.10: LoV öğe seçimi — yöntemler sırayla; her biri sonrası seçili kutu doğrulanır
    let lastPickInfo = "", lastLovHtml = "", pickSeq = 0; const lovHtmlById = {};
    // v3.6.12: aynı id'li LoV pencerelerinden GÖRÜNÜR olanı (body'ye taşınmış) döndürür; tüm aynı-origin çerçevelere bakar
    function findLovDialog(scope, lovId) {
        let hidden = null;
        const seen = new Set();
        const roots = [scope || document].concat(getAllDocs());
        for (const r of roots) {
            let list; try { list = r.querySelectorAll('[id$="lovDialogId"]'); } catch(e) { continue; }
            for (const d of list) {
                if (seen.has(d)) continue; seen.add(d);
                if (!String(d.id).includes(":" + lovId + ":") && !String(d.id).startsWith(lovId + ":")) continue;
                if (isVisible(d)) return d;
                hidden = hidden || d;
            }
        }
        return hidden;
    }
    function lovCaptureHtml(dlg) {
        try {
            const list = dlg.querySelector(".ui-dialog-content") || dlg;
            const h = (list.outerHTML || "").replace(/\s+/g, " ");
            if (h.length > 200) { lastLovHtml = h.slice(0, 1500); lovHtmlById[String(dlg.id || "?").split(":").slice(-2).join(":")] = lastLovHtml; }
        } catch(e) {}
    }
    const nodeHighlighted = n => { const c = n && n.closest && (n.closest(".ui-treenode-content") || (n.closest("li.ui-treenode") && n.closest("li.ui-treenode").querySelector(".ui-treenode-content"))); return !!(c && (c.classList.contains("ui-state-highlight") || c.getAttribute("aria-selected") === "true")); };
    function lovOkButton(dlg) {
        if (!dlg) return null;
        return Array.from(dlg.querySelectorAll("button, a.ui-button, input[type=button]")).find(b => isVisible(b) && !isForbiddenEl(b) && /^(tamam|sec|ekle|uygula)$/.test(trFold((b.value || b.textContent || "").trim()))) || null;
    }
    // v3.6.13: "Lütfen Bekleyiniz" kesin bitişi — en az 800 ms kesintisiz gizli olmalı (yeniden yanıp sönebilir)
    function bekleyinizVisible() {
        for (const d of direktDocs()) {
            try {
                const b = d.getElementById("bekleyinizStatusDialog");
                if (!b || !isVisible(b) || b.getAttribute("aria-hidden") === "true") continue;
                const cs = (b.ownerDocument.defaultView || window).getComputedStyle(b), r = b.getBoundingClientRect();
                if (cs.display !== "none" && cs.visibility !== "hidden" && r.width > 0 && r.height > 0) return true;
            } catch(e) {}
        }
        return isAjaxBusy();
    }
    async function waitBekleyinizGone(maxMs = 20000) {
        const t0 = Date.now(); let clearSince = 0;
        while (Date.now() - t0 < maxMs) {
            autoCheck();
            if (capExpired()) return false;
            if (bekleyinizVisible()) clearSince = 0;
            else { if (!clearSince) clearSince = Date.now(); if (Date.now() - clearSince >= 800) { stepLog("waitBekleyinizGone " + stepWhere(3), t0, "ok"); return true; } }
            await sleep(150);
        }
        stepLog("waitBekleyinizGone " + stepWhere(3) + " (" + maxMs + ")", t0, "ZAMAN AŞIMI");
        return false;
    }
    async function lovClickStrategies(findNode, verify, label, dlgGet) {
        const tried = [];
        const anc = n => (n.closest && n.closest('tr[data-ri], tr[data-rk], .ui-treenode-content, li.ui-treenode, li, a, [onclick]')) || n;
        const mark = el => { const t = "p" + (++pickSeq) + "_" + Date.now(); el.setAttribute("data-ebys-pick", t); return t; };
        const strategies = [
            // 1. tercih: evrak kapatmada (fillLov) gerçek EBYS'de çalışan yöntem — ağaç düğümünün .ui-treenode-content kabına yerel .click()
            ["kapatma yöntemi (.ui-treenode-content click)", n => { const tn = n.closest && n.closest(".ui-treenode"); const t = (n.closest && n.closest(".ui-treenode-content")) || (tn && tn.querySelector(".ui-treenode-content")) || n; if (isForbiddenEl(t)) throw new Error("Onay Akışı"); autoCheck(); t.click(); }],
            ["öğe tıklama", n => userClick(n)],
            ["satır tıklama", n => userClick(anc(n))],
            ["iç hücre tıklama", n => { const a = anc(n); userClick(a.querySelector("td, .ui-treenode-label, .lovItemTitle, span") || a); }],
            ["çift tıklama", n => { const a = anc(n); userClick(a); const W = a.ownerDocument.defaultView || window; a.dispatchEvent(new W.MouseEvent("dblclick", { bubbles: true, cancelable: true, view: W, button: 0 })); }],
            ["jQuery (sayfa)", async n => { const r = await bridgeCall("pfClick", { tok: mark(anc(n)), mode: "jq" }, 3000); if (!r || !r.ok) throw new Error("köprü: " + ((r && r.error) || "yanıt yok")); }],
            ["PrimeFaces widget", async n => { const r = await bridgeCall("pfClick", { tok: mark(anc(n)), mode: "widget" }, 3000); if (!r || !r.ok) throw new Error("widget: " + ((r && r.via) || (r && r.error) || "yanıt yok")); }],
        ];
        for (const [name, fn] of strategies) {
            autoCheck();
            if (verify()) { lastPickInfo = label + ": seçildi (" + (tried[tried.length - 1] || "önceden") + ")"; return { ok: true, via: tried[tried.length - 1] || "-", tried }; }
            await waitFor(() => !isAjaxBusy(), 20000, 250);
            const n = await waitFor(() => findNode() || (verify() ? "VERIFIED" : null), 4000, 150); // v3.6.25: 10→4 sn, seçim görünürse hemen
            if (n === "VERIFIED") { lastPickInfo = label + ": seçildi (" + (tried[tried.length - 1] || "önceden") + ")"; return { ok: true, via: tried[tried.length - 1] || "-", tried }; }
            if (!n) { if (verify()) return { ok: true, via: tried[tried.length - 1] || "-", tried }; tried.push(name + " (öğe yok)"); break; }
            if (isForbiddenEl(n)) { tried.push("Onay Akışı engeli"); break; }
            if (nodeHighlighted(n)) { tried.push(name + " (zaten vurgulu, tıklanmadı)"); }
            else try { await fn(n); tried.push(name); } catch(e) { if (e && e.ebysStop) throw e; tried.push(name + " (" + (e && e.message || "hata") + ")"); continue; }
            await sleep(500);
            // çoklu seçimli ağaç: vurgulandıysa penceredeki "Tamam"a bas
            let okClicked = false;
            const okStep = () => {
                if (verify()) return true;
                if (!okClicked && dlgGet && !isAjaxBusy()) {
                    const d = dlgGet(), n2 = findNode();
                    const b = d && isVisible(d) ? lovOkButton(d) : null;
                    if (b && (!n2 || nodeHighlighted(n2) || d.querySelector(".ui-state-highlight, [aria-selected=true]"))) { okClicked = true; tried.push("Tamam"); try { b.click(); } catch(e) {} }
                }
                return false;
            };
            // v3.6.25: başarı = seçili kutuda görünür (güncel okuyucu) VEYA Tamam'dan sonra pencere kapandı ve örtü yok. Örtü sürerken beklenir;
            // örtü yokken 4 sn sonra (eskiden sabit 9 sn) sonraki yönteme geçilir (en çok 30 sn).
            const dlgClosedAfterOk = () => { if (!okClicked || !dlgGet || bekleyinizStrict()) return false; const d = dlgGet(); return !d || !isVisible(d); };
            const okT0 = Date.now(), okW = stepWhere(2);
            let okRes = false;
            while (Date.now() - okT0 < 30000) {
                autoCheck();
                if ((!isAjaxBusy() && okStep()) || verify() || dlgClosedAfterOk()) { okRes = true; break; }
                if (Date.now() - okT0 > 4000 && !bekleyinizStrict()) break;
                await new Promise(r => setTimeout(r, 150));
            }
            stepLog("Klasör onay bekleme " + okW, okT0, okRes ? "ok" : "ZAMAN AŞIMI");
            if (okRes) { lastPickInfo = label + ": '" + name + "' yöntemiyle seçildi"; dbg(lastPickInfo); return { ok: true, via: name, tried }; }
        }
        lastPickInfo = label + ": seçilemedi; denenen: " + tried.join(", ");
        return { ok: false, tried };
    }
    // ---- v3.6.10: genel "Direkt Gönder" izleyicisi (15 sn, tüm çerçeveler + üst pencere; Durdur ile iptal)
    let direktWatchTimer = null, direktWatchUntil = 0, direktDoneAt = 0;
    function startDirektWatch(ms) {
        direktWatchUntil = Math.max(direktWatchUntil, Date.now() + ms);
        if (direktWatchTimer) return;
        direktWatchTimer = setInterval(() => {
            if (AUTO.stop || Date.now() > direktWatchUntil) { clearInterval(direktWatchTimer); direktWatchTimer = null; return; }
            if (direktBusy) return;
            tryClickDirekt().then(r => { if (r) { try { showToast("✅ Adım 3/3: uyarıda 'Direkt Gönder' seçildi.", "ok"); } catch(e) {} direktWatchUntil = Date.now() + 4000; direktDoneAt = Date.now(); } }).catch(() => {});
        }, 50); // v3.6.23: 300→50 ms — uyarı görünür görünmez 'Direkt Gönder' (yalnızca Gereği bu izleyiciyi başlatır)
    }
    // v3.6.9: "Gereği Seçim Tipi" → "Birim" (zaten Birim ise dokunulmaz). PrimeFaces selectOneMenu (gizli <select>) ya da yerel <select>.
    async function setGeregiSecimTipiBirim(scope) {
        let sel = null;
        for (const s of scope.querySelectorAll("select")) {
            let el = s, hit = false;
            for (let i = 0; i < 6 && el.parentElement && !hit; i++) { el = el.parentElement; if (el.querySelectorAll("select").length > 1) break; if (/geregi\s*secim\s*tipi/.test(trFold(el.textContent || ""))) hit = true; }
            if (hit || /gere[gk]i?.*secim|geregiSecimTipi/i.test(s.id || "")) { sel = s; break; }
        }
        if (!sel) return false;
        const opt = Array.from(sel.options).find(o => /^birim$/.test(trFold(o.textContent || "").trim()));
        if (!opt) return false;
        if (sel.value === opt.value) return true;
        const wrap = sel.closest(".ui-selectonemenu");
        { // v3.6.17: görünen etiket / seçili seçenek zaten "Birim" ise HİÇBİR ŞEY yapılmaz
            const so = sel.options[sel.selectedIndex];
            const lab = wrap && wrap.querySelector(".ui-selectonemenu-label");
            if ((so && /^birim$/.test(trFold(so.textContent || "").trim())) || (lab && /^birim$/.test(trFold(lab.textContent || "").trim()))) return true;
        }
        if (wrap && isVisible(wrap)) {
            try { userClick(wrap.querySelector(".ui-selectonemenu-trigger") || wrap); } catch(e) {}
            const pid = (wrap.id || "") + "_panel";
            const li = await waitFor(() => { const pn = document.getElementById(pid) || document; return Array.from(pn.querySelectorAll(".ui-selectonemenu-item, li")).find(l => isVisible(l) && /^birim$/.test(trFold(l.textContent || "").trim())); }, 5000, 200);
            if (li) { try { userClick(li); } catch(e) { li.click(); } }
        }
        if (sel.value !== opt.value) { sel.value = opt.value; sel.dispatchEvent(new Event("change", { bubbles: true })); }
        await sleep(600);
        await waitFor(() => !isAjaxBusy(), 15000, 250);
        return sel.value === opt.value;
    }
    // v3.6.17: Gereği = Kaldırılacak Klasörler ile BİREBİR aynı yol (canlıda her seferinde çalışan): aynı yazma/tetikleme (setNativeValue + keydown/keyup),
    // aynı bekleme (20 sn liste, 900 ms oturma, AJAX bitişi), aynı findLovDialog, aynı lovClickStrategies (tıklama + vurgu + Tamam). Ayrı Gereği arama/seçim/örtü kodu kaldırıldı.
    // Fark yalnızca: alan kimliği (geregiLov), arama terimi (" / " öncesi kurum adı) ve eşleşme (etiketi kuruma eşit/ kurumu içeren seçilebilir düğüm, ağacın herhangi bir yerinde).
    async function fillGerekFromSender(sender) {
        lastGerekFailed = false;
        const r = await fillGerekLikeKlasor(sender);
        if (r && !r.ok && !cevapScopeEl()) return { ok: true, skipped: true, note: "form kapandı / sonraki ekrana geçildi" };
        if (!r || !r.ok) lastGerekFailed = true;
        return r;
    }
    // v3.6.17: karakter karakter yazım — odak, temizle, her harf için keydown → keypress → değer += harf → input → keyup, 80–120 ms aralık
    async function typeLikeHuman(inp, text) {
        const W = inp.ownerDocument.defaultView || window;
        const setV = v => { try { const d = Object.getOwnPropertyDescriptor(W.HTMLInputElement.prototype, "value"); if (d && d.set) d.set.call(inp, v); else inp.value = v; } catch(e) { inp.value = v; } };
        const key = (type, ch, kc) => {
            let ev; try { ev = new W.KeyboardEvent(type, { bubbles: true, cancelable: true, key: ch, keyCode: kc, which: kc, charCode: type === "keypress" ? ch.charCodeAt(0) : 0 }); } catch(e) { ev = new W.Event(type, { bubbles: true }); }
            try { if (ev.keyCode !== kc) Object.defineProperty(ev, "keyCode", { get: () => kc }); if (ev.which !== kc) Object.defineProperty(ev, "which", { get: () => kc }); } catch(e) {}
            return inp.dispatchEvent(ev);
        };
        try { inp.focus(); } catch(e) {}
        if (inp.value) { setV(""); try { inp.dispatchEvent(new W.Event("input", { bubbles: true })); } catch(e) {} }
        for (const ch of Array.from(text)) {
            autoCheck();
            const up = ch.toLocaleUpperCase("tr-TR");
            const kc = ch === " " ? 32 : /[0-9]/.test(ch) ? ch.charCodeAt(0) : /[A-Z]/.test(up) ? up.charCodeAt(0) : 0;
            key("keydown", ch, kc);
            key("keypress", ch, kc);
            setV(inp.value + ch);
            try { inp.dispatchEvent(new W.InputEvent("input", { bubbles: true, data: ch, inputType: "insertText" })); } catch(e) { try { inp.dispatchEvent(new W.Event("input", { bubbles: true })); } catch(x) {} }
            key("keyup", ch, kc);
            await sleep(80 + Math.floor(Math.random() * 41));
        }
    }
    // v3.6.19: kaydedici (sayfa dünyası köprüsünde; yalnızca üst pencerede)
    let recActive = false, recStopReq = false;
    async function runGerekRecorder(btn) {
        if (recActive) { recStopReq = true; return; } // ikinci basış: kaydı bitir
        if (!(await bridgeAvailable())) { showToast("⚠️ Kayıt için sayfa köprüsü yok (sayfayı F5 ile yenileyin).", "warn"); return; }
        const st = await bridgeCall("recStart", { ms: 61000, label: "elle" }, 2000);
        const bid = st && st.bid;
        recActive = true; recStopReq = false;
        const old = btn.textContent;
        showToast("🎥 Kayıt başladı: Gereği alanına kurum adını yazıp listeden ELLE seçin. Bitirmek için düğmeye tekrar basın.", "info");
        const t0 = Date.now();
        let r = null, reason = "süre";
        try {
            while (Date.now() - t0 < 60000) {
                btn.textContent = "⏺ Kaydediliyor… " + Math.max(0, 60 - Math.floor((Date.now() - t0) / 1000)) + " sn (bitir)";
                await new Promise(res => setTimeout(res, 500));
                if (recStopReq) { reason = "kullanıcı"; break; }
                const g = await bridgeCall("recGet", { bid: bid }, 1500);
                if (g && g.text) r = g;
                if (g && g.promptSeen) { reason = "uyarı"; break; } // YALNIZCA uyarı penceresi kaydı bitirir
            }
            const f = await bridgeCall("recGet", { stop: true, label: "elle", bid: bid }, 2000);
            if (f && f.text) r = f;
        } finally { recActive = false; btn.textContent = old; }
        const text = "Evrak Asistanı " + EXT_VERSION + " — Gereği elle seçim kaydı (bitiş: " + reason + ", " + Math.round((Date.now() - t0) / 1000) + " sn)\n" + ((r && r.text) || "(kayıt boş)");
        console.log("[Evrak Asistanı]", text);
        const ok = await copyToClipboard(text);
        showToast(ok ? "✔️ Kopyalandı — kaydı bana yapıştırın." : "⚠️ Panoya kopyalanamadı; rapor kutuda.", ok ? "ok" : "warn");
        showDiagBox(text);
    }
    // v3.6.54: tanı için görünür EBYS pencerelerinin başlıkları (en çok 4)
    function visibleDialogTitles() {
        const out = [];
        for (const d of direktDocs()) {
            try { d.querySelectorAll(".ui-dialog").forEach(x => { if (out.length < 4 && isVisible(x) && !isPanelEl(x)) { const t = x.querySelector(".ui-dialog-title"); out.push(((t && t.textContent) || x.id || "?").replace(/\s+/g, " ").trim().slice(0, 40)); } }); } catch(e) {}
        }
        return out.length ? out.join(" | ") : "-";
    }
    // v3.6.57: EBYS isteklerini PASİF izle (köprü jQuery ajaxSend/ajaxComplete) — günlüğe başlangıç/bitiş + kaynak id yazılır
    let ajaxSeen = 0;
    async function ajaxPoll() {
        try {
            const r = await bridgeCall("ajaxState", { since: ajaxSeen }, 1500);
            if (!r || !r.ok) return null;
            for (const x of r.log || []) { ajaxSeen = Math.max(ajaxSeen, x.t); stepMark("istek " + x.k + ": " + String(x.s).replace(/^windowCevapEvrakForm:(evrakBilgileriList:\d+:)?/, "").slice(0, 70)); }
            return r;
        } catch(e) { return null; }
    }
    // bekleyen istek 0 ve quietMs boyunca YENİ istek yok (otomatik tamamlama ~1,5 sn gecikmeyle gönderiliyor)
    // v3.6.57: tıklamadan sonra giden istek(ler) için TEK özet satırı (kaynak, olay, güncellenenler, süre, durum)
    async function clickReqSummary(sinceT, label) {
        try {
            const r = await bridgeCall("ajaxState", { since: ajaxSeen, reqSince: sinceT }, 1500);
            if (!r || !r.ok) { stepMark(label + ": izlenemedi (" + ((r && r.error) || "köprü yok") + ")"); return; }
            const short = x => String(x || "").replace(/windowCevapEvrakForm:(evrakBilgileriList:\d+:)?/g, "").replace(/\s+/g, " ").trim();
            const rs = r.reqs || [];
            if (!rs.length) { stepMark(label + ": istek gönderilmedi"); return; }
            stepMark(label + ": " + rs.slice(0, 4).map(q => "kaynak=" + short(q.s).slice(0, 40) + (q.e ? " e=" + q.e : "") + (q.u ? " u=" + short(q.u).slice(0, 60) : "") + " süre=" + ((q.end || r.now) - q.t) + "ms durum=" + (q.end ? q.status : "cevap yok")).join(" | ") + (rs.length > 4 ? " (+" + (rs.length - 4) + ")" : ""));
        } catch(e) {}
    }
    async function ajaxQuiet(quietMs, maxMs, label) {
        const t0 = Date.now(); let ok = false, r = null;
        while (Date.now() - t0 < maxMs) {
            autoCheck();
            r = await ajaxPoll();
            if (!r) { ok = await ebysIdleFor(quietMs, Math.max(500, maxMs - (Date.now() - t0))); break; } // köprü yoksa örtü tabanlı
            if (r.pending === 0 && r.quietMs >= quietMs && !bekleyinizStrict()) { ok = true; break; }
            await sleep(150);
        }
        stepLog(label || "EBYS istekleri sakin", t0, ok ? "ok" : "ZAMAN AŞIMI");
        return ok;
    }
    async function gerekPickOnce(findItem, verify, dlgOf) {
        const tried = [];
        // v3.6.56 (v3.6.28'de çalışan yol): tıklamadan önce örtü 800 ms KESİNTİSİZ kapalı + AJAX boşta, sonra düğüm YENİDEN bulunur
        // v3.6.57 (elle kayıt + kullanıcı gözlemi): yazımdan ~1,5 sn sonra gelen otomatik tamamlama isteği seçim isteğiyle ÇAKIŞMASIN —
        // bekleyen istek 0 ve 1,8 sn hiç yeni istek yok + örtü kapalı olana dek beklenir, sonra düğüm yeniden bulunur
        { const tS = Date.now(); const idle = await ebysIdleFor(800, 8000); stepLog("Gereği tıklama öncesi sakinlik", tS, idle ? "ok" : "ZAMAN AŞIMI"); }
        await ajaxQuiet(1800, 12000, "Gereği: otomatik tamamlama isteği bitti mi");
        await waitFor(() => !isAjaxBusy(), 3000, 100);
        const n = findItem();
        if (!n) return { ok: false, tried: ["öğe yok"] };
        const c = (n.closest && n.closest(".ui-treenode-content")) || n;
        const li = c.closest && c.closest("li.ui-treenode"), tree = c.closest && c.closest(".ui-tree");
        if (isForbiddenEl(c)) return { ok: false, tried: ["Onay Akışı engeli"] };
        autoCheck();
        // v3.6.56: CANLI KÖK NEDEN (3.6.55 raporu) — ilk açılışta köprüden programatik PrimeFaces selectNode/select olayı EBYS isteğini
        // asılı bırakıyor ('Lütfen Bekleyiniz' hiç kapanmıyor). Artık Klasör'de çalışan ve kullanıcının elle yaptığı yol: görünür düğümün
        // .ui-treenode-content öğesine TEK insan tıklaması (pointer/mouse down-up-click). PrimeFaces API'si yalnızca bu sayfada Gereği
        // daha önce başarıyla seçildiyse VE doğal tıklama 5 sn içinde hiçbir şey başlatmadıysa (örtü yok, seçim yok) yedek olarak denenir.
        const desc = el => { try { const lb = el.querySelector && (el.querySelector(".lovItemTitle") || el.querySelector(".ui-treenode-label")); return el.tagName.toLowerCase() + "." + String(el.className || "").trim().split(/\s+/).slice(0, 3).join(".") + (li ? " (li " + (li.classList.contains("ui-treenode-leaf") ? "yaprak" : "üst") + ")" : "") + " '" + String((lb || el).textContent || "").replace(/\s+/g, " ").trim().slice(0, 45) + "'"; } catch(e) { return "?"; } };
        if (c.classList && c.classList.contains("ui-state-highlight") && verify()) { stepMark("Gereği zaten seçili: " + desc(c)); return { ok: true, tried: ["zaten seçili"] }; }
        // v3.6.57: kullanıcı gibi etiketin içindeki .lovItemDetail / .lovItemTitle öğesine (olay .ui-treenode-content'e kabarır) TEK tıklama
        const tgt = (c.querySelector && (c.querySelector(".ui-treenode-label .lovItemDetail") || c.querySelector(".ui-treenode-label .lovItemTitle") || c.querySelector(".ui-treenode-label"))) || c;
        try { const selIn = tree && tree.querySelector('input[id$="_selection"]'); tried.push("seçim alanı önce='" + (selIn ? selIn.value : "?") + "'"); } catch(e) {}
        tried.push("doğal tıklama → " + desc(c) + " hedef=" + (tgt.tagName || "").toLowerCase() + "." + String(tgt.className || "").split(/\s+/)[0]);
        await ajaxPoll();
        const clickT = Date.now();
        userClick(tgt);
        stepMark("Gereği seçim: " + tried.join(" + "));
        let r = null, sawReq = false;
        // uyarı ("Lütfen seçim yapınız" → Direkt Gönder) ya da seçim görünene kadar; örtü 25 sn'yi aşarsa TAKILMA → temiz dur, tıklama tekrarlanmaz
        const t0 = Date.now();
        let ok = false, ovSince = 0, sawOverlay = false, pfTried = false;
        let lastLog = 0;
        while (Date.now() - t0 < 40000) {
            autoCheck();
            if (verify()) { ok = true; break; }
            { const ar = await ajaxPoll(); if (ar && (ar.log || []).length) sawReq = true; }
            const ov = bekleyinizVisible();
            if (ov) { sawOverlay = true; if (!ovSince) ovSince = Date.now(); } else ovSince = 0;
            if (Date.now() - lastLog > 2000) { lastLog = Date.now(); try { stepMark("Gereği bekleme +" + Math.round((Date.now() - t0) / 1000) + " sn: örtü=" + (ov ? "var" : "yok") + ", Direkt Gönder=" + (findDirektGonder() ? "görünür" : "yok") + ", açık pencereler=" + visibleDialogTitles()); } catch(e) {} }
            if (ovSince && Date.now() - ovSince > 24000) { await clickReqSummary(clickT, "Tıklama sonrası istek"); stepMark("Gereği: örtü 24 sn'yi aştı — TAKILMA, durduruluyor"); lastPickInfo = "Gereği: takıldı (" + tried.join(" + ") + ")"; return { ok: false, hang: true, tried }; }
            if (!ov && !sawOverlay && !sawReq && !pfTried && gerekPfTrusted && Date.now() - t0 > 5000) {
                // doğal tıklama hiçbir istek başlatmadı → yalnızca daha önce bu sayfada başarı varsa PrimeFaces yedeği
                pfTried = true;
                const n2 = findItem(); const c2 = n2 && n2.closest ? (n2.closest(".ui-treenode-content") || n2) : null;
                const li2 = c2 && c2.closest("li.ui-treenode"), tree2 = c2 && c2.closest(".ui-tree");
                const tok = "p" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
                try { if (li2) li2.setAttribute("data-ea-pick-li", tok); if (tree2) tree2.setAttribute("data-ea-pick-tree", tok); } catch(e) {}
                try { if (li2 && li2.id && tree2 && tree2.id && window.self === window.top) r = await bridgeCall("treeSelectSingle", { treeId: tree2.id, liId: li2.id, tok: tok }, 4000); } catch(e) {}
                finally { try { if (li2) li2.removeAttribute("data-ea-pick-li"); if (tree2) tree2.removeAttribute("data-ea-pick-tree"); } catch(e) {} }
                tried.push("PrimeFaces yedeği " + (r && r.via ? r.via : "(" + ((r && r.error) || "köprü yok") + ")"));
                stepMark("Gereği seçim: " + tried.join(" + "));
            }
            if (!ov && Date.now() - t0 > 15000) break; // örtü yok ve 15 sn geçti → sonuç gelmedi
            await sleep(250);
        }
        if (ok) gerekPfTrusted = true;
        await clickReqSummary(clickT, "Tıklama sonrası istek");
        if (!ok) {
            const d = dlgOf(), b = d && isVisible(d) ? lovOkButton(d) : null;
            if (b && !bekleyinizVisible()) { tried.push("Tamam"); b.click(); ok = !!(await waitFor(() => verify(), 8000, 250)); }
        }
        lastPickInfo = "Gereği: " + (ok ? "seçildi" : "seçilemedi") + " (" + tried.join(" + ") + ")";
        return { ok, tried };
    }
    async function fillGerekLikeKlasor(sender) {
        lastAutoRec = "";
        let recOn = false;
        try { if (window.self === window.top && await bridgeAvailable()) { const rs = await bridgeCall("recStart", { ms: 90000, label: "otomatik", ifIdle: true }, 1500); recOn = !!(rs && !rs.skipped); } } catch(e) {}
        try { return await fillGerekLikeKlasor_(sender); }
        finally { if (recOn) { try { const r = await bridgeCall("recGet", { stop: true, label: "otomatik" }, 2000); lastAutoRec = (r && r.text) || ""; } catch(e) {} } }
    }
    async function fillGerekLikeKlasor_(sender) {
        // v3.6.21: önceki EBYS isteği 20 sn'den uzun sürüyorsa HİÇBİR çağrı yapmadan temiz iptal
        if (bekleyinizStrict() && !(await waitBekleyinizGone(20000))) return { ok: false, why: "EBYS'nin bekleyen isteği 20 sn'den uzun sürdü; Gereği'ne dokunulmadı (gerekirse sayfayı F5 ile yenileyin)", nodiag: false };
        const scope = cevapScopeEl();
        if (!scope) return { ok: false, why: "Cevap Yaz penceresi bulunamadı" };
        const tab = findLeftTabButton("Bilgileri");
        // v3.6.57: sekme zaten seçiliyse BASILMAZ (elle kayıtta kullanıcı basmıyor; basmak sekmeyi AJAX'la yeniden çizdiriyor)
        if (tab && !(tab.closest && tab.closest("td.tabMenuContainerSelected"))) { tab.click(); await sleep(200); }
        // FIX (v3.6.37): oturumdaki İLK Cevap Yaz'da "Bilgileri" sekmesi ve Gereği LOV'u AJAX ile tembel yükleniyor; eski kod 200 ms sonra
        // bulduğu (sonra AJAX'la DEĞİŞTİRİLEN) girdiye yazıyordu → arama hiç tetiklenmiyor ya da sonuç gizli diyaloğa düşüyordu. Artık: AJAX bitişi +
        // girdinin 3 ardışık yoklamada aynı ve bağlı kalması beklenir (en çok 12 sn).
        await waitFor(() => !isAjaxBusy() && !bekleyinizStrict(), 8000, 100);
        const findG = () => scope.querySelector('input[id$=":geregiLov:LovText"]') || findGerekInput(scope);
        let gInp = null;
        { let last = null, same = 0; const t0 = Date.now();
          while (Date.now() - t0 < 12000) { autoCheck(); const x = findG(); if (x && x === last && x.isConnected && isVisible(x) && !isAjaxBusy()) { if (++same >= 3) { gInp = x; break; } } else { same = 0; last = x; } await sleep(150); }
          if (!gInp) gInp = findG(); stepLog("Gereği alanı hazır", t0, gInp ? "ok" : "YOK"); }
        if (!gInp) return { ok: false, why: "'Gereği' alanı bulunamadı" };
        const form = gInp.closest("form") || scope, gId = lovIdOfInput(gInp);
        // Gereği Seçim Tipi: varsayılan zaten "Birim" — yalnızca FARKLIYSA değiştirilir (değişiklik AJAX başlatır)
        try { await setGeregiSecimTipiBirim(scope); } catch(e) { dbg("Gereği Seçim Tipi:", e); }
        const full = String(sender || "").replace(/\s+/g, " ").trim();
        const term = (full.split(/\s*\/\s*/).filter(Boolean)[0] || full).trim();
        if (term.length < 4) return { ok: false, why: "gönderen kurum adı okunamadı" };
        const sel = () => lovSelectedTitle(form, gId);
        if (sel()) return { ok: true, skipped: true };
        const dlgHasContent = () => { const d = findLovDialog(form, gId); return !!(d && d.querySelector(".ui-treenode-content, tr[data-ri], li.ui-autocomplete-item")); };
        const inp = form.querySelector('[id$="' + gId + ':LovText"]') || gInp;
        // v3.6.17: Gereği'nde İNSAN GİBİ klavye yazımı (yapıştırma yok, 'change' yok): kurum adı "… Müdürlüğü" olmadan yazılır, PrimeFaces kendi gecikmesiyle TEK arama yapar
        const typed = term.replace(/\s+m[uü]d[uü]rl[uü][gğ][uü](ne|n[uü]n)?\s*$/i, "").trim() || term;
        // FIX (v3.6.37): ilk yazımdan önce gerçek odak dizisi (mousedown → focus → mouseup → click) — PrimeFaces LOV'un keyup dinleyicisi ilk odakta bağlanıyor
        try { const W = inp.ownerDocument.defaultView || window; ["mousedown", "mouseup", "click"].forEach(t => { if (t === "mouseup") { try { inp.focus(); } catch(e) {} } inp.dispatchEvent(new W.MouseEvent(t, { bubbles: true, cancelable: true, view: W })); }); inp.dispatchEvent(new W.FocusEvent("focusin", { bubbles: true })); } catch(e) {}
        await sleep(250);
        try { const st = scope.querySelector('select[id*="eregiSecimTipi"], select[id*="secimTipi"]'); stepMark("Gereği yazılıyor: '" + typed + "' (Seçim Tipi=" + (st ? ((st.options[st.selectedIndex] || {}).text || st.value) : "?") + ", alan=" + gId + ")"); } catch(e) {}
        await typeLikeHuman(inp, typed);
        const nz = x => trFold(String(x || "")).replace(/\s+/g, " ").trim();
        const T = nz(term);
        const dlgOf = () => findLovDialog(form, gId);
        let hiddenSince = 0, showAsked = 0;
        const findItem = () => {
            const dlg = dlgOf();
            if (!dlg) return null;
            // FIX (v3.6.37): KÖK NEDEN — ilk kullanımda sonuç ağacı GİZLİ diyaloğa (display:none) yazılıyor, diyalog açılmıyordu (canlı rapor v3.6.14).
            // Gizli ama içi dolu diyalog 0,3 sn sürerse köprüyle PrimeFaces widget.show() istenir; 1,2 sn sonra hâlâ gizliyse düğümler gizli diyalogdan okunur.
            const vis = isVisibleOuter(dlg);
            if (!vis) {
                if (!dlg.querySelector(".ui-treenode-content, tr[data-ri], li.ui-autocomplete-item")) { hiddenSince = 0; return null; }
                // v3.6.53: CANLI KÖK NEDEN (3.6.52 tanı raporu) — gizli diyaloğu zorla göstermek ve gizli (dinamik, yüklenmemiş) ağaçta select
                // olayı tetiklemek EBYS isteğini yarıda bırakıyor, 'Lütfen Bekleyiniz' hiç kapanmıyordu. Artık gizli diyalog GÖSTERİLMEZ ve ondan
                // SEÇİLMEZ: arama bitmiş (örtü yok) ve sonuç 2,5 sn gizli kalıyorsa "HIDDEN" döner → bir kez yeniden yazılır, olmazsa temiz hata.
                if (bekleyinizStrict() || isAjaxBusy()) { hiddenSince = 0; return null; }
                if (!hiddenSince) hiddenSince = Date.now();
                return Date.now() - hiddenSince >= 2500 ? "HIDDEN" : null;
            }
            const isVisible = vis ? isVisibleOuter : (el => !!el && el.isConnected); // gizli diyalogda görünürlük süzgeci kapalı
            lovCaptureHtml(dlg);
            // ağacın herhangi bir yerindeki SEÇİLEBİLİR düğümler (üst düğüm "Birim" seçilebilir değilse elenir)
            let cands = [];
            dlg.querySelectorAll(".ui-treenode-content").forEach(c => {
                if (!isVisible(c)) return;
                const li = c.closest("li.ui-treenode");
                const selectable = c.classList.contains("ui-tree-selectable") || (li && li.classList.contains("ui-treenode-leaf"));
                if (!selectable) return;
                const t = c.querySelector(".lovItemTitle") || c.querySelector(".ui-treenode-label") || c;
                cands.push({ el: c, title: nz(t.textContent), txt: nz(c.textContent) });
            });
            if (!cands.length) dlg.querySelectorAll(".ui-treenode-content").forEach(c => { if (!isVisible(c)) return; const t = c.querySelector(".lovItemTitle") || c.querySelector(".ui-treenode-label") || c; cands.push({ el: c, title: nz(t.textContent), txt: nz(c.textContent) }); });
            if (!cands.length) dlg.querySelectorAll(".lovItemTitle").forEach(t => { if (isVisible(t)) cands.push({ el: t, title: nz(t.textContent), txt: nz((t.parentElement || t).textContent) }); });
            if (!cands.length) dlg.querySelectorAll("tr[data-ri], tr[data-rk], li.ui-autocomplete-item").forEach(t => { if (isVisible(t)) cands.push({ el: t, title: nz(t.textContent), txt: nz(t.textContent) }); });
            const isLeaf = c => { const li = c.el.closest && c.el.closest("li.ui-treenode"); return !!(li && li.classList.contains("ui-treenode-leaf")); };
            const exact = cands.filter(c => c.title === T);
            if (exact.length) return (exact.find(isLeaf) || exact[0]).el; // v3.6.56: aynı adlı iki düğümde yaprak öncelikli
            const hits = cands.filter(c => c.title.includes(T) || c.txt.startsWith(T));
            if (!hits.length) return null;
            return hits.slice().sort((x, y) => x.title.length - y.title.length)[0].el;
        };
        // FIX (v3.6.37): liste 6 sn içinde hiç gelmezse (arama tetiklenmedi) en çok 2 kez temizleyip yeniden yazılır — örtü sürerken beklenir
        let node = null, hiddenHits = 0;
        for (let att = 0; att < 3 && !node; att++) {
            if (att > 0) {
                if (sel()) return { ok: true, skipped: true };
                stepMark("Gereği yeniden yazım " + att);
                await waitFor(() => !isAjaxBusy() && !bekleyinizStrict(), 10000, 100);
                const inp2 = form.querySelector('[id$="' + gId + ':LovText"]') || findG() || inp;
                try { inp2.blur(); } catch(e) {}
                await sleep(300);
                await typeLikeHuman(inp2, typed);
            }
            const tA = Date.now();
            node = await waitFor(() => findItem() || ((Date.now() - tA > 6000 && !bekleyinizStrict() && !isAjaxBusy() && !dlgHasContent()) ? "RETRY" : null), att === 2 ? 20000 : 14000, 50);
            try { const d0 = dlgOf(); stepMark("Gereği liste: sonuç=" + (node === "RETRY" ? "gelmedi" : node === "HIDDEN" ? "gizli pencerede" : node ? "bulundu (" + String((node.textContent || "")).replace(/\s+/g, " ").trim().slice(0, 50) + ")" : "yok") + ", pencere=" + (d0 ? (isVisibleOuter(d0) ? "görünür" : "gizli") : "yok") + ", düğüm=" + (d0 ? d0.querySelectorAll(".ui-treenode-content").length : 0) + ", örtü=" + (bekleyinizStrict() ? "var" : "yok")); } catch(e) {}
            if (node === "RETRY") node = null;
            if (node === "HIDDEN") { node = null; hiddenSince = 0; if (++hiddenHits >= 2) { stepMark("Gereği: liste gizli pencerede — seçim yapılmadı"); return { ok: false, hidden: true, why: "Gereği listesi EBYS'nin gizli penceresine geldi (ilk açılış); seçim yapılmadı", diag: true }; } }
        }
        if (!node) return { ok: false, why: "'" + term + "' listede bulunamadı", diag: true };
        // v3.6.23: canlı gözlem — hızlı seçim + hızlı 'Direkt Gönder' çalışıyor, gecikince EBYS takılıyor → liste görünür görünmez seçilir (0,9 sn bekleme kaldırıldı)
        await waitFor(() => !isAjaxBusy(), 8000, 50);
        const gStart = Date.now();
        startDirektWatch(15000); // seçimden sonra gelen dağıtım uyarısı → "Direkt Gönder"
        // v3.6.18: Gereği seçimi seçim AJAX'ı (dağıtım uyarısı) başlatır; yöntem zinciri örtü sürerken yeniden tıklayıp çoklu seçimli ağaçta seçimi
        // geri alıyor / çakışan istek gönderiyordu. Artık TEK eylem: sayfa dünyasında PrimeFaces Tree'nin kendi nodeClick'i (insan tıklamasıyla aynı yol),
        // köprü yoksa tek yerel tıklama; sonra uyarı/seçim örtü bitene kadar (en çok 60 sn) beklenir. Yeniden tıklama YOK.
        const pr = await gerekPickOnce(findItem, () => !!sel() || direktBusy || !!findDirektGonder(), dlgOf);
        if (!pr.ok) return { ok: false, hang: !!pr.hang, why: (pr.hang ? "Gereği seçiminden sonra EBYS 25 sn'den uzun bekledi (" : "Gereği seçilemedi (") + term + "); denenen: " + pr.tried.join(", "), diag: !pr.hang };
        // v3.6.25: başarı = seçim görünür VEYA 'Direkt Gönder' tıklandı ve uyarı kapandı (canlıda seçim kutusu eski formda okunamıyordu). Yedek: 6 sn (örtü sürerken uzar, en çok 20 sn)
        const pickT0 = Date.now();
        const gDone = () => !!sel() || direktClosedAt >= gStart || (direktDoneAt >= gStart && !findDirektGonder() && !bekleyinizStrict());
        let ok = false;
        { const t0 = Date.now(); while (Date.now() - t0 < 20000) { autoCheck(); if (gDone()) { ok = true; break; } if (Date.now() - t0 > 6000 && !bekleyinizStrict()) break; await new Promise(r => setTimeout(r, 100)); } stepLog("Gereği onay bekleme", t0, ok ? "ok" : "ZAMAN AŞIMI"); }
        if (!ok) return { ok: false, why: "Gereği seçimi kutuda görünmedi (" + term + ")", diag: true };
        // v3.6.26: uyarı kapanışı bazen 0,3 sn'den uzun sürüyor; 2,5 sn boyunca yeniden bak (akışı yavaşlatmaz: zaten seçim bitti)
        let warn = "";
        warn = await gerekCloseCheck(gStart);
        if (warn) showDiagBox(cevapDiagReport(warn));
        return { ok: true, warn: warn };
    }

    // =========================================================================
    // NEW (v3.6.4): OTONOM ⇄ ŞABLON — konuya uyan şablon (kendi/öğrenilen/hazır) varsa Otonom onu yazar; yoksa genel cevap hazırlar.
    // Eşleşme: şablon adı (kök eşleşmesi), öğrenilen konu örnekleri, hazır şablon anahtar kelimeleri, şablon gövdesi; konudaki parantez içi
    // ifade ayrıca puanlanır (kişi adı + (asıl konu) biçimindeki yazılar için). Kendi şablonlarınız +0.08 öncelik alır. Otomatik yazma eşiği %50.
    // =========================================================================
    const TPL_STOP = new Set(("hakkinda hk yazisi yazi yazilari konulu konusu gonderilmesi iletilmesi bildirilmesi gonderme bildirimi bildirim hususu husus ilgi okul okulu okulumuz okulumuza mudurlugu mudurlugune mudurlugunun milli sayili tarihli genelge duyuru cevap cevabi taslak ornek sablon standart ogrenilen ile ve icin olan bir bu gore ilgili ilgisi talebi talep gereginin bilgi verme uygun gorulmedi olumsuz yapildi").split(/\s+/));
    function stemSet(s) {
        const out = new Set();
        trFold(String(s || "").replace(/\{[^}]*\}/g, " ")).split(/[^a-z0-9]+/).forEach(w => { if (w.length >= 3 && !TPL_STOP.has(w) && !/^\d+$/.test(w)) out.add(w.slice(0, 5)); });
        return out;
    }
    function templateMatchScore(name, text, konu) {
        const Ks = [stemSet(konu)];
        const par = String(konu || "").match(/\(([^)]{4,})\)/);
        if (par) Ks.push(stemSet(par[1]));
        const N = stemSet(name), B = stemSet(text), meta = tplMeta[name];
        const hint = BUILTIN_HINTS[name], hk = hint ? trFold(hint).split(/\s+/).filter(w => w.length >= 3) : [];
        let best = 0;
        Ks.forEach(K => {
            if (!K.size) return;
            if (N.size) { let hit = 0; N.forEach(x => { if (K.has(x)) hit++; }); if (hit >= Math.min(2, N.size)) best = Math.max(best, 0.95 * hit / N.size); }
            if (meta && Array.isArray(meta.konular)) meta.konular.forEach(k => { best = Math.max(best, diceOf(K, stemSet(k))); });
            let bh = 0; K.forEach(x => { if (B.has(x)) bh++; });
            if (bh >= 2) best = Math.max(best, 0.7 * bh / K.size);
        });
        if (hk.length) { const kt = trFold(konu); const hit = hk.filter(w => kt.includes(w)).length; if (hit >= 2) best = Math.max(best, Math.min(0.9, 0.05 + 0.2 * hit)); }
        return best;
    }
    function rankTemplatesFor(d) {
        const konu = (d && d.info && d.info.konu) || (d && d.subject) || "";
        if (!konu) return [];
        const eff = getEffectiveTemplates(), out = [];
        Object.keys(eff).forEach(name => {
            let sc = templateMatchScore(name, eff[name], konu);
            if (sc > 0 && Object.prototype.hasOwnProperty.call(savedReplyTemplates, name)) sc = Math.min(1, sc + 0.08);
            if (sc >= 0.3) out.push({ name: name, score: sc });
        });
        return out.sort((a, b) => b.score - a.score);
    }
    function suggestTemplatesFor(d) { return rankTemplatesFor(d).slice(0, 3); }

    // =========================================================================
    // NEW (v3.6.4): TARAMADA EVRAK İÇİNİ DE OKU — Miat bilgisi olmayan evrakların süre/son tarih ifadesi yalnızca metindedir. Açık ise tarama,
    // listedeki bu evrakları tek tek seçip önizleme metnini okur (evrak kapatılmaz/havale edilmez/cevaplanmaz), günlü evrakları takibe alır.
    // Metni okunmuş ve süresi olmayan evrak bir daha okunmaz (ebys_deadline_checked_v1). Bir taramada en çok 80 evrak; kalanı sonraki taramada.
    // =========================================================================
    const DEEP_KEY = "ebys_deep_scan_v1", DEEP_CHECKED_KEY = "ebys_deadline_checked_v1", DEEP_MAX_PER_SCAN = 80;
    const deepScanOn = () => { const v = extStoreGet(DEEP_KEY); return !(v && v.on === false); };
    let deadlineChecked = loadJSON(DEEP_CHECKED_KEY, {}, isPlainObject);
    let deepStop = false;
    function setDeepNotice(text) {
        const c = document.getElementById("ebys-cards-container");
        if (!c) return;
        let n = document.getElementById("ebys-deep-notice");
        if (!n) {
            n = document.createElement("div");
            n.id = "ebys-deep-notice";
            n.style.cssText = "background:#1E3A5F; color:#BAE6FD; border:1px solid #38BDF8; padding:8px; border-radius:10px; font-size:11px; display:flex; gap:8px; align-items:center; justify-content:space-between;";
            n.innerHTML = '<span class="deep-txt"></span><button id="ebys-deep-stop" style="background:#B45309; color:white; border:none; border-radius:8px; padding:3px 8px; cursor:pointer; font-size:10.5px;">⏹ Durdur</button>';
            n.querySelector("#ebys-deep-stop").onclick = () => { deepStop = true; n.querySelector(".deep-txt").textContent = "⏹ Durduruluyor…"; };
            c.prepend(n);
        }
        if (!deepStop) n.querySelector(".deep-txt").textContent = text;
    }
    async function deepCheckDoc(d) {
        if (!d || !d.docNo || d.info) return "skip";
        if (!(await parafOpenRow({ rk: d.rk || "", key: d.docNo, docNo: d.docNo }))) return "open-fail";
        let pv = null;
        try { pv = await readRealPreview(d); } catch(e) { return "read-fail"; }
        if (!pv || !pv.text || !pv.verified) return "read-fail";
        const a = extractDocAttributes(pv.text);
        if (a.tekrar) { takipOnRecurring({ info: { tekrar: a.tekrar, konu: a.konu, gonderen: a.gonderen }, subject: d.subject, gonderen: d.gonderen }); return "tekrar"; }
        const dl = computeDeadline(a.sonTarih, a.tarih || pv.evrakTarihi || d.tarih);
        if (!dl) return "none";
        saveDeadline(d.docNo, dl);
        d.sonTarihDiger = a.sonTarihDiger || [];
        d.kisaIcerik = a.kisaIcerik || "";
        const r = takipFixNote(TK.upsertFromDoc(getTakip(), takipRecOf(d), { autoAdd: getTakipSettings().autoAdd, today: takipToday() }), d);
        if (r.action === "added" || r.action === "updated") saveTakip(r.store);
        try { renderCountdown(d); } catch(e) {}
        return r.action === "added" ? "added" : "found";
    }
    async function deepReadDocs(docs, ctx) {
        const todo = docs.filter(d => d && d.docNo && !d.info && !getDeadline(d) && !deadlineChecked[d.docNo]);
        for (const d of todo) {
            if (deepStop || ctx.done >= DEEP_MAX_PER_SCAN) break;
            setDeepNotice("🔍 Evrak içi okunuyor (" + (ctx.done + 1) + "): " + String(d.subject || d.docNo).slice(0, 40));
            const st = await deepCheckDoc(d);
            if (st === "open-fail" || st === "read-fail") { ctx.fail++; continue; }
            ctx.done++;
            deadlineChecked[d.docNo] = takipToday();
            if (st === "found" || st === "added" || st === "tekrar") ctx.found++;
            if (st === "added") ctx.added++;
        }
        const keys = Object.keys(deadlineChecked);
        if (keys.length > 800) keys.sort((a, b) => String(deadlineChecked[a]).localeCompare(String(deadlineChecked[b]))).slice(0, keys.length - 800).forEach(k => delete deadlineChecked[k]);
        extStoreSet(DEEP_CHECKED_KEY, deadlineChecked);
    }

    // =========================================================================
    // NEW (v3.3): HAVALE — Birim Evrakları > Teslim Alınmayı Bekleyenler → (evrak) "Teslim Al ve Havale Et" → "Kişiye Havale - Hızlı Seçim"
    // Gerçek yapı (kaydedilmiş gerçek sayfalardan çıkarıldı):
    //   Menü    : a.ui-menuitem-link[onclick*="leftMenu.birimEvraklari.teslimAlinmayiBekleyenler"] "Teslim Alınmayı Bekleyenler" (sayı rozeti görülmedi)
    //   Liste   : aynı #mainInboxForm:inboxDataTable; başlık "Teslim Alınmayı Bekleyenler"; satır3 "Kayıt Tarihi / No: … / NNN";
    //             satır4 "Evrak Tarihi: gg.aa.yyyy / Sayı: E-… / Miat: N gün" (Sayı boş olabilir)
    //   Önizleme: mainPreviewForm:onizlemeRightTab düğmeleri "Evrak Göster" / "Teslim Al" / "Teslim Al ve Havale Et" / "Teslim Al ve Kapat"
    //   Form    : .teslimAlHavaleEtDagitimLovPanel — "Kişiye Havale" (dagitimBilgileriKullaniciLov: LovSecilenTable) + "Kişiye Havale - Hızlı Seçim" düğmesi;
    //             "Teslim Al Gönder" (mainPreviewForm:btnTeslimAlGonder = asıl gönderim) / "Vazgeç"
    //   Pencere : #kisiyeHizliHavaleDialog — kisiyeHizliHavaleDialogDT satırları "Ad SOYAD [Ünvan]" + SelectOneButton (G=Gereği, B=Bilgi, S=Koordine);
    //             "Tamam" seçilenleri formdaki Kişiye Havale listesine ekler (gönderim değildir)
    // Güvenlik: kullanıcı onayı olmadan "Tamam"a ve "Teslim Al Gönder"e ASLA basılmaz; "Teslim Al" / "Teslim Al ve Kapat"a hiç basılmaz;
    //   toplu / otomatik havale yoktur; belirsizlikte durulur, EBYS ekranı olduğu gibi (açık) bırakılır.
    // =========================================================================
    const TESLIM_MENU_TAG = "leftMenu.birimEvraklari.teslimAlinmayiBekleyenler";
    const HAVALE_PEOPLE_KEY = "ebys_havale_people_v1"; // kurum kişi listesi (ad soyad + unvan) — yalnızca bu bilgisayarda
    const HAVALE_FAV_KEY = "ebys_havale_fav_v1";       // favori kişiler (etiket listesi)
    const HAVALE_SCAN_KEY = "ebys_havale_scan_v1";     // son "teslim bekleyenler" taraması
    const HAVALE_DONE_KEY = "ebys_havale_done_v1";     // "Havale edildi" işaretleri (evrak anahtarı → zaman)
    const isValidPeople = v => isPlainObject(v) && Array.isArray(v.people) && v.people.every(p => isPlainObject(p) && typeof p.name === "string");
    let havalePeople = loadJSON(HAVALE_PEOPLE_KEY, { at: 0, people: [] }, isValidPeople);
    let havaleFav = loadJSON(HAVALE_FAV_KEY, [], v => Array.isArray(v) && v.every(x => typeof x === "string"));
    let havaleDone = loadJSON(HAVALE_DONE_KEY, {}, isPlainObject);
    let havaleList = [];
    let havaleScanned = false, havaleScanAt = null, havaleRestored = false, havaleScanning = false, havaleBusy = false;
    let havaleNotices = [];       // son taramanın bildirimleri (panel yeniden çizilince korunur)
    const havaleStatus = {};      // kart durum satırları (anahtar → {text, kind})
    const havalePick = {};        // kart başına seçim (anahtar → {etiket: "G"|"B"})
    let activeTab = "gelen";
    const havaleKeyOf = d => d.docNo || (d.kayitNo ? "KAYIT-" + d.kayitNo : "RK-" + d.rk);
    const normName = s => String(s || "").replace(/\s+/g, " ").trim().toLocaleUpperCase("tr");
    const personLabel = p => p.name + (p.title ? " [" + p.title + "]" : "");
    const GB_TEXT = { G: "Gereği", B: "Bilgi", S: "Koordine" };
    (function restoreHavaleScan() {
        const v = loadJSON(HAVALE_SCAN_KEY, null, x => x === null || (isPlainObject(x) && Array.isArray(x.list)));
        if (v && v.list.length) {
            havaleList = v.list.filter(d => isPlainObject(d) && typeof d.subject === "string" && typeof d.key === "string");
            havaleScanned = havaleList.length > 0; havaleScanAt = v.at || null; havaleRestored = havaleScanned;
        }
    })();

    // ---- menü / liste
    // NEW (v3.6.4): menü bağlantısı tüm çerçevelerde, etikete ya da (Türkçe karakter/büyük-küçük harf duyarsız) metne göre aranır;
    // daraltılmış "Birim Evrakları" menüsü açılır; bulunamazsa soldaki menü başlıkları rapora yazılır (Tanılama gerekmeden nedeni görünsün).
    function listMenuLabels() {
        const out = [];
        getAllDocs().forEach(doc => { try { doc.querySelectorAll("a.ui-menuitem-link, .ui-panelmenu a, .ui-menu a, .ui-menu h3, .ui-panelmenu-header").forEach(a => {
            if (isPanelEl(a)) return;
            const t = (a.textContent || "").replace(/\s+/g, " ").trim();
            if (t && t.length < 70 && !out.includes(t)) out.push(t);
        }); } catch(e) {} });
        return out;
    }
    function findTeslimMenuLink() {
        const re = /teslim\s+alinmay\w*\s+bekleyen/;
        for (const doc of getAllDocs()) {
            try {
                const byTag = doc.querySelector('a[onclick*="' + TESLIM_MENU_TAG + '"], a[onclick*="teslimAlinmayiBekleyen" i]');
                if (byTag && !isPanelEl(byTag)) return byTag;
                for (const a of doc.querySelectorAll("a.ui-menuitem-link, .ui-panelmenu a, .ui-menu a")) {
                    if (isPanelEl(a)) continue;
                    if (re.test(trFold(a.textContent || ""))) return a;
                }
            } catch(e) {}
        }
        return null;
    }
    function isOnTeslim() {
        if (!getInboxRoot()) return false;
        const headerOk = /^teslim\s+alinmay\w*\s+bekleyen/.test(trFold(inboxHeaderText()));
        const link = findTeslimMenuLink();
        return link ? (isMenuSelected(link) && headerOk) || headerOk : headerOk;
    }
    // menü başlığı "Birim ..." olan daraltılmış bölümlerden görünmeyen bağlantıyı açar
    async function expandBirimMenus() {
        for (const doc of getAllDocs()) {
            try {
                for (const a of doc.querySelectorAll("a.ui-menuitem-link")) {
                    if (isPanelEl(a) || isVisible(a)) continue;
                    const menu = a.closest(".ui-menu, .ui-panelmenu");
                    const h = menu && menu.querySelector("h3, .ui-menu-header, .ui-panelmenu-header");
                    if (h && /birim/i.test(h.textContent || "")) { await expandMenuFor(a); return true; }
                }
            } catch(e) {}
        }
        return false;
    }
    async function gotoTeslim() {
        lastNavFailure = "";
        if (isOnTeslim()) return true;
        const lv = await leaveEbysTransientUi();
        if (!lv.ok) { lastNavFailure = lv.msg; return false; }
        for (let attempt = 0; attempt < 3; attempt++) {
            let link = findTeslimMenuLink();
            if (!link) { await expandBirimMenus(); link = findTeslimMenuLink(); }
            if (!link) { await sleep(800); continue; }
            await expandMenuFor(link);
            dbg("Birim Evrakları > Teslim Alınmayı Bekleyenler menüsüne geçiliyor (", link.id || "-", ") deneme", attempt + 1);
            try { if (attempt === 0) link.click(); else userClick(link); } catch(e) {}
            if (await waitFor(() => isOnTeslim() && !isAjaxBusy(), attempt === 0 ? AJAX_TIMEOUT_MS + 3000 : 7000, 200)) { await sleep(400); return true; }
            await leaveEbysTransientUi();
        }
        const labels = listMenuLabels();
        lastNavFailure = findTeslimMenuLink()
            ? "Menüye tıklandı ama liste açılmadı" + (visibleEbysDialogTitles().length ? " (ekranda açık pencere: '" + visibleEbysDialogTitles()[0] + "' — kapatıp tekrar deneyin)" : "") + "."
            : labels.length
                ? "Sol menüde 'Teslim Alınmayı Bekleyenler' yok. Hesabınızda bu menü açık değilse (Birim Evrakları yetkisi) havale bu ekrandan yapılamaz. Menüde görünenler: " + labels.slice(0, 22).join(" | ")
                : "Sol menü bulunamadı; EBYS ana sayfasında (Gelen Evraklar ekranı) olmalısınız.";
        dbg("Teslim Alınmayı Bekleyenler açılamadı:", lastNavFailure);
        return false;
    }
    
    function parseTeslimRow(tr) {
        const txt = (sel) => { const e = tr.querySelector(sel); return e ? (e.textContent || "").replace(/\s+/g, " ").trim() : ""; };
        const full = (tr.textContent || "").replace(/\s+/g, " ").trim();
        const s3 = txt(".ui-inbox-satir3"), s4 = txt(".ui-inbox-satir4");
        const docNo = (s4.match(/Sayı\s*:\s*(E-\d{6,10}-[\d.]+-\d+)/) || s4.match(/(E-\d{6,10}-[\d.]+-\d+)/) || [])[1] || "";
        const kayitNo = (s3.match(/\/\s*(\d{5,})\s*$/) || s3.match(/No\s*:.*\/\s*(\d{5,})/) || [])[1] || "";
        const rk = tr.getAttribute("data-rk") || "";
        if (!docNo && !kayitNo && !rk) return null;
        let subject = (txt(".rowTitleForInbox") || txt("td.ui-inbox-satir1 .searchText") || txt("h3.ui-inbox-satir1")).replace(/^Konu\s*:\s*/i, "");
        if (!subject) { const km = full.match(/Konu\s*:\s*(.{3,160}?)(?=\s+(Kişisel Arşive|Geldiği Yer|\d{2}\.\d{2}\.\d{4})|$)/); if (km) subject = km[1]; }
        const et = s4.match(/Evrak Tarihi\s*:\s*(\d{2}\.\d{2}\.\d{4})/);
        const kt = s3.match(/(\d{2}\.\d{2}\.\d{4})/);
        const miat = s4.match(/Miat\s*:\s*(\d+)\s*gün/i);
        const d = {
            docNo: docNo, kayitNo: kayitNo, rk: rk,
            subject: (subject || "Konu belirtilmemiş").substring(0, 160),
            gonderen: txt(".ui-inbox-satir2").replace(/^Geldiği Yer\s*:\s*/i, "") || "-",
            tarih: et ? et[1] : "", kayitTarihi: kt ? kt[1] : "",
            miat: miat ? +miat[1] : null,
            ivedi: /ivedi/i.test(tr.className) || /İVEDİ/.test(full),
            kimde: "", kimdeKaynak: ""
        };
        const kimdeT = extractKimdeFromRow(tr);
        if (kimdeT) { d.kimde = kimdeT; d.kimdeKaynak = "ebys"; }
        d.key = havaleKeyOf(d);
        return d;
    }
    function findTeslimRow(d) {
        const rows = getInboxRows();
        if (d.rk) { const r = rows.find(tr => tr.getAttribute("data-rk") === d.rk); if (r) return r; }
        return rows.find(tr => { const p = parseTeslimRow(tr); return p && p.key === d.key; }) || null;
    }
    function isTeslimRowSelected(tr) { return isRowSelected(tr) || (!!tr && tr.classList.contains("ui-state-active")); }

    // ---- havale formu / hızlı seçim penceresi
    function havaleFormEl() { const pf = getPreviewForm(); return pf ? pf.querySelector('.teslimAlHavaleEtDagitimLovPanel, [id$="teslimAlHavaleEtDagitimLovPanel"]') : null; }
    function isHavaleFormOpen() { const f = havaleFormEl(); return !!(f && isVisible(f)) || !!findToolbarButton("Teslim Al Gönder"); }
    function findHizliBtn() {
        const pf = getPreviewForm();
        if (!pf) return null;
        return Array.from(pf.querySelectorAll("button, a")).find(b => /^Kişiye Havale - Hızlı Seçim$/.test((b.getAttribute("aria-label") || b.getAttribute("title") || "").trim()) && isVisible(b) && !b.classList.contains("ui-state-disabled")) || null;
    }
    function kisiLovRows() {
        const tb = document.querySelector('[id$="dagitimBilgileriKullaniciLov:LovSecilenTable_data"]');
        return tb ? Array.from(tb.children).filter(tr => tr.tagName === "TR" && !tr.classList.contains("ui-datatable-empty-message") && (tr.textContent || "").trim()) : [];
    }
    function quickDialog() { // CHANGE (v3.5.2): tüm (aynı kökenli) çerçevelerde
        for (const doc of getAllDocs()) {
            try {
                const q = doc.getElementById("kisiyeHizliHavaleDialog") || Array.from(doc.querySelectorAll(".ui-dialog")).find(x => /Kişiye Havale - Hızlı Seçim/.test(((x.querySelector(".ui-dialog-title") || {}).textContent) || ""));
                if (q) return q;
            } catch(e) {}
        }
        return null;
    }
    function isQuickOpen() { const q = quickDialog(); return !!(q && isVisible(q)); }
    function quickRows() {
        const q = quickDialog();
        if (!q) return [];
        const tb = q.querySelector('tbody[id$="kisiyeHizliHavaleDialogDT_data"]') || q.querySelector("tbody.ui-datatable-data");
        if (!tb) return [];
        return Array.from(tb.children).filter(tr => tr.tagName === "TR" && !tr.classList.contains("ui-datatable-empty-message")).map(tr => {
            const label = (((tr.querySelector("td") || {}).textContent) || "").replace(/\s+/g, " ").trim();
            const m = label.match(/^(.*?)\s*\[(.*)\]\s*$/);
            const btns = Array.from(tr.querySelectorAll(".ui-selectonebutton .ui-button")).map(b => { const inp = b.querySelector("input"); return { el: b, v: inp ? inp.value : "", active: b.classList.contains("ui-state-active") || !!(inp && inp.checked) }; });
            return { tr: tr, label: label, name: m ? m[1].trim() : label, title: m ? m[2].trim() : "", btns: btns };
        }).filter(r => r.label);
    }
    const quickActive = r => { const b = r.btns.find(x => x.active); return b ? b.v : ""; };
    function quickPageCount() { const q = quickDialog(); const p = q && q.querySelector(".ui-paginator"); return p ? Math.max(1, p.querySelectorAll(".ui-paginator-page").length) : 1; }
    function findQuickTamam(any) {
        const q = quickDialog();
        if (!q) return null;
        return Array.from(q.querySelectorAll("button")).find(b => ((b.getAttribute("aria-label") || (b.querySelector(".ui-button-text") || b).textContent || "").trim() === "Tamam") && (any || isVisible(b))) || null;
    }
    function readQuickPeople() {
        const seen = new Set(), people = [];
        let dup = 0;
        quickRows().forEach(r => { const k = normName(r.label); if (seen.has(k)) { dup++; return; } seen.add(k); people.push({ name: r.name, title: r.title }); });
        return { people: people, dup: dup, multi: quickPageCount() > 1 };
    }
    function savePeople(r) {
        if (!r.people.length) return;
        havalePeople = { at: Date.now(), people: r.people, partial: !!r.multi };
        extStoreSet(HAVALE_PEOPLE_KEY, havalePeople);
    }
    function closeQuickDialog() {
        const q = quickDialog();
        const x = q && q.querySelector(".ui-dialog-titlebar-close");
        if (x && isVisible(q)) { try { x.click(); } catch(e) {} }
    }

    // ---- evrakı aç ve doğrula (yanlış evrak güvenliği)
    async function locateTeslimRow(d) {
        if (!(await gotoTeslim())) return { tr: null, reason: "menu" };
        let tr = findTeslimRow(d);
        if (!tr) {
            await goFirstPage();
            tr = findTeslimRow(d);
            const seen = new Set([tableSignature()]);
            for (let p = 1; !tr && p < MAX_OPEN_PAGES; p++) {
                if (!hasNextPage() || !(await goNextPage())) break;
                const sig = tableSignature();
                if (seen.has(sig)) break;
                seen.add(sig);
                tr = findTeslimRow(d);
            }
        }
        return { tr: tr, reason: tr ? "" : "notfound" };
    }
    async function havaleOpenDoc(d) {
        const loc = await locateTeslimRow(d);
        if (!loc.tr) return { ok: false, msg: loc.reason === "menu" ? "'Birim Evrakları > Teslim Alınmayı Bekleyenler' menüsü bulunamadı ya da açılamadı." + (lastNavFailure ? " " + lastNavFailure : "") : "Evrak 'Teslim Alınmayı Bekleyenler' listesinde bulunamadı (teslim alınmış ya da havale edilmiş olabilir). Listeyi yeniden tarayın." };
        let tr = loc.tr;
        const ready = () => !!findToolbarButton("Teslim Al ve Havale Et") && !isAjaxBusy();
        for (let attempt = 0; attempt < 2; attempt++) {
            const pf0 = getPreviewForm();
            let mutated = false;
            const mo = new MutationObserver(() => { mutated = true; });
            try { if (pf0) mo.observe(pf0, { childList: true, subtree: true }); } catch(e) {}
            clickRowLikeUser(tr, attempt);
            const ok = await waitFor(() => (mutated || getPreviewForm() !== pf0) && ready(), attempt ? 6000 : 9000, 150);
            mo.disconnect();
            if (ok) { await sleep(400); break; }
            tr = findTeslimRow(d) || tr;
            if (attempt === 1) return { ok: false, msg: "Evrak açılamadı (önizleme ya da 'Teslim Al ve Havale Et' düğmesi gelmedi)." };
        }
        const tr2 = findTeslimRow(d);
        if (!tr2 || !isTeslimRowSelected(tr2)) return { ok: false, msg: "Açılan evrak listede seçili görünmüyor; yanlış evrak riskine karşı durduruldu." };
        return { ok: true };
    }
    async function havaleVerifyPreview(d) {
        const pv = await readRealPreview({ docNo: d.docNo || "-" });
        if (d.tarih && pv.evrakTarihi && pv.evrakTarihi !== d.tarih) return { ok: false, msg: "Açılan evrakın tarihi (" + pv.evrakTarihi + ") listedekiyle (" + d.tarih + ") aynı değil; yanlış evrak riskine karşı durduruldu." };
        if (!pv.text) return { ok: false, msg: "Evrak önizlemesi okunamadı; açılan evrakın doğru olduğu doğrulanamadığı için durduruldu." };
        if (d.docNo) {
            if (!pv.verified) return { ok: false, msg: "Açılan evrakın önizlemesinde '" + d.docNo + "' sayısı bulunamadı; yanlış evrak riskine karşı durduruldu." };
            return { ok: true, how: "önizlemede evrak sayısı (" + d.docNo + ") bulundu", text: pv.text };
        }
        const subj = normName(d.subject).slice(0, 30);
        if (subj.length >= 6 && normName(pv.text).includes(subj)) return { ok: true, how: "satırda sayı yok; önizlemede konu bulundu" + (pv.evrakTarihi ? ", tarih eşleşti" : ""), text: pv.text };
        return { ok: false, msg: "Satırda evrak sayısı yok ve konu önizlemede bulunamadı; açılan evrak doğrulanamadığı için durduruldu." };
    }
    // Havale formunu bu evrak için hazırla (gerekirse evrakı açar, doğrular, "Teslim Al ve Havale Et"e basar)
    async function havaleEnsureForm(d) {
        if (isHavaleFormOpen()) {
            const tr = isOnTeslim() ? findTeslimRow(d) : null;
            if (!tr || !isTeslimRowSelected(tr)) return { ok: false, msg: "EBYS'de başka bir evrak için açık bir havale formu var. Önce EBYS'de 'Vazgeç'e basın, sonra tekrar deneyin." };
            const v = await havaleVerifyPreview(d);
            return v.ok ? { ok: true, how: v.how, reused: true, text: v.text } : v;
        }
        const o = await havaleOpenDoc(d);
        if (!o.ok) return o;
        const v = await havaleVerifyPreview(d);
        if (!v.ok) return v;
        const b = findToolbarButton("Teslim Al ve Havale Et");
        if (!b) return { ok: false, msg: "'Teslim Al ve Havale Et' düğmesi bulunamadı." };
        dbg("Teslim Al ve Havale Et:", d.key);
        b.click();
        const ok = await waitFor(() => isHavaleFormOpen() && !isAjaxBusy(), AJAX_TIMEOUT_MS + 5000, 200);
        if (!ok) return { ok: false, msg: "'Teslim Al ve Havale Et' formu açılmadı." };
        await sleep(300);
        return { ok: true, how: v.how, text: v.text };
    }
    async function havaleOpenQuick() {
        if (isQuickOpen() && quickRows().length) return { ok: true };
        const b = findHizliBtn();
        if (!b) return { ok: false, msg: "Formda 'Kişiye Havale - Hızlı Seçim' düğmesi bulunamadı." };
        b.click();
        const ok = await waitFor(() => isQuickOpen() && quickRows().length > 0 && !isAjaxBusy(), AJAX_TIMEOUT_MS + 5000, 200);
        if (!ok) return { ok: false, msg: "'Kişiye Havale - Hızlı Seçim' penceresi açılmadı ya da kişi listesi boş." };
        await sleep(200);
        return { ok: true };
    }
    // ---- NEW (v3.5.2): Hızlı Seçim'e sağlam seçim uygulama
    // KÖK NEDEN (v3.5.1 hatası): gerçek EBYS'de bir satırdaki Gereği/Bilgi/Koordine düğmesine tıklanınca pencerenin tablosu AJAX ile sunucu durumundan
    // YENİDEN ÇİZİLİR. Açılışta görünen varsayılan seçimler sunucuda yoktur → ilk tıklamadan sonra tüm varsayılanlar kaybolur ve eski satır öğeleri
    // (bir kez okunmuş referanslar) geçersizleşir. Eski kod önce varsayılanları kaldırıp sonra hedefi ESKİ öğeden "zaten seçili" sanıp atlıyordu;
    // sonuç: hedef kişide seçim yok → "… için Bilgi seçimi EBYS penceresinde uygulanamadı".
    // Yeni yöntem: her işlemden önce satır YENİDEN bulunur; tıklamadan sonra tablo sakinleşene kadar beklenir; önce hedefler, sonra hedef dışılar;
    // sonuç yeniden okunup gerekirse birkaç tur düzeltilir; 3. denemede sayfa dünyası köprüsüyle PrimeFaces bileşeni doğrudan seçilir.
    const qdKey = s => HC.fold(String(s || "").replace(/\[[^\]]*\]/g, " ")).replace(/[^0-9a-z]+/g, " ").trim();
    function quickMatches(r, t) {
        if (normName(r.label) === normName(personLabel(t))) return true;
        if (qdKey(r.name) !== qdKey(t.name)) return false;
        return !t.title || !r.title || HC.fold(r.title) === HC.fold(t.title);
    }
    function quickFind(t) {
        const rows = quickRows();
        let hits = rows.filter(r => normName(r.label) === normName(personLabel(t)));
        if (!hits.length) hits = rows.filter(r => quickMatches(r, t));
        return hits;
    }
    async function quickSettle(maxMs) {
        const q = quickDialog();
        if (!q) { await sleep(100); return; }
        let last = Date.now();
        const mo = new MutationObserver(() => { last = Date.now(); });
        try { mo.observe(q, { childList: true, subtree: true, attributes: true, attributeFilter: ["class"] }); } catch(e) {}
        const t0 = Date.now();
        await sleep(90);
        while (Date.now() - t0 < (maxMs || 3000)) { if (!isAjaxBusy() && Date.now() - last >= 280) break; await sleep(60); }
        mo.disconnect();
    }
    function quickFilterInput() { const q = quickDialog(); return q ? (q.querySelector('thead input.ui-column-filter, input[id$=":filter"]')) : null; }
    async function quickTypeFilter(v) {
        const inp = quickFilterInput();
        if (!inp || !isVisible(inp)) return false;
        inp.focus();
        setNativeValue(inp, v);
        inp.dispatchEvent(new Event("input", { bubbles: true }));
        inp.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: v ? v.slice(-1) : "Backspace" }));
        inp.dispatchEvent(new Event("change", { bubbles: true }));
        await sleep(250);
        await quickSettle(4000);
        return true;
    }
    const quickFilterActive = () => { const i = quickFilterInput(); return !!(i && i.value.trim()); };
    async function quickClearFilter() { if (quickFilterActive()) await quickTypeFilter(""); }
    // satır görünmüyorsa: önce süzgeç (ad yazılır), sonra sayfalar tek tek
    async function quickLocate(t) {
        if (quickFind(t).length) return true;
        if (await quickTypeFilter(t.name)) {
            await waitFor(() => quickFind(t).length > 0, 2500, 120);
            if (quickFind(t).length) return true;
            await quickClearFilter();
        }
        const q = quickDialog();
        const pag = q && q.querySelector(".ui-paginator");
        if (!pag) return false;
        const pages = pag.querySelectorAll(".ui-paginator-page").length;
        for (let p = 0; p < pages && p < 30; p++) {
            const link = Array.from(quickDialog().querySelectorAll(".ui-paginator .ui-paginator-page")).find(a => (a.textContent || "").trim() === String(p + 1));
            if (!link) break;
            if (!link.classList.contains("ui-state-active")) { link.click(); await quickSettle(4000); }
            if (quickFind(t).length) return true;
        }
        return false;
    }
    async function quickSet(t, v) {
        for (let attempt = 0; attempt < 3; attempt++) {
            const hits = quickFind(t);
            if (hits.length > 1) return { ok: false, msg: "'" + personLabel(t) + "' EBYS listesinde birden fazla kez var; hangisi olduğu belirsiz." };
            if (!hits.length) return { ok: false, notFound: true, msg: "'" + personLabel(t) + "' EBYS kişi listesinde bulunamadı (liste değişmiş olabilir; 🔄 ile yenileyin)." };
            const r = hits[0];
            if (quickActive(r) === v) return { ok: true };
            const b = v ? r.btns.find(x => x.v === v) : r.btns.find(x => x.active);
            if (!b) return { ok: false, msg: "'" + personLabel(t) + "' için " + (GB_TEXT[v] || v) + " seçeneği bulunamadı." };
            if (attempt < 2) userClick(b.el);
            else {
                const set = r.tr.querySelector(".ui-selectonebutton");
                let br = null;
                if (set && set.id && bridgeAvailable()) br = await bridgeCall("sobSet", { id: set.id, value: v }, 3000).catch(() => null);
                if (!br || !br.ok) b.el.click();
            }
            await quickSettle(3500);
            const h2 = quickFind(t);
            if (h2.length === 1 && quickActive(h2[0]) === v) return { ok: true };
        }
        return { ok: false, msg: "'" + personLabel(t) + "' için " + (v ? GB_TEXT[v] + " seçimi" : "varsayılan seçimin kaldırılması") + " EBYS penceresinde uygulanamadı (3 deneme)." };
    }
    function matchQuickRows(rows, sel) { return rows.filter(r => quickMatches(r, sel)); }
    // Seçilen kişilere Gereği/Bilgi uygula; diğer satırlardaki seçimleri kaldırmayı dene. Tamam'a BASMAZ.
    async function havaleApplySelections(sels) {
        const targets = [];
        for (const s of sels) {
            if (targets.some(t => qdKey(t.name) === qdKey(s.name) && (!t.title || !s.title || HC.fold(t.title) === HC.fold(s.title)))) return { ok: false, msg: "'" + personLabel(s) + "' iki kez seçilmiş.", person: personLabel(s) };
            targets.push({ name: s.name, title: s.title || "", v: s.v, label: personLabel(s) });
        }
        await quickSettle(1500);
        for (let round = 0; round < 4; round++) {
            for (const t of targets) {
                if (!quickFind(t).length && !(await quickLocate(t))) return { ok: false, msg: "'" + t.label + "' EBYS kişi listesinde bulunamadı (liste değişmiş olabilir; 🔄 ile yenileyin).", person: t.label };
                const r = await quickSet(t, t.v);
                if (!r.ok) return { ok: false, msg: r.msg, person: t.label };
                const h = quickFind(t)[0];
                if (h) { t.name = h.name; t.title = h.title; t.label = h.label; }
            }
            await quickClearFilter();
            for (let k = 0; k < 40; k++) { // hedef dışı seçimleri kaldır (her tıklamada tablo yenilenebilir → her seferinde yeniden oku)
                const r = quickRows().find(x => quickActive(x) && !targets.some(t => quickMatches(x, t)));
                if (!r) break;
                const res = await quickSet({ name: r.name, title: r.title }, "");
                if (!res.ok) break; // kaldırılamıyor (seçim zorunlu olabilir) → Tamam sonrası denetimde ele alınır
            }
            const rows2 = quickRows();
            const lost = targets.filter(t => { const h = rows2.filter(x => quickMatches(x, t)); return h.length !== 1 || quickActive(h[0]) !== t.v; });
            if (!lost.length) break;
            dbg("Hızlı Seçim: tablo yenilendi, seçimler yeniden uygulanıyor (tur", round + 2, "):", lost.map(t => t.label).join(", "));
        }
        const rows3 = quickRows();
        for (const t of targets) {
            const h = rows3.filter(x => quickMatches(x, t));
            if (h.length === 1 && quickActive(h[0]) !== t.v) return { ok: false, msg: "'" + t.label + "' için " + GB_TEXT[t.v] + " seçimi EBYS penceresinde uygulanamadı (tablo her tıklamada yenileniyor).", person: t.label };
        }
        const notCleared = rows3.filter(r => quickActive(r) && !targets.some(t => quickMatches(r, t))).map(r => r.label);
        return { ok: true, targets: targets, notCleared: notCleared };
    }
    // Hızlı Seçim'de Tamam: pencere kapanıp kişiler forma gelene kadar bekle; olmazsa EBYS'nin mesajını göster
    async function quickTamamAndWait() {
        const t = findQuickTamam();
        if (!t) return { ok: false, msg: "Hızlı Seçim penceresinde 'Tamam' düğmesi bulunamadı." };
        t.click();
        const closed = await waitFor(() => !isQuickOpen() && !isAjaxBusy() && kisiLovRows().length > 0, AJAX_TIMEOUT_MS + 5000, 200);
        if (closed) { await sleep(300); return { ok: true }; }
        const m = Array.from(document.querySelectorAll(".ui-growl-item, .ui-messages-error, .ui-message-error, .ui-messages-warn")).filter(isVisible).map(x => (x.textContent || "").replace(/\s+/g, " ").trim()).filter(Boolean);
        return { ok: false, msg: "Tamam'dan sonra pencere kapanmadı ya da kişiler forma eklenmedi." + (m.length ? " EBYS mesajı: " + m.slice(-1)[0].slice(0, 160) : "") };
    }
    // Formdaki "Kişiye Havale" satırı: türü gizli <select>/seçenek metinlerinden ETKİLENMEDEN oku
    function lovRowType(tr) {
        const pick = s => ((s || "").match(/Gereği|Bilgi|Koordine/) || [])[0] || "";
        const sel = tr.querySelector("select");
        if (sel && sel.selectedIndex >= 0 && sel.options[sel.selectedIndex]) { const v = pick(sel.options[sel.selectedIndex].textContent); if (v) return v; }
        const lab = tr.querySelector(".ui-selectonemenu-label"); if (lab) { const v = pick(lab.textContent); if (v) return v; }
        const act = tr.querySelector(".ui-button.ui-state-active, .ui-state-active[aria-label]"); if (act) { const v = pick((act.getAttribute("aria-label") || "") + " " + (act.textContent || "")); if (v) return v; }
        const c = tr.cloneNode(true);
        c.querySelectorAll("select, option, script, style, .ui-helper-hidden, .ui-helper-hidden-accessible, .ui-selectonemenu-items-wrapper, .ui-selectonemenu-panel").forEach(x => x.remove());
        const ms = Array.from(new Set(((c.textContent || "").match(/Gereği|Bilgi|Koordine/g) || [])));
        return ms.length === 1 ? ms[0] : "";
    }
    function lovRowText(tr) {
        const c = tr.cloneNode(true);
        c.querySelectorAll("select, option, script, style, .ui-helper-hidden-accessible, .ui-selectonemenu-items-wrapper, .ui-selectonemenu-panel").forEach(x => x.remove());
        return (c.textContent || "").replace(/\s+/g, " ").trim();
    }
    function readKisiList() { return kisiLovRows().map(tr => ({ tr: tr, text: lovRowText(tr), type: lovRowType(tr) })); }
    const lovHas = (x, t) => qdKey(x.text).includes(qdKey(t.name));
    function verifyKisiList(targets) {
        const list = readKisiList();
        const extra = list.filter(x => !targets.some(t => lovHas(x, t)));
        for (const t of targets) {
            const hits = list.filter(x => lovHas(x, t));
            if (hits.length !== 1) return { ok: false, extra: extra, msg: "Formdaki 'Kişiye Havale' listesinde '" + t.label + "' " + (hits.length ? "birden fazla" : "yok") + "." };
            if (hits[0].type && hits[0].type !== GB_TEXT[t.v]) return { ok: false, extra: extra, msg: "'" + t.label + "' formda '" + hits[0].type + "' olarak eklenmiş (beklenen: " + GB_TEXT[t.v] + ")." };
        }
        if (list.length !== targets.length) return { ok: false, extra: extra, msg: "Formdaki 'Kişiye Havale' listesinde " + list.length + " kişi var, onaylanan " + targets.length + " kişi." + (extra.length ? " Fazla: " + extra.map(x => x.text.slice(0, 40)).join(", ") : "") };
        return { ok: true, extra: [] };
    }
    // fazladan eklenmiş kişileri formdaki satırın sil düğmesiyle kaldırmayı dene (gönderim değildir)
    async function removeKisiExtras(extra) {
        let removed = 0;
        for (const x of extra) {
            const row = kisiLovRows().find(tr => lovRowText(tr) === x.text);
            const b = row && row.querySelector('button[title*="Sil"], button[aria-label*="Sil"], a[title*="Sil"], button[title*="Kaldır"], .ui-icon-trash, .ui-icon-close, .ui-icon-closethick');
            const el = b && (b.closest("button, a") || b);
            if (!el) continue;
            const n0 = kisiLovRows().length;
            el.click();
            if (await waitFor(() => kisiLovRows().length < n0 && !isAjaxBusy(), 5000, 150)) removed++;
        }
        return removed;
    }
    async function waitGonderResult(d) {
        const t0 = Date.now();
        while (Date.now() - t0 < 25000) {
            await sleep(250);
            if (isAjaxBusy()) continue;
            const warn = Array.from(document.querySelectorAll(".ui-dialog")).find(x => !isPanelEl(x) && isVisible(x) && /kaydedilsin mi|değiştirdiniz/i.test(x.textContent || ""));
            if (warn) return { state: "warn" };
            const err = Array.from(document.querySelectorAll(".ui-messages-error, .ui-message-error, .ui-growl-image-error")).find(isVisible);
            if (err) { const box = err.closest(".ui-growl-item, .ui-messages-error, .ui-message-error") || err; return { state: "error", msg: (box.textContent || "").replace(/\s+/g, " ").trim().slice(0, 200) }; }
            if (!findToolbarButton("Teslim Al Gönder")) return { state: "sent", stillListed: !!findTeslimRow(d) };
        }
        return { state: "timeout" };
    }
    // Onay penceresi — EBYS'de Tamam'a basılmadan ÖNCE; yalnızca "Onayla" ile true döner
    function havaleConfirm(d, a, how) {
        return new Promise(resolve => {
            document.querySelectorAll("#ebys-havale-confirm").forEach(el => el.remove());
            const m = document.createElement("div");
            m.id = "ebys-havale-confirm";
            m.setAttribute("role", "dialog");
            m.setAttribute("aria-modal", "true");
            m.style.cssText = "position:fixed !important; inset:0 !important; background:rgba(0,0,0,0.5) !important; z-index:2147483647 !important; display:flex !important; align-items:center; justify-content:center; font-family:'Segoe UI', Tahoma, sans-serif;";
            const people = a.targets.map(t => '<li class="havale-confirm-person"><b>' + escapeHtml(t.label) + '</b> — <span style="color:' + (t.v === "G" ? "#FCA5A5" : "#93C5FD") + ';">' + GB_TEXT[t.v] + "</span></li>").join("");
            const warn = a.notCleared.length
                ? '<div id="havale-confirm-warn" style="background:#78350F; color:#FDE68A; border:1px solid #F59E0B; padding:6px 8px; border-radius:8px; margin:8px 0;">⚠️ EBYS penceresinde ' + a.notCleared.length + " kişide daha varsayılan bir seçim var ve kaldırılamadı. Tamam'dan sonra formda fazladan kişi görülürse <b>gönderim yapılmaz</b>.</div>"
                : "";
            m.innerHTML = '<div style="width:min(520px, 92vw); max-height:88vh; overflow-y:auto; background:#1F2D4D; color:#E2E8F0; border:1.5px solid #00F0FF; border-radius:16px; padding:16px; font-size:12.5px; line-height:1.5;">'
                + '<div style="font-weight:800; color:#00F0FF; font-size:15px; margin-bottom:8px;">📨 Havale onayı</div>'
                + '<div id="havale-confirm-doc"><b>Evrak:</b> ' + escapeHtml(d.docNo || ("Kayıt No " + (d.kayitNo || "-"))) + (d.tarih ? " · " + escapeHtml(d.tarih) : "") + "</div>"
                + "<div><b>Konu:</b> " + escapeHtml(d.subject) + "</div>"
                + '<div style="color:#A9B6CA; font-size:11px;">Doğrulama: ' + escapeHtml(how || "-") + "</div>"
                + '<div style="margin-top:8px;"><b>Kişiye Havale (' + a.targets.length + "):</b></div><ul style=\"margin:4px 0 0 0; padding-left:18px;\">" + people + "</ul>"
                + warn
                + '<div style="font-size:11px; color:#A9B6CA; margin:8px 0 12px 0;">Onaylarsanız eklenti EBYS\'de: 1) Hızlı Seçim penceresinde <b>Tamam</b>\'a basar, 2) formdaki Kişiye Havale listesinde yalnızca bu kişilerin olduğunu kontrol eder, 3) <b>Teslim Al Gönder</b>\'e basar. Kontrol tutmazsa gönderim yapılmaz. Vazgeçerseniz hiçbir düğmeye basılmaz, EBYS penceresi açık kalır.</div>'
                + '<div style="display:flex; gap:8px; justify-content:flex-end;">'
                + '<button id="btn-havale-confirm-cancel" style="background:#2D3D63; color:#E2E8F0; border:1px solid #A9B6CA; padding:8px 14px; border-radius:10px; font-weight:bold; cursor:pointer;">✖ Vazgeç</button>'
                + '<button id="btn-havale-confirm-ok" style="background:#15803D; color:white; border:none; padding:8px 14px; border-radius:10px; font-weight:bold; cursor:pointer;">✔️ Onayla ve gönder</button>'
                + "</div></div>";
            document.body.appendChild(m);
            const done = (v) => { document.removeEventListener("keydown", onKey, true); m.remove(); resolve(v); };
            const onKey = (e) => { if (e.key === "Escape") { e.preventDefault(); done(false); } };
            document.addEventListener("keydown", onKey, true);
            m.querySelector("#btn-havale-confirm-cancel").onclick = () => done(false);
            m.querySelector("#btn-havale-confirm-ok").onclick = () => done(true);
        });
    }
    function setHavaleStatus(d, text, kind) {
        havaleStatus[d.key] = text ? { text: text, kind: kind || "info" } : null;
        const card = document.querySelector('.ebys-havale-card[data-key="' + CSS.escape(d.key) + '"]');
        const s = card && card.querySelector(".havale-status");
        if (!s) return;
        paintStatus(s, havaleStatus[d.key]);
    }
    function paintStatus(s, st) {
        if (!st) { s.style.display = "none"; s.textContent = ""; return; }
        const col = { ok: ["#064E3B", "#A7F3D0", "#10B981"], warn: ["#78350F", "#FDE68A", "#F59E0B"], info: ["#1E293B", "#CBD5E1", "#56709A"] }[st.kind] || ["#1E293B", "#CBD5E1", "#56709A"];
        s.style.cssText = "display:block; background:" + col[0] + "; color:" + col[1] + "; border:1px solid " + col[2] + "; padding:5px 7px; border-radius:8px; font-size:10.5px; line-height:1.35;";
        s.textContent = st.text;
    }
    function havaleGuard() {
        if (havaleBusy || havaleScanning || isScanningPages) { showToast("⏳ Başka bir işlem sürüyor; bitmesini bekleyin.", "warn"); return false; }
        return true;
    }
    // ---- ana akış (tek evrak, kullanıcı başlatır; onay olmadan Tamam / Teslim Al Gönder yok)
    async function havaleRun(...a) { return autoWrap("Havale", () => havaleRun_(...a)); }
    async function havaleRun_(d, sels) {
        if (!sels.length) { showToast("⚠️ En az bir kişi seçin.", "warn"); return false; }
        if (!havaleGuard()) return false;
        havaleBusy = true;
        let phase = 0; // 0: hiçbir onay düğmesine basılmadı, 1: Tamam'a basıldı
        const stop = (msg) => {
            const tail = phase === 0 ? "EBYS ekranı olduğu gibi bırakıldı; Tamam'a ve Teslim Al Gönder'e basılmadı." : "Teslim Al Gönder'e basılmadı (gönderim yapılmadı); EBYS formu açık bırakıldı.";
            setHavaleStatus(d, "⚠️ " + msg + " " + tail, "warn");
            showToast("⚠️ Havale durduruldu: " + msg, "error"); // NEW (v3.5.2): kişiyi adıyla bildiren uyarı
            dbg("Havale durduruldu:", d.key, msg);
            alert("⚠️ Havale durduruldu: " + msg + "\n\n" + tail);
            return false;
        };
        try {
            setHavaleStatus(d, "⏳ EBYS'de hazırlanıyor (evrak açılıyor ve doğrulanıyor)…", "info");
            const f = await havaleEnsureForm(d);
            if (!f.ok) return stop(f.msg);
            if (kisiLovRows().length) return stop("Formdaki 'Kişiye Havale' listesinde zaten kişi var. EBYS'de listeyi temizleyin ya da 'Vazgeç'e basıp tekrar deneyin.");
            const q = await havaleOpenQuick();
            if (!q.ok) return stop(q.msg);
            const rp = readQuickPeople();
            savePeople(rp);
            const a = await havaleApplySelections(sels);
            if (!a.ok) return stop(a.msg);
            setHavaleStatus(d, "❓ Onayınız bekleniyor…", "info");
            const yes = await havaleConfirm(d, a, f.how);
            if (!yes) {
                setHavaleStatus(d, "✖ Vazgeçildi — EBYS'de hiçbir düğmeye basılmadı; Hızlı Seçim penceresi açık bırakıldı.", "info");
                showToast("✖ Havale onaylanmadı; EBYS'de hiçbir şeye basılmadı.", "warn");
                return false;
            }
            if (!findQuickTamam()) return stop("Hızlı Seçim penceresinde 'Tamam' düğmesi bulunamadı.");
            phase = 1;
            dbg("Hızlı Seçim → Tamam:", d.key, a.targets.length, "kişi");
            const tq = await quickTamamAndWait(); // CHANGE (v3.5.2): EBYS mesajı da gösterilir
            if (!tq.ok) return stop(tq.msg);
            const vr = verifyKisiList(a.targets);
            if (!vr.ok) return stop(vr.msg);
            const g = findToolbarButton("Teslim Al Gönder");
            if (!g) return stop("'Teslim Al Gönder' düğmesi bulunamadı.");
            setHavaleStatus(d, "⏳ Gönderiliyor…", "info");
            dbg("Teslim Al Gönder:", d.key);
            g.click();
            phase = 2;
            const res = await waitGonderResult(d);
            if (res.state === "warn") { setHavaleStatus(d, "⚠️ EBYS bir uyarı gösterdi (evrak değişikliği / kaydetme sorusu). Lütfen EBYS'de elle tamamlayın; eklenti başka düğmeye basmadı.", "warn"); alert("⚠️ EBYS bir uyarı gösterdi. Lütfen EBYS'de elle tamamlayın; eklenti başka bir düğmeye basmadı."); return false; }
            if (res.state === "error") { setHavaleStatus(d, "⚠️ EBYS hata bildirdi: " + res.msg, "warn"); alert("⚠️ EBYS hata bildirdi: " + res.msg); return false; }
            if (res.state === "timeout") { setHavaleStatus(d, "⚠️ Gönderim sonucu beklenen sürede görülmedi. EBYS'de kontrol edin, sonra listeyi yeniden tarayın.", "warn"); return false; }
            havaleDone[d.key] = { at: Date.now() };
            extStoreSet(HAVALE_DONE_KEY, havaleDone);
            d.done = true;
            setHavaleStatus(d, "✅ Havale edildi (" + a.targets.map(x => x.name + " — " + GB_TEXT[x.v]).join(", ") + ")." + (res.stillListed ? " Evrak listede hâlâ görünüyor; yeniden tarayıp kontrol edin." : " Sonraki taramada listeden düşer."), "ok");
            havaleLearnCheck(d, sels); // NEW (v3.4)
            hlRecord(d, a.targets.filter(x => x.v === "G").map(personLabel), a.targets.filter(x => x.v === "B").map(personLabel)); // NEW (v3.6.28)
            renderHavaleList();
            showToast("✅ Havale edildi: " + (d.docNo || d.subject), "ok");
            return true;
        } catch(e) {
            console.error("[Evrak Asistanı] Havale hatası:", e);
            return stop("Beklenmeyen hata: " + (e && e.message ? e.message : e));
        } finally {
            havaleBusy = false;
        }
    }
    // Kişi listesini EBYS'den oku (Hızlı Seçim penceresi). Pencere ya da form açık değilse bu evrak için açılır; hiçbir onay düğmesine basılmaz.
    async function havaleRefreshPeople(d, opts) {
        const silent = !!(opts && opts.silent); const alert = silent ? (m) => { havaleAutoReadMsg = String(m || "").replace(/^⚠️\s*/, "").replace(/^Kişi listesi okunamadı:\s*/, ""); } : window.alert.bind(window); // v3.6.36
        if (!havaleGuard()) return false;
        havaleBusy = true;
        try {
            let opened = false, formOpened = false;
            if (!isQuickOpen()) {
                if (!isHavaleFormOpen()) {
                    if (!d) { showToast("⚠️ Kişi listesini okumak için bir evrakın 📨 Havale Et bölümündeki 🔄 düğmesini kullanın.", "warn"); return false; }
                    setHavaleStatus(d, "⏳ Kişi listesi için EBYS'de havale formu açılıyor…", "info");
                    const f = await havaleEnsureForm(d);
                    if (!f.ok) { setHavaleStatus(d, "⚠️ " + f.msg + " Kişi listesi okunamadı; hiçbir onay düğmesine basılmadı.", "warn"); alert("⚠️ Kişi listesi okunamadı: " + f.msg); return false; }
                    formOpened = !f.reused;
                }
                const q = await havaleOpenQuick();
                if (!q.ok) { if (d) setHavaleStatus(d, "⚠️ " + q.msg, "warn"); alert("⚠️ Kişi listesi okunamadı: " + q.msg); return false; }
                opened = true;
            }
            const r = readQuickPeople();
            if (!r.people.length) { alert("⚠️ Hızlı Seçim penceresinde kişi bulunamadı."); return false; }
            savePeople(r); havaleAutoReadMsg = "";
            if (opened) closeQuickDialog();
            const msg = "✔️ Kişi listesi güncellendi: " + r.people.length + " kişi" + (r.multi ? " (liste birden fazla sayfa; yalnızca görünen sayfa okundu)" : "") + ".";
            if (d) setHavaleStatus(d, msg + (formOpened ? " EBYS'de bu evrakın havale formu açık kaldı; kişileri seçip devam edebilir ya da EBYS'de 'Vazgeç'e basabilirsiniz." : ""), "ok");
            showToast(msg, "ok");
            return true;
        } catch(e) {
            console.error("[Evrak Asistanı] Kişi listesi hatası:", e);
            return false;
        } finally {
            havaleBusy = false;
            renderHavalePeopleInfo();
            document.querySelectorAll(".ebys-havale-card .havale-picker").forEach(p => { if (p.style.display !== "none") renderPicker(p.closest(".ebys-havale-card")); });
        }
    }
    async function havaleOpenOnly(d) {
        if (!havaleGuard()) return;
        if (isHavaleFormOpen()) { alert("⚠️ EBYS'de açık bir havale formu var. Önce EBYS'de 'Vazgeç'e basın."); return; }
        havaleBusy = true;
        try {
            const o = await havaleOpenDoc(d);
            const v = o.ok ? await havaleVerifyPreview(d) : o;
            if (!v.ok) { setHavaleStatus(d, "⚠️ " + v.msg, "warn"); alert("⚠️ " + v.msg); return; }
            setHavaleStatus(d, "📖 Evrak açıldı (" + v.how + ").", "info");
        } finally { havaleBusy = false; }
    }

    // ---- tarama (yalnızca okur; evrak açmaz)
    async function scanTeslimAll() {
        if (!havaleGuard()) return;
        havaleScanning = true;
        const btn = document.getElementById("btn-havale-scan");
        if (btn) { btn.disabled = true; btn.innerText = "⏳ TARANIYOR..."; }
        const found = [];
        let menuFail = false, stuck = false, limitHit = false, menuCount = null, pageIndex = 1;
        const grab = () => getInboxRows().forEach(tr => { const p = parseTeslimRow(tr); if (p && !found.some(x => x.key === p.key)) found.push(p); });
        try {
            if (!(await gotoTeslim())) { menuFail = true; return; }
            if (!(await goFirstPage())) stuck = true;
            grab();
            const seen = new Set([tableSignature()]);
            while (!stuck && hasNextPage()) {
                if (pageIndex >= MAX_SCAN_PAGES) { limitHit = true; break; }
                if (!(await goNextPage())) { stuck = true; break; }
                const sig = tableSignature();
                if (seen.has(sig)) { stuck = true; break; }
                seen.add(sig);
                pageIndex++;
                grab();
            }
            menuCount = parseMenuCount(findTeslimMenuLink());
            if (pageIndex > 1) await goFirstPage();
            dbg("Teslim bekleyenler taraması:", found.length, "evrak,", pageIndex, "sayfa; menü sayısı:", menuCount ? menuCount.total : "-");
        } catch(e) {
            console.error("[Evrak Asistanı] Teslim tarama hatası:", e);
            stuck = true;
        } finally {
            havaleScanning = false;
            havaleNotices = [];
            if (menuFail) havaleNotices.push(["ebys-havale-menu-notice", "⚠️ 'Birim Evrakları > Teslim Alınmayı Bekleyenler' menüsü bulunamadı ya da açılamadı; tarama yapılmadı. " + (lastNavFailure ? lastNavFailure + " " : "") + "(🩺 Tanılama ile rapor alabilirsiniz.)", "warn"]);
            else {
                const keys = new Set(found.map(x => x.key));
                Object.keys(havaleDone).forEach(k => { if (!keys.has(k)) delete havaleDone[k]; });
                found.forEach(x => { if (havaleDone[x.key]) x.stillListed = true; });
                extStoreSet(HAVALE_DONE_KEY, havaleDone);
                havaleList = found; havaleScanned = true; havaleScanAt = Date.now(); havaleRestored = false;
                Object.keys(havaleStatus).forEach(k => { if (!keys.has(k)) delete havaleStatus[k]; });
                extStoreSet(HAVALE_SCAN_KEY, { at: havaleScanAt, list: havaleList });
                if (limitHit) havaleNotices.push(["ebys-havale-limit-notice", "⚠️ Tarama " + MAX_SCAN_PAGES + " sayfa sınırına ulaştı; sonraki sayfalar listelenmedi.", "warn"]);
                if (stuck) havaleNotices.push(["ebys-havale-stuck-notice", "⚠️ Sayfa geçişi beklenen sürede tamamlanmadı; liste eksik olabilir. Taramayı tekrar deneyin.", "warn"]);
                if (menuCount) {
                    if (menuCount.total === found.length) havaleNotices.push(["ebys-havale-count-ok", "✔️ Teslim Alınmayı Bekleyenler: " + found.length + " / " + menuCount.total + " evrak tarandı (menüdeki sayı ile aynı).", "ok"]);
                    else havaleNotices.push(["ebys-havale-count-mismatch", "⚠️ Menüde " + menuCount.total + " evrak görünüyor, " + found.length + " evrak tarandı. Liste eksik olabilir; taramayı tekrarlayın.", "warn"]);
                } else havaleNotices.push(["ebys-havale-count-none", "ℹ️ " + found.length + " evrak tarandı (" + pageIndex + " sayfa). Menüde sayı gösterilmediği için sayı karşılaştırması yapılamadı.", "info"]);
            }
            const b2 = document.getElementById("btn-havale-scan");
            if (b2) { b2.disabled = false; b2.innerText = "📨 TESLİM BEKLEYENLERİ TARA"; }
            renderHavaleList();
        }
    }

    // ---- panel: sekmeler, kartlar, kişi seçici
    function applyActiveTab() {
        const g = document.getElementById("ebys-tab-gelen"), h = document.getElementById("ebys-tab-havale");
        if (!g || !h) return;
        g.style.display = activeTab === "gelen" ? "flex" : "none";
        h.style.display = activeTab === "havale" ? "flex" : "none";
        const tk = document.getElementById("ebys-tab-takip"); // NEW (v3.5)
        if (tk) { tk.style.display = activeTab === "takip" ? "flex" : "none"; if (activeTab === "takip") renderTakipTab(); }
        document.querySelectorAll(".ebys-tab-btn").forEach(b => {
            const on = b.getAttribute("data-tab") === activeTab;
            b.style.background = on ? "#56709A" : "#2D3D63";
            b.style.color = on ? "#FFFFFF" : "#A9B6CA";
            b.style.borderColor = on ? "#00F0FF" : "#4B5D7A";
            b.setAttribute("aria-selected", on ? "true" : "false");
        });
    }
    function renderHavalePeopleInfo() {
        const el = document.getElementById("ebys-havale-people-info");
        if (!el) return;
        const n = (havalePeople.people || []).length;
        el.textContent = n
            ? "👥 Kayıtlı kişi listesi: " + n + " kişi (" + new Date(havalePeople.at).toLocaleString("tr-TR", { timeZone: "Europe/Istanbul", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) + ")" + (havalePeople.partial ? " — kısmi" : "")
            : "👥 Kişi listesi henüz okunmadı: bir evrakın 📨 Havale Et bölümünde 🔄 ile EBYS'den okuyun.";
    }
    function bindHavaleTab() {
        document.querySelectorAll(".ebys-tab-btn").forEach(b => { b.onclick = () => { activeTab = b.getAttribute("data-tab"); applyActiveTab(); }; });
        const sb = document.getElementById("btn-havale-scan");
        if (sb) {
            sb.onclick = scanTeslimAll;
            if (havaleScanning) { sb.disabled = true; sb.innerText = "⏳ TARANIYOR..."; }
        }
        applyActiveTab();
        renderHavalePeopleInfo();
        if (havaleScanned) renderHavaleList();
        bindRulesUi(); // NEW (v3.4)
        renderHqBox(); // NEW (v3.5.2)
    }
    function renderHavaleList() {
        try { renderHqBox(); } catch(e) {} // NEW (v3.5.2)
        const c = document.getElementById("ebys-havale-container");
        const tb = document.getElementById("ebys-tab-btn-havale");
        if (tb) tb.textContent = "📨 Havale" + (havaleScanned ? " (" + havaleList.length + ")" : "");
        if (!c) return;
        c.innerHTML = "";
        const notice = (id, text, kind) => {
            const n = document.createElement("div");
            n.id = id;
            paintStatus(n, { text: text, kind: kind });
            c.appendChild(n);
        };
        havaleNotices.forEach(n => notice(n[0], n[1], n[2]));
        if (havaleRestored && havaleScanAt) notice("ebys-havale-restored-notice", "🕘 Son tarama (" + new Date(havaleScanAt).toLocaleString("tr-TR", { timeZone: "Europe/Istanbul", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) + ") geri yüklendi — güncel liste için yeniden tarayın.", "info");
        if (!havaleScanned) { const e = document.createElement("div"); e.style.cssText = "text-align:center; color:#94A3B8; padding:24px; border:1px dashed #4B5D7A; border-radius:12px;"; e.textContent = "Tarama bekleniyor..."; c.appendChild(e); return; }
        if (!havaleList.length) { const e = document.createElement("div"); e.id = "ebys-havale-empty"; e.style.cssText = "text-align:center; color:#86EFAC; padding:15px; border:1px solid #22C55E; border-radius:10px;"; e.textContent = "Teslim alınmayı bekleyen evrak yok."; c.appendChild(e); return; }
        havaleList.forEach(d => {
            const card = document.createElement("div");
            card.className = "ebys-havale-card";
            card.setAttribute("data-key", d.key);
            const done = !!(d.done || havaleDone[d.key]);
            card.style.cssText = "background:#2D3D63; border:1px solid " + (done ? "#10B981" : "rgba(0,240,255,0.2)") + "; border-radius:12px; padding:10px; display:flex; flex-direction:column; gap:6px;";
            const meta = [d.tarih ? "📅 " + escapeHtml(d.tarih) : "", d.gonderen && d.gonderen !== "-" ? "🏛️ " + escapeHtml(d.gonderen) : "", d.kimde ? "👤 " + escapeHtml(d.kimde) : "👤 bilinmiyor", d.ivedi ? '<b style="color:#F87171;">İVEDİ</b>' : "", d.miat > 0 ? '<span style="color:#FB923C;">Miat: ' + escapeHtml(String(d.miat)) + " gün</span>" : ""].filter(Boolean).join(" · ");
            card.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center; gap:6px;">
                    <span class="havale-docno" style="color:#00F0FF; font-weight:bold; font-size:11px;">📄 ${escapeHtml(d.docNo || ("Kayıt No " + (d.kayitNo || "-")))}</span>
                    ${done ? '<span class="havale-done-badge" style="background:#064E3B; color:#A7F3D0; border:1px solid #10B981; padding:1px 6px; border-radius:8px; font-size:10px;">✅ Havale edildi</span>' : ""}
                    <button class="btn-havale-open" style="background:rgba(0,240,255,0.1); border:1px solid #00F0FF; color:#00F0FF; padding:2px 8px; border-radius:6px; font-size:10px; cursor:pointer;">AÇ ➔</button>
                </div>
                <div class="havale-subject" style="color:#F8FAFC; font-size:11.5px; line-height:1.3;">📌 ${escapeHtml(d.subject)}</div>
                <div class="havale-meta" style="color:#A9B6CA; font-size:10.5px; line-height:1.3;">${meta}</div>
                ${d.stillListed ? '<div class="havale-still" style="color:#FDE68A; font-size:10.5px;">⚠️ Daha önce havale edildi olarak işaretlenmişti ama listede hâlâ görünüyor; EBYS\'de kontrol edin.</div>' : ""}
                <div class="havale-status" style="display:none;"></div>
                <div class="havale-learn" style="display:none;"></div>
                <button class="btn-havale-et" ${done ? "disabled" : ""} style="background:${done ? "#4B5D7A" : "linear-gradient(135deg, #7C3AED, #6D28D9)"}; color:white; border:none; padding:6px; border-radius:8px; font-size:10.5px; font-weight:bold; cursor:${done ? "default" : "pointer"};">📨 Havale Et</button>
                <div class="havale-picker" style="display:none; background:#1F2D4D; padding:8px; border-radius:8px; flex-direction:column; gap:6px;"></div>
            `;
            paintStatus(card.querySelector(".havale-status"), havaleStatus[d.key]);
            renderLearnOffer(card, d); // NEW (v3.4)
            card.querySelector(".btn-havale-open").onclick = () => havaleOpenOnly(d);
            card.querySelector(".btn-havale-et").onclick = () => {
                const p = card.querySelector(".havale-picker");
                if (p.style.display === "flex") { p.style.display = "none"; return; }
                p.style.display = "flex";
                renderPicker(card);
            };
            c.appendChild(card);
        });
    }
    let havaleAutoReadTried = false, havaleAutoReadMsg = ""; // v3.6.36: panel açılınca bir kez otomatik okuma
    function pickerPeople() {
        const out = [], seen = new Set();
        const push = (name, title, src) => { name = String(name || "").trim(); if (!name) return; const lb = personLabel({ name: name, title: title || "" }); const k = normName(name); if (seen.has(k)) return; seen.add(k); out.push({ name: name, title: title || "", label: lb, src: src || "" }); };
        (havalePeople.people || []).forEach(x => push(x.name, x.title, ""));
        try { const rs = getRulesStore(); rs.rules.concat(rs.globalBilgi || []).forEach(r => { const t = r.target || {}; if (t.name) push(t.name, (t.titles || [])[0] || "", "kural"); }); } catch(e) {}
        try { const pn = (getOkulProfil().mudur || "").trim(); if (pn) push(pn, "Okul Müdürü", "okul profili"); } catch(e) {}
        havaleFav.forEach(l => push(l.replace(/\s*\[.*\]$/, ""), ((l.match(/\[(.*)\]$/) || [])[1]) || "", "favori"));
        return out;
    }
    function renderPicker(card) {
        if (!card) return;
        const key = card.getAttribute("data-key");
        const d = havaleList.find(x => x.key === key);
        const p = card.querySelector(".havale-picker");
        if (!d || !p) return;
        const st = havalePick[key] || (havalePick[key] = {});
        if (!(key in havaleAutoSel)) applySuggestion(d, st); // NEW (v3.4): kurala göre ön seçim (bir kez; kişi listesi gelince yeniden)
        const people = pickerPeople(); // v3.6.36: EBYS listesi (önbellek dahil) + kurallardaki kişiler + favoriler
        const ebysN = (havalePeople.people || []).length;
        if (!ebysN && !havaleAutoReadTried && !havaleBusy) { havaleAutoReadTried = true; setTimeout(() => { havaleRefreshPeople(d, { silent: true }).then(ok => { if (!ok) document.querySelectorAll(".ebys-havale-card .havale-picker").forEach(pp => { if (pp.style.display !== "none") renderPicker(pp.closest(".ebys-havale-card")); }); }); }, 50); }
        const favSet = new Set(havaleFav);
        const ordered = people.filter(x => favSet.has(x.label)).concat(people.filter(x => !favSet.has(x.label)));
        const btnCss = "background:#2D3D63; color:#E2E8F0; border:1px solid #56709A; padding:3px 7px; border-radius:6px; font-size:10px; cursor:pointer;";
        p.innerHTML = `
            <div style="display:flex; gap:4px;">
                <input class="havale-search" type="text" placeholder="Kişi ara…" style="flex:1; min-width:0; background:#2D3D63; color:#E2E8F0; border:1px solid #56709A; border-radius:6px; padding:4px 6px; font-size:11px;">
                <button class="btn-havale-read" title="Evrakı açıp önizleme metnini ve ek adlarını okuyarak öneriyi iyileştirir (EBYS'de hiçbir onay düğmesine basılmaz)" style="${btnCss}">📖 Oku ve öner</button>
                <button class="btn-havale-refresh" title="Kişi listesini EBYS'deki 'Kişiye Havale - Hızlı Seçim' penceresinden yeniden oku (onay düğmesine basılmaz)" style="${btnCss}">🔄 EBYS'den yenile</button>
            </div>
            <div class="havale-suggest" style="display:none;"></div>
            <div class="havale-fav-chips" style="display:flex; flex-wrap:wrap; gap:4px;"></div>
            <div class="havale-people" style="display:flex; flex-direction:column; gap:2px; max-height:220px; overflow-y:auto;"></div>
            <div style="display:flex; align-items:center; gap:6px;">
                <span class="havale-sel-summary" style="flex:1; color:#A9B6CA; font-size:10.5px;"></span>
                <button class="btn-havale-start" style="background:#15803D; color:white; border:none; padding:5px 10px; border-radius:8px; font-size:10.5px; font-weight:bold; cursor:pointer;">Devam ➔</button>
            </div>
            <div style="color:#94A3B8; font-size:10px;">EBYS'de seçimler yapılır; Tamam / Teslim Al Gönder'e basmadan önce onayınız istenir.</div>
        `;
        const list = p.querySelector(".havale-people");
        const chips = p.querySelector(".havale-fav-chips");
        const summary = p.querySelector(".havale-sel-summary");
        const startBtn = p.querySelector(".btn-havale-start");
        const updSummary = () => { const n = Object.keys(st).length; summary.textContent = "Seçili: " + n + (n ? " — " + Object.keys(st).map(l => l.replace(/\s*\[.*\]$/, "") + " (" + GB_TEXT[st[l]] + ")").join(", ") : " — listeden + ile kişi ekleyin"); startBtn.disabled = !n; startBtn.style.opacity = n ? "1" : "0.5"; startBtn.style.cursor = n ? "pointer" : "not-allowed"; };
        if (!ebysN) {
            const e = document.createElement("div");
            e.className = "havale-people-empty";
            e.style.cssText = "color:#FBBF24; font-size:10.5px;";
            e.textContent = havaleBusy ? "⏳ Kişi listesi EBYS'den okunuyor (hiçbir onay düğmesine basılmaz)…"
                : havaleAutoReadMsg ? "⚠️ Kişi listesi EBYS'den okunamadı: " + havaleAutoReadMsg + (people.length ? " Aşağıdaki kişiler kurallarınızdan/favorilerden; EBYS'de bulunamazsa uyarılırsınız." : " 🔄 EBYS'den yenile ile tekrar deneyin.")
                : people.length ? "Kişiler kurallarınızdan/favorilerden gösteriliyor; tam liste için 🔄 EBYS'den yenile." : "Kişi listesi okunuyor…";
            list.appendChild(e);
        }
        ordered.forEach(x => {
            const row = document.createElement("div");
            row.className = "havale-person";
            row.setAttribute("data-label", x.label);
            row.style.cssText = "display:flex; align-items:center; gap:5px; padding:2px 4px; border-radius:6px; background:" + (st[x.label] ? "#2D3D63" : "transparent") + ";";
            const v = st[x.label] || "G";
            const sel = !!st[x.label];
            row.innerHTML = '<button class="havale-add" title="' + (sel ? "Çıkar" : "Ekle") + '" style="width:22px; height:22px; padding:0; border-radius:6px; border:none; font:700 14px/1 system-ui,sans-serif; cursor:pointer; color:#fff; background:' + (sel ? "#7F1D1D" : "#15803D") + ';">' + (sel ? "−" : "+") + '</button>'
                + '<span class="havale-pname" style="flex:1; min-width:0; font-size:10.5px; color:#E2E8F0;">' + escapeHtml(x.name) + (x.title ? ' <span style="color:#94A3B8;">[' + escapeHtml(x.title) + "]</span>" : "") + (x.src ? ' <span style="color:#A78BFA; font-size:9.5px;">(' + escapeHtml(x.src) + ")</span>" : "") + "</span>"
                + '<button class="havale-gb" data-v="' + v + '" title="Gereği / Bilgi" style="min-width:52px; background:' + (v === "G" ? "#7F1D1D" : "#1E3A8A") + '; color:white; border:none; padding:2px 6px; border-radius:6px; font-size:10px; cursor:pointer;">' + GB_TEXT[v] + "</button>"
                + '<button class="havale-fav" title="Favori" style="background:none; border:none; color:' + (favSet.has(x.label) ? "#FBBF24" : "#56709A") + '; font-size:13px; cursor:pointer; padding:0 2px;">' + (favSet.has(x.label) ? "★" : "☆") + "</button>";
            const chk = row.querySelector(".havale-add"), gb = row.querySelector(".havale-gb");
            chk.onchange = chk.onclick = () => { const on = !st[x.label]; if (on) st[x.label] = gb.getAttribute("data-v"); else delete st[x.label]; chk.textContent = on ? "−" : "+"; chk.title = on ? "Çıkar" : "Ekle"; chk.style.background = on ? "#7F1D1D" : "#15803D"; row.style.background = on ? "#2D3D63" : "transparent"; updSummary(); };
            gb.onclick = () => {
                const nv = gb.getAttribute("data-v") === "G" ? "B" : "G";
                gb.setAttribute("data-v", nv); gb.textContent = GB_TEXT[nv]; gb.style.background = nv === "G" ? "#7F1D1D" : "#1E3A8A";
                if (st[x.label]) st[x.label] = nv;
                updSummary();
            };
            row.querySelector(".havale-fav").onclick = () => {
                if (favSet.has(x.label)) havaleFav = havaleFav.filter(f => f !== x.label); else havaleFav.push(x.label);
                extStoreSet(HAVALE_FAV_KEY, havaleFav);
                const q = p.querySelector(".havale-search").value;
                renderPicker(card);
                const s2 = card.querySelector(".havale-search"); if (s2 && q) { s2.value = q; s2.dispatchEvent(new Event("input")); }
            };
            list.appendChild(row);
        });
        ordered.filter(x => favSet.has(x.label)).forEach(x => {
            const chip = document.createElement("button");
            chip.className = "havale-fav-chip";
            chip.style.cssText = "background:#2D3D63; color:#FBBF24; border:1px solid #FBBF24; padding:1px 6px; border-radius:10px; font-size:10px; cursor:pointer;";
            chip.textContent = "★ " + x.name;
            chip.title = "Seç / bırak: " + x.label;
            chip.onclick = () => { const row = Array.from(list.querySelectorAll(".havale-person")).find(r => r.getAttribute("data-label") === x.label); const chk = row && row.querySelector(".havale-add"); if (chk) chk.onclick(); };
            chips.appendChild(chip);
        });
        if (!chips.children.length) chips.style.display = "none";
        p.querySelector(".havale-search").oninput = (e) => {
            const q = normName(e.target.value);
            list.querySelectorAll(".havale-person").forEach(r => { r.style.display = !q || normName(r.getAttribute("data-label")).includes(q) ? "flex" : "none"; });
        };
        p.querySelector(".btn-havale-refresh").onclick = () => havaleRefreshPeople(d);
        p.querySelector(".btn-havale-read").onclick = () => havaleReadForSuggest(d, card); // NEW (v3.4)
        renderSuggestBox(card, d); // NEW (v3.4)
        p.querySelector(".btn-havale-start").onclick = async () => {
            const labels = Object.keys(st);
            if (!labels.length) { showToast("⚠️ En az bir kişi seçin.", "warn"); return; }
            const sels = labels.map(l => { const x = people.find(y => y.label === l) || { name: l.replace(/\s*\[.*\]$/, ""), title: ((l.match(/\[(.*)\]$/) || [])[1]) || "" }; return { name: x.name, title: x.title, v: st[l] }; });
            const ok = await havaleRun(d, sels);
            if (ok) { delete havalePick[key]; }
        };
        updSummary();
    }

    // =========================================================================
    // NEW (v3.4): HAVALE KURALLARI — evrakın konusuna (ve istenirse metnine) göre Gereği/Bilgi önerisi.
    // Kurallar yalnızca bu bilgisayarda (chrome.storage.local "ebys_havale_rules_v1"); kodda hiçbir kişi adı / okula özgü kural yoktur.
    // Öneri yalnızca seçicide ön seçim yapar; gönderim v3.3'teki onay + Tamam sonrası doğrulama akışından geçer.
    // =========================================================================
    const HC = (function() {
    // ---- Evrak Asistanı havale çekirdeği (v3.4): Türkçe eşleştirme, hazır anahtar kelime setleri, kural deposu, yönlendirme, görev dağılımı ayrıştırma.
    // Tek kaynak: hem content.js'e hem setup sayfasına (havale_core.js) aynen gömülür. Gerçek kişi adı / okula özgü kural İÇERMEZ.
    const RULES_KEY = "ebys_havale_rules_v1";
    const RULES_FILE_TYPE = "evrak-asistani-havale-kurallari";
    const KEYWORD_SETS = [
        { id: "isg", label: "İSG / İş Güvenliği", keywords: ["isg", "iş sağlığı", "iş güvenliği", "risk değerlendirmesi", "acil durum", "tatbikat", "yangın", "deprem", "sivil savunma"] },
        { id: "personel", label: "Personel İşleri", keywords: ["personel", "izin", "rapor", "görevlendirme", "atama", "ek ders", "maaş", "özlük", "mesai", "nöbet", "hizmet içi eğitim", "disiplin", "sicil"] },
        { id: "sosyal", label: "Sosyal Etkinlikler / Kulüpler / TÜBİTAK", keywords: ["sosyal etkinlik", "sosyal faaliyet", "kulüp", "tübitak", "proje", "yarışma", "olimpiyat", "gezi", "şenlik", "tiyatro", "sergi", "çevre", "e-twinning", "etwinning", "erasmus", "bilim fuarı", "toplum hizmeti"] },
        { id: "kantin", label: "Kantin / Öğrenci Sözleşmeleri", keywords: ["kantin", "kafeterya", "kira", "ihale", "kantin işletme", "hijyen", "gıda", "beslenme", "sözleşme", "öğrenci sözleşmesi", "veli sözleşmesi"] },
        { id: "ogrenci", label: "Öğrenci İşleri / Devamsızlık / Nakil / Burs", keywords: ["öğrenci işleri", "devamsızlık", "nakil", "burs", "mezuniyet", "diploma", "öğrenci belgesi", "karne", "sınıf geçme"] },
        { id: "sinav", label: "Sınav / Ölçme Değerlendirme", keywords: ["sınav", "ölçme değerlendirme", "ortak sınav", "lgs", "yks", "e-sınav", "sınav görevlisi"] },
        { id: "tasima", label: "Taşımalı Eğitim / Servis", keywords: ["taşımalı eğitim", "taşıma", "servis", "okul servis"] },
        { id: "rehberlik", label: "Rehberlik", keywords: ["rehberlik", "psikolojik danışma", "rehber öğretmen", "ram", "kariyer", "akran zorbalığı"] },
        { id: "bilgiislem", label: "Bilgi İşlem / e-Okul / MEBİS", keywords: ["bilgi işlem", "e-okul", "mebis", "mebbis", "eba", "internet", "bilgisayar", "etkileşimli tahta", "siber"] },
        { id: "tasinir", label: "Taşınır / Demirbaş / Satın Alma / Bütçe", keywords: ["taşınır", "demirbaş", "satın alma", "bütçe", "ödenek", "harcama", "fatura", "muhasebe", "tif", "kbs"] },
        { id: "temizlik", label: "Temizlik / Bakım / Onarım", keywords: ["temizlik", "bakım", "onarım", "tadilat", "tesisat", "bahçe", "ısınma", "yakıt", "kalorifer"] },
        { id: "pansiyon", label: "Pansiyon", keywords: ["pansiyon", "yatılı", "belletmen", "iaşe"] },
        { id: "saglik", label: "Pandemi / Sağlık", keywords: ["pandemi", "salgın", "sağlık", "aşı", "bulaşıcı hastalık", "okul sağlığı", "beyaz bayrak"] }
    ];
    const isObj = v => v !== null && typeof v === "object" && !Array.isArray(v);
    const DIA = { "ç": "c", "ğ": "g", "ı": "i", "ö": "o", "ş": "s", "ü": "u", "â": "a", "î": "i", "û": "u" };
    function fold(s, dia) {
        let t = String(s || "").toLocaleLowerCase("tr").normalize("NFC");
        if (dia !== false) t = t.replace(/[çğıöşüâîû]/g, c => DIA[c]).normalize("NFD").replace(/[\u0300-\u036f]/g, "");
        return t;
    }
    function tokenize(s, dia) { return fold(s, dia).split(/[^0-9a-zçğıöşüâîû]+/).filter(Boolean); }
    function soften(w, dia) {
        if (w.length < 4) return null;
        if (/nk$/.test(w)) return w.slice(0, -1) + "g";
        const last = w.slice(-1);
        const m = { p: "b", t: "d", "ç": "c", k: dia === false ? "ğ" : "g" }[last];
        return m ? w.slice(0, -1) + m : null;
    }
    function compileKeyword(kw, dia) {
        const words = tokenize(kw, dia);
        if (!words.length) return null;
        return { kw: String(kw).trim(), words: words.map(w => ({ w: w, exact: w.length <= 3, stems: [w, soften(w, dia)].filter(Boolean) })) };
    }
    const tokMatch = (tok, w) => (w.exact ? tok === w.w : w.stems.some(s => tok.startsWith(s)));
    function matchCompiled(tokens, c) {
        if (!c) return false;
        const n = c.words.length;
        for (let i = 0; i + n <= tokens.length; i++) {
            let ok = true;
            for (let j = 0; j < n && ok; j++) ok = tokMatch(tokens[i + j], c.words[j]);
            if (ok) return true;
        }
        return false;
    }
    function matchKeyword(text, kw, dia) { return matchCompiled(tokenize(text, dia), compileKeyword(kw, dia)); }
    function splitList(s) { return String(s || "").split(/[,;\n]+/).map(x => x.trim()).filter(Boolean); }
    function uniqFold(list) { const seen = new Set(), out = []; list.forEach(x => { const k = fold(x); if (k && !seen.has(k)) { seen.add(k); out.push(x); } }); return out; }
    let idSeq = 0;
    const newId = () => "r" + Date.now().toString(36) + (++idSeq).toString(36) + Math.random().toString(36).slice(2, 6);
    // ---- kural deposu (doğrulama / temizleme)
    function sanitizeRules(v) {
        const s = isObj(v) ? v : {};
        const str = (x, n) => (typeof x === "string" ? x.slice(0, n).trim() : "");
        const list = (x, n) => (Array.isArray(x) ? x : typeof x === "string" ? splitList(x) : []).filter(y => typeof y === "string").map(y => y.trim().slice(0, 120)).filter(Boolean).slice(0, n || 300);
        const target = t => ({ name: str(isObj(t) ? t.name : "", 120), titles: list(isObj(t) ? t.titles : [], 5) });
        const prio = p => (Number.isFinite(+p) ? Math.max(-99, Math.min(99, Math.round(+p))) : 0);
        const rules = (Array.isArray(s.rules) ? s.rules : []).filter(isObj).slice(0, 200).map(r => ({
            id: str(r.id, 40) || newId(), enabled: r.enabled !== false, role: str(r.role, 80), target: target(r.target),
            type: r.type === "B" ? "B" : "G", keywords: uniqFold(list(r.keywords)), negative: uniqFold(list(r.negative)), priority: prio(r.priority), source: str(r.source, 20)
        })).filter(r => r.target.name || r.target.titles.length);
        const globalBilgi = (Array.isArray(s.globalBilgi) ? s.globalBilgi : []).filter(isObj).slice(0, 20).map(g => ({
            id: str(g.id, 40) || newId(), enabled: g.enabled !== false, role: str(g.role, 80), target: target(g.target)
        })).filter(g => g.target.name || g.target.titles.length);
        const o = isObj(s.options) ? s.options : {};
        return { rules: rules, globalBilgi: globalBilgi, options: { threshold: Math.max(1, Math.min(50, Math.round(+o.threshold) || 3)), foldDiacritics: o.foldDiacritics !== false }, template: sanitizeTemplate(s.template, rules) };
    }
    // ---- v3.6.29: ortak MADDE ŞABLONU (her madde tek konu; birleşik maddeler ayrıldı). Kişi adı İÇERMEZ.
    const ITEM_TEMPLATE = [
        ["isg", "İSG / İş Güvenliği", "isg, iş sağlığı, iş güvenliği, risk değerlendirmesi, ramak kala, iş kazası"],
        ["sivilsavunma", "Sivil Savunma / Acil Durum / Tatbikat", "sivil savunma, acil durum, tatbikat, yangın, deprem, afet"],
        ["personel", "Personel İşleri / Özlük", "personel, özlük, sicil, kişisel dosya, hizmet belgesi"],
        ["izin", "İzin / Rapor", "izin, rapor, sağlık raporu, yıllık izin, mazeret izni"],
        ["gorevlendirme", "Görevlendirme / Atama", "görevlendirme, atama, ders görevi, norm kadro"],
        ["ekders", "Ek Ders / Maaş / Tahakkuk", "ek ders, maaş, yan ödeme, tahakkuk, ücret onay, ödeme tahakkuk, gider gerçekleştirme, gerçekleştirme görevlilik, mali ödeme, kbs"],
        ["nobet", "Nöbet / Mesai", "nöbet, nöbet çizelgesi, mesai, fazla mesai"],
        ["hizmetici", "Hizmet İçi Eğitim / Seminer", "hizmet içi eğitim, seminer, mesleki çalışma, mesleki gelişim"],
        ["disiplin", "Disiplin / Soruşturma", "disiplin, soruşturma, inceleme, şikayet"],
        ["toplanti", "Toplantılar / Kurullar", "toplantı, toplant gündemin, öğretmenler kurulu, zümre, şube öğretmenler kurulu"],
        ["stratejik", "Stratejik Plan / Kalite", "stratejik plan, faaliyet raporu, iç kontrol, kalite"],
        ["sosyal", "Sosyal Etkinlikler", "sosyal etkinlik, sosyal faaliyet, şenlik, tiyatro, sergi, toplum hizmeti, belirli gün"],
        ["kulup", "Öğrenci Kulüpleri", "kulüp, öğrenci kulübü, öğrenci meclisi"],
        ["tubitak", "TÜBİTAK / Bilim Fuarı", "tübitak, bilim fuarı, araştırma projesi, 4006, 2204"],
        ["proje", "Projeler / AR-GE", "proje, arge, araştırma geliştirme, proje araştırma, fikir otobü"],
        ["abproje", "AB Projeleri / Erasmus / eTwinning", "erasmus, e-twinning, etwinning, avrupa, ab projesi, ulusal ajans"],
        ["yarisma", "Yarışmalar / Olimpiyatlar", "yarışma, olimpiyat, ödül, beceri yarışması"],
        ["gezi", "Geziler / İzinli Etkinlikler", "gezi, inceleme gezisi, kamp, gezi izni"],
        ["spor", "Spor / Beden Eğitimi", "beden eğitim, spor, okul sporları, turnuva"],
        ["cevre", "Çevre / Sıfır Atık", "çevre, sıfır atık, geri dönüşüm, enerji tasarrufu"],
        ["web", "Web Sitesi / Sosyal Medya", "web, web sitesi, sosyal medya, haber yayını"],
        ["kantin", "Kantin", "kantin, kafeterya, kantin işletme, kantin denetim"],
        ["sozlesme", "Öğrenci / Veli Sözleşmeleri", "öğrenci sözleşmesi, veli sözleşmesi, sözleşme"],
        ["kiraihale", "Kira / İhale", "kira, ihale, kiralama, kik"],
        ["hijyen", "Hijyen / Gıda / Beslenme", "hijyen, gıda, beslenme, gıda denetim"],
        ["ogrenciisleri", "Öğrenci İşleri", "öğrenci işleri, öğrenci belgesi, kütük defter, not çizelge, kayıt kabul"],
        ["devamsizlik", "Devamsızlık / Özür", "devamsızlık, özür tezkere, devam durumu"],
        ["nakil", "Nakil / Kayıt", "nakil, nakil işlemleri, okula yeni"],
        ["burs", "Burs / Parasız Yatılılık", "burs, pyb, parasız yatılı, bursluluk"],
        ["mezuniyet", "Mezuniyet / Diploma / Denklik", "mezuniyet, diploma, ait denklik, denklik, onur belge"],
        ["karne", "Karne / Sınıf Geçme", "karne, sınıf geçme, sorumluluk sınavı, takdir teşekkür"],
        ["sinav", "Sınavlar / Ölçme Değerlendirme", "sınav, ölçme değerlendirme, ortak sınav, lgs, yks, e-sınav, sınav görevlisi"],
        ["tasima", "Taşımalı Eğitim", "taşımalı eğitim, taşıma, taşımalı"],
        ["servis", "Okul Servisi", "servis, okul servis, öğrenci servis"],
        ["rehberlik", "Rehberlik / Psikolojik Danışma", "rehberlik, psikolojik danışma, rehber öğretmen, danışma servi, akran zorbalığı, kariyer"],
        ["ozelegitim", "Özel Eğitim / BEP / RAM", "bep, ram, özel eğitim, kaynaştırma, destek eğitim"],
        ["dyk", "Destekleme ve Yetiştirme Kursları (DYK)", "dyk, destekleme ve yetiştirme, yetiştirme kursu"],
        ["bilgiislem", "Bilgi İşlem / Donanım / İnternet", "bilgi işlem, internet, bilgisayar, etkileşimli tahta, siber, fatih projesi"],
        ["eokul", "e-Okul", "e-okul, eokul"],
        ["mebbis", "MEBBİS / MEBİS / EBA", "mebbis, mebis, eba, piktes"],
        ["tasinir", "Taşınır / Demirbaş", "taşınır, demirbaş, tif, sayımla, mal yönetmelik, tkys"],
        ["satinalma", "Satın Alma", "satın alma, satınalma, doğrudan temin, yoğaltım malzeme, fotokop maki"],
        ["butce", "Bütçe / Muhasebe / Ödenek", "bütçe, ödenek, harcama, fatura, muhasebe"],
        ["temizlik", "Temizlik / Temiz Okul", "temizlik, temiz-okul, beyaz bayrak"],
        ["bakim", "Bakım / Onarım", "bakım, onarım, tadilat, tesisat"],
        ["bahce", "Bahçe / Çevre Düzenleme", "bahçe, çevre düzenleme, ağaçlandırma"],
        ["isinma", "Isınma / Yakıt", "ısınma, yakıt, kalorifer, doğalgaz"],
        ["pansiyon", "Pansiyon / Yatılılık", "pansiyon, yatılı, belletmen, iaşe"],
        ["saglik", "Okul Sağlığı / Salgın", "okul sağlığı, pandemi, salgın, aşı, bulaşıcı hastalık, sağlık taraması"],
        ["sgk", "SGK / Sigorta", "sgk, sigorta, sigortalılık, işe giriş"],
        ["tefbis", "TEFBİS / Okul Gelirleri", "tefbis, okul gelir, bağış"],
        ["beceri", "İşletmelerde Beceri Eğitimi / Staj", "becer eğitim, işletmelerde beceri, staj, işe yerleştirme, meslek eğitim, teknik eğitimde"],
        ["mtoyk", "Mesleki Kurslar / Yaygın Eğitim", "mtoyk, meslek kurs, yaygın meslek, kurs periyodik, periyodik denetimin"],
        ["atp", "Program / Alan-Dal (ATP)", "atp, anadol teknik, teknik program, alan temrinlik, çerçeve öğretim programı"],
        ["kitap", "Ders Kitabı Dağıtımı", "kitap dağıtımın, ders kitabı, ücretsiz kitap"],
        ["okulaile", "Okul Aile Birliği", "aile birlik, okul aile birliği"],
        ["evrak", "Evrak / Arşiv / Yazı İşleri", "büro memur, gelen-giden evrak, arşiv, örnek dosya, yazılan asıl"],
        ["isku", "İŞKUR / Kamu Yararına Çalışma", "işkur, typ, toplum yararına program"],
        ["stk", "STK / Kurum Dışı İş Birliği", "stk, protokol, iş birliği"],
        ["cocuk", "Çocuk Koruma / Güvenlik", "yaşından küçük, çocuk istismarı, okul güvenliği, koruyucu önleyici"]
    ].map(a => ({ id: a[0], label: a[1], keywords: a[2].split(/\s*,\s*/) }));
    const TPL_SRC = "şablon";
    // şablon: { enabled, items:[{id,label,keywords,custom}], removed:[id], people:[{id,name,titles,assign:{itemId:"G"|"B"},priority,negative,fromRule}] }
    function templateFromRules(rules) {
        const items = ITEM_TEMPLATE.map(x => ({ id: x.id, label: x.label, keywords: x.keywords.slice(), custom: false }));
        const people = [];
        (rules || []).filter(r => r.source !== TPL_SRC).forEach(r => {
            const kws = r.keywords.map(k => fold(k));
            const assign = {}, used = new Set();
            items.forEach(it => { const ik = new Set(it.keywords.map(k => fold(k))); kws.forEach(k => { if (ik.has(k)) { assign[it.id] = r.type; used.add(k); } }); });
            const left = r.keywords.filter(k => !used.has(fold(k)));
            if (left.length) { const cid = "c_" + r.id; items.push({ id: cid, label: (r.role || targetText(r.target)) + " (özel)", keywords: left, custom: true }); assign[cid] = r.type; }
            let p = people.find(x => fold(x.name) === fold(r.target.name) && x.titles.join("|") === r.target.titles.join("|"));
            if (!p) { p = { id: "p_" + r.id, name: r.target.name, titles: r.target.titles.slice(), assign: {}, priority: r.priority, negative: r.negative.slice(), fromRule: [] }; people.push(p); }
            if (r.enabled) { Object.keys(assign).forEach(k => { if (!p.assign[k] || assign[k] === "G") p.assign[k] = assign[k]; }); }
            else p.disabledRules = (p.disabledRules || 0) + 1;
            p.fromRule.push(r.id);
        });
        return { enabled: false, migrated: false, items: items, removed: [], people: people };
    }
    function sanitizeTemplate(t, rules) {
        if (!isObj(t)) return templateFromRules(rules);
        const str = (x, n) => (typeof x === "string" ? x.slice(0, n).trim() : "");
        const list = (x, n) => (Array.isArray(x) ? x : typeof x === "string" ? splitList(x) : []).filter(y => typeof y === "string").map(y => y.trim().slice(0, 120)).filter(Boolean).slice(0, n || 300);
        const seen = new Set();
        const items = (Array.isArray(t.items) ? t.items : []).filter(isObj).map(i => ({ id: str(i.id, 40), label: str(i.label, 80), keywords: uniqFold(list(i.keywords)), custom: !!i.custom }))
            .filter(i => i.id && i.label && !seen.has(i.id) && seen.add(i.id)).slice(0, 300);
        const ids = new Set(items.map(i => i.id));
        const people = (Array.isArray(t.people) ? t.people : []).filter(isObj).slice(0, 100).map(p => {
            const a = {}; if (isObj(p.assign)) Object.keys(p.assign).forEach(k => { if (ids.has(k) && (p.assign[k] === "G" || p.assign[k] === "B")) a[k] = p.assign[k]; });
            const o = { id: str(p.id, 40) || newId(), name: str(p.name, 120), titles: list(p.titles, 5), assign: a, priority: Number.isFinite(+p.priority) ? Math.max(-99, Math.min(99, Math.round(+p.priority))) : 0, negative: uniqFold(list(p.negative)), fromRule: list(p.fromRule, 50) };
            if (+p.disabledRules) o.disabledRules = +p.disabledRules;
            return o;
        }).filter(p => p.name || p.titles.length);
        return { enabled: t.enabled === true, migrated: t.migrated === true, items: items, removed: list(t.removed, 300), people: people };
    }
    // şablon → mevcut kural biçimi (kişi başına Gereği ve Bilgi için birer kural; eşleştirme kodu aynen çalışır)
    function templateToRules(t) {
        const out = [];
        const byId = {}, rm = new Set(t.removed || []); (t.items || []).forEach(i => { if (!rm.has(i.id)) byId[i.id] = i; });
        (t.people || []).forEach(p => {
            ["G", "B"].forEach(ty => {
                const its = Object.keys(p.assign || {}).filter(k => p.assign[k] === ty && byId[k]).map(k => byId[k]);
                if (!its.length) return;
                out.push({ id: "t_" + p.id + "_" + ty, enabled: true, role: its.map(i => i.label).join(", ").slice(0, 80), target: { name: p.name, titles: p.titles.slice() },
                    type: ty, keywords: uniqFold([].concat.apply([], its.map(i => i.keywords))), negative: (p.negative || []).slice(), priority: p.priority || 0, source: TPL_SRC });
            });
        });
        return out;
    }
    // şablonu kurallara uygula: eski şablon kuralları çıkarılır, yenileri eklenir; şablona aktarılmış eski kurallar SİLİNMEZ, yalnızca kapatılır
    function applyTemplate(store) {
        const t = store.template;
        if (!t) return store;
        const wasOn = t.enabled;
        t.enabled = true;
        const from = new Set([].concat.apply([], (t.people || []).map(p => p.fromRule || [])));
        store.rules = store.rules.filter(r => r.source !== TPL_SRC);
        if (!wasOn || !t.migrated) { store.rules.forEach(r => { if (from.has(r.id)) r.enabled = false; }); t.migrated = true; }
        store.rules = store.rules.concat(templateToRules(t));
        return store;
    }
    function isRulesFile(v) { return isObj(v) && (Array.isArray(v.rules) || Array.isArray(v.globalBilgi)); }
    function rulesToFile(store) { return Object.assign({ type: RULES_FILE_TYPE, version: 1, exportedAt: new Date().toISOString() }, sanitizeRules(store)); }
    // ---- kişi çözümleme: ada ve/veya ünvana göre, kişi listesinde TAM OLARAK bir kişi olmalı
    const normP = s => String(s || "").replace(/\s+/g, " ").trim().toLocaleUpperCase("tr");
    const labelOf = p => p.name + (p.title ? " [" + p.title + "]" : "");
    // NEW (v3.6.36): müdür gevşek eşleşme — "Okul Müdürü", "Müdür", "Kurum Müdürü", "Müdür V." ve okul profilindeki müdür adı (yardımcılar hariç)
    let principalName = "";
    function setPrincipal(n) { principalName = String(n || "").trim(); }
    const isMudurTitle = s => { const f = fold(s).replace(/[^a-z ]/g, " ").replace(/\s+/g, " ").trim(); return /\bmudur(u)?\b/.test(f) && !/yard|yrd|bas ?yard/.test(f); };
    function isMudurTarget(t) { return (t.titles || []).some(isMudurTitle); }
    function looseMudur(people) {
        const P = people || [];
        if (principalName) { const pn = fold(principalName).replace(/\s+/g, " "); const h = P.filter(p => fold(p.name).replace(/\s+/g, " ") === pn); if (h.length) return h; }
        const exact = P.filter(p => fold(p.title).replace(/[^a-z]/g, "") === "mudur" || fold(p.title).replace(/[^a-z]/g, "") === "okulmuduru");
        if (exact.length) return exact;
        return P.filter(p => isMudurTitle(p.title));
    }
    function resolveTarget(target, people) {
        const t = target || {};
        const titles = (t.titles || []).map(normP).filter(Boolean);
        const name = normP(t.name);
        if (!name && !titles.length) return { status: "invalid", hits: [] };
        let hits = (people || []).filter(p => (!name || normP(p.name) === name));
        if (titles.length) {
            if (name) { const both = hits.filter(p => titles.includes(normP(p.title))); if (both.length) hits = both; }
            else {
                for (const tt of titles) { const h = (people || []).filter(p => normP(p.title) === tt); if (h.length) { hits = h; break; } else hits = []; }
            }
        }
        if (!hits.length && isMudurTarget(t)) hits = looseMudur(people); // NEW (v3.6.36): Okul Müdürü / Müdür / profil adı gevşek eşleşme
        return { status: hits.length === 1 ? "ok" : hits.length ? "ambiguous" : "notfound", hits: hits, person: hits.length === 1 ? hits[0] : null, label: hits.length === 1 ? labelOf(hits[0]) : "", loose: !!(hits.length && isMudurTarget(t)) };
    }
    function targetText(t) { return [t.name, (t.titles || []).length ? "[" + t.titles.join(" / ") + "]" : ""].filter(Boolean).join(" ") || "-"; }
    // ---- yönlendirme: konu (×3) + gönderen (×1) + evrak metni (×1); eşik altı / eşitlik → öneri yok ("emin değilim")
    function routeDoc(doc, store, people) {
        const st = sanitizeRules(store);
        const dia = st.options.foldDiacritics;
        const F = { konu: tokenize(doc.subject, dia), gonderen: tokenize(doc.gonderen, dia), metin: tokenize(doc.body || "", dia) };
        const W = { konu: 3, gonderen: 1, metin: 1 };
        const scored = [];
        st.rules.filter(r => r.enabled).forEach(r => {
            const why = { konu: [], gonderen: [], metin: [] };
            let score = 0;
            r.keywords.forEach(k => { const c = compileKeyword(k, dia); Object.keys(F).forEach(f => { if (matchCompiled(F[f], c)) { why[f].push(k); score += W[f]; } }); });
            const neg = r.negative.filter(k => { const c = compileKeyword(k, dia); return matchCompiled(F.konu, c) || matchCompiled(F.metin, c); });
            const res = resolveTarget(r.target, people);
            scored.push({ rule: r, score: neg.length ? 0 : score, rawScore: score, negative: neg, why: why, res: res, key: res.label || ("?" + targetText(r.target)) });
        });
        const byPerson = {};
        scored.filter(x => x.rule.type === "G").forEach(x => {
            const cur = byPerson[x.key];
            if (!cur || x.score > cur.score || (x.score === cur.score && x.rule.priority > cur.rule.priority)) byPerson[x.key] = x;
        });
        const cands = Object.values(byPerson).filter(x => x.score > 0).sort((a, b) => (b.score - a.score) || (b.rule.priority - a.rule.priority));
        const thr = st.options.threshold;
        const top = cands[0], second = cands[1];
        let gerek = null, reason = "";
        if (!st.rules.length) reason = "norules";
        else if (!top || top.score < thr) reason = "nomatch";
        else if (second && second.score === top.score && second.rule.priority === top.rule.priority) reason = "tie";
        else if (top.res.status !== "ok") reason = "unresolved";
        else gerek = top;
        const bilgi = [], warnings = [];
        if (top && reason === "unresolved") warnings.push((top.rule.role || targetText(top.rule.target)) + ": kişi listesinde " + (top.res.status === "ambiguous" ? "birden fazla kişi eşleşti" : "bulunamadı"));
        scored.filter(x => x.rule.type === "B" && x.score >= thr).forEach(x => {
            if (x.res.status === "ok") { if (!bilgi.some(b => b.label === x.res.label)) bilgi.push({ label: x.res.label, role: x.rule.role, why: x.why, global: false }); }
            else warnings.push((x.rule.role || targetText(x.rule.target)) + " (Bilgi): kişi listesinde bulunamadı");
        });
        st.globalBilgi.filter(g => g.enabled).forEach(g => {
            const r = resolveTarget(g.target, people);
            if (r.status === "ok") { if (!bilgi.some(b => b.label === r.label)) bilgi.push({ label: r.label, role: g.role, why: null, global: true }); }
            else warnings.push((g.role || targetText(g.target)) + " (her evrakta Bilgi): kişi listesinde " + (r.status === "ambiguous" ? "birden fazla kişi eşleşti" : "bulunamadı") + " — isterseniz aşağıdan + ile Bilgi olarak ekleyin");
        });
        const finalBilgi = bilgi.filter(b => !gerek || b.label !== gerek.res.label);
        return {
            gerek: gerek ? { label: gerek.res.label, role: gerek.rule.role, score: gerek.score, why: gerek.why, ruleId: gerek.rule.id, byPriority: !!(second && second.score === gerek.score) } : null,
            uncertain: !gerek, reason: reason, threshold: thr,
            candidates: cands.slice(0, 2).map(x => ({ label: x.res.label, display: x.res.label || targetText(x.rule.target), role: x.rule.role, score: x.score, why: x.why, resolved: x.res.status === "ok" })),
            bilgi: finalBilgi, warnings: warnings, usedBody: !!doc.body
        };
    }
    function whyText(why) {
        if (!why) return "";
        const n = { konu: "konu", gonderen: "gönderen", metin: "evrak metni" };
        return Object.keys(n).filter(f => why[f] && why[f].length).map(f => n[f] + ": " + why[f].join(", ")).join(" · ");
    }
    // ---- görev metninden anahtar kelime üretimi
    const STOP = new Set(("ve veya ile ilgili ilişkin için gibi her türlü diğer vb vs bu şu o da de ki en çok daha olan olarak tarafından üzere göre kadar ise bir iki üç " +
        "işlerini işlerinin işleri işi işler işlemlerini işlemleri işlemlerinin işlem işlemler yürütmek yürütülmesi yürütme yürütür takip etmek takibi takibini etmek yapmak yapılması yapılmasını yapar " +
        "sağlamak sağlanması hazırlamak hazırlanması hazırlar düzenlemek düzenlenmesi düzenler koordine koordinasyon koordinesini görev görevi görevleri görevler görevlerini sorumlu sorumluluğu " +
        "verilen verilecek yazışmalar yazışmaları yazışma okul okulun okulumuz müdürlük müdürlüğü müdür yardımcısı başyardımcısı yardımcıları ilgili kurul kurulu çalışmaları çalışmalarını " +
        "konularda konusunda alanında bulunmak katılmak kontrol kontrolü denetlemek planlamak planlanması izlemek tutmak tutulması istenen ilgilenmek mevzuat gereği gereken " +
        "eder yapar sağlar saklar tutar sunar verir alır bildirir izler oluşturur getirir belirler gerçekleştirir bulunur istenir yapılır edilir olur olup olduğu olduğun olduğunuz olduğunda " +
        "sorumluluğundaki sorumluluğunuzdaki sorumluluğunu sorumluluğunda sorumluluğuna gerekenlere gerekli gerektirdiği gerektiren tüm bütün aynı son sürekli düzenli günlük aylık yıllık " +
        "kendi kendilerine kendisine kendisi kendileri inci ıncı uncu üncü nci ncı biri birlikte ortak beraber ayrıca durumunda durumu durumunu yönelik dair hakkında sonra önce içerisinde içinde arasında " +
        "sınıf sınıfların sınıfın sınıfları ders dersleri derslerin öğretmen öğretmenler öğretmenlerin öğretmenleri müdürün müdüre müdürüne müdürlüğe müdürlüğüne yardımcısına yardımcıları " +
        "işi iş işlemlerin işlerle işlerinin konu konuları gün günü günlerde ay ayın yıl yılı dönem dönemi bilgi bilgileri belgeleri evrakları yazıları sistem sistemine sistemi " +
        "sunmak sunulması iletmek bildirmek teslim vermek almak yaptırmak etmek eden edilen edilmesi olan olması yer alan çalışmak çalışma paylaşmak hazırlayarak yaparak takip " +
        "yapan veren alan olan gelen giden bulunan yapılan yapılacak edilecek hazırlanacak belirtilen gereğince uygun usulüne usulü " +
        "onay onayı onayına onayını veli velisi velisine velileri koordinatör memur memurlar başkanlık başkanlığı başkanlığını başkanlığın başkanlığında komisyon komisyonu komisyonuna komisyonlara " +
        "ekip ekibi ekipler ekiplere ihtiyaç ihtiyacı ihtiyaçları ihtiyaçlarını tedbir tedbirleri tedbirlerini milli millî eğitim bakanlığı yetkili yetkilisi sorumludur sorumludurlar sonuçlandırır " +
        "okulumuzda okulumuzdaki sonunda başında öğrenci öğrenciler öğrencilerin öğrencileri öğrencinin öğrenciye öğrencilere kayıt kaydı biri birlikte şekilde şekli halinde hâlinde").split(/\s+/));
    const VERBISH_RE = /(mak|mek|maktır|mektir|arak|erek|ıyor|iyor|uyor|üyor|acak|ecek|ılır|ilir|ulur|ülür|ınır|inir|nması|nmesi|lması|lmesi|ılması|ilmesi|ulması|ülmesi|dığı|diği|duğu|düğü|tığı|tiği|tuğu|tüğü|ınız|iniz|unuz|ünüz|masını|mesini|masına|mesine|mada|mede|masından|mesinden|mayan|meyen|ılan|ilen|ulan|ülen|lanan|lenen)$/;
    const ACRONYM_RE = /^[A-ZÇĞİÖŞÜ][A-ZÇĞİÖŞÜ0-9.]{1,}$/;
    const VOW = /[aeıioöuü]$/;
    function stemWord(w) {
        // koşullu, tek katmanlı Türkçe ek budama (aşırı budamaya karşı): çoğul/hâl ekleri, ünlüden sonra iyelik+tamlayan, ünsüzden sonra tek ünlü
        let t = String(w).toLocaleLowerCase("tr");
        const multi = ["lerinin", "larının", "lerinde", "larında", "lerini", "larını", "lerine", "larına", "lerden", "lardan", "ndaki", "ndeki", "leri", "ları", "lerin", "ların", "ler", "lar"];
        for (let guard = 0; guard < 3; guard++) {
            const m = multi.find(x => t.endsWith(x) && t.length - x.length >= 4);
            if (m) { t = t.slice(0, -m.length); continue; }
            const g = ["nın", "nin", "nun", "nün", "sı", "si", "su", "sü", "na", "ne"].find(x => t.endsWith(x) && t.length - x.length >= 4 && VOW.test(t.slice(0, -x.length)));
            if (g) { t = t.slice(0, -g.length); continue; }
            if (/[ıiuü]$/.test(t) && t.length - 1 >= 5 && !VOW.test(t.slice(0, -1))) { t = t.slice(0, -1); continue; }
            break;
        }
        const fin = { "ğ": "k", b: "p", d: "t" }[t.slice(-1)];
        if (fin && t.length >= 4) t = t.slice(0, -1) + fin;
        return t;
    }
    function dutyPhrases(duty) {
        // noktalama ile ayrılan bölümler içinde ardışık içerik kelimelerinden 1–2 kelimelik öbekler (kökleri); fiilimsi/genel kelimeler öbeği böler; kısa kısaltmalar (DYK, TEFBİS…) aynen alınır
        const out = [];
        String(duty).replace(/[“”"]/g, " ").replace(/['’][a-zçğıöşü]+/gi, " ").split(/[,.;:()[\]/!?]+/).forEach(seg => {
            const words = seg.split(/[^0-9A-Za-zÇĞİÖŞÜçğıöşüÂÎÛâîû-]+/).map(w => w.replace(/^-+|-+$/g, "")).filter(Boolean);
            const caps = words.map(w => ACRONYM_RE.test(w));
            let run = [];
            const flush = () => {
                for (let i = 0; i < run.length; i++) {
                    if (i + 1 < run.length && stemWord(run[i].w) !== stemWord(run[i + 1].w)) out.push((run[i].acr ? run[i].w : stemWord(run[i].w)) + " " + (run[i + 1].acr ? run[i + 1].w : stemWord(run[i + 1].w)));
                    if (run[i].acr || run[i].w.length >= 6) out.push(run[i].acr ? run[i].w : stemWord(run[i].w));
                }
                run = [];
            };
            words.forEach((w, i) => {
                const l = w.toLocaleLowerCase("tr");
                // tamamı büyük harf kısa kelime ve komşuları büyük harfle yazılmış sıradan kelimeler değilse → kısaltma
                const acr = caps[i] && w.length >= 2 && w.length <= 7 && !(caps[i - 1] || caps[i + 1]) && !/^(T\.C\.|TC|EBYS|MEB)$/.test(w) && !STOP.has(l);
                if (STOP.has(l) || /^\d/.test(l) || (!acr && (l.length < 3 || VERBISH_RE.test(l)))) flush(); else run.push({ w: acr ? l : l, acr: acr });
            });
            flush();
        });
        return out.filter(p => p.replace(/\s/g, "").length >= 3);
    }
    function isAcronymPhrase(p, duties) { return duties.some(d => new RegExp("(^|[^A-Za-zÇĞİÖŞÜçğıöşü])" + p.toLocaleUpperCase("tr").replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "([^A-Za-zÇĞİÖŞÜçğıöşü]|$)").test(d)); }
    // Vekâlet ("X izinli/raporlu olduğunda görevlerini yürütmek") ve genel kapanış ("müdür tarafından verilen diğer görevler") görevleri anahtar kelime üretmez
    const SKIP_DUTY_RE = /(izinli|raporlu|görevli|yokluğunda)[^.]{0,60}(olması|olduğu|bulunduğu|durumunda|günlerde|vekalet|vekâlet)|vekalet etmek|vekâlet etmek|tarafından verilen.{0,40}diğer görev|verilecek diğer görev|vereceği diğer görev/i;
    function isSkippedDuty(d) { return SKIP_DUTY_RE.test(String(d)); }
    function deriveKeywords(duties, allPersonsDuties, opts) {
        opts = opts || {};
        const use = duties.filter(d => !isSkippedDuty(d));
        const text = use.join("\n");
        const toks = tokenize(text);
        const others = (allPersonsDuties && allPersonsDuties.length >= 3) ? allPersonsDuties.map(ds => tokenize(ds.filter(d => !isSkippedDuty(d)).join("\n"))) : null;
        const common = (k) => { if (!others) return false; const c = compileKeyword(k); return others.filter(t => matchCompiled(t, c)).length >= Math.max(3, Math.ceil(others.length * 0.4)); };
        const nameToks = new Set((opts.names || []).flatMap(n => tokenize(n)).filter(t => t.length >= 3));
        const hasName = (p) => tokenize(p).some(t => nameToks.has(t));
        const sets = [];
        let kws = [];
        KEYWORD_SETS.forEach(s => {
            const hit = s.keywords.filter(k => matchCompiled(toks, compileKeyword(k)) && !common(k));
            if (!hit.length) return;
            const full = hit.length >= Math.max(3, Math.ceil(s.keywords.length * 0.4));
            sets.push({ id: s.id, label: s.label, hits: hit, full: full });
            kws = kws.concat(hit); // setin tamamı otomatik eklenmez; inceleme ekranında tek tıkla eklenebilir
        });
        let phrases = [];
        use.forEach(d => { phrases = phrases.concat(dutyPhrases(d)); });
        phrases = phrases.filter(p => !common(p) && !hasName(p));
        const covered = (p) => kws.some(k => matchKeyword(p, k) || matchKeyword(k, p));
        const maxP = opts.maxPhrases || 12;
        const freq = {};
        phrases.forEach(p => { const k = fold(p); freq[k] = (freq[k] || 0) + 1; });
        const acr = (p) => !/\s/.test(p) && isAcronymPhrase(p, use) ? 1 : 0;
        const ranked = uniqFold(phrases).filter(p => !covered(p)).sort((a, b) => (acr(b) - acr(a)) || (b.split(" ").length - a.split(" ").length) || (freq[fold(b)] - freq[fold(a)]));
        const picked = [];
        ranked.forEach(p => { if (picked.length < maxP && !picked.some(q => matchKeyword(p, q) || matchKeyword(q, p))) picked.push(p); });
        kws = uniqFold(kws.concat(picked));
        return { keywords: kws, sets: sets, skipped: duties.length - use.length };
    }
    // Kişiler arası çakışan anahtar kelimeler (eşit puan / yanlış öneri riski)
    function findOverlaps(persons) {
        const out = [];
        const comp = persons.map(p => (p.keywords || []).map(k => ({ k: k, c: compileKeyword(k), t: tokenize(k) })));
        for (let i = 0; i < persons.length; i++) for (let j = i + 1; j < persons.length; j++) {
            comp[i].forEach(a => comp[j].forEach(b => {
                if (matchCompiled(b.t, a.c) || matchCompiled(a.t, b.c)) out.push({ keyword: a.k, other: b.k, a: i, b: j });
            }));
        }
        return out;
    }
    // ---- görev dağılımı PDF metni → kişi bölümleri (satırlar pdf.js metin içeriğinden konuma göre birleştirilmiş olarak gelir)
    const TITLE_RE = /(Müdür\s*Baş\s*Yardımcısı|Müdür\s*Başyardımcısı|Müdür\s*Yardımcısı|Md\.?\s*Yrd\.?|Okul\s*Müdürü|Müdürü?|Öğretmen|Memur|Sayman|Şef)/i;
    const NAME_STOP = new Set(["SAYIN", "SN", "SN.", "T.C.", "TC", "MÜDÜR", "MÜDÜRÜ", "YARDIMCISI", "BAŞYARDIMCISI", "GÖREV", "GÖREVLERİ", "DAĞILIMI", "EĞİTİM", "ÖĞRETİM", "YILI", "ADI", "SOYADI", "UNVANI", "ÜNVANI", "SIRA", "NO", "OKUL", "LİSESİ", "MÜDÜRLÜĞÜ", "VALİLİĞİ", "KONU", "SAYI", "İLGİ", "TARİH", "EK", "DAĞITIM", "ONAY", "OLUR", "TABLOSU", "LİSTESİ", "KURULU", "İŞLERİ"]);
    function findNamesInLine(text, people) {
        const found = [];
        const T = normP(text);
        (people || []).forEach(p => { const n = normP(p.name); if (n.length >= 5 && T.includes(n)) found.push({ name: p.name, title: p.title || "", known: true, idx: T.indexOf(n), raw: n }); });
        if (found.length) return found;
        const re = /((?:[A-ZÇĞİÖŞÜ][a-zçğıöşü]+\s+){1,2})([A-ZÇĞİÖŞÜ]{2,}(?:\s+[A-ZÇĞİÖŞÜ]{2,})?)(?![a-zçğıöşü])/g;
        let m;
        while ((m = re.exec(text))) {
            const given = m[1].trim().split(/\s+/).filter(w => !NAME_STOP.has(normP(w)) && !TITLE_RE.test(w));
            const sur = m[2].trim().split(/\s+/).filter(w => !NAME_STOP.has(w));
            if (!given.length || !sur.length) continue;
            if (given.some(w => /^(Sayın|Konu|Sayı|İlgi|Tarih|Okul|Lisesi|Müdürlüğü)$/i.test(w))) continue;
            found.push({ name: given.join(" ") + " " + sur.join(" "), title: "", known: false, idx: m.index, raw: normP(given.join(" ") + " " + sur.join(" ")) });
        }
        if (!found.length && TITLE_RE.test(text)) { // TAMAMI BÜYÜK HARF ad + ünvan aynı satırda (ör. "ZEYNEP KARACA  Müdür Yardımcısı")
            const re2 = /\b([A-ZÇĞİÖŞÜ]{2,}(?:\s+[A-ZÇĞİÖŞÜ]{2,}){1,2})\b/g;
            while ((m = re2.exec(text))) { const ws = m[1].split(/\s+/).filter(w => !NAME_STOP.has(w)); if (ws.length >= 2) found.push({ name: ws.slice(0, -1).map(w => w.charAt(0) + w.slice(1).toLocaleLowerCase("tr")).join(" ") + " " + ws[ws.length - 1], title: "", known: false, idx: m.index, raw: normP(ws.join(" ")) }); }
        }
        return found;
    }
    const BULLET_RE = /^\s*(?:[•\-–—*▪●○►✓·■□]|\(?\d{1,2}[.)-]|[a-zçğıöşü][.)])\s+/;
    function splitDuties(lines) {
        const duties = [];
        lines.forEach(l => {
            const t = l.replace(/\s+/g, " ").trim();
            if (!t) return;
            const prev = duties[duties.length - 1];
            if (BULLET_RE.test(t) || !prev || /[.;:]$/.test(prev) && /^[A-ZÇĞİÖŞÜ0-9]/.test(t)) duties.push(t.replace(BULLET_RE, "").trim());
            else duties[duties.length - 1] = prev + " " + t;
        });
        return duties.map(d => d.replace(/\s+/g, " ").trim()).filter(d => d.length >= 4);
    }
    function parseDutyDocument(lines, people) {
        // lines: [{ text, cells?: [...] }] belge sırasıyla. Dönüş: { persons: [{ name, title, known, duties }], unassigned: [...] }
        const sections = []; let cur = null; const pre = [];
        lines.forEach(L => {
            let text = typeof L === "string" ? L : L.text;
            const names = findNamesInLine(text, people);
            if (names.length) {
                const n = names.sort((a, b) => a.idx - b.idx)[0];
                const tm = text.match(TITLE_RE);
                let key = normP(n.name);
                let sec = sections.find(s => normP(s.name) === key);
                if (!sec) { sec = { name: n.name, title: n.title || (tm ? tm[1].replace(/\s+/g, " ") : ""), known: n.known, lines: [] }; sections.push(sec); }
                else if (!sec.title && tm) sec.title = tm[1].replace(/\s+/g, " ");
                cur = sec;
                // satırdan ad, ünvan, sıra no ve "Sayın" çıkarılır; kalan metin görev başlangıcıdır
                let rest = text;
                const idxN = normP(rest).indexOf(n.raw);
                if (idxN >= 0) rest = rest.slice(0, idxN) + " " + rest.slice(idxN + n.raw.length);
                rest = rest.replace(TITLE_RE, " ").replace(/^\s*\d{1,2}[.)]?\s+/, " ").replace(/\b(Sayın|Sn\.)\s*/gi, " ").replace(/^[\s:,\-–]+/, "").trim();
                if (rest && /[a-zçğıöşü]{3,}/.test(rest)) cur.lines.push(rest);
                return;
            }
            if (cur) cur.lines.push(text); else pre.push(text);
        });
        const persons = sections.map(s => ({ name: s.name, title: s.title, known: s.known, duties: splitDuties(s.lines) })).filter(p => p.duties.length || p.known);
        return { persons: persons, preamble: splitDuties(pre) };
    }
    // ---- Kişiye özel görev yazısı ("Konu: Görevleriniz (Ad SOYAD Ünvan)", "Sayın : Ad SOYAD" + ünvan, numaralı görevler)
    function normTitle(t) {
        let s = String(t || "").replace(/[()]/g, " ").replace(/\s+/g, " ").trim();
        if (!s) return "";
        s = s.replace(/yad[ıi]mc[ıi]s[ıi]/gi, "yardımcısı").replace(/YAD[IİI]MC[IİI]S[IİI]/g, "YARDIMCISI");
        s = s.replace(/baş\s+yardımcı/gi, "başyardımcı").replace(/BAŞ\s+YARDIMCI/g, "BAŞYARDIMCI");
        s = s.split(" ").map(w => w.charAt(0).toLocaleUpperCase("tr") + w.slice(1).toLocaleLowerCase("tr")).join(" ");
        s = s.replace(/Başyardımcı/g, "Başyardımcı").replace(/\bVe\b/g, "ve");
        return s;
    }
    const LETTER_TITLE_RE = /(müdür|yard[ıi]mc|yad[ıi]mc|memur|öğretmen|hizmetli|teknisyen|sayman|şef|koordinatör|idari|hizmetleri)/i;
    const NAME_ONLY_RE = /^(?:[A-ZÇĞİÖŞÜ][a-zçğıöşü]+\s+){1,2}[A-ZÇĞİÖŞÜ]{2,}(?:\s+[A-ZÇĞİÖŞÜ]{2,})?$/;
    const FOOTER_RE = /güvenli elektronik imza ile imzalanmıştır|^Doğrulama Kodu|^Kep Adresi|^Telefon No|Bilgi için\s*:/i;
    function isLetter(lines) {
        const T = lines.slice(0, 40).map(l => typeof l === "string" ? l : l.text);
        return T.some(t => /^\s*Sayın\s*[:;]/i.test(t) || /^\s*Sayın\s+\S/i.test(t)) && T.some(t => /Görevleriniz|görevleriniz|göreviniz/i.test(t));
    }
    function parseDutyLetter(lines, people) {
        const L = lines.map(l => typeof l === "string" ? { text: l, cells: [{ x: 0, text: l }], page: 1 } : l);
        let name = "", title = "", role = "", known = false, sayinIdx = -1;
        // 1) "Sayın" satırı (+ sonraki kısa satır ünvan) ve Konu parantezi
        for (let i = 0; i < Math.min(L.length, 40); i++) {
            const t = L[i].text.trim();
            const m = t.match(/^Sayın\s*[:;]?\s*(.*)$/i);
            if (!m) continue;
            sayinIdx = i;
            let rest = m[1].trim();
            const nx = L[i + 1] && L[i + 1].text.trim();
            if (nx && nx.length <= 60 && LETTER_TITLE_RE.test(nx) && !/[.]$/.test(nx) && !/^\d/.test(nx)) title = normTitle(nx);
            const nm = findNamesInLine(rest, people);
            if (nm.length) { name = nm[0].name; known = nm[0].known; if (nm[0].title) title = title || nm[0].title; const after = rest.slice(rest.toLocaleUpperCase("tr").indexOf(nm[0].raw) + nm[0].raw.length).trim(); if (!title && after && LETTER_TITLE_RE.test(after)) title = normTitle(after); }
            else if (rest && NAME_ONLY_RE.test(rest.replace(/[,;:]+$/, ""))) name = rest.replace(/[,;:]+$/, "");
            break;
        }
        const konuI = L.findIndex(l => /^\s*Konu\s*:/i.test(l.text));
        if (konuI >= 0) {
            let k = L[konuI].text.replace(/^\s*Konu\s*:\s*/i, "");
            if (/\([^)]*$/.test(k) && L[konuI + 1]) k += " " + L[konuI + 1].text.trim();
            const pm = k.match(/\(([^)]*)\)/);
            if (pm) {
                const inner = pm[1].trim();
                const nm = findNamesInLine(inner, people);
                if (nm.length) {
                    if (!name) { name = nm[0].name; known = nm[0].known; }
                    const after = inner.slice(inner.toLocaleUpperCase("tr").indexOf(nm[0].raw) + nm[0].raw.length).trim();
                    if (!title && after && LETTER_TITLE_RE.test(after)) title = normTitle(after);
                }
            }
        }
        // 2) görev bölümünün başlığı ("KOORDİNATÖR MÜDÜR YARDIMCISI OLARAK GÖREVLERİNİZ") → görev etiketi
        const head = L.find(l => /GÖREVLERİNİZ/.test(l.text) && /[A-ZÇĞİÖŞÜ]{4,}/.test(l.text.replace(/GÖREVLERİNİZ/, "")));
        if (head) role = normTitle(head.text.replace(/OLARAK|GÖREVLERİNİZ|:/g, " "));
        if (!title && role) title = role;
        if (people && people.length && name) {
            const pk = people.filter(p => normP(p.name) === normP(name));
            if (pk.length === 1) { known = true; name = pk[0].name; if (pk[0].title) { if (title && normP(title) !== normP(pk[0].title)) role = role || title; title = pk[0].title; } }
        }
        // 3) görevler: sıralı numara (1-, 2., 3)) ya da harf (a), b.) ile başlayan maddeler; alt maddeler (a., -, 3-a)) ayrı madde olur
        const duties = []; let started = false, expect = 1, cur = null, inFooter = false, curPage = 0, parentNo = "";
        const topRe = /^\s*(\d{1,2})\s?[-.)]\s*(?=[A-ZÇĞİÖŞÜ0-9"'(“])/;
        const letRe = /^\s*([a-zçğıöşü])[.)]\s+/;
        const subRe = /^\s*(?:[-–•▪]\s+|\d{1,2}\s?-\s?[a-zçğıöşü]\)\s*)/;
        let letterMode = false;
        for (let i = Math.max(0, sayinIdx + 1); i < L.length; i++) {
            const l = L[i]; const t = l.text.trim();
            if (l.page !== curPage) { curPage = l.page; inFooter = false; }
            if (FOOTER_RE.test(t)) { inFooter = true; continue; }
            if (inFooter || !t) continue;
            if (/^\d+\s*\/\s*\d+$/.test(t)) continue;
            if (started && (l.cells || []).length && l.cells.every(c => NAME_ONLY_RE.test(c.text))) break; // imza bloğu
            const tm = t.match(topRe), lm = t.match(letRe), sm = t.match(subRe);
            if (tm && +tm[1] >= expect && +tm[1] <= expect + 2 && (started || +tm[1] === 1) && !letterMode) { started = true; expect = +tm[1] + 1; parentNo = tm[1]; cur = { no: tm[1], text: t.replace(topRe, "").trim() }; duties.push(cur); splitInline(); continue; }
            if (!started && lm && lm[1] === "a") { started = true; letterMode = true; }
            if (lm && started && letterMode) { cur = { no: lm[1], text: t.replace(letRe, "").trim() }; duties.push(cur); continue; }
            if (started && (sm || lm) && cur) { cur = { no: parentNo + "." + (lm ? lm[1] : "-"), text: t.replace(lm ? letRe : subRe, "").trim(), sub: true }; duties.push(cur); continue; }
            if (started && cur) { cur.text += " " + t; if (!letterMode) splitInline(); continue; }
        }
        function splitInline() { // aynı satırda sonraki madde ("… etmek. 16- Ayrıca …" ya da satır sonunda "16-")
            for (let g = 0; g < 5; g++) {
                const re = new RegExp("([.;:])\\s*(" + expect + "|" + (expect + 1) + ")\\s?[-.)](?:\\s+(?=[A-ZÇĞİÖŞÜ0-9\"'(“])|\\s*$)");
                const m = cur.text.match(re);
                if (!m) return;
                const rest = cur.text.slice(m.index + m[0].length);
                cur.text = cur.text.slice(0, m.index + 1);
                expect = +m[2] + 1; parentNo = m[2];
                cur = { no: m[2], text: rest.trim() }; duties.push(cur);
            }
        }
        duties.forEach(d => { d.text = d.text.replace(/\s+/g, " ").replace(/\s+([.,;])/g, "$1").trim(); d.skip = isSkippedDuty(d.text); });
        return { letter: true, name: name, title: title, role: role, known: known, duties: duties.filter(d => d.text.length >= 3) };
    }
    // Başlık satırlı tablo ("Sıra | Adı Soyadı | Unvanı | Görevleri"): hücreler sütun konumuna göre atanır; sarılmış ad/ünvan satırları birleştirilir
    function parseDutyTable(lines, people) {
        const L = lines.filter(l => l && l.items && l.items.length);
        const hi = L.findIndex(l => /ad[ıi]\s*soyad|ad[ıi]\s*-\s*soyad|personel/i.test(l.text) && /görev/i.test(l.text) && l.items.length >= 2);
        if (hi < 0) return null;
        // tablo satırları: başlıktan sonra, aralarında büyük dikey boşluk olmayan satırlar
        const body = []; let lastY = L[hi].y, page = L[hi].page, minGap = 1e9;
        for (let i = hi + 1; i < L.length; i++) {
            const l = L[i];
            if (l.page !== page) { page = l.page; lastY = l.y + 14; if (/görev/i.test(l.text) && /ad[ıi]/i.test(l.text)) { lastY = l.y; continue; } }
            if (FOOTER_RE.test(l.text)) continue;
            const gap = lastY - l.y;
            if (gap > 40 || (minGap < 1e9 && gap > Math.max(20, minGap * 2.4))) break; // tablo bitti (imza vb.)
            if (gap > 2) minGap = Math.min(minGap, gap);
            lastY = l.y; body.push(l);
        }
        if (!body.length) return null;
        // sütun başlangıçları: satırlarda tekrar eden x konumları; başlık öğelerinin (ortalanmış olabilir) solundaki en sık konum seçilir
        const cl = [];
        body.forEach(l => l.items.forEach(it => { const c = cl.find(c => Math.abs(c.x - it.x) <= 3); if (c) c.n++; else cl.push({ x: it.x, n: 1 }); }));
        const hdr = L[hi].items.slice().sort((a, b) => a.x - b.x).filter(h => /\S/.test(h.s));
        const kinds = hdr.map(h => /s[ıi]ra|^no\b|^#/i.test(h.s) ? "no" : /görev/i.test(h.s) && !/unvan|ünvan/i.test(h.s) ? "duty" : /unvan|ünvan|kadro/i.test(h.s) ? "title" : /ad[ıi]|soyad|personel|isim/i.test(h.s) ? "name" : "other");
        const cols = []; let prev = -1e9;
        hdr.forEach((h, i) => {
            const center = h.x + (h.w || 0) / 2;
            const cand = cl.filter(c => c.x > prev + 5 && c.x <= center + 5 && c.n >= 2);
            if (!cand.length) return;
            const best = cand.reduce((a, b) => b.n > a.n ? b : a);
            cols.push({ kind: kinds[i], x: best.x }); prev = best.x;
        });
        if (!cols.some(c => c.kind === "name") || !cols.some(c => c.kind === "duty")) return null;
        const colOf = (x) => { let k = cols[0].kind; cols.forEach(c => { if (x >= c.x - 3) k = c.kind; }); return k; };
        const rows = []; let cur = null;
        const hasNo = cols.some(c => c.kind === "no");
        body.forEach(l => {
            const parts = { no: [], name: [], title: [], duty: [], other: [] };
            l.items.forEach(it => parts[colOf(it.x)].push(it.s.trim()));
            const startsRow = hasNo ? (parts.no.length && /^\d{1,3}[.)]?$/.test(parts.no.join(""))) : (parts.name.length && (!cur || cur.duty.length));
            if (startsRow || !cur) { cur = { name: [], title: [], duty: [] }; rows.push(cur); }
            cur.name.push(...parts.name); cur.title.push(...parts.title); if (parts.duty.length) cur.duty.push(parts.duty.join(" "));
        });
        const persons = [];
        rows.forEach(r => {
            const nameTxt = r.name.join(" ").replace(/\s+/g, " ").trim();
            if (!nameTxt) return;
            const nm = findNamesInLine(nameTxt, people);
            let name = nm.length ? nm[0].name : nameTxt;
            let known = nm.length ? !!nm[0].known : false;
            let title = normTitle(r.title.join(" "));
            if (people && people.length) { const pk = people.filter(p => normP(p.name) === normP(name)); if (pk.length === 1) { known = true; name = pk[0].name; if (pk[0].title) title = pk[0].title; } }
            persons.push({ name, title, known, duties: splitDuties(r.duty) });
        });
        return persons.length ? { persons } : null;
    }
    // Belge türünü seçer: kişiye özel yazı → tek kişi; değilse çok kişili tablo/liste
    function parseDutyPdf(lines, people) {
        if (isLetter(lines)) {
            const r = parseDutyLetter(lines, people);
            return { kind: "letter", persons: [{ name: r.name, title: r.title, role: r.role, known: r.known, duties: r.duties.map(d => d.text), dutyItems: r.duties }] };
        }
        const t = parseDutyTable(lines, people);
        const r = t ? { persons: t.persons, preamble: [] } : parseDutyDocument(lines, people);
        return { kind: r.persons.length ? "table" : "unknown", persons: r.persons.map(p => Object.assign({ role: "", dutyItems: p.duties.map((t, i) => ({ no: String(i + 1), text: t, skip: isSkippedDuty(t) })) }, p)), preamble: r.preamble };
    }
    // pdf.js metin öğeleri → satırlar (sayfa sayfa; y'ye göre gruplanır, x'e göre sıralanır; büyük boşluk hücre ayırır)
    function itemsToLines(pages) {
        const out = [];
        pages.forEach((items, pageIdx) => {
            const rows = [];
            // döndürülmüş öğeler (e-imza / doğrulama damgası vb.) atlanır
            items.filter(it => it && typeof it.str === "string" && it.str.trim() && !(it.transform && (Math.abs(it.transform[1]) > 0.01 || Math.abs(it.transform[2]) > 0.01))).forEach(it => {
                const x = it.transform[4], y = it.transform[5], h = Math.abs(it.transform[3]) || 10;
                let r = rows.find(r => Math.abs(r.y - y) <= Math.max(2, h * 0.4));
                if (!r) { r = { y: y, items: [] }; rows.push(r); }
                r.items.push({ x: x, w: it.width || it.str.length * h * 0.5, s: it.str });
            });
            const pageMaxX = rows.reduce((m, r) => Math.max(m, ...r.items.map(i => i.x)), 0);
            rows.sort((a, b) => b.y - a.y).forEach(r => {
                r.items.sort((a, b) => a.x - b.x);
                const cells = []; let c = null, endX = -1e9;
                r.items.forEach(it => { if (!c || it.x - endX > 14) { c = { x: it.x, s: it.s }; cells.push(c); } else c.s += (it.x - endX > 1.5 && !/\s$/.test(c.s) ? " " : "") + it.s; endX = it.x + it.w; });
                // satır sonunda, sayfanın en sağında tek başına duran 1–3 haneli rakam hücresi: damga/doğrulama gürültüsü
                for (let ci = cells.length - 1; ci > 0; ci--) if (/^-?\d{1,3}-?$/.test(cells[ci].s.trim()) && cells[ci].x >= pageMaxX - 25) cells.splice(ci, 1);
                const text = cells.map(c => c.s.trim()).join("   ");
                if (/^[\d\s\-–—/.]+$/.test(text) && !/^\d+\s*\/\s*\d+$/.test(text.trim())) return; // yalnızca rakam/çizgi: damga gürültüsü
                out.push({ text: text, cells: cells.map(c => ({ x: Math.round(c.x), text: c.s.trim() })), items: r.items.filter(i => i.s.trim()).map(i => ({ x: Math.round(i.x), w: Math.round(i.w), s: i.s })), y: r.y, page: pageIdx + 1 });
            });
        });
        return out;
    }
    return { RULES_KEY, RULES_FILE_TYPE, KEYWORD_SETS, ITEM_TEMPLATE, TPL_SRC, templateFromRules, sanitizeTemplate, templateToRules, applyTemplate, fold, tokenize, compileKeyword, matchKeyword, matchCompiled, splitList, uniqFold, newId, sanitizeRules, isRulesFile, rulesToFile,
        resolveTarget, setPrincipal, targetText, labelOf, routeDoc, whyText, stemWord, dutyPhrases, deriveKeywords, isSkippedDuty, findOverlaps, findNamesInLine, splitDuties, parseDutyDocument, parseDutyTable, normTitle, isLetter, parseDutyLetter, parseDutyPdf, itemsToLines };
    })();
    const havaleSuggest = {};   // anahtar → son yönlendirme sonucu
    const havaleAutoSel = {};   // anahtar → otomatik ön seçimler {etiket: G|B}
    const havaleBody = {};      // anahtar → "Oku ve öner" ile okunan evrak metni (yalnızca bellekte; kaydedilmez)
    const havaleLearn = {};     // anahtar → onaylı havalede önerilenden farklı Gereği kişisi (kurala ekleme teklifi)
    let setupHintDismissed = false;
    function getRulesStore() { return HC.sanitizeRules(extStoreGet(HC.RULES_KEY)); }
    function rulesCount(st) { st = st || getRulesStore(); return st.rules.length + st.globalBilgi.length; }
    function saveRulesStore(st) {
        const clean = HC.sanitizeRules(st);
        extStoreSet(HC.RULES_KEY, clean);
        refreshRulesUi();
        return clean;
    }
    function refreshRulesUi() {
        const n = rulesCount();
        const b = document.getElementById("btn-havale-rules");
        if (b) b.textContent = "⚙️ Havale Kuralları" + (n ? " (" + n + ")" : "");
        const ob = document.getElementById("ebys-havale-onboard");
        if (ob) {
            if (n) { ob.style.display = "none"; ob.innerHTML = ""; }
            else {
                ob.style.cssText = "display:block; background:#1E3A5F; color:#DBEAFE; border:1px solid #60A5FA; padding:8px; border-radius:10px; font-size:11px; line-height:1.45;";
                ob.innerHTML = "<b>🧭 İlk kurulum — havale önerileri</b><br>Okulunuzun <b>görev dağılımı</b> belgesini (PDF; her müdür yardımcısı için ayrı PDF de olabilir) yükleyin; eklenti görevlerden havale kurallarını önerir, siz kontrol edip kaydedersiniz. PDF yalnızca bu bilgisayarda okunur.<div style=\"display:flex; gap:6px; margin-top:6px;\"><button class=\"btn-onboard-setup\" style=\"flex:1; background:#2563EB; color:white; border:none; padding:5px; border-radius:8px; font-size:10.5px; font-weight:bold; cursor:pointer;\">📄 Görev Dağılımı Yükle (PDF)</button><button class=\"btn-onboard-manual\" style=\"flex:1; background:#2D3D63; color:#DBEAFE; border:1px solid #60A5FA; padding:5px; border-radius:8px; font-size:10.5px; cursor:pointer;\">⚙️ Kuralları elle gir</button></div>";
                ob.querySelector(".btn-onboard-setup").onclick = openSetupPage;
                ob.querySelector(".btn-onboard-manual").onclick = openRulesModal;
            }
        }
        const hint = document.getElementById("ebys-setup-hint");
        if (hint) {
            if (n || setupHintDismissed) { hint.style.display = "none"; hint.innerHTML = ""; }
            else {
                hint.style.cssText = "display:flex; align-items:center; gap:6px; background:#1E293B; color:#BFDBFE; border:1px dashed #60A5FA; padding:5px 8px; border-radius:10px; font-size:10.5px;";
                hint.innerHTML = '<span style="flex:1;">💡 Havale önerileri için okulunuzun görev dağılımını yükleyin.</span><button class="btn-hint-go" style="background:#2563EB; color:white; border:none; padding:3px 8px; border-radius:6px; font-size:10px; cursor:pointer;">Başla</button><button class="btn-hint-later" title="Bu oturumda gizle" style="background:none; color:#94A3B8; border:none; font-size:12px; cursor:pointer;">✕</button>';
                hint.querySelector(".btn-hint-go").onclick = () => { activeTab = "havale"; applyActiveTab(); };
                hint.querySelector(".btn-hint-later").onclick = () => { setupHintDismissed = true; refreshRulesUi(); };
            }
        }
        const tb = document.getElementById("rules-test-input");
        if (tb && JSON.stringify(getRulesStore()) !== rulesModalShown) renderRulesModal(); // yalnızca başka yerden (kurulum sayfası / başka sekme) değiştiyse yeniden çiz
    }
    function openSetupPage() {
        let url = "";
        try { url = chrome.runtime.getURL("setup.html"); } catch(e) {}
        if (!url) { alert("⚠️ Kurulum sayfası açılamadı. Eklenti menüsünden (Seçenekler) açabilirsiniz."); return; }
        dbg("Kurulum sayfası açılıyor:", url);
        try { window.open(url, "_blank", "noopener"); } catch(e) {}
    }
    try {
        if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) chrome.storage.onChanged.addListener((ch) => { if (ch && ch[HC.RULES_KEY]) setTimeout(refreshRulesUi, 0); });
    } catch(e) {}

    // ==== HL-BEGIN (v3.6.28) havale öğrenme çekirdeği — saf fonksiyonlar; yalnızca bu bilgisayarda ====
    const HL = (function() {
        const KEY = "ebys_havale_learn_v1", SET_KEY = "ebys_havale_learn_set_v1", MAX = 1000;
        const STOP = new Set(("ve veya ile için icin ile ilgili hakkında hakkinda konu konusu bu şu bir olan olarak gibi da de ki mi en çok daha her tüm tum ait göre gore dair üzere uzere sayılı sayili tarihli tarih yazı yazi yazısı yazisi talep talebi müdürlüğü mudurlugu müdürlüğüne mudurlugune bakanlığı bakanligi valiliği valiligi kaymakamlığı kaymakamligi ilçe ilce il milli millî eğitim egitim meb okul okulu lisesi mtal mesleki teknik anadolu t.c tc ilişkin iliskin istenen istenilen hk ilg").split(/\s+/));
        function fold(s) {
            const D = { "ç": "c", "ğ": "g", "ı": "i", "ö": "o", "ş": "s", "ü": "u", "â": "a", "î": "i", "û": "u" };
            return String(s || "").toLocaleLowerCase("tr").normalize("NFC").replace(/[çğıöşüâîû]/g, c => D[c]).normalize("NFD").replace(/[\u0300-\u036f]/g, "");
        }
        function keywords(subject) {
            const out = [];
            fold(subject).split(/[^0-9a-z]+/).forEach(w => {
                if (w.length < 3 || /^\d+$/.test(w) || STOP.has(w)) return;
                const k = w.length > 6 ? w.slice(0, 6) : w; // kaba gövde: ek farklarını tolere eder
                if (!out.includes(k)) out.push(k);
            });
            return out.slice(0, 20);
        }
        function senderKey(g) { return fold(String(g || "").split(/\s\/\s/)[0]).replace(/[^0-9a-z]+/g, " ").trim(); }
        function makeRecord(doc, gerek, bilgi, at) {
            return { at: at || Date.now(), sender: senderKey(doc.gonderen), kw: keywords(doc.subject), konu: String(doc.subject || "").slice(0, 160),
                gerek: (gerek || []).map(String).filter(Boolean).slice(0, 5), bilgi: (bilgi || []).map(String).filter(Boolean).slice(0, 15) };
        }
        function addRecord(list, rec) {
            list = Array.isArray(list) ? list.filter(x => x && typeof x === "object" && Array.isArray(x.kw)) : [];
            if (!rec || !rec.gerek.length || !rec.kw.length) return list;
            // aynı gönderen + aynı anahtar kelimeler varsa eskisinin yerine yenisi
            const sig = rec.sender + "|" + rec.kw.slice().sort().join(",");
            list = list.filter(x => (x.sender + "|" + x.kw.slice().sort().join(",")) !== sig);
            list.push(rec);
            while (list.length > MAX) list.shift();
            return list;
        }
        // benzerlik: Jaccard (anahtar kelime) + aynı gönderen bonusu; eşik 0.5
        function score(doc, rec) {
            const a = keywords(doc.subject), b = rec.kw || [];
            if (!a.length || !b.length) return 0;
            const inter = a.filter(w => b.includes(w)).length;
            if (!inter) return 0;
            const jac = inter / (a.length + b.length - inter);
            const same = senderKey(doc.gonderen) && senderKey(doc.gonderen) === rec.sender;
            return Math.min(1, jac + (same ? 0.25 : 0));
        }
        function suggest(doc, list, threshold) {
            const th = typeof threshold === "number" ? threshold : 0.5;
            let best = null;
            (Array.isArray(list) ? list : []).forEach(r => {
                if (!r || !Array.isArray(r.gerek) || !r.gerek.length) return;
                const s = score(doc, r);
                if (s >= th && (!best || s > best.score || (s === best.score && (r.at || 0) > (best.rec.at || 0)))) best = { score: s, rec: r };
            });
            return best ? { gerek: best.rec.gerek.slice(), bilgi: (best.rec.bilgi || []).slice(), score: Math.round(best.score * 100) / 100, konu: best.rec.konu || "", at: best.rec.at || 0 } : null;
        }
        return { KEY, SET_KEY, MAX, fold, keywords, senderKey, makeRecord, addRecord, score, suggest };
    })();
    // ==== HL-END ====
    function hlOn() { const v = extStoreGet(HL.SET_KEY); return !(isPlainObject(v) && v.on === false); }
    function hlList() { const v = extStoreGet(HL.KEY); return Array.isArray(v) ? v : []; }
    function hlRecord(d, gerek, bilgi) { // yalnızca gönderim görüldükten sonra çağrılır; hata olsa da havaleyi etkilemez
        try { if (!hlOn() || !d) return; extStoreSet(HL.KEY, HL.addRecord(hlList(), HL.makeRecord({ subject: d.subject, gonderen: d.gonderen }, gerek, bilgi))); } catch(e) { console.warn("[Evrak Asistanı] Havale öğrenme kaydı yazılamadı:", e); }
    }
    function hlSuggest(d) { // kişi listesinde olmayanlar atılır
        try {
            if (!hlOn() || !d) return null;
            const r = HL.suggest({ subject: d.subject, gonderen: d.gonderen }, hlList());
            if (!r) return null;
            const fix = l => { const p = hqFindPerson(l); return p ? personLabel(p) : null; };
            const g = r.gerek.map(fix).filter(Boolean), b = r.bilgi.map(fix).filter(Boolean);
            return g.length ? Object.assign(r, { gerek: g.slice(0, 1), bilgi: b.filter(x => x !== g[0]) }) : null;
        } catch(e) { return null; }
    }
    const HL_LABEL = "🎓 Geçmişten öneri (geçen sefer böyle havale ettiniz)";
    // ---- öneri
    function computeSuggestion(d) {
        const res = HC.routeDoc({ subject: d.subject, gonderen: d.gonderen, body: havaleBody[d.key] || "" }, getRulesStore(), havalePeople.people || []);
        havaleSuggest[d.key] = res;
        return res;
    }
    function applySuggestion(d, st) {
        try { HC.setPrincipal(getOkulProfil().mudur || ""); } catch(e) {}
        if (!(havalePeople.people || []).length) { computeSuggestion(d); return havaleSuggest[d.key]; } // kişi listesi yokken ön seçim yapılmaz; liste gelince yeniden denenir
        const prev = havaleAutoSel[d.key] || {};
        Object.keys(prev).forEach(l => { if (st[l] === prev[l]) delete st[l]; });
        const res = computeSuggestion(d);
        const auto = {};
        if (res.gerek) auto[res.gerek.label] = "G";
        res.bilgi.forEach(b => { if (!auto[b.label]) auto[b.label] = "B"; });
        if (!res.gerek) { const L = hlSuggest(d); if (L) { auto[L.gerek[0]] = "G"; L.bilgi.forEach(l => { if (!auto[l]) auto[l] = "B"; }); } } // NEW (v3.6.28): kural yoksa geçmişten ön seçim
        Object.keys(auto).forEach(l => { if (!(l in st)) st[l] = auto[l]; });
        havaleAutoSel[d.key] = auto;
        return res;
    }
    function renderSuggestBox(card, d) {
        const box = card && card.querySelector(".havale-suggest");
        if (!box) return;
        const res = computeSuggestion(d);
        const btn = "background:#2D3D63; color:#E2E8F0; border:1px solid #56709A; padding:1px 6px; border-radius:6px; font-size:10px; cursor:pointer;";
        const whyHtml = (why) => { const t = HC.whyText(why); return t ? '<button class="havale-why-btn" style="' + btn + '">Neden?</button><div class="havale-why" style="display:none; color:#CBD5E1; font-size:10px; margin-top:2px;">Eşleşen kelimeler — ' + escapeHtml(t) + "</div>" : ""; };
        let h = "";
        if (res.reason === "norules") h += '<div class="havale-suggest-empty" style="color:#94A3B8;">Henüz havale kuralı yok — ⚙️ Havale Kuralları\'ndan ekleyin ya da görev dağılımı PDF\'i yükleyin.</div>';
        else if (res.gerek) h += '<div class="havale-sug-g">🎯 Gereği önerisi: <b>' + escapeHtml(res.gerek.label) + "</b>" + (res.gerek.role ? " — " + escapeHtml(res.gerek.role) : "") + ' <span style="color:#94A3B8;">(puan ' + res.gerek.score + (res.gerek.byPriority ? ", öncelikle" : "") + ")</span> " + whyHtml(res.gerek.why) + "</div>";
        else {
            h += '<div class="havale-sug-unsure" style="color:#FDE68A;">❓ Emin değilim, lütfen seçin. <span style="color:#94A3B8;">' + escapeHtml(res.reason === "tie" ? "(iki kural eşit puan aldı)" : res.reason === "unresolved" ? "(önerilen kişi listede bulunamadı)" : "(eşik " + res.threshold + " puanın üstünde eşleşme yok)") + "</span></div>";
            res.candidates.forEach(c => {
                h += '<div class="havale-cand" data-label="' + escapeHtml(c.label) + '" style="margin-top:3px;">• ' + escapeHtml(c.display) + (c.role ? " — " + escapeHtml(c.role) : "") + ' <span style="color:#94A3B8;">(puan ' + c.score + ")</span> "
                    + (c.resolved ? '<button class="btn-havale-cand-pick" style="' + btn + '">Gereği seç</button> ' : "") + whyHtml(c.why) + "</div>";
            });
        }
        res.bilgi.forEach(b => { h += '<div class="havale-sug-b" style="margin-top:3px;">ℹ️ Bilgi: <b>' + escapeHtml(b.label) + "</b>" + (b.role ? " — " + escapeHtml(b.role) : "") + (b.global ? ' <span style="color:#94A3B8;">(her evrakta)</span>' : " " + whyHtml(b.why)) + "</div>"; });
        res.warnings.forEach(w => { h += '<div class="havale-sug-warn" style="color:#FCA5A5; margin-top:3px;">⚠️ ' + escapeHtml(w) + "</div>"; });
        if (res.reason !== "norules" && !(havalePeople.people || []).length) h += '<div style="color:#FBBF24; margin-top:3px;">Otomatik ön seçim için kişi listesi gerekli; yine de aşağıdan + ile kişi seçebilirsiniz.</div>';
        const HLs = hlSuggest(d); // NEW (v3.6.28)
        if (HLs && !(res.gerek && res.gerek.label === HLs.gerek[0])) {
            h += '<div class="havale-sug-learn" style="margin-top:4px; border-top:1px dashed #56709A; padding-top:3px; color:#C4B5FD;">' + escapeHtml(HL_LABEL) + (res.gerek ? ' <span style="color:#FDE68A;">— kuraldan farklı, siz seçin</span>' : "") + '<br>🎯 Gereği: <b>' + escapeHtml(HLs.gerek[0]) + "</b>" + (HLs.bilgi.length ? " · ℹ️ Bilgi: " + escapeHtml(HLs.bilgi.join(", ")) : "") + ' <span style="color:#94A3B8;">(benzerlik ' + Math.round(HLs.score * 100) + "%; örnek: " + escapeHtml(HLs.konu.slice(0, 60)) + ')</span> <button class="btn-havale-learn-pick" style="' + btn + '">Bunu seç</button></div>';
        }
        h += '<div class="havale-sug-src" style="color:#94A3B8; font-size:10px; margin-top:3px;">Kaynak: ' + (res.usedBody ? "konu + gönderen + evrak metni" : "liste satırı (konu + gönderen) — daha iyi öneri için 📖 Oku ve öner") + ". Öneriyi değiştirebilirsiniz; gönderimden önce yine onay istenir.</div>";
        box.innerHTML = h;
        box.style.cssText = "display:block; background:#2D3D63; border:1px solid #4B5D7A; border-radius:8px; padding:6px 8px; font-size:10.5px; line-height:1.45; color:#E2E8F0;";
        box.querySelectorAll(".havale-why-btn").forEach(b => { b.onclick = () => { const w = b.nextElementSibling; if (w) w.style.display = w.style.display === "none" ? "block" : "none"; }; });
        const lp = box.querySelector(".btn-havale-learn-pick");
        if (lp && HLs) lp.onclick = () => {
            const st = havalePick[d.key] || (havalePick[d.key] = {});
            Object.keys(st).forEach(l => { if (st[l] === "G") delete st[l]; });
            st[HLs.gerek[0]] = "G";
            HLs.bilgi.forEach(l => { if (!(l in st)) st[l] = "B"; });
            renderPicker(card);
        };
        box.querySelectorAll(".btn-havale-cand-pick").forEach(b => {
            b.onclick = () => {
                const label = b.closest(".havale-cand").getAttribute("data-label");
                const st = havalePick[d.key] || (havalePick[d.key] = {});
                Object.keys(st).forEach(l => { if (st[l] === "G") delete st[l]; });
                st[label] = "G";
                renderPicker(card);
            };
        });
    }
    async function havaleReadForSuggest(d, card) {
        if (!havaleGuard()) return;
        havaleBusy = true;
        try {
            setHavaleStatus(d, "⏳ Evrak açılıp okunuyor (öneri için)…", "info");
            let v;
            if (isHavaleFormOpen()) {
                const tr = isOnTeslim() ? findTeslimRow(d) : null;
                if (!tr || !isTeslimRowSelected(tr)) { setHavaleStatus(d, "⚠️ EBYS'de başka bir evrak için açık bir havale formu var; önce EBYS'de 'Vazgeç'e basın.", "warn"); return; }
                v = await havaleVerifyPreview(d);
            } else {
                const o = await havaleOpenDoc(d);
                v = o.ok ? await havaleVerifyPreview(d) : o;
            }
            if (!v.ok) { setHavaleStatus(d, "⚠️ " + v.msg + " Öneri yalnızca liste satırına göre kaldı.", "warn"); return; }
            const att = readRealAttachments();
            havaleBody[d.key] = [v.text || "", att.items.map(a => [a.name].concat(a.points || []).join(" ")).join("\n")].join("\n");
            const st = havalePick[d.key] || (havalePick[d.key] = {});
            applySuggestion(d, st);
            setHavaleStatus(d, "📖 Evrak metni okundu (" + v.how + "); öneri güncellendi.", "info");
        } finally {
            havaleBusy = false;
            const c = document.querySelector('.ebys-havale-card[data-key="' + CSS.escape(d.key) + '"]') || card;
            if (c) { const p = c.querySelector(".havale-picker"); if (p) { p.style.display = "flex"; renderPicker(c); } }
        }
    }
    // ---- düzeltmeden öğrenme (yalnızca kullanıcı tıklarsa kurala eklenir)
    function havaleLearnCheck(d, sels) {
        const g = sels.find(s => s.v === "G");
        if (!g) return;
        const label = personLabel(g);
        const sug = havaleSuggest[d.key];
        if (sug && sug.gerek && sug.gerek.label === label) return;
        havaleLearn[d.key] = { name: g.name, title: g.title || "", label: label, subject: d.subject };
    }
    function proposeKeywords(subject) {
        const ph = HC.uniqFold(HC.dutyPhrases(subject)).filter(p => p.length >= 4);
        return ph.slice(0, 3);
    }
    function renderLearnOffer(card, d) {
        const el = card.querySelector(".havale-learn");
        const L = havaleLearn[d.key];
        if (!el) return;
        if (!L) { el.style.display = "none"; el.innerHTML = ""; return; }
        el.style.cssText = "display:flex; flex-direction:column; gap:4px; background:#1F2D4D; border:1px dashed #A78BFA; border-radius:8px; padding:6px; font-size:10.5px;";
        el.innerHTML = '<div>🧠 Gereği olarak <b>' + escapeHtml(L.label) + "</b> seçtiniz (öneri farklıydı). Benzer evraklar için kurala eklensin mi?</div>"
            + '<button class="btn-havale-learn" style="background:#6D28D9; color:white; border:none; padding:4px 8px; border-radius:6px; font-size:10.5px; cursor:pointer; align-self:flex-start;">➕ Bu konuyu kurala ekle</button>';
        el.querySelector(".btn-havale-learn").onclick = () => {
            el.innerHTML = '<div>Eklenecek anahtar kelimeler (virgülle; düzenleyebilirsiniz):</div><input class="havale-learn-input" type="text" style="background:#2D3D63; color:#E2E8F0; border:1px solid #56709A; border-radius:6px; padding:4px 6px; font-size:11px;">'
                + '<div style="display:flex; gap:6px;"><button class="btn-havale-learn-save" style="background:#15803D; color:white; border:none; padding:4px 8px; border-radius:6px; font-size:10.5px; cursor:pointer;">Kurala ekle</button><button class="btn-havale-learn-cancel" style="background:#2D3D63; color:#E2E8F0; border:1px solid #56709A; padding:4px 8px; border-radius:6px; font-size:10.5px; cursor:pointer;">Vazgeç</button></div>';
            el.querySelector(".havale-learn-input").value = proposeKeywords(L.subject).join(", ");
            el.querySelector(".btn-havale-learn-cancel").onclick = () => { delete havaleLearn[d.key]; renderLearnOffer(card, d); };
            el.querySelector(".btn-havale-learn-save").onclick = () => {
                const kws = HC.splitList(el.querySelector(".havale-learn-input").value);
                if (!kws.length) { showToast("⚠️ En az bir anahtar kelime yazın.", "warn"); return; }
                const st = getRulesStore();
                const people = havalePeople.people || [];
                let r = st.rules.find(x => x.type === "G" && HC.resolveTarget(x.target, people).label === L.label);
                if (r) r.keywords = HC.uniqFold(r.keywords.concat(kws));
                else { r = { id: HC.newId(), enabled: true, role: L.title, target: { name: L.name, titles: L.title ? [L.title] : [] }, type: "G", keywords: kws, negative: [], priority: 0, source: "öğrenme" }; st.rules.push(r); }
                saveRulesStore(st);
                delete havaleLearn[d.key];
                el.style.cssText = "display:block; color:#A7F3D0; font-size:10.5px;";
                el.textContent = "✔️ Kurala eklendi: " + kws.join(", ");
                showToast("✔️ Kurala eklendi.", "ok");
            };
        };
    }
    // ---- Havale Kuralları penceresi
    let ruleEditId = null; // null: kapalı, "": yeni
    let rulesModalShown = "";
    let rulesUndo = [], tplFilter = ""; const tplOpen = new Set(); // v3.6.35: tek tık ekle/çıkar (onay penceresi yok) + geri al + arama
    function openRulesModal() {
        ensureSkin35(); document.querySelectorAll("#ebys-havale-rules-modal").forEach(el => el.remove());
        const m = document.createElement("div");
        m.id = "ebys-havale-rules-modal";
        m.setAttribute("role", "dialog");
        m.style.cssText = "position:fixed !important; inset:0 !important; background:rgba(0,0,0,0.5) !important; z-index:2147483647 !important; display:flex !important; align-items:center; justify-content:center; font-family:'Segoe UI', Tahoma, sans-serif;";
        m.innerHTML = '<div class="rules-box" style="width:min(720px, 95vw); max-height:92vh; overflow-y:auto; background:#1F2D4D; color:#E2E8F0; border:1.5px solid #00F0FF; border-radius:16px; padding:16px; font-size:12px; line-height:1.45;"></div>';
        document.body.appendChild(m);
        ruleEditId = null;
        renderRulesModal();
    }
    function renderRulesModal() {
        const m = document.getElementById("ebys-havale-rules-modal");
        if (!m) return;
        const box = m.querySelector(".rules-box");
        const st = getRulesStore();
        rulesModalShown = JSON.stringify(st);
        const people = havalePeople.people || [];
        const inp = "background:#2D3D63; color:#E2E8F0; border:1px solid #56709A; border-radius:6px; padding:4px 6px; font-size:11.5px; box-sizing:border-box;";
        const btn = "background:#2D3D63; color:#E2E8F0; border:1px solid #56709A; padding:3px 8px; border-radius:6px; font-size:11px; cursor:pointer;";
        const resTxt = (t) => { const r = HC.resolveTarget(t, people); return !people.length ? "" : r.status === "ok" ? ' <span style="color:#86EFAC;">✔ ' + escapeHtml(r.label) + "</span>" : ' <span style="color:#FCA5A5;">⚠ ' + (r.status === "ambiguous" ? "birden fazla kişi" : "listede yok") + "</span>"; };
        const personOpts = '<option value="">— elle yaz / ünvanla eşle —</option>' + people.map((p, i) => '<option value="' + i + '">' + escapeHtml(personLabel(p)) + "</option>").join("");
        let formFill = null;
        let h = '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;"><b style="color:#00F0FF; font-size:15px;">⚙️ Havale Kuralları</b><span style="display:flex; gap:6px;">' + (rulesUndo.length ? '<button id="btn-rules-undo" title="Son değişikliği geri al" style="' + btn + '">↶ Geri al</button>' : '') + '<button id="btn-rules-close" style="' + btn + '">✕</button></span></div>'
            + '<div style="color:#A9B6CA; font-size:11px; margin-bottom:8px;">Kurallar yalnızca bu bilgisayarda saklanır. Kural: kişi (ad ve/veya ünvan) + anahtar kelimeler. Konu eşleşmesi 3, gönderen ve evrak metni eşleşmesi 1 puan; en yüksek puanlı kural eşiği geçerse o kişi Gereği olarak önerilir. Eşitlikte öneri yapılmaz.</div>'
            + '<div style="display:flex; gap:6px; flex-wrap:wrap; margin-bottom:10px;"><button id="btn-rules-setup" style="' + btn + ' background:#2563EB; border-color:#2563EB;">📄 Görev Dağılımı Yükle (PDF)</button><button id="btn-rules-export" style="' + btn + '">📤 Dışa aktar (JSON)</button><label style="' + btn + ' display:inline-flex; align-items:center; color:#E2E8F0 !important;">📥 İçe aktar<input type="file" id="rules-import-input" accept=".json,application/json" style="display:none;"></label></div>';
        h += '<div style="font-weight:bold; color:#BFDBFE; margin-top:4px;">Her evrakta Bilgi</div><div id="rules-global-list" style="display:flex; flex-direction:column; gap:3px; margin:4px 0;">';
        if (!st.globalBilgi.length) h += '<div style="color:#94A3B8;">(yok)</div>';
        st.globalBilgi.forEach(g => { h += '<div class="rule-global-row" data-id="' + escapeHtml(g.id) + '" style="display:flex; gap:6px; align-items:center;"><input type="checkbox" class="rule-global-enabled"' + (g.enabled ? " checked" : "") + '><span style="flex:1;">' + escapeHtml(g.role || "-") + " — " + escapeHtml(HC.targetText(g.target)) + resTxt(g.target) + '</span><button class="rule-global-del ico ico-del" title="Kaldır (Geri al ile geri getirilebilir)" style="' + btn + '">−</button></div>'; });
        h += '</div><div style="display:flex; gap:4px; flex-wrap:wrap; align-items:center;"><select id="global-person" style="' + inp + ' max-width:220px;">' + personOpts + '</select><input id="global-titles" placeholder="ya da ünvan (ör. Okul Müdürü, Müdür)" style="' + inp + ' flex:1; min-width:160px;"><input id="global-role" placeholder="etiket (ör. Okul Müdürü)" style="' + inp + ' width:140px;"><button id="btn-global-add" style="' + btn + '">+ Ekle</button></div>';
        h += '<div style="font-weight:bold; color:#BFDBFE; margin-top:12px;">Gereği / Bilgi kuralları</div><div id="rules-list" style="display:flex; flex-direction:column; gap:3px; margin:4px 0;">';
        if (!st.rules.length) h += '<div style="color:#94A3B8;">(henüz kural yok)</div>';
        st.rules.forEach(r => {
            h += '<div class="rule-row" data-id="' + escapeHtml(r.id) + '" style="display:flex; gap:6px; align-items:center; background:#2D3D63; border-radius:6px; padding:3px 6px;"><input type="checkbox" class="rule-enabled"' + (r.enabled ? " checked" : "") + '><span style="flex:1; min-width:0;"><b>' + escapeHtml(r.role || "-") + "</b> — " + escapeHtml(HC.targetText(r.target)) + resTxt(r.target) + ' · <span style="color:' + (r.type === "G" ? "#FCA5A5" : "#93C5FD") + ';">' + (r.type === "G" ? "Gereği" : "Bilgi") + '</span> · <span class="rule-kwcount">' + r.keywords.length + " anahtar</span>" + (r.negative.length ? " · " + r.negative.length + " hariç" : "") + (r.priority ? " · öncelik " + r.priority : "") + (r.source ? ' <span style="color:#94A3B8;">(' + escapeHtml(r.source) + ")</span>" : "") + '</span><button class="rule-edit" style="' + btn + '">Düzenle</button><button class="rule-del ico ico-del" title="Kuralı sil (Geri al ile geri getirilebilir)" style="' + btn + '">−</button></div>';
        });
        h += '</div><button id="btn-rule-new" style="' + btn + '">+ Yeni kural</button>';
        if (ruleEditId !== null) {
            const r = st.rules.find(x => x.id === ruleEditId) || { id: "", role: "", target: { name: "", titles: [] }, type: "G", keywords: [], negative: [], priority: 0 };
            const selIdx = people.findIndex(p => r.target.name && normName(p.name) === normName(r.target.name) && (!r.target.titles.length || r.target.titles.some(t => normName(t) === normName(p.title))));
            h += '<div id="ebys-rule-form" style="margin-top:10px; background:#2D3D63; border:1px solid #00F0FF; border-radius:10px; padding:8px; display:flex; flex-direction:column; gap:5px;">'
                + "<b>" + (r.id ? "Kuralı düzenle" : "Yeni kural") + "</b>"
                + '<div style="display:flex; gap:4px; flex-wrap:wrap;"><select id="rule-person" style="' + inp + ' max-width:260px;">' + personOpts.replace('value="' + selIdx + '"', 'value="' + selIdx + '" selected') + '</select><input id="rule-name" placeholder="Ad Soyad (ünvanla eşleşme için boş bırakın)" style="' + inp + ' flex:1; min-width:150px;"><input id="rule-titles" placeholder="Ünvan(lar), virgülle" style="' + inp + ' width:180px;"></div>'
                + '<div style="display:flex; gap:4px; flex-wrap:wrap;"><input id="rule-role" placeholder="Görev etiketi (ör. Sosyal etkinlikler)" style="' + inp + ' flex:1;"><select id="rule-type" style="' + inp + '"><option value="G">Gereği</option><option value="B">Bilgi</option></select><label style="display:flex; align-items:center; gap:3px; color:#E2E8F0 !important;">Öncelik <input id="rule-priority" type="number" min="-99" max="99" style="' + inp + ' width:60px;"></label></div>'
                + '<textarea id="rule-keywords" rows="3" placeholder="Anahtar kelimeler (virgülle): kulüp, tübitak, sosyal etkinlik" style="' + inp + ' width:100%;"></textarea>'
                + '<textarea id="rule-negative" rows="1" placeholder="Hariç kelimeler (isteğe bağlı, virgülle)" style="' + inp + ' width:100%;"></textarea>'
                + '<div style="display:flex; gap:4px; flex-wrap:wrap;"><span style="color:#A9B6CA;">Hazır setler:</span>' + HC.KEYWORD_SETS.map(s => '<button class="rule-set-btn" data-set="' + s.id + '" title="' + escapeHtml(s.keywords.join(", ")) + '" style="' + btn + ' font-size:10px;">+ ' + escapeHtml(s.label) + "</button>").join("") + "</div>"
                + '<div style="display:flex; gap:6px;"><button id="btn-rule-save" style="' + btn + ' background:#15803D; border-color:#15803D;">Kaydet</button><button id="btn-rule-cancel" style="' + btn + '">Vazgeç</button></div></div>';
            formFill = () => {
                const q = id => document.getElementById(id);
                if (!q("rule-name")) return;
                q("rule-name").value = r.target.name; q("rule-titles").value = r.target.titles.join(", "); q("rule-role").value = r.role; q("rule-type").value = r.type;
                q("rule-priority").value = String(r.priority || 0); q("rule-keywords").value = r.keywords.join(", "); q("rule-negative").value = r.negative.join(", ");
            };
        }
        h += '<div style="font-weight:bold; color:#BFDBFE; margin-top:12px;">Ayarlar ve deneme</div><div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;"><label>Eşik (puan) <input id="rules-threshold" type="number" min="1" max="50" value="' + st.options.threshold + '" style="' + inp + ' width:60px;"></label><label><input id="rules-fold" type="checkbox"' + (st.options.foldDiacritics ? " checked" : "") + '> Türkçe karakterlere duyarsız (ş=s, ı=i …)</label></div>'
            + '<div style="display:flex; gap:4px; margin-top:4px;"><input id="rules-test-input" placeholder="Denemek için bir evrak konusu yazın…" style="' + inp + ' flex:1;"></div><div id="rules-test-out" style="color:#CBD5E1; font-size:11px; margin-top:3px;"></div>';
        h += renderTemplateSection(st, people, inp, btn, resTxt);
        const keepTest = (document.getElementById("rules-test-input") || {}).value || "";
        const keepScroll = box.scrollTop, fAct = document.activeElement && document.activeElement.id === "tpl-filter";
        box.innerHTML = h;
        box.scrollTop = keepScroll; if (fAct) { const f = document.getElementById("tpl-filter"); if (f) { f.focus(); f.setSelectionRange(f.value.length, f.value.length); } }
        if (formFill) formFill();
        bindRulesModal(st, people, keepTest);
    }
    function bindRulesModal(st, people, keepTest) {
        const q = id => document.getElementById(id);
        const m = q("ebys-havale-rules-modal");
        q("btn-rules-close").onclick = () => m.remove();
        q("btn-rules-setup").onclick = openSetupPage;
        q("btn-rules-export").onclick = () => {
            const data = "data:application/json;charset=utf-8," + encodeURIComponent(JSON.stringify(HC.rulesToFile(getRulesStore()), null, 2));
            const a = document.createElement("a"); a.href = data; a.download = "evrak_asistani_havale_kurallari_" + Date.now() + ".json"; document.body.appendChild(a); a.click(); a.remove();
        };
        q("rules-import-input").onchange = (ev) => {
            const f = ev.target.files && ev.target.files[0];
            if (!f) return;
            const fr = new FileReader();
            fr.onload = () => {
                ev.target.value = "";
                let v = null; try { v = JSON.parse(fr.result); } catch(e) {}
                if (!HC.isRulesFile(v)) { alert("❌ Geçersiz kural dosyası."); return; }
                const inc = HC.sanitizeRules(v);
                const cur = getRulesStore();
                if (rulesCount(cur) && !confirm("İçe aktarılan " + inc.rules.length + " kural ve " + inc.globalBilgi.length + " 'her evrakta Bilgi' kaydı mevcut kurallarınızın YERİNE geçecek. Devam edilsin mi?")) return;
                saveRulesStore(inc);
                alert("✅ " + inc.rules.length + " kural ve " + inc.globalBilgi.length + " 'her evrakta Bilgi' kaydı içe aktarıldı.");
                renderRulesModal();
            };
            fr.readAsText(f, "UTF-8");
        };
        const save = (fn) => { const s = getRulesStore(); rulesUndo.push(JSON.stringify(s)); if (rulesUndo.length > 30) rulesUndo.shift(); fn(s); saveRulesStore(s); renderRulesModal(); };
        if (q("btn-rules-undo")) q("btn-rules-undo").onclick = () => { const prev = rulesUndo.pop(); if (prev) { try { saveRulesStore(JSON.parse(prev)); } catch(e) {} showToast("↶ Son değişiklik geri alındı.", "ok"); renderRulesModal(); } };
        m.querySelectorAll(".rule-global-row").forEach(row => {
            const id = row.getAttribute("data-id");
            row.querySelector(".rule-global-enabled").onchange = (e) => save(s => { const g = s.globalBilgi.find(x => x.id === id); if (g) g.enabled = e.target.checked; });
            row.querySelector(".rule-global-del").onclick = () => save(s => { s.globalBilgi = s.globalBilgi.filter(x => x.id !== id); });
        });
        q("btn-global-add").onclick = () => {
            const idx = q("global-person").value;
            const titles = HC.splitList(q("global-titles").value);
            let target = null;
            if (idx !== "") { const p = people[+idx]; target = { name: p.name, titles: p.title ? [p.title] : [] }; }
            else if (titles.length) target = { name: "", titles: titles };
            if (!target) { showToast("⚠️ Kişi seçin ya da ünvan yazın.", "warn"); return; }
            save(s => { s.globalBilgi.push({ id: HC.newId(), enabled: true, role: q("global-role").value.trim() || (target.titles[0] || target.name), target: target }); });
        };
        m.querySelectorAll(".rule-row").forEach(row => {
            const id = row.getAttribute("data-id");
            row.querySelector(".rule-enabled").onchange = (e) => save(s => { const r = s.rules.find(x => x.id === id); if (r) r.enabled = e.target.checked; });
            row.querySelector(".rule-edit").onclick = () => { ruleEditId = id; renderRulesModal(); };
            row.querySelector(".rule-del").onclick = () => { if (ruleEditId === id) ruleEditId = null; save(s => { s.rules = s.rules.filter(x => x.id !== id); }); };
        });
        q("btn-rule-new").onclick = () => { ruleEditId = ""; renderRulesModal(); };
        if (q("ebys-rule-form")) {
            // Hazır setler = aç/kapa düğmeleri: seçilince setin kelimeleri eklenir (✓), yeniden tıklanınca YALNIZCA o setin kelimeleri çıkarılır
            // (elle yazılan ya da seçili başka bir sette de bulunan kelimeler kalır). Açılışta kelimeleri tam olarak bulunan setler seçili görünür.
            const kf = k => HC.fold(k).replace(/\s+/g, " ").trim();
            const setById = id => HC.KEYWORD_SETS.find(s => s.id === id);
            const setKeys = s => s.keywords.map(kf);
            const curKeys = () => new Set(HC.splitList(q("rule-keywords").value).map(kf));
            const selSets = new Set();
            const ownedKeys = () => { const o = new Set(); selSets.forEach(id => setKeys(setById(id)).forEach(k => o.add(k))); return o; };
            const initKeys = curKeys();
            HC.KEYWORD_SETS.forEach(s => { if (s.keywords.length && setKeys(s).every(k => initKeys.has(k))) selSets.add(s.id); });
            let manualKw = (() => { const o = ownedKeys(); return new Set([...initKeys].filter(k => !o.has(k))); })();
            const otherRules = st.rules.filter(r => r.id !== ruleEditId && r.enabled !== false);
            const refreshChips = () => {
                const myName = normName(q("rule-name").value.trim());
                m.querySelectorAll(".rule-set-btn").forEach(b => {
                    const s = setById(b.getAttribute("data-set"));
                    if (!s) return;
                    const on = selSets.has(s.id), ks = setKeys(s);
                    const who = Array.from(new Set(otherRules.filter(r => !(myName && r.target.name && normName(r.target.name) === myName)).filter(r => { const rk = new Set(r.keywords.map(kf)); return ks.every(k => rk.has(k)); }).map(r => HC.targetText(r.target))));
                    b.classList.toggle("hit", on);
                    b.setAttribute("data-sel", on ? "1" : "0");
                    b.innerHTML = (on ? "✓ " : "+ ") + escapeHtml(s.label) + (on && who.length ? ' <span class="rule-set-warn" style="color:#FCD34D; font-size:9.5px;">⚠ başka kişide de seçili: ' + escapeHtml(who.join(", ")) + "</span>" : "");
                    b.style.background = on ? "#14532D" : "#2D3D63"; b.style.borderColor = on ? "#22C55E" : "#56709A"; b.style.color = on ? "#A7F3D0" : "#E2E8F0";
                    b.title = s.keywords.join(", ") + (who.length ? "\n⚠ başka kişide de seçili: " + who.join(", ") : "");
                });
            };
            const syncFromText = () => {
                const ck = curKeys();
                selSets.forEach(id => { const ks = setKeys(setById(id)); if (!ks.every(k => ck.has(k))) { selSets.delete(id); ks.forEach(k => { if (ck.has(k)) manualKw.add(k); }); } });
                const o = ownedKeys();
                manualKw = new Set([...ck].filter(k => manualKw.has(k) || !o.has(k)));
                refreshChips();
            };
            q("rule-person").onchange = () => { const v = q("rule-person").value; if (v === "") return; const p = people[+v]; q("rule-name").value = p.name; q("rule-titles").value = p.title || ""; if (!q("rule-role").value) q("rule-role").value = p.title || ""; refreshChips(); };
            q("rule-name").oninput = refreshChips;
            q("rule-keywords").oninput = syncFromText;
            m.querySelectorAll(".rule-set-btn").forEach(b => { b.onclick = () => {
                const set = setById(b.getAttribute("data-set"));
                if (!set) return;
                const cur = HC.splitList(q("rule-keywords").value);
                if (selSets.has(set.id)) {
                    selSets.delete(set.id);
                    const keep = ownedKeys(), ks = new Set(setKeys(set));
                    q("rule-keywords").value = cur.filter(k => { const f = kf(k); return !ks.has(f) || manualKw.has(f) || keep.has(f); }).join(", ");
                    if (q("rule-role").value.trim() === set.label) { const nx = Array.from(selSets).map(setById)[0]; q("rule-role").value = nx ? nx.label : ""; }
                } else {
                    selSets.add(set.id);
                    q("rule-keywords").value = HC.uniqFold(cur.concat(set.keywords)).join(", ");
                    if (!q("rule-role").value) q("rule-role").value = set.label;
                }
                refreshChips();
            }; });
            refreshChips();
            q("btn-rule-cancel").onclick = () => { ruleEditId = null; renderRulesModal(); };
            q("btn-rule-save").onclick = () => {
                const target = { name: q("rule-name").value.trim(), titles: HC.splitList(q("rule-titles").value) };
                if (!target.name && !target.titles.length) { showToast("⚠️ Kişi seçin, ad yazın ya da ünvan yazın.", "warn"); return; }
                const kws = HC.splitList(q("rule-keywords").value);
                if (!kws.length) { showToast("⚠️ En az bir anahtar kelime yazın.", "warn"); return; }
                const data = { role: q("rule-role").value.trim(), target: target, type: q("rule-type").value === "B" ? "B" : "G", keywords: kws, negative: HC.splitList(q("rule-negative").value), priority: +q("rule-priority").value || 0 };
                const editing = ruleEditId;
                ruleEditId = null;
                save(s => { const r = s.rules.find(x => x.id === editing); if (r) Object.assign(r, data); else s.rules.push(Object.assign({ id: HC.newId(), enabled: true, source: "elle" }, data)); });
            };
        }
        q("rules-threshold").onchange = (e) => save(s => { s.options.threshold = +e.target.value || 3; });
        q("rules-fold").onchange = (e) => save(s => { s.options.foldDiacritics = e.target.checked; });
        const ti = q("rules-test-input"), to = q("rules-test-out");
        const runTest = () => {
            const t = ti.value.trim();
            if (!t) { to.textContent = ""; return; }
            const r = HC.routeDoc({ subject: t, gonderen: "", body: "" }, getRulesStore(), people);
            to.textContent = r.gerek ? "🎯 Gereği: " + r.gerek.label + " (puan " + r.gerek.score + ") — " + HC.whyText(r.gerek.why) : "❓ Emin değilim" + (r.candidates.length ? ": " + r.candidates.map(c => c.display + " (" + c.score + ")").join(" / ") : " (eşleşme yok)");
            if (r.bilgi.length) to.textContent += " · Bilgi: " + r.bilgi.map(b => b.label).join(", ");
        };
        ti.oninput = runTest;
        if (keepTest) { ti.value = keepTest; runTest(); }
        bindTemplateSection(people, save);
    }
    // ---- v3.6.29: 🧩 Madde şablonu — kişi başına her maddeyi Gereği / Bilgi / yok olarak +/- ile ayarla; kurallara otomatik dönüşür
    function renderTemplateSection(st, people, inp, btn, resTxt) {
        const t = st.template || HC.templateFromRules(st.rules);
        const removed = new Set(t.removed || []);
        const items = t.items.filter(i => !removed.has(i.id));
        const byId = {}; t.items.forEach(i => { byId[i.id] = i; });
        const sbtn = btn + " padding:1px 6px; font-size:10.5px;";
        let h = '<div id="tpl-section" style="margin-top:14px; border-top:1px solid #56709A; padding-top:8px;"><b style="color:#00F0FF;">🧩 Madde şablonu (kişi × madde)</b>'
            + '<div style="color:#A9B6CA; font-size:11px; margin:3px 0 6px;">Her madde ayrı bir konudur (ör. Kantin ile Taşıma ayrı). Kişiyi ekleyin, sonra her madde için <b style="color:#FCA5A5;">+ Gereği</b> ya da <b style="color:#93C5FD;">+ Bilgi</b> seçin; ✕ ile çıkarın. Şablon kurallara kendiliğinden dönüşür (kaynak: şablon).'
            + (t.enabled ? "" : ' <span style="color:#FDE68A;">Şablon henüz kapalı: mevcut kurallarınız aynen çalışıyor. İlk değişiklikte devreye girer; şablona aktarılan eski kurallar silinmez, yalnızca kapatılır (listeden yeniden açılabilir).</span>') + "</div>";
        h += '<div style="display:flex; gap:6px; align-items:center; margin:2px 0 6px;"><input id="tpl-filter" placeholder="🔎 Madde / kişi ara (ör. kantin, taşıma)…" style="' + inp + ' flex:1; padding:5px 8px;"><span id="tpl-filter-n" style="color:#A9B6CA; font-size:11px;"></span></div>';
        h += '<div style="display:flex; flex-direction:column; gap:5px;">';
        if (!t.people.length) h += '<div style="color:#94A3B8;">(şablonda kişi yok — aşağıdan ekleyin)</div>';
        t.people.forEach(p => {
            const asg = Object.keys(p.assign).filter(k => byId[k] && !removed.has(k));
            const free = items.filter(i => !p.assign[i.id]);
            h += '<div class="tpl-person" data-p="' + escapeHtml(p.id) + '" style="background:#2D3D63; border-radius:8px; padding:5px 7px;">'
                + '<div style="display:flex; gap:6px; align-items:center;"><b style="flex:1;">👤 ' + escapeHtml(HC.targetText({ name: p.name, titles: p.titles })) + "</b>" + resTxt({ name: p.name, titles: p.titles })
                + '<button class="tpl-person-del" title="Kişiyi şablondan çıkar" style="' + sbtn + '">− Kişi</button></div>'
                + '<div style="display:flex; flex-wrap:wrap; gap:3px; margin:4px 0;">'
                + (asg.length ? asg.map(k => '<span class="tpl-chip" data-i="' + escapeHtml(k) + '" style="display:inline-flex; align-items:center; gap:3px; border-radius:10px; padding:1px 6px; font-size:10.5px; background:' + (p.assign[k] === "G" ? "#7F1D1D" : "#1E3A8A") + ';">'
                    + escapeHtml(byId[k].label) + ' <button class="tpl-chip-tog" title="Gereği ↔ Bilgi" style="' + sbtn + '">' + (p.assign[k] === "G" ? "Gereği" : "Bilgi") + '</button><button class="tpl-chip-del ico ico-del" title="Bu maddeyi kişiden çıkar" style="' + sbtn + '">−</button></span>').join("") : '<span style="color:#94A3B8; font-size:10.5px;">(madde yok)</span>')
                + '</div><div style="display:flex; gap:4px; align-items:center;"><select class="tpl-add-item" style="' + inp + ' flex:1; max-width:280px;"><option value="">— madde seç —</option>' + free.map(i => '<option value="' + escapeHtml(i.id) + '">' + escapeHtml(i.label) + "</option>").join("") + "</select>"
                + '<button class="tpl-add-g" style="' + sbtn + ' color:#FCA5A5;">+ Gereği</button><button class="tpl-add-b" style="' + sbtn + ' color:#93C5FD;">+ Bilgi</button></div>'
                + (free.length ? '<details class="tpl-free-wrap"' + (tplOpen.has(p.id) || tplFilter ? " open" : "") + ' style="margin-top:4px;"><summary style="cursor:pointer; color:#BFDBFE; font-size:11.5px;">Tek tıkla ekle (' + free.length + ' madde): <span style="color:#86EFAC;">+</span> Gereği · <span style="color:#93C5FD;">+</span> Bilgi</summary><div style="display:flex; flex-wrap:wrap; gap:4px; margin-top:4px;">'
                    + free.map(i => '<span class="tpl-free" data-i="' + escapeHtml(i.id) + '" data-q="' + escapeHtml(HC.fold(i.label + " " + i.keywords.join(" "))) + '" title="' + escapeHtml(i.keywords.join(", ")) + '">' + escapeHtml(i.label) + '<button class="ico ico-add tpl-free-g" title="Gereği olarak ekle">+</button><button class="ico ico-add-b tpl-free-b" title="Bilgi olarak ekle">+</button></span>').join("") + '</div></details>' : '')
                + '</div>';
        });
        h += "</div>";
        const personOpts = '<option value="">— kişi listesinden seç / elle yaz —</option>' + people.map((p, i) => '<option value="' + i + '">' + escapeHtml(personLabel(p)) + "</option>").join("");
        h += '<div style="display:flex; gap:4px; flex-wrap:wrap; align-items:center; margin-top:5px;"><select id="tpl-person-sel" style="' + inp + ' max-width:220px;">' + personOpts + '</select><input id="tpl-person-name" placeholder="Ad Soyad" style="' + inp + ' flex:1; min-width:120px;"><input id="tpl-person-titles" placeholder="Ünvan (ör. Müdür Yardımcısı)" style="' + inp + ' width:170px;"><button id="btn-tpl-person-add" style="' + btn + '">+ Kişi</button></div>';
        h += '<div style="font-weight:bold; color:#BFDBFE; margin-top:10px;">Maddeler (' + items.length + ')</div><div id="tpl-items" style="display:flex; flex-wrap:wrap; gap:3px; margin:4px 0;">'
            + items.map(i => '<span class="tpl-item" data-i="' + escapeHtml(i.id) + '" title="' + escapeHtml(i.keywords.join(", ")) + '" style="display:inline-flex; align-items:center; gap:3px; background:#2D3D63; border:1px solid ' + (i.custom ? "#F59E0B" : "#56709A") + '; border-radius:10px; padding:1px 6px; font-size:10.5px;">' + escapeHtml(i.label)
                + ' <button class="tpl-item-edit" title="Adı / anahtar kelimeleri düzenle" style="' + sbtn + '">✎</button><button class="tpl-item-del" title="Maddeyi kaldır" style="' + sbtn + '">−</button></span>').join("") + "</div>";
        const rem = t.items.filter(i => removed.has(i.id));
        if (rem.length) h += '<div style="display:flex; flex-wrap:wrap; gap:3px; align-items:center;"><span style="color:#A9B6CA; font-size:10.5px;">Kaldırılanlar:</span>' + rem.map(i => '<button class="tpl-item-restore" data-i="' + escapeHtml(i.id) + '" style="' + sbtn + '">+ ' + escapeHtml(i.label) + "</button>").join("") + "</div>";
        h += '<div style="display:flex; gap:4px; flex-wrap:wrap; margin-top:5px;"><input id="tpl-item-label" placeholder="Özel madde adı (ör. Okul Kooperatifi)" style="' + inp + ' width:200px;"><input id="tpl-item-kw" placeholder="Anahtar kelimeler, virgülle" style="' + inp + ' flex:1; min-width:160px;"><button id="btn-tpl-item-add" style="' + btn + '">+ Madde ekle</button></div></div>';
        return h;
    }
    function bindTemplateSection(people, save) {
        const q = id => document.getElementById(id);
        const sec = q("tpl-section");
        if (!sec) return;
        const tsave = fn => save(s => { if (!s.template) s.template = HC.templateFromRules(s.rules); fn(s.template); HC.applyTemplate(s); });
        const findP = (t, id) => t.people.find(x => x.id === id);
        const fi = q("tpl-filter");
        const applyFilter = () => { // v3.6.35: hızlı arama (yeniden çizim yok)
            const f = HC.fold(fi.value || "").trim(); tplFilter = fi.value || ""; let n = 0;
            sec.querySelectorAll(".tpl-free").forEach(x => { const on = !f || (x.getAttribute("data-q") || "").includes(f); x.style.display = on ? "" : "none"; if (on && f) n++; });
            sec.querySelectorAll(".tpl-item").forEach(x => { const on = !f || HC.fold(x.textContent + " " + (x.title || "")).includes(f); x.style.display = on ? "" : "none"; });
            sec.querySelectorAll(".tpl-free-wrap").forEach(d => { if (f) d.open = true; else d.open = tplOpen.has(d.closest(".tpl-person").getAttribute("data-p")); });
            const nEl = q("tpl-filter-n"); if (nEl) nEl.textContent = f ? n + " eşleşme" : "";
        };
        if (fi) { fi.value = tplFilter; fi.oninput = applyFilter; applyFilter(); }
        sec.querySelectorAll(".tpl-person").forEach(row => {
            const pid = row.getAttribute("data-p");
            row.querySelector(".tpl-person-del").onclick = () => tsave(t => { t.people = t.people.filter(x => x.id !== pid); });
            row.querySelectorAll(".tpl-free").forEach(fr => { const iid = fr.getAttribute("data-i"); const addT = ty => tsave(t => { const p = findP(t, pid); if (p) p.assign[iid] = ty; });
                fr.querySelector(".tpl-free-g").onclick = () => addT("G"); fr.querySelector(".tpl-free-b").onclick = () => addT("B"); });
            const det = row.querySelector(".tpl-free-wrap"); if (det) det.ontoggle = () => { if (tplFilter) return; if (det.open) tplOpen.add(pid); else tplOpen.delete(pid); };
            row.querySelectorAll(".tpl-chip").forEach(ch => {
                const iid = ch.getAttribute("data-i");
                ch.querySelector(".tpl-chip-tog").onclick = () => tsave(t => { const p = findP(t, pid); if (p) p.assign[iid] = p.assign[iid] === "G" ? "B" : "G"; });
                ch.querySelector(".tpl-chip-del").onclick = () => tsave(t => { const p = findP(t, pid); if (p) delete p.assign[iid]; });
            });
            const add = ty => { const iid = row.querySelector(".tpl-add-item").value; if (!iid) { showToast("⚠️ Önce bir madde seçin.", "warn"); return; } tsave(t => { const p = findP(t, pid); if (p) p.assign[iid] = ty; }); };
            row.querySelector(".tpl-add-g").onclick = () => add("G");
            row.querySelector(".tpl-add-b").onclick = () => add("B");
        });
        q("tpl-person-sel").onchange = (e) => { const p = people[+e.target.value]; if (e.target.value !== "" && p) { q("tpl-person-name").value = p.name || ""; q("tpl-person-titles").value = p.title || ""; } };
        q("btn-tpl-person-add").onclick = () => {
            const name = q("tpl-person-name").value.trim(), titles = HC.splitList(q("tpl-person-titles").value);
            if (!name && !titles.length) { showToast("⚠️ Ad ya da ünvan yazın.", "warn"); return; }
            tsave(t => { t.people.push({ id: HC.newId(), name: name, titles: titles, assign: {}, priority: 0, negative: [], fromRule: [] }); });
        };
        sec.querySelectorAll(".tpl-item").forEach(el => {
            const iid = el.getAttribute("data-i");
            el.querySelector(".tpl-item-del").onclick = () => { tsave(t => { const it = t.items.find(x => x.id === iid); t.people.forEach(p => { delete p.assign[iid]; }); if (it && it.custom) t.items = t.items.filter(x => x.id !== iid); else if (!t.removed.includes(iid)) t.removed.push(iid); }); };
            el.querySelector(".tpl-item-edit").onclick = () => {
                const s0 = getRulesStore(), it0 = s0.template && s0.template.items.find(x => x.id === iid);
                if (!it0) return;
                // v3.6.35: açılır pencere (prompt) yerine satır içi düzenleme
                el.innerHTML = '<input class="tpl-ed-l" style="width:130px; padding:2px 5px;"><input class="tpl-ed-k" style="width:220px; padding:2px 5px;" placeholder="anahtar kelimeler, virgülle"><button class="ico ico-add tpl-ed-ok" title="Kaydet">✔</button><button class="ico ico-del tpl-ed-no" title="Vazgeç">✕</button>';
                el.querySelector(".tpl-ed-l").value = it0.label; el.querySelector(".tpl-ed-k").value = it0.keywords.join(", "); el.querySelector(".tpl-ed-l").focus();
                const ok = () => { const lb = el.querySelector(".tpl-ed-l").value, kws = HC.splitList(el.querySelector(".tpl-ed-k").value);
                    if (!lb.trim() || !kws.length) { showToast("⚠️ Ad ve en az bir anahtar kelime gerekli.", "warn"); return; }
                    tsave(t => { const it = t.items.find(x => x.id === iid); if (it) { it.label = lb.trim(); it.keywords = kws; } }); };
                el.querySelector(".tpl-ed-ok").onclick = ok; el.querySelector(".tpl-ed-no").onclick = () => renderRulesModal();
                el.querySelectorAll("input").forEach(x => { x.onkeydown = (e) => { if (e.key === "Enter") ok(); if (e.key === "Escape") renderRulesModal(); }; });
            };
        });
        sec.querySelectorAll(".tpl-item-restore").forEach(b => { b.onclick = () => { const iid = b.getAttribute("data-i"); tsave(t => { t.removed = t.removed.filter(x => x !== iid); }); }; });
        q("btn-tpl-item-add").onclick = () => {
            const lb = q("tpl-item-label").value.trim(), kws = HC.splitList(q("tpl-item-kw").value);
            if (!lb || !kws.length) { showToast("⚠️ Madde adı ve en az bir anahtar kelime yazın.", "warn"); return; }
            tsave(t => { t.items.push({ id: "c_" + HC.newId(), label: lb, keywords: kws, custom: true }); });
        };
    }
    function bindRulesUi() {
        const b = document.getElementById("btn-havale-rules");
        if (b) b.onclick = openRulesModal;
        const s = document.getElementById("btn-havale-setup");
        if (s) s.onclick = openSetupPage;
        refreshRulesUi();
    }
    // =========================================================================
    // NEW (v3.5): 📅 GÜNLÜ EVRAK TAKİBİ — son tarihi belirlenen evrakların en az bilgiyle takibi + masaüstü hatırlatma ayarları + CSV/.ics indirme.
    // Saklanan (yalnızca bu bilgisayarda, chrome.storage.local "ebys_takip_v1"): evrak sayısı, konu, gönderen (kısa), son tarih, ilk görülme tarihi,
    // durum (açık/tamamlandı), isteğe bağlı not. Evrak metni ve ekler SAKLANMAZ. Bildirimleri arka plan hizmet çalışanı (background.js) gösterir.
    // İndirmeler Blob + <a download> ile yapılır (downloads izni yok); dosyalar yalnızca kullanıcı düğmeye bastığında oluşturulur.
    // =========================================================================
    const TK = (function() {
    // ---- Evrak Asistanı günlü evrak takip çekirdeği (v3.5): iş günü sayacı, takip deposu, bildirim eşikleri, CSV ve .ics üretimi.
    // Tek kaynak: hem content.js'e hem background.js'e (v35src/takip_core.js) aynen gömülür. Ağ erişimi, kişi adı, okula özgü veri İÇERMEZ.
    const STORE_KEY = "ebys_takip_v1";              // { items: [...], dismissed: [evrak no] }
    const SETTINGS_KEY = "ebys_takip_settings_v1";  // { autoAdd, notify: { enabled, thresholds, overdue, dailyTime } }
    const NOTIFIED_KEY = "ebys_takip_notified_v1";  // yalnızca arka plan: { "<id>|<sonTarih>|<eşik>": "YYYY-MM-DD" } (tekrar bildirmeme)
    const MAX_ITEMS = 500;
    const THRESHOLD_CHOICES = [5, 3, 2, 1, 0];      // 0 = son gün
    const DEFAULT_SETTINGS = { autoAdd: true, notify: { enabled: true, thresholds: [3, 1, 0], overdue: true, dailyTime: "08:30" } };
    // sabit tarihli resmî tatiller (content.js'teki geri sayımla AYNI liste; dinî bayramlar her yıl değiştiği için dahil değildir)
    const FIXED_HOLIDAYS = ["01-01", "04-23", "05-01", "05-19", "07-15", "08-30", "10-29"];
    const pad2 = (n) => String(n).padStart(2, "0");
    const isPlainObject = v => v !== null && typeof v === "object" && !Array.isArray(v);
    function utcDate(y, m, d) { const dt = new Date(Date.UTC(y, m - 1, d)); return (dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d) ? dt : null; }
    function fromIso(s) { const m = String(s || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? utcDate(+m[1], +m[2], +m[3]) : null; }
    function isoOf(dt) { return dt.getUTCFullYear() + "-" + pad2(dt.getUTCMonth() + 1) + "-" + pad2(dt.getUTCDate()); }
    function isValidIso(s) { return !!fromIso(s); }
    function fmtTr(iso) { const d = fromIso(iso); return d ? pad2(d.getUTCDate()) + "." + pad2(d.getUTCMonth() + 1) + "." + d.getUTCFullYear() : ""; }
    function parseTrOrIso(s) {
        s = String(s || "").trim();
        if (isValidIso(s)) return s;
        const m = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
        const d = m && utcDate(+m[3], +m[2], +m[1]);
        return d ? isoOf(d) : "";
    }
    // İstanbul saatiyle bugün / saat (Türkiye 2016'dan beri sürekli UTC+3; Intl yoksa +3 kullanılır)
    function istanbulParts(ms) {
        const t = ms == null ? Date.now() : ms;
        try {
            const p = {};
            new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Istanbul", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" })
                .formatToParts(new Date(t)).forEach(x => { p[x.type] = x.value; });
            return { iso: p.year + "-" + p.month + "-" + p.day, hh: +p.hour % 24, mm: +p.minute };
        } catch (e) {
            const n = new Date(t + 3 * 3600000);
            return { iso: isoOf(n), hh: n.getUTCHours(), mm: n.getUTCMinutes() };
        }
    }
    function todayIso(ms) { return istanbulParts(ms).iso; }
    function isBusinessDay(dt) {
        const wd = dt.getUTCDay();
        if (wd === 0 || wd === 6) return false;
        return !FIXED_HOLIDAYS.includes(pad2(dt.getUTCMonth() + 1) + "-" + pad2(dt.getUTCDate()));
    }
    // (a, b] aralığındaki iş günü sayısı (a < b)
    function businessDaysBetween(aIso, bIso) {
        const a = fromIso(aIso), b = fromIso(bIso);
        if (!a || !b || b <= a) return 0;
        let n = 0;
        for (let t = a.getTime() + 86400000; t <= b.getTime(); t += 86400000) if (isBusinessDay(new Date(t))) n++;
        return n;
    }
    function calDays(aIso, bIso) { const a = fromIso(aIso), b = fromIso(bIso); return a && b ? Math.round((b.getTime() - a.getTime()) / 86400000) : null; }
    // Kalan süre: remaining = kalan iş günü (bugünden sonra, son tarih dahil); 0 = bugün son gün (ya da son tarih hafta sonu/tatil ve bugün son iş günü); < 0 = süresi geçti
    function remainingOf(deadlineIso, today) {
        const cal = calDays(today, deadlineIso);
        if (cal === null) return null;
        if (cal < 0) return { remaining: -Math.max(1, businessDaysBetween(deadlineIso, today)), cal: cal, overdueDays: -cal, overdue: true };
        if (cal === 0) return { remaining: 0, cal: 0, overdueDays: 0, overdue: false };
        return { remaining: businessDaysBetween(today, deadlineIso), cal: cal, overdueDays: 0, overdue: false };
    }
    // Renkler content.js'teki geri sayımla aynı: kırmızı ≤ 2, turuncu ≤ 5, yeşil; süresi geçen kırmızı
    function statusOf(deadlineIso, today) {
        const r = remainingOf(deadlineIso, today);
        if (!r) return { remaining: 9999, level: "green", color: "#86EFAC", label: "Tarih yok", plain: "tarih yok", overdue: false, cal: null };
        const level = r.overdue || r.remaining <= 2 ? "red" : r.remaining <= 5 ? "orange" : "green";
        const color = level === "red" ? "#F87171" : level === "orange" ? "#FB923C" : "#86EFAC";
        let plain, label;
        if (r.overdue) { plain = "süresi geçti (" + r.overdueDays + " gün)"; label = "⚠️ Süresi geçti (" + r.overdueDays + " gün)"; }
        else if (r.cal === 0) { plain = "bugün son gün"; label = "⏰ Bugün son gün"; }
        else if (r.remaining === 0) { plain = "bugün son iş günü"; label = "⏰ Bugün son iş günü"; }
        else { plain = r.remaining + " iş günü kaldı"; label = "⏳ " + r.remaining + " iş günü kaldı"; }
        return Object.assign({}, r, { level: level, color: color, label: label, plain: plain });
    }
    function clean(s, max) { s = String(s == null ? "" : s).replace(/\p{Cc}+/gu, " ").replace(/\s+/g, " ").trim(); return s.length > max ? s.slice(0, max - 1).trimEnd() + "…" : s; }
    function shortSender(s) { return clean(s, 80); }
    function newId() { return "t" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
    function sanitizeItem(x) {
        if (!isPlainObject(x)) return null;
        const sonTarih = parseTrOrIso(x.sonTarih);
        const konu = clean(x.konu, 200);
        if (!sonTarih || !konu) return null;
        const out = {
            id: /^[A-Za-z0-9_-]{1,40}$/.test(String(x.id || "")) ? String(x.id) : newId(),
            evrakNo: clean(x.evrakNo, 80),
            konu: konu,
            gonderen: shortSender(x.gonderen),
            sonTarih: sonTarih,
            ilkGorulme: parseTrOrIso(x.ilkGorulme) || todayIso(),
            durum: x.durum === "tamamlandi" ? "tamamlandi" : "acik",
            not: clean(x.not, 300),
            kaynak: x.kaynak === "elle" ? "elle" : "otomatik"
        };
        const kimde = clean(x.kimde, 120); if (kimde) { out.kimde = kimde; out.kimdeKaynak = x.kimdeKaynak === "elle" ? "elle" : x.kimdeKaynak === "gecmis" ? "gecmis" : "ebys"; }
        if (x.tarihElle) out.tarihElle = true;
        // NEW (v3.5.2): evrak tarihi ve "kısa içerik" (yalnızca yazıda son tarihin geçtiği cümle(ler), en çok 300 karakter; yazının tamamı saklanmaz)
        const tarih = parseTrOrIso(x.tarih); if (tarih) out.tarih = tarih;
        const kisa = clean(x.kisa, 300); if (kisa) out.kisa = kisa;
        if (out.durum === "tamamlandi") out.tamamlanma = parseTrOrIso(x.tamamlanma) || todayIso();
        return out;
    }
    function sanitizeStore(v) {
        const s = isPlainObject(v) ? v : {};
        const seenId = new Set(), seenNo = new Set(), items = [];
        (Array.isArray(s.items) ? s.items : []).forEach(x => {
            const it = sanitizeItem(x);
            if (!it || seenId.has(it.id) || (it.evrakNo && seenNo.has(it.evrakNo))) return;
            seenId.add(it.id); if (it.evrakNo) seenNo.add(it.evrakNo);
            items.push(it);
        });
        // sınır: önce en eski tamamlananlar, sonra en eski son tarihliler atılır
        if (items.length > MAX_ITEMS) {
            const order = items.slice().sort((a, b) => (a.durum === b.durum ? 0 : a.durum === "tamamlandi" ? -1 : 1) || a.sonTarih.localeCompare(b.sonTarih));
            const drop = new Set(order.slice(0, items.length - MAX_ITEMS).map(x => x.id));
            for (let i = items.length - 1; i >= 0; i--) if (drop.has(items[i].id)) items.splice(i, 1);
        }
        const dismissed = Array.from(new Set((Array.isArray(s.dismissed) ? s.dismissed : []).map(x => clean(x, 80)).filter(Boolean))).slice(-MAX_ITEMS);
        return { items: items, dismissed: dismissed };
    }
    function isValidStore(v) { return isPlainObject(v) && Array.isArray(v.items) && v.items.every(x => sanitizeItem(x) !== null) && (v.dismissed === undefined || Array.isArray(v.dismissed)); }
    function sanitizeTime(t) { const m = String(t || "").match(/^(\d{1,2}):(\d{2})$/); return m && +m[1] < 24 && +m[2] < 60 ? pad2(+m[1]) + ":" + m[2] : DEFAULT_SETTINGS.notify.dailyTime; }
    function sanitizeSettings(v) {
        const s = isPlainObject(v) ? v : {}, n = isPlainObject(s.notify) ? s.notify : {};
        const th = Array.isArray(n.thresholds) ? n.thresholds.map(Number).filter(x => THRESHOLD_CHOICES.includes(x)) : DEFAULT_SETTINGS.notify.thresholds;
        return {
            autoAdd: s.autoAdd === undefined ? DEFAULT_SETTINGS.autoAdd : s.autoAdd === true,
            notify: {
                enabled: n.enabled === undefined ? DEFAULT_SETTINGS.notify.enabled : n.enabled === true,
                thresholds: Array.from(new Set(th)).sort((a, b) => b - a),
                overdue: n.overdue === undefined ? DEFAULT_SETTINGS.notify.overdue : n.overdue === true,
                dailyTime: sanitizeTime(n.dailyTime)
            }
        };
    }
    function isValidSettings(v) { return isPlainObject(v) && (v.notify === undefined || isPlainObject(v.notify)); }
    function findByNo(store, evrakNo) { return evrakNo ? store.items.find(x => x.evrakNo === evrakNo) || null : null; }
    // Evrakın son tarihi belirlendiğinde: var olan kaydı günceller ya da (otomatikse) ekler. Dönüş: { store, action: "added"|"updated"|"same"|"dismissed"|"manual", item }
    function upsertFromDoc(store, rec, opts) {
        store = sanitizeStore(store);
        const today = (opts && opts.today) || todayIso();
        const no = clean(rec.evrakNo, 80);
        const ex = findByNo(store, no);
        if (ex) {
            let changed = false;
            const k = clean(rec.konu, 200), g = shortSender(rec.gonderen), iso = parseTrOrIso(rec.sonTarih);
            if (k && k !== ex.konu && ex.kaynak !== "elle") { ex.konu = k; changed = true; }
            if (g && g !== ex.gonderen) { ex.gonderen = g; changed = true; }
            if (iso && iso !== ex.sonTarih && !ex.tarihElle) { ex.sonTarih = iso; changed = true; }
            const kd = clean(rec.kimde, 120);
            if (kd) {
                const fromGecmis = rec.kimdeKaynak === "gecmis";
                const fromEbys = rec.kimdeKaynak === "ebys" || fromGecmis;
                const keepGecmis = ex.kimdeKaynak === "gecmis" && !fromGecmis; // v1.0.2: Evrak Geçmişi'nden okunan (Gereği) liste tahminiyle ezilmez
                if (!keepGecmis && (fromEbys || !ex.kimde || ex.kimdeKaynak !== "elle")) {
                    const srcNew = fromGecmis ? "gecmis" : fromEbys ? "ebys" : (rec.kimdeKaynak === "elle" ? "elle" : "ebys");
                    if (kd !== (ex.kimde || "") || (fromEbys && ex.kimdeKaynak !== srcNew)) { ex.kimde = kd; ex.kimdeKaynak = srcNew; changed = true; }
                }
            }
            const kz = clean(rec.kisa, 300), td = parseTrOrIso(rec.tarih); // NEW (v3.5.2)
            if (kz && kz !== ex.kisa) { ex.kisa = kz; changed = true; }
            if (td && td !== ex.tarih) { ex.tarih = td; changed = true; }
            return { store: store, action: changed ? "updated" : "same", item: ex };
        }
        const force = !!(opts && opts.force);
        if (!force && no && store.dismissed.includes(no)) return { store: store, action: "dismissed", item: null };
        if (!force && !(opts && opts.autoAdd)) return { store: store, action: "manual", item: null };
        const it = sanitizeItem({ evrakNo: no, konu: rec.konu, gonderen: rec.gonderen, sonTarih: rec.sonTarih, ilkGorulme: today, durum: "acik", not: rec.not || "", kaynak: force && rec.kaynak === "elle" ? "elle" : "otomatik", tarih: rec.tarih, kisa: rec.kisa, kimde: rec.kimde, kimdeKaynak: rec.kimdeKaynak });
        if (!it) return { store: store, action: "invalid", item: null };
        store.items.push(it);
        if (no) store.dismissed = store.dismissed.filter(x => x !== no);
        return { store: sanitizeStore(store), action: "added", item: it };
    }
    function addManual(store, rec, today) {
        store = sanitizeStore(store);
        const no = clean(rec.evrakNo, 80);
        if (no && findByNo(store, no)) return { store: store, item: null, error: "Bu evrak numarası zaten takipte." };
        const it = sanitizeItem({ evrakNo: no, konu: rec.konu, gonderen: rec.gonderen, sonTarih: rec.sonTarih, ilkGorulme: today || todayIso(), durum: "acik", not: rec.not, kaynak: "elle", tarihElle: true, kimde: rec.kimde, kimdeKaynak: rec.kimde ? "elle" : "" });
        if (!it) return { store: store, item: null, error: "Konu ve geçerli bir son tarih gerekli." };
        store.items.push(it);
        if (no) store.dismissed = store.dismissed.filter(x => x !== no);
        return { store: sanitizeStore(store), item: it, error: "" };
    }
    function updateItem(store, id, patch, today) {
        store = sanitizeStore(store);
        const it = store.items.find(x => x.id === id);
        if (!it) return { store: store, item: null, error: "Kayıt bulunamadı." };
        if (patch.sonTarih !== undefined) { const iso = parseTrOrIso(patch.sonTarih); if (!iso) return { store: store, item: it, error: "Geçerli bir tarih girin." }; if (iso !== it.sonTarih) { it.sonTarih = iso; it.tarihElle = true; } }
        if (patch.konu !== undefined) { const k = clean(patch.konu, 200); if (!k) return { store: store, item: it, error: "Konu boş olamaz." }; it.konu = k; }
        if (patch.not !== undefined) it.not = clean(patch.not, 300);
        if (patch.kimde !== undefined) {
            const kd = clean(patch.kimde, 120);
            if (kd) { it.kimde = kd; it.kimdeKaynak = patch.kimdeKaynak === "ebys" ? "ebys" : patch.kimdeKaynak === "gecmis" ? "gecmis" : "elle"; }
            else { delete it.kimde; delete it.kimdeKaynak; }
        }
        if (patch.durum !== undefined) {
            it.durum = patch.durum === "tamamlandi" ? "tamamlandi" : "acik";
            if (it.durum === "tamamlandi") it.tamamlanma = today || todayIso(); else delete it.tamamlanma;
        }
        return { store: sanitizeStore(store), item: it, error: "" };
    }
    // Silinen / geri alınan evrak numarası "dismissed" listesine girer → aynı evrak yeniden otomatik eklenmez ("📅 Takibe al" ile eklenebilir)
    function removeItem(store, id, remember) {
        store = sanitizeStore(store);
        const it = store.items.find(x => x.id === id);
        store.items = store.items.filter(x => x.id !== id);
        if (it && it.evrakNo && remember !== false && !store.dismissed.includes(it.evrakNo)) store.dismissed.push(it.evrakNo);
        return { store: sanitizeStore(store), item: it || null };
    }
    function openItems(store) { return sanitizeStore(store).items.filter(x => x.durum === "acik"); }
    function sortForList(items, today) {
        return items.map(x => ({ x: x, s: statusOf(x.sonTarih, today) }))
            .sort((a, b) => a.s.remaining - b.s.remaining || a.x.sonTarih.localeCompare(b.x.sonTarih) || a.x.konu.localeCompare(b.x.konu, "tr"))
            .map(o => o.x);
    }
    function counts(store, today) {
        const st = sanitizeStore(store), open = st.items.filter(x => x.durum === "acik");
        const ss = open.map(x => statusOf(x.sonTarih, today));
        return { open: open.length, done: st.items.length - open.length, overdue: ss.filter(s => s.overdue).length, red: ss.filter(s => s.level === "red").length,
            soon: ss.filter(s => !s.overdue && s.remaining <= 3).length, manual: st.items.filter(x => x.kaynak === "elle").length, dismissed: st.dismissed.length };
    }
    function kimdeOf(it) { return clean(it && it.kimde, 120); }
    function kimdeLabel(it) { return kimdeOf(it) || "bilinmiyor"; }
    function filterByKimde(items, filter) {
        if (!filter || filter === "tumu" || filter === "") return (items || []).slice();
        if (filter === "__bilinmiyor__") return (items || []).filter(it => !kimdeOf(it));
        return (items || []).filter(it => kimdeOf(it) === filter);
    }
    function summaryByKimde(store, today) {
        const map = new Map();
        openItems(store).forEach(it => {
            const key = kimdeOf(it) || "__bilinmiyor__";
            if (!map.has(key)) map.set(key, { key: key, name: kimdeLabel(it), open: 0, overdue: 0 });
            const row = map.get(key);
            row.open++;
            if (statusOf(it.sonTarih, today).overdue) row.overdue++;
        });
        return Array.from(map.values()).sort((a, b) => (a.key === "__bilinmiyor__") - (b.key === "__bilinmiyor__") || b.open - a.open || a.name.localeCompare(b.name, "tr"));
    }
    // ---- bildirim mantığı (arka plan): hangi açık evrak hangi eşikte bildirilmeli?
    // Eşik: kalan iş günü ≤ eşik olan EN KÜÇÜK seçili eşik (Chrome o gün kapalıysa sonraki açılışta telafi edilir); her eşik her evrak için bir kez;
    // süresi geçmiş evrak günde bir kez. Anahtar son tarihi de içerir → tarih düzeltilirse yeniden bildirilir.
    function stageOf(item, today, settings) {
        const s = statusOf(item.sonTarih, today);
        if (s.cal === null) return null;
        if (s.overdue) return settings.notify.overdue ? "gecti" : null;
        const th = settings.notify.thresholds.filter(t => s.remaining <= t).sort((a, b) => a - b);
        return th.length ? "t" + th[0] : null;
    }
    function dueNotifications(store, settings, notified, today) {
        settings = sanitizeSettings(settings);
        notified = isPlainObject(notified) ? notified : {};
        if (!settings.notify.enabled) return [];
        const out = [];
        sortForList(openItems(store), today).forEach(it => {
            const stage = stageOf(it, today, settings);
            if (!stage) return;
            const key = it.id + "|" + it.sonTarih + "|" + stage;
            const last = notified[key];
            if (stage === "gecti" ? last === today : !!last) return;
            out.push({ key: key, stage: stage, item: it, status: statusOf(it.sonTarih, today) });
        });
        return out;
    }
    function notificationText(item, today) {
        const s = statusOf(item.sonTarih, today);
        return {
            title: clean(item.konu, 70) || "Günlü evrak",
            message: "Son tarih: " + fmtTr(item.sonTarih) + " — " + s.plain,
            contextMessage: item.evrakNo ? "Evrak No: " + clean(item.evrakNo, 60) : "Evrak Asistanı — Günlü Takip"
        };
    }
    function pruneNotified(notified, store, today) {
        const ids = new Set(sanitizeStore(store).items.map(x => x.id)), out = {};
        Object.keys(isPlainObject(notified) ? notified : {}).forEach(k => {
            const d = notified[k], cd = calDays(d, today);
            if (ids.has(k.split("|")[0]) && cd !== null && cd <= 90) out[k] = d;
        });
        return out;
    }
    // Günlük saat: bugün HH:MM (İstanbul) geçmediyse bugün, geçtiyse yarın → epoch ms
    function nextDailyMs(dailyTime, nowMs) {
        const t = sanitizeTime(dailyTime).split(":").map(Number);
        const p = istanbulParts(nowMs);
        const offsetMs = (Date.UTC(+p.iso.slice(0, 4), +p.iso.slice(5, 7) - 1, +p.iso.slice(8, 10), p.hh, p.mm) - Math.floor(nowMs / 60000) * 60000);
        let target = Date.UTC(+p.iso.slice(0, 4), +p.iso.slice(5, 7) - 1, +p.iso.slice(8, 10), t[0], t[1]) - offsetMs;
        if (target <= nowMs) target += 86400000;
        return target;
    }
    function isBeforeDailyTime(dailyTime, nowMs) {
        const t = sanitizeTime(dailyTime).split(":").map(Number), p = istanbulParts(nowMs);
        return p.hh * 60 + p.mm < t[0] * 60 + t[1];
    }
    // ---- dışa aktarma: Excel uyumlu CSV (UTF-8 BOM, ; ayraç, CRLF) — formül enjeksiyonuna karşı = + - @ ile başlayan hücreler ' ile başlatılır
    const CSV_COLUMNS = ["Evrak No", "Konu", "Gönderen", "Kimde", "Son Tarih", "Kalan İş Günü", "Durum", "Not"];
    function csvCell(v) {
        let s = String(v == null ? "" : v);
        if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+$/.test(s)) s = "'" + s;
        return /[";\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }
    function durumText(it, s) { return it.durum === "tamamlandi" ? "Tamamlandı" : s.overdue ? "Süresi geçti" : s.remaining === 0 ? "Son gün" : "Açık"; }
    function buildCsv(store, today) {
        const st = sanitizeStore(store);
        const open = sortForList(st.items.filter(x => x.durum === "acik"), today);
        const done = st.items.filter(x => x.durum === "tamamlandi").sort((a, b) => a.sonTarih.localeCompare(b.sonTarih));
        const rows = [CSV_COLUMNS];
        open.concat(done).forEach(it => {
            const s = statusOf(it.sonTarih, today);
            rows.push([it.evrakNo, it.konu, it.gonderen, it.kimde || "bilinmiyor", fmtTr(it.sonTarih), it.durum === "tamamlandi" ? "" : String(s.remaining), durumText(it, s), it.not]);
        });
        return "\uFEFF" + rows.map(r => r.map(csvCell).join(";")).join("\r\n") + "\r\n";
    }
    // ---- dışa aktarma: iCalendar (.ics, RFC 5545) — açık her evrak için son tarihte tüm gün etkinliği + 3 gün ve 1 gün önce hatırlatma (günlük saatte)
    function fnv1a(s) { let h = 0x811c9dc5; for (const ch of String(s)) { h ^= ch.codePointAt(0); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(16).padStart(8, "0"); }
    function icsUid(it) { return "evrak-" + (it.evrakNo ? fnv1a("no:" + it.evrakNo) + fnv1a("no2:" + it.evrakNo) : fnv1a("id:" + it.id) + fnv1a("id2:" + it.id)) + "@evrak-asistani"; }
    function icsEsc(s) { return String(s == null ? "" : s).replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n"); }
    function icsFold(line) {
        // 75 sekizlik sınırı (UTF-8), çok baytlı karakter bölünmez
        const enc = (c) => { const n = c.codePointAt(0); return n < 0x80 ? 1 : n < 0x800 ? 2 : n < 0x10000 ? 3 : 4; };
        const out = []; let cur = "", len = 0, limit = 75;
        for (const ch of line) {
            const b = enc(ch);
            if (len + b > limit) { out.push(cur); cur = " "; len = 1; limit = 75; }
            cur += ch; len += b;
        }
        out.push(cur);
        return out.join("\r\n");
    }
    function icsDuration(minutesBefore) {
        const d = Math.floor(minutesBefore / 1440), h = Math.floor((minutesBefore % 1440) / 60), m = minutesBefore % 60;
        return "-P" + (d ? d + "D" : "") + (h || m ? "T" + (h ? h + "H" : "") + (m ? m + "M" : "") : (d ? "" : "T0M"));
    }
    function utcStamp(ms) { const d = new Date(ms); return d.getUTCFullYear() + pad2(d.getUTCMonth() + 1) + pad2(d.getUTCDate()) + "T" + pad2(d.getUTCHours()) + pad2(d.getUTCMinutes()) + pad2(d.getUTCSeconds()) + "Z"; }
    function buildIcs(store, today, nowMs, dailyTime) {
        const t = sanitizeTime(dailyTime).split(":").map(Number), atMin = t[0] * 60 + t[1];
        const L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Evrak Asistani//Gunlu Evrak Takibi 3.5.0//TR", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
            "X-WR-CALNAME:Evrak Takip", "X-WR-TIMEZONE:Europe/Istanbul",
            "BEGIN:VTIMEZONE", "TZID:Europe/Istanbul", "BEGIN:STANDARD", "DTSTART:19700101T000000", "TZOFFSETFROM:+0300", "TZOFFSETTO:+0300", "TZNAME:+03", "END:STANDARD", "END:VTIMEZONE"];
        const stamp = utcStamp(nowMs == null ? Date.now() : nowMs);
        sortForList(openItems(store), today).forEach(it => {
            const d = fromIso(it.sonTarih), next = new Date(d.getTime() + 86400000);
            const konu = clean(it.konu, 200);
            const desc = [it.evrakNo ? "Evrak No: " + it.evrakNo : "", it.gonderen ? "Gönderen: " + it.gonderen : "", it.kimde ? "Kimde: " + it.kimde : "Kimde: bilinmiyor", "Son tarih: " + fmtTr(it.sonTarih), it.not ? "Not: " + it.not : "", "Evrak Asistanı — Günlü Evrak Takibi"].filter(Boolean).join("\n");
            L.push("BEGIN:VEVENT", "UID:" + icsUid(it), "DTSTAMP:" + stamp,
                "DTSTART;VALUE=DATE:" + isoOf(d).replace(/-/g, ""), "DTEND;VALUE=DATE:" + isoOf(next).replace(/-/g, ""),
                "SUMMARY:" + icsEsc("Son gün: " + konu), "DESCRIPTION:" + icsEsc(desc), "STATUS:CONFIRMED", "TRANSP:TRANSPARENT");
            [[3, "3 gün kaldı"], [1, "1 gün kaldı"]].forEach(([days, txt]) => {
                L.push("BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:" + icsEsc(konu + " — " + txt + " (son tarih " + fmtTr(it.sonTarih) + ")"), "TRIGGER:" + icsDuration(days * 1440 - atMin), "END:VALARM");
            });
            L.push("END:VEVENT");
        });
        L.push("END:VCALENDAR");
        return L.map(icsFold).join("\r\n") + "\r\n";
    }
    function fileName(ext, today) { return "evrak-takip-" + (today || todayIso()) + "." + ext; }
    return { STORE_KEY, SETTINGS_KEY, NOTIFIED_KEY, MAX_ITEMS, THRESHOLD_CHOICES, DEFAULT_SETTINGS, FIXED_HOLIDAYS, fromIso, isoOf, isValidIso, fmtTr, parseTrOrIso, istanbulParts, todayIso,
        isBusinessDay, businessDaysBetween, calDays, remainingOf, statusOf, clean, shortSender, newId, sanitizeItem, sanitizeStore, isValidStore, sanitizeTime, sanitizeSettings, isValidSettings,
        findByNo, upsertFromDoc, addManual, updateItem, removeItem, openItems, sortForList, counts, kimdeOf, kimdeLabel, filterByKimde, summaryByKimde, stageOf, dueNotifications, notificationText, pruneNotified, nextDailyMs, isBeforeDailyTime,
        CSV_COLUMNS, csvCell, buildCsv, fnv1a, icsUid, icsEsc, icsFold, icsDuration, buildIcs, fileName };
    })();
    // NEW (v3.5.2): 📗 .xlsx yazıcısı (eklentinin kendi kodu: ZIP 'stored' + CRC-32 + SpreadsheetML; dış kütüphane / uzak kod yok)
    const XL = (function() {
    // ---- Evrak Asistanı XLSX yazıcısı (v3.5.2): Office Open XML (SpreadsheetML) çalışma kitabını tarayıcıda üretir; dış kütüphane / uzak kod / ağ YOK.
    // ZIP "stored" (sıkıştırmasız) + CRC-32; paylaşılan dizgiler; stiller: kalın başlık, dolgu renkleri, kaydırmalı metin, tarih biçimi; dondurulmuş başlık, otomatik filtre.
    // Tek kaynak: v352src/xlsx_core.js (content.js'e aynen gömülür).
    const CRC_T = (function () { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
    function crc32(u8) { let c = 0xFFFFFFFF; for (let i = 0; i < u8.length; i++) c = CRC_T[(c ^ u8[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
    const utf8 = (s) => new TextEncoder().encode(s);
    function zipStore(files, when) {
        const d = when instanceof Date ? when : new Date();
        const dosTime = ((d.getHours() & 31) << 11) | ((d.getMinutes() & 63) << 5) | ((d.getSeconds() / 2) & 31);
        const dosDate = (((d.getFullYear() - 1980) & 127) << 9) | (((d.getMonth() + 1) & 15) << 5) | (d.getDate() & 31);
        const parts = [], central = [];
        let off = 0;
        files.forEach(f => {
            const name = utf8(f.name), data = typeof f.data === "string" ? utf8(f.data) : f.data, crc = crc32(data);
            const h = new DataView(new ArrayBuffer(30));
            h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true);
            h.setUint16(10, dosTime, true); h.setUint16(12, dosDate, true); h.setUint32(14, crc, true); h.setUint32(18, data.length, true); h.setUint32(22, data.length, true);
            h.setUint16(26, name.length, true); h.setUint16(28, 0, true);
            parts.push(new Uint8Array(h.buffer), name, data);
            const c = new DataView(new ArrayBuffer(46));
            c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, 0, true);
            c.setUint16(12, dosTime, true); c.setUint16(14, dosDate, true); c.setUint32(16, crc, true); c.setUint32(20, data.length, true); c.setUint32(24, data.length, true);
            c.setUint16(28, name.length, true); c.setUint16(30, 0, true); c.setUint16(32, 0, true); c.setUint16(34, 0, true); c.setUint16(36, 0, true); c.setUint32(38, 0, true); c.setUint32(42, off, true);
            central.push(new Uint8Array(c.buffer), name);
            off += 30 + name.length + data.length;
        });
        const cdSize = central.reduce((a, b) => a + b.length, 0);
        const e = new DataView(new ArrayBuffer(22));
        e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, cdSize, true); e.setUint32(16, off, true);
        const all = parts.concat(central, [new Uint8Array(e.buffer)]);
        const out = new Uint8Array(all.reduce((a, b) => a + b.length, 0));
        let p = 0; all.forEach(b => { out.set(b, p); p += b.length; });
        return out;
    }
    // XML'de geçersiz denetim karakterleri atılır; Excel hücre sınırı 32767
    const xesc = (s) => String(s == null ? "" : s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, "").slice(0, 32000).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
    function colName(i) { let s = ""; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; }
    // ISO tarih → Excel seri günü (1900 tarih sistemi)
    function serialOf(iso) { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || "")); if (!m) return null; return Math.round((Date.UTC(+m[1], +m[2] - 1, +m[3]) - Date.UTC(1899, 11, 30)) / 86400000); }
    // Dolgu renkleri (ARGB): kırmızı / turuncu / yeşil / gri (tamamlandı) / yok
    const FILLS = { red: "FFFECACA", orange: "FFFED7AA", green: "FFBBF7D0", done: "FFE5E7EB" };
    const LEVELS = ["none", "red", "orange", "green", "done"];
    const KINDS = ["text", "wrap", "date", "num", "center"];
    function stylesXml() {
        const fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>', '<fill><patternFill patternType="solid"><fgColor rgb="FF1F3864"/><bgColor indexed="64"/></patternFill></fill>']
            .concat(["red", "orange", "green", "done"].map(l => '<fill><patternFill patternType="solid"><fgColor rgb="' + FILLS[l] + '"/><bgColor indexed="64"/></patternFill></fill>'));
        const fillIdx = { none: 0, red: 3, orange: 4, green: 5, done: 6 };
        const xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>',
            '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'];
        LEVELS.forEach(l => KINDS.forEach(k => {
            const num = k === "date" ? ' numFmtId="164" applyNumberFormat="1"' : ' numFmtId="0"';
            const al = k === "wrap" ? '<alignment vertical="top" wrapText="1"/>' : k === "num" || k === "center" || k === "date" ? '<alignment horizontal="center" vertical="top"/>' : '<alignment vertical="top"/>';
            xfs.push('<xf' + num + ' fontId="' + (l === "done" ? 2 : 0) + '" fillId="' + fillIdx[l] + '" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1">' + al + '</xf>');
        }));
        xfs.push('<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>'); // başlık (bilgi sayfası)
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            + '<numFmts count="1"><numFmt numFmtId="164" formatCode="dd\\.mm\\.yyyy"/></numFmts>'
            + '<fonts count="4"><font><sz val="11"/><color theme="1"/><name val="Calibri"/><family val="2"/><scheme val="minor"/></font>'
            + '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/><scheme val="minor"/></font>'
            + '<font><sz val="11"/><color rgb="FF4B5563"/><name val="Calibri"/><family val="2"/><scheme val="minor"/></font>'
            + '<font><b/><sz val="13"/><color theme="1"/><name val="Calibri"/><family val="2"/><scheme val="minor"/></font></fonts>'
            + '<fills count="' + fills.length + '">' + fills.join("") + '</fills>'
            + '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFBFBFBF"/></left><right style="thin"><color rgb="FFBFBFBF"/></right><top style="thin"><color rgb="FFBFBFBF"/></top><bottom style="thin"><color rgb="FFBFBFBF"/></bottom><diagonal/></border></borders>'
            + '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            + '<cellXfs count="' + xfs.length + '">' + xfs.join("") + '</cellXfs>'
            + '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles><dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/></styleSheet>';
    }
    const xfOf = (level, kind) => 2 + LEVELS.indexOf(LEVELS.includes(level) ? level : "none") * KINDS.length + Math.max(0, KINDS.indexOf(kind));
    const TITLE_XF = 2 + LEVELS.length * KINDS.length;
    // sheet: { name, cols:[{title, width, kind}], rows:[{level, cells:[value|{v,kind}]}], freeze, filter, landscape, plain:[[...]] }
    function sheetXml(sh, sst) {
        const si = (s) => { s = String(s); if (!sst.map.has(s)) { sst.map.set(s, sst.list.length); sst.list.push(s); } sst.count++; return sst.map.get(s); };
        const rowsXml = [];
        const cell = (ref, v, xf, kind) => {
            if (v === null || v === undefined || v === "") return '<c r="' + ref + '" s="' + xf + '"/>';
            if (kind === "date") { const n = serialOf(v); return n === null ? '<c r="' + ref + '" s="' + xf + '" t="s"><v>' + si(v) + '</v></c>' : '<c r="' + ref + '" s="' + xf + '"><v>' + n + '</v></c>'; }
            if (typeof v === "number" && isFinite(v)) return '<c r="' + ref + '" s="' + xf + '"><v>' + v + '</v></c>';
            return '<c r="' + ref + '" s="' + xf + '" t="s"><v>' + si(v) + '</v></c>';
        };
        let r = 0;
        if (sh.plain) {
            sh.plain.forEach((line, i) => { r++; rowsXml.push('<row r="' + r + '">' + line.map((v, j) => cell(colName(j) + r, v, i === 0 ? TITLE_XF : 0, "text")).join("") + '</row>'); });
        } else {
            r = 1;
            rowsXml.push('<row r="1" ht="30" customHeight="1">' + sh.cols.map((c, j) => cell(colName(j) + 1, c.title, 1, "text")).join("") + '</row>');
            sh.rows.forEach(row => { r++; rowsXml.push('<row r="' + r + '">' + sh.cols.map((c, j) => { const raw = row.cells[j]; const v = raw && typeof raw === "object" ? raw.v : raw; return cell(colName(j) + r, v, xfOf(row.level, c.kind), c.kind); }).join("") + '</row>'); });
        }
        const ncol = sh.plain ? Math.max(1, ...sh.plain.map(l => l.length)) : sh.cols.length;
        const last = colName(ncol - 1) + Math.max(1, r);
        const views = sh.freeze ? '<sheetViews><sheetView workbookViewId="0" tabSelected="' + (sh.selected ? 1 : 0) + '"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/></sheetView></sheetViews>'
            : '<sheetViews><sheetView workbookViewId="0"' + (sh.selected ? ' tabSelected="1"' : '') + '/></sheetViews>';
        const cols = sh.plain ? '<cols><col min="1" max="1" width="110" customWidth="1"/></cols>' : '<cols>' + sh.cols.map((c, j) => '<col min="' + (j + 1) + '" max="' + (j + 1) + '" width="' + (c.width || 12) + '" customWidth="1"/>').join("") + '</cols>';
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            + (sh.landscape ? '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>' : '')
            + '<dimension ref="A1:' + last + '"/>' + views + '<sheetFormatPr defaultRowHeight="15"/>' + cols
            + '<sheetData>' + rowsXml.join("") + '</sheetData>'
            + (sh.filter && !sh.plain ? '<autoFilter ref="A1:' + colName(ncol - 1) + Math.max(1, r) + '"/>' : '')
            + '<pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.3" footer="0.3"/>'
            + (sh.landscape ? '<pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/>' : '')
            + '</worksheet>';
    }
    function buildXlsx(sheets, meta) {
        const sst = { map: new Map(), list: [], count: 0 };
        const sheetFiles = sheets.map((sh, i) => ({ name: "xl/worksheets/sheet" + (i + 1) + ".xml", data: sheetXml(sh, sst) }));
        const now = (meta && meta.now) ? new Date(meta.now) : new Date();
        const iso = now.toISOString().replace(/\.\d{3}Z$/, "Z");
        const defs = sheets.map((sh, i) => sh.filter && !sh.plain ? '<definedName name="_xlnm._FilterDatabase" localSheetId="' + i + '" hidden="1">\'' + xesc(sh.name).replace(/'/g, "''") + '\'!$A$1:$' + colName(sh.cols.length - 1) + '$' + (sh.rows.length + 1) + '</definedName>' : "").join("");
        const files = [
            { name: "[Content_Types].xml", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
                + '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                + sheets.map((s, i) => '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join("")
                + '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
                + '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>' },
            { name: "_rels/.rels", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>' },
            { name: "docProps/core.xml", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>' + xesc((meta && meta.title) || "Evrak Asistanı") + '</dc:title><dc:creator>Evrak Asistanı</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">' + iso + '</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">' + iso + '</dcterms:modified></cp:coreProperties>' },
            { name: "docProps/app.xml", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Evrak Asistanı</Application></Properties>' },
            { name: "xl/workbook.xml", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>'
                + sheets.map((s, i) => '<sheet name="' + xesc(s.name).slice(0, 31) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>').join("") + '</sheets>' + (defs ? '<definedNames>' + defs + '</definedNames>' : '') + '</workbook>' },
            { name: "xl/_rels/workbook.xml.rels", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                + sheets.map((s, i) => '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>').join("")
                + '<Relationship Id="rId' + (sheets.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId' + (sheets.length + 2) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/></Relationships>' },
            { name: "xl/styles.xml", data: stylesXml() }
        ].concat(sheetFiles);
        files.push({ name: "xl/sharedStrings.xml", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' + sst.count + '" uniqueCount="' + sst.list.length + '">' + sst.list.map(s => '<si><t xml:space="preserve">' + xesc(s) + '</t></si>').join("") + '</sst>' });
        return zipStore(files, now);
    }
    // ---- günlü evrak takip dosyası (evrak-takip-YYYY-AA-GG.xlsx)
    function takipSheets(TK, store, today, nowMs) {
        const st = TK.sanitizeStore(store);
        const open = TK.sortForList(st.items.filter(x => x.durum === "acik"), today);
        const done = st.items.filter(x => x.durum === "tamamlandi").sort((a, b) => a.sonTarih.localeCompare(b.sonTarih));
        const cols = [{ title: "Sıra", width: 6, kind: "center" }, { title: "Son tarih", width: 12, kind: "date" }, { title: "Kalan iş günü", width: 10, kind: "num" }, { title: "Durum", width: 18, kind: "wrap" },
            { title: "Evrak no", width: 31, kind: "text" }, { title: "Tarih", width: 12, kind: "date" }, { title: "Gönderen", width: 30, kind: "wrap" }, { title: "Kimde", width: 28, kind: "wrap" }, { title: "Konu", width: 45, kind: "wrap" },
            { title: "Kısa içerik", width: 60, kind: "wrap" }, { title: "Not", width: 30, kind: "wrap" }];
        let n = 0;
        const rows = open.concat(done).map(it => {
            const isDone = it.durum === "tamamlandi", s = TK.statusOf(it.sonTarih, today);
            const level = isDone ? "done" : s.overdue || s.remaining <= 2 ? "red" : s.remaining <= 5 ? "orange" : "green";
            const durum = isDone ? "Tamamlandı" : s.overdue ? "Süresi geçti (" + s.overdueDays + " gün)" : s.cal === 0 ? "Bugün son gün" : s.remaining <= 2 ? "Acil (" + s.remaining + " iş günü)" : "Açık";
            return { level: level, cells: [++n, it.sonTarih, isDone ? "" : s.remaining, durum, it.evrakNo || "(evrak no yok)", it.tarih || "", it.gonderen || "", it.kimde || "bilinmiyor", it.konu, it.kisa || "", it.not || ""] };
        });
        const stamp = (function () { const p = TK.istanbulParts(nowMs == null ? Date.now() : nowMs); return TK.fmtTr(p.iso) + " " + String(p.hh).padStart(2, "0") + ":" + String(p.mm).padStart(2, "0"); })();
        const c = TK.counts(st, today);
        const info = [["Evrak Takip Listesi — günlü evraklar"], ["Oluşturma: " + stamp + " (İstanbul saati) — Evrak Asistanı, bu bilgisayarda oluşturuldu."],
            ["Açık: " + c.open + " · Süresi geçen: " + c.overdue + " · Tamamlanan: " + c.done], [""],
            ["Renkler: KIRMIZI = süresi geçti ya da en çok 2 iş günü kaldı · TURUNCU = 3–5 iş günü · YEŞİL = 6 iş günü ve üstü · GRİ = tamamlandı."],
            ["Kalan iş günü: hafta sonu ve sabit tarihli resmî tatiller hariç (dinî bayramlar dahil edilmez); süresi geçmiş evraklarda eksi değer."],
            ["Kısa içerik: yazıda son tarihin geçtiği cümle(ler) (en çok 300 karakter); yazının tamamı saklanmaz."],
            ["Bu dosya otomatik güncellenmez; güncel hâli için eklentiden yeniden indirin. Dosyayı paylaşırken kişisel veri içerebileceğini unutmayın."]];
        return [{ name: "Takip", cols: cols, rows: rows, freeze: true, filter: true, landscape: true, selected: true }, { name: "Açıklama", plain: info }];
    }
    function takipXlsx(TK, store, today, nowMs) { return buildXlsx(takipSheets(TK, store, today, nowMs), { title: "Evrak Takip Listesi", now: nowMs }); }
    return { crc32, zipStore, buildXlsx, colName, serialOf, xesc, takipSheets, takipXlsx, FILLS };
    })();
    // NEW (v3.5.1): 🗓️ takvim çekirdeği (takvim.js ile tek kaynak: v351src/takvim_core.js)
    const TV = (function(TK) {
    // ---- Evrak Asistanı takip TAKVİMİ çekirdeği (v3.5.1): aylık takvim + ay listesi (HTML), tek dosyalık çevrimdışı takvim, not defteri (.txt).
    // Tek kaynak: content.js (indirilen dosyalar) ve takvim.js (eklentinin takvim sayfası) içine AYNEN gömülür. Girdi: TK (takip çekirdeği).
    // Ağ erişimi, uzak kaynak, kişi adı, okula özgü veri YOKTUR; tüm metinler HTML kaçışlıdır.
    const MONTHS = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
    const DAYS = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"];
    const pad2 = (n) => String(n).padStart(2, "0");
    const esc = (s) => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    function ymOf(iso) { return String(iso || "").slice(0, 7); }
    function ymParts(ym) { const m = String(ym || "").match(/^(\d{4})-(\d{2})$/); return m && +m[2] >= 1 && +m[2] <= 12 ? { y: +m[1], m: +m[2] } : null; }
    function addMonths(ym, n) { const p = ymParts(ym); if (!p) return ""; const t = p.y * 12 + (p.m - 1) + n; return Math.floor(t / 12) + "-" + pad2((t % 12) + 1); }
    function monthTitle(ym) { const p = ymParts(ym); return p ? MONTHS[p.m - 1] + " " + p.y : ""; }
    // Pazartesi ile başlayan haftalar: [[{ iso, day, inMonth }, ×7], ...]
    function monthGrid(ym) {
        const p = ymParts(ym); if (!p) return [];
        const first = new Date(Date.UTC(p.y, p.m - 1, 1)), lead = (first.getUTCDay() + 6) % 7;
        const days = new Date(Date.UTC(p.y, p.m, 0)).getUTCDate(), weeks = [], nw = Math.ceil((lead + days) / 7);
        let t = first.getTime() - lead * 86400000;
        for (let k = 0; k < nw; k++) {
            const w = [];
            for (let i = 0; i < 7; i++, t += 86400000) { const d = new Date(t); w.push({ iso: TK.isoOf(d), day: d.getUTCDate(), inMonth: d.getUTCMonth() === p.m - 1 }); }
            weeks.push(w);
        }
        return weeks;
    }
    // kayıt + durum: level red/orange/green; tamamlanan "done" (gri)
    function decorate(it, today) {
        const s = TK.statusOf(it.sonTarih, today), done = it.durum === "tamamlandi";
        const short = done ? "Tamamlandı" : s.overdue ? s.overdueDays + " gün geçti" : s.cal === 0 ? "Bugün son gün" : s.remaining === 0 ? "Son iş günü" : s.remaining + " iş günü";
        return { it: it, s: s, done: done, level: done ? "done" : s.level, short: short, plain: done ? "tamamlandı" : s.plain };
    }
    function itemsOfMonth(store, ym, today) {
        const st = TK.sanitizeStore(store);
        return st.items.filter(x => ymOf(x.sonTarih) === ym).map(x => decorate(x, today))
            .sort((a, b) => a.it.sonTarih.localeCompare(b.it.sonTarih) || (a.done - b.done) || a.s.remaining - b.s.remaining || a.it.konu.localeCompare(b.it.konu, "tr"));
    }
    const LEVEL_TEXT = { red: "Kırmızı (≤ 2 iş günü / süresi geçti)", orange: "Turuncu (3–5 iş günü)", green: "Yeşil (6+ iş günü)", done: "Gri (tamamlandı)" };
    function shortKonu(s, n) { s = TK.clean(s, 200); return s.length > n ? s.slice(0, n - 1).trimEnd() + "…" : s; }
    // aylık takvim + altında ayın listesi (HTML parçası)
    function monthHtml(store, ym, today) {
        const items = itemsOfMonth(store, ym, today), byDay = {};
        items.forEach(x => { (byDay[x.it.sonTarih] = byDay[x.it.sonTarih] || []).push(x); });
        let h = '<section class="tv-month" data-ym="' + esc(ym) + '"><h2 class="tv-title">' + esc(monthTitle(ym)) + '</h2>'
            + '<table class="tv-grid" role="grid" aria-label="' + esc(monthTitle(ym)) + ' takvimi"><thead><tr>' + DAYS.map((d, i) => '<th scope="col" class="' + (i >= 5 ? "tv-we" : "") + '"><span class="tv-dl">' + d + '</span><span class="tv-ds">' + d.slice(0, 3) + '</span></th>').join("") + '</tr></thead><tbody>';
        monthGrid(ym).forEach(w => {
            h += "<tr>";
            w.forEach((c, i) => {
                const evs = c.inMonth ? (byDay[c.iso] || []) : [];
                const cls = ["tv-day", c.inMonth ? "" : "tv-out", c.iso === today ? "tv-today" : "", i >= 5 ? "tv-we" : "", evs.length ? "tv-has" : ""].filter(Boolean).join(" ");
                h += '<td class="' + cls + '" data-iso="' + c.iso + '"><div class="tv-num">' + c.day + (c.iso === today ? ' <span class="tv-todaylbl">Bugün</span>' : "") + "</div>";
                evs.forEach(x => {
                    h += '<div class="tv-ev tv-' + x.level + '" title="' + esc(x.it.konu + (x.it.evrakNo ? " — " + x.it.evrakNo : "") + " — " + x.plain) + '">'
                        + '<span class="tv-k">' + esc(shortKonu(x.it.konu, 40)) + '</span>'
                        + (x.it.evrakNo ? '<span class="tv-no">' + esc(x.it.evrakNo) + '</span>' : '<span class="tv-no">✍️ elle eklendi</span>')
                        + '<span class="tv-left">' + esc(x.short) + "</span></div>";
                });
                h += "</td>";
            });
            h += "</tr>";
        });
        h += '</tbody></table><h3 class="tv-lh">' + esc(monthTitle(ym)) + " — evraklar (" + items.length + ")</h3>";
        if (!items.length) h += '<p class="tv-empty">Bu ay son tarihi olan takipli evrak yok.</p>';
        else {
            h += '<table class="tv-list"><thead><tr><th>Son tarih</th><th>Kalan</th><th>Evrak No</th><th>Konu</th><th>Gönderen</th><th>Kimde</th><th>Not</th></tr></thead><tbody>';
            items.forEach(x => {
                h += '<tr class="tv-row tv-' + x.level + '"><td class="tv-nowrap">' + esc(TK.fmtTr(x.it.sonTarih)) + '</td><td class="tv-nowrap"><span class="tv-badge tv-' + x.level + '">' + esc(x.short) + '</span></td><td class="tv-mono">' + esc(x.it.evrakNo || "—") + "</td><td>" + esc(x.it.konu) + "</td><td>" + esc(x.it.gonderen || "") + "</td><td>" + esc(x.it.kimde || "bilinmiyor") + "</td><td>" + esc(x.it.not || "") + "</td></tr>";
            });
            h += "</tbody></table>";
        }
        return h + '<p class="tv-legend">' + ["red", "orange", "green", "done"].map(l => '<span class="tv-badge tv-' + l + '">' + LEVEL_TEXT[l] + "</span>").join(" ") + " · Kalan süre iş günüyle (hafta sonu ve sabit tarihli resmî tatiller hariç; dinî bayramlar dahil edilmez).</p></section>";
    }
    // açık + koyu tema, yazdırma (A4 yatay, her zaman açık renk)
    const CSS = [
        ":root{--bg:#F8FAFC;--fg:#0F172A;--mut:#475569;--card:#FFFFFF;--line:#CBD5E1;--out:#EEF2F7;--we:#F1F5F9;--today:#2563EB;",
        "--red:#B91C1C;--redbg:#FEE2E2;--orange:#9A3412;--orangebg:#FFEDD5;--green:#166534;--greenbg:#DCFCE7;--done:#475569;--donebg:#E2E8F0;}",
        "@media (prefers-color-scheme: dark){:root{--bg:#0F172A;--fg:#F1F5F9;--mut:#CBD5E1;--card:#1E293B;--line:#475569;--out:#162032;--we:#1A2436;--today:#60A5FA;",
        "--red:#FCA5A5;--redbg:#450A0A;--orange:#FDBA74;--orangebg:#431407;--green:#86EFAC;--greenbg:#052E16;--done:#CBD5E1;--donebg:#334155;}}",
        "*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:14px 'Segoe UI',Tahoma,Arial,sans-serif;line-height:1.35}",
        ".tv-wrap{max-width:1400px;margin:0 auto;padding:14px 16px}.tv-head{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:8px}",
        ".tv-head h1{font-size:20px;margin:0 12px 0 0}.tv-btn{background:var(--card);color:var(--fg);border:1px solid var(--line);border-radius:8px;padding:7px 12px;font:inherit;font-weight:600;cursor:pointer}",
        ".tv-btn:hover,.tv-btn:focus-visible{border-color:var(--today);outline:2px solid transparent}.tv-btn.tv-primary{background:var(--today);color:#fff;border-color:var(--today)}",
        ".tv-info{color:var(--mut);font-size:12.5px;margin:4px 0 10px}.tv-warn{background:var(--orangebg);color:var(--orange);border:1px solid var(--orange);padding:8px 10px;border-radius:8px}",
        ".tv-title{font-size:22px;margin:6px 0 8px}.tv-grid{width:100%;border-collapse:collapse;table-layout:fixed;background:var(--card)}",
        ".tv-grid th{padding:6px;border:1px solid var(--line);font-size:13px;text-align:left}.tv-grid th.tv-we{color:var(--mut)}.tv-ds{display:none}",
        ".tv-grid td{vertical-align:top;border:1px solid var(--line);height:104px;padding:4px;overflow:hidden}.tv-grid td.tv-we{background:var(--we)}.tv-grid td.tv-out{background:var(--out);color:var(--mut)}",
        ".tv-grid td.tv-today{outline:3px solid var(--today);outline-offset:-3px}.tv-num{font-weight:700;font-size:13px;margin-bottom:3px}.tv-todaylbl{font-size:11px;font-weight:700;color:var(--today)}",
        ".tv-ev{border-left:5px solid var(--done);background:var(--donebg);color:var(--fg);border-radius:4px;padding:2px 4px;margin:0 0 3px;font-size:11.5px;display:flex;flex-direction:column}",
        ".tv-ev .tv-k{font-weight:600}.tv-ev .tv-no{font-size:10.5px;color:var(--mut);word-break:break-all}.tv-ev .tv-left{font-size:10.5px;font-weight:700}",
        ".tv-ev.tv-red{border-color:var(--red);background:var(--redbg)}.tv-ev.tv-red .tv-left{color:var(--red)}.tv-ev.tv-orange{border-color:var(--orange);background:var(--orangebg)}.tv-ev.tv-orange .tv-left{color:var(--orange)}",
        ".tv-ev.tv-green{border-color:var(--green);background:var(--greenbg)}.tv-ev.tv-green .tv-left{color:var(--green)}.tv-ev.tv-done{opacity:.9}.tv-ev.tv-done .tv-k{text-decoration:line-through}",
        ".tv-lh{font-size:16px;margin:14px 0 6px}.tv-list{width:100%;border-collapse:collapse;background:var(--card);font-size:13px}.tv-list th,.tv-list td{border:1px solid var(--line);padding:5px 7px;text-align:left;vertical-align:top}",
        ".tv-list th{background:var(--we)}.tv-nowrap{white-space:nowrap}.tv-mono{font-family:Consolas,'Courier New',monospace;font-size:12px;word-break:break-all}.tv-row.tv-done td{color:var(--mut)}",
        ".tv-badge{display:inline-block;border:1px solid currentColor;border-radius:6px;padding:1px 6px;font-size:11.5px;font-weight:700;margin:2px 2px 2px 0}",
        ".tv-badge.tv-red{color:var(--red);background:var(--redbg)}.tv-badge.tv-orange{color:var(--orange);background:var(--orangebg)}.tv-badge.tv-green{color:var(--green);background:var(--greenbg)}.tv-badge.tv-done{color:var(--done);background:var(--donebg)}",
        ".tv-legend{color:var(--mut);font-size:12px;margin:8px 0 18px}.tv-empty{color:var(--mut)}.tv-month{margin-bottom:18px}",
        "@media (max-width:800px){.tv-dl{display:none}.tv-ds{display:inline}.tv-grid td{height:80px}}",
        ".js .tv-month{display:none}.js .tv-month.tv-active{display:block}",
        "@media print{@page{size:A4 landscape;margin:9mm}:root{--bg:#fff;--fg:#000;--mut:#333;--card:#fff;--line:#888;--out:#F3F4F6;--we:#F7F7F7;--today:#1D4ED8;",
        "--red:#991B1B;--redbg:#FEE2E2;--orange:#9A3412;--orangebg:#FFEDD5;--green:#166534;--greenbg:#DCFCE7;--done:#374151;--donebg:#E5E7EB}",
        "body{font-size:11px;-webkit-print-color-adjust:exact;print-color-adjust:exact}.tv-noprint{display:none!important}.tv-wrap{max-width:none;padding:0}",
        ".tv-grid td{height:auto;min-height:20mm}.tv-ev{font-size:9px}.tv-ev .tv-no,.tv-ev .tv-left{font-size:8.5px}.tv-lh{page-break-before:always;break-before:page;margin-top:0}.tv-list{font-size:10px}.tv-list tr{page-break-inside:avoid}",
        ".tv-title{font-size:16px;margin:0 0 4px}.js .tv-month.tv-active{display:block}}"
    ].join("\n");
    // takvimde gösterilecek aylar: açık kayıtların en erkeninden (en çok 12 ay önce) en geçine kadar; bu ay her zaman dahil; en çok 24 ay
    function monthRange(store, today) {
        const st = TK.sanitizeStore(store), cur = ymOf(today);
        const yms = st.items.map(x => ymOf(x.sonTarih)).filter(Boolean).sort();
        let a = cur, b = cur;
        if (yms.length) { if (yms[0] < a) a = yms[0]; if (yms[yms.length - 1] > b) b = yms[yms.length - 1]; }
        if (a < addMonths(cur, -12)) a = addMonths(cur, -12);
        const out = [];
        for (let x = a; x <= b && out.length < 24; x = addMonths(x, 1)) out.push(x);
        return out;
    }
    function stampTr(ms) { const p = TK.istanbulParts(ms); return TK.fmtTr(p.iso) + " " + pad2(p.hh) + ":" + pad2(p.mm); }
    // TEK DOSYALIK takvim: çift tıklayınca internetsiz açılır (gömülü stil + küçük gezinme betiği; dış kaynak yok)
    function standaloneHtml(store, today, nowMs) {
        const yms = monthRange(store, today), cur = ymOf(today), c = TK.counts(store, today);
        const nav = '<div class="tv-head tv-noprint"><button class="tv-btn" id="tv-prev" type="button">◀ Önceki ay</button><button class="tv-btn" id="tv-today" type="button">Bu ay</button><button class="tv-btn" id="tv-next" type="button">Sonraki ay ▶</button>'
            + '<button class="tv-btn tv-primary" id="tv-print" type="button">🖨️ Yazdır / PDF olarak kaydet</button></div>';
        const script = "(function(){var d=document;d.documentElement.className='js';var s=[].slice.call(d.querySelectorAll('.tv-month'));var i=0;s.forEach(function(e,k){if(e.getAttribute('data-ym')===" + JSON.stringify(cur) + ")i=k;});"
            + "function show(){s.forEach(function(e,k){e.className='tv-month'+(k===i?' tv-active':'');});var p=d.getElementById('tv-prev'),n=d.getElementById('tv-next');if(p)p.disabled=i<=0;if(n)n.disabled=i>=s.length-1;}"
            + "d.getElementById('tv-prev').onclick=function(){if(i>0){i--;show();}};d.getElementById('tv-next').onclick=function(){if(i<s.length-1){i++;show();}};"
            + "d.getElementById('tv-today').onclick=function(){s.forEach(function(e,k){if(e.getAttribute('data-ym')===" + JSON.stringify(cur) + ")i=k;});show();};d.getElementById('tv-print').onclick=function(){window.print();};show();})();";
        return '<!DOCTYPE html>\n<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Evrak Takip Takvimi — ' + esc(monthTitle(cur)) + '</title>'
            + '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; script-src \'unsafe-inline\'"><style>' + CSS + '</style></head><body><div class="tv-wrap">'
            + '<div class="tv-head"><h1>🗓️ Evrak Takip Takvimi</h1></div>'
            + '<p class="tv-info">Oluşturma: ' + esc(stampTr(nowMs)) + ' (İstanbul saati) · Açık: ' + c.open + ' · Süresi geçen: ' + c.overdue + ' · Tamamlanan: ' + c.done
            + ' · Bu dosya Evrak Asistanı tarafından <b>bu bilgisayarda</b> oluşturuldu; internet gerektirmez ve kendiliğinden güncellenmez (güncel hâli için eklentiden yeniden indirin).</p>'
            + nav + yms.map(ym => monthHtml(store, ym, today)).join("\n") + '</div><script>' + script + '</script></body></html>\n';
    }
    // NOT DEFTERİ listesi: sıralı (süresi geçen → en yakın), sonra tamamlananlar; Windows Not Defteri için UTF-8 BOM + CRLF
    function notepadText(store, today, nowMs) {
        const st = TK.sanitizeStore(store);
        const open = TK.sortForList(st.items.filter(x => x.durum === "acik"), today).map(x => decorate(x, today));
        const done = st.items.filter(x => x.durum === "tamamlandi").sort((a, b) => a.sonTarih.localeCompare(b.sonTarih)).map(x => decorate(x, today));
        const line = (x) => TK.fmtTr(x.it.sonTarih) + " — " + (x.done ? "tamamlandı" : x.s.overdue ? "SÜRESİ GEÇTİ (" + x.s.overdueDays + " gün)" : x.s.cal === 0 ? "BUGÜN SON GÜN" : x.s.remaining === 0 ? "bugün son iş günü" : x.s.remaining + " iş günü kaldı")
            + " — " + (x.it.evrakNo || "(evrak no yok)") + " — " + TK.clean(x.it.konu, 200) + (x.it.not ? "  [Not: " + TK.clean(x.it.not, 300) + "]" : "");
        const L = ["EVRAK TAKİP LİSTESİ (günlü evraklar)", "Oluşturma: " + stampTr(nowMs) + " (İstanbul saati) — Evrak Asistanı, bu bilgisayarda", "Biçim: son tarih — kalan süre — evrak no — konu", "Kalan süre iş günüyle (hafta sonu ve sabit tarihli resmî tatiller hariç).", ""];
        L.push("AÇIK EVRAKLAR (" + open.length + ")", "------------------------------");
        if (!open.length) L.push("(açık günlü evrak yok)");
        open.forEach(x => L.push(line(x)));
        if (done.length) { L.push("", "TAMAMLANANLAR (" + done.length + ")", "------------------------------"); done.forEach(x => L.push(line(x))); }
        return "\uFEFF" + L.join("\r\n") + "\r\n";
    }
    function htmlFileName(today) { return "evrak-takip-takvimi-" + ymOf(today) + ".html"; }
    return { MONTHS, DAYS, esc, ymOf, ymParts, addMonths, monthTitle, monthGrid, decorate, itemsOfMonth, monthHtml, CSS, monthRange, standaloneHtml, notepadText, htmlFileName, stampTr };
    })(TK);
    let takipShowDone = false, takipFormOpen = false, takipEditId = null, takipSettingsOpen = false, takipLastDay = "", takipKimdeFilter = "";
    const takipMemo = { raw: undefined, val: null };
    function getTakip() {
        const raw = extCache[TK.STORE_KEY];
        if (takipMemo.val && raw === takipMemo.raw) return takipMemo.val;
        takipMemo.raw = raw; takipMemo.val = TK.sanitizeStore(extClone(raw));
        return takipMemo.val;
    }
    function saveTakip(st) { const c = TK.sanitizeStore(st); extStoreSet(TK.STORE_KEY, c); refreshTakipUi(); return c; }
    function getTakipSettings() { return TK.sanitizeSettings(extStoreGet(TK.SETTINGS_KEY)); }
    function saveTakipSettings(s) { const c = TK.sanitizeSettings(s); extStoreSet(TK.SETTINGS_KEY, c); return c; }
    const takipToday = () => TK.todayIso();
    // arka plan hizmet çalışanına ileti (yanıt yoksa null; test/eski tarayıcıda sessizce geçer)
    function takipBg(type) {
        return new Promise(res => {
            let done = false;
            const fin = (v) => { if (!done) { done = true; res(v || null); } };
            try {
                if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") return fin(null);
                const p = chrome.runtime.sendMessage({ type: type }, (r) => { try { void chrome.runtime.lastError; } catch(e) {} fin(r); });
                if (p && typeof p.then === "function") p.then(fin, () => fin(null));
            } catch(e) { fin(null); }
            setTimeout(() => fin(null), 3000);
        });
    }
    function takipRecOf(d) {
        const i = d.info || {}, dl = getDeadline(d);
        const subj = d.subject && d.subject !== "Konu belirtilmemiş" ? d.subject : "";
        return { evrakNo: d.docNo || "", konu: i.konu || subj || "(konu okunamadı)", gonderen: i.gonderen || (d.gonderen && d.gonderen !== "-" ? d.gonderen : ""), sonTarih: dl ? dl.iso : "", not: takipNoteOf(d, dl),
            tarih: i.tarih || d.tarih || "", kisa: i.kisaIcerik || d.kisaIcerik || "", kimde: d.kimde || i.kimde || "", kimdeKaynak: d.kimdeKaynak || i.kimdeKaynak || "" }; // NEW (v1.0.1): Kimde
    }
    // NEW (v3.5.1): otomatik not — EBYS miadından geldiyse dayanağı; yazıda birden çok son tarih varsa diğerleri
    function takipNoteOf(d, dl) {
        if (!dl) return "";
        if (dl.kind === "miat") return dl.basis || "EBYS Miat";
        const other = (d.info && d.info.sonTarihDiger && d.info.sonTarihDiger.length ? d.info.sonTarihDiger : d.sonTarihDiger) || [];
        return other.length ? "Yazıdaki diğer son tarih" + (other.length > 1 ? "ler" : "") + ": " + other.join(", ") : "";
    }
    // otomatik not güncellenir (miat → yazıdaki tarih); kullanıcının kendi notuna dokunulmaz
    function takipFixNote(r, d) {
        const it = r && r.item;
        if (!it || (r.action !== "updated" && r.action !== "same")) return r;
        const autoNote = /^EBYS(?:'de girilen miat| Miat)/.test(it.not || "") || /^Yazıdaki diğer son tarih/.test(it.not || "") || (!it.not && it.kaynak === "otomatik");
        const n = takipNoteOf(d, getDeadline(d));
        if (autoNote && n !== (it.not || "")) { it.not = n; r.action = "updated"; }
        return r;
    }
    // NEW (v3.5.1): tarama sonrası — son tarihi bilinen (EBYS Miat ya da kayıtlı) ve takipte olmayan evraklar otomatik eklenir (otomatik ekleme açıksa)
    function takipOnScan() {
        if (!extHasConsent() || !getTakipSettings().autoAdd) return 0;
        let st = getTakip();
        const added = [];
        scannedList.forEach(d => {
            const dl = getDeadline(d);
            if (!d.docNo || !dl || !dl.iso || TK.findByNo(st, d.docNo)) return;
            const r = TK.upsertFromDoc(st, takipRecOf(d), { autoAdd: true, today: takipToday() });
            if (r.action === "added") { st = r.store; added.push(r.item); }
        });
        if (added.length) {
            saveTakip(st);
            if (added.length === 1) showTakipToast(added[0]);
            else { showToast("📅 Taramada son tarihi belli " + added.length + " günlü evrak (EBYS Miat bilgisi) takibe alındı.\nListe: 📅 Günlü Takip sekmesi.", "ok"); try { takipXlsxOffer(added.length); } catch(e) {} }
        }
        return added.length;
    }
    // NEW (v3.5.1): "AÇ ➔" ile açılan evrak — önizleme metninden son tarih (ek sekmesi tıklanmaz, evrak değiştirilmez); Nitelik yapılmışsa onun sonucu geçerlidir
    async function takipOnOpen(d) {
        try {
            if (!d || !d.docNo || d.info || !extHasConsent()) return null;
            let text = "", evrakTarihi = "", verified = false;
            if (isRealEbys() && getPreviewForm()) { const pv = await readRealPreview(d); text = pv.text; evrakTarihi = pv.evrakTarihi; verified = pv.verified; }
            else { text = await waitForPreview(d, PREVIEW_TIMEOUT_MS); verified = !!text; }
            if (!text || !verified || d.info) return null;
            applyKimdeFromEbys(d, text);
            const a = extractDocAttributes(text);
            if (a.tekrar) { takipOnRecurring({ info: { tekrar: a.tekrar, konu: a.konu, gonderen: a.gonderen }, subject: d.subject, gonderen: d.gonderen }); return "tekrar"; } // NEW (v3.6.4)
            const dl = computeDeadline(a.sonTarih, a.tarih || evrakTarihi || d.tarih);
            if (!dl) return null;
            saveDeadline(d.docNo, dl);
            d.sonTarihDiger = a.sonTarihDiger || [];
            d.kisaIcerik = a.kisaIcerik || ""; // NEW (v3.5.2)
            const r = takipFixNote(TK.upsertFromDoc(getTakip(), takipRecOf(d), { autoAdd: getTakipSettings().autoAdd, today: takipToday() }), d);
            if (r.action === "added" || r.action === "updated") saveTakip(r.store);
            if (r.action === "added") showTakipToast(r.item);
            renderCountdown(d);
            return r.action;
        } catch(e) { console.warn("[Evrak Asistanı] AÇ sonrası son tarih okunamadı:", e); return null; }
    }
    // Nitelik / Otonom ile son tarih belirlendiğinde (analyzeCardDoc) çağrılır
    function takipOnDeadline(d) {
        try {
            const dl = d && d.info && d.info.deadline;
            if (!dl || !dl.iso || !extHasConsent()) return;
            if (d.info.tekrar) return; // NEW (v3.6.4): tekrarlı yazıda takip kayıtlarını kural oluşturur (çift kayıt olmasın)
            const r = takipFixNote(TK.upsertFromDoc(getTakip(), takipRecOf(d), { autoAdd: getTakipSettings().autoAdd, today: takipToday() }), d);
            if (r.action === "added" || r.action === "updated") saveTakip(r.store);
            if (r.action === "added") showTakipToast(r.item);
            renderTakipCardBtn(d);
        } catch(e) { console.warn("[Evrak Asistanı] Takip kaydı yapılamadı:", e); }
    }
    function takipAddDoc(d) {
        const r = TK.upsertFromDoc(getTakip(), takipRecOf(d), { force: true, today: takipToday() });
        if (r.action === "added" || r.action === "updated") saveTakip(r.store);
        return r;
    }
    function showTakipToast(item) {
        try { takipXlsxOffer(1); } catch(e) {} // NEW (v3.5.2): ayar açıksa güncel Excel önerisi
        let t = document.getElementById("ebys-takip-toast");
        if (!t) { t = document.createElement("div"); t.id = "ebys-takip-toast"; t.setAttribute("role", "status"); document.body.appendChild(t); }
        t.style.cssText = "position:fixed !important; right:16px !important; bottom:72px !important; max-width:400px; z-index:2147483647 !important; padding:8px 10px 8px 12px; border-radius:12px; font:12px 'Segoe UI',sans-serif; color:#E0F2FE; background:#1E3A5F !important; border:1px solid #60A5FA; box-shadow:0 4px 16px rgba(0,0,0,.4); display:flex; gap:10px; align-items:center;";
        t.innerHTML = '<span class="tt-msg" style="flex:1;"></span><button class="tt-undo" style="background:#0F172A; color:#93C5FD; border:1px solid #60A5FA; border-radius:8px; padding:3px 8px; cursor:pointer; font-weight:bold; font-size:11px;">↩️ Geri al</button>';
        t.querySelector(".tt-msg").textContent = "📅 Takibe alındı: " + TK.clean(item.konu, 60) + " (son tarih " + TK.fmtTr(item.sonTarih) + ")";
        t.querySelector(".tt-undo").onclick = () => {
            saveTakip(TK.removeItem(getTakip(), item.id, true).store);
            t.querySelector(".tt-msg").textContent = "↩️ Takipten çıkarıldı (bu evrak yeniden otomatik eklenmez; kartta 📅 Takibe al ile ekleyebilirsiniz).";
            const u = t.querySelector(".tt-undo"); if (u) u.remove();
            clearTimeout(showTakipToast.timer); showTakipToast.timer = setTimeout(() => { t.style.display = "none"; }, 4000);
        };
        t.style.display = "flex";
        clearTimeout(showTakipToast.timer);
        showTakipToast.timer = setTimeout(() => { t.style.display = "none"; }, 10000);
    }
    // evrak kartında: "📅 Takibe al" (takipte değilse) ya da "📅 Takipte"
    function renderTakipCardBtn(d) {
        const card = d && findCardEl(d.docNo);
        if (!card) return;
        let el = card.querySelector(".card-takip");
        const dl = getDeadline(d);
        if (!dl || !dl.iso || !d.docNo) { if (el) el.remove(); return; }
        if (!el) { el = document.createElement("div"); el.className = "card-takip"; const cd = card.querySelector(".card-countdown"); if (cd) cd.after(el); else card.appendChild(el); }
        const it = TK.findByNo(getTakip(), d.docNo);
        el.style.cssText = "display:flex; gap:6px; align-items:center; font-size:10.5px;";
        const bcss = "background:#1F2D4D; color:#93C5FD; border:1px solid #60A5FA; padding:2px 8px; border-radius:6px; font-size:10px; cursor:pointer;";
        if (it) {
            el.innerHTML = '<span class="takip-state" style="color:' + (it.durum === "acik" ? "#93C5FD" : "#86EFAC") + ';">' + (it.durum === "acik" ? "📅 Takipte" : "✅ Takipte: tamamlandı") + '</span><button class="btn-takip-goto" style="' + bcss + '">Listeyi aç</button>';
            el.querySelector(".btn-takip-goto").onclick = () => { activeTab = "takip"; applyActiveTab(); };
        } else {
            el.innerHTML = '<button class="btn-takip-add" title="Bu evrakı günlü evrak takip listesine ekle" style="' + bcss + '">📅 Takibe al</button>';
            el.querySelector(".btn-takip-add").onclick = () => { const r = takipAddDoc(d); if (r.item) showToast("📅 Takibe alındı: " + TK.clean(r.item.konu, 60), "ok"); renderTakipCardBtn(d); };
        }
    }
    // NEW (v3.5.2): KISA İÇERİK — yazıda son tarihin geçtiği cümle(ler) (en çok 300 karakter); yazının tamamı saklanmaz
    function deadlineExcerpt(rawText, docDateText) {
        const t = String(rawText || "").replace(/\s+/g, " ").trim();
        if (!t) return "";
        const rel = /\b(\d{1,3}|bir|iki|üç|dört|beş|altı|yedi|sekiz|dokuz|on|on beş|yirmi|otuz)\s*\(?\w*\)?\s+(?:iş\s+)?günü?\s+(?:içinde|içerisinde|zarfında)/i;
        const dateRe = new RegExp("\\d{1,2}[./]\\d{1,2}[./]\\d{4}|\\d{1,2}\\s+(?:" + TR_MONTHS + ")\\s+\\d{4}", "i");
        const out = [];
        for (let s of t.split(/(?<=[.!?;])\s+(?=[A-ZÇĞİÖŞÜ0-9"“(])|\s+(?=İlgi\s*:|Konu\s*:|Sayı\s*:)/)) {
            s = s.trim();
            let hit = false;
            try { hit = !!findDeadlineDates(s, docDateText).chosenIso; } catch(e) {}
            if (!hit && !rel.test(s)) continue;
            if (s.length > 300) { const m = s.match(dateRe) || s.match(rel); const i = m ? m.index : 0; const a = Math.max(0, i - 170); s = (a ? "…" : "") + s.slice(a, a + 290).trim() + (a + 290 < s.length ? "…" : ""); }
            if (!out.includes(s)) out.push(s);
            if (out.length >= 3) break;
        }
        const r = out.join(" … ");
        return r.length > 300 ? r.slice(0, 299).trimEnd() + "…" : r;
    }
    // NEW (v3.5.2): Excel (.xlsx) — eklentinin kendi küçük OOXML yazıcısıyla (dış kütüphane / uzak kod yok), Blob + <a download> (downloads izni yok)
    const TK_XLSX_KEY = "ebys_takip_xlsx_v1";
    const XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    function takipXlsxSettings() { const v = extStoreGet(TK_XLSX_KEY); return { autoOffer: !!(isPlainObject(v) && v.autoOffer) }; }
    function takipXlsxName(t) { return "evrak-takip-" + t + ".xlsx"; }
    function takipDownloadXlsx() {
        const s2 = getTakip(), t = takipToday();
        if (!s2.items.length) return null;
        takipDownload(takipXlsxName(t), XL.takipXlsx(TK, s2, t, Date.now()), XLSX_MIME);
        return takipXlsxName(t);
    }
    // "Otomatik indir" ayarı: yeni günlü evrak eklenince tek tıkla indirme ÖNERİSİ (sessiz yazma yok)
    function takipXlsxOffer(n) {
        if (!takipXlsxSettings().autoOffer) return;
        let t = document.getElementById("ebys-xlsx-offer");
        if (!t) { t = document.createElement("div"); t.id = "ebys-xlsx-offer"; t.setAttribute("role", "status"); document.body.appendChild(t); }
        t.style.cssText = "position:fixed !important; right:16px !important; bottom:128px !important; max-width:400px; z-index:2147483647 !important; padding:8px 10px 8px 12px; border-radius:12px; font:12px 'Segoe UI',sans-serif; color:#DCFCE7; background:#14532D !important; border:1px solid #22C55E; box-shadow:0 4px 16px rgba(0,0,0,.4); display:flex; gap:8px; align-items:center;";
        t.innerHTML = '<span style="flex:1;">📗 Takibe ' + (n > 1 ? n + " yeni günlü evrak" : "yeni günlü evrak") + ' eklendi.</span><button class="xo-dl" style="background:#15803D; color:white; border:none; border-radius:8px; padding:4px 8px; cursor:pointer; font-weight:bold; font-size:11px;">📥 Güncel Excel\'i indir</button><button class="xo-x" title="Kapat" style="background:none; border:none; color:#BBF7D0; cursor:pointer; font-size:14px;">✕</button>';
        t.querySelector(".xo-dl").onclick = () => { const f = takipDownloadXlsx(); t.remove(); if (f) showToast("📗 " + f + " indirildi.", "ok"); };
        t.querySelector(".xo-x").onclick = () => t.remove();
        clearTimeout(takipXlsxOffer.timer);
        takipXlsxOffer.timer = setTimeout(() => { try { t.remove(); } catch(e) {} }, 30000);
    }
    function takipDownload(name, text, mime) { // text: metin ya da Uint8Array (.xlsx)
        const url = URL.createObjectURL(new Blob([text], { type: mime }));
        const a = document.createElement("a");
        a.href = url; a.download = name; a.style.display = "none";
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => { try { URL.revokeObjectURL(url); } catch(e) {} }, 60000);
    }
    function takipMsg(text, kind) {
        const m = document.getElementById("ebys-takip-msg");
        if (!m) return;
        m.textContent = text || "";
        m.style.cssText = text ? "font-size:11px; padding:6px 8px; border-radius:8px; border:1px solid " + (kind === "warn" ? "#FBBF24; color:#FDE68A;" : "#22C55E; color:#BBF7D0;") : "display:none;";
    }
    function refreshTakipUi() {
        try { renderTekrarBox(); } catch(e) {} // NEW (v3.6.4)
        takipLastDay = takipToday();
        const tb = document.getElementById("ebys-tab-btn-takip");
        if (tb) {
            const c = TK.counts(getTakip(), takipLastDay);
            tb.textContent = "📅 Günlü Takip" + (c.open ? " (" + c.open + ")" : "");
            tb.title = c.open ? c.open + " açık evrak" + (c.overdue ? ", " + c.overdue + " süresi geçmiş" : "") + (c.red ? ", " + c.red + " kırmızı" : "") : "Günlü evrak takibi";
            tb.setAttribute("data-alert", c.red ? "red" : "");
        }
        if (activeTab === "takip") renderTakipTab();
        try { scannedList.forEach(renderTakipCardBtn); } catch(e) {}
    }
    const TK_BTN = "background:#2D3D63; color:#E2E8F0; border:1px solid #56709A; padding:6px 8px; border-radius:10px; font-weight:bold; cursor:pointer; font-size:11px;";
    const TK_IN = "background:#1F2D4D; color:#F8FAFC; border:1px solid #56709A; border-radius:6px; padding:4px 6px; font-size:11px; box-sizing:border-box;";
    // ---- Müdür 1.0.2: günlü takip satırına tıklanınca takvim + ayrıntı + Kimde (Gereği). Veriler yalnız bu bilgisayarda; EBYS'ye yazılmaz. ----
    const TAKIP_DETAY_ID = "ebys-takip-detay";
    const TR_AY_ADLARI = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
    function takipRuleFor(it) { // tekrarlı yazı kuralı (varsa): TEKRAR-<kural>-<tarih> kayıtları ya da aynı konulu kural
        try {
            const rules = (typeof tekrarStore !== "undefined" && tekrarStore && Array.isArray(tekrarStore.rules)) ? tekrarStore.rules : [];
            if (!rules.length || !it) return null;
            const m = String(it.evrakNo || "").match(/^TEKRAR-(r[a-z0-9]+)-\d{4}-\d{2}-\d{2}/);
            if (m) { const r = rules.find(x => x.id === m[1]); if (r) return r; }
            const norm = s => trFold(String(s || "").replace(/^🔁\s*/, "").replace(/\s+—\s+dönem sonuna son.*$/i, "")).replace(/\s+/g, " ").trim();
            const k = norm(it.konu);
            return k ? (rules.find(x => norm(x.konu) === k) || null) : null;
        } catch (e) { return null; }
    }
    // işaretli günler: son tarih (kalan gündeyse yeşil/turuncu/kırmızı, geçtiyse kırmızı) + tekrarlı/dönemsel gelecek tarihler
    function takipDetayMarks(it, today) {
        const hasDl = !!(it && it.sonTarih);
        const st = hasDl ? TK.statusOf(it.sonTarih, today) : null; // v1.0.3: süre bulunamadıysa null
        const marks = hasDl ? [{ iso: it.sonTarih, kind: st.overdue ? "gecen" : "son", label: "Son tarih — " + st.plain }] : [];
        const rule = takipRuleFor(it);
        if (rule && rule.rule) {
            let occ = []; try { occ = ruleOccurrences(rule.rule, today, 8) || []; } catch (e) {}
            occ.forEach(o => {
                if (!o || !o.iso) return;
                if (hasDl && o.iso === it.sonTarih) { marks[0].label += " (tekrarlı: " + ruleText(rule.rule) + ")"; return; }
                marks.push({ iso: o.iso, kind: o.pre ? "on" : "tekrar", label: (o.pre ? "Ön hatırlatma" : "Sonraki dönem") + (o.shifted ? " (hafta sonu/tatil → önceki iş günü)" : "") });
            });
        }
        return { marks: marks, rule: rule, status: st };
    }
    // ay ızgarası (Pazartesi ilk gün): { baslik, yil, ay, weeks: [[{ iso, gun, buAy, bugun, marks }]] }
    function takipTakvimAy(yil, ay, marks, today) {
        const first = new Date(Date.UTC(yil, ay - 1, 1));
        const lead = (first.getUTCDay() + 6) % 7;
        const start = Date.UTC(yil, ay - 1, 1 - lead);
        const byIso = {};
        (marks || []).forEach(m => { (byIso[m.iso] = byIso[m.iso] || []).push(m); });
        const weeks = [];
        for (let w = 0; w < 6; w++) {
            const wk = [];
            for (let d = 0; d < 7; d++) {
                const dt = new Date(start + (w * 7 + d) * 86400000);
                const iso = dt.getUTCFullYear() + "-" + pad2(dt.getUTCMonth() + 1) + "-" + pad2(dt.getUTCDate());
                wk.push({ iso: iso, gun: dt.getUTCDate(), buAy: dt.getUTCMonth() === ay - 1, bugun: iso === today, hafta: d >= 5, marks: byIso[iso] || [] });
            }
            if (w >= 4 && !wk.some(c => c.buAy)) break;
            weeks.push(wk);
        }
        return { baslik: TR_AY_ADLARI[ay - 1] + " " + yil, yil: yil, ay: ay, weeks: weeks };
    }
    const TAKIP_MARK_STYLE = { son: "background:#16A34A; color:#fff;", gecen: "background:#DC2626; color:#fff;", tekrar: "background:#2563EB; color:#fff;", on: "background:#7C3AED; color:#fff;" };
    function takipKimdeLabel(ctx, it) { // ekranda gösterilecek Kimde satırı: { text, src, known }
        if (ctx.gecmisYok) return { text: "Bilinmiyor", src: "Evrak Geçmişi'nde 'Gereği İçin' havale satırı bulunamadı", known: false };
        if (!it.kimde) return { text: "Bilinmiyor", src: ctx.durum ? "" : "henüz okunmadı", known: false };
        const src = it.kimdeKaynak === "gecmis" ? "Gereği — EBYS Evrak Geçmişi" : it.kimdeKaynak === "elle" ? "elle atandı (yalnız bu bilgisayarda)" : "EBYS listesinden (Geçmiş'ten doğrulanmadı)";
        return { text: it.kimde, src: src, known: true };
    }
    function takipDetayHtml(it, today, ctx) {
        const info = takipDetayMarks(it, today), st = info.status, hasDl = !!st;
        const done = it.durum === "tamamlandi";
        const cal = takipTakvimAy(ctx.yil, ctx.ay, info.marks, today);
        const kd = takipKimdeLabel(ctx, it);
        const kapTxt = kapatildiMetni(ctx.kapatildi || (kimdeStore[ctx.docNo] && kimdeStore[ctx.docNo].kapatildi)); // v1.0.4
        const kalan = !hasDl ? '<span class="td-kalan" data-level="none" style="font-weight:800; color:#FDE68A;">Süre bulunamadı</span>' : done ? '<span style="color:#94A3B8;">✅ Tamamlandı</span>' : '<span class="td-kalan" data-level="' + (st.overdue ? "red" : st.level) + '" style="font-weight:800; color:' + (st.overdue ? "#F87171" : st.color) + ';">' + escapeHtml(st.overdue ? "⚠️ Süresi geçti (" + st.overdueDays + " gün)" : st.label) + '</span>';
        const row = (k, v) => '<div style="display:flex; gap:8px;"><div style="flex:0 0 92px; color:#94A3B8;">' + k + '</div><div style="flex:1; color:#F1F5F9; word-break:break-word;">' + v + '</div></div>';
        const head = '<tr>' + ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"].map(x => '<th style="padding:3px; font-size:10.5px; color:#94A3B8; font-weight:600;">' + x + '</th>').join("") + '</tr>';
        const body = cal.weeks.map(wk => '<tr>' + wk.map(c => {
            const m = c.marks[0];
            let css = "text-align:center; padding:5px 0; font-size:11.5px; border-radius:6px; ";
            css += m ? TAKIP_MARK_STYLE[m.kind] + " font-weight:800; " : (c.buAy ? "color:" + (c.hafta ? "#94A3B8" : "#E2E8F0") + "; " : "color:#475569; ");
            if (c.bugun) css += "outline:2px solid #FACC15; outline-offset:-2px; ";
            return '<td class="td-gun' + (m ? " td-mark td-" + m.kind : "") + '" data-iso="' + c.iso + '"' + (m ? ' data-mark="' + m.kind + '" title="' + escapeHtml(TK.fmtTr(c.iso) + " — " + c.marks.map(x => x.label).join("; ")) + '"' : "") + ' style="' + css + '">' + c.gun + '</td>';
        }).join("") + '</tr>').join("");
        const legend = '<div style="display:flex; gap:10px; flex-wrap:wrap; font-size:10.5px; color:#CBD5E1; margin-top:4px;">'
            + '<span><span style="display:inline-block; width:10px; height:10px; background:' + ((st && st.overdue) ? "#DC2626" : "#16A34A") + '; border-radius:3px;"></span> ' + ((st && st.overdue) ? "Süresi geçen son tarih" : "Son tarih") + '</span>'
            + (info.rule ? '<span><span style="display:inline-block; width:10px; height:10px; background:#2563EB; border-radius:3px;"></span> Sonraki dönemler</span><span><span style="display:inline-block; width:10px; height:10px; background:#7C3AED; border-radius:3px;"></span> Ön hatırlatma</span>' : '')
            + '<span><span style="display:inline-block; width:10px; height:10px; border:2px solid #FACC15; border-radius:3px;"></span> Bugün</span></div>';
        const list = (!info.marks.length ? '<li class="td-tarih-satir" data-mark="yok" style="color:#FDE68A;">Süre bulunamadı (yazıdan ya da EBYS miadından son tarih okunamadı)</li>' : "") + info.marks.map(m => '<li class="td-tarih-satir" data-mark="' + m.kind + '" style="color:' + (m.kind === "gecen" ? "#F87171" : "#E2E8F0") + ';"><b>' + escapeHtml(TK.fmtTr(m.iso)) + '</b> — ' + escapeHtml(m.label) + '</li>').join("");
        const okuBtn = /^E-\d/.test(it.evrakNo || "") ? '<button type="button" class="td-kimde-oku" ' + (ctx.busy ? "disabled " : "") + 'style="' + TK_BTN + ' font-size:10.5px; padding:4px 8px;">' + (ctx.busy ? "⏳ Okunuyor…" : "🔄 EBYS Evrak Geçmişi'nden oku") + '</button>' : '';
        const wappBtn = '<button type="button" class="td-wapp" title="WhatsApp ile paylaş (otomatik gönderilmez)" style="' + TK_BTN + ' font-size:10.5px; padding:4px 8px; color:#86EFAC; border-color:#22C55E;">💬 WhatsApp</button>';
        return '<div class="td-kutu" style="width:min(520px,94vw); max-height:92vh; overflow:auto; background:#1F2D4D; color:#E2E8F0; border:1.5px solid #38BDF8; border-radius:14px; padding:14px; font:12px \'Segoe UI\',sans-serif; box-shadow:0 10px 40px rgba(0,0,0,.6); display:flex; flex-direction:column; gap:8px;">'
            + '<div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;"><div class="td-konu" style="font-weight:800; font-size:13px; line-height:1.35; color:#F8FAFC;">📌 ' + escapeHtml(it.konu) + '</div><button type="button" class="td-kapat" title="Kapat (Esc)" style="background:none; border:none; color:#CBD5E1; font-size:18px; cursor:pointer; line-height:1;">✕</button></div>'
            + '<div class="td-bilgi" style="display:flex; flex-direction:column; gap:3px; background:#2D3D63; border-radius:10px; padding:8px;">'
            + row("Sayı", escapeHtml(/^TEKRAR-/.test(it.evrakNo || "") ? "Tekrarlı yazı kuralı" : (it.evrakNo || "Elle eklendi")))
            + row("Evrak tarihi", escapeHtml(it.tarih ? TK.fmtTr(it.tarih) : "—"))
            + row("Gönderen", escapeHtml(it.gonderen || "—"))
            + row("Son tarih", hasDl ? '<b class="td-son" style="color:' + (st.overdue && !done ? "#F87171" : "#F1F5F9") + ';">' + escapeHtml(TK.fmtTr(it.sonTarih)) + '</b>' : '<b class="td-son" style="color:#FDE68A;">Süre bulunamadı</b>')
            + row("Kalan gün", kalan)
            + (it.not ? row("Not", escapeHtml(it.not)) : "")
            + '</div>'
            + '<div class="td-kimde-kutu" style="background:#162544; border:1px solid ' + (kd.known ? "#22C55E" : "#56709A") + '; border-radius:10px; padding:8px; display:flex; flex-direction:column; gap:4px;">'
            + '<div style="color:#94A3B8; font-size:10.5px;">👤 Kimde (Gereği)</div>'
            + '<div class="td-kimde" style="font-size:13px; font-weight:800; color:' + (kd.known ? "#86EFAC" : "#FDE68A") + ';">' + escapeHtml(kd.text) + '</div>'
            + (kd.src ? '<div class="td-kimde-kaynak" style="font-size:10.5px; color:#A9B6CA;">' + escapeHtml(kd.src) + '</div>' : '')
            + (kapTxt ? '<div class="td-kapatildi" style="font-size:11px; font-weight:700; color:#E2E8F0;">🔒 ' + escapeHtml(kapTxt) + '</div>' : '')
            + (ctx.durum ? '<div class="td-durum" style="font-size:10.5px; color:#BAE6FD;">' + escapeHtml(ctx.durum) + '</div>' : '')
            + '<div style="display:flex; gap:6px; flex-wrap:wrap;">' + okuBtn + wappBtn + '</div></div>'
            + '<div style="display:flex; justify-content:space-between; align-items:center;"><button type="button" class="td-onceki" style="' + TK_BTN + ' padding:3px 10px;">‹</button><div class="td-ay" style="font-weight:800; color:#F8FAFC;">' + escapeHtml(cal.baslik) + '</div><div style="display:flex; gap:4px;"><button type="button" class="td-bugun" style="' + TK_BTN + ' padding:3px 8px; font-size:10.5px;">Bugün</button><button type="button" class="td-sonraki" style="' + TK_BTN + ' padding:3px 10px;">›</button></div></div>'
            + '<table class="td-takvim" style="width:100%; border-collapse:separate; border-spacing:2px; table-layout:fixed;"><thead>' + head + '</thead><tbody>' + body + '</tbody></table>'
            + legend
            + '<ul class="td-tarihler" style="margin:2px 0 0 16px; padding:0; font-size:11px; display:flex; flex-direction:column; gap:2px;">' + list + '</ul>'
            + '<div style="font-size:10px; color:#94A3B8;">Salt okunur: EBYS\'de kayıt, havale, imza veya paraf yapılmaz; veriler yalnız bu bilgisayarda tutulur. © Eyüp ŞEKER</div>'
            + '</div>';
    }
    function takipDetayRender(ctx) {
        const host = document.getElementById(TAKIP_DETAY_ID);
        if (!host) return;
        const it = takipDetayItem(ctx);
        if (!it) { host.remove(); return; }
        host.innerHTML = takipDetayHtml(it, takipToday(), ctx);
        const $ = s => host.querySelector(s);
        const kapat = () => { try { document.removeEventListener("keydown", host._esc, true); } catch (e) {} host.remove(); };
        $(".td-kapat").onclick = kapat;
        host.onclick = (ev) => { if (ev.target === host) kapat(); };
        const nav = (delta) => { let y = ctx.yil, a = ctx.ay + delta; if (a < 1) { a = 12; y--; } if (a > 12) { a = 1; y++; } ctx.yil = y; ctx.ay = a; takipDetayRender(ctx); };
        $(".td-onceki").onclick = () => nav(-1);
        $(".td-sonraki").onclick = () => nav(1);
        $(".td-bugun").onclick = () => { const t = takipToday(); ctx.yil = +t.slice(0, 4); ctx.ay = +t.slice(5, 7); takipDetayRender(ctx); };
        const oku = $(".td-kimde-oku"); if (oku) oku.onclick = () => takipDetayKimdeOku(ctx);
        const wapp = $(".td-wapp"); if (wapp) bindWaPaylasBtn(wapp, it);
    }
    // Gelen kartından açılan, takipte olmayan evrak için geçici (kaydedilmeyen) kayıt
    function takipPseudoItem(d) {
        const rec = takipRecOf(d);
        return { id: "", evrakNo: d.docNo || "", konu: TK.clean(rec.konu, 200), gonderen: rec.gonderen || "", sonTarih: TK.parseTrOrIso(rec.sonTarih) || "", tarih: TK.parseTrOrIso(rec.tarih) || "",
            durum: "acik", not: rec.not || "", kimde: d.kimde || "", kimdeKaynak: d.kimde ? (d.kimdeKaynak || "ebys") : "", gecici: true };
    }
    // pencerenin göstereceği kayıt: önce takip deposu (id ya da evrak no), yoksa kartın evrakı
    function takipDetayItem(ctx) {
        const st = getTakip();
        let it = ctx.id ? (st.items || []).find(x => x.id === ctx.id) : null;
        if (!it && ctx.docNo) it = TK.findByNo(st, ctx.docNo);
        if (it) return it;
        const d = ctx.docNo ? scannedList.find(x => x.docNo === ctx.docNo) : null;
        return d ? takipPseudoItem(d) : null;
    }
    function openTakipDetay(it, d) {
        if (!it || (!it.id && !it.evrakNo)) return null;
        const old = document.getElementById(TAKIP_DETAY_ID); if (old) { try { document.removeEventListener("keydown", old._esc, true); } catch (e) {} old.remove(); }
        const m = /^(\d{4})-(\d{2})/.exec(it.sonTarih || "") || /^(\d{4})-(\d{2})/.exec(takipToday());
        const ctx = { id: it.id || "", docNo: it.evrakNo || (d && d.docNo) || "", yil: +m[1], ay: +m[2], busy: false, durum: "", gecmisYok: false };
        const host = document.createElement("div");
        host.id = TAKIP_DETAY_ID; host.setAttribute("role", "dialog"); host.setAttribute("aria-modal", "true"); host.setAttribute("aria-label", "Evrak ayrıntısı ve takvim");
        host.style.cssText = "position:fixed !important; inset:0 !important; z-index:2147483646 !important; background:rgba(8,15,30,.62); display:flex; align-items:center; justify-content:center; padding:10px;";
        host._esc = (ev) => { if (ev.key === "Escape") { document.removeEventListener("keydown", host._esc, true); host.remove(); } };
        document.addEventListener("keydown", host._esc, true);
        document.body.appendChild(host);
        takipDetayRender(ctx);
        // Kimde: yalnızca elle atanmamış ve Geçmiş'ten okunmamışsa otomatik oku (evrak gerçek bir EBYS numarasına sahipse)
        if (/^E-\d/.test(it.evrakNo || "") && it.kimdeKaynak !== "gecmis" && it.kimdeKaynak !== "elle" && isRealEbys()) takipDetayKimdeOku(ctx);
        return host;
    }
    // Güvenli açma: hata olursa görünür bildirim (sessizce hiçbir şey olmaması engellenir)
    function openTakipDetaySafe(it, d) {
        try { const h = openTakipDetay(it, d); if (!h) throw new Error("kayıt bulunamadı"); return h; }
        catch (e) {
            console.warn("[Evrak Asistanı – Müdür Paketi] Ayrıntı açılamadı:", e);
            try { showToast("⚠️ Ayrıntı penceresi açılamadı: " + ((e && e.message) || e), "error"); } catch (x) {}
            try { takipMsg("⚠️ Ayrıntı penceresi açılamadı: " + ((e && e.message) || e), "warn"); } catch (x) {}
            return null;
        }
    }
    // Gelen kartı: takipteyse kaydı, değilse kartın evrakını gösterir (son tarih yoksa "Süre bulunamadı")
    function openDocDetay(d) {
        const it = (d && d.docNo && TK.findByNo(getTakip(), d.docNo)) || (d ? takipPseudoItem(d) : null);
        return openTakipDetaySafe(it, d);
    }
    // ---- Kimde (Gereği) kalıcı kayıt: evrak no → kişi (yalnız bu bilgisayarda); kartlar, son tarama ve takip kaydı birlikte güncellenir ----
    function kimdeApplyStored(d) {
        try { const k = d && kimdeStore[d.docNo]; if (k && k.kimde) { d.kimde = k.kimde; d.kimdeKaynak = "gecmis"; } } catch (e) {}
        return d;
    }
    function kimdeKaydet(docNo, kimde, kap) {
        const k = TK.clean(kimde, 120); if (!docNo) return;
        const kp = (kap && (kap.tarih || kap.kisi)) ? { tarih: TK.clean(kap.tarih || "", 20), kisi: TK.clean(kap.kisi || "", 120) } : null; // v1.0.4: Evrak Kapatıldı bilgisi
        if (!k && !kp) return;
        const eski = kimdeStore[docNo] || {};
        kimdeStore[docNo] = { kimde: k || eski.kimde || "", at: istanbulTodayIso() };
        if (kp) kimdeStore[docNo].kapatildi = kp; else if (eski.kapatildi) kimdeStore[docNo].kapatildi = eski.kapatildi;
        const keys = Object.keys(kimdeStore);
        if (keys.length > 500) keys.sort((a, b) => String(kimdeStore[a].at).localeCompare(String(kimdeStore[b].at))).slice(0, keys.length - 500).forEach(x => { delete kimdeStore[x]; });
        extStoreSet(KIMDE_KEY, kimdeStore);
        const d = scannedList.find(x => x.docNo === docNo);
        if (!k) { if (d) { try { renderCardMeta(d); } catch (e) {} } return; }
        if (d) { d.kimde = k; d.kimdeKaynak = "gecmis"; try { saveLastScan(); } catch (e) {} try { renderCardMeta(d); } catch (e) {} }
        const st = getTakip(), it = TK.findByNo(st, docNo);
        if (it) { const r = TK.updateItem(st, it.id, { kimde: k, kimdeKaynak: "gecmis" }, takipToday()); if (!r.error) saveTakip(r.store); }
    }
    let kimdeBusy = false;
    // Evrakı EBYS'de açıp Evrak Geçmişi'nden Kimde (Gereği) okur; bulunursa kaydeder. Salt okunur: yalnız evrak seçme ve sekme tıklaması.
    async function kimdeOkuEbys(docNo) {
        if (kimdeBusy) return { ok: false, kimde: "", error: "Başka bir Kimde okuması sürüyor; bitmesini bekleyin." };
        kimdeBusy = true;
        let res;
        try {
            res = await autoWrap("Kimde okuma", async () => {
                if (!(await openDocOrWarn(docNo))) return { ok: false, kimde: "", error: "Evrak Gelen Evraklar listesinde açılamadı (kapatılmış/havale edilmiş olabilir; yeniden tarayın)." };
                return await readGecmisKimde();
            });
        } catch (e) { res = { ok: false, kimde: "", error: e && e.ebysStop ? "Durduruldu." : "Okunamadı: " + ((e && e.message) || e) }; }
        finally { kimdeBusy = false; }
        if (res && res.ok && (res.kimde || res.kapatildi)) kimdeKaydet(docNo, res.kimde, res.kapatildi);
        return res || { ok: false, kimde: "", error: "Okunamadı" };
    }
    // v1.0.4: "Kapatıldı: gg.aa.yyyy – Kişi" (Evrak Geçmişi'ndeki en son "Evrak Kapatıldı" satırı)
    function kapatildiMetni(k) { return k && (k.tarih || k.kisi) ? "Kapatıldı: " + [k.tarih, k.kisi].filter(Boolean).join(" – ") : ""; }
    function kimdeSonucMetni(res) {
        const sy = res && res.pages > 1 ? res.pages + " sayfa, " + res.rows + " satır" : null;
        if (res && res.ok && res.kimde) return "✔️ Evrak Geçmişi okundu" + (sy || res.tarih ? " (" + [sy, res.tarih ? "son Gereği havalesi: " + res.tarih : ""].filter(Boolean).join("; ") + ")" : "") + ".";
        if (res && res.ok) {
            const ek = (res.limited ? " İlk " + GECMIS_MAX_SAYFA + " sayfa okundu (sayfa sınırı)." : "") + (res.pagerErr ? " (" + res.pagerErr + ")" : "");
            if (res.neden === "tarih-yok-belirsiz") return "Geçmişte birden çok Gereği satırı var ama tarihleri okunamadı; kişi seçilmedi.";
            if (res.neden === "sadece-kurum") return "Geçmiş okundu (" + (sy || res.rows + " satır") + "); Gereği İçin satırları yalnız kuruma/otomatik havale; kişiye Gereği havalesi yok." + ek;
            return "Geçmiş okundu (" + (sy || res.rows + " satır") + "); Gereği İçin havale satırı yok." + ek;
        }
        return "⚠️ " + ((res && res.error) || "Okunamadı");
    }
    async function takipDetayKimdeOku(ctx) {
        if (ctx.busy) return;
        const it0 = takipDetayItem(ctx);
        if (!it0 || !/^E-\d/.test(it0.evrakNo || "")) return;
        ctx.busy = true; ctx.gecmisYok = false; ctx.durum = "⏳ Evrak EBYS'de açılıp Evrak Geçmişi okunuyor (salt okunur)…"; takipDetayRender(ctx);
        const res = await kimdeOkuEbys(it0.evrakNo);
        ctx.busy = false;
        if (res.ok && res.kapatildi) ctx.kapatildi = res.kapatildi; // v1.0.4
        if (res.ok && !res.kimde) ctx.gecmisYok = true;
        ctx.durum = kimdeSonucMetni(res);
        takipDetayRender(ctx);
    }
    function takipItemEl(it, today, done) {
        const s = TK.statusOf(it.sonTarih, today);
        const el = document.createElement("div");
        el.className = "ebys-takip-item" + (done ? " takip-done" : "");
        el.setAttribute("data-id", it.id);
        el.setAttribute("data-level", done ? "done" : s.level);
        el.setAttribute("role", "button"); el.setAttribute("tabindex", "0"); el.setAttribute("title", "Tıklayın: son tarih takvimi, evrak bilgisi ve kimde (Gereği)"); // v1.0.2
        const col = done ? "#64748B" : s.color;
        el.style.cssText = "background:#2D3D63; border:1px solid " + (done ? "#4B5D7A" : "rgba(0,240,255,0.2)") + "; border-left:4px solid " + col + "; border-radius:10px; padding:8px; display:flex; flex-direction:column; gap:4px; cursor:pointer; pointer-events:auto;" + (done ? " opacity:0.75;" : "");
        el.innerHTML =
            '<div style="display:flex; justify-content:space-between; gap:6px; align-items:center;">'
            + '<span class="takip-no" style="color:#00F0FF; font-weight:bold; font-size:10.5px;">' + (it.evrakNo ? "📄 " + escapeHtml(it.evrakNo) : "✍️ Elle eklendi") + '</span>'
            + '<span class="takip-cd" style="font-weight:800; font-size:11px; padding:2px 7px; border-radius:8px; background:#1F2D4D; border:1px solid ' + col + '; color:' + col + '; white-space:nowrap;">' + escapeHtml(done ? "✅ Tamamlandı" : s.label) + '</span></div>'
            + '<div class="takip-konu" style="color:#F8FAFC; font-size:11.5px; line-height:1.3;">📌 ' + escapeHtml(it.konu) + '</div>'
            + '<div class="takip-meta" style="color:#A9B6CA; font-size:10.5px;">' + [it.gonderen ? "🏛️ " + escapeHtml(it.gonderen) : "", "👤 Kimde: " + (it.kimde ? "<b class=\"takip-kimde\" style=\"color:#E2E8F0;\">" + escapeHtml(it.kimde) + "</b>" + (it.kimdeKaynak === "gecmis" ? " (Gereği)" : it.kimdeKaynak === "ebys" ? " (EBYS)" : " (elle)") : "<span class=\"takip-kimde\">Bilinmiyor</span>"), "📅 Son tarih: <b style=\"color:#E2E8F0;\">" + escapeHtml(TK.fmtTr(it.sonTarih)) + "</b>" + (it.tarihElle ? " ✏️" : ""), "İlk görülme: " + escapeHtml(TK.fmtTr(it.ilkGorulme))].filter(Boolean).join(" · ") + '</div>'
            + (it.not ? '<div class="takip-not" style="color:#FDE68A; font-size:10.5px;">📝 ' + escapeHtml(it.not) + '</div>' : '')
            + '<div style="display:flex; gap:4px; flex-wrap:wrap;">'
            + '<button class="btn-takip-detay" title="Takvim, evrak bilgisi ve kimde (Gereği)" style="flex:1; ' + TK_BTN + ' font-size:10px; padding:4px; color:#93C5FD; border-color:#60A5FA;">📅 Ayrıntı</button>'
            + '<button class="btn-takip-wapp" title="WhatsApp ile paylaş (otomatik gönderilmez)" style="flex:1; ' + TK_BTN + ' font-size:10px; padding:4px; color:#86EFAC; border-color:#22C55E;">💬 WhatsApp</button>'
            + (done ? '<button class="btn-takip-reopen" style="flex:1; ' + TK_BTN + ' font-size:10px; padding:4px;">↩️ Yeniden aç</button>'
                : '<button class="btn-takip-done" style="flex:1; background:#15803D; color:white; border:none; padding:4px; border-radius:8px; font-size:10px; font-weight:bold; cursor:pointer;">✅ Tamamlandı</button>'
                + '<button class="btn-takip-edit" style="flex:1; ' + TK_BTN + ' font-size:10px; padding:4px;">✏️ Düzenle</button>')
            + '<button class="btn-takip-del" style="flex:0 0 auto; background:#7F1D1D; color:#FECACA; border:none; padding:4px 8px; border-radius:8px; font-size:10px; cursor:pointer;">🗑️ Sil</button></div>';
        // v1.0.2: satıra (düğmeler/giriş alanları dışında) tıklama ya da Enter/Boşluk → takvim ve ayrıntı penceresi; "📅 Ayrıntı" düğmesi de aynısını açar
        const openDet = () => { openTakipDetaySafe(it); };
        el.addEventListener("click", (ev) => { const tg = ev.target; if (tg && tg.closest && tg.closest("button, input, select, textarea, a, label, .takip-edit-form")) return; openDet(); });
        el.addEventListener("keydown", (ev) => { if ((ev.key === "Enter" || ev.key === " ") && ev.target === el) { ev.preventDefault(); openDet(); } });
        el.querySelector(".btn-takip-detay").onclick = (ev) => { ev.stopPropagation(); openDet(); };
        bindWaPaylasBtn(el.querySelector(".btn-takip-wapp"), it);
        const upd = (patch, okMsg) => { const r = TK.updateItem(getTakip(), it.id, patch, takipToday()); if (r.error) { takipMsg("⚠️ " + r.error, "warn"); return false; } saveTakip(r.store); if (okMsg) takipMsg(okMsg); return true; };
        if (done) el.querySelector(".btn-takip-reopen").onclick = () => upd({ durum: "acik" }, "↩️ Yeniden açıldı.");
        else {
            el.querySelector(".btn-takip-done").onclick = () => upd({ durum: "tamamlandi" }, "✅ Tamamlandı olarak işaretlendi (hatırlatma gönderilmez).");
            el.querySelector(".btn-takip-edit").onclick = () => { takipEditId = takipEditId === it.id ? null : it.id; renderTakipTab(); };
        }
        el.querySelector(".btn-takip-del").onclick = () => {
            
            saveTakip(TK.removeItem(getTakip(), it.id, true).store);
            takipMsg("🗑️ Takipten silindi.");
        };
        if (!done && takipEditId === it.id) {
            const f = document.createElement("div");
            f.className = "takip-edit-form";
            f.style.cssText = "display:flex; flex-direction:column; gap:4px; background:#1F2D4D; padding:6px; border-radius:8px;";
            f.innerHTML = '<label style="font-size:10.5px; color:#A9B6CA !important;">Konu<input class="te-konu" type="text" maxlength="200" style="width:100%; ' + TK_IN + '"></label>'
                + '<label style="font-size:10.5px; color:#A9B6CA !important;">Son tarih (yanlış okunduysa düzeltin)<input class="te-tarih" type="date" style="width:100%; ' + TK_IN + '"></label>'
                + '<label style="font-size:10.5px; color:#A9B6CA !important;">Kimde (EBYS\'den okunamazsa elle yazın; EBYS\'ye yazılmaz)<input class="te-kimde" type="text" maxlength="120" placeholder="memur / müdür yardımcısı / birim" style="width:100%; ' + TK_IN + '"></label>'
                + '<label style="font-size:10.5px; color:#A9B6CA !important;">Not<input class="te-not" type="text" maxlength="300" style="width:100%; ' + TK_IN + '"></label>'
                + '<div style="display:flex; gap:4px;"><button class="te-save" style="flex:1; background:#10B981; color:white; border:none; padding:5px; border-radius:8px; font-weight:bold; cursor:pointer; font-size:10.5px;">💾 Kaydet</button><button class="te-cancel" style="flex:1; ' + TK_BTN + ' font-size:10.5px; padding:5px;">Vazgeç</button></div>';
            f.querySelector(".te-konu").value = it.konu; f.querySelector(".te-tarih").value = it.sonTarih; f.querySelector(".te-not").value = it.not || ""; f.querySelector(".te-kimde").value = it.kimde || "";
            f.querySelector(".te-save").onclick = () => { if (upd({ konu: f.querySelector(".te-konu").value, sonTarih: f.querySelector(".te-tarih").value, not: f.querySelector(".te-not").value, kimde: f.querySelector(".te-kimde").value }, "💾 Kaydedildi.")) { takipEditId = null; renderTakipTab(); } };
            f.querySelector(".te-cancel").onclick = () => { takipEditId = null; renderTakipTab(); };
            el.appendChild(f);
        }
        return el;
    }
    function takipPreviewHtml(st, today) {
        const first = TK.sortForList(TK.openItems(st), today)[0];
        const sample = first || { konu: "Örnek: Okul güvenliği bilgi formu", sonTarih: today, evrakNo: "E-00000000-000-000000" };
        const t = TK.notificationText(sample, today);
        return '<div style="font-size:10.5px; color:#A9B6CA; margin-bottom:4px;">Bildirim önizlemesi' + (first ? " (listedeki ilk evrak)" : " (örnek)") + ':</div>'
            + '<div class="takip-notif-preview" style="background:#F8FAFC; color:#0F172A; border-radius:10px; padding:10px; display:flex; gap:10px; box-shadow:0 4px 14px rgba(0,0,0,.35); font-family:\'Segoe UI\',sans-serif;">'
            + '<div style="font-size:26px; line-height:1;">📅</div><div style="min-width:0;"><div style="font-size:10px; color:#475569;">Google Chrome · Evrak Asistanı</div>'
            + '<div class="tnp-title" style="font-weight:700; font-size:12px;">' + escapeHtml(t.title) + '</div><div class="tnp-msg" style="font-size:11.5px;">' + escapeHtml(t.message) + '</div>'
            + '<div class="tnp-ctx" style="font-size:10.5px; color:#475569;">' + escapeHtml(t.contextMessage) + '</div></div></div>';
    }
    function renderTakipSettings(box, st, today) {
        const s = getTakipSettings();
        const thLabels = { 5: "5 iş günü kala", 3: "3 iş günü kala", 2: "2 iş günü kala", 1: "1 iş günü kala", 0: "Son gün" };
        box.innerHTML = '<div style="font-weight:800; color:#FDE68A; font-size:11.5px;">🔔 Bildirim ve takip ayarları</div>'
            + '<label style="color:#E2E8F0 !important; display:flex; gap:6px; align-items:flex-start;"><input type="checkbox" id="takip-set-auto"><span>Son tarihi belirlenen evrakları <b>otomatik takibe al</b> (kapalıysa evrak kartında <b>📅 Takibe al</b> düğmesi çıkar)</span></label>'
            + '<label style="color:#E2E8F0 !important; display:flex; gap:6px; align-items:flex-start;"><input type="checkbox" id="takip-set-notify"><span><b>Masaüstü bildirimleri</b> (açık takip kaydı varken)</span></label>'
            + '<div id="takip-set-ths" style="display:flex; flex-wrap:wrap; gap:4px 10px; padding-left:20px;">'
            + TK.THRESHOLD_CHOICES.map(n => '<label style="color:#E2E8F0 !important; white-space:nowrap;"><input type="checkbox" class="takip-th" value="' + n + '"> ' + thLabels[n] + '</label>').join("")
            + '<label style="color:#E2E8F0 !important; white-space:nowrap;"><input type="checkbox" id="takip-set-overdue"> Süresi geçince (günde 1 kez)</label></div>'
            + '<label style="color:#E2E8F0 !important; padding-left:20px;">Günlük bildirim saati: <input type="time" id="takip-set-time" style="' + TK_IN + '"> <span style="color:#A9B6CA;">(İstanbul saati)</span></label>'
            + '<label style="color:#E2E8F0 !important; display:flex; gap:6px; align-items:flex-start;"><input type="checkbox" id="takip-set-xlsx-offer"><span><b>Otomatik indir:</b> yeni günlü evrak takibe eklenince güncel Excel dosyasını tek tıkla indirmeyi öner (dosya siz tıklamadan yazılmaz)</span></label>' // NEW (v3.5.2)
            + '<div style="display:flex; gap:6px; align-items:center;"><button id="btn-takip-test" style="' + TK_BTN + '">🔔 Test bildirimi gönder</button><span id="takip-test-res" style="font-size:10.5px; color:#A9B6CA;"></span></div>'
            + '<div id="takip-preview-box">' + takipPreviewHtml(st, today) + '</div>'
            + '<div class="takip-help" style="font-size:10.5px; color:#CBD5E1; line-height:1.45; background:#1F2D4D; padding:6px 8px; border-radius:8px;">ℹ️ <b>Chrome açık olmalıdır.</b> Bildirimler EBYS sekmesi açık olmasa da Chrome çalıştığı sürece gelir: Chrome açılınca, saatte bir ve seçtiğiniz günlük saatte kontrol edilir (günlük saatten önce bildirim gösterilmez). Chrome tamamen kapalıyken bildirim gelmez; Chrome\'u açtığınızda kaçırılan hatırlatmalar gösterilir. Pencereleri kapattığınızda da çalışması için Chrome Ayarlar › Sistem › <b>"Google Chrome kapatıldığında arka plan uygulamalarını çalıştırmaya devam et"</b> seçeneğini açabilirsiniz. Windows\'ta Ayarlar › Sistem › Bildirimler\'de Google Chrome\'a izin verin; "Rahatsız etmeyin" açıksa bildirim görünmez. Bildirimde yalnızca <b>konu, son tarih ve evrak sayısı</b> bulunur; her eşik her evrak için bir kez, süresi geçmiş evrak için günde bir kez bildirilir. Tıklayınca EBYS açılır.</div>'
            + '<div id="takip-bg-status" style="font-size:10px; color:#94A3B8;"></div>';
        const q = (id) => box.querySelector("#" + id);
        q("takip-set-auto").checked = s.autoAdd;
        q("takip-set-notify").checked = s.notify.enabled;
        box.querySelectorAll(".takip-th").forEach(c => { c.checked = s.notify.thresholds.includes(+c.value); c.disabled = !s.notify.enabled; });
        q("takip-set-overdue").checked = s.notify.overdue; q("takip-set-overdue").disabled = !s.notify.enabled;
        q("takip-set-time").value = s.notify.dailyTime; q("takip-set-time").disabled = !s.notify.enabled;
        const collect = () => ({ autoAdd: q("takip-set-auto").checked, notify: { enabled: q("takip-set-notify").checked, thresholds: Array.from(box.querySelectorAll(".takip-th")).filter(c => c.checked).map(c => +c.value), overdue: q("takip-set-overdue").checked, dailyTime: q("takip-set-time").value || "08:30" } });
        const onChange = () => { saveTakipSettings(collect()); takipMsg("💾 Ayarlar kaydedildi."); renderTakipTab(); };
        box.querySelectorAll("input").forEach(i => { i.onchange = onChange; });
        q("takip-set-xlsx-offer").checked = takipXlsxSettings().autoOffer; // NEW (v3.5.2): ayrı anahtar (takip ayarları bilinmeyen alanları atar)
        q("takip-set-xlsx-offer").onchange = () => { extStoreSet(TK_XLSX_KEY, { autoOffer: q("takip-set-xlsx-offer").checked }); takipMsg("💾 Ayarlar kaydedildi."); };
        q("btn-takip-test").onclick = async () => {
            const res = q("takip-test-res");
            res.textContent = "⏳ Gönderiliyor...";
            const r = await takipBg("ebys-takip-test");
            res.textContent = r && r.ok ? (r.permission === "denied" ? "⚠️ Chrome bu eklentinin bildirimlerine izin vermiyor (Chrome/Windows bildirim ayarlarını kontrol edin)." : "✅ Test bildirimi gönderildi. Görmediyseniz Windows bildirim ayarlarını kontrol edin.")
                : "⚠️ Arka plan hizmetine ulaşılamadı (eklentiyi chrome://extensions sayfasından yeniden yükleyin).";
        };
        takipBg("ebys-takip-status").then(r => {
            const el = q("takip-bg-status");
            if (!el) return;
            if (!r) { el.textContent = "Arka plan hizmeti: yanıt yok."; return; }
            const d = (r.alarms || []).find(a => /gunluk/.test(a.name));
            el.textContent = "Arka plan hizmeti: " + (r.active ? "hatırlatmalar etkin" : "hatırlatma yok (bildirim kapalı ya da açık kayıt yok)") + (d ? " · sonraki günlük kontrol: " + new Date(d.scheduledTime).toLocaleString("tr-TR", { timeZone: "Europe/Istanbul", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "") + (r.permission === "denied" ? " · ⚠️ bildirim izni kapalı" : "");
        });
    }
    function renderTakipTab() {
        const c = document.getElementById("ebys-takip-container");
        if (!c) return;
        const st = getTakip(), set = getTakipSettings(), today = takipToday();
        takipLastDay = today;
        const openAll = TK.sortForList(st.items.filter(x => x.durum === "acik"), today), done = st.items.filter(x => x.durum === "tamamlandi").sort((a, b) => b.sonTarih.localeCompare(a.sonTarih));
        const open = TK.filterByKimde(openAll, takipKimdeFilter);
        const kimdeRows = TK.summaryByKimde(st, today);
        c.innerHTML = '<div class="takip-intro" style="color:#A9B6CA; font-size:10.5px; line-height:1.4;">Son tarihi belirlenen evraklar (taramada EBYS <b>Miat</b> bilgisi olanlar; son tarihi yalnızca yazının içinde geçenler kartta 🔍 Nitelik / AÇ ➔ ile okununca) ' + (set.autoAdd ? "otomatik olarak" : "kartlardaki <b>📅 Takibe al</b> düğmesiyle") + ' bu listeye alınır. Kalan süre <b>iş günüyle</b> hesaplanır. <b>Kimde</b> bilgisi EBYS listesindeki havale/teslim alan alanından salt okunur; okunamazsa <b>bilinmiyor</b> görünür, ✏️ Düzenle ile yalnızca bu bilgisayarda atanır (EBYS tarafına yazılmaz).</div>'
            + '<div id="ebys-takip-kimde-sum" style="display:flex; flex-wrap:wrap; gap:6px;"></div>'
            + '<div style="display:flex; gap:6px; align-items:center; flex-wrap:wrap;"><label style="font-size:10.5px; color:#A9B6CA !important;">Kişiye göre süz <select id="takip-kimde-filter" style="' + TK_IN + '; max-width:100%;"></select></label></div>'
            + '<div style="display:flex; gap:6px; flex-wrap:wrap;">'
            + '<button id="btn-takip-add" style="flex:1; ' + TK_BTN + ' color:#86EFAC; border-color:#22C55E;">➕ Elle ekle</button>'
            + '<button id="btn-takip-csv" title="Excel\'de açılabilen CSV dosyası (UTF-8, ; ayraçlı)" style="flex:1; ' + TK_BTN + ' color:#6EE7B7; border-color:#10B981;">📊 CSV indir</button>'
            + '<button id="btn-takip-ics" title="Takvim dosyası: açık evraklar son tarihte tüm gün etkinlik, 3 gün ve 1 gün önce hatırlatma" style="flex:1; ' + TK_BTN + ' color:#93C5FD; border-color:#60A5FA;">📆 Takvime ekle (.ics)</button>'
            + '<button id="btn-takip-settings" style="flex:1; ' + TK_BTN + ' color:#FDE68A; border-color:#FBBF24;">🔔 Bildirim ayarları</button></div>'
            + '<div id="ebys-takip-row2" style="display:flex; gap:6px; flex-wrap:wrap;">' // NEW (v3.5.1)
            + '<button id="btn-takip-takvim" title="Aylık takvim: her günün evrakları renkli (kalan iş günü); yazdırılabilir" style="flex:1; ' + TK_BTN + ' color:#C4B5FD; border-color:#A78BFA;">🗓️ Takvim görünümü</button>'
            + '<button id="btn-takip-html" title="İnternetsiz açılan tek dosyalık takvim (evrak-takip-takvimi-YYYY-AA.html)" style="flex:1; ' + TK_BTN + ' color:#C4B5FD; border-color:#A78BFA;">📄 Takvim dosyası (.html)</button>'
            + '<button id="btn-takip-txt" title="Not Defteri ile açılan düz liste: tarih — kalan gün — evrak no — konu" style="flex:1; ' + TK_BTN + ' color:#E2E8F0;">📝 Not defteri (.txt)</button></div>'
            + '<div id="ebys-takip-row3" style="display:flex; gap:6px;"><button id="btn-takip-xlsx" title="Gerçek Excel dosyası (evrak-takip-YYYY-AA-GG.xlsx): renkli satırlar, sabit başlık, süzgeç" style="flex:1; background:#15803D; color:white; border:none; padding:7px; border-radius:10px; font-weight:bold; cursor:pointer; font-size:11.5px;">📗 Excel\'e indir (.xlsx)</button></div>' // NEW (v3.5.2)
            + '<div id="ebys-takip-form" style="display:none;"></div><div id="ebys-takip-settings" style="display:none;"></div><div id="ebys-takip-msg" style="display:none;"></div>'
            + '<div id="ebys-takip-pending" style="display:none;"></div><div id="ebys-takip-list" style="display:flex; flex-direction:column; gap:6px;"></div>'
            + '<button id="btn-takip-show-done" style="' + TK_BTN + ' font-weight:normal; color:#A9B6CA;"></button><div id="ebys-takip-done-list" style="display:none; flex-direction:column; gap:6px;"></div>';
        const q = (id) => c.querySelector("#" + id);
        const list = q("ebys-takip-list");
        if (!open.length) {
            const e = document.createElement("div");
            e.id = "ebys-takip-empty";
            e.style.cssText = "text-align:center; color:#94A3B8; padding:20px; border:1px dashed #4B5D7A; border-radius:12px; line-height:1.5;";
            e.textContent = takipKimdeFilter && openAll.length ? "Bu kişide açık evrak yok. Süzgeci 'Tümü' yapın." : (st.items.length ? "Açık günlü evrak yok. 🎉" : "Takip listesi boş. Taramada EBYS'de miadı (Miat) girilmiş evraklar buraya kendiliğinden eklenir. Son tarihi yalnızca yazının içinde geçen evraklar için kartta 🔍 Nitelik ya da AÇ ➔ düğmesine basın; ➕ Elle ekle ile de ekleyebilirsiniz.");
            list.appendChild(e);
        } else open.forEach(it => list.appendChild(takipItemEl(it, today, false)));
        (function wireKimdeFilter() {
            const sel = q("takip-kimde-filter");
            if (sel) {
                const opts = [["", "Tümü (" + openAll.length + ")"]].concat(kimdeRows.map(r => [r.key, r.name + " — " + r.open + " açık" + (r.overdue ? ", " + r.overdue + " süresi geçen" : "")]));
                sel.innerHTML = opts.map(o => '<option value="' + escapeHtml(o[0]) + '">' + escapeHtml(o[1]) + "</option>").join("");
                sel.value = takipKimdeFilter;
                sel.onchange = () => { takipKimdeFilter = sel.value || ""; renderTakipTab(); };
            }
            const box = q("ebys-takip-kimde-sum");
            if (box && kimdeRows.length) {
                box.innerHTML = kimdeRows.map(r => {
                    const on = takipKimdeFilter === r.key;
                    return '<button type="button" class="kimde-chip" data-key="' + encodeURIComponent(r.key) + '" style="background:' + (on ? "#1E3A5F" : "#1F2D4D") + "; color:#E2E8F0; border:1px solid " + (on ? "#00F0FF" : "#56709A") + '; border-radius:999px; padding:3px 9px; font-size:10.5px; cursor:pointer;">' + escapeHtml(r.name) + " · " + r.open + " açık" + (r.overdue ? ' · <b style="color:#F87171;">' + r.overdue + " süresi geçen</b>" : "") + "</button>";
                }).join("") + (takipKimdeFilter ? '<button type="button" class="kimde-chip-all" style="background:#1F2D4D; color:#93C5FD; border:1px solid #60A5FA; border-radius:999px; padding:3px 9px; font-size:10.5px; cursor:pointer;">Tümü</button>' : "");
                box.querySelectorAll(".kimde-chip").forEach(b => { b.onclick = () => { const k = decodeURIComponent(b.getAttribute("data-key") || ""); takipKimdeFilter = (takipKimdeFilter === k) ? "" : k; renderTakipTab(); }; });
                const all = box.querySelector(".kimde-chip-all"); if (all) all.onclick = () => { takipKimdeFilter = ""; renderTakipTab(); };
            }
        })();
        const sd = q("btn-takip-show-done");
        sd.textContent = (takipShowDone ? "▾ Tamamlananları gizle" : "▸ Tamamlananları göster") + " (" + done.length + ")";
        sd.style.display = done.length ? "block" : "none";
        sd.onclick = () => { takipShowDone = !takipShowDone; renderTakipTab(); };
        const dl = q("ebys-takip-done-list");
        if (takipShowDone && done.length) { dl.style.display = "flex"; done.forEach(it => dl.appendChild(takipItemEl(it, today, true))); }
        // son taramada son tarihi bilinen ama takipte olmayan evraklar (ör. v3.4'ten kalan kayıtlı son tarihler)
        const pend = scannedList.filter(d => d.docNo && getDeadline(d) && getDeadline(d).iso && !TK.findByNo(st, d.docNo) && !st.dismissed.includes(d.docNo));
        if (pend.length) {
            const p = q("ebys-takip-pending");
            p.style.cssText = "display:flex; gap:6px; align-items:center; background:#1E3A5F; border:1px solid #60A5FA; color:#DBEAFE; padding:6px 8px; border-radius:10px; font-size:10.5px;";
            p.innerHTML = '<span style="flex:1;">Son taramada son tarihi bilinen <b>' + pend.length + '</b> evrak takipte değil.</span><button id="btn-takip-add-pending" style="' + TK_BTN + ' font-size:10px; padding:3px 8px;">📅 Hepsini takibe al</button>';
            p.querySelector("#btn-takip-add-pending").onclick = () => { let s2 = getTakip(); pend.forEach(d => { s2 = TK.upsertFromDoc(s2, takipRecOf(d), { force: true, today: takipToday() }).store; }); saveTakip(s2); takipMsg("📅 " + pend.length + " evrak takibe alındı."); };
        }
        // elle ekleme formu
        const form = q("ebys-takip-form");
        q("btn-takip-add").onclick = () => { takipFormOpen = !takipFormOpen; renderTakipTab(); };
        if (takipFormOpen) {
            form.style.cssText = "display:flex; flex-direction:column; gap:4px; background:#1F2D4D; border:1px solid #22C55E; padding:8px; border-radius:10px;";
            form.innerHTML = '<div style="font-weight:800; color:#86EFAC; font-size:11px;">➕ Elle günlü evrak ekle</div>'
                + '<input id="takip-new-konu" type="text" maxlength="200" placeholder="Konu (zorunlu)" style="' + TK_IN + '">'
                + '<div style="display:flex; gap:4px;"><label style="flex:1; font-size:10.5px; color:#A9B6CA !important;">Son tarih<input id="takip-new-tarih" type="date" style="width:100%; ' + TK_IN + '"></label>'
                + '<label style="flex:1; font-size:10.5px; color:#A9B6CA !important;">Evrak sayısı (isteğe bağlı)<input id="takip-new-no" type="text" maxlength="80" style="width:100%; ' + TK_IN + '"></label></div>'
                + '<input id="takip-new-kimde" type="text" maxlength="120" placeholder="Kimde (isteğe bağlı; EBYS\'ye yazılmaz)" style="' + TK_IN + '">'
                + '<input id="takip-new-not" type="text" maxlength="300" placeholder="Not (isteğe bağlı)" style="' + TK_IN + '">'
                + '<div style="display:flex; gap:4px;"><button id="btn-takip-new-save" style="flex:1; background:#10B981; color:white; border:none; padding:6px; border-radius:8px; font-weight:bold; cursor:pointer; font-size:11px;">💾 Ekle</button><button id="btn-takip-new-cancel" style="flex:1; ' + TK_BTN + '">Vazgeç</button></div>';
            form.querySelector("#btn-takip-new-cancel").onclick = () => { takipFormOpen = false; renderTakipTab(); };
            form.querySelector("#btn-takip-new-save").onclick = () => {
                const r = TK.addManual(getTakip(), { konu: form.querySelector("#takip-new-konu").value, sonTarih: form.querySelector("#takip-new-tarih").value, evrakNo: form.querySelector("#takip-new-no").value, not: form.querySelector("#takip-new-not").value, kimde: form.querySelector("#takip-new-kimde").value }, takipToday());
                if (r.error) { takipMsg("⚠️ " + r.error, "warn"); return; }
                takipFormOpen = false; saveTakip(r.store); takipMsg("✅ Eklendi: " + TK.clean(r.item.konu, 60));
            };
        }
        // ayarlar
        const sb = q("ebys-takip-settings");
        q("btn-takip-settings").onclick = () => { takipSettingsOpen = !takipSettingsOpen; renderTakipTab(); };
        if (takipSettingsOpen) {
            sb.style.cssText = "display:flex; flex-direction:column; gap:6px; background:#26355A; border:1px solid #FBBF24; padding:8px; border-radius:10px; font-size:11px; color:#E2E8F0;";
            renderTakipSettings(sb, st, today);
        }
        // indirmeler
        q("btn-takip-xlsx").onclick = () => { // NEW (v3.5.2)
            const f = takipDownloadXlsx();
            if (!f) { takipMsg("⚠️ Listede evrak yok.", "warn"); return; }
            takipMsg("📗 " + f + " indirildi (Excel / LibreOffice ile açılır).");
        };
        q("btn-takip-csv").onclick = () => {
            const s2 = getTakip(), t = takipToday();
            if (!s2.items.length) { takipMsg("⚠️ Listede evrak yok.", "warn"); return; }
            takipDownload(TK.fileName("csv", t), TK.buildCsv(s2, t), "text/csv;charset=utf-8");
            takipMsg("📊 " + TK.fileName("csv", t) + " indirildi (Excel ile açabilirsiniz).");
        };
        q("btn-takip-ics").onclick = () => {
            const s2 = getTakip(), t = takipToday();
            if (!TK.openItems(s2).length) { takipMsg("⚠️ Takvime eklenecek açık evrak yok.", "warn"); return; }
            takipDownload(TK.fileName("ics", t), TK.buildIcs(s2, t, Date.now(), getTakipSettings().notify.dailyTime), "text/calendar;charset=utf-8");
            takipMsg("📆 " + TK.fileName("ics", t) + " indirildi: dosyayı açarak Outlook / Google Takvim / telefon takviminize ekleyebilirsiniz.");
        };
        // NEW (v3.5.1): 🗓️ takvim görünümü / takvim dosyası / not defteri
        q("btn-takip-takvim").onclick = () => {
            let url = "";
            try { url = chrome.runtime.getURL("takvim.html"); } catch(e) {}
            if (!url) { takipMsg("⚠️ Takvim sayfası açılamadı; 📄 Takvim dosyası (.html) düğmesiyle indirip açabilirsiniz.", "warn"); return; }
            try { window.open(url, "_blank", "noopener"); } catch(e) {}
            takipMsg("🗓️ Takvim yeni sekmede açıldı (liste değiştikçe kendiliğinden güncellenir).");
        };
        q("btn-takip-html").onclick = () => {
            const s2 = getTakip(), t = takipToday();
            if (!s2.items.length) { takipMsg("⚠️ Listede evrak yok.", "warn"); return; }
            takipDownload(TV.htmlFileName(t), TV.standaloneHtml(s2, t, Date.now()), "text/html;charset=utf-8");
            takipMsg("📄 " + TV.htmlFileName(t) + " indirildi: çift tıklayınca internetsiz açılır; yazdırabilir ya da PDF olarak kaydedebilirsiniz.");
        };
        q("btn-takip-txt").onclick = () => {
            const s2 = getTakip(), t = takipToday();
            if (!s2.items.length) { takipMsg("⚠️ Listede evrak yok.", "warn"); return; }
            takipDownload(TK.fileName("txt", t), TV.notepadText(s2, t, Date.now()), "text/plain;charset=utf-8");
            takipMsg("📝 " + TK.fileName("txt", t) + " indirildi (Not Defteri ile açılır).");
        };
    }
    // v1.0.3 KÖK NEDEN DÜZELTMESİ: sekme düğmelerinin onclick'i yalnız bindHavaleTab() içinde bağlanıyordu; Müdür Paketi'nde Havale kaldırılırken bu çağrı da silindi
    // → "📅 Günlü Takip" sekmesine tıklamak hiçbir şey yapmıyordu. Havale kodu geri getirilmeden yalnızca sekme geçişi bağlanır.
    function bindTabButtons() {
        try {
            document.querySelectorAll(".ebys-tab-btn").forEach(b => { b.onclick = () => { try { activeTab = b.getAttribute("data-tab") || "gelen"; applyActiveTab(); } catch (e) { console.warn("[Evrak Asistanı – Müdür Paketi] Sekme açılamadı:", e); try { showToast("⚠️ Sekme açılamadı: " + ((e && e.message) || e), "error"); } catch (x) {} } }; });
            applyActiveTab();
        } catch (e) { console.warn("[Evrak Asistanı – Müdür Paketi] Sekmeler bağlanamadı:", e); }
    }
    function bindTakipTab() {
        refreshTakipUi();
        if (!bindTakipTab.started) {
            bindTakipTab.started = true;
            setInterval(() => { if (takipToday() !== takipLastDay) refreshTakipUi(); }, 60000); // gün değişince geri sayım yenilenir
            try { if (extStorage && chrome.storage.onChanged) chrome.storage.onChanged.addListener((ch, area) => { if ((!area || area === "local") && (TK.STORE_KEY in ch || TK.SETTINGS_KEY in ch)) setTimeout(refreshTakipUi, 0); }); } catch(e) {}
        }
    }
    function takipDiagLine(bg) {
        const c = TK.counts(getTakip(), takipToday()), s = getTakipSettings();
        return "açık=" + c.open + " (süresi geçen=" + c.overdue + ", ≤3 iş günü=" + c.soon + "), tamamlanan=" + c.done + ", elle eklenen=" + c.manual + ", otomatik ekleme=" + (s.autoAdd ? "açık" : "kapalı")
            + ", bildirim=" + (s.notify.enabled ? "açık" : "kapalı") + ", eşikler=" + (s.notify.thresholds.map(n => n === 0 ? "son gün" : n).join("/") || "-") + (s.notify.overdue ? "/süresi geçince" : "") + ", saat=" + s.notify.dailyTime
            + ", arka plan=" + (bg ? (bg.active ? "etkin" : "beklemede") + ", alarm=" + (bg.alarms || []).length + ", izin=" + (bg.permission || "-") : "yanıt yok");
    }
    // =========================================================================
    // NEW (v3.5.2): TAM OTOMATİK HAVALE SIRASI — eklenti her evrak için EBYS havale formunu kurallara göre DOLDURUR;
    // EBYS'nin son gönderme düğmesine ('Teslim Al Gönder') ASLA basmaz. Kullanıcı her evrakı kendisi gönderir; gönderim görülünce sıradaki doldurulur.
    // Toplu gönderim yoktur. Doldurulan/gönderilen her evrak bu bilgisayarda günlüğe yazılır (görüntüle / CSV / Excel).
    // =========================================================================
    const HQ_LOG_KEY = "ebys_havale_log_v1", HQ_SET_KEY = "ebys_havale_auto_v1", HQ_LOG_MAX = 500;
    const hq = { on: false, list: [], i: 0, phase: "idle", d: null, plan: null, status: null, sendClicked: false, snapshot: null, timer: null, stats: { sent: 0, skipped: 0 } };
    function hqSettings() { const v = extStoreGet(HQ_SET_KEY); return { mudurBilgi: !(isPlainObject(v) && v.mudurBilgi === false) }; }
    function hqLog() { const v = extStoreGet(HQ_LOG_KEY); return Array.isArray(v) ? v.filter(isPlainObject) : []; }
    function hqLogWrite(entry) {
        const list = hqLog();
        const i = entry.id ? list.findIndex(x => x.id === entry.id) : -1;
        if (i >= 0) list[i] = Object.assign(list[i], entry); else list.push(Object.assign({ id: "h" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6) }, entry));
        while (list.length > HQ_LOG_MAX) list.shift();
        extStoreSet(HQ_LOG_KEY, list);
        return i >= 0 ? list[i] : list[list.length - 1];
    }
    const hqIsMudur = p => { const pn = HC.fold(getOkulProfil().mudur || "").replace(/\s+/g, " ").trim(); if (pn && HC.fold(p.name || "").replace(/\s+/g, " ").trim() === pn) return true; const f = HC.fold(p.title || "").replace(/[^a-z ]/g, " ").replace(/\s+/g, " ").trim(); return /\bmudur(u)?\b/.test(f) && !/yard|yrd/.test(f); }; // v3.6.36: gevşek
    const hqFindPerson = label => (havalePeople.people || []).find(p => normName(personLabel(p)) === normName(label)) || null;
    // Gereği / Bilgi planı: kartta elle değiştirdiğiniz seçim > kural önerisi; müdür her zaman Bilgi
    function hqPlan(d) {
        const out = { sels: [], sure: true, notes: [], source: "kural" };
        const st = havalePick[d.key] || {}, auto = havaleAutoSel[d.key] || {};
        const edited = Object.keys(st).length && JSON.stringify(Object.keys(st).sort().map(k => k + st[k])) !== JSON.stringify(Object.keys(auto).sort().map(k => k + auto[k]));
        const add = (label, v) => { const p = hqFindPerson(label); if (!p) { out.notes.push("'" + label + "' kişi listesinde yok"); out.sure = false; return; } if (out.sels.some(s => normName(personLabel(s)) === normName(personLabel(p)))) return; out.sels.push({ name: p.name, title: p.title || "", v: v }); };
        if (edited) {
            out.source = "kartta sizin seçiminiz";
            Object.keys(st).forEach(l => add(l, st[l]));
        } else {
            const res = computeSuggestion(d);
            if (res.gerek) add(res.gerek.label, "G");
            else if (hlSuggest(d)) { // NEW (v3.6.28): kural eşleşmedi → geçmişten öneri (yine Teslim Al Gönder'e siz basarsınız)
                const L = hlSuggest(d);
                out.sure = false; out.source = HL_LABEL;
                add(L.gerek[0], "G"); L.bilgi.forEach(b => add(b, "B"));
                out.notes.push("kural eşleşmedi; geçmiş havaleden önerildi");
            }
            else {
                out.sure = false;
                const c = (res.candidates || []).find(x => x.resolved && x.label);
                if (c) { add(c.label, "G"); out.notes.push(res.reason === "tie" ? "iki kural eşit puan aldı" : "eşik altında en iyi aday"); }
                else out.notes.push(res.reason === "norules" ? "havale kuralı yok" : "Gereği için uygun kişi bulunamadı");
            }
            (res.bilgi || []).forEach(b => add(b.label, "B"));
            if (res.gerek) { const L = hlSuggest(d); if (L && L.gerek[0] !== res.gerek.label) out.learnHint = "🎓 Geçen sefer Gereği: " + L.gerek[0] + " (kuraldan farklı; isterseniz kartta değiştirin)"; }
        }
        if (hqSettings().mudurBilgi) {
            const m = (havalePeople.people || []).find(hqIsMudur);
            if (m) {
                const ex = out.sels.find(s => normName(personLabel(s)) === normName(personLabel(m)));
                if (ex && ex.v === "G") { ex.v = "B"; out.sure = false; out.notes.push("müdür Gereği önerilmişti; Bilgi yapıldı, Gereği kişisini kontrol edin"); }
                else if (!ex) out.sels.push({ name: m.name, title: m.title || "", v: "B" });
                else ex.v = "B";
            }
        }
        if (!out.sels.some(s => s.v === "G")) out.sure = false;
        return out;
    }
    const hqLabels = (sels, v) => sels.filter(s => s.v === v).map(personLabel);
    async function hqCancelForm() { // sıradan çıkarken açık formu işlem yapmadan kapat (Vazgeç; gönderim değildir)
        if (isQuickOpen()) { closeQuickDialog(); await waitFor(() => !isQuickOpen() && !isAjaxBusy(), 4000, 120); }
        if (isHavaleFormOpen()) { const v = findVazgecButton(); if (v) { v.click(); await waitFor(() => !isHavaleFormOpen() && !isAjaxBusy(), AJAX_TIMEOUT_MS, 150); } }
    }
    async function hqFillDoc(d) {
        const f = await havaleEnsureForm(d);
        if (!f.ok) return f;
        if (f.text && !havaleBody[d.key]) havaleBody[d.key] = f.text;
        if (kisiLovRows().length) return { ok: false, msg: "Formdaki 'Kişiye Havale' listesinde zaten kişi var. EBYS'de listeyi temizleyin ya da 'Vazgeç'e basıp 🔁 Yeniden doldur'a basın." };
        const q = await havaleOpenQuick();
        if (!q.ok) return q;
        savePeople(readQuickPeople());
        const plan = hqPlan(d);
        hq.plan = plan;
        if (!plan.sels.length) return { ok: false, plan: plan, msg: "Doldurulacak kişi belirlenemedi (" + (plan.notes.join("; ") || "kural yok") + "). Hızlı Seçim penceresi açık; bu evrakı EBYS'de elle havale edebilir ya da ⏭ Atla diyebilirsiniz." };
        const a = await havaleApplySelections(plan.sels);
        if (!a.ok) return { ok: false, plan: plan, msg: a.msg };
        const t = await quickTamamAndWait();
        if (!t.ok) return { ok: false, plan: plan, msg: t.msg };
        let vr = verifyKisiList(a.targets);
        if (!vr.ok && vr.extra && vr.extra.length) { const n = await removeKisiExtras(vr.extra); if (n) { await sleep(300); vr = verifyKisiList(a.targets); } }
        plan.targets = a.targets;
        return { ok: true, plan: plan, verify: vr };
    }
    function hqActive() { return hq.on; }
    async function hqStart() {
        if (hq.on) return;
        if (!havaleGuard()) return;
        const list = havaleList.filter(d => !(d.done || havaleDone[d.key]));
        if (!list.length) { showToast(havaleScanned ? "✔️ Havale edilecek evrak kalmadı." : "⚠️ Önce '📨 Teslim Bekleyenleri Tara' ile listeyi alın.", "warn"); return; }
        Object.assign(hq, { on: true, list: list, i: 0, phase: "idle", d: null, plan: null, status: null, stats: { sent: 0, skipped: 0 } });
        dbg("Havale sırası başladı:", list.length, "evrak");
        hqFill();
    }
    function hqStop(msg) {
        hqWatch(false);
        hq.on = false; hq.phase = "idle";
        renderHqBox();
        showToast(msg || "⏹ Havale sırası durduruldu. EBYS ekranı olduğu gibi bırakıldı.", "warn");
    }
    async function hqFill() {
        if (!hq.on) return;
        hqWatch(false);
        const d = hq.list[hq.i];
        if (!d) { const s = hq.stats; hq.on = false; hq.phase = "idle"; renderHqBox(); showToast("✅ Havale sırası bitti: " + s.sent + " gönderildi, " + s.skipped + " atlandı.", "ok"); return; }
        if (havaleBusy || havaleScanning || isScanningPages) { setTimeout(hqFill, 800); return; }
        hq.d = d; hq.plan = null; hq.phase = "filling"; hq.sendClicked = false; hq.snapshot = null;
        hq.status = { text: "⏳ EBYS'de dolduruluyor (evrak açılıyor, doğrulanıyor, Hızlı Seçim)…", kind: "info" };
        renderHqBox();
        havaleBusy = true;
        let r;
        try { r = await hqFillDoc(d); } catch(e) { console.error("[Evrak Asistanı] Havale sırası hatası:", e); r = { ok: false, msg: "Beklenmeyen hata: " + (e && e.message || e) }; }
        finally { havaleBusy = false; }
        if (!hq.on) return;
        if (!r.ok) {
            hq.phase = "error";
            hq.status = { text: "⚠️ " + r.msg + " — Teslim Al Gönder'e basılmadı.", kind: "warn" };
            setHavaleStatus(d, "⚠️ Otomatik doldurma: " + r.msg, "warn");
            showToast("⚠️ Havale doldurulamadı (" + (d.docNo || d.subject).slice(0, 40) + "):\n" + r.msg, "warn");
            renderHqBox();
            return;
        }
        const p = r.plan;
        hq.logId = hqLogWrite({ at: Date.now(), evrakNo: d.docNo || ("Kayıt No " + (d.kayitNo || "-")), konu: d.subject || "", gonderen: d.gonderen || "", gerek: hqLabels(p.targets, "G"), bilgi: hqLabels(p.targets, "B"), durum: "dolduruldu", emin: !!p.sure }).id;
        hq.phase = "waiting";
        hq.status = r.verify.ok
            ? { text: "✍️ Form dolduruldu. Kontrol edip EBYS'de 'Teslim Al Gönder'e siz basın; gönderim görülünce sıradaki evrak doldurulur.", kind: p.sure ? "ok" : "unsure" }
            : { text: "⚠️ Form dolduruldu ama denetim tutmadı: " + r.verify.msg + " EBYS'de düzeltip gönderin ya da ⏭ Atla.", kind: "warn" };
        setHavaleStatus(d, p.sure ? "✍️ Form otomatik dolduruldu; gönderme sizde." : "❓ Emin değilim — form dolduruldu, kişileri kontrol edin.", p.sure ? "ok" : "warn");
        renderHqBox();
        hqWatch(true);
    }
    // gönderim izleme: kullanıcının 'Teslim Al Gönder' tıklaması yakalanır (yalnızca izlenir), form kapanınca sonuç değerlendirilir
    function hqCapture(e) {
        if (!hq.on || hq.phase !== "waiting") return;
        const b = e.target && e.target.closest && e.target.closest("button, a");
        if (!b || isPanelEl(b)) return;
        const lab = ((b.getAttribute("aria-label") || "") + " " + (b.textContent || "")).replace(/\s+/g, " ");
        if (!/Teslim Al Gönder/.test(lab)) return;
        hq.sendClicked = true;
        hq.snapshot = readKisiList().map(x => ({ text: x.text, type: x.type }));
        dbg("Kullanıcı 'Teslim Al Gönder'e bastı:", hq.d && hq.d.key);
    }
    if (EXT_IS_TOP) document.addEventListener("click", hqCapture, true);
    function hqWatch(on) {
        clearInterval(hq.timer); hq.timer = null;
        if (!on) return;
        let closedAt = 0;
        hq.timer = setInterval(() => {
            if (!hq.on || hq.phase !== "waiting") { clearInterval(hq.timer); return; }
            if (isHavaleFormOpen() || isAjaxBusy()) { closedAt = 0; return; }
            const warn = Array.from(document.querySelectorAll(".ui-dialog")).find(x => !isPanelEl(x) && isVisible(x) && /kaydedilsin mi|değiştirdiniz/i.test(x.textContent || ""));
            if (warn) return; // EBYS sorusu: kullanıcı yanıtlar
            if (!closedAt) { closedAt = Date.now(); return; }
            if (Date.now() - closedAt < 900) return;
            clearInterval(hq.timer); hq.timer = null;
            const d = hq.d;
            const err = Array.from(document.querySelectorAll(".ui-messages-error, .ui-message-error, .ui-growl-image-error")).find(isVisible);
            const gone = isOnTeslim() && !findTeslimRow(d);
            if ((hq.sendClicked && !err) || gone) hqSent(d); else hqCancelled(d);
        }, 500);
    }
    function hqSent(d) {
        const snap = hq.snapshot || [];
        const pick = ty => snap.filter(x => x.type === ty).map(x => x.text.replace(/\s*(Gereği|Bilgi|Koordine)\s*$/, "").trim());
        const plan = hq.plan || { targets: [] };
        hqLogWrite({ id: hq.logId, at: Date.now(), durum: "gönderildi", gerek: snap.length ? pick("Gereği") : hqLabels(plan.targets || [], "G"), bilgi: snap.length ? pick("Bilgi") : hqLabels(plan.targets || [], "B") });
        hlRecord(d, snap.length ? pick("Gereği") : hqLabels(plan.targets || [], "G"), snap.length ? pick("Bilgi") : hqLabels(plan.targets || [], "B")); // NEW (v3.6.28)
        havaleDone[d.key] = { at: Date.now() };
        extStoreSet(HAVALE_DONE_KEY, havaleDone);
        d.done = true;
        const orig = havaleList.find(x => x.key === d.key); if (orig) orig.done = true;
        setHavaleStatus(d, "✅ Gönderildi (sizin onayınızla).", "ok");
        hq.stats.sent++; hq.i++;
        hq.phase = "advancing";
        hq.status = { text: "✅ Gönderildi. Sıradaki evrak dolduruluyor…", kind: "ok" };
        try { renderHavaleList(); } catch(e) {}
        renderHqBox();
        setTimeout(hqFill, 1200);
    }
    function hqCancelled(d) {
        hqLogWrite({ id: hq.logId, durum: "vazgeçildi" });
        hq.phase = "paused";
        hq.status = { text: "✖ Havale formu gönderilmeden kapandı. 🔁 Yeniden doldur, ⏭ Atla ya da ⏹ Durdur.", kind: "warn" };
        renderHqBox();
    }
    async function hqSkip() {
        if (!hq.on || hq.phase === "filling") return;
        hqWatch(false);
        await hqCancelForm();
        hq.stats.skipped++; hq.i++;
        hqFill();
    }
    async function hqRefill() {
        if (!hq.on || hq.phase === "filling") return;
        hqWatch(false);
        await hqCancelForm();
        hqFill();
    }
    function renderHqBox() {
        const box = document.getElementById("ebys-havale-auto");
        if (!box) return;
        const btn = (id, txt, bg) => '<button id="' + id + '" style="flex:1; background:' + bg + '; color:white; border:none; padding:6px; border-radius:8px; font-size:10.5px; font-weight:bold; cursor:pointer;">' + txt + "</button>";
        const nLog = hqLog().length;
        box.style.cssText = "display:block; background:#13233F; border:1px solid #3B82F6; border-radius:10px; padding:8px; font-size:11px; line-height:1.45; color:#E2E8F0;";
        if (!hq.on) {
            const n = havaleList.filter(d => !(d.done || havaleDone[d.key])).length;
            box.innerHTML = '<div style="font-weight:800; color:#93C5FD;">🤖 Tam otomatik havale</div>'
                + '<div style="color:#CBD5E1; font-size:10.5px;">Listedeki her evrak için kurallara göre Gereği/Bilgi EBYS formuna doldurulur. <b>Teslim Al Gönder\'e siz basarsınız</b>; gönderim görülünce sıradaki evrak doldurulur. Toplu gönderim yoktur.</div>'
                + '<label style="display:flex; gap:5px; align-items:center; margin:4px 0; font-size:10.5px; color:#E2E8F0 !important;"><input type="checkbox" id="hq-mudur-bilgi"' + (hqSettings().mudurBilgi ? " checked" : "") + "> Müdür her evrakta Bilgi olarak eklensin</label>"
                + '<label style="display:flex; gap:5px; align-items:center; margin:4px 0; font-size:10.5px; color:#E2E8F0 !important;"><input type="checkbox" id="hq-learn-on"' + (hlOn() ? " checked" : "") + '> 🎓 Havalede öğren <span style="color:#94A3B8;">(' + hlList().length + ' kayıt)</span> <button id="btn-hq-learn-clear" title="Öğrenilen havale kayıtlarını sil" style="margin-left:auto; background:#7F1D1D; color:white; border:none; padding:1px 6px; border-radius:6px; font-size:10px; cursor:pointer;">🗑️ Öğrenileni sil</button></label>'
                + '<div style="display:flex; gap:6px;">' + btn("btn-hq-start", "▶ Sırayı başlat (" + n + " evrak)", n ? "#2563EB" : "#475569") + btn("btn-hq-log", "📒 Havale günlüğü (" + nLog + ")", "#334155") + "</div>";
        } else {
            const d = hq.d || hq.list[hq.i] || {};
            const p = hq.plan;
            const st = hq.status || { text: "", kind: "info" };
            const col = { ok: ["#064E3B", "#A7F3D0", "#10B981"], warn: ["#78350F", "#FDE68A", "#F59E0B"], unsure: ["#713F12", "#FEF08A", "#EAB308"], info: ["#1E293B", "#CBD5E1", "#56709A"] }[st.kind] || ["#1E293B", "#CBD5E1", "#56709A"];
            let who = "";
            if (p) {
                const g = hqLabels(p.targets || p.sels, "G"), b = hqLabels(p.targets || p.sels, "B");
                who = '<div id="hq-plan" style="margin-top:4px;">'
                    + (p.sure ? "" : '<div id="hq-unsure" style="background:#FEF08A; color:#713F12; border-radius:6px; padding:3px 6px; font-weight:bold; margin-bottom:3px;">⚠️ Emin değilim' + (p.notes.length ? " — " + escapeHtml(p.notes.join("; ")) : "") + "</div>")
                    + '<div>🎯 Gereği: <b>' + (g.length ? escapeHtml(g.join(", ")) : "—") + "</b></div>"
                    + '<div>ℹ️ Bilgi: ' + (b.length ? escapeHtml(b.join(", ")) : "—") + "</div>"
                    + (p.learnHint ? '<div style="color:#C4B5FD; font-size:10px;">' + escapeHtml(p.learnHint) + "</div>" : "")
                    + '<div style="color:#94A3B8; font-size:10px;">Kaynak: ' + escapeHtml(p.source) + "</div></div>";
            }
            const next = hq.list.slice(hq.i + 1, hq.i + 4).map(x => "• " + escapeHtml((x.subject || "").slice(0, 50))).join("<br>");
            box.innerHTML = '<div style="display:flex; justify-content:space-between; align-items:center;"><b id="hq-progress" style="color:#93C5FD; font-size:12px;">Havale sırası: ' + Math.min(hq.i + 1, hq.list.length) + "/" + hq.list.length + "</b>"
                + '<span style="color:#94A3B8; font-size:10px;">✅ ' + hq.stats.sent + " · ⏭ " + hq.stats.skipped + "</span></div>"
                + '<div id="hq-doc" style="margin-top:3px;"><b>' + escapeHtml(d.docNo || ("Kayıt No " + (d.kayitNo || "-"))) + "</b> · " + escapeHtml(d.subject || "") + "</div>"
                + who
                + '<div id="hq-status" style="margin-top:5px; background:' + col[0] + "; color:" + col[1] + "; border:1px solid " + col[2] + '; padding:5px 7px; border-radius:8px; font-size:10.5px;">' + escapeHtml(st.text) + "</div>"
                + '<div style="display:flex; gap:5px; margin-top:6px;">' + btn("btn-hq-refill", "🔁 Yeniden doldur", "#2563EB") + btn("btn-hq-skip", "⏭ Atla", "#475569") + btn("btn-hq-stop", "⏹ Durdur", "#B91C1C") + btn("btn-hq-log", "📒", "#334155") + "</div>"
                + (next ? '<div style="color:#94A3B8; font-size:10px; margin-top:5px;">Sıradakiler:<br>' + next + "</div>" : "");
            const busy = hq.phase === "filling" || hq.phase === "advancing";
            ["btn-hq-refill", "btn-hq-skip"].forEach(id => { const b = box.querySelector("#" + id); if (b) { b.disabled = busy; b.style.opacity = busy ? "0.5" : "1"; } });
        }
        const on = (id, fn) => { const b = box.querySelector("#" + id); if (b) b.onclick = fn; };
        on("btn-hq-start", hqStart); on("btn-hq-log", openHqLog); on("btn-hq-stop", () => hqStop()); on("btn-hq-skip", hqSkip); on("btn-hq-refill", hqRefill);
        const mb = box.querySelector("#hq-mudur-bilgi");
        if (mb) mb.onchange = () => extStoreSet(HQ_SET_KEY, { mudurBilgi: mb.checked });
        const lo = box.querySelector("#hq-learn-on");
        if (lo) lo.onchange = () => extStoreSet(HL.SET_KEY, { on: lo.checked });
        const lc = box.querySelector("#btn-hq-learn-clear");
        if (lc) lc.onclick = (e) => { e.preventDefault(); { extStoreSet(HL.KEY, []); renderHqBox(); showToast("🗑️ Öğrenilen havale kayıtları silindi.", "ok"); } };
    }
    const hqStamp = ms => { const p = TK.istanbulParts(ms); return TK.fmtTr(p.iso) + " " + String(p.hh).padStart(2, "0") + ":" + String(p.mm).padStart(2, "0"); };
    function hqLogRows() { return hqLog().slice().reverse().map(x => [hqStamp(x.at || 0), x.evrakNo || "", x.konu || "", (x.gerek || []).join(", "), (x.bilgi || []).join(", "), x.durum || "", x.emin === false ? "Emin değilim" : ""]); }
    const HQ_COLS = ["Tarih-saat", "Evrak no", "Konu", "Gereği", "Bilgi", "Durum", "Not"];
    function hqExport(kind) {
        const rows = hqLogRows();
        if (!rows.length) { showToast("Günlük boş.", "warn"); return; }
        const day = TK.istanbulParts(Date.now()).iso;
        if (kind === "csv") {
            const q = v => '"' + String(v).replace(/"/g, '""') + '"';
            takipDownload("havale-gunlugu-" + day + ".csv", "\uFEFF" + [HQ_COLS].concat(rows).map(r => r.map(q).join(";")).join("\r\n"), "text/csv;charset=utf-8");
        } else {
            const widths = [17, 27, 45, 30, 40, 13, 14];
            const sheet = { name: "Havale günlüğü", cols: HQ_COLS.map((t, i) => ({ title: t, width: widths[i], kind: i >= 2 && i <= 4 ? "wrap" : "text" })), rows: rows.map(r => ({ level: r[5] === "gönderildi" ? "green" : r[6] ? "orange" : "none", cells: r })), freeze: true, filter: true, landscape: true, selected: true };
            takipDownload("havale-gunlugu-" + day + ".xlsx", XL.buildXlsx([sheet], { title: "Havale günlüğü", now: Date.now() }), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        }
    }
    function openHqLog() {
        document.querySelectorAll("#ebys-hq-log").forEach(x => x.remove());
        const m = document.createElement("div");
        m.id = "ebys-hq-log";
        m.setAttribute("role", "dialog");
        m.style.cssText = "position:fixed !important; inset:0 !important; background:rgba(0,0,0,0.5) !important; z-index:2147483647 !important; display:flex !important; align-items:center; justify-content:center; font-family:'Segoe UI', Tahoma, sans-serif;";
        const rows = hqLogRows();
        const b = (id, t, bg) => '<button id="' + id + '" style="background:' + bg + '; color:white; border:none; padding:6px 10px; border-radius:8px; font-weight:bold; cursor:pointer; font-size:11px;">' + t + "</button>";
        m.innerHTML = '<div style="width:min(860px,94vw); max-height:86vh; display:flex; flex-direction:column; background:#1F2D4D; color:#E2E8F0; border:1.5px solid #00F0FF; border-radius:14px; padding:14px; font-size:11.5px;">'
            + '<div style="font-weight:800; color:#00F0FF; font-size:14px; margin-bottom:6px;">📒 Havale günlüğü (' + rows.length + ')</div>'
            + '<div style="color:#A9B6CA; font-size:10.5px; margin-bottom:6px;">Yalnızca bu bilgisayarda tutulur (en çok ' + HQ_LOG_MAX + ' kayıt). Kişi adları içerir; paylaşırken dikkat edin.</div>'
            + '<div style="overflow:auto; flex:1;"><table id="hq-log-table" style="width:100%; border-collapse:collapse; font-size:11px;"><thead><tr>' + HQ_COLS.map(c => '<th style="text-align:left; border-bottom:1px solid #56709A; padding:3px; position:sticky; top:0; background:#1F2D4D;">' + c + "</th>").join("") + "</tr></thead><tbody>"
            + (rows.length ? rows.map(r => "<tr>" + r.map(v => '<td style="border-bottom:1px solid #2D3D63; padding:3px; vertical-align:top;">' + escapeHtml(v) + "</td>").join("") + "</tr>").join("") : '<tr><td colspan="7" style="padding:8px; color:#94A3B8;">Henüz kayıt yok.</td></tr>')
            + "</tbody></table></div>"
            + '<div style="display:flex; gap:6px; justify-content:flex-end; margin-top:8px;">' + b("btn-hq-log-xlsx", "📗 Excel (.xlsx)", "#15803D") + b("btn-hq-log-csv", "📊 CSV", "#2563EB") + b("btn-hq-log-clear", "🗑️ Günlüğü temizle", "#7F1D1D") + b("btn-hq-log-close", "Kapat", "#334155") + "</div></div>";
        document.body.appendChild(m);
        m.querySelector("#btn-hq-log-xlsx").onclick = () => hqExport("xlsx");
        m.querySelector("#btn-hq-log-csv").onclick = () => hqExport("csv");
        m.querySelector("#btn-hq-log-clear").onclick = () => { { extStoreSet(HQ_LOG_KEY, []); m.remove(); renderHqBox(); } };
        m.querySelector("#btn-hq-log-close").onclick = () => m.remove();
        m.addEventListener("click", e => { if (e.target === m) m.remove(); });
    }


    // NEW: arayüzü kur ve kendi kendini onarmayı başlat
    // v3.6.49: evrak açılınca (önizleme) PDF bir kez indirilir; konu + gövde özeti panelde gösterilir ve sesli okunabilir. Hiçbir EBYS düğmesine basılmaz.
    const ozBekle = ms => new Promise(r => setTimeout(r, ms)); // AUTO.stop'tan bağımsız
    const OZ_PDF_KEY = "ea_onizleme_pdf_indirilen_v1"; let ozSonAnahtar = "", ozSon = null, ozMesgul = false;
    function ozFrameKey() { try { const pf = getPreviewForm(); const fr = Array.from((pf || document).querySelectorAll("iframe.onizlemeFrame")).find(f => f.offsetWidth > 0 && f.offsetHeight > 0); if (!fr) return ""; let k = fr.getAttribute("src") || ""; try { const w = fr.contentWindow; const app = w && w.PDFViewerApplication; if (app && app.url) k += "|" + app.url; } catch(e) {} const tl = pf && pf.querySelector(".onizlemeTarih"); return k + "|" + (tl ? (tl.textContent || "").trim().slice(0, 60) : ""); } catch(e) { return ""; } }
    function ozKonu(t) { const m = String(t || "").match(/Konu\s*:\s*([^\n]+(?:\n(?!\s*(?:\S+\s*:|$))[^\n]{1,80})?)/i); return m ? m[1].replace(/\s+/g, " ").trim() : ""; }
    function ozSayi(t) { const s0 = String(t || ""); const m1 = s0.match(/Say[ıi]\s*:?\s*(E-\d{5,}-[\d.]+-\d{5,})/i); if (m1) return m1[1]; const m = s0.match(/E-\d{5,}-[\d.]+-\d{5,}/); return m ? m[0] : ""; }
    function ozKart() { // v3.6.50: özetin konacağı kart — E-sayı (tam ya da son parça) ile eşleşen evrak kartı
        if (!ozSon) return null; const adaylar = [ozSon.sayi].concat(ozSon.tumSayi || []).filter(Boolean);
        for (const n of adaylar) { const c = findCardEl(n); if (c) return c; }
        const kartlar = Array.from(document.querySelectorAll("#ebys-cards-container .ebys-doc-card"));
        for (const n of adaylar) { const k = String(n).split("-").pop(); if (k.length >= 5) { const c = kartlar.find(x => String(x.getAttribute("data-docno") || "").split("-").pop() === k); if (c) return c; } }
        return null; }
    function ozCiz() {
        let box = document.getElementById("ea-onizleme-ozet"); const kart = ozKart();
        if (!ozSon || !kart) { if (box) box.remove(); return; }
        if (!box) { box = document.createElement("div"); box.id = "ea-onizleme-ozet"; box.style.cssText = "background:#1F2D4D; border:1px solid #00F0FF; border-radius:8px; padding:8px; color:#F8FAFC; font-size:11px; line-height:1.4; margin-top:4px;"; }
        const satir = kart.querySelector(".btn-card-ozet") && kart.querySelector(".btn-card-ozet").parentElement; // 🔍 Nitelik / ⚡ Otonom / … düğme satırı
        if (satir) { if (satir.nextElementSibling !== box) satir.insertAdjacentElement("afterend", box); } else if (box.parentElement !== kart) kart.appendChild(box);
        const B = 'style="cursor:pointer; background:#000; color:#FDE047; border:2px solid #FDE047; border-radius:8px; padding:4px 8px; font-weight:800; font-size:11px;"';
        box.style.display = "block";
        box.innerHTML = '<div><b style="color:#00F0FF;">Konu:</b> ' + escapeHtml(ozSon.konu || "—") + '</div><div style="margin-top:4px;"><b style="color:#00F0FF;">Özet:</b> ' + (ozSon.ozet ? escapeHtml(ozSon.ozet) : '<span style="color:#FCA5A5;">Özet çıkarılamadı</span>') + '</div>'
            + '<div style="display:flex; flex-wrap:wrap; gap:4px; margin-top:6px;"><button type="button" id="ea-oz-ses" ' + B + '>🔊 Sesli oku</button><button type="button" id="ea-oz-dur" ' + B + '>⏹ Durdur</button><button type="button" id="ea-oz-pdf" ' + B + '>📄 PDF indir</button></div><div id="ea-oz-msg" style="margin-top:4px; font-size:10.5px; color:#CBD5E1;">' + escapeHtml(ozSon.pdfMsg || "") + '</div>';
        box.querySelector("#ea-oz-ses").onclick = () => { try { speechSynthesis.cancel(); const O = window.EA_OZET; const m = "Konu: " + O.sesTemizle(ozSon.konu || "") + ". " + (ozSon.ozet ? "Özet: " + O.sesTemizle(ozSon.ozet) : "Özet çıkarılamadı"); const u = new SpeechSynthesisUtterance(m); const v = speechSynthesis.getVoices().find(x => /^tr/i.test(x.lang)); u.lang = "tr-TR"; if (v) u.voice = v; speechSynthesis.speak(u); } catch(e) { showToast("Sesli okuma bu tarayıcıda kullanılamıyor.", "warn"); } };
        box.querySelector("#ea-oz-dur").onclick = () => { try { speechSynthesis.cancel(); } catch(e) {} }; box._eaOz = true; // klonlanmış (düğmesiz) kopyayı ayırt et
        box.querySelector("#ea-oz-pdf").onclick = async () => { const o = ozSon; if (!o) return; o.pdfMsg = "⏳ PDF indiriliyor…"; ozCiz(); o.pdfMsg = await ozIndir(o.sayi, o.konu, o.sayi); if (ozSon === o) ozCiz(); };
    }
    async function ozIndir(anahtar, konu, sayi) {
        let list = []; try { list = JSON.parse(localStorage.getItem(OZ_PDF_KEY) || "[]"); } catch(e) {}
        const r = await bridgeCall("pdfData", {}, 15000); if (!r || !r.ok || !r.b64) return "📄 PDF indirilemedi" + (r && r.error ? " (" + r.error + ")" : "") + ".";
        const bin = atob(r.b64); const a8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a8[i] = bin.charCodeAt(i);
        const ad = ((sayi || "evrak").replace(/[^\w.-]+/g, "_") + "_" + String(konu || "").normalize("NFC").replace(/[\\/:*?"<>|\n\r\t]+/g, " ").replace(/\s+/g, "_").slice(0, 60)).replace(/_+/g, "_").replace(/_$/, "") + ".pdf";
        const url = URL.createObjectURL(new Blob([a8], { type: "application/pdf" })); const l = document.createElement("a"); l.href = url; l.download = ad; document.body.appendChild(l); l.click(); l.remove(); setTimeout(() => URL.revokeObjectURL(url), 30000);
        list.push(anahtar); try { localStorage.setItem(OZ_PDF_KEY, JSON.stringify(list.slice(-300))); } catch(e) {}
        return "📄 PDF indirildi: " + ad;
    }
    async function ozTik() {
        if (ozMesgul || window.top !== window) return; if (!document.getElementById("ebys-cards-container")) return; if (!extHasConsent()) return;
        const k = ozFrameKey(); if (!k) return; if (k === ozSonAnahtar) { if (ozSon) { const b0 = document.getElementById("ea-onizleme-ozet"); const kk = ozKart(); if (kk && (!b0 || !kk.contains(b0) || !b0._eaOz)) { if (b0 && !b0._eaOz) b0.remove(); ozCiz(); } } return; }
        ozMesgul = true;
        try { await ozBekle(900); if (ozFrameKey() !== k) return; let t = ""; const t0 = Date.now();
            while (!t && Date.now() - t0 < 12000) { const r = await bridgeCall("pdfText", { maxPages: 4 }, 6000); if (r && r.ok && r.text && r.text.replace(/\s/g, "").length > 30) t = r.text; else { const d2 = readPdfDomText(); if (d2 && d2.replace(/\s/g, "").length > 30) t = d2; else await ozBekle(600); } if (ozFrameKey() !== k) return; }
            ozSonAnahtar = k; if (!t) { ozSon = null; ozCiz(); return; }
            const O = window.EA_OZET; const konu = ozKonu(t), sayi = ozSayi(t); ozSon = { konu: konu, sayi: sayi, tumSayi: (String(t).match(/E-\d{5,}-[\d.]+-\d{5,}/g) || []), ozet: O ? O.ozetCikar(t) : "", pdfMsg: "" }; ozCiz(); // v3.6.51: otomatik indirme yok; yalnızca 📄 PDF indir ile
        } catch(e) { console.warn("[Evrak Asistanı] önizleme özeti:", e); } finally { ozMesgul = false; }
    }
    try { if (window.top === window) setInterval(() => { ozTik(); }, 1500); } catch(e) {}
    const bootUI = () => { createUI(); startSelfHealing(); try { maybeAutoScanAfterNav(); } catch(e) {} };
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", bootUI);
    } else {
        bootUI();
    }
    if (window.__EBYS_TESTING__) window.__ebysTest = { extractDocAttributes: extractDocAttributes, computeDeadline: computeDeadline, findRecurringRule: findRecurringRule, rankTemplatesFor: rankTemplatesFor }; // yalnızca testlerde
    } // ebysMain
})();
