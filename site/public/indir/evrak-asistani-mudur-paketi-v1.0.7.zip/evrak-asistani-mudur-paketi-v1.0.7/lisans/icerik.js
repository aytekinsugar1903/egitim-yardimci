/* manifest içerik betikleri — yalnız lisans/deneme geçerliyken kaydedilir */
self.EA_ICERIK = [
  {
    "id": "ea-ic-1",
    "matches": [
      "https://ebys.meb.gov.tr/*"
    ],
    "js": [
      "ozet.js",
      "ekoku.js",
      "content.js"
    ],
    "persistAcrossSessions": true,
    "allFrames": true,
    "runAt": "document_idle"
  },
  {
    "id": "ea-ic-2",
    "matches": [
      "https://ebys.meb.gov.tr/*"
    ],
    "js": [
      "bridge.js"
    ],
    "persistAcrossSessions": true,
    "runAt": "document_idle",
    "world": "MAIN"
  }
];
