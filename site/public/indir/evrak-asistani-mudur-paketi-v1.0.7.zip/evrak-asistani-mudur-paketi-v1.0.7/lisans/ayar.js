/* Ürün lisans ayarı — Evrak Asistanı / Eyüp ŞEKER */
self.EA_LISANS_AYAR = {
  "urun": "mudur",
  "kabul": [
    "mudur"
  ],
  "ad": "Evrak Asistanı – Müdür Paketi",
  "surum": "1.0.7",
  "depo": "ea_lisans_mudur_v1",
  "simgeAc": true,
  "hazirMetin": "EBYS sekmesini yenileyin; Müdür Paketi paneli açılır."
};
