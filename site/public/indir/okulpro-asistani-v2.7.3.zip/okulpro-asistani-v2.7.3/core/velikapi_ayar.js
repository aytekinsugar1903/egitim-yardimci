"use strict";
// [VELİDUY] Adres + entegrasyon anahtarı ayarı (chrome.storage.local "velikapi")
(async () => {
  const a = document.getElementById("vkAdres"), k = document.getElementById("vkAnahtar");
  const { velikapi } = await chrome.storage.local.get("velikapi");
  a.value = "https://veli.otonomevrak.com";
  if (velikapi) { a.value = (velikapi.adres || a.value).replace("velikapi.aytekinsugar1903", "veliduy.aytekinsugar1903"); k.value = velikapi.anahtar || ""; }
  document.getElementById("vkKaydet").onclick = async () => {
    const adres = a.value.trim().replace(/\/+$/, ""), anahtar = k.value.trim();
    const m = document.getElementById("mesaj");
    const yaz = (t) => { m.textContent = t; m.style.display = "block"; setTimeout(() => (m.style.display = "none"), 5000); };
    if (!adres && !anahtar) { await chrome.storage.local.remove("velikapi"); yaz("Veli Asistanı bağlantısı kaldırıldı."); return; }
    if (!/^https:\/\/[^\s]+$/.test(adres)) { yaz("Adres https:// ile başlamalı."); return; }
    if (!/^vk_[0-9a-f]{48}$/.test(anahtar)) { yaz("Anahtar vk_ ile başlayan 51 karakter olmalı (Veli Asistanı > Okul sayfasından kopyalayın)."); return; }
    await chrome.storage.local.set({ velikapi: { adres, anahtar } });
    yaz("Veli Asistanı bağlantısı kaydedildi.");
  };
})();
