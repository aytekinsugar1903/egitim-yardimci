"use strict";
// v2.4.2: Yerel Okuma Servisi eşleştirme (chrome.storage.local "yerel_okuma": açık, port, belirteç). Servis yalnız 127.0.0.1.
(async () => {
  const YO = globalThis.YerelOkuma; if (!YO) return;
  const d = document.getElementById("yoDurum"), m = document.getElementById("mesaj");
  const yaz = (t) => { if (!m) return; m.textContent = t; m.style.display = "block"; setTimeout(() => (m.style.display = "none"), 6000); };
  async function goster() {
    const s = await YO.durum(1500);
    if (s.durum === "kapali") d.textContent = s.acik ? "servis kapalı / kurulu değil — eklenti kendi okuyucusunu kullanıyor" : "kullanılmıyor";
    else if (!s.acik || !s.eslesmis) d.textContent = `servis açık (${s.surum || "?"}, ${s.cihaz || "?"}) — eşleşmemiş`;
    else d.textContent = s.durum === "hazir" ? `BAĞLI — ${s.cihaz === "cuda" ? "ekran kartı (GPU)" : "işlemci (CPU)"}, servis ${s.surum}` : `bağlı, modeller ${s.durum}${s.hata ? " (" + s.hata + ")" : ""}`;
  }
  document.getElementById("yoBaglan").onclick = async () => { const r = await YO.eslestir(); yaz(r.ok ? "Yerel okuma servisine bağlandı." : "Bağlanamadı: " + r.hata); goster(); };
  document.getElementById("yoKapat").onclick = async () => { await YO.kapat(); yaz("Yerel okuma servisi kullanılmayacak."); goster(); };
  document.getElementById("yoDenetle").onclick = goster;
  goster();
})();
