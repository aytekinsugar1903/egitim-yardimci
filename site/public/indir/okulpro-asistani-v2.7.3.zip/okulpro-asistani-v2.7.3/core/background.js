// v2.4.1: T.C. kasası anahtarı chrome.storage.session'da (yalnız bellek); e-Okul içerik betikleri de okuyabilsin
function oturumErisimi() { try { chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_AND_UNTRUSTED_CONTEXTS" }).catch(() => {}); } catch (e) {} }
oturumErisimi();
chrome.runtime.onStartup.addListener(oturumErisimi);
chrome.runtime.onInstalled.addListener(oturumErisimi);
// v2.4.1: güncellemeden sonra depoda eski sürümden kalan düz T.C. varsa ve kasa kurulmamışsa kasa sayfası açılır (ilk açılışta şifrelenir)
chrome.runtime.onInstalled.addListener(async () => {
  try { const r = await chrome.storage.local.get(["durum", "sonRapor", "tcKasa"]);
    const duz = [r.durum, r.sonRapor].some((v) => v && Array.isArray(v.satirlar) && v.satirlar.some((s) => s && /^\d{11}$/.test(String(s.tc || ""))));
    if (duz && !r.tcKasa) chrome.tabs.create({ url: chrome.runtime.getURL("core/kasa.html") }); } catch (e) {}
});

// Simgeye tıklanınca e-Okul sayfasındaki yüzen paneli aç/kapat.
// Sayfada panel yoksa (adres eşleşmiyorsa) paneli yeni sekmede aç.
async function panelDegistir(sekmeId) {
  try { await chrome.tabs.sendMessage(sekmeId, { tip: "degistir" }, { frameId: 0 }); }
  catch (e) { await chrome.tabs.create({ url: chrome.runtime.getURL("modules/rapor/panel.html") }); }
}
chrome.action.onClicked.addListener(async (tab) => { await panelDegistir(tab.id); });

const E_OKUL = /^https:\/\/([a-z0-9-]+\.)*e-?okul\.meb\.gov\.tr\//i;
// v2.4.0: klavye kısayolu (varsayılan Ctrl+Shift+E) — e-Okul sekmesinde paneli aç/kapat
chrome.commands.onCommand.addListener(async (komut) => {
  if (komut !== "panel-ac") return;
  const [sekme] = await chrome.tabs.query({ active: true, currentWindow: true });
  // v2.4.1: kısayol yalnız e-Okul sekmesinde çalışır (adres yalnız izinli e-Okul sekmelerinde görülür; başka sitede yeni sekme açılmaz)
  if (sekme && typeof sekme.id === "number" && E_OKUL.test(sekme.url || "")) await panelDegistir(sekme.id);
});

// Panelden "tarama sayfasını aç" isteği (OCR yalnızca eklenti sayfasında, yerel olarak çalışır).
chrome.runtime.onMessage.addListener((m) => {
  if (m && m.tip === "kvkkAc") chrome.tabs.create({ url: chrome.runtime.getURL("core/kvkk.html") });
  if (m && m.tip === "okulAyarlariAc") chrome.tabs.create({ url: chrome.runtime.getURL("core/okul_ayarlari.html") });
  if (m && m.tip === "kasaAc") chrome.tabs.create({ url: chrome.runtime.getURL("core/kasa.html") }); // v2.4.1
  if (m && m.tip === "bosFormAc") chrome.tabs.create({ url: chrome.runtime.getURL("modules/rapor/bos_form.html") + "?tur=" + (Number(m.tur) || 1) }); // v2.5.8: Boş form indir
  if (m && m.tip === "taramaAc") chrome.tabs.create({ url: chrome.runtime.getURL("modules/rapor/tarama.html") + (m.tur === "veli" ? "?tur=veli" : "") }); // v2.3.25
});

// İlk kurulumda KVKK bilgilendirmesini göster (onaylanana kadar otomasyonlar kapalı)
chrome.runtime.onInstalled.addListener(async () => {
  const r = await chrome.storage.local.get("kvkkOnay");
  if (!r.kvkkOnay) chrome.tabs.create({ url: chrome.runtime.getURL("core/kvkk.html") });
});
// Tarayıcı açılışında: "kapanışta sil" seçiliyse rapor verilerini ve günlüğü temizle (önceki oturum kapanırken kalmış olanlar)
chrome.runtime.onStartup.addListener(async () => {
  const r = await chrome.storage.local.get(["ayar", "durum"]);
  if (r.ayar && r.ayar.kapanistaSil && !(r.durum && r.durum.calisiyor)) await chrome.storage.local.remove(["durum", "log"]);
});

// [VELİDUY] Devamsız listesini okulun Veli Asistanı adresine gönderir (yalnızca kullanıcı tıklamasıyla tetiklenir).
chrome.runtime.onMessage.addListener((m, _g, yanit) => {
  if (!m || m.tip !== "vkGonder") return;
  (async () => {
    const { velikapi } = await chrome.storage.local.get("velikapi");
    const adres = ((velikapi && velikapi.adres) || "https://veli.otonomevrak.com").trim().replace(/\/+$/, "").replace("velikapi.aytekinsugar1903", "veliduy.aytekinsugar1903");
    const anahtar = ((velikapi && velikapi.anahtar) || "").trim();
    if (!/^https:\/\//.test(adres) || !anahtar) return { ok: false, hata: "Okul ayarlarında Veli Asistanı adresi ve entegrasyon anahtarı girilmemiş." };
    const v = m.veri || {};
    const entries = (v.entries || []).map((e) => ({ ogrenciNo: String(e.ogrenciNo), sinif: String(e.sinif || ""), tur: String(e.tur || "gelmedi") }));
    try {
      const r = await fetch(adres + "/api/integrations/eokul/absences", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + anahtar },
        body: JSON.stringify({ date: v.date, entries }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) return { ok: false, hata: j.error || ("HTTP " + r.status) };
      return { ok: true, sonuc: j };
    } catch (e) {
      return { ok: false, hata: "Veli Asistanı'na ulaşılamadı: " + e.message };
    }
  })().then(yanit);
  return true;
});

// v2.7.0: Not Girişi 1.9.22 ses penceresi + OYSS şablon/indirme (klasör: Not Girisi/OYSS/tarih)
try { importScripts("../ses/yonet.js"); } catch (e) {}
let sesPencere = null, sesSekme = null, sesKare = null;
function sesHedefYaz(kayit) {
  if (kayit && kayit.tabId != null) sesSekme = kayit.tabId;
  if (kayit && kayit.frameId != null) sesKare = kayit.frameId;
  try { chrome.storage.local.set({ ngaSesHedef: { tabId: sesSekme, frameId: sesKare, z: Date.now() } }); } catch (e) {}
}
function sesPencereAc() {
  const url = chrome.runtime.getURL("ses/ses.html");
  const ac = () => chrome.windows.create({ url: url, type: "popup", width: 480, height: 360, focused: true }, (w) => { sesPencere = w && w.id; });
  if (sesPencere != null) {
    chrome.windows.get(sesPencere, () => {
      if (chrome.runtime.lastError) { sesPencere = null; ac(); }
      else chrome.windows.update(sesPencere, { focused: true });
    });
    return;
  }
  ac();
}
function sesKapa() {
  try { chrome.storage.local.set({ ngaSesKomut: { k: "dur", z: Date.now() } }); } catch (e) {}
  if (sesPencere != null) {
    try { chrome.windows.remove(sesPencere, () => { void chrome.runtime.lastError; }); } catch (e) {}
    sesPencere = null;
  }
}
function sesParcaIlet(paket) {
  const Y = (typeof NGASesYonet !== "undefined") ? NGASesYonet : null;
  const p = Y && Y.sesParcaPaket ? Y.sesParcaPaket(paket) : Object.assign({ tip: "nga-ses-parca" }, paket, { final: paket && paket.final !== false });
  try { chrome.storage.local.set({ ngaSesMetin: p }); } catch (e) {}
  const tabId = sesSekme;
  if (tabId == null) return;
  const kareler = Y && Y.sesKareHedefleri ? Y.sesKareHedefleri({ frameId: sesKare }) : (sesKare != null && sesKare !== 0 ? [sesKare, 0] : [0]);
  const gonder = (frameId, msg) => {
    try { chrome.tabs.sendMessage(tabId, msg, { frameId: frameId }, () => { void chrome.runtime.lastError; }); } catch (e) {}
  };
  if (Y && Y.sesParcaDagit) Y.sesParcaDagit(p, kareler, gonder);
  else kareler.forEach((f) => gonder(f, p));
  try { chrome.tabs.sendMessage(tabId, p, () => { void chrome.runtime.lastError; }); } catch (e) {}
  if (chrome.scripting && chrome.scripting.executeScript) {
    try {
      chrome.scripting.executeScript({
        target: { tabId: tabId, allFrames: true },
        func: (msg) => { try { if (self.NGASes && self.NGASes._hap && self.NGASes._hap.parcaIsle) self.NGASes._hap.parcaIsle(msg); } catch (e) {} },
        args: [p]
      }, () => { void chrome.runtime.lastError; });
    } catch (e) {}
  }
}
chrome.runtime.onMessage.addListener((m, gonderen) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m) return;
  if (m.tip === "ses-ac") {
    const Y = (typeof NGASesYonet !== "undefined") ? NGASesYonet : null;
    const kayit = Y && Y.sesSekmeKaydet ? Y.sesSekmeKaydet(gonderen, m) : { tabId: gonderen.tab && gonderen.tab.id, frameId: gonderen.frameId };
    sesHedefYaz(kayit);
    sesPencereAc();
    return;
  }
  if (m.tip === "ses-kapa") { sesKapa(); return; }
  if (m.tip === "ses-izin-pencere") { sesPencereAc(); return; }
  if (m.tip === "nga-ses-parca") { sesParcaIlet(m); return; }
});

function dosyaAdiGuvenli(ad, yedek) {
  let s = String(ad || yedek || "OYSS.xlsx");
  s = s.replace(/[\\/:*?"<>|]+/g, "_").replace(/[\u0000-\u001f]/g, "");
  s = s.replace(/^.*[\\/]/, "");
  const nokta = s.lastIndexOf(".");
  let taban = nokta > 0 ? s.slice(0, nokta) : s;
  let uzanti = nokta > 0 ? s.slice(nokta) : ".xlsx";
  taban = taban.replace(/[.\s]+$/g, "").replace(/^[.\s]+/g, "") || "OYSS";
  uzanti = uzanti.replace(/[.\s]+$/g, "") || ".xlsx";
  if (uzanti.charAt(0) !== ".") uzanti = "." + uzanti;
  return (taban + uzanti).slice(0, 150);
}
function indirYoluGuvenli(ad, yedek) {
  const ham = String(ad || yedek || "OYSS.xlsx").replace(/[\u0000-\u001f]/g, "").replace(/\\/g, "/");
  const parts = ham.split("/").filter(Boolean);
  const temiz = [];
  for (let i = 0; i < parts.length; i++) {
    if (parts[i] === "." || parts[i] === "..") continue;
    if (i === parts.length - 1) temiz.push(dosyaAdiGuvenli(parts[i], yedek || "OYSS.xlsx"));
    else {
      const parca = parts[i].replace(/[\\/:*?"<>|]+/g, "_").replace(/^[.\s]+|[.\s]+$/g, "").slice(0, 80);
      if (parca) temiz.push(parca);
    }
  }
  return (temiz.join("/") || dosyaAdiGuvenli(yedek || "OYSS.xlsx")).slice(0, 240);
}
function oyssU8b64(u8) {
  let s = "";
  const CH = 0x8000;
  for (let i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
  return btoa(s);
}
const indirGunluk = [];
function gunluk(kayit) {
  indirGunluk.push(Object.assign({ t: new Date().toISOString() }, kayit));
  if (indirGunluk.length > 40) indirGunluk.shift();
  try { chrome.storage.local.set({ ngaOyssIndirGunluk: indirGunluk.slice(-20) }); } catch (e) {}
}

chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== "oyss-sablon") return;
  (async () => {
    try {
      const r = await fetch(chrome.runtime.getURL("modules/oyss/OYSS_Soru_Bazli_Not_Sablonu.xlsx"));
      if (!r.ok) throw new Error("şablon HTTP " + r.status);
      const u8 = new Uint8Array(await r.arrayBuffer());
      gunluk({ adim: "sablon", ok: true, bayt: u8.length });
      yanit({ ok: true, veri: oyssU8b64(u8), bayt: u8.length });
    } catch (e) {
      const hata = String(e && e.message || e);
      gunluk({ adim: "sablon", ok: false, hata });
      yanit({ ok: false, hata });
    }
  })();
  return true;
});

chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== "oyss-indir") return;
  try {
    const tur = String(m.tur || "application/octet-stream").replace(/[^a-z0-9.+\/-]/gi, "") || "application/octet-stream";
    const url = "data:" + tur + ";base64," + String(m.veri || "");
    const ad = indirYoluGuvenli(m.ad, "OYSS.xlsx");
    if (!m.veri) {
      const hata = "indirme verisi boş";
      gunluk({ adim: "indir", ok: false, ad, hata });
      yanit({ ok: false, hata, ad });
      return true;
    }
    chrome.downloads.download({ url, filename: ad, saveAs: false, conflictAction: "uniquify" }, (id) => {
      const err = chrome.runtime.lastError && chrome.runtime.lastError.message;
      if (err || !id) {
        gunluk({ adim: "indir", ok: false, ad, id: id || null, hata: err || "indirme başlamadı" });
        yanit({ ok: false, hata: err || "indirme başlamadı", ad, id: id || null });
        return;
      }
      const bitir = () => {
        chrome.downloads.search({ id }, (items) => {
          const it = (items && items[0]) || {};
          const yol = it.filename || "";
          let klasor = "";
          if (yol) {
            const n = Math.max(yol.lastIndexOf("\\"), yol.lastIndexOf("/"));
            klasor = n >= 0 ? yol.slice(0, n) : "";
          }
          gunluk({ adim: "indir", ok: true, ad, id, yol, klasor });
          yanit({ ok: true, ad, id, yol, klasor });
        });
      };
      const dinle = (delta) => {
        if (delta.id !== id || !delta.state) return;
        if (delta.state.current === "complete") { chrome.downloads.onChanged.removeListener(dinle); bitir(); }
        else if (delta.state.current === "interrupted") {
          chrome.downloads.onChanged.removeListener(dinle);
          const hata = (delta.error && delta.error.current) || "indirme yarıda kesildi";
          gunluk({ adim: "indir", ok: false, ad, id, hata });
          yanit({ ok: false, hata, ad, id });
        }
      };
      chrome.downloads.onChanged.addListener(dinle);
      chrome.downloads.search({ id }, (items) => {
        if (items && items[0] && items[0].state === "complete") { chrome.downloads.onChanged.removeListener(dinle); bitir(); }
      });
    });
  } catch (e) {
    const hata = String(e && e.message || e);
    gunluk({ adim: "indir", ok: false, hata });
    yanit({ ok: false, hata });
  }
  return true;
});

chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== "oyss-indir-gunluk") return;
  yanit({ ok: true, gunluk: indirGunluk.slice() });
  return true;
});

chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== "oyss-indir-goster" || !m.id) return;
  try { chrome.downloads.show(+m.id); yanit({ ok: true }); }
  catch (e) { yanit({ ok: false, hata: String(e && e.message || e) }); }
  return true;
});

chrome.runtime.onMessage.addListener((m, gonderen, yanit) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m || m.tip !== "oyss-indir-ac" || !m.id) return;
  try {
    chrome.downloads.open(+m.id);
    const err = chrome.runtime.lastError && chrome.runtime.lastError.message;
    yanit({ ok: !err, hata: err || "" });
  } catch (e) { yanit({ ok: false, hata: String(e && e.message || e) }); }
  return true;
});

// v2.7.3: Ders Notu sekmesi (Not Girişi 1.9.24; ilk: 2.7.1) — Excel'den not girişi sayfası ve paneli açma iletisi
const DN_SAYFALAR = { ice: "ice/ice.html", iceOgren: "ice/ice.html#ogrenilen", notoku: "ice/ice.html", tarama: "ice/ice.html" };
chrome.runtime.onMessage.addListener((m, gonderen) => {
  if (!gonderen || gonderen.id !== chrome.runtime.id || !m) return;
  if (m.tip === "sekme-ac" && DN_SAYFALAR[m.hedef]) { chrome.tabs.create({ url: chrome.runtime.getURL(DN_SAYFALAR[m.hedef]) }); return; }
  if (m.tip === "nga-ac-ilet" && gonderen.tab && gonderen.tab.id != null) {
    try { chrome.tabs.sendMessage(gonderen.tab.id, { tip: "nga-ac" }, () => { void chrome.runtime.lastError; }); } catch (e) {}
  }
});
