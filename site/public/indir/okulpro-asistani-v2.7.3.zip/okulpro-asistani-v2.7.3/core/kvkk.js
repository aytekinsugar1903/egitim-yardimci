const $ = (s) => document.querySelector(s);
$("#okudum").onchange = () => { $("#onayla").disabled = !$("#okudum").checked; };
$("#onayla").onclick = async () => {
  await chrome.storage.local.set({ kvkkOnay: { tarih: new Date().toISOString(), surum: chrome.runtime.getManifest().version } });
  $("#onaylandi").textContent = "Onaylandı. Bu sekmeyi kapatabilirsiniz.";
};
chrome.storage.local.get("kvkkOnay").then((r) => { if (r.kvkkOnay) $("#onaylandi").textContent = "Daha önce onaylandı: " + new Date(r.kvkkOnay.tarih).toLocaleString("tr"); });
