"use strict";
const P = globalThis.OkulProfil;
const $ = (s) => document.querySelector(s);
let siniflar = [];

function mesaj(m) { const e = $("#mesaj"); e.textContent = m; e.style.display = "block"; clearTimeout(mesaj.t); mesaj.t = setTimeout(() => (e.style.display = "none"), 4000); }

function sinifCiz() {
  const ol = $("#siniflar"); ol.innerHTML = "";
  siniflar.forEach((ad, i) => {
    const li = document.createElement("li");
    const inp = document.createElement("input"); inp.value = ad; inp.placeholder = "ör. AMP - 9. Sınıf / A Şubesi";
    inp.oninput = () => { siniflar[i] = inp.value; };
    const btn = (t, title, fn) => { const b = document.createElement("button"); b.textContent = t; b.title = title; b.className = "kucuk"; b.onclick = fn; return b; };
    li.append(inp,
      btn("↑", "Yukarı taşı", () => { if (i > 0) { [siniflar[i - 1], siniflar[i]] = [siniflar[i], siniflar[i - 1]]; sinifCiz(); } }),
      btn("↓", "Aşağı taşı", () => { if (i < siniflar.length - 1) { [siniflar[i + 1], siniflar[i]] = [siniflar[i], siniflar[i + 1]]; sinifCiz(); } }),
      btn("−", "Satırı sil", () => { siniflar.splice(i, 1); sinifCiz(); }),
      btn("+", "Altına satır ekle", () => { siniflar.splice(i + 1, 0, ""); sinifCiz(); ol.children[i + 1].querySelector("input").focus(); }));
    ol.append(li);
  });
  $("#sinifSay").textContent = siniflar.filter((s) => s.trim()).length;
}

function indir(metin, ad, tur) { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([metin], { type: tur })); a.download = ad; a.click(); }
const temizSiniflar = () => siniflar.map((s) => s.trim()).filter(Boolean);

async function yukle() {
  const p = await P.profilOku();
  $("#okulAdi").value = p.okulAdi;
  siniflar = p.siniflar.slice();
  $("#kurumlar").value = p.ayar.kurumlar || P.VARSAYILAN_KURUMLAR; kurumCiz();
  $("#bekleMin").value = p.ayar.bekleMin || 3000; $("#bekleMax").value = p.ayar.bekleMax || 4000;
  $("#sevkSure").value = p.ayar.sevkSure || 1;
  $("#otoTemizle").checked = p.ayar.otoTemizle !== false; $("#kapanistaSil").checked = !!p.ayar.kapanistaSil;
  // v2.4.0: tatil / arife takvimi (kayıtlı metin yoksa varsayılan gösterilir)
  const B = globalThis.VeliBirlestir;
  $("#tatiller").value = typeof p.ayar.tatilMetni === "string" ? p.ayar.tatilMetni : (B ? B.VARSAYILAN_TATIL_METNI : "");
  $("#arifeler").value = typeof p.ayar.arifeMetni === "string" ? p.ayar.arifeMetni : (B ? B.VARSAYILAN_ARIFE_METNI : "");
  takvimOzetCiz();
  sinifCiz();
}

function formdanProfil(ayar) {
  return { okulAdi: $("#okulAdi").value.trim(), siniflar: temizSiniflar(),
    ayar: { ...ayar, kurumlar: $("#kurumlar").value.trim() || P.VARSAYILAN_KURUMLAR,
      bekleMin: Math.max(500, Number($("#bekleMin").value) || 3000), bekleMax: Math.max(Number($("#bekleMin").value) || 3000, Number($("#bekleMax").value) || 4000),
      sevkSure: Number($("#sevkSure").value) || 1, otoTemizle: $("#otoTemizle").checked, kapanistaSil: $("#kapanistaSil").checked,
      tatilMetni: $("#tatiller").value.trim(), arifeMetni: $("#arifeler").value.trim() } };
}

// v2.4.0: takvim özeti — kaç gün tatil/arife, tanınmayan satır var mı
function takvimOzetCiz() {
  const B = globalThis.VeliBirlestir, e = $("#takvimOzet"); if (!B || !e) return;
  const gunSay = (araliklar) => araliklar.reduce((n, [b, s]) => n + (Math.round((new Date(s + "T12:00:00") - new Date(b + "T12:00:00")) / 86400000) + 1), 0);
  const t = B.tarihleriCoz($("#tatiller").value), a = B.tarihleriCoz($("#arifeler").value);
  const tSatir = $("#tatiller").value.split(/\r?\n/).filter((s) => s.replace(/#.*$/, "").trim()).length;
  const aSatir = $("#arifeler").value.split(/\r?\n/).filter((s) => s.replace(/#.*$/, "").trim()).length;
  const atilan = (tSatir - t.length) + (aSatir - a.length);
  e.textContent = `Tatil ${gunSay(t)} gün (${t.length} satır) · Arife ${a.length} gün` + (atilan > 0 ? ` · ${atilan} satır tarih olarak tanınmadı` : "") + (atilan > 0 ? " — gg.aa.yyyy biçiminde yazın" : "");
  e.style.color = atilan > 0 ? "#b00020" : "#0b5d1e";
}

$("#tatilVarsayilan").onclick = () => {
  const B = globalThis.VeliBirlestir; if (!B) return;
  if (!confirm("Tatil ve arife takvimi 2026–2027 varsayılanına dönsün mü? (Kaydet'e basınca geçerli olur)")) return;
  $("#tatiller").value = B.VARSAYILAN_TATIL_METNI; $("#arifeler").value = B.VARSAYILAN_ARIFE_METNI; takvimOzetCiz(); mesaj("Varsayılan takvim yüklendi. Kaydet'e basın.");
};
["#tatiller", "#arifeler"].forEach((s) => { const e = $(s); if (e) e.addEventListener("input", takvimOzetCiz); });

$("#sinifEkle").onclick = () => { siniflar.push(""); sinifCiz(); $("#siniflar").lastChild.querySelector("input").focus(); };
$("#sinifVarsayilan").onclick = () => { if (confirm("Şube listesi boşaltılsın mı? (Okulunuzun şubelerini e-Okul’daki adlarıyla yeniden girin.)")) { siniflar = P.VARSAYILAN_SINIFLAR.slice(); sinifCiz(); } };
$("#sinifTemizle").onclick = () => { if (confirm("Tüm şubeler silinsin mi? (Kaydet'e basınca geçerli olur)")) { siniflar = []; sinifCiz(); } };
$("#sinifDisa").onclick = () => indir(temizSiniflar().join("\r\n"), "subeler.txt", "text/plain;charset=utf-8");
$("#sinifIce").onchange = async (e) => {
  const f = e.target.files[0]; if (!f) return;
  const m = (await f.text()).replace(/^\ufeff/, "");
  let l; try { const j = JSON.parse(m); l = Array.isArray(j) ? j : j.siniflar; } catch (x) { l = m.split(/\r?\n/); }
  siniflar = (l || []).map(String).map((s) => s.trim()).filter(Boolean); sinifCiz(); e.target.value = "";
  mesaj(`${siniflar.length} şube içe aktarıldı. Kaydet'e basın.`);
};

$("#kaydet").onclick = async () => {
  if (!$("#tatiller").value.trim() && !$("#arifeler").value.trim() && !confirm("Tatil ve arife listesi boş. Bu durumda hiçbir gün tatil sayılmaz ve ardışık günler tatilde de birleştirilir. Yine de kaydedilsin mi?")) return;
  const p = await P.profilOku();
  await P.profilYaz(formdanProfil(p.ayar));
  siniflar = temizSiniflar(); sinifCiz();
  mesaj("Kaydedildi. Açık e-Okul sekmelerinde yeni liste ve takvim hemen geçerli olur.");
  if (globalThis.VeliBirlestir) globalThis.VeliBirlestir.takvimYaz(formdanProfil(p.ayar).ayar);
};

$("#profilDisa").onclick = async () => {
  const p = formdanProfil((await P.profilOku()).ayar);
  const cikti = { tur: "eokul-asistan-okul-profili", surum: 2, tarih: new Date().toISOString(), okulAdi: p.okulAdi, siniflar: p.siniflar,
    rapor: { kurumlar: p.ayar.kurumlar, hiz: p.ayar.hiz, bekleMin: p.ayar.bekleMin, bekleMax: p.ayar.bekleMax, sevkSure: p.ayar.sevkSure, otoTemizle: p.ayar.otoTemizle, kapanistaSil: p.ayar.kapanistaSil, neden: p.ayar.neden, veliNeden: p.ayar.veliNeden, veliAciklama: p.ayar.veliAciklama, faaliyetNeden: p.ayar.faaliyetNeden, faaliyetAciklama: p.ayar.faaliyetAciklama, sureHesabi: p.ayar.sureHesabi, secici: p.ayar.secici, tatilMetni: p.ayar.tatilMetni, arifeMetni: p.ayar.arifeMetni } };
  indir(JSON.stringify(cikti, null, 2), `okul_profili_${(p.okulAdi || "okul").replace(/[^\wÇĞİÖŞÜçğıöşü-]+/g, "_")}.json`, "application/json");
};
$("#profilIce").onchange = async (e) => {
  const f = e.target.files[0]; if (!f) return; e.target.value = "";
  let j; try { j = JSON.parse(await f.text()); } catch (x) { alert("Geçersiz JSON dosyası."); return; }
  if (j.tur !== "eokul-asistan-okul-profili") { alert("Bu dosya bir okul profili değil."); return; }
  if (!confirm(`"${j.okulAdi || "?"}" profili yüklensin mi? Mevcut okul ayarlarının üzerine yazılır.`)) return;
  const eski = (await P.profilOku()).ayar;
  const r = j.rapor || {}, ayar = { ...eski };
  for (const k of ["kurumlar", "hiz", "bekleMin", "bekleMax", "sevkSure", "otoTemizle", "kapanistaSil", "neden", "veliNeden", "veliAciklama", "faaliyetNeden", "faaliyetAciklama", "sureHesabi", "secici", "tatilMetni", "arifeMetni"]) if (r[k] !== undefined && r[k] !== null) ayar[k] = r[k];
  await P.profilYaz({ okulAdi: j.okulAdi || "", siniflar: Array.isArray(j.siniflar) ? j.siniflar.map(String) : [], ayar });
  await yukle(); mesaj("Profil içe aktarıldı ve kaydedildi.");
};

$("#tumunuSil").onclick = async () => {
  if (!confirm("Eklentinin TÜM verileri (okul profili, ayarlar, rapor listesi, günlük, KVKK onayı) silinsin mi? Geri alınamaz.")) return;
  const r = await chrome.storage.local.get(["durum", "kilit"]);
  if (r.durum && r.durum.calisiyor) { alert("Rapor otomasyonu çalışıyor; önce durdurun."); return; }
  await P.tumVerileriSil();
  await yukle(); mesaj("Tüm veriler silindi. (e-Okul sekmelerindeki şube listesi kopyası da bir sonraki sayfa yüklemesinde varsayılana döner.)");
};

yukle();

// v2.3.4: Açıklama listesi +/− düzenleyici (gizli textarea ile eşitlenir; kaydetme mantığı aynı)
function kurumCiz() {
  const kap = document.getElementById("kurumListe"), ta = document.getElementById("kurumlar"); if (!kap) return;
  const satirlar = ta.value.split(/\r?\n/).filter((x) => x.trim()); kap.innerHTML = "";
  const yaz = () => { ta.value = [...kap.querySelectorAll("input")].map((i) => i.value.trim()).filter(Boolean).join("\n"); };
  satirlar.forEach((l) => {
    const d = document.createElement("div"), i = document.createElement("input"), b = document.createElement("button");
    i.value = l; i.style.width = "85%"; i.placeholder = "Ad | anahtar1, anahtar2"; i.oninput = yaz;
    b.type = "button"; b.textContent = "−"; b.title = "Çıkar"; b.style.cssText = "color:#c00;font-weight:bold"; b.onclick = () => { d.remove(); yaz(); };
    d.append(i, " ", b); kap.append(d);
  });
}
document.getElementById("kurumEkle").onclick = () => { const ta = document.getElementById("kurumlar"); ta.value = ta.value.trim() + "\nYeni | anahtar"; kurumCiz(); const l = document.querySelectorAll("#kurumListe input"); l[l.length - 1].select(); };

// v2.4.1: T.C. kasası sayfası
if (document.getElementById("kasaAc")) document.getElementById("kasaAc").onclick = () => chrome.runtime.sendMessage({ tip: "kasaAc" });
