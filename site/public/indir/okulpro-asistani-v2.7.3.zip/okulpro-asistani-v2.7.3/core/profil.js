// Okul profili: okula özgü tüm ayarlar tek yerde. Eklenti sayfaları ve köprü ortak kullanır.
"use strict";
(function (kok) {
  const VARSAYILAN_SINIFLAR = []; // v2.6.0: okula özgü varsayılan yok; şubeler Okul Ayarları’nda girilir
  const VARSAYILAN_KURUMLAR = "Aile Hekimi | aile sagligi merkezi, asm, aile hekimi, aile hekimligi\nŞehir Hastanesi | sehir hastanesi\nÜniversite Hastanesi | universite, universitesi, tip fakultesi\nDevlet Hastanesi | devlet hastanesi";
  const KILIT_OMUR_MS = 30000;
  // Profil = { okulAdi, siniflar[] }  +  rapor ayarları ("ayar" anahtarında: kurumlar, bekleMin, bekleMax, sevkSure, neden, ...)
  async function profilOku() {
    const r = await chrome.storage.local.get(["okulProfili", "ayar"]);
    const p = r.okulProfili || {};
    return { okulAdi: p.okulAdi || "", siniflar: Array.isArray(p.siniflar) ? p.siniflar : VARSAYILAN_SINIFLAR.slice(), ayar: r.ayar || {} };
  }
  async function profilYaz(p) {
    await chrome.storage.local.set({ okulProfili: { okulAdi: p.okulAdi || "", siniflar: p.siniflar || [] }, ayar: p.ayar || {} });
  }
  // Ortak kilit: { modul: "rapor" | "devamsizlik", ts }. Rapor için durum.calisiyor da kilit sayılır.
  async function kilitDurumu() {
    const r = await chrome.storage.local.get(["kilit", "durum"]);
    if (r.durum && r.durum.calisiyor) return { modul: "rapor" };
    if (r.kilit && Date.now() - r.kilit.ts < KILIT_OMUR_MS) return r.kilit;
    return null;
  }
  // KVKK: ilk kullanımda bilgilendirme onayı zorunlu
  async function kvkkOnayli() { try { return !!(await chrome.storage.local.get("kvkkOnay")).kvkkOnay; } catch (e) { return false; } }
  // Günlüklerde TC maskeleme: 12345678901 -> 123******01
  const tcMaskele = (s) => String(s).replace(/\b([1-9]\d{2})\d{6}(\d{2})\b/g, "$1******$2");
  // Tüm eklenti verilerini sil (profil, ayarlar, rapor listesi, günlük, KVKK onayı dahil)
  async function tumVerileriSil() { const LIS = "ea_lisans_eokul_v1"; const l = await chrome.storage.local.get(LIS); await chrome.storage.local.clear(); if (l[LIS]) await chrome.storage.local.set(l); try { await chrome.storage.session.clear(); } catch (e) {} } // v2.6.0: lisans kaydı korunur (öğrenci verisi değildir)
  const MODUL_ADI = { rapor: "Rapor otomasyonu", devamsizlik: "Devamsızlık (yoklama) otomasyonu", oyss: "OYSS not girişi" };
  kok.OkulProfil = { VARSAYILAN_SINIFLAR, VARSAYILAN_KURUMLAR, KILIT_OMUR_MS, profilOku, profilYaz, kilitDurumu, MODUL_ADI, kvkkOnayli, tcMaskele, tumVerileriSil };
})(globalThis);
