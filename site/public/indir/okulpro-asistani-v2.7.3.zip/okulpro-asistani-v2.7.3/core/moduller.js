// Okul Pro Devamsızlık Rapor Asistanı — modül kayıt noktası (genişletme noktası).
// Her modül, başlatıcıya (launcher.js) bir sekme olarak eklenmek için şunu çağırır:
//   EOA.modulKaydet({ id, ad, simge, sira, kur(alan, yardimci) })
// kur(): sekme ilk açıldığında bir kez çağrılır; "alan" sekmenin içerik kutusudur (gölge DOM içinde).
"use strict";
(function (kok) {
  const EOA = kok.EOA || (kok.EOA = {});
  EOA.MARKA = { ad: "Okul Pro Devamsızlık Rapor Asistanı", yazar: "Eyüp Şeker" };
  EOA.moduller = EOA.moduller || [];
  EOA.modulKaydet = (m) => { if (!EOA.moduller.some((x) => x.id === m.id)) EOA.moduller.push(m); };
})(globalThis);
