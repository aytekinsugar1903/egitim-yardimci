// Okul Pro Devamsızlık Rapor Asistanı — tek başlatıcı: sol altta balon, tıklayınca modül sekmeli, taşınabilir panel (gölge DOM).
(() => {
  if (window !== window.top || document.getElementById("eoa-host")) return;
  const KEY = "panelKonum231"; // v2.3.1: eski (büyük) kayıtlı boyut yok sayılır
  const SURUM = chrome.runtime.getManifest().version;
  const host = document.createElement("div");
  host.id = "eoa-host";
  host.style.cssText = "all:initial;position:fixed;left:0;top:0;width:0;height:0;z-index:2147483647;";
  const kok = host.attachShadow({ mode: "open" });
  kok.innerHTML = `
    <style>
      .balon{position:fixed;left:12px;bottom:12px;width:52px;height:52px;border-radius:14px;background:#1a73e8 url(${chrome.runtime.getURL("icons/icon48.png")}) center/40px no-repeat;
        cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.4)}
      .kutu{position:fixed;width:420px;height:560px;min-width:300px;min-height:200px;max-width:100vw;max-height:80vh;box-sizing:border-box;background:#fff;border:1px solid #1a73e8;
        border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.35);display:none;flex-direction:column;overflow:hidden;resize:both;font:13px Arial,sans-serif}
      .kutu.acik{display:flex}
      .kutu.kucuk{height:auto!important;min-height:0;resize:none}.kutu.kucuk>:not(.baslik){display:none!important}
      .dugmeler{display:flex;gap:2px}
      .tutamak{position:absolute;top:0;bottom:0;width:8px;cursor:ew-resize;background:#ff9800;opacity:.85;z-index:5}.tutamak:hover{opacity:1}
      .tutamak.sol{left:0}.tutamak.sag{right:0}.kutu.kucuk .tutamak{display:none!important}
      .kutu{padding:0 8px}
      .baslik{background:#1a73e8;color:#fff;font:600 13px Arial,sans-serif;padding:6px 8px;cursor:move;display:flex;justify-content:space-between;align-items:center;user-select:none;flex:none}
      .baslik img{width:18px;height:18px;vertical-align:middle;margin-right:6px}
      .kapat{cursor:pointer;padding:0 6px;font-size:16px;line-height:1}
      .sekmeler{display:flex;flex-wrap:wrap;background:#e8f0fe;flex:none;border-bottom:1px solid #c6dafc}
      .sekme{padding:7px 10px;cursor:pointer;font:600 12px Arial;color:#1a4fa0;border-bottom:3px solid transparent}
      .sekme.secili{border-bottom-color:#1a73e8;background:#fff}
      .icerik{flex:1;overflow:auto;background:#fff;color:#222}
      .sayfa{display:none}.sayfa.secili{display:block}
      .alt{flex:none;font:11px Arial;color:#666;padding:4px 8px;border-top:1px solid #eee;display:flex;justify-content:space-between}
      .kvkk{background:#fff3cd;padding:8px;font:12px Arial;border-bottom:1px solid #e0c060}
      .kvkk button{margin-left:6px}
      .panelkok{font:13px/1.4 Arial,sans-serif;margin:10px}
      .panelkok button{padding:5px 10px;margin:4px 4px 4px 0;cursor:pointer;border:1px solid #888;background:#f4f4f4;border-radius:3px}
      .panelkok button.ana{background:#1a73e8;color:#fff;border-color:#1a73e8}.panelkok .not{color:#555;font-size:12px}
    </style>
    <div class="balon" title="Okul Pro Devamsızlık Rapor Asistanı"></div>
    <div class="kutu">
      <div class="baslik"><span><img src="${chrome.runtime.getURL("icons/icon32.png")}">Okul Pro</span><span class="dugmeler"><span class="kapat yasla" data-yon="sol" title="Sola yasla">◀</span><span class="kapat yasla" data-yon="sag" title="Sağa yasla">▶</span><span class="kapat kucult" title="Küçült / büyüt">−</span><span class="kapat sifirla" title="Konumu ve boyutu sıfırla">⟲</span><span class="kapat gizle" title="Kapat (balona dön)">×</span></span></div>
      <div class="kvkk" hidden>KVKK bilgilendirmesi henüz onaylanmadı; otomasyonlar kapalı. <button class="kvkkAc">Oku ve onayla</button></div>
      <div class="sekmeler"></div>
      <div class="icerik"></div>
      <div class="tutamak sol" title="Sağa sola çekerek genişlet/daralt"></div><div class="tutamak sag" title="Sağa sola çekerek genişlet/daralt"></div>
      <div class="alt"><span>v${SURUM}</span><span>© Eyüp Şeker</span></div>
    </div>`;
  document.documentElement.appendChild(host);

  const kutu = kok.querySelector(".kutu"), balon = kok.querySelector(".balon");
  const baslik = kok.querySelector(".baslik"), sekmeler = kok.querySelector(".sekmeler"), icerik = kok.querySelector(".icerik");
  const VARSAYILAN = { left: null, top: 12, w: 420, h: 560, acik: false, kucuk: false, sekme: "rapor" };
  let konum = { ...VARSAYILAN };
  let zamanlayici;
  const gonder = (m) => { try { chrome.runtime.sendMessage(m); } catch (e) { alert("Eklenti güncellendi; sayfayı yenileyin (F5)."); } };

  // Yerleşik sekmeler: Okul ayarları ve Hakkında
  EOA.modulKaydet({ id: "ayarlar", ad: "Okul ayarları", simge: "🏫", sira: 90, kur(alan) {
    alan.innerHTML = `<div class="panelkok"><h2>Okul ayarları</h2>
      <p class="not">Şube listesi, rapor Açıklama listesi, bekleme süreleri, sevk süresi, gizlilik (KVKK) ayarları ve okul profili aktarımı.</p>
      <button class="ana">Okul ayarlarını aç</button></div>`;
    alan.querySelector("button").onclick = () => gonder({ tip: "okulAyarlariAc" });
  } });
  EOA.modulKaydet({ id: "hakkinda", ad: "Hakkında", simge: "ℹ", sira: 99, kur(alan) {
    alan.innerHTML = `<div class="panelkok"><h2>Okul Pro Devamsızlık Rapor Asistanı</h2>
      <p>Sürüm ${SURUM}<br>Geliştiren: <b>Eyüp Şeker</b></p>
      <p class="not">Tüm işlemler bu bilgisayarda, tarayıcının içinde yapılır; öğrenci verisi bir sunucuya gönderilmez (yalnız lisans doğrulaması: anahtar, kurum kodu, kurulum kimliği, ürün, sürüm).</p>
      <button class="kv">KVKK bilgilendirmesi</button></div>`;
    alan.querySelector(".kv").onclick = () => gonder({ tip: "kvkkAc" });
  } });

  const kurulan = new Set();
  function sekmeCiz() {
    const liste = [...EOA.moduller].sort((a, b) => a.sira - b.sira);
    sekmeler.innerHTML = ""; 
    for (const m of liste) {
      const s = document.createElement("div");
      s.className = "sekme" + (m.id === konum.sekme ? " secili" : ""); s.textContent = `${m.simge} ${m.ad}`;
      s.onclick = () => { konum.sekme = m.id; kaydet(); sekmeCiz(); };
      sekmeler.append(s);
      let sayfa = icerik.querySelector(`[data-modul="${m.id}"]`);
      if (!sayfa) { sayfa = document.createElement("div"); sayfa.className = "sayfa"; sayfa.dataset.modul = m.id; icerik.append(sayfa); }
      sayfa.classList.toggle("secili", m.id === konum.sekme);
      if (m.id === konum.sekme && konum.acik && !kurulan.has(m.id)) {
        kurulan.add(m.id);
        Promise.resolve().then(() => m.kur(sayfa)).catch((e) => { kurulan.delete(m.id); sayfa.textContent = "Modül yüklenemedi: " + e.message + " (sayfayı F5 ile yenileyin)"; });
      }
    }
  }

  function kaydet() {
    clearTimeout(zamanlayici);
    zamanlayici = setTimeout(() => { try { chrome.storage.local.set({ [KEY]: konum }); } catch (e) {} }, 300);
  }
  function uygula() {
    konum.w = Math.min(Math.max(300, +konum.w || 420), Math.max(300, innerWidth));
    if (konum.taraf === "sol") konum.left = 0; else if (konum.taraf === "sag") konum.left = innerWidth - konum.w;
    konum.h = Math.min(Math.max(200, +konum.h || 560), Math.round(innerHeight * 0.8));
    kutu.style.width = konum.w + "px"; kutu.style.height = konum.h + "px";
    const left = konum.left ?? (innerWidth - konum.w - 12); // varsayılan: sağa yaslı
    const top = konum.top ?? 12;
    kutu.style.left = Math.min(Math.max(0, left), Math.max(0, innerWidth - 80)) + "px";
    kutu.style.top = Math.min(Math.max(0, top), Math.max(0, innerHeight - 40)) + "px";
    kutu.classList.toggle("acik", konum.acik);
    kutu.classList.toggle("kucuk", !!konum.kucuk);
    kok.querySelector(".kucult").textContent = konum.kucuk ? "▢" : "−";
    balon.style.display = konum.acik ? "none" : "block";
    sekmeCiz();
  }
  function degistir(ac) { konum.acik = ac ?? !konum.acik; uygula(); kaydet(); }

  balon.addEventListener("click", () => degistir(true));
  kok.querySelector(".gizle").addEventListener("click", () => degistir(false));
  kok.querySelector(".kucult").addEventListener("click", () => { konum.kucuk = !konum.kucuk; uygula(); kaydet(); });
  kok.querySelector(".sifirla").addEventListener("click", () => { konum = { ...VARSAYILAN, acik: true, sekme: konum.sekme }; uygula(); kaydet(); });
  kok.querySelectorAll(".yasla").forEach((d) => d.addEventListener("click", () => {
    konum.left = d.dataset.yon === "sol" ? 0 : innerWidth - konum.w; konum.taraf = d.dataset.yon; uygula(); kaydet();
  }));
  kok.querySelectorAll(".tutamak").forEach((t) => t.addEventListener("mousedown", (e) => {
    const solMu = t.classList.contains("sol"), sx = e.clientX, ow = kutu.offsetWidth, ol = kutu.offsetLeft;
    const tasi = (ev) => {
      const dx = ev.clientX - sx;
      const w = Math.min(Math.max(300, solMu ? ow - dx : ow + dx), innerWidth);
      konum.w = w; konum.left = solMu ? ol + ow - w : ol; konum.taraf = null; uygula();
    };
    const birak = () => { window.removeEventListener("mousemove", tasi, true); window.removeEventListener("mouseup", birak, true); kaydet(); };
    window.addEventListener("mousemove", tasi, true); window.addEventListener("mouseup", birak, true);
    e.preventDefault(); e.stopPropagation();
  }));
  baslik.addEventListener("dblclick", (e) => { if (e.target.closest(".kapat")) return; konum.kucuk = !konum.kucuk; uygula(); kaydet(); });
  kok.querySelector(".kvkkAc").addEventListener("click", () => gonder({ tip: "kvkkAc" }));
  baslik.addEventListener("mousedown", (e) => {
    if (e.target.closest(".kapat")) return;
    const sx = e.clientX, sy = e.clientY, ox = kutu.offsetLeft, oy = kutu.offsetTop;
    const tasi = (ev) => { konum.taraf = null; konum.left = ox + ev.clientX - sx; konum.top = oy + ev.clientY - sy; uygula(); };
    const birak = () => { window.removeEventListener("mousemove", tasi, true); window.removeEventListener("mouseup", birak, true); kaydet(); };
    window.addEventListener("mousemove", tasi, true); window.addEventListener("mouseup", birak, true);
    e.preventDefault();
  });
  new ResizeObserver(() => { if (!konum.acik || konum.kucuk) return; konum.w = kutu.offsetWidth; konum.h = kutu.offsetHeight; kaydet(); }).observe(kutu);
  window.addEventListener("resize", uygula);

  const kvkkGoster = async () => { kok.querySelector(".kvkk").hidden = await OkulProfil.kvkkOnayli(); };
  try {
    chrome.runtime.onMessage.addListener((m) => { if (m && m.tip === "degistir") degistir(); });
    chrome.storage.onChanged.addListener((c) => { if (c.kvkkOnay) kvkkGoster(); });
    chrome.storage.local.get(KEY).then((r) => { if (r[KEY]) konum = { ...konum, ...r[KEY] }; uygula(); });
    kvkkGoster();
  } catch (e) { uygula(); }
})();
