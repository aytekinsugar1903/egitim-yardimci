// v2.4.1 — T.C. kasası sayfası (oluştur / aç / kilitle / parola değiştir / sıfırla)
"use strict";
const $ = (s) => document.querySelector(s);
const K = globalThis.EOAKasa;
const mesaj = (m, kotu) => { $("#mesaj").textContent = m; $("#mesaj").className = kotu ? "kotu" : "iyi"; };
const temizle = () => document.querySelectorAll("input[type=password]").forEach((i) => { i.value = ""; });
async function calisiyorMu() { try { const r = await chrome.storage.local.get("durum"); return !!(r.durum && r.durum.calisiyor); } catch (e) { return false; } }
async function ciz() {
  const d = await K.durumBilgisi();
  $("#durumYazi").textContent = !d.kurulu ? "Kurulmadı — T.C. içeren rapor satırları için önce kasa oluşturun" : d.acik ? "Açık" : "Kilitli";
  $("#durumYazi").className = d.acik ? "iyi" : "kotu";
  $("#kurBolum").hidden = d.kurulu; $("#acBolum").hidden = !d.kurulu || d.acik; $("#acikBolum").hidden = !d.acik; $("#sifirBolum").hidden = !d.kurulu || d.acik;
  if (!d.acik && d.kurulu) $("#pa").focus(); else if (!d.kurulu) $("#p1").focus();
}
async function is(fn, basari) {
  document.querySelectorAll("button").forEach((b) => { b.disabled = true; });
  mesaj("İşleniyor…");
  try { const n = await fn(); mesaj(basari(n)); } catch (e) { mesaj(e && e.message ? e.message : String(e), true); }
  finally { temizle(); document.querySelectorAll("button").forEach((b) => { b.disabled = false; }); await ciz(); }
}
$("#olustur").onclick = () => is(async () => { if ($("#p1").value !== $("#p2").value) throw new Error("Parolalar aynı değil."); return K.olustur($("#p1").value); },
  (n) => `Kasa oluşturuldu ve açıldı.${n ? ` Depodaki ${n} düz T.C. şifrelendi.` : ""}`);
$("#ac").onclick = () => is(() => K.ac($("#pa").value), (n) => `Kasa açıldı.${n ? ` Eski sürümden kalan ${n} düz T.C. şifrelendi, düz hâli silindi.` : ""}`);
$("#pa").addEventListener("keydown", (e) => { if (e.key === "Enter") $("#ac").click(); });
$("#kilitle").onclick = () => is(async () => { if (await calisiyorMu()) throw new Error("Otomasyon çalışıyor; önce Durdur'a basın."); await K.kilitle(); }, () => "Kasa kilitlendi.");
$("#degistir").onclick = () => is(async () => { if ($("#pn1").value !== $("#pn2").value) throw new Error("Yeni parolalar aynı değil."); return K.parolaDegistir($("#pe").value, $("#pn1").value); }, () => "Parola değiştirildi; T.C.'ler yeni anahtarla şifrelendi.");
$("#sifirla").onclick = () => { if (!confirm("Kasa sıfırlansın mı? Şifreli T.C.'ler kalıcı olarak silinir.")) return; is(() => K.sifirla(), () => "Kasa sıfırlandı. Yeni kasa oluşturun."); };
ciz();
