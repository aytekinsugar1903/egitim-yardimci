// v2.4.1 — T.C. kasası (KVKK). Öğrenci T.C. kimlik numaraları chrome.storage.local'da DÜZ METİN tutulmaz.
// Yöntem: kasa parolası -> PBKDF2-SHA256 (210.000 tur, 16 bayt tuz) -> AES-GCM 256 anahtar; her T.C. 12 bayt rastgele IV ile şifrelenir.
// Anahtar yalnız chrome.storage.session'da (bellek; tarayıcı kapanınca silinir) durur; parola hiçbir yere yazılmaz.
// Uygulama kodu değişmeden çalışsın diye "durum", "sonRapor" ve "log" anahtarları için chrome.storage.local get/set ve
// storage.onChanged bu dosyada sarılır: yazarken 11 haneli T.C. -> satir.tcS (şifreli), satir.tc = ""; okurken kasa açıksa geri çözülür.
// Kasa kilitliyken T.C. alanı boş gelir (tcS korunur); kasa kurulmamış/kilitliyken gelen düz T.C. DEPOYA YAZILMAZ (satır KONTROL + uyarı).
(function (kok) {
  "use strict";
  if (kok.EOAKasa) return;
  const KASA = "tcKasa", OTURUM = "tcKasaAnahtar", ITER = 210000, ON = "k1:";
  const KORUNAN = ["durum", "sonRapor", "log"];
  const DOGRULAMA = "eokul-asistani-kasa-v1";
  const ch = typeof chrome !== "undefined" ? chrome : null;
  const depo = ch && ch.storage && ch.storage.local ? ch.storage.local : null;
  const ham = depo ? { get: depo.get.bind(depo), set: depo.set.bind(depo) } : null;
  const enc = new TextEncoder(), dec = new TextDecoder();
  const b64 = (u) => { let s = ""; const a = new Uint8Array(u); for (let i = 0; i < a.length; i++) s += String.fromCharCode(a[i]); return btoa(s); };
  const un64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  const TC_DESEN = /^\d{11}$/;
  const maske = (tc) => { const s = String(tc ?? ""); return TC_DESEN.test(s) ? s.slice(0, 3) + "******" + s.slice(-2) : s; };
  const metinMaskele = (s) => typeof s === "string" ? s.replace(/(^|\D)(\d{3})\d{6}(\d{2})(?!\d)/g, "$1$2******$3") : s;
  const MASKE_DESEN = /^\d{3}\*{6}\d{2}$/;

  // ---- anahtar ----
  let anahtar = null, anahtarB64 = null;
  const sifreOn = new Map(), cozOn = new Map(); // aynı oturumda aynı değer için tekrar şifreleme/çözme yapılmaz
  async function oturumOku() {
    try { if (!ch || !ch.storage || !ch.storage.session) return null; return (await ch.storage.session.get(OTURUM))[OTURUM] || null; }
    catch (e) { return null; } // içerik betiğine oturum erişimi verilmemişse kasa kilitli sayılır
  }
  async function anahtarAl() {
    const b = await oturumOku();
    if (!b) { anahtar = null; anahtarB64 = null; sifreOn.clear(); cozOn.clear(); return null; }
    if (b !== anahtarB64) {
      anahtar = await crypto.subtle.importKey("raw", un64(b), { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
      anahtarB64 = b; sifreOn.clear(); cozOn.clear();
    }
    return anahtar;
  }
  async function turet(parola, tuz, iter) {
    const m = await crypto.subtle.importKey("raw", enc.encode(parola), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey({ name: "PBKDF2", salt: tuz, iterations: iter, hash: "SHA-256" }, m, { name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"]);
  }
  async function sifreleK(metin, k) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const c = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, k, enc.encode(metin));
    return ON + b64(iv) + ":" + b64(c);
  }
  async function cozK(jeton, k) {
    const [iv, c] = String(jeton).slice(ON.length).split(":");
    return dec.decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: un64(iv) }, k, un64(c)));
  }
  async function tcSifrele(tc, k) { if (sifreOn.has(tc)) return sifreOn.get(tc); const j = await sifreleK(tc, k); sifreOn.set(tc, j); cozOn.set(j, tc); return j; }
  async function tcCoz(j, k) { if (cozOn.has(j)) return cozOn.get(j); const t = await cozK(j, k); cozOn.set(j, t); if (!sifreOn.has(t)) sifreOn.set(t, j); return t; }

  // ---- satır / değer dönüşümü ----
  const kopya = (v) => (typeof structuredClone === "function" ? structuredClone(v) : JSON.parse(JSON.stringify(v)));
  async function satirSifrele(s, k, kurulu) {
    if (!s || typeof s !== "object") return s;
    for (const a of ["uyari", "sonuc"]) if (typeof s[a] === "string") s[a] = metinMaskele(s[a]);
    if (typeof s.tc !== "string" && typeof s.tc !== "number") return s;
    const t = String(s.tc).replace(/\s/g, "");
    if (!TC_DESEN.test(t)) return s; // okul no (≤6 hane), maskeli değer, boş: olduğu gibi
    if (k) { s.tcS = await tcSifrele(t, k); s.tc = ""; return s; }
    // Kasa hiç kurulmamışsa (eski sürümden kalan veri): olduğu gibi kalır; kasa ilk açılışta şifreler ve düzü siler.
    // Yeni düz T.C. girişi arayüzde kasa açık olmadan engellenir (tarama Aktar, içe alma, elle T.C.).
    if (kurulu === false) return s;
    // kasa kurulu ama kilitli: düz T.C. yazılmaz
    s.tc = ""; delete s.tcS; s.tcYazilmadi = true;
    if (s.durum === "HAZIR") s.durum = "KONTROL";
    s.sari = true; s.uyari = "T.C. kaydedilmedi: T.C. kasası kilitli/kurulmamış. Kasayı açıp T.C.'yi yeniden girin" + (s.uyari ? " · " + s.uyari : "");
    return s;
  }
  async function satirCoz(s, k) {
    if (!s || typeof s !== "object" || typeof s.tcS !== "string") return s;
    if (!k) { s.tc = ""; return s; } // kilitli: tcS korunur, T.C. görünmez
    try { s.tc = await tcCoz(s.tcS, k); delete s.tcS; } catch (e) { s.tc = ""; } // başka kasanın verisi: dokunma
    return s;
  }
  async function degerSifrele(ad, v, k, kurulu) {
    if (v == null) return v;
    if (ad === "log") return Array.isArray(v) ? v.map(metinMaskele) : metinMaskele(v);
    if (ad === "durum") { if (Array.isArray(v.satirlar)) for (const s of v.satirlar) await satirSifrele(s, k, kurulu); if (typeof v.sonHata === "string") v.sonHata = metinMaskele(v.sonHata); return v; }
    if (ad === "sonRapor") { if (Array.isArray(v.satirlar)) for (const s of v.satirlar) await satirSifrele(s, k, kurulu); return v; }
    return v;
  }
  async function degerCoz(ad, v, k) {
    if (v == null || ad === "log") return v;
    if ((ad === "durum" || ad === "sonRapor") && Array.isArray(v.satirlar)) for (const s of v.satirlar) await satirCoz(s, k);
    return v;
  }

  // ---- chrome.storage.local sarmalayıcı (yalnız korunan anahtarlar) ----
  if (ham) {
    depo.get = async function (anahtarlar, geri) {
      const r = await ham.get(anahtarlar);
      if (KORUNAN.some((a) => r && a in r)) { const k = await anahtarAl(); for (const a of KORUNAN) if (a in r) r[a] = await degerCoz(a, r[a], k); }
      if (typeof geri === "function") geri(r);
      return r;
    };
    depo.set = async function (o, geri) {
      let yaz = o;
      if (o && KORUNAN.some((a) => a in o)) {
        const k = await anahtarAl(), kurulu = k ? true : !!(await ham.get(KASA))[KASA]; yaz = { ...o };
        for (const a of KORUNAN) if (a in o) yaz[a] = await degerSifrele(a, kopya(o[a]), k, kurulu);
      }
      const r = await ham.set(yaz);
      if (typeof geri === "function") geri();
      return r;
    };
    const oc = ch.storage.onChanged;
    if (oc && oc.addListener) {
      const ekle = oc.addListener.bind(oc), cikar = oc.removeListener ? oc.removeListener.bind(oc) : null, sarili = new Map();
      oc.addListener = function (fn) {
        let sira = Promise.resolve();
        const s = (degisim, alan) => {
          if (alan !== "local" || !KORUNAN.some((a) => a in degisim)) { sira = sira.then(() => fn(degisim, alan)).catch(() => {}); return; }
          sira = sira.then(async () => {
            const k = await anahtarAl();
            for (const a of KORUNAN) if (a in degisim) { const d = degisim[a];
              if (d.newValue !== undefined) d.newValue = await degerCoz(a, d.newValue, k);
              if (d.oldValue !== undefined) d.oldValue = await degerCoz(a, d.oldValue, k); }
            return fn(degisim, alan);
          }).catch(() => {});
        };
        sarili.set(fn, s); return ekle(s);
      };
      if (cikar) oc.removeListener = function (fn) { const s = sarili.get(fn); sarili.delete(fn); return cikar(s || fn); };
    }
  }

  // ---- kasa yönetimi (yalnız eklenti sayfaları: kasa.html) ----
  async function kasaBilgi() { if (!ham) return null; return (await ham.get(KASA))[KASA] || null; }
  async function durumBilgisi() { const kb = await kasaBilgi(); const k = await anahtarAl(); return { kurulu: !!kb, acik: !!(kb && k) }; }
  async function acikMi() { return !!(await kasaBilgi()) && !!(await anahtarAl()); }
  const parolaUygun = (p) => typeof p === "string" && p.length >= 10;
  async function oturumaYaz(k) { const raw = await crypto.subtle.exportKey("raw", k); await ch.storage.session.set({ [OTURUM]: b64(raw) }); await anahtarAl(); }
  // Göç: depodaki düz T.C.'leri şifrele, günlükleri maskele (ilk açılışta ve parola değişiminde)
  async function goc(eskiK) {
    const k = await anahtarAl(); if (!k) throw new Error("Kasa açık değil");
    const r = await ham.get(KORUNAN), yaz = {}; let sayi = 0;
    for (const a of KORUNAN) {
      if (!(a in r)) continue; const v = r[a];
      if (eskiK && v && Array.isArray(v.satirlar)) for (const s of v.satirlar) if (s && typeof s.tcS === "string") { try { s.tc = await cozK(s.tcS, eskiK); delete s.tcS; } catch (e) {} }
      if (v && Array.isArray(v.satirlar)) sayi += v.satirlar.filter((s) => s && TC_DESEN.test(String(s.tc ?? "").replace(/\s/g, ""))).length;
      yaz[a] = await degerSifrele(a, v, k, true);
    }
    if (Object.keys(yaz).length) await ham.set(yaz);
    return sayi;
  }
  async function olustur(parola) {
    if (!parolaUygun(parola)) throw new Error("Kasa parolası en az 10 karakter olmalı.");
    if (await kasaBilgi()) throw new Error("Kasa zaten kurulu.");
    const tuz = crypto.getRandomValues(new Uint8Array(16)), k = await turet(parola, tuz, ITER);
    await ham.set({ [KASA]: { surum: 1, yontem: "PBKDF2-SHA256/AES-GCM-256", tur: ITER, tuz: b64(tuz), dogrulama: await sifreleK(DOGRULAMA, k), tarih: new Date().toISOString() } });
    await oturumaYaz(k);
    return goc(null);
  }
  async function ac(parola) {
    const kb = await kasaBilgi(); if (!kb) throw new Error("Kasa kurulu değil.");
    const k = await turet(parola, un64(kb.tuz), kb.tur || ITER);
    try { if ((await cozK(kb.dogrulama, k)) !== DOGRULAMA) throw 0; } catch (e) { throw new Error("Kasa parolası yanlış."); }
    await oturumaYaz(k);
    return goc(null);
  }
  async function kilitle() { try { await ch.storage.session.remove(OTURUM); } catch (e) {} await anahtarAl(); }
  async function parolaDegistir(eski, yeni) {
    if (!parolaUygun(yeni)) throw new Error("Yeni parola en az 10 karakter olmalı.");
    const kb = await kasaBilgi(); if (!kb) throw new Error("Kasa kurulu değil.");
    const ek = await turet(eski, un64(kb.tuz), kb.tur || ITER);
    try { if ((await cozK(kb.dogrulama, ek)) !== DOGRULAMA) throw 0; } catch (e) { throw new Error("Eski parola yanlış."); }
    const tuz = crypto.getRandomValues(new Uint8Array(16)), k = await turet(yeni, tuz, ITER);
    await ham.set({ [KASA]: { ...kb, tur: ITER, tuz: b64(tuz), dogrulama: await sifreleK(DOGRULAMA, k), tarih: new Date().toISOString() } });
    await oturumaYaz(k);
    return goc(ek);
  }
  // Parola unutulduysa: kasa ve şifreli T.C.'ler silinir (satırlar kalır, T.C. alanı boş + KONTROL)
  async function sifirla() {
    const r = await ham.get(KORUNAN), yaz = {};
    for (const a of ["durum", "sonRapor"]) { const v = r[a]; if (!v || !Array.isArray(v.satirlar)) continue;
      v.satirlar.forEach((s) => { if (s && typeof s.tcS === "string") { delete s.tcS; s.tc = ""; if (s.durum === "HAZIR") s.durum = "KONTROL"; s.sari = true; s.uyari = "Kasa sıfırlandı: T.C.'yi yeniden girin"; } });
      yaz[a] = v; }
    if (Object.keys(yaz).length) await ham.set(yaz);
    await ch.storage.local.remove(KASA); await kilitle();
  }
  // Bekleyen düz T.C. var mı (test/denetim için; değerleri döndürmez)
  async function duzTcSay() { const r = await ham.get(KORUNAN); let n = 0; const ara = (v) => { const j = JSON.stringify(v || ""); const m = j.match(/(?<![\w+\/])\d{11}(?![\w+\/=])/g); return m ? m.length : 0; }; for (const a of KORUNAN) n += ara(r[a]); return n; }

  kok.EOAKasa = { KASA, OTURUM, ITER, maske, metinMaskele, MASKE_DESEN, TC_DESEN, durumBilgisi, acikMi, kasaBilgi, olustur, ac, kilitle, parolaDegistir, sifirla, duzTcSay,
    _ic: { satirSifrele, satirCoz, degerSifrele, degerCoz, sifreleK, cozK, turet } };
})(typeof globalThis !== "undefined" ? globalThis : this);
