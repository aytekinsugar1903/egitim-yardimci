# [ŞABLON] Kişisel Veri İşleme Envanteri — Örnek Satır
> **Şablondur**, hukuki görüş değildir; okulunuzun KVKK irtibat kişisince uyarlanmalıdır.

| Alan | Örnek değer |
|---|---|
| Süreç | Öğrenci sağlık raporu / sevk belgesinin e-Okul'a işlenmesi |
| Birim | Müdür yardımcılığı / e-Okul veri giriş sorumlusu |
| Veri konusu kişi grubu | Öğrenci |
| Veri kategorileri | Kimlik (TC, ad soyad), Sağlık bilgisi (rapor tarihi, süresi, kurum, rapor/sevk türü) |
| Özel nitelikli mi? | Evet (sağlık) |
| Amaç | Özürlü devamsızlığın e-Okul'a kaydı |
| Hukuki sebep | [KVKK sorumlusunca belirlenecek] |
| Veri kaynağı | Velinin/öğrencinin teslim ettiği belge |
| Kullanılan araç | Okul Pro Devamsızlık Rapor Asistanı (tarayıcı eklentisi, yerel çalışır, uzak sunucu yok) |
| Saklama yeri | Basılı dosya: [arşiv]; taranmış PDF: [klasör/bilgisayar]; eklenti deposu: aynı bilgisayar, başarılı girişten sonra silinir |
| Saklama süresi | [politika süresi] |
| Alıcı / aktarım | MEB e-Okul (yurt içi). Yurt dışı aktarım yok |
| Teknik tedbirler | Kurum bilgisayarı, kullanıcı oturumu, eklentide yerel işleme, TC maskeli günlük, otomatik silme, "Tüm verileri sil" |
| İdari tedbirler | Kullanım taahhütnamesi, yetkili personel listesi, aydınlatma metni |
