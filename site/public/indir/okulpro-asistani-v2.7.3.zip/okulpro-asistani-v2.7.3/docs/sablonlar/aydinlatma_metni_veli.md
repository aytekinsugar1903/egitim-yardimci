# [ŞABLON] Öğrenci Sağlık Raporlarının İşlenmesine İlişkin Aydınlatma Metni (Veliler İçin)
> Bu metin bir **şablondur**, hukuki görüş değildir. Okulunuzun KVKK irtibat kişisi / hukuk birimi tarafından gözden geçirilmeden kullanmayınız. Köşeli parantezleri doldurunuz.

**Veri sorumlusu:** [Okul adı] Müdürlüğü, [adres], [e-posta / KEP], [telefon]

6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") uyarınca, öğrencimize ait aşağıdaki kişisel veriler bu metinde açıklanan amaç ve şekilde işlenmektedir.

**1. İşlenen veriler:** T.C. kimlik numarası, ad soyad, sınıf/şube; okula teslim edilen sağlık raporu veya sevk belgesindeki rapor/sevk tarihi, istirahat süresi, belgeyi düzenleyen sağlık kuruluşu (sağlık verisi – özel nitelikli kişisel veri).

**2. İşleme amacı:** Öğrencinin özürlü devamsızlığının e-Okul Yönetim Bilgi Sistemine kaydedilmesi ve devam-devamsızlık işlemlerinin mevzuata uygun yürütülmesi.

**3. Hukuki sebep:** [Okulunuzun KVKK sorumlusunca belirlenecek; ör. KVKK md. 6 kapsamında kanunlarda öngörülme / hukuki yükümlülüğün yerine getirilmesi; ilgili MEB yönetmelik hükümleri.]

**4. İşleme yöntemi:** Teslim edilen belgeler okulda taranır; okulun bilgisayarındaki tarayıcı eklentisi ile **yalnızca o bilgisayarda, internete veya üçüncü kişilere gönderilmeden** okunur ve görevli personelin kontrolünden sonra e-Okul'a girilir. Eklentide kalan bilgiler, e-Okul'a girişten sonra silinir.

**5. Aktarım:** Veriler, mevzuat gereği e-Okul sistemi (Millî Eğitim Bakanlığı) dışında kimseye aktarılmaz.

**6. Saklama süresi:** Basılı/taranmış belgeler [okulun saklama-imha politikasındaki süre] boyunca saklanır ve süre sonunda imha edilir.

**7. Haklarınız:** KVKK md. 11 kapsamındaki haklarınız için [başvuru yöntemi/adresi] üzerinden başvurabilirsiniz.

[Tarih] — [Okul Müdürü adı, imza]
