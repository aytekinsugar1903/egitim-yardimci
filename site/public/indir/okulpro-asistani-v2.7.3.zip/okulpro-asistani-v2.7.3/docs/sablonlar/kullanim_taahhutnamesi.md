# [ŞABLON] Okul Pro Devamsızlık Rapor Asistanı Kullanım Taahhütnamesi
> **Şablondur**, hukuki görüş değildir; okulunuzun KVKK irtibat kişisince uyarlanmalıdır.

[Okul adı] Müdürlüğünde e-Okul veri girişiyle görevli olarak, "Okul Pro Devamsızlık Rapor Asistanı" tarayıcı eklentisini kullanırken:

1. Eklentiyi yalnızca görevim kapsamında, okulun bana tahsis ettiği bilgisayarda kullanacağımı,
2. Öğrenci sağlık raporlarını ve bunlardan elde edilen bilgileri (TC, ad soyad, rapor bilgileri) görevim dışında kullanmayacağımı, kopyalamayacağımı, kimseyle paylaşmayacağımı,
3. Eklentiden indirilen CSV/Excel/PDF dosyalarını ve taranmış belgeleri okulun belirlediği klasörde saklayacağımı, işim bitince [politika]ya göre sileceğimi,
4. Eklentinin "başarılı girişten sonra otomatik sil" ayarını kapatmayacağımı; görev değişikliğinde veya bilgisayar devrinde **Tüm verileri sil** işlemini yapacağımı,
5. Destek amacıyla günlük paylaşmam gerekirse yalnızca maskeli günlüğü paylaşacağımı, rapor görüntüsü paylaşmayacağımı,
6. Bir veri ihlali şüphesinde derhal [KVKK irtibat kişisi]ne bildireceğimi

taahhüt ederim.

Ad Soyad: ……………… Görevi: ……………… Tarih: ……………… İmza: ………………
