# Okul Pro Devamsızlık Rapor Asistanı

**Marka: Evrak Asistanı**

**Geliştiren: Eyüp Şeker** · Sürüm 2.7.3 · Chrome / Edge (Manifest V3)

e-Okul'daki zaman alıcı işleri otomatikleştiren tarayıcı eklentisi. Resmî bir MEB ürünü değildir.

Kapsam: devamsızlık, sağlık raporu, faaliyet formu, veli izni ve not girişi/OYSS.

| Modül | Ne yapar |
|---|---|
| 📄 **Rapor** | Haftalık toplu taranan sağlık raporlarını / sevk belgelerini **çevrimdışı Türkçe OCR** ile okur, TC kimlik numarasına göre öğrencilere ayırır, başlangıç tarihi, gün sayısı, tür (Raporlu/Sevkli) ve kurumu çıkarır; kontrolünüzden sonra e-Okul *Özürlü Devamsızlık* ekranına işler. |
| 📝 **Veli İzni** | Makine okunur veli izin formlarını (el yazısı okul no + Tam/Yarım kutuları) yerel modelle okur; art arda günleri tek kayıtta birleştirir; e-Okul'a *İzinli* olarak işler. |
| 🏅 **Faaliyet** | Toplu/bireysel faaliyet formlarını okur ya da numara listesiyle toplu ekler; *Faaliyet* nedeniyle işler. |
| 📋 **OYSS** | e-Okul *OYSS Not Girişi* ekranındaki sınıf/ders/şube kutucuklarıyla listeyi tek adımda Excel'e aktarır (`Not Girisi/OYSS/tarih`); soru sayısı ve azami puan şablona yazılır. Doldurulan puanlar ve Katılım Okul No ile eşlenir; sesli giriş ve Excel'den «e-Okul'a yaz» vardır. Kapılar geçilirse «yaz ve Kaydet» Kaydet'e basar (onaylı istisna). Güvenlik Koduna dokunulmaz. |
| ⏱ **Devamsızlık** | Okul ayarlarındaki şubeleri sırayla açar, ders yoklamalarına göre Tam gün / Sabah / Öğle / Geç kutularını mevzuata göre işaretler (günde yalnız 1 ders kaçırılmışsa hangi ders olursa olsun **Geç**) ve kaydeder; sesli/yazılı "123 numara yarım gün" girişi desteklenir. |

Kontrol tablosunda **arama + durum süzgeci + toplu seçim** (HAZIR/KONTROL yap, tür değiştir, sil) ve seçili satırlar için **A4 teslim/imza listesi** yazdırma vardır. Tatil ve arife günleri *Okul ayarları*'ndan düzenlenir.

Tüm işlemler **bilgisayarınızdaki tarayıcıda** yapılır; öğrenci verisi sunucuya, buluta veya yapay zekâya gitmez. Lisans doğrulaması: eklenti ilk açılışta kurum kodu, lisans sözleşmesi ve KVKK onayı ister; 48 saatlik deneme veya lisans anahtarı api.otonomevrak.com üzerinden doğrulanır. Bu doğrulamada yalnızca lisans anahtarı, kurum kodu, rastgele kurulum kimliği, ürün kodu ve sürüm gönderilir; öğrenci, rapor, not veya devamsızlık verisi asla gönderilmez. İmzalı lisans jetonu 7 gün çevrimdışı çalışır. Bkz. [KVKK.md](KVKK.md).

## Kurulum
1. Zip'i bir klasöre çıkarın (klasör adı: `okulpro-asistani-v2.7.3`).
2. Chrome → **⋮ → Uzantılar → Uzantıları yönet** (`chrome://extensions`).
3. Sağ üstten **Geliştirici modu**'nu açın → **Paketlenmemiş öğe yükle** → klasörü seçin.
4. Açılan **KVKK bilgilendirmesini** okuyup onaylayın (onaylanmadan otomasyonlar çalışmaz).
5. e-Okul'a girin; sol altta mavi **pano simgesi** (başlatıcı) görünür. `Ctrl+Shift+E` de paneli açar/kapatır.

Eski "e-Okul Rapor Otomasyonu" veya "e-Okul Devamsızlık Asistanı" eklentileri yüklüyse **kaldırın** (aynı sayfada iki kopya çalışmasın). Eski devamsızlık eklentisindeki şube listesi ilk açılışta otomatik içe alınır.

## Belgeler
- [KULLANIM.md](KULLANIM.md) — adım adım kullanım kılavuzu
- [KVKK.md](KVKK.md) — kişisel veriler, saklama, silme; `docs/sablonlar/` altında okul için şablonlar
- [GELISTIRICI.md](GELISTIRICI.md) — mimari, yeni modül ekleme
- [CHANGELOG.md](CHANGELOG.md) — sürüm geçmişi

## Okul profili (başka okullara kurulum)
Okula özgü her şey (okul adı, şube listesi, rapor Açıklama listesi, bekleme süreleri, sevk süresi, gizlilik seçenekleri, e-Okul ekran metinleri) **Okul ayarları** sayfasındadır. **Okul profilini dışa aktar** ile `.json` dosyası alınır; yeni okulda **Okul profilini içe aktar** ile tek seferde yüklenir. Şube listesi boş bırakılabilir.

© Eyüp Şeker. Üçüncü taraf bileşenler: pdf.js (Apache-2.0), tesseract.js (Apache-2.0), pdf-lib (MIT).
