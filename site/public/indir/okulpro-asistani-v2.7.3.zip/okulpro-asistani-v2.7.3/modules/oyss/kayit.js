// v2.7.0: OYSS sekmesi — Not Girişi Asistanı 1.9.22 kutucuk, tek adım indirme ve sesli giriş.
// Şube sınav durumu ve "… Kapat" düğmesine dokunulmaz. Güvenlik Koduna dokunulmaz.
// Kaydet'e basmak kullanıcı onaylı istisnadır (yalnız "e-Okul'a yaz ve Kaydet").
EOA.modulKaydet({
  id: "oyss", ad: "OYSS", simge: "📋", sira: 13,
  kur(alan) {
    if (typeof NGAOyssHTML !== "function" || typeof NGAOyssBagla !== "function") {
      alan.textContent = "OYSS modülü yüklenemedi. Sayfayı yenileyin.";
      return;
    }
    alan.innerHTML = '<div class="panelkok" id="oyss-panel">' + NGAOyssHTML() + "</div>";
    const $ = (id) => alan.querySelector("#" + String(id).replace(/[^a-zA-Z0-9_-]/g, ""));
    const yazUyari = (t) => {
      const durum = $("nga-oyss-durum");
      if (durum) { durum.textContent = t; durum.style.color = "#b00020"; durum.style.fontWeight = "700"; }
    };
    async function kvkkVeKilit() {
      if (typeof OkulProfil !== "undefined" && !(await OkulProfil.kvkkOnayli())) {
        yazUyari("KVKK onayı olmadan çalışmaz.");
        return false;
      }
      if (typeof OkulProfil !== "undefined") {
        const kilit = await OkulProfil.kilitDurumu();
        if (kilit && kilit.modul && kilit.modul !== "oyss") {
          const ad = (OkulProfil.MODUL_ADI && OkulProfil.MODUL_ADI[kilit.modul]) || kilit.modul;
          yazUyari("Başka bir otomasyon çalışıyor: " + ad + ". Bitmesini bekleyin veya durdurun.");
          return false;
        }
      }
      return true;
    }
    const hizSel = $("nga-oyss-hiz");
    chrome.storage.local.get("ayar").then((r) => {
      if (hizSel && r.ayar && r.ayar.hiz) hizSel.value = r.ayar.hiz;
    }).catch(() => {});
    NGAOyssBagla(alan, $);
    if (hizSel) {
      const once = hizSel.onchange;
      hizSel.onchange = async function (ev) {
        if (typeof once === "function") once.call(this, ev);
        try {
          const r = await chrome.storage.local.get("ayar");
          await chrome.storage.local.set({ ayar: { ...(r.ayar || {}), hiz: hizSel.value } });
        } catch (e) {}
      };
    }
    function sarmala(id, kilitli) {
      const el = $(id);
      if (!el) return;
      const eski = el.onclick;
      if (typeof eski !== "function") return;
      el.onclick = async function (ev) {
        if (!(await kvkkVeKilit())) return;
        let taimer = null;
        if (kilitli) {
          try { await chrome.storage.local.set({ kilit: { modul: "oyss", ts: Date.now() } }); } catch (e) {}
          taimer = setInterval(() => { chrome.storage.local.set({ kilit: { modul: "oyss", ts: Date.now() } }).catch(() => {}); }, 5000);
        }
        try { return await eski.call(this, ev); }
        finally {
          if (taimer) clearInterval(taimer);
          if (kilitli) { try { await chrome.storage.local.remove("kilit"); } catch (e) {} }
        }
      };
    }
    ["nga-oyss-hizli-aktar", "nga-oyss-hepsi-indir", "nga-oyss-yaz", "nga-oyss-excel-eokul-yaz", "nga-oyss-tum", "nga-oyss-aktar"].forEach((id) => sarmala(id, true));
    ["nga-oyss-ses", "nga-oyss-hizli-ac"].forEach((id) => sarmala(id, false));
  },
});
