"use strict";
// Panel hem sayfa içinde (gölge DOM, panel_host.js) hem de tek başına sekmede (panel.html) çalışır.
function panelKur(KOK, MOD = "rapor") { // v2.3.25: MOD "rapor" (sağlık raporu) | "veli" (veli izni) — aynı motor, ayrı liste görünümü
const FAAL = MOD === "faaliyet", VELI = MOD === "veli" || FAAL; // v2.3.43: "faaliyet" ayrı sekme (Veli İzni paneliyle aynı görünüm)
const benim = (s) => (FAAL ? !!(s && s.faaliyet) : VELI ? !!(s && s.veli && !s.faaliyet) : !(s && s.veli));
const KEY = "durum", AYAR = "ayar";
const EGITIM_BAS = new Date(2026, 8, 1), EGITIM_BIT = new Date(2027, 5, 30);
const $ = (s) => KOK.querySelector(s);
{ // v2.3.25: sekmeye göre başlık ve düğmeler (yalnızca o sekmenin işi görünür)
  const gizle = (sec) => { const e = KOK.querySelector(sec); if (e) (e.closest("label") || e).style.display = "none"; };
  if (VELI) {
    const h1 = KOK.querySelector("h1"); if (h1) h1.textContent = "Veli İzni (İzinli) girişi";
    const h2 = KOK.querySelector("section h2"); if (h2) h2.textContent = "1) Veli izni formlarını oku";
    const n = h2 && h2.nextElementSibling; if (n) n.textContent = "Taranmış veli izni formlarını (PDF/foto) tarama sayfasında okutun ve buraya aktarın; ya da aşağıdan Veli izni (JSON) yükleyin. Tür: İzinli, Açıklama: Veli izni.";
    ["#neden", "#sureHesabi", "#csvYukle", "#ogrTcBolum"].forEach(gizle);
    if (FAAL) { // v2.3.43
      if (h1) h1.textContent = "Faaliyet girişi"; if (h2) h2.textContent = "1) Faaliyet formlarını oku";
      if (n) n.textContent = "Taranmış faaliyet formlarını tarama sayfasında (Tür: Veli izni formu — faaliyet formu kendiliğinden tanınır) okutun ve aktarın; ya da aşağıdan toplu faaliyet ekleyin. Tür: Faaliyet.";
      gizle("#veliJsonYukle");
    } else { const fb = KOK.querySelector("#faaliyetBolum"); if (fb) fb.style.display = "none"; }
  } else { ["#veliNeden", "#veliAciklama", "#veliJsonYukle", "#faaliyetNeden", "#faaliyetAciklama", "#faaliyetAdlariEt"].forEach(gizle); const fb = KOK.querySelector("#faaliyetBolum"); if (fb) fb.style.display = "none"; const bb = KOK.querySelector("#birlesBolum"); if (bb) bb.style.display = "none"; } // v2.3.37: faaliyet yalnız Veli İzni sekmesinde // v2.3.28: Excel her iki sekmede
}
// TAHMİNİ seçiciler: gerçek e-Okul HTML'i görülmeden ekran görüntüsü etiketlerine göre yazıldı.
const SECICI_VARSAYILAN = { menu: "Özürlü Devamsızlık", neden: "Nedeni", bas: "Başlangıç Tarihi", sure: "Süre (Gün)", acik: "Açıklama" };

// ---------- Yardımcılar ----------
function tcGecerli(tc) {
  if (!/^\d{11}$/.test(tc) || tc[0] === "0") return false;
  const d = [...tc].map(Number);
  const t1 = d[0] + d[2] + d[4] + d[6] + d[8], t2 = d[1] + d[3] + d[5] + d[7];
  if ((((t1 * 7 - t2) % 10) + 10) % 10 !== d[9]) return false;
  return d.slice(0, 10).reduce((a, b) => a + b, 0) % 10 === d[10];
}
function tarihCoz(s) {
  const m = String(s || "").match(/(\d{1,2})\s*[./\-\s]\s*(\d{1,2})\s*[./\-\s]\s*(\d{2,4})/);
  if (!m) return null;
  let [, g, a, y] = m.map(Number);
  if (y < 100) y += 2000;
  const t = new Date(y, a - 1, g);
  return t.getFullYear() === y && t.getMonth() === a - 1 && t.getDate() === g ? t : null;
}
const p2 = (n) => String(n).padStart(2, "0");
const tarihYaz = (t) => (t ? `${p2(t.getDate())}/${p2(t.getMonth() + 1)}/${t.getFullYear()}` : "");
function gunSay(bas, bit, hesap) {
  if (bit < bas) return 0;
  let n = 0;
  for (let t = new Date(bas); t <= bit; t.setDate(t.getDate() + 1)) {
    if (hesap !== "is_gunu" || (t.getDay() !== 0 && t.getDay() !== 6)) n++;
  }
  return n;
}

async function durumOku() {
  const d = (await chrome.storage.local.get(KEY))[KEY];
  return d || { calisiyor: false, deneme: true, limit: 0, islenen: 0, sonHata: "", neden: "Raporlu", satirlar: [], idx: -1, step: "bos", adimNo: 0, stepTs: 0, kaydetSayisi: 0 };
}
const durumYaz = (d) => chrome.storage.local.set({ [KEY]: d });
async function ayarOku() {
  return (await chrome.storage.local.get(AYAR))[AYAR] || { neden: "Raporlu", sureHesabi: "belge", secici: SECICI_VARSAYILAN };
}

// ---------- Tablo ----------
const ALANLAR = [
  ["dosya", "Dosya", null], ["tc", "TC / Okul No", "tc"], ["adsoyad", "Ad Soyad", ""], ["bas", "Başlangıç", "tarih"],
  ["bit", "Bitiş", "tarih"], ["tur", "Tür", "tur"], ["sure", "Süre", "kisa"], ["aciklama", "Açıklama", "kurum"],
  ["uyari", "Uyarı", null], ["durum", "Durum", "sec"], ["sonuc", "Sonuç", null],
];
const VARS_KURUM = "Aile Hekimi | aile sagligi merkezi, asm, aile hekimi, aile hekimligi\nŞehir Hastanesi | sehir hastanesi\nÜniversite Hastanesi | universite, universitesi, tip fakultesi\nDevlet Hastanesi | devlet hastanesi";
const RaporCikarimListe = (ay) => String(ay.kurumlar || VARS_KURUM).split(/\r?\n/).map((l) => l.split("|")[0].trim()).filter(Boolean).map((ad) => ({ ad }));
const DURUMLAR = ["HAZIR", "KONTROL", "OK", "ATLANDI", "HATA"];

// ---------- v2.4.0: arama / durum süzgeci ve toplu seçim ----------
let filtreMetin = "", filtreDurum = "TUMU";
const secili = new Set(); // yalnız bu sekmenin satır kodları (liste her yenilendiğinde kodlar yeniden verilir)
let kodHarita = new Map(); // satır kodu -> satır dizini (son çizimdeki)
const yeniKod = () => "r" + Math.random().toString(36).slice(2, 9);
const satirKod = (s) => (s.kod = s.kod || yeniKod()); // v2.4.1: kod depoya yazılır (süzgeç/arama değişince seçim kaybolmaz)
const katla = (v) => String(v ?? "").toLocaleLowerCase("tr");
function satirEsles(s) {
  if (filtreDurum === "SARI") { if (!s.sari) return false; }
  else if (filtreDurum !== "TUMU" && s.durum !== filtreDurum) return false;
  const q = filtreMetin.trim(); if (!q) return true;
  const hedef = katla([s.no, s.tc, s.adsoyad, s.bas, s.bit, s.sure, s.tur, s.aciklama, s.uyari, s.durum, s.sonuc, s.dosya].filter(Boolean).join(" | "));
  return q.split(/\s+/).every((p) => hedef.includes(katla(p)));
}
const benimSatirlar = (d) => d.satirlar.map((s, i) => ({ s, i })).filter((x) => benim(x.s));
function secimCiz(gorunen, toplam, kilit) {
  const n = secili.size, el = $("#secimSay");
  if (el) el.textContent = `${gorunen}/${toplam} satır` + (filtreMetin.trim() || filtreDurum !== "TUMU" ? " (süzgeçli)" : "") + ` · ${n} seçili`;
  const k = !!kilit;
  ["#secHazir", "#secKontrol", "#secTur", "#secSil"].forEach((sel) => { const b = $(sel); if (b) b.disabled = k || !n; });
  const tum = $("#tumSec"); if (tum) tum.disabled = k || !gorunen;
  const birak = $("#secBirak"); if (birak) birak.disabled = !n;
}
// Toplu HAZIR için satır doğrulaması (Başlat'ın kuralıyla aynı + Açıklama zorunlu)
function satirHatasi(g) {
  const e = [];
  if (g.ara === "no") { if (!/^\d{1,6}$/.test(String(g.no || ""))) e.push("Okul No boş/geçersiz"); }
  else if (RaporSutun.maskeliMi && RaporSutun.maskeliMi(g.tc)) e.push(g.maskeMesaj || "Maskeli TC: öğrenci listesiyle eşleşmedi");
  else if (!tcGecerli(String(g.tc || ""))) e.push("TC geçersiz");
  if (!tarihCoz(g.bas)) e.push("Başlangıç tarihi boş/okunamadı");
  if (!g.sure) e.push("Süre (gün) boş");
  if (!String(g.aciklama || "").trim()) e.push("Açıklama boş");
  return e;
}
// v2.5.3: maskeli T.C. eşlemesi — öğrenci listesi (isteğe bağlı, T.C. sütunlu) + kontrol listesindeki tam T.C.
const OGR_TC_KEY = "raporOgrTcListe";
async function ogrTcListeOku() {
  try { const r = (await chrome.storage.local.get(OGR_TC_KEY))[OGR_TC_KEY]; return Array.isArray(r && r.liste) ? r.liste : []; } catch (e) { return []; }
}
function eslemeKaynaklari(d, ekstra) {
  const L = [], seen = new Set();
  const ekle = (k) => { const t = String((k && (k.tc || k.t)) || ""); if (!/^\d{11}$/.test(t) || seen.has(t)) return; seen.add(t); L.push({ tc: t, adsoyad: k.adsoyad || k.a || "", no: k.no || k.n || "" }); };
  for (const s of (d && d.satirlar) || []) if (benim(s)) ekle(s);
  for (const k of ekstra || []) ekle(k);
  return L;
}
function maskeDoldur(s, liste) {
  if (!(RaporSutun.maskeliMi && RaporSutun.maskeliMi(s.tc))) { s.maskeMesaj = ""; return { doldu: false }; }
  const r = RaporSutun.maskeIleEsle(s.tc, s.adsoyad, liste);
  if (r.durum === "tek") {
    const k = r.kayit; s.tc = k.tc || k.t;
    if (!String(s.adsoyad || "").trim() && (k.adsoyad || k.a)) s.adsoyad = k.adsoyad || k.a;
    s.maskeMesaj = ""; return { doldu: true };
  }
  s.maskeMesaj = r.mesaj; return { doldu: false, mesaj: r.mesaj };
}

let KURUM_ADLARI = [];
async function tabloCiz() {
  const d = await durumOku();
  const ay = await ayarOku();
  KURUM_ADLARI = RaporCikarimListe(ay).map((x) => x.ad);
  const t = $("#tablo");
  t.innerHTML = "";
  if (VELI) birlesCiz(d); // v2.3.43
  const hepsi = benimSatirlar(d);
  // v2.4.1: satır kodları depoda kalıcı; arama/süzgeç değişse de seçim korunur. Yinelenen kod (kopyalanan satır) yenilenir.
  const gecerli = new Set(); let kodYeni = false;
  hepsi.forEach(({ s }) => { const once = s.kod; if (gecerli.has(s.kod)) s.kod = yeniKod(); gecerli.add(satirKod(s)); if (s.kod !== once) kodYeni = true; });
  if (kodYeni && !d.calisiyor) durumYaz(d); // kodlar kalıcı olsun (onChanged ile bir kez daha çizilir)
  kodHarita = new Map(hepsi.map(({ s, i }) => [s.kod, i])); // v2.4.0: toplu işlem seçilen dizinleri kullanır
  [...secili].forEach((k) => { if (!gecerli.has(k)) secili.delete(k); });
  if (!hepsi.length) {
    t.innerHTML = "<tr><td>Liste boş</td></tr>";
    secimCiz(0, 0, d.calisiyor); return;
  }
  const kilit = d.calisiyor;
  const gorunen = hepsi.filter(({ s }) => satirEsles(s));
  t.insertAdjacentHTML("beforeend", '<tr><th class="sec"><input type="checkbox" id="hepsi" title="Görünenlerin tümünü seç"></th>' + ALANLAR.map((a) => `<th>${a[1]}</th>` + (VELI && a[0] === "sure" ? "<th>Günler (− ayır / + kat)</th>" : "")).join("") + "</tr>"); // v2.3.43 // v2.4.0
  if (!gorunen.length) {
    t.insertAdjacentHTML("beforeend", `<tr><td colspan="${ALANLAR.length + 1 + (VELI ? 1 : 0)}">Süzgece uyan satır yok — aramayı temizleyin (Esc) ya da durum süzgecini “Tüm durumlar” yapın.</td></tr>`);
    secimCiz(0, hepsi.length, kilit); return;
  }
  const onaylar = [];
  gorunen.forEach(({ s, i }) => {
    const tr = document.createElement("tr");
    tr.className = s.durum + (s.sari ? " sari" : "") + (kilit && i === d.idx ? " aktif" : "") + (secili.has(s.kod) ? " secili" : "");
    const tdSec = document.createElement("td"); tdSec.className = "sec"; // v2.4.0: toplu seçim
    const onay = document.createElement("input"); onay.type = "checkbox"; onay.checked = secili.has(s.kod); onay.disabled = kilit;
    onay.title = "Bu satırı seç";
    onay.onchange = () => { if (onay.checked) secili.add(s.kod); else secili.delete(s.kod); tr.classList.toggle("secili", onay.checked);
      const h = t.querySelector("#hepsi"); if (h) { const g = gorunen.map((x) => x.s.kod); h.checked = g.every((k) => secili.has(k)); h.indeterminate = !h.checked && g.some((k) => secili.has(k)); }
      secimCiz(gorunen.length, hepsi.length, kilit); };
    tdSec.append(onay); tr.append(tdSec);
    const tdSil = document.createElement("td"), sil = document.createElement("button");
    sil.className = "ico ico-del"; sil.textContent = "−"; sil.title = "Listeden çıkar"; sil.disabled = kilit;
    sil.onclick = async () => { const x = await durumOku(); if (x.calisiyor) return; RaporYardim.satirSil(x.satirlar, i); await durumYaz(x); };
    const ekle = document.createElement("button"); ekle.className = "ico ico-add"; ekle.textContent = "+"; ekle.title = "Altına yeni satır ekle"; ekle.disabled = kilit; ekle.style.marginLeft = "3px"; // v2.3.43
    ekle.onclick = async () => { const x = await durumOku(); if (x.calisiyor || !x.satirlar[i]) return; const o = x.satirlar[i];
      x.satirlar.splice(i + 1, 0, { dosya: "(elle)", ara: o.ara, no: o.no || "", tc: o.tc || "", adsoyad: "", bas: "", bit: "", tur: o.tur, neden: o.neden, veli: !!o.veli, ...(o.faaliyet ? { faaliyet: true } : {}), aciklama: o.aciklama || "", elleKaydet: o.elleKaydet, sure: o.veli ? "1" : "", yarim: false, uyari: "Elle eklendi: tarihi yazın", durum: "KONTROL", sonuc: "", elle: true }); await durumYaz(x); };
    tdSil.append(sil, ekle); tr.append(tdSil);
    for (const [k, , tur] of ALANLAR) {
      const td = document.createElement("td");
      if (tur === null) { td.textContent = s[k] ?? ""; td.title = s[k] ?? ""; if (k === "uyari") { td.style.maxWidth = "220px"; td.style.overflow = "hidden"; td.style.textOverflow = "ellipsis"; } }
      else if (tur === "kurum") {
        const sel = document.createElement("select"); sel.add(new Option("— seçin —", ""));
        const adlar = KURUM_ADLARI.includes(s.aciklama) || !s.aciklama ? KURUM_ADLARI : [...KURUM_ADLARI, s.aciklama];
        adlar.forEach((x) => sel.add(new Option(x, x, false, x === s.aciklama)));
        if (!s.aciklama) sel.style.background = "#ffd54f";
        sel.disabled = kilit; sel.onchange = () => alanKaydet(i, k, sel.value);
        td.append(sel);
      }
      else if (tur === "tur") { // v2.3.43: satır başına tür seçimi — Devamsızlık / Rapor / Veli İzni / Faaliyet (seçilince satır o sekmeye geçer)
        const sel = document.createElement("select"), simdi = s.faaliyet ? "faaliyet" : s.veli ? "veli" : s.tur === "Sevkli" ? "Sevkli" : "Raporlu";
        const sec = s.veli ? [["devamsizlik", "Devamsızlık"], ["Raporlu", "Rapor"], ["veli", "Veli İzni"], ["faaliyet", "Faaliyet"]] : [["devamsizlik", "Devamsızlık"], ["Raporlu", "Rapor (Raporlu)"], ["Sevkli", "Rapor (Sevkli)"], ["veli", "Veli İzni"], ["faaliyet", "Faaliyet"]];
        sec.forEach(([v, ad]) => sel.add(new Option(ad, v, false, v === simdi)));
        sel.disabled = kilit; sel.style.fontWeight = "bold"; sel.onchange = () => (sel.value === "Sevkli" || sel.value === "Raporlu") && !s.veli ? alanKaydet(i, k, sel.value) : turDegistir(i, sel.value);
        td.append(sel);
      }
      else if (tur === "sec") {
        const sel = document.createElement("select");
        DURUMLAR.forEach((x) => sel.add(new Option(x, x, false, x === s.durum)));
        sel.disabled = kilit;
        sel.onchange = () => alanKaydet(i, k, sel.value);
        td.append(sel);
      } else {
        const inp = document.createElement("input");
        inp.value = s[k] ?? ""; inp.className = tur; inp.disabled = kilit;
        if (k === "tc" && s.tcS && !s.tc) { inp.placeholder = "🔒 kasa kilitli"; inp.disabled = true; inp.title = "T.C. şifreli: görmek için T.C. kasasını açın"; } // v2.4.1
        inp.onchange = () => alanKaydet(i, k, inp.value.trim());
        if (k === "sure") { // v2.3.43: Süre − / + (veli izni / faaliyet 0,5 adım; rapor 1 gün)
          const adim = s.veli ? 0.5 : 1, deg = (y) => { const n = Number(String(inp.value).replace(",", ".")) || 0, v = Math.max(adim, Math.min(s.veli ? (globalThis.VeliBirlestir && VeliBirlestir.arifeSatiri(s) ? 0.5 : 5) : 365, n + y * adim)); /* v2.3.44: arife en çok 0,5 */ alanKaydet(i, k, String(v).replace(".", ",")); };
          const b = (m, y) => { const x = document.createElement("button"); x.type = "button"; x.className = "ico " + (y > 0 ? "ico-add" : "ico-del"); x.textContent = m; x.title = (y > 0 ? "Artır " : "Azalt ") + String(adim).replace(".", ","); x.disabled = kilit; x.onclick = () => deg(y); x.style.margin = "0 2px"; return x; };
          td.append(b("−", -1), inp, b("+", 1));
        } else td.append(inp);
      }
      tr.append(td);
      if (VELI && k === "sure") { // v2.3.43: ardışık günler — − son günü ayırır, + ertesi günü katar
        const tg = document.createElement("td"), B = globalThis.VeliBirlestir;
        if (B) { const bl = B.birlesikMi(s), j = B.sonrakiBul(d.satirlar, i);
          const ay = document.createElement("button"); ay.className = "ico ico-del"; ay.textContent = "−"; ay.title = "Son günü ayrı kayıt yap"; ay.disabled = kilit || !bl;
          ay.onclick = async () => { const x = await durumOku(); if (x.calisiyor) return; if (B.ayir(x.satirlar, i)) await durumYaz(x); };
          const ka = document.createElement("button"); ka.className = "ico ico-add"; ka.textContent = "+"; ka.title = "Ertesi günü bu kayda kat"; ka.disabled = kilit || j < 0; ka.style.marginLeft = "3px";
          ka.onclick = async () => { const x = await durumOku(); if (x.calisiyor) return; if (B.birlestirSonraki(x.satirlar, i)) await durumYaz(x); };
          const m = document.createElement("span"); m.style.marginLeft = "5px"; m.textContent = bl ? B.planMetni(s) : j >= 0 ? "ertesi gün eklenebilir" : B.arifeSatiri(s) ? "ARİFE — yarım gün (en çok 0,5)" : ""; if (B.arifeSatiri(s) || /arife/.test(m.textContent)) m.style.color = "#FCD34D"; // v2.3.44
          tg.append(ay, ka, m); }
        tr.append(tg);
      }
    }
    t.append(tr);
    onaylar.push(onay);
  });
  // v2.4.0: başlıktaki "hepsi" kutusu — yalnız görünenleri seçer (yeniden çizim yapmadan, seçim kaybolmasın)
  const h = t.querySelector("#hepsi");
  if (h) {
    const kodlar = gorunen.map(({ s }) => s.kod);
    h.checked = kodlar.every((k) => secili.has(k));
    h.indeterminate = !h.checked && kodlar.some((k) => secili.has(k));
    h.disabled = kilit;
    h.onchange = () => {
      secili.clear(); if (h.checked) kodlar.forEach((k) => secili.add(k));
      onaylar.forEach((c) => { c.checked = h.checked; c.closest("tr").classList.toggle("secili", h.checked); });
      h.indeterminate = false; secimCiz(gorunen.length, hepsi.length, kilit);
    };
  }
  secimCiz(gorunen.length, hepsi.length, kilit);
}

async function alanKaydet(i, k, v) {
  if (k === "tc" && /^\d{11}$/.test(String(v).replace(/\s/g, "")) && !(await kasaAcikMi())) { await kasaGerekli(); return; } // v2.4.1
  const d = await durumOku(), ayar = await ayarOku();
  const s = d.satirlar[i];
  if (!s) return;
  if (k === "bas" || k === "bit") v = RaporYardim.tarihNormal(v); // 15.10.2026 / 15/10/26 / 15 Ekim 2026
  const eski = String(s[k] ?? "").trim(); let yayildi = 0;
  s[k] = v;
  if (s.birlesik && k !== "durum") delete s.birlesik;
  if (k === "tc" && eski.trim() && eski !== String(v)) { // v2.4.5: aynı (yanlış) numaralı diğer satırlar da değişir; Geri al hepsini döndürür
    const es = [];
    d.satirlar.forEach((x, j) => { if (j !== i && x && String(x.tc ?? "").trim() === eski && !!x.veli === !!s.veli && !!x.faaliyet === !!s.faaliyet && !["OK"].includes(x.durum)) { es.push(j); x.tc = v; if (x.ara === "no") x.no = String(v).replace(/\D/g, ""); } });
    if (es.length) { NO_GERI = { eski, yeni: v, satirlar: [i, ...es] }; yayildi = es.length + 1; } // v2.4.7: odak tablodayken onChanged yeniden çizmiyordu; açıkça çizilir
  }
  if (k === "sure" && s.veli) s.yarim = String(v).replace(".", ",") === "0,5"; // v2.3.43 // v2.3.43: elle düzeltilen birleşik satır artık ayrılamaz (değerleri kullanıcınındır)
  if (k === "tc" && s.ara === "no") s.no = String(v).replace(/\D/g, ""); // v2.3.25: veli satırında bu sütun Okul No
  if (s.elle && k !== "durum") s.uyari = "";
  if (k === "tur" && v === "Sevkli") { s.sure = Number(ayar.sevkSure) || 1; s.bit = s.bas; }
  if ((k === "bas" || k === "bit") && s.tur !== "Sevkli") {
    const b = tarihCoz(s.bas), e = tarihCoz(s.bit);
    if (b && e) s.sure = gunSay(b, e, ayar.sureHesabi);
  }
  await durumYaz(d);
  if (yayildi) { await tabloCiz(); noNotu(`${yayildi} satır güncellendi (${yayildi - 1} satırda da aynı numara vardı)`, true); } // v2.4.7: odak tablodayken onChanged yeniden çizmiyordu
}
// v2.4.5: numara toplu değişiminin geri alınması
var NO_GERI = null;
function noNotu(m, geri) {
  let n = $("#noNotu");
  if (!n) { n = document.createElement("div"); n.id = "noNotu"; n.style.cssText = "margin:4px 0;font-weight:bold"; const t = $("#tablo"); if (!t || !t.parentNode) return; t.parentNode.insertBefore(n, t); }
  n.textContent = m + " ";
  if (geri) { const b = document.createElement("button"); b.textContent = "Geri al"; b.onclick = async () => { const g = NO_GERI; if (!g) return; const d = await durumOku();
    g.satirlar.forEach((j) => { const x = d.satirlar[j]; if (x && String(x.tc) === String(g.yeni)) { x.tc = g.eski; if (x.ara === "no") x.no = String(g.eski).replace(/\D/g, ""); } });
    NO_GERI = null; await durumYaz(d); await tabloCiz(); n.textContent = g.satirlar.length + " satır geri alındı"; }; n.appendChild(b); }
}


// ---------- Düğmeler ----------
$("#satirEkle").onclick = async () => {
  const d = await durumOku(); if (d.calisiyor) return;
  const ay = VELI ? await ayarOku() : null;
  RaporYardim.satirEkle(d.satirlar, FAAL ? { dosya: "(elle)", ara: "no", no: "", tc: "", tur: "Faaliyet", neden: ay.faaliyetNeden || "Faaliyet", veli: true, faaliyet: true, aciklama: ay.faaliyetAciklama || "Faaliyet", elleKaydet: true, sure: "1", durum: "KONTROL", sonuc: "" } : VELI ? { dosya: "(elle)", ara: "no", no: "", tc: "", tur: "İzinli", neden: ay.veliNeden || "İzinli", veli: true, aciklama: ay.veliAciklama || "Veli izni", elleKaydet: true, sure: "1", durum: "KONTROL", sonuc: "" } : { dosya: "(elle)", durum: "KONTROL", sonuc: "" });
  await durumYaz(d);
};
$("#ayarKaydet").onclick = async () => {
  const secici = {}; for (const k of Object.keys(SECICI_VARSAYILAN)) secici[k] = $("#s_" + k).value.trim() || SECICI_VARSAYILAN[k];
  await chrome.storage.local.set({ [AYAR]: { ...(await ayarOku()), neden: $("#neden").value.trim(), veliNeden: $("#veliNeden").value.trim() || "İzinli", veliAciklama: $("#veliAciklama").value.trim() || "Veli izni", faaliyetNeden: $("#faaliyetNeden").value.trim() || "Faaliyet", faaliyetAciklama: $("#faaliyetAciklama").value.trim() || "Faaliyet", sureHesabi: $("#sureHesabi").value, guvenliMod: $("#guvenliMod").checked, otoKaydet: $("#otoKaydet").checked, kaydetArasiSn: Math.max(0, Number($("#kaydetArasiSn").value) || 0), secici } });
  $("#ayarlar").open = false;
};

$("#okulAyarAc").onclick = () => chrome.runtime.sendMessage({ tip: "okulAyarlariAc" });
$("#taramaAc").onclick = () => chrome.runtime.sendMessage({ tip: "taramaAc", tur: VELI ? "veli" : "rapor" });
if ($("#bosFormAc")) { $("#bosFormAc").hidden = !VELI; $("#bosFormAc").style.display = VELI ? "" : "none"; $("#bosFormAc").onclick = () => chrome.runtime.sendMessage({ tip: "bosFormAc", tur: FAAL ? 2 : 1 }); } // v2.5.8: Boş form indir (yerel PDF)

// ---------- v2.4.0: arama, durum süzgeci, toplu işlem, A4 listesi ----------
let aramaZaman;
if ($("#arama")) {
  $("#arama").addEventListener("input", () => { clearTimeout(aramaZaman); aramaZaman = setTimeout(() => { filtreMetin = $("#arama").value; tabloCiz(); }, 150); });
  $("#arama").addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); $("#arama").value = ""; filtreMetin = ""; tabloCiz(); } });
  $("#arama").addEventListener("keydown", (e) => { if (e.key === "Enter") { clearTimeout(aramaZaman); filtreMetin = $("#arama").value; tabloCiz(); } });
}
if ($("#durumFiltre")) $("#durumFiltre").onchange = () => { filtreDurum = $("#durumFiltre").value || "TUMU"; tabloCiz(); };

// Seçilen satırların dizinleri (çizim anındaki eşleme ile; liste değiştiyse geçersiz olanlar atlanır)
async function secilenDizinler() {
  const d = await durumOku();
  const kodlu = new Map(d.satirlar.map((s, i) => [s && s.kod, i])); // v2.4.1: dizin, güncel listede kodla bulunur
  const idx = [...secili].map((k) => kodlu.get(k)).filter((i) => typeof i === "number" && d.satirlar[i] && benim(d.satirlar[i]));
  return { d, idx: [...new Set(idx)].sort((a, b) => a - b) };
}
if ($("#tumSec")) $("#tumSec").onclick = () => { const h = $("#tablo") && $("#tablo").querySelector("#hepsi"); if (h) { h.checked = true; if (h.onchange) h.onchange(); } };
if ($("#secBirak")) $("#secBirak").onclick = () => { secili.clear(); tabloCiz(); };

if ($("#secHazir")) $("#secHazir").onclick = async () => {
  const { d, idx } = await secilenDizinler(); if (d.calisiyor || !idx.length) return;
  const kaynak = eslemeKaynaklari(d, await ogrTcListeOku());
  let oldu = 0; const nedenler = [];
  for (const i of idx) {
    const s = d.satirlar[i]; maskeDoldur(s, kaynak); const e = satirHatasi(s);
    if (e.length) { s.durum = "KONTROL"; s.sari = true; s.uyari = "HAZIR yapılamadı: " + e.join(", "); nedenler.push(e.join(", ")); }
    else { s.durum = "HAZIR"; s.sari = false; s.sonuc = ""; if (/^HAZIR yapılamadı:/.test(s.uyari || "")) s.uyari = ""; oldu++; }
  }
  await durumYaz(d);
  ekMesaj = RaporSutun.hazirOzet(oldu, nedenler, "Toplu");
  ilerlemeYaz(d);
};
// v2.5.1: TEK TIKLA "Hepsini HAZIR yap": görünen (süzgeçli) satırlardan OK olmayanların hepsi (KONTROL / ATLANDI / HATA); eksik alanlı satır KONTROL kalır, OK'e dokunulmaz
if ($("#hepsiHazir")) $("#hepsiHazir").onclick = async () => {
  const d = await durumOku(); if (d.calisiyor) { ekMesaj = "Giriş çalışırken değiştirilemez; önce Durdur'a basın"; ilerlemeYaz(d); return; }
  const idx = [], say = {}; d.satirlar.forEach((s, i) => { if (!s || !benim(s) || !satirEsles(s) || s.durum === "HAZIR" || s.durum === "OK") return; idx.push(i); say[s.durum] = (say[s.durum] || 0) + 1; });
  if (!idx.length) { ekMesaj = "HAZIR yapılacak satır yok (görünen satırların hepsi zaten HAZIR ya da OK)"; ilerlemeYaz(d); return; }
  if ((say.ATLANDI || say.HATA) && !confirm(`${idx.length} satır HAZIR yapılacak: ` + Object.entries(say).map(([k, v]) => `${k} ${v}`).join(", ") + ".\nATLANDI/HATA satırlar yeniden denenir; OK (girilmiş) satırlara dokunulmaz. Devam edilsin mi?")) return;
  const kaynak = eslemeKaynaklari(d, await ogrTcListeOku());
  let oldu = 0; const nedenler = [];
  for (const i of idx) { const s = d.satirlar[i]; maskeDoldur(s, kaynak); const e = satirHatasi(s);
    if (e.length) { s.durum = "KONTROL"; s.sari = true; s.uyari = "HAZIR yapılamadı: " + e.join(", "); nedenler.push(e.join(", ")); } else { s.durum = "HAZIR"; s.sari = false; s.sonuc = ""; if (/^HAZIR yapılamadı:/.test(s.uyari || "")) s.uyari = ""; oldu++; } }
  await durumYaz(d); ekMesaj = RaporSutun.hazirOzet(oldu, nedenler, "Hepsi"); ilerlemeYaz(d);
};
// v2.5.1: çalışma hızı (canlı: eokul.js her turda ayarı okur)
if ($("#hizSec")) { chrome.storage.local.get("ayar").then((r) => { $("#hizSec").value = (r.ayar && r.ayar.hiz) || "hizli"; }); $("#hizSec").onchange = async () => { const r = await chrome.storage.local.get("ayar"); await chrome.storage.local.set({ ayar: { ...(r.ayar || {}), hiz: $("#hizSec").value } }); }; }
if ($("#secKontrol")) $("#secKontrol").onclick = async () => {
  const { d, idx } = await secilenDizinler(); if (d.calisiyor || !idx.length) return;
  idx.forEach((i) => { const s = d.satirlar[i]; s.durum = "KONTROL"; s.sonuc = ""; });
  await durumYaz(d); ekMesaj = `Toplu: ${idx.length} satır KONTROL yapıldı`; ilerlemeYaz(d);
};
if ($("#secSil")) $("#secSil").onclick = async () => {
  const { d, idx } = await secilenDizinler(); if (d.calisiyor || !idx.length) return;
  if (!confirm(`${idx.length} satır listeden çıkarılsın mı? (e-Okul'a girilmez; geri alınamaz)`)) return;
  const sil = new Set(idx);
  d.satirlar = d.satirlar.filter((s, i) => !sil.has(i));
  secili.clear(); await durumYaz(d); ekMesaj = `${idx.length} satır listeden çıkarıldı`; ilerlemeYaz(d);
};
if ($("#secTur")) $("#secTur").onchange = async () => {
  const hedef = $("#secTur").value; $("#secTur").value = ""; if (!hedef) return;
  const { d, idx } = await secilenDizinler(); if (d.calisiyor || !idx.length) return;
  const n = idx.length; secili.clear();
  for (const i of [...idx].sort((a, b) => b - a)) await turDegistir(i, hedef); // yüksekten aşağıya: satır çıkarılsa da dizinler kaymaz
  ekMesaj = `${n} satırın türü değiştirildi`; ilerlemeYaz(await durumOku());
};

// A4 teslim/imza listesi: ekranda görünen (süzgeçli) satırlar; TC gizlenir
if ($("#a4Yazdir")) $("#a4Yazdir").onclick = async () => {
  const d = await durumOku();
  const liste = d.satirlar.filter((s) => benim(s) && satirEsles(s));
  if (!liste.length) { ekMesaj = "Yazdırılacak satır yok (liste boş ya da süzgeç)."; ilerlemeYaz(d); return; }
  const okul = ((await chrome.storage.local.get("okulProfili")).okulProfili || {}).okulAdi || "";
  const ad = FAAL ? "Faaliyet katılım listesi" : VELI ? "Veli izni takip listesi" : "Sağlık raporu takip listesi";
  const maske = (v) => { const s = String(v || ""); return /^\d{11}$/.test(s) ? s.slice(0, 3) + "******" + s.slice(-2) : s; };
  const kimlik = (s) => (s.ara === "no" && s.no ? s.no : maske(s.tc)); // v2.4.1: Okul No boşsa T.C. de maskeli
  const toplamSure = liste.reduce((n, s) => n + (Number(String(s.sure ?? "").replace(",", ".")) || 0), 0);
  const suzgec = !!(filtreMetin.trim() || filtreDurum !== "TUMU");
  const satirlar = liste.map((s, i) => `<tr><td class="n">${i + 1}</td><td class="n">${kacHtml(kimlik(s))}</td><td>${kacHtml(s.adsoyad)}</td><td class="n">${kacHtml(String(s.bas || "").replace(/\//g, "."))}</td><td class="n">${kacHtml(s.sure)}</td><td>${kacHtml(s.tur)}</td><td>${kacHtml(s.aciklama)}</td><td class="imza"></td></tr>`).join("");
  const bHtml = `<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>${kacHtml(ad)}</title><style>
    @page{size:A4;margin:14mm 12mm}
    body{font:11.5px/1.35 Arial,sans-serif;color:#000;margin:0}
    h1{font-size:15px;margin:0 0 3px} .alt{font-size:11px;color:#333;margin:0 0 8px}
    table{border-collapse:collapse;width:100%} th,td{border:1px solid #333;padding:2.5px 4px;text-align:left;vertical-align:middle}
    th{background:#e5e7eb;font-size:11px} td.n{text-align:center;white-space:nowrap} td.imza{width:110px}
    tbody tr:nth-child(even){background:#f7f7f7} .dip{font-size:10px;color:#444;margin-top:6px}
    </style></head><body>
    <h1>${kacHtml(okul ? okul + " — " : "")}${kacHtml(ad)}</h1>
    <p class="alt">${new Date().toLocaleDateString("tr-TR")} · ${liste.length} satır · toplam süre ${String(Math.round(toplamSure * 2) / 2).replace(".", ",")} gün${suzgec ? " · süzgeç uygulanmış liste" : ""}</p>
    <table><thead><tr><th style="width:26px">#</th><th style="width:74px">Okul No / TC</th><th>Ad Soyad</th><th style="width:64px">Tarih</th><th style="width:40px">Süre</th><th style="width:64px">Tür</th><th>Açıklama</th><th>İmza</th></tr></thead><tbody>${satirlar}</tbody></table>
    <p class="dip">Bu liste Okul Pro Devamsızlık Rapor Asistanı ile bu bilgisayarda hazırlandı; TC kimlik numaraları gizlenmiştir. © Eyüp Şeker</p>
    </body></html>`;
  const w = window.open(URL.createObjectURL(new Blob([bHtml], { type: "text/html;charset=utf-8" })));
  if (w) w.addEventListener("load", () => w.print());
  else { ekMesaj = "Yazdırma penceresi engellendi (tarayıcının açılır pencere iznini kontrol edin)."; ilerlemeYaz(d); }
};

$("#atla").onclick = async () => {
  const d = await durumOku();
  if (!d.calisiyor) return;
  d.adimNo = (d.adimNo || 0) + 1; d.stepTs = Date.now(); d.atla = true; await durumYaz(d);
};

// v2.3.24: Başlat reddedilirse neden hem panelde (kırmızı, kalın) hem Günlük'te görünür; sessiz kalmaz.
async function baslatRed(m) {
  const el = $("#ilerleme"); el.textContent = "BAŞLAMADI: " + m; el.style.cssText = "color:#fff;background:#b00020;font-weight:bold;font-size:13px;padding:6px";
  try { const r = await chrome.storage.local.get("log"); const l = (r.log || []).slice(-60); l.push(new Date().toLocaleTimeString("tr") + " Başlat reddedildi: " + m); await chrome.storage.local.set({ log: l }); } catch (e) {}
}
$("#baslat").onclick = async () => {
  $("#ilerleme").style.cssText = ""; ekMesaj = "";
  if (!(await chrome.storage.local.get("kvkkOnay")).kvkkOnay) { await baslatRed("Önce KVKK bilgilendirmesini onaylayın (başlatıcı > Hakkında)."); return; }
  { const d0 = await durumOku(); if (d0.satirlar.some((s) => benim(s) && s.durum === "HAZIR" && s.tcS && !s.tc)) { await kasaGerekli(); return; } } // v2.4.1: kilitli kasayla T.C. araması yapılmaz
  // Ortak kilit: devamsızlık otomasyonu çalışıyorsa başlatma
  const kl = (await chrome.storage.local.get("kilit")).kilit;
  if (kl && kl.modul === "devamsizlik" && Date.now() - kl.ts < 30000) { await baslatRed("Devamsızlık (yoklama) otomasyonu çalışıyor. Önce onu bitirin veya durdurun."); return; }
  const d = await durumOku(), ayar = await ayarOku();
  let ilk = d.satirlar.findIndex((s) => benim(s) && s.durum === "HAZIR"); // yalnızca (düzenlenmiş) listede kalan HAZIR satırlar girilir
  if (ilk < 0) { const k = d.satirlar.filter((s) => benim(s) && s.durum === "KONTROL").length; await baslatRed(k ? `Durumu HAZIR olan satır yok. ${k} satır KONTROL durumunda: tabloda kontrol edip Durum sütununu HAZIR yapın.` : "Durumu HAZIR olan satır yok (liste boş). Önce taramadan Aktar ya da Veli izni (JSON) yükle."); return; }
  const aciksiz = d.satirlar.find((s) => benim(s) && s.durum === "HAZIR" && !String(s.aciklama || "").trim());
  if (aciksiz) { await baslatRed(`Açıklama seçilmemiş satır var (${aciksiz.adsoyad || aciksiz.tc}). Lütfen listeden seçin.`); return; }
  // v2.3.31: hatalı numara / eksik veri çalışmayı engellemez — o satır sarı "atlandı" olur, diğerleriyle devam edilir
  const hataNe = (g) => { const e = []; if (g.ara === "no") { if (!/^\d{1,6}$/.test(String(g.no || ""))) e.push("Okul No boş/geçersiz"); } else if (RaporSutun.maskeliMi && RaporSutun.maskeliMi(g.tc)) e.push(g.maskeMesaj || "Maskeli TC: öğrenci listesiyle eşleşmedi"); else if (!tcGecerli(g.tc)) e.push("TC geçersiz"); if (!tarihCoz(g.bas)) e.push("Başlangıç tarihi boş/okunamadı"); if (!g.sure) e.push("Süre (gün) boş"); return e; };
  let atlanan = 0;
  d.satirlar.forEach((s) => { if (!benim(s) || s.durum !== "HAZIR") return; const e = hataNe(s); if (e.length) { s.durum = "ATLANDI"; s.sari = true; s.sonuc = (e[0].startsWith("Okul No") || e[0].startsWith("TC") ? "Bulunamadı — atlandı: " : "Geçersiz veri — atlandı: ") + e.join(", "); atlanan++; } });
  ilk = d.satirlar.findIndex((s) => benim(s) && s.durum === "HAZIR");
  if (ilk < 0) { await durumYaz(d); await baslatRed(`Girilecek geçerli satır kalmadı (${atlanan} satır hatalı numara/eksik veri nedeniyle atlandı, sarı). Satırları düzeltip Durum'u HAZIR yapın.`); return; }
  if (atlanan) ekMesaj = `${atlanan} satır hatalı numara/eksik veri nedeniyle atlandı (sarı); diğerleri giriliyor.`;
  Object.assign(d, {
    calisiyor: true, deneme: false, atla: false, limit: Number($("#limit").value) || 0,
    islenen: 0, sonHata: "", otoTemizle: ayar.otoTemizle !== false, neden: ayar.neden || "Raporlu", idx: ilk, kapsam: MOD, step: "kurtar", kurtarSay: 0, // kurtar: arama ekranı açıksa hemen "ara"ya geçer, değilse menüden gider
    adimNo: (d.adimNo || 0) + 1, stepTs: Date.now(), kaydetSayisi: 0,
  });
  await chrome.storage.local.remove(RAPOR); // yeni çalışma: eski rapor kalkar
  await durumYaz(d);
};

$("#durdur").onclick = async () => { const d = await durumOku(); d.calisiyor = false; d.step = "durdu"; await durumYaz(d); };

$("#temizle").onclick = async () => {
  const d = await durumOku();
  if (d.calisiyor || !confirm("Tüm liste silinsin mi?")) return;
  d.satirlar = d.satirlar.filter((s) => !benim(s)); d.idx = -1; await durumYaz(d); // v2.3.25: yalnız bu sekmenin listesi
};

const CSV_BASLIK = ["Dosya", "TC", "AdSoyad", "Baslangic", "Bitis", "Tur", "Sure", "Aciklama", "Uyari", "Durum", "Sonuc"];
const CSV_ANAHTAR = ["dosya", "tc", "adsoyad", "bas", "bit", "tur", "sure", "aciklama", "uyari", "durum", "sonuc"];

$("#csvIndir").onclick = async () => {
  const d = await durumOku();
  // v2.3.32: tablo ile aynı başlıklar (RaporSutun), TC metin, tarih gg.aa.yyyy
  const blob = new Blob([RaporSutun.csvYaz(d.satirlar.filter(benim), VELI)], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = FAAL ? "faaliyet.csv" : VELI ? "veli_izni.csv" : "raporlar.csv"; a.click();
};

// v2.2.0: Veli izni OCR aracının (veli_izni_eokul.json) çıktısını içe aktarır. Okul No ile aranır, Nedeni "VELİ İZNİ", Kaydet'e kullanıcı basar.
$("#veliJsonYukle").onchange = async (e) => {
  const f = e.target.files[0]; if (!f) return;
  let j; try { j = JSON.parse((await f.text()).replace(/^\ufeff/, "")); } catch (x) { $("#ilerleme").textContent = "JSON okunamadı: " + x.message; return; }
  const kayitlar = Array.isArray(j) ? j : j.kayitlar || [];
  const d = await durumOku(); if (d.calisiyor) return;
  const ay = await ayarOku(); // v2.3.3: Nedeni/Açıklama Ayarlar'dan (varsayılan İzinli / Veli izni)
  for (const k of kayitlar) {
    const no = String(k.ogrenci_no || k.no || "").replace(/\D/g, "");
    // v2.3.0: yarım gün (formda tarih yanında Y) -> Süre 0,5. T veya işaretsiz = tam gün (1).
    const yarim = k.yarim_gun === true || k.gun_turu === "YARIM" || Number(String(k.sure).replace(",", ".")) === 0.5;
    d.satirlar.push({ dosya: k.dosya || "(veli izni)", ara: "no", no, tc: no, adsoyad: k.ad_soyad || k.ad || "", bas: k.baslangic, bit: k.bitis || k.baslangic,
      tur: "İzinli", neden: ay.veliNeden || "İzinli", veli: true, sure: yarim ? "0,5" : String(k.sure || 1), yarim, aciklama: ay.veliAciklama || "Veli izni", elleKaydet: true,
      uyari: (yarim ? "YARIM GÜN (0,5) — e-Okul'da Süre alanını kontrol edin. " : "") + (k.uyari || ""), durum: k.onaylandi ? "HAZIR" : "KONTROL", sonuc: "" });
  }
  await durumYaz(d); try { if (e && e.target) e.target.value = ""; } catch (_) {}
  $("#ilerleme").textContent = `${kayitlar.length} veli izni satırı eklendi (Okul No ile aranacak, Kaydet'e siz basacaksınız).`;
};
async function ogrTcDurumCiz() {
  const el = $("#ogrTcDurum"), sil = $("#ogrTcSil"); if (!el) return;
  try {
    const r = (await chrome.storage.local.get(OGR_TC_KEY))[OGR_TC_KEY], n = r && Array.isArray(r.liste) ? r.liste.length : 0;
    el.textContent = n ? `${n} öğrenci (T.C. eşleme)` + (r.tarih ? `, ${r.tarih.split("-").reverse().join(".")}` : "") : "Maskeli T.C. için e-Okul öğrenci listesini yükleyin (T.C. sütunu gerekli).";
    if (sil) sil.hidden = !n;
  } catch (e) { el.textContent = ""; }
}
if ($("#ogrTcYukle")) $("#ogrTcYukle").onchange = async (e) => {
  const f = e.target.files[0]; try { if (e && e.target) e.target.value = ""; } catch (_) {}
  if (!f) return;
  try {
    let T;
    if (/\.xlsx$/i.test(f.name)) { if (!globalThis.EvrakXlsx) throw new Error("Excel okuyucu yok"); T = await EvrakXlsx.oku(await f.arrayBuffer()); }
    else { const b = await f.arrayBuffer(); let m = new TextDecoder("utf-8").decode(b); if (m.includes("\uFFFD")) m = new TextDecoder("windows-1254").decode(b); T = RaporSutun.csvOku(m); }
    const r = RaporSutun.ogrenciTcOku(T);
    if (!r.kayitlar.length) { if ($("#ogrTcDurum")) $("#ogrTcDurum").textContent = r.uyari; return; }
    await chrome.storage.local.set({ [OGR_TC_KEY]: { liste: r.kayitlar, tarih: new Date().toISOString().slice(0, 10), ad: f.name } });
    await ogrTcDurumCiz();
    ekMesaj = `Öğrenci listesi yüklendi: ${r.kayitlar.length} T.C. (yalnız bu bilgisayar, hiçbir yere gönderilmez). Maskeli satırlar için “Hepsini HAZIR yap”ı yeniden deneyin.`;
    ilerlemeYaz(await durumOku());
  } catch (er) { if ($("#ogrTcDurum")) $("#ogrTcDurum").textContent = "Liste okunamadı: " + er.message; }
};
if ($("#ogrTcSil")) $("#ogrTcSil").onclick = async () => {
  if (!confirm("T.C. eşleme listesi silinsin mi? (kontrol listesindeki satırlara dokunulmaz)")) return;
  try { await chrome.storage.local.remove(OGR_TC_KEY); } catch (e) {}
  await ogrTcDurumCiz(); ekMesaj = "T.C. eşleme listesi silindi"; ilerlemeYaz(await durumOku());
};
if (!VELI) ogrTcDurumCiz();

$("#csvYukle").onchange = async (e) => { // v2.3.32: başlık adına göre eşlenir (sıraya göre değil); 2.3.31 ve öncesi dosyalar da okunur
  const f = e.target.files[0]; if (!f) return;
  try { if (e && e.target) e.target.value = ""; } catch (_) {}
  if (!VELI) return raporTabloYukle(RaporSutun.csvOku(await f.text()), f.name, "CSV");
  let ham; try { ham = RaporSutun.icAl(RaporSutun.csvOku(await f.text())); } catch (er) { $("#ilerleme").textContent = "CSV okunamadı: " + er.message; return; }
  const d = await durumOku();
  const digerleri = d.satirlar.filter((s) => !benim(s)); // v2.3.25: öteki sekmenin listesi korunur
  d.satirlar = digerleri.concat(ham.map((o) => {
    const s = {}; for (const k of CSV_ANAHTAR) s[k] = o[k] ?? "";
    if (!DURUMLAR.includes(s.durum)) s.durum = "KONTROL";
    Object.assign(s, { veli: true, ara: "no", no: String(s.tc).replace(/\D/g, ""), tur: "İzinli", elleKaydet: true });
    if (FAAL) Object.assign(s, { tur: "Faaliyet", faaliyet: true, neden: "Faaliyet" }); // v2.3.43
    return s;
  }));
  await durumYaz(d);
};

// ---------- v2.3.27: Veli İzni Excel (.xlsx) indir / yükle (yerel; günde bir satır) ----------
const XL_BASLIK = ["Okul No", "Ad Soyad", "Tarih", "Süre", "Tür", "Açıklama", "Durum", "Not / Neden"];
const sureMetin = (v) => { const t = String(v ?? "").trim().toLocaleUpperCase("tr").replace(/\s/g, ""); if (/^(1|1,0|1\.0|T|TAM)$/.test(t)) return "1"; if (/^(0,5|0\.5|,5|\.5|Y|YARIM|1\/2)$/.test(t)) return "0,5"; if (/^[2-9]$/.test(t)) return t; { const m = t.match(/^([1-4])[,.]5$/); if (m) return m[1] + ",5"; } return ""; }; // v2.3.43: birleşik satırlar (1,5 … 4,5) // v2.3.29: taramadan gelen 2–9 günlük satırlar Excel dönüşünde reddedilmesin
$("#xlsxIndir").onclick = async () => { if (!VELI) return raporXlsxIndir();
  const d = await durumOku(), liste = d.satirlar.filter(benim), sari = new Set();
  const satirlar = liste.map((s, i) => { if (s.durum === "KONTROL" || s.durum === "HATA") sari.add(i);
    return [s.no || s.tc || "", s.adsoyad || "", s.bas || "", s.yarim || String(s.sure) === "0,5" || String(s.sure) === "0.5" ? "0,5" : String(s.sure || "1"), s.faaliyet ? "Faaliyet" : "İzinli", s.aciklama || "Veli izni", s.durum || "KONTROL", [s.uyari, s.sonuc].filter(Boolean).join(" | ")]; });
  const blob = EvrakXlsx.yaz({ sayfa: "Veli izni", basliklar: XL_BASLIK, satirlar, sari, genislik: [10, 24, 12, 6, 8, 14, 10, 60] });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `${FAAL ? "faaliyet" : "veli_izni"}_${new Date().toISOString().slice(0, 10)}.xlsx`; a.click();
  ekMesaj = `${liste.length} satır Excel'e yazıldı (sarı = KONTROL)`; $("#ilerleme").style.cssText = ""; $("#ilerleme").textContent = `${liste.length} satır Excel'e yazıldı (sarı = KONTROL). Düzelttiğiniz satırda Durum'u HAZIR yapın, sonra "Excel (.xlsx) yükle".`;
};
$("#xlsxYukle").onchange = async (e) => {
  const f = e.target.files[0]; e.target.value = ""; if (!f) return; if (!VELI) return raporXlsxYukle(f);
  const d = await durumOku(); if (d.calisiyor) { await baslatRed("Giriş çalışırken Excel yüklenemez. Önce Durdur'a basın."); return; }
  let tablo; try { tablo = await EvrakXlsx.oku(await f.arrayBuffer()); } catch (er) { await baslatRed("Excel okunamadı: " + er.message); return; }
  const bas = (tablo[0] || []).map((x) => String(x).trim().toLocaleLowerCase("tr")), sut = (ad) => bas.findIndex((x) => x === ad.toLocaleLowerCase("tr") || x.startsWith(ad.toLocaleLowerCase("tr").split(" ")[0]));
  const iNo = sut("Okul No"), iAd = sut("Ad Soyad"), iT = sut("Tarih"), iS = sut("Süre"), iA = sut("Açıklama"), iD = sut("Durum"), iN = sut("Not / Neden");
  if (iNo < 0 || iT < 0) { await baslatRed('Excel başlıkları tanınmadı: ilk satırda en az "Okul No" ve "Tarih" olmalı.'); return; }
  const ay = await ayarOku(), yeni = []; let hazir = 0, kontrol = 0;
  for (const h of tablo.slice(1)) { if (!h || !h.some((x) => String(x).trim())) continue;
    const no = String(h[iNo] ?? "").replace(/\D/g, ""), tarih = RaporYardim.tarihNormal(String(h[iT] ?? "").trim()), sure = iS >= 0 ? sureMetin(h[iS]) : "1";
    const neden = []; if (!/^\d{1,6}$/.test(no)) neden.push("Okul No boş/geçersiz"); if (!tarihCoz(tarih)) neden.push("Tarih geçersiz (gg/aa/yyyy)"); if (!sure) neden.push("Süre 1 / 0,5 (ya da T / Y) olmalı");
    const istenen = String(iD >= 0 ? h[iD] ?? "" : "").trim().toLocaleUpperCase("tr"), notu = String(iN >= 0 ? h[iN] ?? "" : "").trim();
    const durum = neden.length ? "KONTROL" : istenen === "HAZIR" || (!istenen && !notu) ? "HAZIR" : istenen === "OK" ? "OK" : "KONTROL";
    if (durum === "HAZIR") hazir++; else if (durum === "KONTROL") kontrol++;
    yeni.push({ dosya: "(Excel) " + f.name, ara: "no", no, tc: no, adsoyad: String(iAd >= 0 ? h[iAd] ?? "" : "").trim(), bas: tarih, bit: tarih, tur: FAAL ? "Faaliyet" : "İzinli", neden: FAAL ? ay.faaliyetNeden || "Faaliyet" : ay.veliNeden || "İzinli", veli: true, ...(FAAL ? { faaliyet: true } : {}), // v2.3.43: Faaliyet sekmesi
      sure: sure || "1", yarim: sure === "0,5", aciklama: String(iA >= 0 ? h[iA] ?? "" : "").trim() || (FAAL ? ay.faaliyetAciklama || "Faaliyet" : ay.veliAciklama || "Veli izni"), elleKaydet: true,
      uyari: neden.length ? neden.join(", ") : durum === "KONTROL" ? (notu || "Durum KONTROL bırakılmış") : "", durum, sonuc: "" }); }
  d.satirlar = d.satirlar.filter((s) => !benim(s)).concat(yeni); d.idx = -1; await durumYaz(d);
  ekMesaj = `Excel yüklendi: ${yeni.length} satır — HAZIR ${hazir}, KONTROL ${kontrol}`;
  $("#ilerleme").style.cssText = ""; $("#ilerleme").textContent = `Excel yüklendi: ${yeni.length} satır — HAZIR ${hazir}, KONTROL ${kontrol}. ${FAAL ? "Faaliyet" : "Veli İzni"} listesi Excel'deki ile değiştirildi; Başlat'a basabilirsiniz.`;
};

// ---------- v2.3.28: Sağlık raporu Excel (.xlsx) indir / yükle (yerel; veli satırlarına dokunmaz) ----------
// ---------- v2.3.28: Sağlık raporu Excel (.xlsx) indir / yükle (yerel; veli satırlarına dokunmaz) ----------
// v2.3.32: Excel de CSV ile aynı 11 sütun ve tablo başlıkları (RaporSutun); yükleme başlık adına göre
async function raporXlsxIndir() {
  const d = await durumOku(), liste = d.satirlar.filter(benim), sari = new Set();
  const satirlar = liste.map((s, i) => { if (s.durum === "KONTROL" || s.durum === "HATA") sari.add(i); return RaporSutun.disaSatir(s, VELI); });
  const blob = EvrakXlsx.yaz({ sayfa: "Sağlık raporu", basliklar: RaporSutun.BASLIKLAR, satirlar, sari, genislik: [16, 13, 24, 12, 12, 9, 6, 16, 30, 10, 40] });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `saglik_raporu_${new Date().toISOString().slice(0, 10)}.xlsx`; a.click();
  ekMesaj = `${liste.length} satır Excel'e yazıldı (sarı = KONTROL)`; $("#ilerleme").style.cssText = ""; $("#ilerleme").textContent = `${liste.length} satır Excel'e yazıldı (sarı = KONTROL). Düzelttiğiniz satırda Durum'u HAZIR yapın, sonra "Excel (.xlsx) yükle".`;
}
async function raporXlsxYukle(f) {
  let tablo; try { tablo = await EvrakXlsx.oku(await f.arrayBuffer()); } catch (er) { await baslatRed("Excel okunamadı: " + er.message); return; }
  return raporTabloYukle(tablo, f.name, "Excel");
}
async function raporTabloYukle(tablo, dosyaAdi, tip) {
  const d = await durumOku(); if (d.calisiyor) { await baslatRed(`Giriş çalışırken ${tip} yüklenemez. Önce Durdur'a basın.`); return; }
  let ham; try { ham = RaporSutun.icAl(tablo); } catch (er) { await baslatRed(`${tip} ${er.message}.`); return; }
  // v2.4.1 (KVKK): dışa aktarılan dosyada T.C. maskelidir (123******45); geri yüklerken mevcut listedeki T.C. ile eşlenir
  if (ham.some((o) => /^\d{11}$/.test(o.tc) || (RaporSutun.maskeliMi && RaporSutun.maskeliMi(o.tc))) && !(await kasaAcikMi())) { await kasaGerekli(); return; }
  // v2.5.3: maskeli T.C. silinmez; öğrenci listesi + mevcut listedeki tam T.C. ile eşlenir (tek eşleşme → doldurulur)
  const kaynak = eslemeKaynaklari(d, await ogrTcListeOku());
  const ayar = await ayarOku(), yeni = []; let hazir = 0, kontrol = 0;
  for (const o of ham) {
    let maskeMesaj = "";
    if (RaporSutun.maskeliMi && RaporSutun.maskeliMi(o.tc)) {
      const r = RaporSutun.maskeIleEsle(o.tc, o.adsoyad, kaynak);
      if (r.durum === "tek") { o.tc = r.kayit.tc || r.kayit.t; if (!o.adsoyad && (r.kayit.adsoyad || r.kayit.a)) o.adsoyad = r.kayit.adsoyad || r.kayit.a; }
      else maskeMesaj = r.mesaj;
    }
    const kim = o.tc, noMu = kim.length > 0 && kim.length <= 6 && !(RaporSutun.maskeliMi && RaporSutun.maskeliMi(kim));
    const b = RaporYardim.tarihNormal(o.bas), e = RaporYardim.tarihNormal(o.bit) || b;
    let sure = o.sure; if (!/^\d+(,5)?$/.test(sure)) sure = ""; if (!sure && tarihCoz(b) && tarihCoz(e)) sure = String(gunSay(tarihCoz(b), tarihCoz(e), ayar.sureHesabi) || "");
    const turHam = o.tur, tur = /^sevk/i.test(turHam) ? "Sevkli" : "Raporlu"; // v2.3.29: Rapor sekmesi yalnız Raporlu/Sevkli
    const neden = []; if (maskeMesaj) neden.push(maskeMesaj); else if (!(noMu || tcGecerli(kim))) neden.push("TC / Okul No geçersiz"); if (!tarihCoz(b)) neden.push("Başlangıç geçersiz (gg.aa.yyyy)"); if (!sure) neden.push("Süre/Bitiş eksik"); if (turHam && !/^(raporlu|sevkli)$/i.test(turHam.toLocaleLowerCase("tr"))) neden.push(`Tür "${turHam}" geçersiz (Raporlu/Sevkli)`);
    const aciklama = o.aciklama; if (!aciklama) neden.push("Açıklama boş");
    const istenen = o.durum.toLocaleUpperCase("tr"), notu = [o.uyari, o.ekNot].filter(Boolean).join(" · ");
    const durum = neden.length ? "KONTROL" : DURUMLAR.includes(istenen) ? istenen : !istenen && !notu ? "HAZIR" : "KONTROL";
    if (durum === "HAZIR") hazir++; else if (durum === "KONTROL") kontrol++;
    yeni.push(Object.assign({ dosya: o.dosya || `(${tip}) ${dosyaAdi}`, tc: kim, adsoyad: o.adsoyad, bas: b, bit: e, tur, sure,
      aciklama, uyari: neden.length ? neden.join(", ") : notu || (durum === "KONTROL" ? "Durum KONTROL bırakılmış" : ""), durum, sonuc: o.sonuc, maskeMesaj }, noMu ? { ara: "no", no: kim } : {})); }
  d.satirlar = d.satirlar.filter((s) => !benim(s)).concat(yeni); d.idx = -1; await durumYaz(d);
  ekMesaj = `${tip} yüklendi: ${yeni.length} satır — HAZIR ${hazir}, KONTROL ${kontrol}`;
  $("#ilerleme").style.cssText = ""; $("#ilerleme").textContent = `${tip} yüklendi: ${yeni.length} satır — HAZIR ${hazir}, KONTROL ${kontrol}. Rapor listesi dosyadaki ile değiştirildi; Başlat'a basabilirsiniz.`;
}

// ---------- Sonuç raporu ----------
const RAPOR = "sonRapor";
function nedenSinifi(s) {
  const t = String(s.sonuc || "");
  if (s.durum === "OK") return "Girildi";
  if (/TC hatalı|bulunamad/i.test(t)) return "TC hatalı/bulunamadı";
  if (/zaten var|zaten kay/i.test(t)) return "Zaten kayıtlı";
  if (/okunamad/i.test(t + (s.uyari || ""))) return "Okunamadı";
  if (s.durum === "ATLANDI") return "Atlandı";
  return "Hata";
}
// v2.3.46: e-Okul Özürlü Devamsızlıklar listesiyle karşılaştırma
function listeKarsilastir(s) {
  const t = String(s.sonuc || "");
  if (s.durum === "OK") return /listede|yeni satır/i.test(t) ? "✓ listede görüldü" : "✓ e-Okul başarı mesajı";
  if (/zaten (var|kay|girilmi)|çakış/i.test(t)) return "✓ önceden listede vardı";
  return "✗ listede YOK — elle girin";
}
function raporKur(d) {
  const satirlar = d.satirlar.filter((s) => ["OK", "HATA", "ATLANDI"].includes(s.durum) && s.sonuc && (!d.kapsam || (d.kapsam === "faaliyet" ? !!s.faaliyet : d.kapsam === "veli" ? !!s.veli && !s.faaliyet : !s.veli))).map((s) => ({
    tc: s.tc, adsoyad: s.adsoyad, bas: s.bas, bit: s.bit, sure: s.sure, tur: s.faaliyet ? "Faaliyet" : s.veli ? "İzinli" : s.tur, durum: s.durum, sari: !!s.sari, sinif: nedenSinifi(s), liste: listeKarsilastir(s), sonuc: s.sonuc }));
  const say = {}; satirlar.forEach((s) => { say[s.sinif] = (say[s.sinif] || 0) + 1; });
  return { tarih: new Date().toLocaleString("tr"), toplam: satirlar.length, say, satirlar, kapsam: d.kapsam || "rapor" };
}
const RK = [["no", "#"], ["tc", "TC"], ["adsoyad", "Ad Soyad"], ["bas", "Başlangıç"], ["bit", "Bitiş"], ["sure", "Süre"], ["tur", "Tür"], ["sinif", "Durum"], ["liste", "e-Okul listesi"], ["sonuc", "Ayrıntı"]];
const raporHucre = (s, k) => (k === "tc" ? RaporSutun.tcMaske(s[k]) : s[k]); // v2.4.1 (KVKK): rapor dışa aktarımında T.C. maskeli
const kacHtml = (v) => String(v ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
const ozetMetni = (r, maskeli) => { const kd = r.satirlar.filter((s) => /^Kaydedilemedi/.test(s.sonuc || "")), sy = (f) => r.satirlar.filter(f).length; // v2.3.46: tek bakışta özet
  const ok = sy((s) => s.durum === "OK"), at = sy((s) => s.durum === "ATLANDI"), ha = sy((s) => s.durum === "HATA"), yok = sy((s) => (s.liste ? /YOK/.test(s.liste) : s.durum !== "OK" && !/zaten|çakış/i.test(s.sonuc || "")) && s.sonuc);
  return `${r.tarih} · Toplam ${r.toplam} · KAYDEDİLDİ: ${ok} · ATLANDI: ${at}` + (ha ? ` · HATA: ${ha}` : "") + ` · e-Okul listesinde olmayan: ${yok}` + (yok ? " (sarı satırları elle girin)" : " — hepsi tamam ✓") + (kd.length ? ` · KAYDEDİLEMEDİ (${kd.length}, elle girin): ` + kd.map((s) => `${(maskeli ? RaporSutun.tcMaske(s.tc) : s.tc) || "?"} ${s.bas || ""}`.trim()).join(", ") : ""); };
const raporAdi = (r) => (r.kapsam === "faaliyet" ? "faaliyet" : r.satirlar.length && r.satirlar.every((s) => s.tur === "İzinli") ? "veli izni" : "rapor"); // v2.3.24 // v2.3.43: faaliyet
async function raporCiz() {
  const r = (await chrome.storage.local.get(RAPOR))[RAPOR];
  const rk = r && (r.kapsam || (raporAdi(r) === "veli izni" ? "veli" : "rapor"));
  $("#raporBolum").hidden = !r || rk !== MOD; if (!r || rk !== MOD) return;
  $("#raporOzet").textContent = ozetMetni(r);
  $("#raporTablo").innerHTML = "<tr>" + RK.map((k) => `<th>${k[1]}</th>`).join("") + "</tr>" +
    r.satirlar.map((s, i) => `<tr class="${s.durum}${s.sari ? " sari" : ""}">` + RK.map(([k]) => `<td>${kacHtml(k === "no" ? i + 1 : s[k])}</td>`).join("") + "</tr>").join("");
  $("#raporBolum").scrollIntoView && $("#raporBolum").scrollIntoView({ block: "nearest" });
}
$("#raporCsv").onclick = async () => {
  const r = (await chrome.storage.local.get(RAPOR))[RAPOR]; if (!r) return;
  const kac = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const l = [kac(ozetMetni(r, true)), RK.map((k) => k[1]).join(";"), ...r.satirlar.map((s) => RK.map(([k]) => kac(k === "tc" ? "\t" + (raporHucre(s, k) || "") : s[k])).join(";"))];
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + l.join("\r\n")], { type: "text/csv;charset=utf-8" }));
  a.download = raporAdi(r) === "faaliyet" ? "faaliyet_giris_sonucu.csv" : raporAdi(r) === "veli izni" ? "veli_izni_giris_sonucu.csv" : "rapor_giris_sonucu.csv"; a.click();
};
$("#raporYazdir").onclick = async () => {
  const r = (await chrome.storage.local.get(RAPOR))[RAPOR]; if (!r) return;
  const html = `<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>${raporAdi(r) === "faaliyet" ? "Faaliyet" : raporAdi(r) === "veli izni" ? "Veli izni" : "Rapor"} giriş sonucu</title><style>body{font:12px Arial;margin:16px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #444;padding:3px 5px;text-align:left}th{background:#ddd}tr.HATA{background:#fde2e2}tr.sari{background:#fff3cd}tr.OK{background:#e2f5e6}</style></head><body>
<h2>e-Okul ${raporAdi(r)} giriş sonucu</h2><p><b>${kacHtml(ozetMetni(r, true))}</b></p><table><tr>${RK.map((k) => `<th>${k[1]}</th>`).join("")}</tr>${r.satirlar.map((s) => `<tr class="${s.durum}${s.sari ? " sari" : ""}">` + RK.map(([k]) => `<td>${kacHtml(raporHucre(s, k))}</td>`).join("") + "</tr>").join("")}</table></body></html>`;
  const w = window.open(URL.createObjectURL(new Blob([html], { type: "text/html;charset=utf-8" })));
  if (w) w.addEventListener("load", () => w.print());
};

// ---------- v2.3.43: satır türünü değiştir (Devamsızlık / Rapor / Veli İzni / Faaliyet) ----------
const DEV_KEY = "devamsizlikBekleyen";
async function turDegistir(i, hedef) {
  const d = await durumOku(), ay = await ayarOku(); if (d.calisiyor) return; const s = d.satirlar[i]; if (!s) return;
  const no = String(s.no || (s.ara === "no" ? s.tc : "") || "").replace(/\D/g, "");
  const ad = { devamsizlik: "Devamsızlık", Raporlu: "Rapor", veli: "Veli İzni", faaliyet: "Faaliyet" }[hedef] || hedef;
  if (hedef === "devamsizlik") { // e-Okul'da özürsüz devamsızlık yoklama ekranından girilir: satır buradan çıkar, yoklama ekranının Sesli/Yazılı kutusuna yazılacak metin olur
    const gunler = Array.isArray(s.birlesik) && s.birlesik.length ? s.birlesik : [s];
    const yeni = gunler.map((g) => `${String(g.bas || "").replace(/\//g, ".")} ${no || s.tc || "?"} numara${String(g.sure).replace(".", ",") === "0,5" ? " yarım gün" : Number(String(g.sure).replace(",", ".")) > 1 ? " " + String(g.sure).replace(".", ",") + " gün" : ""}`);
    const eski = (await chrome.storage.local.get(DEV_KEY))[DEV_KEY] || [];
    d.satirlar.splice(i, 1); await chrome.storage.local.set({ [DEV_KEY]: [...eski, ...yeni] }); await durumYaz(d);
    ekMesaj = `Satır Devamsızlık'a ayrıldı (${yeni.length} gün) — aşağıdaki metni yoklama ekranındaki Sesli/Yazılı kutusuna yapıştırın`; ilerlemeYaz(d); devCiz(); return;
  }
  delete s.birlesik; delete s.faaliyet;
  if (hedef === "veli") Object.assign(s, { veli: true, ara: "no", no, tc: no || s.tc, tur: "İzinli", neden: ay.veliNeden || "İzinli", aciklama: ay.veliAciklama || "Veli izni", elleKaydet: true });
  else if (hedef === "faaliyet") Object.assign(s, { veli: true, faaliyet: true, ara: "no", no, tc: no || s.tc, tur: "Faaliyet", neden: ay.faaliyetNeden || "Faaliyet", aciklama: ay.faaliyetAciklama || "Faaliyet", elleKaydet: true });
  else { Object.assign(s, { veli: false, tur: hedef === "Sevkli" ? "Sevkli" : "Raporlu", aciklama: "" }); delete s.neden; delete s.elleKaydet; if (hedef === "Sevkli") { s.sure = Number(ay.sevkSure) || 1; s.bit = s.bas; } }
  s.yarim = String(s.sure) === "0,5"; s.durum = "KONTROL"; s.sari = false; s.sonuc = "";
  s.uyari = `Tür değiştirildi → ${ad}: ${hedef === "veli" || hedef === "faaliyet" ? "Okul No, tarih ve süreyi" : "TC/Okul No ve Açıklama'yı (kurum)"} kontrol edip HAZIR yapın`;
  await durumYaz(d); ekMesaj = `Satır ${ad} sekmesine taşındı (KONTROL)`; ilerlemeYaz(d);
}
async function devCiz() {
  const k = $("#devBekleyen"); if (!k) return; const l = (await chrome.storage.local.get(DEV_KEY))[DEV_KEY] || [];
  k.hidden = !l.length; $("#devMetin").textContent = l.join("\n");
}
if ($("#devKopyala")) $("#devKopyala").onclick = async () => { try { await navigator.clipboard.writeText($("#devMetin").textContent); ekMesaj = "Devamsızlık metni kopyalandı"; } catch (e) { ekMesaj = "Kopyalanamadı: metni seçip Ctrl+C yapın"; } ilerlemeYaz(await durumOku()); };
if ($("#devTemizle")) $("#devTemizle").onclick = async () => { await chrome.storage.local.set({ [DEV_KEY]: [] }); devCiz(); };
// ---------- v2.3.43: Ardışık günler — tek e-Okul kaydı (plan; − ayır / + birleştir). Kaydet akışı değişmedi. ----------
function birlesCiz(d) {
  const kut = $("#birlesPlan"); if (!kut || !globalThis.VeliBirlestir) return;
  const B = VeliBirlestir, kilit = d.calisiyor; kut.innerHTML = "";
  const liste = d.satirlar; let birlesik = 0, eklenebilir = 0;
  liste.forEach((s, i) => {
    if (!benim(s)) return;
    const b = B.birlesikMi(s), j = B.sonrakiBul(liste, i);
    if (b) birlesik++; if (j >= 0) eklenebilir++;
    if (!b && j < 0) return;
    const sat = document.createElement("div"); sat.className = "birles-satir";
    const eksi = document.createElement("button"); eksi.className = "ico ico-del"; eksi.textContent = "−"; eksi.title = "Son günü ayrı kayıt yap"; eksi.disabled = kilit || !b;
    eksi.onclick = async () => { const x = await durumOku(); if (x.calisiyor) return; if (VeliBirlestir.ayir(x.satirlar, i)) await durumYaz(x); };
    const arti = document.createElement("button"); arti.className = "ico ico-add"; arti.textContent = "+"; arti.title = "Ertesi günü bu kayda kat"; arti.disabled = kilit || j < 0;
    arti.onclick = async () => { const x = await durumOku(); if (x.calisiyor) return; if (VeliBirlestir.birlestirSonraki(x.satirlar, i)) await durumYaz(x); };
    const m = document.createElement("span"); m.textContent = `No ${s.no || s.tc || "?"}${s.faaliyet ? " (Faaliyet)" : ""} · ${B.planMetni(s)}` + (b ? "" : "  — birleştirilebilir");
    sat.append(eksi, arti, m); kut.append(sat);
  });
  const ozet = $("#birlesOzet"); if (ozet) ozet.textContent = birlesik || eklenebilir ? `${birlesik} birleşik kayıt` + (eklenebilir ? ` · ${eklenebilir} satıra ertesi gün eklenebilir` : "") : "Birleştirilecek ardışık gün yok.";
  const bt = $("#birlesHepsi"); if (bt) bt.disabled = kilit || !eklenebilir;
}
if ($("#birlesHepsi")) $("#birlesHepsi").onclick = async () => {
  const d = await durumOku(); if (d.calisiyor || !globalThis.VeliBirlestir) return;
  const r = VeliBirlestir.otomatik(d.satirlar, benim); await durumYaz(d);
  ekMesaj = (r.kayit ? `Ardışık günler birleştirildi: ${r.once} satır → ${r.sonra} kayıt` : "Birleştirilecek ardışık gün yok") + (r.arife ? ` · ${r.arife} arife satırı 0,5 yapıldı` : ""); ilerlemeYaz(d);
};
// ---------- Canlı güncelleme ----------
let ekMesaj = ""; // v2.3.27: Excel yükleme/indirme sonucu, liste yenilense de görünür kalır
function ilerlemeYaz(d) {
  const toplam = d.satirlar.filter((s) => benim(s) && ["HAZIR", "OK", "ATLANDI", "HATA"].includes(s.durum)).length;
  const ok = d.satirlar.filter((s) => benim(s) && s.durum === "OK").length;
  const hata = d.satirlar.filter((s) => benim(s) && s.durum === "HATA").length;
  const s = d.satirlar[d.idx];
  if (d.calisiyor && (d.kapsam || "rapor") !== MOD) { $("#ilerleme").textContent = `Öteki sekmenin (${({ rapor: "Rapor", veli: "Veli İzni", faaliyet: "Faaliyet" })[d.kapsam || "rapor"]}) girişi çalışıyor. Bu listede OK: ${ok}, Hata: ${hata}`; return; }
  $("#ilerleme").textContent = d.calisiyor
    ? `Çalışıyor: ${s ? s.adsoyad || s.tc : ""} — adım: ${d.step}  (OK: ${ok}, Hata: ${hata})`
    : `Beklemede. OK: ${ok}, Hata: ${hata}, Toplam: ${toplam}` + (d.step === "bitti" ? " — bitti" : "") + (ekMesaj ? " · " + ekMesaj : "");
}

async function gunlukCiz() {
  const r = await chrome.storage.local.get(["log", KEY]);
  $("#gunluk").textContent = (r.log || []).join("\n");
  $("#sonHata").textContent = r[KEY] && r[KEY].sonHata ? "Son hata: " + r[KEY].sonHata : "";
}
$("#gunlukKopyala").onclick = async () => { await navigator.clipboard.writeText($("#gunluk").textContent + "\n" + $("#sonHata").textContent); };
$("#gunlukTemizle").onclick = async () => { const d = await durumOku(); d.sonHata = ""; await durumYaz(d); await chrome.storage.local.set({ log: [] }); };
// ---------- v2.4.1: T.C. kasası (KVKK) ----------
async function kasaAcikMi() { return !!(globalThis.EOAKasa && await EOAKasa.acikMi()); }
async function kasaGerekli() { ekMesaj = "T.C. kasası kilitli ya da kurulmamış: açılan sayfada kasayı açın, sonra yeniden deneyin."; try { chrome.runtime.sendMessage({ tip: "kasaAc" }); } catch (e) {} ilerlemeYaz(await durumOku()); kasaCiz(); }
async function kasaCiz() {
  const bar = $("#kasaBar"); if (!bar) return;
  if (VELI || !globalThis.EOAKasa) { bar.hidden = true; return; } // veli izni / faaliyet Okul No ile çalışır
  const b = await EOAKasa.durumBilgisi();
  $("#kasaDurum").textContent = !b.kurulu ? "T.C. kasası kurulmadı — rapor satırları (T.C.) için önce kasa oluşturun." : b.acik ? "T.C. kasası açık (T.C.'ler bu bilgisayarda şifreli)." : "T.C. kasası kilitli — T.C.'ler gizli; Başlat için kasayı açın.";
  $("#kasaDurum").style.color = b.acik ? "" : "#FCD34D";
}
if ($("#kasaAc")) $("#kasaAc").onclick = () => chrome.runtime.sendMessage({ tip: "kasaAc" });
chrome.storage.onChanged.addListener(async (ch, alan) => { // kasa açıldı/kilitlendi: T.C.'ler yeniden çözülsün
  if ((alan === "session" && ch[globalThis.EOAKasa ? EOAKasa.OTURUM : "tcKasaAnahtar"]) || (alan === "local" && ch.tcKasa)) { await kasaCiz(); await tabloCiz(); }
});
chrome.storage.onChanged.addListener(async (ch) => {
  if (ch[RAPOR]) raporCiz();
  // Çalışma bittiğinde (çalışıyor -> durdu) raporu oluştur; bir sonraki başlatmaya kadar saklanır
  if (ch[KEY] && ch[KEY].oldValue && ch[KEY].oldValue.calisiyor && ch[KEY].newValue && !ch[KEY].newValue.calisiyor && !ch[KEY].newValue.deneme)
    await chrome.storage.local.set({ [RAPOR]: raporKur(ch[KEY].newValue) });
  if (ch.log || ch[KEY]) gunlukCiz();
  if (ch[DEV_KEY]) devCiz(); // v2.3.43
  if (!ch[KEY]) return;
  if (!ch[KEY].newValue) { await tabloCiz(); ilerlemeYaz(await durumOku()); return; } // "Tüm verileri sil"
  const aktif = KOK.getRootNode().activeElement;
  if (!(aktif && aktif.closest && aktif.closest("#tablo") && !ch[KEY].newValue.calisiyor)) await tabloCiz();
  ilerlemeYaz(ch[KEY].newValue);
});

(async () => {
  const a = await ayarOku();
  $("#neden").value = a.neden; $("#veliNeden").value = a.veliNeden || "İzinli"; $("#kaydetArasiSn").value = a.kaydetArasiSn ?? 1; $("#veliAciklama").value = a.veliAciklama || "Veli izni"; $("#faaliyetNeden").value = a.faaliyetNeden || "Faaliyet"; $("#faaliyetAciklama").value = a.faaliyetAciklama || "Faaliyet"; $("#faAciklama").value = a.faaliyetAciklama || "Faaliyet"; { const ta = $("#faaliyetAdlari"); if (ta) { const fa = (await chrome.storage.local.get("faaliyetAdlari")).faaliyetAdlari; ta.value = (Array.isArray(fa) ? fa : []).join("\n"); // v2.3.38: yerel faaliyet adı listesi
    ta.onchange = async () => { const l = [...new Set(ta.value.split(/\n+/).map((x) => x.trim().toLocaleUpperCase("tr-TR")).filter(Boolean))]; await chrome.storage.local.set({ faaliyetAdlari: l }); ta.value = l.join("\n"); }; } } $("#sureHesabi").value = a.sureHesabi || "belge"; $("#guvenliMod").checked = a.guvenliMod === true; $("#otoKaydet").checked = a.otoKaydet !== false;
  const sc = { ...SECICI_VARSAYILAN, ...(a.secici || {}) }; for (const k of Object.keys(SECICI_VARSAYILAN)) $("#s_" + k).value = sc[k];
  await kasaCiz(); // v2.4.1
  await tabloCiz(); ilerlemeYaz(await durumOku()); gunlukCiz(); raporCiz(); devCiz();
  if (VELI) faaliyetKur(KOK); // v2.3.37
})();
}

// ---------- v2.3.37: Toplu faaliyet (numara listesi ya da Excel) → Veli İzni listesine Tür=Faaliyet satırları ----------
function faaliyetSatiri(no, bas, sure, aciklama, ay, kaynak) {
  const n = String(no || "").replace(/\D/g, ""), t = RaporYardim.tarihNormal(String(bas || "").trim()), neden = [];
  if (!/^\d{1,6}$/.test(n)) neden.push("Okul No boş/geçersiz"); if (!/^\d\d\/\d\d\/\d{4}$/.test(t)) neden.push("Tarih geçersiz (gg.aa.yyyy)"); if (!/^(1|0,5)$/.test(sure)) neden.push("Süre 1 ya da 0,5 olmalı");
  return { dosya: kaynak, ara: "no", no: n, tc: n, adsoyad: "", bas: t, bit: t, tur: "Faaliyet", neden: ay.faaliyetNeden || "Faaliyet", veli: true, faaliyet: true, sure, yarim: sure === "0,5",
    aciklama: String(aciklama || "").trim() || ay.faaliyetAciklama || "Faaliyet", elleKaydet: true, uyari: neden.join(", "), durum: neden.length ? "KONTROL" : "HAZIR", sonuc: "" };
}
function faaliyetGunleri(bas, adet) { // başlangıçtan itibaren hafta içi günler
  const t = tarihCoz(RaporYardim.tarihNormal(bas)); if (!t) return [bas]; const out = []; const d = new Date(t);
  while (out.length < adet) { if (d.getDay() % 6) out.push(`${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`); d.setDate(d.getDate() + 1); }
  return out;
}
function faaliyetKur(KOK) {
  const $ = (s) => KOK.querySelector(s); if (!$("#faEkle")) return;
  const yaz = (m, hata) => { const e = $("#faDurum"); e.textContent = m; e.style.color = hata ? "#b00020" : "#0b5d1e"; };
  $("#faEkle").onclick = async () => {
    const d = (await chrome.storage.local.get("durum")).durum || { calisiyor: false, satirlar: [], idx: -1, step: "bos", adimNo: 0, stepTs: 0 };
    if (d.calisiyor) { yaz("Giriş çalışırken eklenemez. Önce Durdur'a basın.", true); return; }
    const nolar = $("#faNolar").value.split(/[^0-9]+/).filter(Boolean); if (!nolar.length) { yaz("Okul numarası yazın.", true); return; }
    const ay = (await chrome.storage.local.get("ayar")).ayar || {}, gunler = faaliyetGunleri($("#faTarih").value, Math.max(1, Math.min(10, Number($("#faGun").value) || 1)));
    const yeni = []; for (const no of nolar) for (const g of gunler) yeni.push(faaliyetSatiri(no, g, $("#faSure").value, $("#faAciklama").value, ay, "(toplu faaliyet)"));
    d.satirlar = (d.satirlar || []).concat(yeni); await chrome.storage.local.set({ durum: d });
    const k = yeni.filter((s) => s.durum === "KONTROL").length; yaz(`${yeni.length} faaliyet satırı eklendi (${nolar.length} öğrenci × ${gunler.length} gün). HAZIR ${yeni.length - k}, KONTROL ${k}.`, k > 0);
    $("#faNolar").value = "";
  };
  $("#faXlsx").onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    const d = (await chrome.storage.local.get("durum")).durum || { calisiyor: false, satirlar: [], idx: -1, step: "bos", adimNo: 0, stepTs: 0 };
    if (d.calisiyor) { yaz("Giriş çalışırken yüklenemez.", true); return; }
    let tablo; try { tablo = await EvrakXlsx.oku(await f.arrayBuffer()); } catch (er) { yaz("Excel okunamadı: " + er.message, true); return; }
    const bas = (tablo[0] || []).map((x) => String(x).trim().toLocaleLowerCase("tr")), sut = (...adlar) => bas.findIndex((x) => adlar.some((a) => x.startsWith(a)));
    const iNo = sut("okul no", "no", "numara"), iT = sut("tarih"), iS = sut("süre", "sure"), iA = sut("açıklama", "aciklama", "faaliyet");
    if (iNo < 0) { yaz('Excel başlıkları tanınmadı: ilk satırda en az "Okul No" olmalı (isteğe bağlı: Tarih, Süre, Açıklama).', true); return; }
    const ay = (await chrome.storage.local.get("ayar")).ayar || {}, yeni = [];
    for (const h of tablo.slice(1)) { if (!h || !String(h[iNo] ?? "").trim()) continue;
      const sh = String(iS >= 0 ? h[iS] ?? "" : "").trim().toLocaleLowerCase("tr"), sure = /^(0[,.]5|y|yar)/.test(sh) ? "0,5" : "1";
      yeni.push(faaliyetSatiri(h[iNo], iT >= 0 && String(h[iT] ?? "").trim() ? h[iT] : $("#faTarih").value, sure, iA >= 0 && String(h[iA] ?? "").trim() ? h[iA] : $("#faAciklama").value, ay, "(Excel faaliyet) " + f.name)); }
    d.satirlar = (d.satirlar || []).concat(yeni); await chrome.storage.local.set({ durum: d });
    const k = yeni.filter((s) => s.durum === "KONTROL").length; yaz(`Excel: ${yeni.length} faaliyet satırı eklendi. HAZIR ${yeni.length - k}, KONTROL ${k}.`, k > 0);
  };

  // v2.3.45: tanılama günlüğü dışa aktarma (TC'ler günlükte zaten maskeli; satır özeti maskelenir)
  if ($("#gunlukIndir")) $("#gunlukIndir").onclick = async () => {
    const r = await chrome.storage.local.get(["log", KEY]); const d = r[KEY] || {};
    const m = (x) => String(x || "").replace(/\b([1-9]\d{2})\d{6}(\d{2})\b/g, "$1******$2");
    const satir = (d.satirlar || []).map((x, i) => `${i + 1}. ${m(x.tc)} ${x.faaliyet ? "Faaliyet" : x.veli ? "Veli" : "Rapor"} ${x.bas || ""} süre=${x.sure || ""} durum=${x.durum || ""} sonuç=${x.sonuc || ""}`);
    const t = [`Okul Pro Devamsızlık Rapor Asistanı ${chrome.runtime.getManifest().version} tanılama — ${new Date().toLocaleString("tr")}`, `Adım: ${d.step || "-"} · Çalışıyor: ${!!d.calisiyor} · ${m(d.sonHata || "")}`, "", "SATIRLAR:", ...satir, "", "GÜNLÜK:", ...(r.log || [])].join("\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([t], { type: "text/plain" })); a.download = `eokul-tanilama-${Date.now()}.txt`; a.click();
  };
  
}
if (location.protocol === "chrome-extension:") panelKur(document, ({ veli: "veli", faaliyet: "faaliyet" })[new URLSearchParams(location.search).get("mod")] || "rapor");

