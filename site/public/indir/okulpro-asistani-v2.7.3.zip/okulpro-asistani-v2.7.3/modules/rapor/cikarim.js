"use strict";
// OCR metninden rapor alanlarını çıkaran saf fonksiyonlar (tarayıcı + Node testleri ortak kullanır).
(function (kok) {
  const ASCII = { "Ç": "C", "Ğ": "G", "İ": "I", "Ö": "O", "Ş": "S", "Ü": "U", "Â": "A", "Î": "I", "Û": "U" };
  // Büyük harfe çevirip Türkçe harfleri ASCII'ye indirger; uzunluk korunur (indeksler orijinalle hizalı).
  function eslestirmeMetni(s) {
    return [...s].map((c) => { const u = c.toLocaleUpperCase("tr"); const k = u.length === 1 ? u : c.toUpperCase().slice(0, 1); return ASCII[k] || k; }).join("");
  }

  function tcGecerli(tc) {
    if (!/^\d{11}$/.test(tc) || tc[0] === "0") return false;
    const d = [...tc].map(Number);
    const t1 = d[0] + d[2] + d[4] + d[6] + d[8], t2 = d[1] + d[3] + d[5] + d[7];
    if ((((t1 * 7 - t2) % 10) + 10) % 10 !== d[9]) return false;
    return d.slice(0, 10).reduce((a, b) => a + b, 0) % 10 === d[10];
  }

  // OCR'ın rakam yerine okuduğu harfler
  const RAKAMLAS = { O: "0", o: "0", D: "0", Q: "0", I: "1", l: "1", "|": "1", i: "1", "!": "1", Z: "2", z: "2", S: "5", s: "5", B: "8", G: "6", b: "6", T: "7", g: "9", q: "9" };

  // Metindeki geçerli TC'leri bağlam puanıyla döndürür (en olası ilk).
  function tcBul(metin) {
    const adaylar = new Map();
    const re = /[0-9OoDQIl|i!ZzSsBGbTgq](?:[ \u00a0]?[0-9OoDQIl|i!ZzSsBGbTgq]){10,13}/g;
    let m;
    while ((m = re.exec(metin))) {
      const ham = m[0];
      if ((ham.match(/\d/g) || []).length < 8) continue;
      const temiz = [...ham.replace(/[ \u00a0]/g, "")].map((c) => RAKAMLAS[c] || c).join("");
      for (let i = 0; i + 11 <= temiz.length; i++) {
        const tc = temiz.slice(i, i + 11);
        if (!tcGecerli(tc)) continue;
        const once = eslestirmeMetni(metin.slice(Math.max(0, m.index - 60), m.index));
        let puan = 1;
        if (/(T\.?\s?C\.?|KIMLIK|TCKN|HASTA|OGRENCI)/.test(once)) puan += 5;
        if (/(DOKTOR|HEKIM\s*(TC|KIMLIK)|DIPLOMA|TESCIL|PROTOKOL|BARKOD)/.test(once)) puan -= 4;
        const e = adaylar.get(tc);
        if (!e || e.puan < puan) adaylar.set(tc, { tc, puan, konum: m.index });
      }
    }
    return [...adaylar.values()].sort((a, b) => b.puan - a.puan || a.konum - b.konum);
  }

  const TARIH_RE = /(\d{1,2})\s?[./\-,]\s?(\d{1,2})\s?[./\-,]\s?(\d{4}|\d{2})(?!\d)/g;
  function tarihNesne(g, a, y) {
    g = +g; a = +a; y = +y; if (y < 100) y += 2000;
    const t = new Date(y, a - 1, g);
    return t.getFullYear() === y && t.getMonth() === a - 1 && t.getDate() === g && y > 2000 && y < 2100 ? t : null;
  }
  function tarihler(metin) {
    const r = []; let m; TARIH_RE.lastIndex = 0;
    while ((m = TARIH_RE.exec(metin))) { const t = tarihNesne(m[1], m[2], m[3]); if (t) r.push({ t, i: m.index, son: m.index + m[0].length }); }
    // v2.3.17: OCR ay ile yıl arasındaki noktayı düşürebiliyor ("15.102026")
    const re0 = /(?<!\d)(\d{1,2})[./-](\d{2})(20\d{2})(?!\d)/g;
    while ((m = re0.exec(metin))) { const t = tarihNesne(m[1], m[2], m[3]); if (t && !r.some((x) => x.i === m.index)) r.push({ t, i: m.index, son: m.index + m[0].length }); }
    // "15 Ekim 2026" / "15 EKİM 26" (uzunluk korunan eşleştirme metniyle, indeksler hizalı)
    const M = eslestirmeMetni(metin), AY = { OCAK: 1, SUBAT: 2, MART: 3, NISAN: 4, MAYIS: 5, HAZIRAN: 6, TEMMUZ: 7, AGUSTOS: 8, EYLUL: 9, EKIM: 10, KASIM: 11, ARALIK: 12 };
    const re = /(\d{1,2})\s*\.?\s*(OCAK|SUBAT|MART|NISAN|MAYIS|HAZIRAN|TEMMUZ|AGUSTOS|EYLUL|EKIM|KASIM|ARALIK)\s*(\d{4}|\d{2})(?!\d)/g;
    while ((m = re.exec(M))) { const t = tarihNesne(m[1], AY[m[2]], m[3]); if (t) r.push({ t, i: m.index, son: m.index + m[0].length }); }
    return r.sort((a, b) => a.i - b.i);
  }

  const YAZI_SAYI = { BIR: 1, IKI: 2, UC: 3, DORT: 4, BES: 5, ALTI: 6, YEDI: 7, SEKIZ: 8, DOKUZ: 9, ON: 10, ONBIR: 11, ONIKI: 12, ONUC: 13, ONDORT: 14, ONBES: 15, YIRMI: 20, OTUZ: 30 };

  function gunBul(M) {
    // M: eşleştirme metni (büyük harf ASCII)
    const adaylar = [];
    let m; const re = /(\d{1,3})\s*(?:\(\s*([A-Z ]{2,15})\s*\)\s*)?(?:IS\s*)?GUN/g;
    while ((m = re.exec(M))) {
      const n = +m[1]; if (n < 1 || n > 180) continue;
      const yakın = M.slice(Math.max(0, m.index - 80), m.index + 80);
      let puan = /ISTIRAHAT|RAPOR|SURE/.test(yakın) ? 3 : 1;
      if (m[2] && YAZI_SAYI[m[2].replace(/\s/g, "")] === n) puan += 3;
      // v2.3.14: "10 (BIR) GUN" -> yazıyla yazılan sayı rakamdan güvenilirdir (OCR sona 0 ekleyebiliyor)
      else if (m[2] && YAZI_SAYI[m[2].replace(/\s/g, "")]) { adaylar.push({ n: YAZI_SAYI[m[2].replace(/\s/g, "")], puan: puan + 4, i: m.index }); continue; }
      adaylar.push({ n, puan, i: m.index });
    }
    const re2 = /\b(BIR|IKI|UC|DORT|BES|ALTI|YEDI|SEKIZ|DOKUZ|ON(?:\s?(?:BIR|IKI|UC|DORT|BES))?|YIRMI|OTUZ)\)?\s+GUN/g; // v2.3.17: "(BIR) GUN" (rakam okunamamışsa)
    while ((m = re2.exec(M))) {
      // v2.3.17: memur raporu dipnotu ("bir defada en çok on gün rapor verilebilir", "en çok on gün daha") gün sayısı değildir
      if (/(EN\s*COK|EN\s*FAZLA|AZAMI)\s*$/.test(M.slice(Math.max(0, m.index - 20), m.index)) || /^\s*GUN\s*(DAHA|RAPOR\s*VERILEBILIR)/.test(M.slice(m.index + m[1].length, m.index + m[1].length + 30))) continue;
      adaylar.push({ n: YAZI_SAYI[m[1].replace(/\s/g, "")], puan: 2, i: m.index });
    }
    adaylar.sort((a, b) => b.puan - a.puan || a.i - b.i);
    return adaylar.length ? adaylar[0].n : null;
  }

  function satirlar(metin) { return metin.split(/\r?\n/).map((s) => s.replace(/\s+/g, " ").trim()).filter(Boolean); }

  function kurumBul(metin) {
    const S = satirlar(metin);
    const SA = S.map(eslestirmeMetni);
    let hastane = null, asm = null, hekim = null;
    for (let i = 0; i < S.length; i++) {
      const u = SA[i];
      if (!hastane && /(HASTANES|TIP FAKULTES|ARASTIRMA HASTANE|SAGLIK KOMPLEKS|TIP MERKEZ|POLIKLINI|DIS HEKIMLIGI MERKEZ|AGIZ VE DIS)/.test(u)) hastane = S[i];
      if (!asm && /(AILE SAGLIGI MERKEZ|\bASM\b|NOLU A\.?S\.?M)/.test(u)) asm = S[i];
      if (!hekim) {
        const m = u.match(/AILE HEKIMI\s*(?:ADI SOYADI|ADI)?\s*[:\-]?\s*((?:UZM\.?\s*|DR\.?\s*)*[A-Z][A-Z .]{4,40})/);
        if (m && !/BIRIM|KODU|NO\b|SAGLIGI/.test(m[1])) hekim = S[i].slice(m.index + m[0].length - m[1].length).trim();
        else if (/^(UZM\.?\s*)?DR\.?\s+[A-Z]/.test(u) && asm) hekim = S[i];
      }
    }
    if (hastane && !asm) return { tur: "HASTANE", ad: temizle(hastane) };
    if (asm || hekim) return { tur: "AİLE HEKİMİ", ad: temizle([hekim, asm].filter(Boolean).join(" - ")) };
    if (hastane) return { tur: "HASTANE", ad: temizle(hastane) };
    return { tur: "", ad: "" };
  }
  const temizle = (s) => s.replace(/\s+[.,|]+(?=\s|$)/g, "").replace(/^[^A-Za-zÇĞİÖŞÜçğıöşü]+|[^A-Za-zÇĞİÖŞÜçğıöşü)]+$/g, "").slice(0, 100);

  function adSoyadBul(metin) {
    for (const s of satirlar(metin)) {
      const u = eslestirmeMetni(s);
      const m = u.match(/(?:HASTA(?:NIN)?|OGRENCI(?:NIN)?)?\s*ADI\s*(?:VE\s*)?SOYADI\s*[:\-]?\s*(.+)/);
      if (m && !/HEKIM|DOKTOR/.test(u.slice(0, m.index + 5))) return temizle(s.slice(s.length - m[1].length)).slice(0, 60);
    }
    return "";
  }

  const v_aralik = (b, e) => !!(b && e && e > b);

  // Bir öğrencinin (bir grup sayfanın) metninden rapor alanlarını çıkarır.
  function raporCikar(metin) {
    const M = eslestirmeMetni(metin);
    const tcs = tcBul(metin);
    const T = tarihler(metin);
    const notlar = [];
    let bas = null, bit = null;
    // Aralık: "13.10.2026 - 15.10.2026" veya "13.10.2026 tarihinden 15.10.2026 tarihine kadar"
    for (let k = 0; k + 1 < T.length && !bas; k++) {
      const ara = M.slice(T[k].son, T[k + 1].i);
      if (ara.length < 40 && /^\s*(-|–|—|ILE|\/|TARIHINDEN(\s*ITIBAREN)?|ARASI)?\s*(TARIHINE KADAR)?\s*(-|–)?\s*$/.test(ara) && T[k + 1].t >= T[k].t) {
        bas = T[k].t; bit = T[k + 1].t;
      }
    }
    if (!bas) {
      for (const d of T) {
        const once = M.slice(Math.max(0, d.i - 50), d.i), sonra = M.slice(d.son, d.son + 30);
        if (/(BASLANGIC|BASLAMA|ISTIRAHAT(\s*BAS)?)\s*(TARIHI)?\s*[:\-]?\s*$/.test(once) || /^\s*(TARIHINDEN|ITIBAREN)/.test(sonra)) { bas = d.t; break; }
      }
    }
    if (!bit) {
      for (const d of T) {
        const once = M.slice(Math.max(0, d.i - 40), d.i);
        if (/(BITIS|DONUS|KADAR)\s*(TARIHI)?\s*[:\-]?\s*$/.test(once) && (!bas || d.t >= bas)) { bit = d.t; break; }
      }
    }
    if (!bas) {
      const rt = T.find((d) => /(RAPOR|SEVK|BELGE|MUAYENE)?\s*TARIHI?\s*[:\-]?\s*$|DUZENLEME|MUAYENE/.test(M.slice(Math.max(0, d.i - 40), d.i))) || T[0];
      if (rt) { bas = rt.t; notlar.push("Başlangıç olarak rapor/ilk tarih alındı"); }
    }
    const gun = gunBul(M);
    const kurum = kurumBul(metin);
    // Sevk: gün sayısı/istirahat yoksa (sevk belgesi, "muayene olmuştur", refakat...) -> Sevkli
    const sevkKelime = /SEVK|MUAYENE OLMUS|MUAYENE EDILMIS|REFAKAT|BASVURMUS|POLIKLINIGE GELMIS|HASTANEYE GITMIS|TETKIK ICIN/.test(M);
    const istirahatVar = /ISTIRAHAT|IS GOREMEZ|DINLENME/.test(M);
    const tur = !gun && !(v_aralik(bas, bit)) && (sevkKelime || !istirahatVar) ? "Sevkli" : "Raporlu";
    return { tc: tcs[0] ? tcs[0].tc : "", tcAdaylari: tcs.map((x) => x.tc), ad_soyad: adSoyadBul(metin), baslangic: bas, bitis: bit, gun_sayisi: gun, kurum, notlar, tur, sevkKelime };
  }

  // Sayfa metinlerini TC'ye göre gruplar: TC'li sayfa yeni grup başlatır (aynı TC ise devam), TC'siz sayfa öncekine eklenir.
  function sayfalariGrupla(sayfalar) {
    const gruplar = [];
    for (const s of sayfalar) {
      const tc = (tcBul(s.metin)[0] || {}).tc || "";
      const son = gruplar[gruplar.length - 1];
      if (son && (!tc || tc === son.tc)) son.sayfalar.push(s);
      else if (son && !son.tc && tc) { son.tc = tc; son.sayfalar.push(s); }
      else gruplar.push({ tc, sayfalar: [s] });
    }
    return gruplar;
  }

  // ---- Standart kurum listesi (Açıklama) ve bulanık sınıflandırma ----
  const KURUM_VARSAYILAN = [
    { ad: "Aile Hekimi", anahtar: ["aile sagligi merkezi", "asm", "aile hekimi", "aile hekimligi", "aile hekimligi birimi"] },
    { ad: "Şehir Hastanesi", anahtar: ["sehir hastanesi"] },
    { ad: "Üniversite Hastanesi", anahtar: ["universite", "universitesi", "tip fakultesi", "arastirma ve uygulama hastanesi"] },
    { ad: "Devlet Hastanesi", anahtar: ["devlet hastanesi"] },
  ];
  // "Ad | anahtar1, anahtar2" satırlarından liste
  function kurumListesiCoz(metin) {
    return String(metin || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => {
      const [ad, an] = l.split("|");
      const anahtar = (an || ad).split(",").map((x) => sade(x)).filter(Boolean);
      return { ad: ad.trim(), anahtar };
    }).filter((k) => k.ad);
  }
  const kurumListesiYaz = (liste) => liste.map((k) => `${k.ad} | ${k.anahtar.join(", ")}`).join("\n");
  // küçük harf, Türkçe harfsiz, yalnızca harf/boşluk (OCR'da 0->o, 1->i gibi düzeltmelerle)
  function sade(s) {
    return eslestirmeMetni(String(s)).toLowerCase().replace(/0/g, "o").replace(/[1|!]/g, "i").replace(/5/g, "s").replace(/[^a-z ]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function lev(a, b, sinir) {
    if (Math.abs(a.length - b.length) > sinir) return sinir + 1;
    let on = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      const su = [i]; let min = i;
      for (let j = 1; j <= b.length; j++) { su[j] = Math.min(on[j] + 1, su[j - 1] + 1, on[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); min = Math.min(min, su[j]); }
      if (min > sinir) return sinir + 1;
      on = su;
    }
    return on[b.length];
  }
  // Anahtar kelimeyi metinde OCR hatalarına toleranslı arar; bulunan en iyi eşleşmenin benzerliğini (0..1) döndürür.
  function bulanikAra(kelimeler, anahtar) {
    const ak = anahtar.split(" "), n = ak.length, sinir = anahtar.length <= 4 ? 0 : Math.floor(anahtar.length / 6);
    let en = 0;
    for (let i = 0; i + n <= kelimeler.length; i++) {
      for (const ek of [0, 1, -1]) { // OCR bitişik/ayrık kelime toleransı
        const m = n + ek; if (m < 1 || i + m > kelimeler.length) continue;
        const parca = kelimeler.slice(i, i + m).join(" ");
        const pk = ak.length === 1 && m === 1 ? parca : parca;
        const d = lev(pk, anahtar, sinir);
        if (d <= sinir) en = Math.max(en, 1 - d / Math.max(anahtar.length, 1));
      }
    }
    return en;
  }
  // Metni listeye göre sınıflar. Güvenli tek kazanan yoksa ad = "" döner.
  function kurumSinifla(metin, liste) {
    liste = liste && liste.length ? liste : KURUM_VARSAYILAN;
    const kelimeler = sade(metin).split(" ").filter(Boolean);
    const puanlar = liste.map((k) => {
      let p = 0;
      for (const a of k.anahtar) { const b = bulanikAra(kelimeler, a); if (b) p = Math.max(p, b * Math.min(a.length, 20)); }
      return { ad: k.ad, p };
    }).sort((x, y) => y.p - x.p);
    const [bir, iki] = puanlar;
    if (!bir || bir.p < 2.5) return { ad: "", puanlar };
    if (iki && iki.p > 0 && iki.p >= bir.p * 0.8) return { ad: "", puanlar, belirsiz: true };
    return { ad: bir.ad, puanlar };
  }

  const api = { KURUM_VARSAYILAN, kurumListesiCoz, kurumListesiYaz, kurumSinifla, tcGecerli, tcBul, tarihler, gunBul, kurumBul, raporCikar, sayfalariGrupla, eslestirmeMetni };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  kok.RaporCikarim = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
