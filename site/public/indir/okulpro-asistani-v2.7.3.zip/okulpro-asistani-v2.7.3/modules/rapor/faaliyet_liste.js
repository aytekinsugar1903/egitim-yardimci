// v2.4.3: Taranmış "faaliyet / görevli-izinli öğrenci listesi" resmî yazısı (üstte yazı + tarih, altta çizgili NUMARA / SINIF / ADI-SOYADI tablosu).
// Tam sayfa Tesseract çizgili tablodaki küçük yazıyı okuyamıyor; tablo çizgileri piksellerden bulunur, her hücre ayrı okunur (çevrimdışı, görüntü saklanmaz).
(function (kok) {
  const N = (s) => String(s || "").toLocaleUpperCase("tr").replace(/\u0130/g, "I").replace(/\u015e/g, "S").replace(/\u011e/g, "G").replace(/\u00dc/g, "U").replace(/\u00d6/g, "O").replace(/\u00c7/g, "C"); // \u kaçışları: dosya kodlamasından bağımsız
  // Yazı bir öğrenci listesi + faaliyet/izin bildirimi mi? (veli izni / faaliyet formu VeliFormu'nda önce denenir)
  function belgeMi(metin) {
    const t = N(metin).replace(/\s+/g, " ");
    // v2.4.7: el yazılı veli izni / devamsızlık formları liste sanılıp ElRakam (el yazısı rakam modeli) atlanıyordu — dilekçe/veli formu sözcükleri varsa liste sayılmaz (başlık OCR'da bozuk okunabildiği için şart koşulmaz)
    return /FAALIYET|IZINLI|GOREVLI/.test(t) && /ISIMLERI\s*(YAZILI|BELIRTILEN)|ASAGIDA.{0,40}OGRENCI|OGRENCILERIMIZ|OGRENCI LISTESI|KATILACAK/.test(t)
      && !/DILEKCE|VELI\s*IZIN\s*FORMU|ARZ\s*EDERIM.{0,80}VELI|VELISI/.test(t);
  }
  function enUzunKosu(n, kara, bosluk) { let en = 0, k = 0, b = 0; for (let i = 0; i < n; i++) { if (kara(i)) { k += 1 + b; b = 0; if (k > en) en = k; } else if (++b > bosluk) { k = 0; b = 0; } } return en; }
  function grupla(a, ara) { const g = []; for (const v of a) { const s = g[g.length - 1]; if (s && v - s[1] <= ara) s[1] = v; else g.push([v, v]); } return g.map(([a0, a1]) => Math.round((a0 + a1) / 2)); }
  // Gri görüntüde (Uint8, 0 siyah) tablo çizgileri: yatay = sayfa eninin %35'inden uzun neredeyse kesintisiz koşu; dikey = tablo yüksekliğinin %80'i
  function izgara(g, w, h, esik = 215) {
    const kara = (x, y) => g[y * w + x] < esik;
    const ys = []; for (let y = 0; y < h; y++) if (enUzunKosu(w, (x) => kara(x, y), 3) > 0.35 * w) ys.push(y);
    let Y = grupla(ys, 2); if (Y.length < 3) return null;
    // en uzun düzenli aralıklı küme (yazının altındaki tek çizgi vb. elenir)
    const ara = Y.slice(1).map((v, i) => v - Y[i]).sort((a, b) => a - b), rh = ara[Math.floor(ara.length / 2)];
    let iyi = [], cur = [Y[0]]; for (let i = 1; i < Y.length; i++) { if (Math.abs(Y[i] - Y[i - 1] - rh) <= Math.max(4, 0.35 * rh) || (Y[i] - Y[i - 1] > rh && Y[i] - Y[i - 1] < 2.6 * rh && cur.length > 1)) cur.push(Y[i]); else { if (cur.length > iyi.length) iyi = cur; cur = [Y[i]]; } } if (cur.length > iyi.length) iyi = cur;
    Y = iyi; if (Y.length < 3 || rh < 12) return null;
    const y0 = Y[0], y1 = Y[Y.length - 1], xs = [];
    for (let x = 0; x < w; x++) if (enUzunKosu(y1 - y0 + 1, (i) => kara(x, y0 + i), 3) > 0.8 * (y1 - y0)) xs.push(x);
    const X = grupla(xs, 4); if (X.length < 3) return null;
    // üst kenar çizgisi silik/kayıpsa: ilk çizginin bir satır üstünde mürekkep varsa (başlık satırı) sanal çizgi
    const ust = y0 - rh; if (ust > 0) { let m = 0; for (let y = ust + 3; y < y0 - 3; y++) for (let x = X[0] + 3; x < X[X.length - 1] - 3; x++) if (kara(x, y)) m++; if (m > 0.01 * rh * (X[X.length - 1] - X[0])) Y.unshift(ust); }
    return { y: Y, x: X, rh };
  }
  function murekkep(g, w, x0, y0, x1, y1, esik = 160) { let m = 0; for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) if (g[y * w + x] < esik) m++; return m; }
  const noNorm = (s) => { const t = String(s || "").replace(/[OoQD]/g, "0").replace(/[Il|!]/g, "1").replace(/[Ss]/g, "5").replace(/[Bb]/g, "8").replace(/\D/g, ""); return t; };
  function sinifNorm(s) { const t = N(s).replace(/\s+/g, ""); const m = /(9|1[0-2]|[5-8])[-\/.]?([A-Z])/.exec(t); return m ? `${m[1]}-${m[2]}` : ""; }
  function adNorm(s) { return String(s || "").replace(/[|_\[\]{}()<>=*~"\u201c\u201d#@$%^&+\\/0-9]/g, " ").replace(/\s+/g, " ").trim(); }
  // sütun rolleri: önce başlık, yoksa içerik (rakam 3-6 = numara, 9-A biçimi = sınıf, en uzun yazı = ad, 1-2 hane artan = sıra)
  function roller(baslik, govde) {
    const k = baslik.length, r = new Array(k).fill("");
    baslik.forEach((b, j) => { const t = N(b).replace(/[^A-Z]/g, ""); if (/SOYAD|ADI|ISIM/.test(t)) r[j] = "ad"; else if (/SINIF|SUBE/.test(t)) r[j] = "sinif"; else if (/SIRA|^SNO$/.test(t)) r[j] = "sira"; else if (/NUMARA|^NO$|OKULNO|OGRNO/.test(t)) r[j] = "no"; });
    const skor = (j, f) => govde.filter((s) => s[j] && f(s[j])).length;
    for (const [rol, f] of [["sinif", (v) => !!sinifNorm(v) && !/\d{3}/.test(v)], ["no", (v) => /^\d{3,6}$/.test(noNorm(v)) && !sinifNorm(v)], ["ad", (v) => /[A-Za-z\u00c0-\u017f]{2,}\s+[A-Za-z\u00c0-\u017f]{2,}/.test(v)]]) {
      if (r.includes(rol)) continue; let en = -1, ej = -1; for (let j = 0; j < k; j++) if (!r[j]) { const s = skor(j, f); if (s > en) { en = s; ej = j; } } if (ej >= 0 && en > 0) r[ej] = rol; }
    return r;
  }
  // tablonun ÜSTÜNDEKİ yazıdaki tarih(ler); imza tarihi tablonun altındadır
  function tarihler(kel, tabloUst) {
    const ust = kel.filter((x) => x.bbox.y1 < tabloUst).sort((a, b) => a.bbox.y0 - b.bbox.y0 || a.bbox.x0 - b.bbox.x0);
    const metin = ust.map((x) => x.text).join(" "), T = N(metin), yarim = /YARIM\s*GUN|OGLEDEN\s*(SONRA|ONCE)|0[,.]5\s*GUN/.test(T);
    const cikan = [], gor = new Set(), ekle = (g, a, y, guv) => { const d = new Date(+y, +a - 1, +g); if (d.getMonth() !== +a - 1 || d.getDate() !== +g) return; const s = `${String(g).padStart(2, "0")}/${String(a).padStart(2, "0")}/${y}`; if (!gor.has(s)) { gor.add(s); cikan.push({ tarih: s, guven: guv }); } };
    const guv = (s) => { const w = ust.find((x) => x.text.includes(s.split(/\s/)[0])); return w && w.confidence >= 80 ? 95 : 60; };
    const re = /\b(\d{1,2})\s*[-\u2013]\s*(\d{1,2})\s*[./]\s*(\d{1,2})\s*[./]\s*(20\d\d)\b|\b(\d{1,2})\s*[./]\s*(\d{1,2})\s*[./]\s*(20\d\d)\b/g; let m;
    while ((m = re.exec(metin))) { if (m[1]) { const a = +m[1], b = +m[2]; if (b >= a && b - a <= 6) for (let g = a; g <= b; g++) ekle(g, m[3], m[4], 60); } else ekle(m[5], m[6], m[7], guv(m[0])); }
    return { liste: cikan.map((t) => ({ ...t, yarim, gun: yarim ? 0.5 : 1, supheli: false, not: t.guven < 70 ? "Faaliyet tarihi emin değil — yazıdan kontrol edin" : "" })), yarim };
  }
  // ocr(x0, y0, x1, y1, whitelist, psm) → {text, confidence}; g: gri piksel, w×h
  async function oku({ g, w, h, kel, metin, ocr }) {
    if (!belgeMi(metin)) return null;
    const Z = izgara(g, w, h); if (!Z) return null;
    const pay = Math.max(3, Math.round(Z.rh * 0.1)), hucre = (i, j) => [Z.x[j] + pay, Z.y[i] + pay, Z.x[j + 1] - pay, Z.y[i + 1] - pay];
    const sat = [], k = Z.x.length - 1;
    for (let i = 0; i < Z.y.length - 1; i++) { const r = []; let bos = true;
      for (let j = 0; j < k; j++) { const [a, b, c, d] = hucre(i, j); if (murekkep(g, w, a, b, c, d) < 12) { r.push(""); continue; } bos = false; const o = await ocr(a, b, c, d, "", "7"); r.push(String(o.text || "").trim()); }
      sat.push(bos ? null : r); }
    const dolu = sat.filter(Boolean); if (dolu.length < 2) return null;
    let bas = 0; const ilk = sat.findIndex(Boolean); const R0 = roller(sat[ilk], []);
    if (R0.filter(Boolean).length >= 2) bas = ilk + 1; // ilk dolu satır başlık
    const govde = sat.slice(bas).filter(Boolean), R = bas ? (() => { const r = roller(sat[ilk], govde); return r; })() : roller(new Array(k).fill(""), govde);
    const jNo = R.indexOf("no"); if (jNo < 0) return null;
    const ogrenciler = [], uyari = [];
    for (let i = bas; i < sat.length; i++) { const r = sat[i]; if (!r) continue;
      const [a, b, c, d] = hucre(i, jNo); let no = "", guv = 0;
      if (r[jNo]) { const o = await ocr(a, b, c, d, "0123456789", "7"); no = noNorm(o.text); guv = (o.confidence || 0) / 100; const ilkOku = noNorm(r[jNo]); if (ilkOku && ilkOku !== no) guv = Math.min(guv, 0.5); }
      const ad = R.includes("ad") ? adNorm(r[R.indexOf("ad")]) : "", sinif = R.includes("sinif") ? sinifNorm(r[R.indexOf("sinif")]) : "";
      if (!no && !ad) continue;
      const gecerli = /^\d{1,6}$/.test(no), noGuven = gecerli && no.length >= 3 ? guv : 0;
      ogrenciler.push({ no, noGuven, ad, sinif, satir: i - bas + 1, noUyari: !gecerli ? `Numara okunamadı ("${r[jNo] || ""}") — görüntüden yazın` : noGuven < 0.8 ? `Numara emin değil (${no}) — kontrol edin` : "" }); }
    const T = tarihler(kel, Z.y[0]);
    if (!T.liste.length) { T.liste.push({ tarih: "", gun: 1, yarim: false, guven: 0, supheli: false, not: "Faaliyet tarihi yazıda bulunamadı — tarihi yazın" }); uyari.push("Faaliyet tarihi bulunamadı"); }
    const faAd = etkinlik(metin || kel.map((x) => x.text).join(" ")); // v2.4.6: faaliyet adı (Kros, Futbol…) → Açıklama
    return { ogrenciler, tarihler: T.liste, uyari, izgara: Z, hucreler: sat.filter(Boolean), faAd };
  }
  // v2.4.6: yazıdaki etkinlik adı. Önce sözlük (ayarlardaki faaliyet adları + spor/etkinlik listesi), yoksa "… müsabaka/turnuva/yarışma" öncesindeki büyük harfli kelime.
  const ETK = ["KROS", "FUTBOL", "FUTSAL", "VOLEYBOL", "BASKETBOL", "HENTBOL", "ATLETIZM", "SATRANC", "MASA TENISI", "TENIS", "BADMINTON", "GURES", "YUZME", "JUDO", "KARATE", "TAEKWONDO", "BOKS", "OKCULUK", "HALK OYUNLARI", "BOCCE", "DART", "BISIKLET", "JIMNASTIK", "ORYANTIRING", "KAYAK", "ESKRIM", "BILEK GURESI", "MANGALA", "ZEKA OYUNLARI", "TIYATRO", "KORO", "MUNAZARA", "BILGI YARISMASI", "SERGI", "GEZI", "TUBITAK", "TEKNOFEST", "BILIM FUARI"];
  const TR = { KROS: "Kros", FUTBOL: "Futbol", FUTSAL: "Futsal", VOLEYBOL: "Voleybol", BASKETBOL: "Basketbol", HENTBOL: "Hentbol", ATLETIZM: "Atletizm", SATRANC: "Satranç", "MASA TENISI": "Masa Tenisi", TENIS: "Tenis", BADMINTON: "Badminton", GURES: "Güreş", YUZME: "Yüzme", JUDO: "Judo", KARATE: "Karate", TAEKWONDO: "Taekwondo", BOKS: "Boks", OKCULUK: "Okçuluk", "HALK OYUNLARI": "Halk Oyunları", BOCCE: "Bocce", DART: "Dart", BISIKLET: "Bisiklet", JIMNASTIK: "Jimnastik", ORYANTIRING: "Oryantiring", KAYAK: "Kayak", ESKRIM: "Eskrim", "BILEK GURESI": "Bilek Güreşi", MANGALA: "Mangala", "ZEKA OYUNLARI": "Zeka Oyunları", TIYATRO: "Tiyatro", KORO: "Koro", MUNAZARA: "Münazara", "BILGI YARISMASI": "Bilgi Yarışması", SERGI: "Sergi", GEZI: "Gezi", TUBITAK: "TÜBİTAK", TEKNOFEST: "TEKNOFEST", "BILIM FUARI": "Bilim Fuarı" };
  const bas = (s) => String(s).toLocaleLowerCase("tr").replace(/(^|\s)(\S)/g, (m, a, b) => a + b.toLocaleUpperCase("tr"));
  function etkinlik(metin) {
    const T = " " + N(metin).replace(/[^A-Z0-9 ]+/g, " ").replace(/\s+/g, " ") + " ";
    const kul = (globalThis.FAALIYET_ADLARI || []).map((x) => [N(x).replace(/[^A-Z0-9 ]+/g, " ").trim(), String(x)]).filter((x) => x[0].length > 2);
    const uz = (l) => l.sort((a, b) => b[0].length - a[0].length);
    for (const [n, ham] of [...uz(ETK.map((e) => [e, TR[e]])), ...uz(kul)]) if (T.includes(" " + n + " ")) return { metin: TR[n] || bas(ham), ham: n, sozluk: true, guven: 0.95 };
    const m = /([A-Z]{3,}(?: [A-Z]{3,})?) (MUSABAKA|TURNUVA|YARISMA|SAMPIYONA|MAC|ETKINLIG|GOSTERI|FESTIVAL)/.exec(T);
    if (m) return { metin: bas(m[1]), ham: m[1], sozluk: false, guven: 0.6 };
    return null;
  }
  kok.FaaliyetListe = { etkinlik, belgeMi, izgara, roller, tarihler, oku, noNorm, sinifNorm, adNorm };
})(typeof globalThis !== "undefined" ? globalThis : this);
