// v2.6.1: Brother tarayıcı JPEG'leri (eksik EOI, bozulmuş işaret, SOI'den önce çöp) createImageBitmap ile açılamayabiliyor; Image() veya onarım yedekleri.
(function (kok) {
  function jpegOnar(bytes) {
    const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
    let soi = -1;
    for (let i = 0; i < u8.length - 1; i++) {
      if (u8[i] === 0xFF && u8[i + 1] === 0xD8) { soi = i; break; }
    }
    if (soi < 0) return null;
    const govde = soi === 0 ? u8 : u8.subarray(soi);
    let eoi = -1;
    for (let i = govde.length - 2; i >= 1; i--) {
      if (govde[i] === 0xFF && govde[i + 1] === 0xD9) { eoi = i; break; }
    }
    if (eoi >= 0 && soi === 0) return u8;
    const son = eoi >= 0 ? govde.subarray(0, eoi + 2) : govde;
    const out = new Uint8Array(son.length + (eoi >= 0 ? 0 : 2));
    out.set(son, 0);
    if (eoi < 0) { out[son.length] = 0xFF; out[son.length + 1] = 0xD9; }
    return out;
  }

  function resimYukle(blob) {
    return new Promise((coz, red) => {
      const url = URL.createObjectURL(blob);
      const im = new Image();
      const bitir = (fn, arg) => { URL.revokeObjectURL(url); fn(arg); };
      im.onload = () => bitir(coz, im);
      im.onerror = () => bitir(red, new Error("Görüntü çözülemedi"));
      im.src = url;
    });
  }

  async function gorselCoz(file) {
    const opts = { imageOrientation: "from-image" };
    try { return await createImageBitmap(file, opts); } catch (e1) {
      try { return await createImageBitmap(file); } catch (e2) { /* Image() yedeği */ }
    }
    try { return await resimYukle(file instanceof Blob ? file : new Blob([file])); }
    catch (e3) {
      const buf = new Uint8Array(await file.arrayBuffer());
      const onar = jpegOnar(buf);
      if (!onar) throw e3;
      const blob = new Blob([onar], { type: "image/jpeg" });
      try { return await createImageBitmap(blob, opts); } catch (e4) {
        try { return await createImageBitmap(blob); } catch (e5) {
          return await resimYukle(blob);
        }
      }
    }
  }


  function pdfEofVar(u8) {
    const sig = [0x25, 0x25, 0x45, 0x4F, 0x46]; // %%EOF
    const bas = Math.max(0, u8.length - 65536);
    for (let i = u8.length - 5; i >= bas; i--) {
      let ok = true;
      for (let j = 0; j < 5; j++) if (u8[i + j] !== sig[j]) { ok = false; break; }
      if (ok) return true;
    }
    return false;
  }
  function jpegEoiVar(u8) {
    for (let i = u8.length - 2; i >= 1; i--) if (u8[i] === 0xFF && u8[i + 1] === 0xD9) return true;
    return false;
  }
  function dosyaTeshis(ad, bytes) {
    const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
    const adl = String(ad || "").toLowerCase();
    if (!u8.length) return { ok: false, uyari: "Dosya boş (0 bayt). Tarama bitmeden kopyalanmış olabilir; cihazdan yeniden tarayın." };
    if (u8.length < 8) return { ok: false, uyari: "Dosya çok küçük (" + u8.length + " bayt). Tarama veya kopyalama yarıda kesilmiş olabilir; yeniden tarayın." };
    const pdf = u8[0] === 0x25 && u8[1] === 0x50 && u8[2] === 0x44 && u8[3] === 0x46;
    const jpeg = u8.length >= 3 && u8[0] === 0xFF && u8[1] === 0xD8 && u8[2] === 0xFF;
    const png = u8[0] === 0x89 && u8[1] === 0x50 && u8[2] === 0x4E && u8[3] === 0x47;
    if (pdf) {
      const kesik = !pdfEofVar(u8);
      return { ok: true, tur: "pdf", kesik, uyari: kesik ? "PDF kesik görünüyor (bitiş işareti %%EOF yok). Tarama veya kopyalama yarıda kesilmiş olabilir; yeniden tarayın." : "" };
    }
    if (/\.pdf$/i.test(adl) && !pdf) return { ok: false, tur: "degil", uyari: "Bu dosya PDF değil (beklenen %PDF başı yok). Yanlış uzantı veya yarım kalmış tarama olabilir; yeniden tarayın." };
    if (jpeg) return { ok: true, tur: "jpeg", kesik: !jpegEoiVar(u8) };
    if (jpegOnar(u8)) return { ok: true, tur: "jpeg", onarildi: true };
    if (/\.jpe?g$/i.test(adl)) return { ok: false, tur: "degil", uyari: "Bu dosya JPEG değil (beklenen FF D8 başı yok). Brother taraması yarım kalmış veya dosya bozulmuş olabilir; yeniden tarayın." };
    if (png) return { ok: true, tur: "png" };
    return { ok: true, tur: "diger" };
  }

  const API = { jpegOnar, gorselCoz, dosyaTeshis };

  if (typeof module === "object" && module.exports) module.exports = API;
  kok.VeliJpeg = API;
})(typeof globalThis !== "undefined" ? globalThis : this);
