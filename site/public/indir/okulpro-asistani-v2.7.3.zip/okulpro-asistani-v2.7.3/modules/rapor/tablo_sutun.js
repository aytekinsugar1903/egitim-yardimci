// v2.3.32: Rapor listesi CSV / Excel indir-yükle için TEK sütun tanımı. Yükleme başlık ADINA göre eşler (sıraya göre asla).
// v2.5.3: ek başlık takma adları, başlık yoksa eski konumsal sıra, ek sütunlar nota alınır; maskeli T.C. (149******52) kısmi anahtar olarak eşlenir.
(function (kok) {
  const SUTUNLAR = [
    { k: "dosya", b: "Dosya", eski: ["Sayfalar"] },
    { k: "tc", b: "TC / Okul No", eski: ["TC", "Okul No", "TC Kimlik", "TC Kimlik No", "T.C. Kimlik No", "TCKN", "T.C.", "T.C. Kimlik"] },
    { k: "adsoyad", b: "Ad Soyad", eski: ["AdSoyad", "Adı Soyadı", "Ad Soyadı", "Adı Soyad"] },
    { k: "bas", b: "Başlangıç", eski: ["Baslangic", "Başlangıç Tarihi", "Baslangic Tarihi"] },
    { k: "bit", b: "Bitiş", eski: ["Bitis", "Bitiş Tarihi", "Bitis Tarihi"] },
    { k: "tur", b: "Tür", eski: ["Tur"] },
    { k: "sure", b: "Süre", eski: ["Sure", "Süre (Gün)", "Sure (Gun)"] },
    { k: "aciklama", b: "Açıklama", eski: ["Aciklama"] },
    { k: "uyari", b: "Uyarı", eski: ["Uyari", "Not / Neden"] },
    { k: "durum", b: "Durum" },
    { k: "sonuc", b: "Sonuç", eski: ["Sonuc"] },
  ];
  const BASLIKLAR = SUTUNLAR.map((s) => s.b);
  const katla = (s) => String(s ?? "").toLocaleLowerCase("tr").replace(/i̇/g, "i").replace(/ı/g, "i").replace(/ş/g, "s").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ö/g, "o").replace(/ç/g, "c").replace(/[^a-z0-9]/g, "");
  const adKatla = (s) => String(s ?? "").toLocaleLowerCase("tr").replace(/i̇/g, "i").replace(/ı/g, "i").replace(/ş/g, "s").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ö/g, "o").replace(/ç/g, "c").replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
  // başlık satırı -> { anahtar: sütun no }
  function eslestir(baslik) {
    const ad = (baslik || []).map(katla), es = {};
    for (const s of SUTUNLAR) { const i = ad.findIndex((x) => [s.b, ...(s.eski || [])].some((y) => katla(y) === x)); if (i >= 0) es[s.k] = i; }
    return es;
  }
  const baslikVarMi = (satir) => Object.keys(eslestir(satir || [])).length > 0;
  const p2 = (n) => String(n).padStart(2, "0");
  // her biçimden (gg/aa/yyyy, gg.aa.yyyy, yyyy-aa-gg, Excel seri no) -> iç biçim gg/aa/yyyy
  function tarihIc(v) {
    const s = String(v ?? "").trim(); if (!s) return "";
    if (/^\d{5}(\.\d+)?$/.test(s) && +s > 20000 && +s < 80000) { const d = new Date(Date.UTC(1899, 11, 30) + Math.round(+s * 86400000)); return `${p2(d.getUTCDate())}/${p2(d.getUTCMonth() + 1)}/${d.getUTCFullYear()}`; }
    let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/); if (m) return `${p2(+m[3])}/${p2(+m[2])}/${m[1]}`;
    m = s.match(/^(\d{1,2})\s*[./\-]\s*(\d{1,2})\s*[./\-]\s*(\d{2,4})$/); if (m) return `${p2(+m[1])}/${p2(+m[2])}/${m[3].length === 2 ? "20" + m[3] : m[3]}`;
    return s;
  }
  const tarihDis = (v) => { const s = tarihIc(v); return /^\d{2}\/\d{2}\/\d{4}$/.test(s) ? s.replace(/\//g, ".") : s; }; // dosyaya gg.aa.yyyy
  // TC'yi metin olarak geri al: ="123", 5,47872940840E+10, 54787294084.0 — maskeli değer (149******52) olduğu gibi kalır
  function kimlikMetni(v) {
    let s = String(v ?? "").trim().replace(/^="(.*)"$/, "$1").replace(/^'/, "");
    if (maskeliMi(s)) return s.replace(/\s/g, "");
    if (/^\d+(?:[.,]\d+)?e\+?\d+$/i.test(s)) { const n = Number(s.replace(",", ".")); if (Number.isFinite(n)) s = n.toFixed(0); }
    else if (/^\d+[.,]0+$/.test(s)) s = s.replace(/[.,]0+$/, "");
    return s.replace(/\s/g, "");
  }
  // v2.5.3: 3 ilk + son 2 hane, ortası yıldız (sayısı esnek). Tam 11 hane de aynı anahtara indirgenir.
  function maskeliMi(v) { return /^\d{3}\*+\d{2}$/.test(String(v ?? "").trim().replace(/\s/g, "")); }
  function maskeAnahtar(v) {
    const s = String(v ?? "").trim().replace(/\s/g, "");
    const m = s.match(/^(\d{3})\*+(\d{2})$/); if (m) return m[1] + m[2];
    const d = s.replace(/\D/g, ""); return /^\d{11}$/.test(d) ? d.slice(0, 3) + d.slice(-2) : "";
  }
  function adUyar(ad, aday) {
    const a = adKatla(ad), b = adKatla(aday); if (!a) return true; if (!b) return false;
    if (a === b) return true;
    if (b.startsWith(a) || a.startsWith(b)) return true;
    const [kisa, uzun] = a.length <= b.length ? [a, b] : [b, a];
    return kisa.split(" ").every((t) => t && uzun.split(" ").some((x) => x === t || x.startsWith(t) || t.startsWith(x)));
  }
  // liste: [{tc|t, adsoyad|a, no|n}]. Tam T.C. aynı olan adaylar tek kişi sayılır.
  function maskeIleEsle(maske, adsoyad, liste) {
    const yok = { durum: "yok", adaylar: [], mesaj: "Maskeli TC: öğrenci listesiyle eşleşmedi" };
    const key = maskeAnahtar(maske); if (!key) return yok;
    const ham = (liste || []).filter((k) => maskeAnahtar(k.tc || k.t) === key);
    const bir = (arr) => { const m = new Map(); for (const k of arr) { const t = String(k.tc || k.t || ""); if (t && !m.has(t)) m.set(t, k); } return [...m.values()]; };
    let sec = bir(ham); if (!sec.length) return yok;
    if (String(adsoyad || "").trim()) {
      const adli = bir(sec.filter((k) => adUyar(adsoyad, k.adsoyad || k.a)));
      if (!adli.length) return yok;
      sec = adli;
    }
    if (sec.length === 1) return { durum: "tek", kayit: sec[0], adaylar: sec, mesaj: "" };
    return { durum: "cok", adaylar: sec, mesaj: "Maskeli TC: birden fazla öğrenci eşleşti, seçin" };
  }
  // e-Okul / Excel öğrenci listesi (T.C. sütunu varsa). Yalnız yerel eşleme için; varsayılan Veli listesine dokunmaz.
  function ogrenciTcOku(tablo) {
    const T = (tablo || []).filter((r) => r && r.some((x) => String(x ?? "").trim())); if (!T.length) return { kayitlar: [], uyari: "Tablo boş." };
    let hi = -1, iT = -1, iN = -1, iA = -1, iSoy = -1;
    for (let i = 0; i < Math.min(8, T.length) && hi < 0; i++) {
      const b = T[i].map(adKatla);
      const t = b.findIndex((x) => /^(t c kimlik no|t c kimlik|tc kimlik no|tc kimlik|tckn|t c|tc)$/.test(x.replace(/\s+/g, " ")));
      if (t >= 0) { hi = i; iT = t; iN = b.findIndex((x) => /^(okul no|okulno|ogrenci no|ogrno|numara|no|okul numarasi|ogrenci numarasi)$/.test(x)); iA = b.findIndex((x) => /^(adi soyadi|ad soyad|adsoyad|ogrenci adi soyadi|ad soyadi|isim|ogrenci adi|ad|adi)$/.test(x)); iSoy = b.findIndex((x) => /^(soyadi|soyad)$/.test(x)); }
    }
    if (hi < 0) return { kayitlar: [], uyari: 'T.C. sütunu bulunamadı: ilk satırda "T.C. Kimlik No" veya "TC" başlığı olsun.' };
    const kay = new Map(); let atlanan = 0;
    for (const r of T.slice(hi + 1)) {
      const tc = kimlikMetni(r[iT]); if (!/^\d{11}$/.test(tc)) { atlanan++; continue; }
      let a = iA >= 0 ? String(r[iA] ?? "").trim() : ""; if (iSoy >= 0 && r[iSoy]) a = (a + " " + String(r[iSoy]).trim()).trim();
      kay.set(tc, { tc, adsoyad: a, no: iN >= 0 ? String(r[iN] ?? "").replace(/\D/g, "") : "" });
    }
    return { kayitlar: [...kay.values()], atlanan, uyari: kay.size ? "" : "Geçerli T.C. kimlik no bulunamadı." };
  }
  // satır nesnesi -> dosya hücreleri (11 sütun, tablo sırası)
  const tcMaske = (v) => String(v ?? "").replace(/^(\d{3})\d{6}(\d{2})$/, "$1******$2"); // v2.4.1 (KVKK): dışa aktarılan dosyada düz T.C. olmaz
  const disaSatir = (s, VELI) => SUTUNLAR.map(({ k }) => k === "tc" ? tcMaske(String((s.ara === "no" ? s.no || s.tc : s.tc) ?? "")) : k === "bas" || k === "bit" ? tarihDis(s[k]) : k === "tur" && s.veli ? "İzinli" : String(s[k] ?? ""));
  // tablo ([[başlık], [satır]...]) -> ham alan nesneleri; başlık tanınmazsa konumsal sıra (eski panel sırası)
  function icAl(tablo) {
    if (!tablo || !tablo.length) return [];
    const varBaslik = baslikVarMi(tablo[0]);
    let es, veri;
    if (varBaslik) {
      es = eslestir(tablo[0]);
      if (es.tc === undefined || es.bas === undefined) throw new Error('başlıklar tanınmadı: ilk satırda en az "TC / Okul No" ve "Başlangıç" olmalı');
      veri = tablo.slice(1);
    } else {
      es = {}; SUTUNLAR.forEach((s, i) => { es[s.k] = i; });
      veri = tablo;
    }
    const al = (h, k) => es[k] === undefined ? "" : String(h[es[k]] ?? "").trim();
    const kullanilan = new Set(Object.values(es));
    return veri.filter((h) => h && h.some((x) => String(x ?? "").trim())).map((h) => {
      const o = {}; for (const { k } of SUTUNLAR) o[k] = al(h, k);
      const km = kimlikMetni(o.tc); o.tc = maskeliMi(km) ? km.replace(/\s/g, "") : km.replace(/\D/g, "");
      o.bas = tarihIc(o.bas); o.bit = tarihIc(o.bit);
      o.sure = o.sure.replace(".", ",");
      if (varBaslik) {
        const notlar = [];
        (tablo[0] || []).forEach((ad, i) => {
          if (kullanilan.has(i)) return;
          const v = String(h[i] ?? "").trim(); if (!v) return;
          const kn = katla(ad);
          if (kn === "belgedekigun" || kn === "belgedekigun") { if (!o.sure) o.sure = v.replace(".", ","); else notlar.push(ad + ": " + v); }
          else if (kn === "okunankurum") { if (!o.aciklama) o.aciklama = v; else notlar.push(ad + ": " + v); }
          else notlar.push((ad || "Sütun") + ": " + v);
        });
        if (notlar.length) o.ekNot = notlar.join(" · ");
      }
      o._var = es; return o;
    });
  }
  // CSV: ; , veya sekme ayırıcı, tırnaklı alan (içinde ayırıcı/satır sonu olabilir)
  function csvOku(metin) {
    metin = String(metin).replace(/^\ufeff/, "");
    const ilk = metin.split(/\r?\n/, 1)[0], ay = [";", "\t", ","].sort((a, b) => ilk.split(b).length - ilk.split(a).length)[0];
    const sat = []; let h = [], f = "", q = false;
    for (let i = 0; i < metin.length; i++) { const c = metin[i];
      if (q) { if (c === '"') { if (metin[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; continue; }
      if (c === '"' && f === "") q = true; else if (c === '"' && f === "=") { f = ""; q = true; } else if (c === ay) { h.push(f); f = ""; } else if (c === "\n" || c === "\r") { if (c === "\r" && metin[i + 1] === "\n") i++; h.push(f); sat.push(h); h = []; f = ""; } else f += c; }
    if (f !== "" || h.length) { h.push(f); sat.push(h); }
    return sat;
  }
  const kac = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  // CSV yaz: TC Excel'de bilimsel gösterime dönmesin diye ="..." biçiminde
  const csvYaz = (liste, VELI) => "\ufeff" + [BASLIKLAR.map(kac).join(";"), ...liste.map((s) => disaSatir(s, VELI).map((v, i) => SUTUNLAR[i].k === "tc" && v ? `=${kac(v)}` : kac(v)).join(";"))].join("\r\n");
  // v2.5.3: Hepsini HAZIR özeti — kaç satır HAZIR, kalanlar neden KONTROL
  function hazirOzet(oldu, nedenler, baslik) {
    const kaldi = (nedenler || []).length;
    let msg = `${baslik || "Hepsi"}: ${oldu} satır HAZIR`;
    if (!kaldi) return msg;
    const say = {}; for (const n of nedenler) { const k = n || "eksik veri"; say[k] = (say[k] || 0) + 1; }
    const dokum = Object.entries(say).map(([k, v]) => `${k} (${v})`).join(", ");
    return msg + ` · ${kaldi} satır eksik veri nedeniyle KONTROL kaldı: ${dokum}`;
  }
  kok.RaporSutun = { tcMaske, SUTUNLAR, BASLIKLAR, eslestir, baslikVarMi, tarihIc, tarihDis, kimlikMetni, disaSatir, icAl, csvOku, csvYaz, maskeliMi, maskeAnahtar, maskeIleEsle, ogrenciTcOku, hazirOzet };
  if (typeof module !== "undefined") module.exports = kok.RaporSutun;
})(typeof globalThis !== "undefined" ? globalThis : this);
