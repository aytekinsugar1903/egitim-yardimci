"use strict";
// v2.5.0: Öğrenci listesi (okul no ↔ ad ↔ sınıf) — Veli İzni okul numarası doğrulaması. TAMAMEN YEREL: liste yalnızca bu tarayıcının depolamasında (chrome.storage.local, "ogrListe") durur;
// dışarı gönderilmez, istendiğinde silinir. T.C. kimlik no ve başka sütunlar ASLA saklanmaz. Adlar isteğe bağlı (kapalıysa yalnız baş harfler).
(function (kok) {
  const KEY = "ogrListe";
  let LISTE = [], HARITA = new Map(), TARIH = "", ADLI = true;
  const katla = (s) => String(s ?? "").toLocaleLowerCase("tr").replace(/i̇/g, "i").replace(/ı/g, "i").replace(/ş/g, "s").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ö/g, "o").replace(/ç/g, "c").replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
  const rakam = (v) => String(v ?? "").replace(/\D/g, "");
  const bas = (ad) => String(ad || "").trim().split(/\s+/).filter(Boolean).map((w) => w[0].toLocaleUpperCase("tr") + ".").join("");
  function kur(liste, tarih, adli) { LISTE = liste; TARIH = tarih || ""; ADLI = adli !== false; HARITA = new Map(); for (const k of LISTE) HARITA.set(k.n, k); }
  async function hazirla() { try { const r = (await chrome.storage.local.get(KEY))[KEY]; if (r && Array.isArray(r.liste)) kur(r.liste, r.tarih, r.adli); } catch (e) { /* depo yok: liste boş */ } return LISTE.length; }
  const hazirMi = () => LISTE.length > 0;
  const bul = (n) => HARITA.get(rakam(n)) || null;
  async function kaydet(kayitlar, adli) { const liste = kayitlar.map((k) => ({ n: k.n, a: adli ? k.a : bas(k.a), s: k.s })); const t = new Date().toISOString().slice(0, 10); kur(liste, t, adli); await chrome.storage.local.set({ [KEY]: { liste, tarih: t, adli: !!adli } }); }
  async function sil() { kur([], "", true); try { await chrome.storage.local.remove(KEY); } catch (e) { /* yok */ } }
  // --- ayrıştırma: tablo (satır dizileri) -> [{n,a,s}] ---
  function csvTablo(metin) {
    const m = String(metin || "").replace(/^\uFEFF/, ""), ilk = m.split(/\r?\n/).slice(0, 8).join("\n");
    const say = (c) => (ilk.match(new RegExp(c === "\t" ? "\\t" : "\\" + c, "g")) || []).length, ayr = [";", "\t", ","].sort((a, b) => say(b) - say(a))[0];
    return m.split(/\r?\n/).filter((s) => s.trim()).map((s) => { const o = []; let h = "", q = false; for (let i = 0; i < s.length; i++) { const c = s[i]; if (c === '"') { if (q && s[i + 1] === '"') { h += '"'; i++; } else q = !q; } else if (c === ayr && !q) { o.push(h); h = ""; } else h += c; } o.push(h); return o.map((x) => x.trim()); });
  }
  const SINIF_RE = /^\s*\d{1,2}\s*[-/. ]?\s*[A-ZÇĞİÖŞÜ][A-ZÇĞİÖŞÜa-zçğıöşü0-9 ./-]{0,14}$/;
  function ayristir(tablo) {
    const T = (tablo || []).filter((r) => r && r.some((x) => String(x ?? "").trim())); if (!T.length) return { kayitlar: [], uyari: "Tablo boş." };
    let hi = -1, iN = -1, iA = -1, iS = -1, iSoy = -1;
    for (let i = 0; i < Math.min(8, T.length) && hi < 0; i++) { const b = T[i].map(katla);
      const n = b.findIndex((x) => /^(okul no|okulno|ogrenci no|ogrno|numara|no|okul numarasi|ogrenci numarasi)$/.test(x));
      if (n >= 0) { hi = i; iN = n; iA = b.findIndex((x) => /^(adi soyadi|ad soyad|adsoyad|ogrenci adi soyadi|ad soyadi|isim|ogrenci adi|ad|adi)$/.test(x)); iSoy = b.findIndex((x) => /^(soyadi|soyad)$/.test(x)); iS = b.findIndex((x) => /^(sinif|sube|sinifi|sinif sube|sinifi sube|sinif subesi)$/.test(x) || /^sinif/.test(x)); } }
    let veri = hi >= 0 ? T.slice(hi + 1) : T;
    if (hi < 0) { // başlıksız: içerikten tahmin
      const kol = Math.max(...T.map((r) => r.length)); let en = { iN: -1, p: 0 };
      for (let c = 0; c < kol; c++) { const p = T.filter((r) => /^\d{2,6}$/.test(String(r[c] ?? "").trim())).length / T.length; if (p > en.p) en = { iN: c, p }; }
      if (en.p < 0.6) return { kayitlar: [], uyari: 'Okul numarası sütunu bulunamadı: ilk satırda "Okul No" başlığı olsun (ya da sütunda 2-6 haneli numaralar).' };
      iN = en.iN; for (let c = 0; c < kol; c++) { if (c === iN) continue; if (iS < 0 && T.filter((r) => SINIF_RE.test(String(r[c] ?? ""))).length / T.length > 0.6) iS = c; else if (iA < 0 && T.filter((r) => /\s/.test(String(r[c] ?? "").trim()) && /[A-Za-zÇĞİÖŞÜçğıöşü]/.test(String(r[c] ?? ""))).length / T.length > 0.6) iA = c; }
    }
    const kay = new Map(); let atlanan = 0;
    for (const r of veri) { const n = rakam(r[iN]); if (!/^\d{1,6}$/.test(n)) { atlanan++; continue; }
      let a = iA >= 0 ? String(r[iA] ?? "").trim() : ""; if (iSoy >= 0 && r[iSoy]) a = (a + " " + String(r[iSoy]).trim()).trim();
      kay.set(n, { n, a, s: iS >= 0 ? String(r[iS] ?? "").trim() : "" }); }
    return { kayitlar: [...kay.values()], atlanan, uyari: kay.size ? "" : "Geçerli okul numarası bulunamadı." };
  }
  // --- eşleştirme: okuyucunun hane olasılıkları (noOlas) + liste ---
  const ll = (o, c) => { let s = 0; for (let i = 0; i < c.length; i++) s += Math.log(Math.max(o[i][+c[i]], 1e-4)); return s; };
  const ham = (a, b) => { let d = 0; for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) d++; return d; };
  function adaylar(no, olas, ayar = {}) { // listede olmayan numara için en olası liste numaraları (en fazla 3)
    const n = rakam(no), L = n.length; if (!L || !hazirMi()) return [];
    const gecerli = olas && olas.length === L, hmax = gecerli ? 2 : 1, ref = gecerli ? ll(olas, n) : 0, out = [];
    for (const k of LISTE) { if (k.n.length !== L) continue; const h = ham(k.n, n); if (h < 1 || h > hmax) continue; out.push({ no: k.n, kayit: k, puan: gecerli ? ll(olas, k.n) - ref : -h * 4 }); }
    out.sort((a, b) => b.puan - a.puan); return out.filter((x) => gecerli ? x.puan >= -(ayar.oneriDelta || 5) : true).slice(0, 3);
  }
  function karar(no, olas, ayar = {}) { // yalnız belirgin durumda kendiliğinden düzeltme (aksi halde null → öneri). Benzetimle ayarlı: delta 1.5, marj 0.7, belirsiz hane p ≤ 0.6
    const n = rakam(no), L = n.length; if (!L || !olas || olas.length !== L || bul(n)) return null;
    const delta = ayar.delta ?? 1.5, marj = ayar.marj ?? 0.7, kapi = ayar.kapi ?? 0.6, ad = adaylar(n, olas, { oneriDelta: 50 }); if (!ad.length) return null;
    const tum = []; const ref = ll(olas, n); for (const k of LISTE) { if (k.n.length !== L) continue; const h = ham(k.n, n); if (h >= 1 && h <= 2) tum.push({ no: k.n, kayit: k, p: ll(olas, k.n) }); } tum.sort((a, b) => b.p - a.p);
    const en = tum[0]; if (!en) return null; if (en.p < ref - delta) return null; if (tum.length > 1 && tum[1].p > en.p - marj) return null;
    for (let i = 0; i < L; i++) if (en.no[i] !== n[i] && olas[i][+n[i]] > kapi) return null;
    return { no: en.no, kayit: en.kayit };
  }
  // --- arayüz (tarama sayfası, Veli İzni bölümü) ---
  function arayuz(kap, degisti) {
    const ciz = () => { const n = LISTE.length; kap.innerHTML = '<h3 style="margin:0 0 4px">Öğrenci listesi (isteğe bağlı) — okul numarasını listeyle doğrular</h3>'
      + '<div class="not" id="ogrDurum" style="margin:2px 0 6px">' + (n ? `<b>${n}</b> öğrenci yüklü${TARIH ? " (" + TARIH.split("-").reverse().join(".") + ")" : ""}${ADLI ? "" : " · adlar yalnız baş harf"}. Okunan numara listede yoksa en yakın numaralar önerilir; belirgin hatalar kendiliğinden düzeltilir (turuncu, Geri al ile).` : "Liste yüklü değil. Excel/CSV yükleyin ya da e-Okul sınıf listesini kopyalayıp yapıştırın (yalnız Okul No, Ad Soyad, Sınıf sütunları kullanılır; T.C. ve diğerleri saklanmaz).") + "</div>"
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><input type="file" id="ogrDosya" accept=".xlsx,.csv,.txt,.tsv"><label style="font-size:.9em"><input type="checkbox" id="ogrAdli"' + (ADLI ? " checked" : "") + '> Adları kaydet (önerilir)</label>' + (n ? ' <button type="button" id="ogrSil">Listeyi sil</button>' : "") + "</div>"
      + '<details style="margin-top:6px"><summary>Yapıştır</summary><textarea id="ogrYapistir" rows="4" style="width:100%;box-sizing:border-box" placeholder="Okul No&#9;Adı Soyadı&#9;Sınıf&#10;4778&#9;…&#9;11-D"></textarea><button type="button" id="ogrYukle">Yapıştırılanı yükle</button></details>';
      const kayit = async (T) => { const r = ayristir(T); const d = kap.querySelector("#ogrDurum"); if (!r.kayitlar.length) { d.textContent = r.uyari; d.style.color = "#b00"; return; } await kaydet(r.kayitlar, kap.querySelector("#ogrAdli").checked); ciz(); degisti && degisti(r); };
      kap.querySelector("#ogrDosya").onchange = async (e) => { const f = e.target.files[0]; e.target.value = ""; if (!f) return; try { let T;
        if (/\.xlsx$/i.test(f.name)) { if (!globalThis.EvrakXlsx) throw new Error("Excel okuyucu yok"); T = await EvrakXlsx.oku(await f.arrayBuffer()); }
        else { const b = await f.arrayBuffer(); let m = new TextDecoder("utf-8").decode(b); if (m.includes("\uFFFD")) m = new TextDecoder("windows-1254").decode(b); T = csvTablo(m); }
        await kayit(T); } catch (er) { const d = kap.querySelector("#ogrDurum"); d.textContent = "Liste okunamadı: " + er.message + " (.xls ise Excel'de .xlsx ya da CSV olarak kaydedin ya da yapıştırın)"; d.style.color = "#b00"; } };
      kap.querySelector("#ogrYukle").onclick = () => kayit(csvTablo(kap.querySelector("#ogrYapistir").value));
      const s = kap.querySelector("#ogrSil"); if (s) s.onclick = async () => { if (!confirm("Kayıtlı öğrenci listesi silinsin mi?")) return; await sil(); ciz(); degisti && degisti(null); };
    }; ciz();
  }
  kok.OgrListe = { hazirla, hazirMi, bul, kaydet, sil, ayristir, csvTablo, adaylar, karar, arayuz, say: () => LISTE.length, _kur: kur };
  if (typeof module !== "undefined") module.exports = kok.OgrListe;
})(typeof globalThis !== "undefined" ? globalThis : this);
