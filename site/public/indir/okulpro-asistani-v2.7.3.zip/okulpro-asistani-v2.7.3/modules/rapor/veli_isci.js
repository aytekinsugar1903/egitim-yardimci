// v2.3.21: Veli izni ağır işleri (eğiklik, tablo ızgarası, el yazısı rakam modeli) arayüzü dondurmasın diye ayrı iş parçacığında.
importScripts("../ortak/okuma/rakam.js", "../ortak/okuma/duzen.js"); // v2.3.23: ortak okuma modülü
let hazir = null;
const yukle = () => hazir || (hazir = fetch("../ortak/okuma/lib/rakam.bin").then((r) => r.arrayBuffer()).then((b) => ElRakam.yukle(b)));
self.onmessage = async (e) => {
  const { id, img, kel, bugun } = e.data;
  try {
    await yukle();
    const opt = { bugun: bugun ? new Date(bugun) : undefined };
    if (e.data.tur === "oku") { self.postMessage({ id, L: VeliDuzen.oku(img, kel || [], opt) }); return; } // Tesseract başlıklarıyla eski düzen
    const Z = VeliDuzen.izgara(img, opt); delete Z.img; self.postMessage({ id, Z });
  } catch (err) { self.postMessage({ id, hata: String(err && err.message || err) }); }
};
