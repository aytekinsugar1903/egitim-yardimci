"use strict";
// v2.1.3 ortak yardımcılar (tarama, panel, e-Okul içerik betiği ve Node testleri ortak kullanır).
(function (kok) {
  const uyu = (ms) => new Promise((r) => setTimeout(r, ms));
  const p2 = (n) => String(n).padStart(2, "0");
  const AYLAR = { OCAK: 1, SUBAT: 2, MART: 3, NISAN: 4, MAYIS: 5, HAZIRAN: 6, TEMMUZ: 7, AGUSTOS: 8, EYLUL: 9, EKIM: 10, KASIM: 11, ARALIK: 12 };
  const asc = (s) => String(s).toLocaleUpperCase("tr").replace(/[ÇĞİÖŞÜÂÎÛ]/g, (c) => ({ Ç: "C", Ğ: "G", İ: "I", Ö: "O", Ş: "S", Ü: "U", Â: "A", Î: "I", Û: "U" })[c]);
  function gecerliTarih(g, a, y) {
    g = +g; a = +a; y = +y; if (y < 100) y += 2000;
    const t = new Date(y, a - 1, g);
    return t.getFullYear() === y && t.getMonth() === a - 1 && t.getDate() === g && y > 2000 && y < 2100 ? t : null;
  }
  // "15.10.2026", "15/10/26", "15-10-2026", "15 Ekim 2026", "15 EKİM 26" -> Date | null
  function tarihCozGenis(s) {
    s = String(s || "").trim(); if (!s) return null;
    let m = s.match(/(\d{1,2})\s*[./\-,]\s*(\d{1,2})\s*[./\-,]\s*(\d{4}|\d{2})(?!\d)/);
    if (m) return gecerliTarih(m[1], m[2], m[3]);
    m = asc(s).match(/(\d{1,2})\s*\.?\s*(OCAK|SUBAT|MART|NISAN|MAYIS|HAZIRAN|TEMMUZ|AGUSTOS|EYLUL|EKIM|KASIM|ARALIK)\s*(\d{4}|\d{2})(?!\d)/);
    return m ? gecerliTarih(m[1], AYLAR[m[2]], m[3]) : null;
  }
  const tarihYaz = (t) => (t ? `${p2(t.getDate())}/${p2(t.getMonth() + 1)}/${t.getFullYear()}` : "");
  const tarihNormal = (s) => { const t = tarihCozGenis(s); return t ? tarihYaz(t) : String(s || "").trim(); };

  // ---- Düzenlenebilir liste (+ / −) ----
  const BOS_SATIR = () => ({ tc: "", adsoyad: "", bas: "", bit: "", belgeGun: "", sure: "", tur: "Raporlu", aciklama: "", kurum: "", uyari: "Elle eklendi: alanları doldurun", guven: 0, elle: true, sayfalar: [] });
  function satirEkle(liste, alanlar) { const s = Object.assign(BOS_SATIR(), alanlar || {}); liste.push(s); return s; }
  function satirSil(liste, i) { if (i < 0 || i >= liste.length) return null; return liste.splice(i, 1)[0]; }
  // e-Okul'a girilecek satırlar: yalnızca listede kalan (düzenlenmiş) ve HAZIR olanlar
  const girilecekler = (liste) => liste.filter((s) => s && s.durum === "HAZIR");

  // ---- Güven / uyarı ----
  function tcGecerli(tc) {
    if (!/^\d{11}$/.test(tc) || tc[0] === "0") return false;
    const d = [...tc].map(Number), t1 = d[0] + d[2] + d[4] + d[6] + d[8], t2 = d[1] + d[3] + d[5] + d[7];
    if ((((t1 * 7 - t2) % 10) + 10) % 10 !== d[9]) return false;
    return d.slice(0, 10).reduce((a, b) => a + b, 0) % 10 === d[10];
  }
  // 0-100 arası güven: OCR güveni + alanların geçerliliği
  function guvenHesapla(s, ocrGuven) {
    let p = 100;
    if (!tcGecerli(String(s.tc || ""))) p -= 40;
    if (!tarihCozGenis(s.bas)) p -= 25;
    if (!s.sure) p -= 15;
    if (!s.aciklama) p -= 10;
    if (!s.adsoyad) p -= 5;
    if (s.okunamayan) p -= 30;
    if (typeof ocrGuven === "number" && ocrGuven < 60) p -= Math.round((60 - ocrGuven) / 2);
    return Math.max(0, Math.min(100, p));
  }
  // Aynı TC + aynı başlangıç tarihi olan satırları işaretler (ilki kalır, diğerlerine uyarı eklenir)
  function tekrarIsaretle(liste) {
    const gor = new Map(); let n = 0;
    liste.forEach((s, i) => {
      s.tekrar = false;
      if (!s.tc) return;
      const k = s.tc + "|" + tarihNormal(s.bas);
      if (gor.has(k)) { s.tekrar = true; n++; const u = `Tekrar: ${gor.get(k) + 1}. satırla aynı TC ve tarih`; if (!String(s.uyari || "").includes("Tekrar:")) s.uyari = [s.uyari, u].filter(Boolean).join(" | "); }
      else gor.set(k, i);
    });
    return n;
  }

  // ---- Dayanıklılık ----
  function zamanAsimi(p, ms, ad) {
    let id; return Promise.race([p, new Promise((_, r) => { id = setTimeout(() => r(new Error(`${ad || "İşlem"} zaman aşımı (${ms} ms)`)), ms); })]).finally(() => clearTimeout(id));
  }
  async function tekrarDene(fn, { deneme = 2, ms = 60000, ad = "", bekle = 300 } = {}) {
    let son;
    for (let i = 1; i <= deneme; i++) {
      try { return await zamanAsimi(Promise.resolve().then(() => fn(i)), ms, ad); } catch (e) { son = e; if (i < deneme) await uyu(bekle); }
    }
    throw son;
  }
  // Her öğeyi ayrı işler; bir öğenin hatası tüm partiyi durdurmaz.
  async function partiIsle(ogeler, fn, ayar) {
    const sonuc = [];
    for (let i = 0; i < ogeler.length; i++) {
      try { sonuc.push({ ok: true, deger: await tekrarDene(() => fn(ogeler[i], i), ayar) }); }
      catch (e) { sonuc.push({ ok: false, hata: String((e && e.message) || e), oge: ogeler[i] }); }
    }
    return sonuc;
  }

  // ---- Çift Kaydet ----
  // mesgul(): AJAX/PrimeFaces/UpdatePanel sürüyor mu. Sayfa sakinleşene kadar bekler.
  async function hazirBekle(mesgul, { max = 10000, sakin = 300, adim = 100 } = {}) {
    const t0 = Date.now(); let sakinBas = 0;
    while (Date.now() - t0 < max) {
      if (!mesgul()) { if (!sakinBas) sakinBas = Date.now(); if (Date.now() - sakinBas >= sakin) return true; } else sakinBas = 0;
      await uyu(adim);
    }
    return false;
  }
  // Kaydet'e iki kez basar: hazır bekle -> 1. tık -> ~1 sn -> hazır bekle -> 2. tık -> hazır bekle -> kayitVar() doğrula.
  // v2.3.7: en çok 3 tık. Her tıktan sonra aralikMs bekler; e-Okul onay uyarısı (uyari()) görünüyorsa ya da kayıt yoksa
  // Kaydet simgesini YENİDEN bulup tekrar basar (postback DOM'u değiştirir). Uyarı yok + kayıt listede = başarı.
  async function ciftKaydet({ bul, mesgul, tikla, kayitVar, uyari = () => false, aralikMs = 1000, maxBekle = 10000, dogrulaMs = 15000, olay = () => {}, enCok = 3 }) {
    for (let i = 1; i <= enCok; i++) {
      await hazirBekle(() => mesgul() && !uyari(), { max: maxBekle }); // uyarı penceresinin örtüsü "meşgul" sayılmasın
      const k = bul(); if (!k) return { ok: false, hata: `Kaydet simgesi ${i}. tıklamada bulunamadı` };
      olay("tik" + i); await tikla(k);
      await uyu(aralikMs);
      const t0 = Date.now(), son = i === enCok ? dogrulaMs : 3000;
      while (Date.now() - t0 < son) { if (!uyari() && !mesgul() && kayitVar()) return { ok: true, tik: i }; if (uyari() && i < enCok) break; await uyu(250); }
    }
    return { ok: false, hata: `Kaydet'e ${enCok} kez basıldı ama kayıt listede görünmedi` + (uyari() ? " (e-Okul uyarısı hâlâ açık)" : "") };
  }
  // DOM'dan PrimeFaces/jQuery/UpdatePanel yükleme göstergeleri
  function domMesgul(doc) {
    doc = doc || document;
    if (doc.readyState !== "complete") return true;
    if (doc.documentElement.getAttribute("data-eokul-mesgul") === "1") return true;
    const gor = (e) => e && e.getClientRects().length && getComputedStyle(e).visibility !== "hidden" && getComputedStyle(e).display !== "none";
    return [...doc.querySelectorAll(".ui-blockui, .ui-blockui-content, .ui-widget-overlay, .ui-dialog-loading, [id$=ajaxStatus] .ui-icon-loading, .ajax-loader, [id*=UpdateProgress]")].some(gor);
  }

  const api = { uyu, tarihCozGenis, tarihYaz, tarihNormal, BOS_SATIR, satirEkle, satirSil, girilecekler, tcGecerli, guvenHesapla, tekrarIsaretle, zamanAsimi, tekrarDene, partiIsle, hazirBekle, ciftKaydet, domMesgul };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  kok.RaporYardim = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
