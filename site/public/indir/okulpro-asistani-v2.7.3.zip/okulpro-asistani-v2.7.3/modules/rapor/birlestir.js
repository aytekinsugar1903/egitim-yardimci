"use strict";
// v2.3.43: Veli izni / faaliyet — aynı öğrencinin ARDIŞIK okul günlerini tek e-Okul kaydında birleştirir.
// Kurallar: yalnız aynı hafta içinde (Pzt–Cum) art arda takvim günleri; hafta sonunu ve tatili ASLA aşmaz.
// Yarım gün (0,5) yalnız dizinin SON günü olabilir (yarımdan sonraki gün yeni kayıt başlatır).
// Yalnız HAZIR, tek günlük (1 ya da 0,5) satırlar; aynı Okul No + aynı Tür + aynı Nedeni + aynı Açıklama.
// Birleşik satır: ilk tarih, Süre = toplam (ör. 1,5), Bitiş = son tarih; asıl satırlar s.birlesik içinde saklanır (− ile ayrılır).
(function (kok) {
  // 2026-2027 MEB çalışma takvimi (Genelge 2026/68) + resmî/dini bayramlar: bu günlerde satır birleştirilmez.
  // v2.4.0: takvim artık Okul ayarlarından düzenlenebilir (ayar.tatilMetni / ayar.arifeMetni).
  // Metin tanımlı değilse aşağıdaki varsayılan kullanılır; metin boşsa hiçbir gün tatil sayılmaz.
  const VARSAYILAN_TATIL_METNI = [
    "29.10.2026               # Cumhuriyet Bayramı",
    "16.11.2026 - 20.11.2026  # Ara tatil",
    "01.01.2027               # Yılbaşı",
    "25.01.2027 - 05.02.2027  # Yarıyıl tatili",
    "08.03.2027 - 12.03.2027  # Ramazan Bayramı",
    "23.04.2027               # Ulusal Egemenlik ve Çocuk Bayramı",
    "01.05.2027               # Emek ve Dayanışma Günü",
    "15.05.2027 - 19.05.2027  # Kurban Bayramı",
  ].join("\n");
  // v2.3.44: arife günleri e-Okul'da YARIM gün işlenir (en çok 0,5): 28 Ekim 2026, Ramazan arifesi 8 Mart 2027, Kurban arifesi 15 Mayıs 2027
  const VARSAYILAN_ARIFE_METNI = [
    "28.10.2026               # Cumhuriyet Bayramı arifesi",
    "08.03.2027               # Ramazan Bayramı arifesi",
    "15.05.2027               # Kurban Bayramı arifesi",
  ].join("\n");
  const TATIL = new Set(), ARIFE = new Set();
  const p2 = (n) => String(n).padStart(2, "0"), p4 = (n) => String(n).padStart(4, "0");
  const anahtarGun = (t) => t.getFullYear() + "-" + (t.getMonth() + 1) + "-" + t.getDate();
  const ekle = (b, e) => { const t = new Date(b + "T12:00:00"), s = new Date((e || b) + "T12:00:00"); for (; t <= s; t.setDate(t.getDate() + 1)) TATIL.add(anahtarGun(t)); };
  // "gg.aa.yyyy" | "gg.aa.yyyy - gg.aa.yyyy" | "yyyy-aa-gg"; satır sonundaki # açıklaması yok sayılır
  const DESEN_TARIH = /\d{4}-\d{1,2}-\d{1,2}|\d{1,2}[./-]\d{1,2}[./-]\d{4}/g;
  function tarihleriCoz(metin) {
    const tek = (x) => { // -> "yyyy-aa-gg" | null (geçersiz gün/ay reddedilir)
      const s = String(x || "").trim(); let r = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/), y, a, g;
      if (r) { [, y, a, g] = r; } else { r = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/); if (!r) return null; [, g, a, y] = r; }
      const t = new Date(+y, +a - 1, +g, 12);
      if (t.getFullYear() !== +y || t.getMonth() !== +a - 1 || t.getDate() !== +g || +y < 2000 || +y > 2100) return null;
      return `${p4(+y)}-${p2(+a)}-${p2(+g)}`;
    };
    const out = [];
    String(metin ?? "").split(/\r?\n/).forEach((satir) => {
      const t = [...satir.replace(/#.*$/, "").matchAll(DESEN_TARIH)].map((m) => tek(m[0])).filter(Boolean);
      if (!t.length) return;
      out.push(t.length > 1 ? (t[0] <= t[1] ? [t[0], t[1]] : [t[1], t[0]]) : [t[0], t[0]]);
    });
    return out;
  }
  // ayar -> takvim (tatilMetni/arifeMetni tanımlı değilse varsayılan). Dönüş: { tatil, arife } gün sayısı.
  function takvimYaz(ayar) {
    ayar = ayar || {};
    TATIL.clear(); ARIFE.clear();
    const tatil = typeof ayar.tatilMetni === "string" ? ayar.tatilMetni : VARSAYILAN_TATIL_METNI;
    const arife = typeof ayar.arifeMetni === "string" ? ayar.arifeMetni : VARSAYILAN_ARIFE_METNI;
    tarihleriCoz(tatil).forEach(([b, e]) => ekle(b, e));
    tarihleriCoz(arife).forEach(([b]) => { const t = new Date(b + "T12:00:00"); if (!isNaN(t)) ARIFE.add(anahtarGun(t)); });
    return { tatil: TATIL.size, arife: ARIFE.size };
  }
  async function takvimYukle() {
    try { const r = await chrome.storage.local.get("ayar"); return takvimYaz((r && r.ayar) || {}); }
    catch (e) { return takvimYaz({}); }
  }
  takvimYaz({}); // açılışta varsayılan; depoda kayıtlı takvim varsa hemen ardından o geçerli olur
  // v2.4.1: Okul ayarlarında Kaydet'e basılınca açık e-Okul sekmeleri de yeni takvimi hemen kullanır (sayfa yenilemeden)
  try { if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) chrome.storage.onChanged.addListener((c, alan) => { if (alan === "local" && c.ayar) takvimYaz(c.ayar.newValue || {}); }); } catch (e) {}
  try { if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) chrome.storage.local.get("ayar").then((r) => takvimYaz((r && r.ayar) || {})).catch(() => {}); } catch (e) {}
  const tarih = (s) => { const m = String(s || "").match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/); if (!m) return null; const t = new Date(+m[3], +m[2] - 1, +m[1], 12); return t.getDate() === +m[1] && t.getMonth() === +m[2] - 1 ? t : null; };
  const yaz = (t) => `${p2(t.getDate())}/${p2(t.getMonth() + 1)}/${t.getFullYear()}`;
  const kisa = (s) => { const t = tarih(s); return t ? `${p2(t.getDate())}.${p2(t.getMonth() + 1)}` : String(s || ""); };
  const tatilMi = (t) => TATIL.has(t.getFullYear() + "-" + (t.getMonth() + 1) + "-" + t.getDate());
  const arifeMi = (t) => !!t && ARIFE.has(t.getFullYear() + "-" + (t.getMonth() + 1) + "-" + t.getDate());
  const ARIFE_NOT = "ARİFE (yarım gün): Süre 0,5";
  // v2.3.44: arife gününe düşen tam günlük satır 0,5 olur (yalnız tek günlük veli izni / faaliyet satırları)
  function arifeDuzelt(liste, filtre = () => true) {
    let n = 0;
    for (const s of liste) {
      if (!s || !s.veli || !filtre(s) || (Array.isArray(s.birlesik) && s.birlesik.length)) continue;
      const t = tarih(s.bas); if (!arifeMi(t) || sayi(s.sure) !== 1) continue;
      s.sure = "0,5"; s.yarim = true; s.arife = true; if (!String(s.uyari || "").includes("ARİFE")) s.uyari = [ARIFE_NOT, s.uyari].filter(Boolean).join(" | "); n++;
    }
    return n;
  }
  const okulGunu = (t) => !!t && t.getDay() >= 1 && t.getDay() <= 5 && !tatilMi(t);
  const sayi = (v) => Number(String(v ?? "").replace(/\s/g, "").replace(",", "."));
  const sureYaz = (n) => String(Math.round(n * 2) / 2).replace(".", ",");
  const katla = (s) => String(s || "").toLocaleLowerCase("tr").replace(/\s+/g, " ").trim();
  const anahtar = (s) => [String(s.no || s.tc || "").replace(/\D/g, ""), s.faaliyet ? "F" : "V", katla(s.tur), katla(s.neden), katla(s.aciklama)].join("|");
  // satırın kapsadığı günler: [{t, g}] (g = 1 ya da 0,5)
  function gunler(s) {
    if (Array.isArray(s.birlesik) && s.birlesik.length) return s.birlesik.flatMap(gunler);
    const t = tarih(s.bas), g = sayi(s.sure);
    return t && (g === 1 || g === 0.5) ? [{ t, g }] : null;
  }
  function uygunMu(s) { // birleştirmeye girebilir mi
    if (!s || !s.veli || s.durum !== "HAZIR" || s.sari) return false;
    if (!/^\d{1,6}$/.test(String(s.no || "").replace(/\D/g, "")) || String(s.no || "").replace(/\D/g, "") !== String(s.no || "")) return false;
    const g = gunler(s); return !!g && g.every((x) => okulGunu(x.t));
  }
  // a'nın hemen arkasından b gelebilir mi (aynı hafta, ertesi takvim günü, a'nın son günü tam gün)
  function eklenebilir(a, b) {
    if (!uygunMu(a) || !uygunMu(b) || anahtar(a) !== anahtar(b)) return false;
    const ga = gunler(a), gb = gunler(b), son = ga[ga.length - 1], ilk = gb[0];
    if (son.g !== 1) return false; // yarım gün yalnız son gün olabilir
    const ertesi = new Date(son.t); ertesi.setDate(ertesi.getDate() + 1);
    return ertesi.getFullYear() === ilk.t.getFullYear() && ertesi.getMonth() === ilk.t.getMonth() && ertesi.getDate() === ilk.t.getDate() && okulGunu(ilk.t);
  }
  function asillar(s) { return Array.isArray(s.birlesik) && s.birlesik.length ? s.birlesik : [s]; }
  function birlesikKur(parcalar) { // parcalar: asıl (tek günlük) satırlar, tarih sırasında
    if (parcalar.length === 1) return parcalar[0];
    const ilk = parcalar[0], son = parcalar[parcalar.length - 1], top = parcalar.reduce((n, p) => n + sayi(p.sure), 0);
    const yarimSon = sayi(son.sure) === 0.5;
    const bilgi = `BİRLEŞİK: ${kisa(ilk.bas)}–${kisa(son.bas)} (${parcalar.length} gün${yarimSon ? (arifeMi(tarih(son.bas)) ? ", son gün ARİFE yarım" : ", son gün yarım") : ""}) → ${kisa(ilk.bas)} Süre ${sureYaz(top)}`;
    return Object.assign({}, ilk, { bas: yaz(tarih(ilk.bas)), bit: yaz(tarih(son.bas)), sure: sureYaz(top), yarim: false, yarimSon,
      dosya: [...new Set(parcalar.map((p) => p.dosya).filter(Boolean))].join(", "), birlesik: parcalar.map((p) => Object.assign({}, p)), uyari: bilgi, sonuc: "" });
  }
  // a ile b'yi tek satırda topla (a önce)
  const topla = (a, b) => birlesikKur([...asillar(a), ...asillar(b)]);
  // Listedeki (yalnız filtre(s) doğru olan) satırları otomatik birleştirir. Dönüş: { once, sonra, kayit } (kayit = birleşen grup sayısı)
  function otomatik(liste, filtre = () => true) {
    const arife = arifeDuzelt(liste, filtre); // v2.3.44
    const once = liste.filter((s) => filtre(s)).length; let kayit = 0;
    const adaylar = liste.map((s, i) => ({ s, i })).filter((x) => filtre(x.s) && uygunMu(x.s));
    const gruplar = new Map(); for (const x of adaylar) { const k = anahtar(x.s); if (!gruplar.has(k)) gruplar.set(k, []); gruplar.get(k).push(x); }
    const sil = new Set(), yeni = new Map();
    for (const g of gruplar.values()) {
      g.sort((a, b) => gunler(a.s)[0].t - gunler(b.s)[0].t || a.i - b.i);
      let cur = null;
      const kapat = () => { if (cur && cur.uyeler.length > 1) { yeni.set(cur.uyeler[0].i, cur.satir); cur.uyeler.slice(1).forEach((u) => sil.add(u.i)); kayit++; } };
      for (const x of g) {
        if (cur && eklenebilir(cur.satir, x.s)) { cur.satir = topla(cur.satir, x.s); cur.uyeler.push(x); }
        else { kapat(); cur = { satir: x.s, uyeler: [x] }; }
      }
      kapat();
    }
    if (!kayit) return { once, sonra: once, kayit: 0, arife };
    const sonuc = []; liste.forEach((s, i) => { if (sil.has(i)) return; sonuc.push(yeni.has(i) ? yeni.get(i) : s); });
    liste.splice(0, liste.length, ...sonuc);
    return { once, sonra: once - sil.size, kayit, arife };
  }
  // − : birleşik satırın son gününü ayrı satır yap (yerinde)
  function ayir(liste, i) {
    const s = liste[i]; if (!s || !Array.isArray(s.birlesik) || s.birlesik.length < 2) return false;
    const p = s.birlesik.map((x) => Object.assign({}, x)), son = p.pop();
    liste.splice(i, 1, birlesikKur(p), son); return true;
  }
  // + : i. satıra bir sonraki uygun günü ekle (listede herhangi bir yerde)
  function sonrakiBul(liste, i) { const a = liste[i]; if (!a) return -1; return liste.findIndex((b, j) => j !== i && eklenebilir(a, b)); }
  function birlestirSonraki(liste, i) {
    const j = sonrakiBul(liste, i); if (j < 0) return false;
    liste[i] = topla(liste[i], liste[j]); liste.splice(j, 1); return true;
  }
  // panel planı için tek satır metni: "19.10 → 1,5 gün (19.10–20.10)"
  function planMetni(s) {
    const p = asillar(s), ilk = p[0], son = p[p.length - 1];
    return `${kisa(ilk.bas)} → ${sureYaz(p.reduce((n, x) => n + sayi(x.sure), 0))} gün` + (p.length > 1 ? ` (${kisa(ilk.bas)}–${kisa(son.bas)})` : "") + (arifeMi(tarih(son.bas)) ? " · arife yarım" : ""); // v2.3.44
  }
  const birlesikMi = (s) => Array.isArray(s && s.birlesik) && s.birlesik.length > 1;
  const arifeSatiri = (s) => !!s && !(Array.isArray(s.birlesik) && s.birlesik.length > 1) && arifeMi(tarih(s.bas)); // v2.3.44
  kok.VeliBirlestir = { arifeDuzelt, arifeMi: (s) => arifeMi(tarih(s)), arifeSatiri, otomatik, ayir, birlestirSonraki, sonrakiBul, eklenebilir, uygunMu, planMetni, birlesikMi, okulGunu, tatilMi, sureYaz,
    // v2.4.0: takvim Okul ayarlarından düzenlenebilir
    takvimYaz, takvimYukle, tarihleriCoz, VARSAYILAN_TATIL_METNI, VARSAYILAN_ARIFE_METNI };
})(typeof globalThis !== "undefined" ? globalThis : this);
