// e-Okul içeriğinde (tüm iframe'lerde) çalışır.
// Durum chrome.storage.local["durum"] içinde tutulur; sayfa yenilense de kaldığı yerden devam eder.
// Adımlar: ara -> bekle_ogrenci -> menu -> form -> kaydet1 -> kaydet2 -> dogrula (ya da onay_bekle)  (her satır için)
(() => {
  if (/OOK08001\.aspx/i.test(location.href)) return; // devamsızlık (yoklama) modülünün sayfası
  const KEY = "durum";
  let DONGU_MS = 700; // v2.5.1: hız profiline göre ayarlanır
  const ADIM_ZAMAN_ASIMI_MS = 45000;

  // ---- Seçiciler: panel > Ayarlar'dan değiştirilebilir (chrome.storage "ayar.secici").
  // DİKKAT: Bunlar TAHMİNDİR; gerçek e-Okul HTML'i görülmeden ekran etiketlerine göre yazıldı.
  let MENU_METNI = "Özürlü Devamsızlık";
  let ETIKET = { neden: "Nedeni", baslangic: "Başlangıç Tarihi", sure: "Süre (Gün)", aciklama: "Açıklama" };
  let VELI_NEDEN = "İzinli", VELI_ACIKLAMA = "Veli izni";
  let KAYDET_ARASI_MS = 1000;
  let GUVENLI = false, OTO_KAYDET = true, BEK_MIN = 3000, BEK_MAX = 4000;
  // v2.5.1: ÇALIŞMA HIZI (ayar "hiz"). Güvenlik denetimi sayfaHazir() her profilde AYNI kalır (sayfa yüklendi mi, UpdatePanel/postback sürüyor mu: data-eokul-mesgul);
  // değişen yalnız "insan gibi" bekleme ve yazma hızıdır. kisa = metin alanı yazma, orta = Başlangıç Tarihi (postback tetikleyebilir), agir = tıklama/seçim (postback).
  const PROFIL = {
    normal:   { dongu: 700, yaz: [80, 200], ilk: [150, 300], sil: [60, 140], kisa: null, orta: null, agir: null, oturma: 1200, baslangic: 3500 },
    hizli:    { dongu: 300, yaz: [10, 24],  ilk: [50, 100],  sil: [8, 16],   kisa: [180, 320], orta: [350, 550], agir: [900, 1400], oturma: 500, baslangic: 800 },
    cokhizli: { dongu: 200, yaz: [3, 8],    ilk: [25, 50],   sil: [3, 6],    kisa: [90, 160],  orta: [200, 320], agir: [500, 800],  oturma: 300, baslangic: 400 },
  };
  let HIZ = "hizli";
  const aralik = (a) => a[0] + Math.random() * (a[1] - a[0]);
  async function seciciYukle() {
    let ay = {}; try { ay = (await chrome.storage.local.get("ayar")).ayar || {}; } catch (e) { return; }
    GUVENLI = ay.guvenliMod === true;
    // OTO_KAYDET = false; (v2.3.46: kullanıcı onayıyla otomatik Kaydet açık) // v2.3.45: KURAL — eklenti Kaydet'e asla kendisi basmaz; öğretmen basar
    KAYDET_ARASI_MS = 1000; // v2.3.13: kullanıcı kuralı — otomatik Kaydet basışları arası 1 sn
    BEK_MIN = Math.max(500, Number(ay.bekleMin) || 3000); BEK_MAX = Math.max(BEK_MIN, Number(ay.bekleMax) || 4000);
    HIZ = PROFIL[ay.hiz] ? ay.hiz : "hizli"; DONGU_MS = PROFIL[HIZ].dongu; if (sonIslem === 0) bekleme = PROFIL[HIZ].baslangic; // v2.5.1: sayfa yüklenince ilk işlem için bekleme (içerik betiği her sayfa yüklenişinde yeniden başlar)
    VELI_NEDEN = ay.veliNeden || "İzinli"; VELI_ACIKLAMA = ay.veliAciklama || "Veli izni";
    const s = ay.secici || {};
    MENU_METNI = s.menu || MENU_METNI;
    ETIKET = { neden: s.neden || ETIKET.neden, baslangic: s.bas || ETIKET.baslangic, sure: s.sure || ETIKET.sure, aciklama: s.acik || ETIKET.aciklama };
  }

  const norm = (s) => (s || "").replace(/\s+/g, " ").trim();
  const kucuk = (s) => norm(s).toLocaleLowerCase("tr");
  // v2.3.3: Türkçe/büyük-küçük harf duyarsız karşılaştırma (İ/ı/ş/ğ/ü/ö/ç -> ascii)
  const katla = (s) => kucuk(s).replace(/i̇/g, "i").replace(/[ıi]/g, "i").replace(/ş/g, "s").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ö/g, "o").replace(/ç/g, "c");
  const veliMi = (s) => !!(s && !s.faaliyet && (s.veli || /* v2.3.37: faaliyet satırı kendi Nedeni/Açıklaması ile */ /veli/.test(katla(s.neden || ""))));
  const gorunur = (e) => !!(e && (e.offsetWidth || e.offsetHeight || e.getClientRects().length));
  const sonra = (a, b) => !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING) && !a.contains(b);

  // ---- Günlük: konsola [eOkulRapor] ile yazar, son satırları panelde göstermek için depoya koyar ----
  let sonLog = "";
  function log(...a) {
    const mask = (x) => String(x).replace(/\b([1-9]\d{2})\d{6}(\d{2})\b/g, "$1******$2"); // KVKK: TC maskele
    console.log("[eOkulRapor]", ...a.map((x) => (typeof x === "string" ? mask(x) : x)));
    const m = mask(a.map((x) => x instanceof Element ? `<${x.tagName.toLowerCase()} id=${x.id} name=${x.name || ""} title=${x.title || ""}>` : typeof x === "object" ? JSON.stringify(x) : String(x)).join(" "));
    if (m === sonLog) return; sonLog = m;
    if (!baglamVar()) return;
    try {
      chrome.storage.local.get("log").then((r) => {
        const l = (r.log || []).slice(-60); l.push(new Date().toLocaleTimeString("tr") + " " + m.slice(0, 600));
        return chrome.storage.local.set({ log: l });
      }).catch(() => {});
    } catch (e) {}
  }

  // Araç çubuğu simgeleri resimdir (+, çöp, disket...). title/alt/src/id ile bulunur. TAHMİNİ anahtar kelimeler.
  const SIMGE = { yeni: /yeni|ekle|add|new|plus|insert/i, kaydet: /kaydet|save|disk|floppy/i };
  function simgeBul(tur) {
    const adaylar = [...document.querySelectorAll("img,input[type=image],input[type=submit],input[type=button],a,button")].filter(gorunur).map((e) => ({ e,
      t: [e.title, e.alt, e.id, e.name, e.value, e.getAttribute("aria-label"), e.tagName === "BUTTON" ? norm(e.textContent) : "", e.getAttribute("src"), e.getAttribute("onclick"), e.getAttribute("href")].filter(Boolean).join(" ") }));
    const bul = adaylar.find((x) => SIMGE[tur].test(x.t) && !/sil|delete|trash|iptal|cancel/i.test(x.t));
    if (!bul && adaylar.length) log(`"${tur}" simgesi yok. Adaylar:`, adaylar.filter((x) => x.e.tagName !== "A").slice(0, 25).map((x) => x.t.slice(0, 80)));
    return bul ? bul.e : null;
  }

  // Sayfa tam yüklendi mi, ASP.NET UpdatePanel/postback sürüyor mu? (ana_dunya.js data-eokul-mesgul yazar)
  // Her işlemden önce sayfanın en az 1,5 sn sakin olmasını bekler (insan gibi, tek tek adım).
  let sonIslem = 0;
  function sayfaHazir() {
    if (document.readyState !== "complete") return false;
    if (performance.now() < bekleme) return false;
    if (document.documentElement.getAttribute("data-eokul-mesgul") === "1") return false;
    return Date.now() - sonIslem > bekleme;
  }
  // Her işlemden sonra rastgele 3-4 sn (ayardan) bekleme
  let bekleme = 3500;
  const islemYapildi = (tur = "agir") => { sonIslem = Date.now(); const a = PROFIL[HIZ][tur] || PROFIL[HIZ].agir; bekleme = a ? aralik(a) : BEK_MIN + Math.random() * (BEK_MAX - BEK_MIN); }; // normal profil: ayardaki bekleMin–bekleMax
  const uyu = (ms) => new Promise((r) => setTimeout(r, ms));

  // Harf harf yazma: her karakter için keydown/keypress/input/keyup, 80-200 ms rastgele aralık.
  async function yazarakYaz(el, metin, tur = "kisa") {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    const tus = (tur, key) => el.dispatchEvent(new KeyboardEvent(tur, { key, code: key.length === 1 ? "Key" + key.toUpperCase() : key, bubbles: true, cancelable: true,
      keyCode: key === "Backspace" ? 8 : key.charCodeAt(0), which: key === "Backspace" ? 8 : key.charCodeAt(0), charCode: tur === "keypress" ? key.charCodeAt(0) : 0 }));
    el.focus(); el.dispatchEvent(new FocusEvent("focus")); el.click();
    await uyu(aralik(PROFIL[HIZ].ilk));
    while (el.value.length) { // mevcut içeriği Backspace ile sil
      tus("keydown", "Backspace"); setter.call(el, el.value.slice(0, -1));
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContentBackward" })); tus("keyup", "Backspace");
      await uyu(aralik(PROFIL[HIZ].sil));
    }
    for (const c of metin) {
      tus("keydown", c); tus("keypress", c);
      setter.call(el, el.value + c);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: c }));
      tus("keyup", c);
      await uyu(aralik(PROFIL[HIZ].yaz));
    }
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur(); el.dispatchEvent(new FocusEvent("blur"));
    islemYapildi(tur);
  }

  // ---- Durum okuma/yazma ----
  // Eklenti yeniden yüklenip sayfa yenilenmezse chrome.* "Extension context invalidated" verir: yakala, uyar, dur.
  let baglamKoptu = false;
  const baglamVar = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; } };
  function baglamKontrol() {
    if (baglamVar()) return true;
    if (!baglamKoptu) { baglamKoptu = true; console.warn("[eOkulRapor] Eklenti güncellendi; sayfayı yenileyin (F5)."); try { afis("e-Okul Rapor eklentisi güncellendi: lütfen sayfayı yenileyin (F5)."); } catch (e) {} }
    return false;
  }
  async function oku() { if (!baglamKontrol()) return null; try { return (await chrome.storage.local.get(KEY))[KEY]; } catch (e) { baglamKontrol(); return null; } }
  async function yaz(d) { if (!baglamKontrol()) return; try { await chrome.storage.local.set({ [KEY]: d }); } catch (e) { baglamKontrol(); } }

  // Aynı adımın birden fazla frame tarafından işlenmesini engelleyen karşılaştır-ve-geç
  async function gecis(adimNo, degistir) {
    const is = async () => {
      const d = await oku();
      if (!d || d.adimNo !== adimNo) return false;
      degistir(d);
      d.adimNo = adimNo + 1;
      d.stepTs = Date.now();
      await yaz(d);
      return true;
    };
    return navigator.locks ? navigator.locks.request("eokul-gecis", is) : is();
  }

  // Mevcut satırı bitir, sıradaki HAZIR satıra geç (veya durdur)
  function bitir(d, durum, sonuc) {
    const s = d.satirlar[d.idx];
    if (durum === "HATA") { log("HATA:", sonuc, "adım:", d.step); d.sonHata = `${s ? String(s.tc).replace(/^(\d{3})\d{6}(\d{2})$/, "$1******$2") : ""}: ${sonuc} (adım: ${d.step})`; }
    if (s && durum === "OK" && d.otoTemizle !== false) {
      // KVKK: başarıyla girilen satırın kişisel verilerini sil, yalnızca maskeli özet kalsın
      d.satirlar[d.idx] = { dosya: "", tc: String(s.tc).replace(/^(\d{3})\d{6}(\d{2})$/, "$1******$2"), adsoyad: "", bas: s.bas, bit: "", sure: s.sure, tur: s.veli ? "İzinli" : s.tur, veli: !!s.veli, aciklama: s.aciklama, uyari: "", durum: "OK", sonuc };
    } else if (s) {
      if (durum && (!d.deneme || durum === "HATA")) s.durum = durum;
      s.sonuc = (d.deneme && durum !== "HATA" ? "DENEME: " : "") + sonuc;
    }
    d.islenen = (d.islenen || 0) + 1;
    let sonraki = -1;
    if (!d.limit || d.islenen < d.limit) {
      for (let i = d.idx + 1; i < d.satirlar.length; i++) {
        if (d.satirlar[i].durum === "HAZIR" && (!d.kapsam || (d.kapsam === "faaliyet" ? !!d.satirlar[i].faaliyet : d.kapsam === "veli" ? !!d.satirlar[i].veli && !d.satirlar[i].faaliyet : !d.satirlar[i].veli))) { sonraki = i; break; } // v2.3.43: Faaliyet ayrı sekme // v2.3.25: yalnız başlatılan sekmenin satırları
      }
    }
    if (sonraki < 0) { d.calisiyor = false; d.step = "bitti"; // v2.3.46: bitişte sayfada kısa özet
      try { const st = d.satirlar.filter((x) => x.sonuc), ok = st.filter((x) => x.durum === "OK").length; afis(`Bitti: KAYDEDİLDİ ${ok} · ATLANDI/HATA ${st.length - ok}. Öğrenci öğrenci liste ve e-Okul karşılaştırması panelde "Sonuç" bölümünde.`); } catch (e) {} }
    else { d.idx = sonraki; d.step = d.kurtar ? "kurtar" : "ara"; d.kaydetSayisi = 0; d.kurtarSay = 0; d.ustMenuSay = 0; d.formMenuSay = 0; d.anahtarSay = 0; }
    d.kurtar = false; d.kaydetPending = null; d.nedenSay = 0; // v2.3.9 (+2.3.24 nedenSay)
    d.kaydetToplam = 0; d.kaydetSonTs = 0; d.kaydetIlkTs = 0; // v2.3.36
  }
  // v2.3.36: Kaydet en çok 3 kez denenir; kayıt yine görülmezse satır sarı "Kaydedilemedi", sıradakine geçilir (sonsuz döngü yok)
  const KAYDET_MAX = 3, KAYDET_BEKLE_MS = 12000, KAYDET_TAVAN_MS = 90000;
  function kaydedilemedi(d, neden) { d.kurtar = true; const s = d.satirlar[d.idx]; if (s) s.sari = true; log("KAYDEDİLEMEDİ:", neden);
    bitir(d, "ATLANDI", `Kaydedilemedi — elle girin (${neden})`); }
  function kaydetSay(x) { x.kaydetToplam = (x.kaydetToplam || 0) + 1; x.kaydetSonTs = Date.now(); if (!x.kaydetIlkTs) x.kaydetIlkTs = x.kaydetSonTs; }
  // Yanlış TC: e-Okul ana sayfaya döndü / uyarı verdi. Satırı işaretle, menüden forma dönüp sıradakine geç.
  // v2.3.31: hatalı / e-Okul'da olmayan numara çalışmayı durdurmaz — satır sarı "Bulunamadı — atlandı", sıradakine geçilir
  function tcHatali(d, neden) { d.kurtar = true; if (d.satirlar[d.idx]) d.satirlar[d.idx].sari = true; bitir(d, "ATLANDI", "Bulunamadı — atlandı" + (neden ? ": " + neden : "")); }
  // v2.3.31: e-Okul oturumu gerçekten kapandı mı (giriş/şifre ekranı ya da oturum sona erdi mesajı)
  function oturumKapandi() {
    if (window !== window.top || !document.body) return false;
    if (document.querySelector("input[type=password]")) return true;
    return /oturum(unuz)?(un)?\s*(s[üu]re(si|niz)?\s*)?(doldu|sona erdi|zaman a[şs][ıi]m)/i.test(document.body.innerText || document.body.textContent || "");
  }
  const OTURUM_MESAJI = "e-Okul oturumu kapandı (giriş ekranı görüldü). e-Okul'a yeniden girip Özürlü Devamsızlık ekranını açın ve Başlat'a basın; kalan öğrencilerden devam edilir.";
  async function oturumDurdur(no) { log("DURDU: " + OTURUM_MESAJI); afis(OTURUM_MESAJI); await gecis(no, (x) => { x.calisiyor = false; x.step = "durdu"; x.sonHata = OTURUM_MESAJI; }); }
  // Ana sayfadan Özürlü Devamsızlık / arama ekranına dönmek için tıklanacak menü öğesi (sırayla dener)
  // v2.3.4: bu belge + aynı kökenli tüm alt çerçeveler (frame/iframe) taranır
  function belgeler() {
    const out = [], gez = (doc) => { if (!doc || out.includes(doc)) return; out.push(doc);
      for (const f of doc.querySelectorAll("iframe,frame")) { try { gez(f.contentDocument); } catch (e) {} } };
    gez(document); return out;
  }
  function menuAdaylari() {
    return belgeler().flatMap((doc) => [...doc.querySelectorAll("a,li,span,td,div,button")]
      .filter((x) => x.children.length <= 1 && gorunur(x) && norm(x.textContent).length > 2 && norm(x.textContent).length <= 60));
  }
  let sonAdayLog = 0, linkLoglandi = false, linkLoglandi2 = false;
  function kurtarmaHedefi(deneme = 0) {
    // v2.3.7: önce "Hızlı Öğrenci Bilgisi" / "Öğrenci Arama" (OGRMenu1 hızlı arama ekranına götürür), title ve metin
    const hizli = ["hizli ogrenci bilgisi", "ogrenci arama"];
    for (const hz of hizli) {
      const l = belgeler().flatMap((doc) => [...doc.querySelectorAll("a,[title],input[type=image],img")]).filter(gorunur)
        .find((x) => katla(x.getAttribute("title") || "") === hz || katla(x.textContent) === hz || katla(x.getAttribute("alt") || "") === hz);
      if (l) return l.closest("a") || l;
    }
    const ad = menuAdaylari(), h = katla(MENU_METNI);
    const dogrudan = ad.find((x) => katla(x.textContent) === h) || ad.find((x) => katla(x.textContent).includes(h));
    if (dogrudan) return dogrudan;
    // v2.3.6: ana sayfadan Öğrenci İşlemleri sayfasına (OGRMenu1 hızlı arama) giden bağlantı: href/metin OGR / Öğrenci İşlemleri / Ogrenci
    const linkler = belgeler().flatMap((doc) => [...doc.querySelectorAll("a[href],area[href],[onclick]")]).filter(gorunur);
    if (!linkLoglandi) { linkLoglandi = true; log("Bağlantılar (ilk 30):", linkler.slice(0, 30).map((a) => `${norm(a.textContent).slice(0, 40)} → ${(a.getAttribute("href") || a.getAttribute("onclick") || "").slice(0, 80)}`).join(" · ")); }
    const ogr = linkler.filter((a) => { const t = katla(a.textContent), hr = a.getAttribute("href") || a.getAttribute("onclick") || "";
      return t.includes("ogrenci islemleri") || /OGR/.test(hr) || /ogrenci/i.test(hr) || t === "ogrenci"; });
    if (ogr.length && !linkLoglandi2) { linkLoglandi2 = true; log("v2.3.25: OGR bağlantıları tıklanmadı (okul türü seçimini düşürüyor):", ogr.length); }
    // üst menü gruplarını sırayla aç (her denemede bir sonrakini dener)
    const gruplar = ["Devamsızlık İşlemleri", "Devamsızlık", "Öğrenci Bilgileri"].map(katla); // v2.3.25: "Öğrenci İşlemleri" başlığı okul türünü sıfırlıyor, tıklanmaz
    const bulunan = gruplar.map((g) => ad.find((x) => katla(x.textContent) === g)).filter(Boolean);
    if (Date.now() - sonAdayLog > 15000) { sonAdayLog = Date.now(); log(`Menü adayları (${ad.length}, ilk 30):`, [...new Set(ad.map((x) => norm(x.textContent)))].slice(0, 30).join(" · ")); }
    return bulunan.length ? bulunan[deneme % bulunan.length] : null;
  }

  // ---- DOM yardımcıları ----
  function degerYaz(el, v) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    if (el.disabled) { log("Alan kapalı, yazılmadı:", el); return; }
    if (el.readOnly) log("UYARI: alan salt okunur (takvimden seçiliyor olabilir), yine de yazılıyor:", el);
    if (el.value === v) return;
    el.focus();
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur();
    islemYapildi();
  }

  function etiketSonrasi(etiket, tag) {
    const etiketler = [...document.querySelectorAll("td,th,label,span")].filter((e) => norm(e.textContent) === etiket);
    for (const a of etiketler) {
      const hedef = [...document.querySelectorAll(tag)].find((x) => sonra(a, x));
      if (hedef) return hedef;
    }
    return null;
  }

  function radyoMetni(r) {
    if (r.id) { const l = document.querySelector(`label[for="${r.id}"]`); if (l) return l.textContent; }
    let n = r.nextSibling;
    while (n && !norm(n.textContent)) n = n.nextSibling;
    return n ? n.textContent : "";
  }

  // v2.2.0: satır "ara: no" ise Okul No radyosu, değilse T.C. Kimlik No radyosu kullanılır.
  const anahtar = (s) => String(s && s.ara === "no" ? s.no : s && s.tc || "");
  function aramaOgeleri(s) {
    const noIle = s && s.ara === "no";
    const tcRadyo = [...document.querySelectorAll("input[type=radio]")]
      .filter(gorunur).find((r) => { const m = kucuk(radyoMetni(r) + " " + (r.value || "") + " " + (r.id || "")); return noIle ? /okul ?no|numara|öğrenci no|okulno/.test(m) : /kimlik|tckn/.test(m); }); // v2.3.25: value/id de bakılır
    if (!tcRadyo) return null;
    const kutu = [...document.querySelectorAll("input[type=text],input:not([type])")]
      .filter(gorunur).find((x) => sonra(tcRadyo, x));
    if (!kutu) return null;
    const buton = [...document.querySelectorAll("input[type=button],input[type=submit],button,a")]
      .filter(gorunur).find((x) => sonra(kutu, x) && norm(x.value || x.textContent) === "Ara");
    return buton ? { tcRadyo, kutu, buton } : null;
  }

  function menuBul() {
    const hepsi = belgeler().flatMap((doc) => [...doc.querySelectorAll("a,td,span,div,li")]).filter((e) => e.children.length <= 1 && gorunur(e));
    const h = katla(MENU_METNI);
    // önce birebir, sonra Türkçe duyarsız birebir, sonra "özürlü devamsızlık" içeren kısa metin
    return hepsi.find((e) => norm(e.textContent) === MENU_METNI) || hepsi.find((e) => katla(e.textContent) === h)
      || hepsi.find((e) => { const t = katla(e.textContent); return t.length <= 60 && t.includes(h); }) || null;
  }

  function formOgeleri() {
    const neden = etiketSonrasi(ETIKET.neden, "select");
    const bas = etiketSonrasi(ETIKET.baslangic, "input");
    const sure = etiketSonrasi(ETIKET.sure, "input");
    const acik = etiketSonrasi(ETIKET.aciklama, "textarea") || etiketSonrasi(ETIKET.aciklama, "input[type=text]") || etiketSonrasi(ETIKET.aciklama, "select");
    return neden && bas && sure && acik ? { neden, bas, sure, acik } : null;
  }

  function kayitVar(bas, neden) {
    const n = katla(neden).split(/[\s(]/)[0] || katla(neden); // v2.3.45: "Faaliyet (36/3 Madde)" listede kısa görünebilir
    if (kayitYokBilgisi()) return false; // v2.3.33
    if (kaydetUyarisiYerel()) return false; // v2.3.9: uyarı açıkken kayıt yok sayılır
    // v2.3.9: yalnızca en içteki veri satırları (iç tablo/form alanı içermeyen); "Geç" satırları sayılmaz
    return [...document.querySelectorAll("tr")].filter((tr) => tr.cells.length >= 2 && !tr.querySelector("table,select,input,textarea")
      && ![...tr.cells].some((c) => katla(c.textContent) === "gec")).some((tr) => {
      const h = [...tr.cells].map((c) => norm(c.textContent));
      const v = [bas, bas.replace(/\//g, ".")]; return h.some((x) => v.some((b) => x.includes(b))) && h.some((x) => katla(x).includes(n));
    });
  }

  // ---- v2.3.8: yeni arayüz başlangıcı ----
  const metinBul = (hedef, secici = "a,button,li,span,div,td,label,h1,h2,h3,h4,h5,p") => {
    const h = katla(hedef);
    return belgeler().flatMap((doc) => [...doc.querySelectorAll(secici)]).filter((e) => e.children.length <= 2 && gorunur(e) && katla(e.textContent) === h)
      .sort((a, b) => a.textContent.length - b.textContent.length)[0] || null;
  };
  // Adım B: kenar çubuğunda "Hızlı Öğrenci Arama" (Okul No anahtarı + metin kutusu + Ara)
  function yeniArama() {
    if (aramaOgeleri({ ara: "no" })) return null; // eski OGRMenu1 ekranı
    const bas = metinBul("Hızlı Öğrenci Arama"); if (!bas) return null;
    const doc = bas.ownerDocument, sonraki = (sec) => [...doc.querySelectorAll(sec)].filter((x) => gorunur(x) && sonra(bas, x));
    const kutu = sonraki("input[type=text],input[type=search],input[type=number],input:not([type])")[0]; if (!kutu) return null;
    const buton = sonraki("button,input[type=button],input[type=submit],a").find((x) => katla(x.value || x.textContent) === "ara"); if (!buton) return null;
    // v2.3.10: anahtar durumu GÖRÜNEN metinden / placeholder'dan / aria-checked'dan okunur; belirsizse tıklanmaz
    const kisa = [...doc.querySelectorAll("label,span,div,b,small,p")].filter((x) => x.children.length <= 2 && gorunur(x) && sonra(bas, x) && !!(x.compareDocumentPosition(kutu) & Node.DOCUMENT_POSITION_FOLLOWING));
    const okulGor = kisa.filter((x) => katla(x.textContent) === "okul no");
    const tcGor = kisa.filter((x) => /^(t\.?\s?c\.?|t\.?c\.? kimlik no|tc kimlik no|kimlik no)$/.test(katla(x.textContent)));
    const ph = katla(kutu.getAttribute("placeholder") || "");
    const sw = [...doc.querySelectorAll("[role=switch],input[type=checkbox],.switch,.toggle,[class*=switch],[class*=toggle]")].find((x) => sonra(bas, x) && !!(x.compareDocumentPosition(kutu) & Node.DOCUMENT_POSITION_FOLLOWING));
    let durum = "belirsiz", neden = "";
    if (/okul/.test(ph)) { durum = "okulno"; neden = "placeholder"; }
    else if (/\btc\b|t\.c|kimlik/.test(ph)) { durum = "tc"; neden = "placeholder"; }
    else if (okulGor.length && !tcGor.length) { durum = "okulno"; neden = "görünen metin 'Okul No'"; }
    else if (tcGor.length && !okulGor.length) { durum = "tc"; neden = "görünen metin 'TC'"; }
    else if (sw && sw.getAttribute("aria-label")) { const al = katla(sw.getAttribute("aria-label")); if (/okul/.test(al)) { durum = "okulno"; neden = "aria-label"; } else if (/kimlik|\btc\b/.test(al)) { durum = "tc"; neden = "aria-label"; } }
    const tiklanacak = sw ? (sw.closest("label") || sw) : (tcGor[0] || null);
    const okulNoEt = [...doc.querySelectorAll("label,span,div")].filter((x) => x.children.length <= 2 && gorunur(x) && sonra(bas, x) && katla(x.textContent) === "okul no")[0] || null;
    let anahtarEl = null;
    if (okulNoEt) anahtarEl = (okulNoEt.htmlFor && doc.getElementById(okulNoEt.htmlFor)) || okulNoEt.querySelector("input[type=checkbox],input[type=radio]")
      || okulNoEt.parentElement.querySelector("input[type=checkbox],input[type=radio]") || null;
    // v2.3.32: tür seçici <select> ya da açılır düğme (Okul No / T.C. Kimlik No) da olabilir; bootstrap-toggle "off" sınıfı
    const turKat = (x) => { const m = katla(x); return /kimlik|^t\.?\s?c\.?( no)?$|\btckn\b/.test(m) ? "tc" : /okul ?no|okul numara/.test(m) ? "okulno" : ""; };
    const sel = sonraki("select").find((x) => !!(x.compareDocumentPosition(kutu) & Node.DOCUMENT_POSITION_FOLLOWING) && [...x.options].some((o) => turKat(o.text) === "tc"));
    let secici = null;
    if (sel) { secici = { tip: "select", el: sel }; const o = sel.options[sel.selectedIndex]; const tk = o ? turKat(o.text) : ""; if (tk) { durum = tk; neden = "seçim kutusu"; } }
    else {
      const tg = sonraki("div.toggle,.toggle").find((x) => x.querySelector(".toggle-on,.toggle-off") && !!(x.compareDocumentPosition(kutu) & Node.DOCUMENT_POSITION_FOLLOWING));
      if (tg) { const on = tg.querySelector(".toggle-on"), off = tg.querySelector(".toggle-off"); const akt = tg.classList.contains("off") ? off : on; const tk = akt ? turKat(akt.textContent) : "";
        if (tk) { durum = tk; neden = "anahtar (toggle)"; } secici = { tip: "tikla", el: tg }; }
      else {
        const db = sonraki("button,a,[role=button],[data-toggle=dropdown],[data-bs-toggle=dropdown]").find((x) => x !== buton && turKat(x.textContent) && !!(x.compareDocumentPosition(kutu) & Node.DOCUMENT_POSITION_FOLLOWING) && katla(x.textContent).length < 25);
        if (db) { const tk = turKat(db.textContent); if (durum === "belirsiz" || /dropdown/i.test(db.className + (db.getAttribute("data-toggle") || "") + (db.getAttribute("data-bs-toggle") || ""))) { durum = tk; neden = "düğme metni"; } secici = { tip: /dropdown/i.test(db.className + (db.getAttribute("data-toggle") || "") + (db.getAttribute("data-bs-toggle") || "") + (db.getAttribute("aria-haspopup") || "")) ? "menu" : "tikla", el: db }; }
      }
    }
    const menuOgesi = (hedef) => [...doc.querySelectorAll("a,li,button,span,div,label")].filter((x) => x.children.length <= 1 && gorunur(x) && sonra(bas, x) && (!secici || x !== secici.el) && !(secici && secici.el.contains(x)) && turKat(x.textContent) === hedef && katla(x.textContent).length < 25)[0] || null;
    return { kutu, buton, okulNoEt, anahtarEl, durum, neden, tiklanacak, secici, menuOgesi };
  }
  // v2.3.32: Hızlı Öğrenci Arama türünü hedefe çevir (select seçeneği, açılır menü öğesi ya da anahtar tıklaması)
  function aramaTuruCevir(yb, hedef, deneme) {
    const sc = yb.secici;
    if (sc && sc.tip === "select") {
      const o = [...sc.el.options].find((x) => { const m = katla(x.text); return hedef === "tc" ? /kimlik|^t\.?\s?c/.test(m) : /okul ?no/.test(m); });
      if (!o) return false; sc.el.value = o.value; o.selected = true; islemYapildi();
      sc.el.dispatchEvent(new Event("input", { bubbles: true })); sc.el.dispatchEvent(new Event("change", { bubbles: true })); return true;
    }
    const mo = yb.menuOgesi(hedef); if (mo && sc && sc.tip === "menu") { islemYapildi(); tamTikla(mo.querySelector("a,button") || mo.closest("a,button") || mo); return true; }
    if (sc && sc.tip === "menu") { islemYapildi(); tamTikla(sc.el); return true; } // menü açılır; sonraki turda öğe tıklanır
    const el = (sc && sc.el) || yb.tiklanacak; if (!el) return false; islemYapildi();
    if (el.classList && el.classList.contains("toggle")) { // v2.3.33: bootstrap-toggle — her denemede farklı yol
      const yol = (deneme || 0) % 4, cb = el.querySelector("input[type=checkbox]");
      if (yol === 0) { tamTikla(el); return "kutu tıklandı"; }
      if (yol === 1) { el.setAttribute("data-eoa-hedef", "1"); window.postMessage({ kaynak: "eokul-eklenti-komut", islem: "toggle", hedef: hedef }, "*"); return "sayfa jQuery bootstrapToggle"; }
      if (yol === 2) { const lb = el.querySelector(el.classList.contains("off") ? ".toggle-off" : ".toggle-on") || el.querySelector(".toggle-group") || el; tamTikla(lb); return "etiket tıklandı"; }
      if (cb) { cb.checked = !cb.checked; cb.dispatchEvent(new Event("click", { bubbles: true })); cb.dispatchEvent(new Event("change", { bubbles: true })); return "gizli kutu değiştirildi"; }
      tamTikla(el); return "kutu tıklandı";
    }
    tamTikla(el); return true;
  }
  // v2.3.33: tür seçicinin gerçek yapısını bir kez günlüğe yaz (değerler ve rakamlar silinir; kişisel veri yok)
  function turDokumu(yb) {
    try { if (sessionStorage.getItem("eoa-tur-dokum")) return; sessionStorage.setItem("eoa-tur-dokum", "1");
      let k = yb.kutu; for (let i = 0; i < 4 && k.parentElement && !(yb.secici && k.contains(yb.secici.el)); i++) k = k.parentElement;
      const c = k.cloneNode(true); c.querySelectorAll("input,textarea").forEach((x) => { x.removeAttribute("value"); x.value = ""; });
      const h = c.outerHTML.replace(/\s+/g, " ").replace(/\d{3,}/g, "#").slice(0, 1800);
      log("TANI tür seçici (" + location.pathname + "): " + h);
    } catch (e) { log("TANI tür seçici yazılamadı: " + e.message); }
  }
  // v2.3.32: öğrencinin mevcut Özürlü Devamsızlıklar tablosunda bu satırın tarihleriyle çakışan kayıt var mı
  const gunNo = (g) => { const m = String(g || "").match(/(\d{1,2})[./](\d{1,2})[./](\d{4})/); return m ? Math.round(Date.UTC(+m[3], +m[2] - 1, +m[1]) / 86400000) : null; };
  function satirAraligi(s) {
    const b = gunNo(s.bas); if (b === null) return null;
    let e = gunNo(s.bit); const su = Math.ceil(Number(String(s.sure || "").replace(",", ".")) || 0);
    if (e === null || e < b) e = su > 0 ? b + su - 1 : b;
    return [b, e];
  }
  function cakisanKayit(s) {
    const ar = satirAraligi(s); if (!ar) return null;
    if (kayitYokBilgisi()) return null; // v2.3.33: "Kaydı Bulunamamıştır" = mevcut kayıt yok
    const bas = metinBul("Öğrencinin Özürlü Devamsızlıkları", "a,span,div,td,th,label,h1,h2,h3,h4,h5,p,b,legend");
    const trs = bas ? [...bas.ownerDocument.querySelectorAll("tr")].filter((tr) => sonra(bas, tr)) : [];
    for (const tr of trs) {
      if (tr.querySelector("table,select,input,textarea") || tr.cells.length < 2) continue;
      const tarihler = [...norm([...tr.cells].map((c) => c.textContent).join(" ")).matchAll(/\b\d{1,2}[./]\d{1,2}[./]\d{4}\b/g)].map((m) => gunNo(m[0])).filter((x) => x !== null);
      if (!tarihler.length) continue;
      const kb = Math.min(...tarihler), ke = Math.max(...tarihler);
      if (kb <= ar[1] && ke >= ar[0]) return norm(tr.textContent).slice(0, 100);
    }
    return null;
  }
  const zatenGirilmis = (x) => { x.kurtar = true; if (x.satirlar[x.idx]) x.satirlar[x.idx].sari = true; bitir(x, "ATLANDI", "Zaten girilmiş — atlandı"); };
  const TEKRAR_RE = /(daha once|zaten|onceden|ayni tarih|mevcut).{0,60}(girilmis|kayit|kaydedilmis|devamsizlik|bulunmaktadir)|cakis/;
  // v2.3.32: Kaydet sonrası "daha önce girilmiş / çakışıyor" sayfa içi uyarısı
  function tekrarModal() {
    for (const doc of belgeler()) {
      const m = [...doc.querySelectorAll("div,p,span,td")].filter((x) => gorunur(x) && x.children.length <= 3 && katla(x.textContent).length < 300 && TEKRAR_RE.test(katla(x.textContent)) && !/kaydetme islemine devam/.test(katla(x.textContent)) && !/ozurlu devamsizliklari$/.test(katla(norm(x.textContent)))).sort((a, b) => a.textContent.length - b.textContent.length)[0];
      if (!m) continue;
      let kap = m, ok = null; for (let i = 0; i < 6 && kap.parentElement && !ok; i++) { ok = [...kap.parentElement.querySelectorAll("button,input[type=button],a")].find((x) => gorunur(x) && /^(ok|tamam|kapat)$/.test(katla(x.value || x.textContent))) || null; kap = kap.parentElement; }
      if (ok) return { mesaj: norm(m.textContent), ok }; // yalnızca OK düğmeli kutu (tablo metni yanlışlıkla sayılmasın)
    }
    return null;
  }
  // v2.3.32: e-Okul "Okul No Alanındaki Değer 9999999999 Değerinden Büyük Olamaz" kutusu (sayfa içi modal)
  function okulNoBuyukModal() {
    for (const doc of belgeler()) {
      const m = [...doc.querySelectorAll("div,p,span,td")].filter((x) => gorunur(x) && x.children.length <= 3 && /okul no alanindaki deger.*buyuk olamaz/.test(katla(x.textContent)) && katla(x.textContent).length < 200).sort((a, b) => a.textContent.length - b.textContent.length)[0];
      if (!m) continue;
      let kap = m; for (let i = 0; i < 6 && kap.parentElement; i++) { const b = [...kap.parentElement.querySelectorAll("button,input[type=button],a")].find((x) => gorunur(x) && /^(ok|tamam|kapat)$/.test(katla(x.value || x.textContent))); if (b) return { mesaj: norm(m.textContent), ok: b }; kap = kap.parentElement; }
      return { mesaj: norm(m.textContent), ok: null };
    }
    return null;
  }
  // Adım A: ana sayfa (Ortaöğretim Öğrenci İşlemleri)
  const anaSayfaHedefi = () => metinBul("Ortaöğretim Öğrenci İşlemleri");
  // v2.3.33: "Öğrenci İçin Devamsızlık Kaydı Bulunamamıştır (E01-OOG02013)" yalnızca tablo bilgi satırıdır (kayıt yok), uyarı DEĞİL
  const bilgiSatiri = (t) => /kaydi bulunamamistir|kayit bulunamamistir/.test(katla(t));
  const kayitYokBilgisi = () => belgeler().some((doc) => [...doc.querySelectorAll("td,div,span,p")].some((e) => e.children.length <= 3 && gorunur(e) && norm(e.textContent).length < 200 && bilgiSatiri(e.textContent)));
  function kaydetUyarisiYerel() {
    return [...document.querySelectorAll("div,span,td,p,li")].some((e) => { if (e.children.length > 3 || !gorunur(e)) return false; const t = norm(e.textContent);
      if (bilgiSatiri(t)) return false;
      return t.length < 600 && (/E01-OOG02013/.test(t) || /Devam etmek için Kaydet/i.test(t) || /E01-[A-Z0-9]+/.test(t) && /Kaydet/.test(t)); });
  }
  // v2.3.9: Kaydet tıklamasından ÖNCE bekleyen-kaydet durumu depoya yazılır (postback yeniden yüklese de bilinir)
  async function pendingYaz(idx) {
    const x = await oku(); if (!x) return;
    const p = x.kaydetPending && x.kaydetPending.idx === idx ? x.kaydetPending : { idx, tik: 0 };
    x.kaydetPending = { idx, tik: p.tik + 1, ts: Date.now() }; await yaz(x);
    log(`Kaydet bekleniyor: satır ${idx + 1}, ${x.kaydetPending.tik}. tıklama kaydedildi`);
  }
  function tamTikla(el) {
    islemYapildi(); const w = el.ownerDocument.defaultView || window, o = { bubbles: true, cancelable: true, view: w, button: 0 };
    for (const t of ["mouseover", "mousedown", "mouseup", "click"]) el.dispatchEvent(new w.MouseEvent(t, o));
  }
  // v2.3.7: Kaydet sonrası e-Okul onay uyarısı ("...devam ederseniz... Kaydet ... İptal", E01-...) görünüyor mu
  function kaydetUyarisi() {
    return belgeler().some((doc) => [...doc.querySelectorAll("div,span,td,p,li")].some((e) => {
      if (e.children.length > 3 || !gorunur(e)) return false; const t = norm(e.textContent);
      if (bilgiSatiri(t)) return false; // v2.3.33
      return t.length < 600 && (/E01-[A-Z0-9]+/.test(t) || (/Kaydet/.test(t) && /devam/i.test(t) && /İptal|Iptal/.test(t)));
    }));
  }
  // v2.3.13: Kaydet yardımcıları
  function kaydetHazir() { // postback bitti mi (sayfa tam yüklü, UpdatePanel/AJAX yok)
    if (document.readyState !== "complete") return false;
    if (document.documentElement.getAttribute("data-eokul-mesgul") === "1") return false;
    return !(globalThis.RaporYardim && globalThis.RaporYardim.domMesgul(document));
  }
  // confirm/alert yalnızca kaydetme süresince (15 sn) otomatik geçilir; ana_dunya.js bu zaman damgasına bakar
  function kaydetPenceresi() { document.documentElement.setAttribute("data-eokul-otokaydet", String(Date.now() + 15000)); }
  function basariMesaji() {
    const e = [...document.querySelectorAll("div,span,td,p,li")].find((x) => x.children.length <= 3 && gorunur(x) && norm(x.textContent).length < 200 && /başarı(yla|lı)|kaydedildi|kayıt edildi|kayıt işlemi tamam/i.test(norm(x.textContent)));
    return e ? norm(e.textContent) : "";
  }
  function kayitCercevesiVar() { try { return [...document.querySelectorAll("iframe,frame")].length > 0; } catch (e) { return false; } }
  function tikla(el) { log("Tıklanıyor:", el); islemYapildi(); (el.closest("a,button") || el).click(); }

  // ---- Ana döngü ----
  let mesgul = false;

  let mesgulTs = 0, mesgulBildirildi = false;
  async function adim() {
    const d = await oku();
    if (!d || !d.calisiyor || d.idx < 0) return;
    const s = d.satirlar[d.idx];
    if (!s) return;
    const no = d.adimNo;
    await seciciYukle();
    if (oturumKapandi()) { await oturumDurdur(no); return; } // v2.3.31: satır HAZIR kalır, Başlat kaldığı yerden sürer
    // v2.3.11 Adım A: ana sayfa (giris.aspx) — kuyruk çalışıyorsa doğrudan Öğrenci İşlemleri (OOG01001) sayfasına git.
    // Hazır-bekleme ve metin eşleşmesinden ÖNCE yapılır (ana sayfa hiç "sakin" olmasa da çalışsın).
    // v2.3.25: e-Okul "okul türü yada sınıf/şube bulunmamaktadır" bilgilendirme sayfası → döngüye girme, dur
    if (window === window.top && (/OOG00002\.aspx/i.test(location.pathname) || /tan[ıi]ml[ıi] okul t[üu]r[üu]/i.test((document.body && document.body.innerText) || ""))) {
      const m = "e-Okul okul türü seçimini kaybetti (Bilgilendirme sayfası). Okul türünü seçip Özürlü Devamsızlık ekranını açın, sonra Başlat'a basın.";
      log("DURDU: " + m + " Sayfa: " + location.pathname); afis(m);
      await gecis(no, (x) => { x.calisiyor = false; x.step = "durdu"; x.sonHata = m; }); return;
    }
    if (window === window.top && /\/giris\.aspx$/i.test(location.pathname) && !/^(onay_bekle|kaydet1|kaydet2|dogrula)$/.test(d.step)) {
      const son = Number(sessionStorage.getItem("eoa-A") || 0);
      if (Date.now() - son > 5000) {
        sessionStorage.setItem("eoa-A", String(Date.now()));
        const say = Number(sessionStorage.getItem("eoa-A-say") || 0) + 1; sessionStorage.setItem("eoa-A-say", String(say));
        /* v2.3.25: adres yazarak gitmek (OOG01001) okul türü/dönem seçimini düşürüyordu; yalnızca görünen bağlantı tıklanır */
        const h = katla("Ortaöğretim Öğrenci İşlemleri");
        const l = [...document.querySelectorAll("a,li")].filter(gorunur).find((x) => katla(x.textContent).includes(h) && katla(x.textContent).length < h.length + 20);
        if (l) { log("Adım A: bağlantı metinle tıklanıyor:", l); tamTikla(l.tagName === "A" ? l : (l.querySelector("a") || l)); }
        else log("Adım A: 'Ortaöğretim Öğrenci İşlemleri' bağlantısı bulunamadı");
      }
      return;
    }
    // v2.3.36: Kaydet bekçisi — 3 basıştan sonra 12 sn içinde kayıt görülmezse ya da satır Kaydet aşamasında 90 sn'yi aşarsa sarı atla
    if ((d.kaydetToplam || 0) > 0 && (/^(kaydet1|kaydet2|dogrula)$/.test(d.step) || d.kaydetPending)) {
      const sure = Date.now() - (d.kaydetSonTs || 0), tavan = Date.now() - (d.kaydetIlkTs || Date.now());
      if ((d.kaydetToplam >= KAYDET_MAX && sure > KAYDET_BEKLE_MS) || tavan > KAYDET_TAVAN_MS) {
        const bm = basariMesaji();
        if (bm || (formOgeleri() && !kaydetUyarisi() && kayitVar(s.bas, nedenAl(d, s)))) { afis(""); document.documentElement.removeAttribute("data-eokul-otokaydet"); await gecis(no, (x) => bitir(x, "OK", "Kaydedildi" + (bm ? " (" + bm.slice(0, 60) + ")" : ", listede görüldü"))); return; }
        document.documentElement.removeAttribute("data-eokul-otokaydet");
        await gecis(no, (x) => kaydedilemedi(x, `${x.kaydetToplam} kez Kaydet'e basıldı, ${Math.round(KAYDET_BEKLE_MS / 1000)} sn beklendi, yeni satır Özürlü Devamsızlıklar listesinde görülmedi` + (kaydetUyarisi() ? "; e-Okul uyarısı açık: " + uyariMetni() : "") + (!simgeBul("kaydet") ? "; Kaydet simgesi bulunamadı" : ""))); return;
      }
    }
    // v2.3.13: Otomatik Kaydet — 2 basış, aralarında en az 1 sn. Durum her basıştan ÖNCE depoya yazılır,
    // postback sayfayı/çerçeveyi yenilese de kaldığı yerden sürer. Düğme her seferinde yeniden bulunur.
    if (s.ara !== "no" && /^(kaydet1|kaydet2|dogrula)$/.test(d.step)) { // v2.3.32: Rapor — tekrar/çakışma uyarısı → OK, sarı atla, sıradakine geç
      const tm = tekrarModal();
      if (tm) { log("e-Okul tekrar uyarısı:", tm.mesaj); islemYapildi(); tamTikla(tm.ok); document.documentElement.removeAttribute("data-eokul-otokaydet"); await gecis(no, zatenGirilmis); return; }
    }
    if (d.step === "kaydet1" || d.step === "kaydet2") {
      const k = simgeBul("kaydet");
      if (!k) { if (d.step === "kaydet1" && window === window.top && Date.now() - d.stepTs > 15000 && !kayitCercevesiVar()) await gecis(no, (x) => bitir(x, "HATA", "Kaydet (disket) simgesi bulunamadı")); return; }
      if (!kaydetHazir()) return; // postback bitmedi
      const ilk = d.step === "kaydet1";
      if (!ilk && Date.now() - (d.kaydetTs || 0) < KAYDET_ARASI_MS) return; // 1 sn bekleme
      if (!ilk) {
        // 2. basış YALNIZCA e-Okul uyarısı (E01-OOG02013 / "Devam etmek için Kaydet") görününce, 1 sn sonra yapılır. İptal'e asla basılmaz.
        const uyari = kaydetUyarisi();
        if (!uyari) {
          const bm = basariMesaji();
          if (bm || (formOgeleri() && kayitVar(s.bas, nedenAl(d, s)))) {
            log("Uyarı çıkmadan kayıt doğrulandı (1. basış yetti): " + (bm || "satır listede"));
            await gecis(no, (x) => bitir(x, "OK", "Kaydedildi (1. basışta)")); afis(""); return;
          }
          // v2.4.6: uyarı beklemeden — kayıt listede görülmediyse Kaydet ~1 sn arayla toplam 3 kez basılır (Faaliyet'te E01 uyarısı çıkmıyordu,
          // eski kod 2. basışı yalnız uyarıda yapıyordu). 3 basıştan sonra bekçi 12 sn bekler; kayıt yoksa sarı ATLANDI. Doğrulanmadan sıradakine geçilmez.
          if ((d.kaydetToplam || 0) < KAYDET_MAX && Date.now() - (d.kaydetTs || 0) >= KAYDET_ARASI_MS) {
            const ts = Date.now(); if (await gecis(no, (x) => { x.kaydetTs = ts; kaydetSay(x); })) { kaydetPenceresi(); log(`Kayıt henüz listede yok, Kaydet'e ${(d.kaydetToplam || 0) + 1}/${KAYDET_MAX}. basış`); tikla(k); } }
          return;
        }
        if (!d.uyariTs) { const t = Date.now(); log("e-Okul uyarısı görüldü (E01-OOG02013), 1 sn sonra Kaydet'e 2. kez basılacak"); await gecis(no, (x) => { x.uyariTs = t; }); return; }
        if (Date.now() - d.uyariTs < KAYDET_ARASI_MS) return;
      }
      const ts = Date.now();
      if ((d.kaydetToplam || 0) >= KAYDET_MAX) return; // v2.3.36: bekçi karar verir
      if (!(await gecis(no, (x) => { x.step = ilk ? "kaydet2" : "dogrula"; x.kaydetTs = ts; x.kaydetSayisi = 0; x.uyariTs = 0; kaydetSay(x); }))) return;
      kaydetPenceresi();
      log(`Kaydet'e ${ilk ? 1 : 2}. basış` + (ilk ? "" : ` (${((ts - d.kaydetTs) / 1000).toFixed(1)} sn sonra)`) + (kaydetUyarisi() ? " — e-Okul uyarısı görünüyor" : ""));
      tikla(k);
      return;
    }
    if (d.step === "dogrula") {
      if (!simgeBul("kaydet") && !formOgeleri() && !basariMesaji()) return; // ilgisiz çerçeve
      if (!kaydetHazir()) return;
      const bm = basariMesaji();
      if (bm || (!kaydetUyarisi() && formOgeleri() && kayitVar(s.bas, nedenAl(d, s)))) {
        log("Kayıt doğrulandı: " + (bm ? "e-Okul mesajı: " + bm : "satır listede görüldü"));
        document.documentElement.removeAttribute("data-eokul-otokaydet"); afis("");
        await gecis(no, (x) => bitir(x, "OK", bm ? "Kaydedildi (" + bm.slice(0, 60) + ")" : "Kaydedildi, listede görüldü")); return;
      }
      if (kaydetUyarisi() && (d.kaydetSayisi || 0) < 1 && Date.now() - (d.kaydetTs || 0) >= KAYDET_ARASI_MS) {
        const k = simgeBul("kaydet"); const ts = Date.now();
        if (k && (d.kaydetToplam || 0) < KAYDET_MAX && await gecis(no, (x) => { x.kaydetSayisi = 1; x.kaydetTs = ts; kaydetSay(x); })) { kaydetPenceresi(); log("e-Okul uyarısı hâlâ açık, Kaydet'e 3. kez basılıyor"); tikla(k); }
        return;
      }
      if (Date.now() - d.stepTs > 20000) { // v2.3.36: kayıt görülmediyse toplam 3 denemeye kadar yeniden bas, sonra sarı atla
        const k = simgeBul("kaydet"), ts = Date.now();
        if (k && (d.kaydetToplam || 0) < KAYDET_MAX) { if (await gecis(no, (x) => { x.stepTs = ts; x.kaydetTs = ts; kaydetSay(x); })) { kaydetPenceresi(); log(`Kayıt doğrulanamadı, Kaydet yeniden deneniyor (${(d.kaydetToplam || 0) + 1}/${KAYDET_MAX})`); tikla(k); } }
        else await gecis(no, (x) => kaydedilemedi(x, `Kaydet'e ${d.kaydetToplam || 0} kez basıldı, kayıt doğrulanamadı` + (kaydetUyarisi() ? "; e-Okul uyarısı açık" : "")));
      }
      return;
    }
    if (!sayfaHazir()) { // v2.3.24: çalışırken sayfa uzun süre "meşgul" kalırsa sessiz kalma
      if (window === window.top) { if (!mesgulTs) mesgulTs = Date.now();
        else if (Date.now() - mesgulTs > 10000 && !mesgulBildirildi) { mesgulBildirildi = true; const m = `Sayfa 10 sn'dir hazır değil (yükleniyor: ${document.readyState}, e-Okul AJAX meşgul: ${document.documentElement.getAttribute("data-eokul-mesgul") === "1" ? "evet" : "hayır"}). Adım: ${d.step}. Sayfa: ${location.pathname}`; log("BEKLİYOR: " + m); afis("e-Okul Asistanı bekliyor: " + m); } }
      return;
    }
    if (mesgulBildirildi) { mesgulBildirildi = false; afis(""); } mesgulTs = 0;
    // v2.3.9: HER turda önce: e-Okul Kaydet onay uyarısı / bekleyen kaydet
    {
      const uy = kaydetUyarisiYerel(), p = d.kaydetPending && d.kaydetPending.idx === d.idx ? d.kaydetPending : null;
      if (OTO_KAYDET && uy && !/^(kaydet1|kaydet2|dogrula|kurtar)$/.test(d.step)) { // v2.3.45: otomatik Kaydet kapalı // v2.3.36: kurtarmada eski uyarıya yeni satır adına basılmaz
        if (document.documentElement.getAttribute("data-eokul-otokaydet") === "1" && !p) return; // çift-kaydet akışı bu sayfada sürüyor
        const tik = p ? p.tik : 1;
        if (tik >= 3) { log("Uyarı 3 Kaydet tıklamasından sonra hâlâ açık"); if (p && Date.now() - p.ts > KAYDET_ARASI_MS + 5000) await gecis(no, (x) => kaydedilemedi(x, "e-Okul uyarısı 3 Kaydet'ten sonra geçilemedi")); return; }
        if (p && Date.now() - p.ts < KAYDET_ARASI_MS) return; // ayarlı bekleme
        const k = simgeBul("kaydet");
        if (!k) { log("Uyarı açık ama Kaydet simgesi bu çerçevede yok"); return; }
        log(`e-Okul uyarısı açık (E01-OOG02013): Kaydet'e ${tik + 1}. kez basılıyor`);
        if ((d.kaydetToplam || 0) >= KAYDET_MAX) return; // v2.3.36: bekçi karar verir
        await gecis(no, kaydetSay); await pendingYaz(d.idx); document.documentElement.setAttribute("data-eokul-otokaydet", "1"); tikla(k);
        return; // uyarı açıkken başka hiçbir şey (arama yazma vb.) yapılmaz
      }
      if (p && !/^(kaydet1|kaydet2)$/.test(d.step)) {
        if (formOgeleri() && kayitVar(s.bas, nedenAl(d, s))) { log("Kayıt listede görüldü (uyarı yok) — başarılı"); afis(""); await gecis(no, (x) => bitir(x, "OK", "Kaydedildi, listede görüldü")); return; }
      }
    }
    if (d.atla) { await gecis(no, (x) => { x.atla = false; bitir(x, "ATLANDI", "Kullanıcı atladı"); }); return; }
    const gecen = Date.now() - d.stepTs;

    if (d.step === "kurtar") {
      if (aramaOgeleri(s)) { log("Kurtarma: arama ekranına dönüldü"); await gecis(no, (x) => { x.step = "ara"; x.kurtarSay = 0; }); return; }
      if (yeniArama()) { log("Adım B: yeni arayüz Hızlı Öğrenci Arama bulundu"); await gecis(no, (x) => { x.step = "ara"; x.kurtarSay = 0; }); return; }
      if (window === window.top && formOgeleri()) { // v2.3.25: Özürlü Devamsızlık ekranı açık → yerinde çalış, menüye/başka sayfaya gitme
        if (gecen > 4000) { const m = "Özürlü Devamsızlık ekranı açık ama sol menüde Hızlı Öğrenci Arama (Okul No + Ara) bulunamadı. Başka sayfaya gidilmedi."; log("DURDU: " + m); afis(m); await gecis(no, (x) => { x.calisiyor = false; x.step = "durdu"; x.sonHata = m; }); }
        return;
      }
      const ana = window === window.top && anaSayfaHedefi();
      if (ana && !(d.kurtarSay && gecen < 3000) && (d.kurtarSay || 0) < 8) {
        log("Adım A: ana sayfa, 'Ortaöğretim Öğrenci İşlemleri' tıklanıyor");
        if (await gecis(no, (x) => { x.kurtarSay = (x.kurtarSay || 0) + 1; })) tamTikla(ana.closest("a,button") || ana);
        return;
      }
      if (window !== window.top) return;
      if (d.kurtarSay && gecen < 3000) return; // v2.3.6: denemeler arası en az 3 sn
      const say = (d.kurtarSay || 0) + 1;
      if (say > 8) { await gecis(no, (x) => { x.calisiyor = false; x.step = "durdu"; x.sonHata = "Özürlü Devamsızlık ekranına otomatik dönülemedi (8 deneme; menü adayları Günlük'te). Ekranı elle açıp yeniden başlatın."; }); return; }
      const h = kurtarmaHedefi(say - 1);
      log(`Kurtarma denemesi ${say}/8:`, h ? norm(h.textContent) : `menü öğesi yok. BEKLENİYOR: Hızlı Öğrenci Arama (T.C./Okul No radyosu + Ara) ya da "${MENU_METNI}" menüsü; elle açarsanız otomatik devam eder.`);
      if (await gecis(no, (x) => { x.kurtarSay = say; }) && h) tikla(h);
      return;
    }

    if (/^(ara|bekle_ogrenci|menu)$/.test(d.step)) { // v2.3.32: TC, Okul No kutusuna yazıldıysa → OK, TC'ye çevir, bir kez yeniden dene
      const mb = okulNoBuyukModal();
      if (mb) {
        log("e-Okul uyarısı:", mb.mesaj); if (mb.ok) { islemYapildi(); tamTikla(mb.ok); }
        if (s.ara !== "no" && d.tcYenidenIdx !== d.idx) { log("Arama türü TC'ye çevrilip bir kez yeniden deneniyor"); await gecis(no, (x) => { x.tcYenidenIdx = x.idx; x.step = "ara"; x.anahtarSay = 0; }); }
        else await gecis(no, (x) => tcHatali(x, mb.mesaj.slice(0, 120)));
        return;
      }
    }
    if (d.step === "ara") {
      const a = aramaOgeleri(s);
      const yb = !a && yeniArama();
      if (yb) { // v2.3.8 Adım B: Okul No anahtarı açık olmalı, kenar kutusuna numara, Ara
        // v2.3.32: rapor satırı (ara !== "no") T.C. Kimlik No ile aranır: tür seçici önce TC'ye çevrilir ve doğrulanır. Veli izni (ara: "no") eskisi gibi.
        if (s.ara !== "no") {
          const tc = String(s.tc || "").replace(/\D/g, "");
          if (yb.durum !== "tc") {
            const say = d.anahtarSay || 0;
            if (say === 0) turDokumu(yb);
            if (say >= 4) { // v2.3.33: yedek yol — Özürlü Devamsızlık ekranındaki eski arama (T.C.Kimlik No radyosu)
              const mn = window === window.top && menuBul();
              if (mn && d.eskiAramaIdx !== d.idx + 1) { log("Adım B: tür çevrilemedi; yedek yol: Özürlü Devamsızlık ekranındaki T.C.Kimlik No araması"); if (await gecis(no, (x) => { x.eskiAramaIdx = x.idx + 1; })) tikla(mn); return; }
              const m = "Hızlı Öğrenci Arama türü T.C. Kimlik No'ya çevrilemedi (4 deneme). Sol menüde türü elle 'T.C. Kimlik No' yapın ya da Özürlü Devamsızlık ekranını açın; otomatik devam eder."; log("Adım B: " + m); afis(m); return; }
            log(`Adım B: arama türü ${yb.durum === "okulno" ? "Okul No" : "belirsiz"} (${yb.neden || "-"}), T.C. Kimlik No'ya çevriliyor (${say + 1}/4)`);
            if (await gecis(no, (x) => { x.anahtarSay = say + 1; })) { const y = aramaTuruCevir(yb, "tc", say); if (typeof y === "string") log("Adım B: anahtar yolu: " + y); }
            return; // sonraki turda yeniden doğrulanır
          }
          log(`Adım B: arama türü T.C. Kimlik No (${yb.neden})`);
          if (yb.kutu.value !== tc) { log("Adım B: TC yazılıyor"); await yazarakYaz(yb.kutu, tc); return; }
          log("Adım B: Ara tıklanıyor (TC)");
          if (await gecis(no, (x) => { x.step = "bekle_ogrenci"; })) tamTikla(yb.buton);
          return;
        }
        const sayi = String(s.no || s.tc || "");
        if (yb.durum === "tc") {
          const say = d.anahtarSay || 0;
          if (say >= 2) { log("Adım B: anahtar 2 tıklamadan sonra hâlâ TC gösteriyor; elle Okul No'ya alın"); return; }
          if (!yb.tiklanacak && !yb.secici) { log("Adım B: anahtar TC'de ama tıklanacak öğe bulunamadı; elle Okul No'ya alın"); return; }
          log(`Adım B: anahtar TC gösteriyor (${yb.neden}), Okul No'ya çevriliyor (${say + 1}/2)`);
          if (await gecis(no, (x) => { x.anahtarSay = say + 1; })) { if (yb.secici) aramaTuruCevir(yb, "okulno"); else tamTikla(yb.tiklanacak); }
          return; // sonraki turda yeniden doğrulanır
        }
        if (yb.durum === "belirsiz") log("Adım B: anahtar durumu belirlenemedi; tıklanmadı, Okul No varsayıldı");
        else log(`Adım B: anahtar Okul No'da (${yb.neden})`);
        if (yb.kutu.value !== sayi) { log("Adım B: numara yazılıyor"); await yazarakYaz(yb.kutu, sayi); return; }
        log("Adım B: Ara tıklanıyor:", sayi);
        if (await gecis(no, (x) => { x.step = "bekle_ogrenci"; })) tamTikla(yb.buton);
        return;
      }
      if (!a && window === window.top && (gecen > 6000 || (gecen > 1500 && kurtarmaHedefi()))) { log("Arama kutusu yok (ana sayfa?), kurtarmaya geçiliyor"); await gecis(no, (x) => { x.step = "kurtar"; x.kurtarSay = 0; }); return; }
      if (!a) { if (window === window.top) log("Hızlı Öğrenci Arama kutusu bu çerçevede bulunamadı (bekleniyor)"); return; }
      // Varsayılan seçili "Okul No"; önce T.C.Kimlik No radyosunu seç. Seçim postback yaparsa sayfa yenilenir, bir sonraki turda devam edilir.
      if (!a.tcRadyo.checked) { log((s.ara === "no" ? "Okul No" : "T.C.Kimlik No") + " radyosu seçiliyor"); islemYapildi(); a.tcRadyo.click(); return; }
      if (a.kutu.value !== anahtar(s)) { log(s.ara === "no" ? "Okul no yazılıyor" : "TC yazılıyor"); await yazarakYaz(a.kutu, anahtar(s)); return; } // Ara bir sonraki turda (bekleme sonrası)
      log("Öğrenci aranıyor:", anahtar(s));
      if (await gecis(no, (x) => { x.step = "bekle_ogrenci"; x.aramaOncesi = performance.timeOrigin; })) tikla(a.buton);
      return;
    }

    if (d.step === "bekle_ogrenci") {
      // Arama sonrası postback ile sayfa yenilenir; TC sayfada görünmeyebilir. Yenilenmiş sayfa + 1.5 sn yeter.
      const yenilendi = performance.timeOrigin > d.stepTs - 500;
      if ((yenilendi && gecen > 1500) || gecen > 8000 || (document.body && document.body.innerText.includes(anahtar(s)))) {
        log("Öğrenci arama tamam (yenilendi=" + yenilendi + ")");
        await gecis(no, (x) => { x.step = "menu"; });
      }
      return;
    }

    if (d.step === "menu") {
      if (formOgeleri()) { log("Form zaten açık, menü atlandı"); await gecis(no, (x) => { x.step = "form"; x.denemeSay = 0; x.nedenSay = 0; }); return; }
      const m = menuBul();
      if (!m && window === window.top && (d.ustMenuSay || 0) < 2 && gecen > 1500) { // v2.3.8: kapalı üst menüyü aç
        const ust = metinBul("Öğrenci Dosya Bilgileri");
        if (ust && await gecis(no, (x) => { x.ustMenuSay = (x.ustMenuSay || 0) + 1; x.step = "menu"; })) { log("Üst menü açılıyor: Öğrenci Dosya Bilgileri"); tamTikla(ust.closest("a") || ust); return; }
      }
      if (!m) {
        const ogrenciVar = belgeler().some((doc) => doc.body && doc.body.innerText.includes(anahtar(s)));
        if (window === window.top && gecen > 3000) log(`BEKLENİYOR: "${MENU_METNI}" menüsü ya da Özürlü Devamsızlık formu (Nedeni/Başlangıç Tarihi/Süre/Açıklama). Menüyü elle açarsanız otomatik devam eder.` + (ogrenciVar ? "" : " (öğrenci ekranda görünmüyor)"));
        // Öğrenci açılmadı: e-Okul ana sayfaya döndü ya da öğrenci bulunamadı (öğrenci görünüyorsa elle gezinmeyi bekle)
        if (gecen > 8000 && window === window.top && !ogrenciVar) { log("Öğrenci bulunamadı: " + anahtar(s) + " — atlandı, sıradakine geçiliyor"); await gecis(no, (x) => { // v2.3.7: aynı öğrencinin bekleyen diğer satırları da HATA (tekrar aranmaz)
          const k = anahtar(x.satirlar[x.idx]);
          x.satirlar.forEach((r, i) => { if (i !== x.idx && r.durum === "HAZIR" && !!r.veli === !!x.satirlar[x.idx].veli && anahtar(r) === k) { r.durum = "ATLANDI"; r.sari = true; r.sonuc = "Bulunamadı — atlandı: " + k; } });
          x.kurtar = true; x.satirlar[x.idx].sari = true; bitir(x, "ATLANDI", "Bulunamadı — atlandı: " + k); }); }
        return;
      }
      log("Menü tıklanıyor:", MENU_METNI);
      if (await gecis(no, (x) => { x.step = "form"; x.denemeSay = 0; x.nedenSay = 0; })) tikla(m);
      return;
    }

    if (d.step === "form") {
      const f = formOgeleri();
      if (!f) {
        if (gecen > 4000 && window === window.top) {
          const m = menuBul(), say = d.formMenuSay || 0;
          if (m && say < 3 && await gecis(no, (x) => { x.formMenuSay = say + 1; })) {
            // v2.3.7: 1) td'ye tam fare olayları 2) içteki <a> 3) üst <tr>
            const hedef = say === 0 ? m : say === 1 ? (m.querySelector("a") || m.closest("a") || m) : (m.closest("tr") || m);
            log(`Form yok, menü yeniden tıklanıyor (${say + 1}/3):`, hedef); tamTikla(hedef); return;
          }
          log(`BEKLENİYOR: Özürlü Devamsızlık formu (etiketler: ${Object.values(ETIKET).join(" / ")}). "${MENU_METNI}" ekranını elle açarsanız otomatik devam eder.`);
        }
        return;
      }
      if (gecen < PROFIL[HIZ].oturma) return; // postback sonrası sayfanın oturması (hız profiline göre)

      if (s.ara !== "no" && window === window.top) { // v2.3.33: açılan öğrenci doğrulanır (ekrandaki TC satırın TC'si olmalı)
        const tc = String(s.tc || "").replace(/\D/g, ""), metin = (document.body && document.body.innerText) || "";
        const tcler = (metin.match(/\b\d{11}\b/g) || []);
        if (tc && tcler.length && !tcler.includes(tc)) { log("Ekrandaki öğrenci bu satırın öğrencisi değil; girilmedi"); await gecis(no, (x) => { x.kurtar = true; if (x.satirlar[x.idx]) x.satirlar[x.idx].sari = true; bitir(x, "ATLANDI", "Ekranda farklı öğrenci açıldı — atlandı"); }); return; }
      }
      if (s.ara !== "no") { const ck = cakisanKayit(s); if (ck) { log("Çakışan kayıt e-Okul'da var:", ck); afis(""); await gecis(no, zatenGirilmis); return; } } // v2.3.32
      if (kayitVar(s.bas, nedenAl(d, s))) {
        await gecis(no, (x) => bitir(x, "ATLANDI", "Aynı tarihli rapor kaydı zaten var"));
        return;
      }
      // Alanlar kapalıysa önce araç çubuğundaki "+" (Yeni) simgesine bas
      if (f.neden.disabled || f.bas.disabled || f.sure.disabled || f.bas.readOnly && !f.bas.value) {
        const yeni = simgeBul("yeni");
        log("Alanlar kapalı; Yeni simgesi:", yeni);
        if (!yeni) { await gecis(no, (x) => bitir(x, "HATA", "Alanlar kapalı ve Yeni (+) simgesi bulunamadı")); return; }
        if (await gecis(no, (x) => { x.step = "form"; })) tikla(yeni);
        return;
      }
      const hedefNeden = katla(nedenAl(d, s));
      const secenek = [...f.neden.options].find((o) => katla(o.text) === hedefNeden) || (hedefNeden && [...f.neden.options].find((o) => katla(o.text).includes(hedefNeden)));
      if (!secenek) {
        log("Nedeni seçenekleri:", [...f.neden.options].map((o) => o.text));
        await gecis(no, (x) => bitir(x, "HATA", `"${nedenAl(d, s)}" seçeneği listede yok`));
        return;
      }
      if (!String(s.aciklama || "").trim()) { await gecis(no, (x) => bitir(x, "HATA", "Açıklama seçilmemiş; panelden listeden seçin")); return; }
      const bas = String(s.bas).replace(/[.\-]/g, "/"); // e-Okul GG/AA/YYYY ister
      // e-Okul Türkçe ondalık ister: yarım gün = "0,5" (tam gün = "1")
      const sure = String(s.sure).replace(/\s+/g, "").replace(".", ",").replace(/,0+$/, "");
      const acik = guvenliMetin(veliMi(s) ? VELI_ACIKLAMA : s.aciklama);
      if (f.acik.tagName === "SELECT") { // v2.3.3: Açıklama liste ise "veli" içeren seçeneği seç, yoksa dokunma
        const ao = veliMi(s) ? [...f.acik.options].find((o) => katla(o.text).includes("veli")) : null;
        if (ao && f.acik.value !== ao.value) { ao.selected = true; f.acik.dispatchEvent(new Event("change", { bubbles: true })); islemYapildi("kisa"); log("Açıklama seçildi:", ao.text); return; }
      }
      if (f.neden.value !== secenek.value) {
        if (f.neden.disabled) { log("Nedeni kapalı"); return; }
        const nsay = (d.nedenSay || 0) + 1; // v2.3.24: seçim tutmazsa sonsuz denemek yerine durdur ve nedenini yaz
        if (nsay > 3) { await gecis(no, (x) => bitir(x, "HATA", `Nedeni "${secenek.text}" seçilemedi (3 deneme; seçili: "${f.neden.selectedOptions[0] ? f.neden.selectedOptions[0].text : ""}")`)); return; }
        await gecis(no, (x) => { x.nedenSay = nsay; });
        f.neden.focus();
        secenek.selected = true; // yalnızca sayfada var olan <option> seçilir
        f.neden.dispatchEvent(new Event("input", { bubbles: true }));
        f.neden.dispatchEvent(new Event("change", { bubbles: true }));
        f.neden.blur();
        islemYapildi();
        log("Nedeni seçildi:", secenek.text, "(postback olabilir, bir sonraki turda devam)");
        return; // AutoPostBack ise sayfa yenilenir; değilse sonraki turda diğer alanlar doldurulur
      }
      // Her turda yalnızca BİR alan doldurulur; arada postback/UpdatePanel bitmesi beklenir.
      const alanlar = [[f.sure, sure, "Süre"]];
      if (!GUVENLI) {
        // Tarih takvimden de seçilebiliyor; zaten doğruysa hiç dokunma.
        if (f.bas.value !== bas) alanlar.unshift([f.bas, bas, "Başlangıç"]);
        if (acik && f.acik.tagName !== "SELECT") alanlar.push([f.acik, acik, "Açıklama"]);
      }
      for (const [el, v, ad] of alanlar) {
        if (el.value !== v) {
          const sayi = (d.denemeSay || 0) + 1;
          if (sayi > 8) { await gecis(no, (x) => bitir(x, "HATA", `${ad} alanı doldurulamadı (değer="${el.value}")`)); return; }
          log(ad + " harf harf yazılıyor:", v);
          await yazarakYaz(el, v, ad === "Başlangıç" ? "orta" : "kisa");
          await gecis(no, (x) => { x.denemeSay = sayi; });
          return;
        }
      }
      { const sec = f.neden.selectedOptions[0]; if (!sec || katla(sec.text) !== katla(secenek.text)) { log("Nedeni doğrulanamadı:", sec ? sec.text : "(boş)"); return; } } // v2.3.24: Kaydet'ten önce Nedeni metinle doğrulanır
      log("Form dolduruldu", { neden: secenek.text, guvenliMod: GUVENLI, bas, sure, acik: GUVENLI ? "(boş bırakıldı)" : acik, kaydetSimgesi: simgeBul("kaydet") });
      formTani(f);
      const tarihNotu = f.bas.value !== bas ? ` DİKKAT: Başlangıç Tarihi ${f.bas.value}, olması gereken ${bas}.` : "";
      if (!OTO_KAYDET || GUVENLI || tarihNotu) { // v2.3.4: veli izni satırları da raporlu gibi otomatik (2 tık) kaydedilir
        const taban = listeSatirSayisi(); const beklenen = { bas, sure, neden: secenek.text };
        await gecis(no, (x) => { x.step = "onay_bekle"; x.onayTaban = taban; x.onayBeklenen = beklenen; x.onayTs = Date.now(); });
        log("Form dolduruldu, öğretmenin Kaydet'e basması bekleniyor (liste satırı: " + taban + ")");
        afis(`${s.adsoyad || s.tc}: form dolduruldu (${s.faaliyet ? "Faaliyet, " : ""}${bas}, ${sure} gün${s.yarim ? " — YARIM GÜN" : ""}).${tarihNotu} Kontrol edip KAYDET (disket) simgesine SİZ basın; kayıt listede görülünce sıradaki öğrenciye geçilir.`);
        return;
      }
      await gecis(no, (x) => { x.step = "kaydet1"; });
      afis(`${s.adsoyad || s.tc}: form dolduruldu, otomatik kaydediliyor...`);
      return;
    }

    if (d.step === "onay_bekle") { // v2.3.45: öğretmen Kaydet'e basar; eklenti yalnızca izler
      const f = formOgeleri(); if (!f) return;
      const bm = basariMesaji(), uy = kaydetUyarisi(), n = listeSatirSayisi();
      if (kayitVar(s.bas, nedenAl(d, s)) || (!uy && (bm || (d.onayTaban != null && n > d.onayTaban)))) {
        afis(""); log("KAYDEDİLDİ (öğretmen kaydetti):", bm || (n > (d.onayTaban || 0) ? "listeye yeni satır eklendi" : "satır listede görüldü"));
        await gecis(no, (x) => bitir(x, "OK", "KAYDEDİLDİ — " + (bm ? bm.slice(0, 60) : "listede görüldü"))); return;
      }
      if (uy) { const um = uyariMetni(); if (um && um !== d.onayUyari) { log("e-Okul uyarısı (Kaydet sonrası):", um); await gecis(no, (x) => { x.onayUyari = um; }); afis("e-Okul uyarısı: " + um + " — Kontrol edip gerekirse yeniden Kaydet'e siz basın ya da satırı panelden atlayın."); } return; }
      const b = d.onayBeklenen; // postback alanları sıfırladıysa (Nedeni değişince Süre/Tarih boşalır) yeniden doldur
      if (b && !f.bas.disabled && (f.bas.value !== b.bas || f.sure.value !== b.sure || !(f.neden.selectedOptions[0] && katla(f.neden.selectedOptions[0].text) === katla(b.neden)))) {
        const ns = (d.sifirSay || 0) + 1;
        log(`Alanlar sıfırlandı (postback?): Tarih="${f.bas.value}" Süre="${f.sure.value}" Nedeni="${f.neden.selectedOptions[0] ? f.neden.selectedOptions[0].text : ""}"; yeniden dolduruluyor (${ns}/3)`);
        if (ns > 3) { await gecis(no, (x) => kaydedilemedi(x, "alanlar e-Okul tarafından sürekli sıfırlanıyor (Nedeni seçimi postback); Tarih/Süre tutmadı")); return; }
        await gecis(no, (x) => { x.sifirSay = ns; x.step = "form"; x.denemeSay = 0; x.nedenSay = 0; }); return;
      }
    }
  }

  // e-Okul'a giden Açıklama: ASP.NET istek doğrulamasına takılmasın diye yalnızca harf/rakam/boşluk, ASCII, en çok 50 karakter.
  // e-Okul'a giden Açıklama: yalnızca harf (Türkçe dahil), rakam, boşluk; noktalama yok; en çok 40 karakter.
  function guvenliMetin(s) {
    return String(s || "").replace(/[^A-Za-zÇĞİÖŞÜçğıöşü ]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 40).trim();
  }

  // Tanılama: kaydetmeden önce formdaki tüm alanları (gizliler dahil) günlüğe yazar.
  function formTani(f) {
    const kok = f.neden.form || f.neden.closest("table")?.parentElement || document;
    const ozet = [...kok.querySelectorAll("input,select,textarea")].filter((x) => !/^__(VIEWSTATE|EVENTVALIDATION|PREVIOUSPAGE)/.test(x.name || ""))
      .map((x) => {
        const v = x.tagName === "SELECT" ? `${x.value} [${x.options[x.selectedIndex]?.text || ""}]` : (x.type === "radio" || x.type === "checkbox") ? (x.checked ? "✓" : "–") : x.value;
        return `${x.tagName.toLowerCase()}${x.type ? ":" + x.type : ""} name=${x.name || "-"} id=${x.id || "-"}${x.readOnly ? " RO" : ""}${x.disabled ? " DIS" : ""} = "${String(v).slice(0, 40)}"`;
      });
    const vs = kok.querySelector("[name=__VIEWSTATE]"), ev = kok.querySelector("[name=__EVENTVALIDATION]");
    log(`TANI: ${ozet.length} alan; VIEWSTATE ${vs ? vs.value.length : 0} kr, EVENTVALIDATION ${ev ? "var" : "yok"}`);
    for (let i = 0; i < ozet.length; i += 6) log("TANI " + ozet.slice(i, i + 6).join(" | "));
  }

  // Satırın Türü Sevkli ise Nedeni "Sevkli", değilse ayardaki (varsayılan "Raporlu")
  // v2.3.45: Özürlü Devamsızlıklar listesindeki veri satırı sayısı (öğretmen Kaydet'e basınca artar)
  function listeSatirSayisi() {
    return [...document.querySelectorAll("tr")].filter((tr) => tr.cells.length >= 3 && !tr.querySelector("table,select,input,textarea,th")
      && [...tr.cells].some((c) => /\b\d{1,2}[./]\d{1,2}[./]\d{4}\b/.test(c.textContent))).length;
  }
  function uyariMetni() {
    const e = belgeler().flatMap((doc) => [...doc.querySelectorAll("div,span,td,p,li")]).find((x) => x.children.length <= 3 && gorunur(x) && /E01-|uyarı|hata|zaten|çakış|giriniz|boş olamaz/i.test(norm(x.textContent)) && norm(x.textContent).length < 300);
    return e ? norm(e.textContent).slice(0, 160) : "";
  }
  const nedenAl = (d, s) => (veliMi(s) ? VELI_NEDEN : s && s.neden ? s.neden : s && s.tur === "Sevkli" ? "Sevkli" : d.neden || "Raporlu");

  function afis(metin) {
    if (window !== window.top && !document.querySelector("select")) return;
    let a = document.getElementById("eokul-eklenti-afis");
    if (!metin) { if (a) a.remove(); return; }
    if (!a) { a = document.createElement("div"); a.id = "eokul-eklenti-afis";
      a.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483646;background:#ffeb3b;color:#000;font:bold 14px Arial;padding:8px;text-align:center;box-shadow:0 2px 6px #0006";
      document.body.appendChild(a); }
    a.textContent = metin;
  }

  async function hataSayfasiKontrol() {
    if (!/hata_yakala/i.test(location.href)) return false;
    const d = await oku();
    if (d && d.calisiyor) {
      const yol = new URLSearchParams(location.search).get("aspxerrorpath") || "";
      log("e-Okul sunucu hata sayfası:", location.href, "adım:", d.step);
      const s = d.satirlar[d.idx];
      if (s) { s.durum = "HATA"; s.sonuc = `e-Okul sunucu hatası (adım: ${d.step})`; }
      d.sonHata = `e-Okul hata sayfasına yönlendirdi (${yol}), adım: ${d.step}, TC: ${s ? s.tc : ""}. Otomasyon DURDURULDU. e-Okul'a yeniden girip formu elle kontrol edin.`;
      d.calisiyor = false; d.step = "durdu"; d.adimNo = (d.adimNo || 0) + 1;
      await yaz(d);
    }
    return true;
  }

  async function dongu() {
    if (await hataSayfasiKontrol()) return;
    if (mesgul) return;
    mesgul = true;
    try { await adim(); } catch (e) { console.warn("[e-Okul eklentisi]", e); }
    finally { mesgul = false; }
  }
  if (window === window.top) { log("Sayfa: " + location.pathname); if (!/\/giris\.aspx$/i.test(location.pathname)) sessionStorage.removeItem("eoa-A-say"); } // v2.3.11
  (function planla() { setTimeout(async () => { if (!baglamKontrol()) return; try { await dongu(); } catch (e) { console.warn("[e-Okul eklentisi]", e); } planla(); }, DONGU_MS); })(); // v2.5.1: tur aralığı hız profiline göre değişir

  // ---- alert/confirm mesajları (ana_dunya.js'den) ----
  window.addEventListener("message", async (e) => {
    if (e.source !== window || !e.data || e.data.kaynak !== "eokul-eklenti") return;
    const m = e.data.mesaj;
    log(`e-Okul ${e.data.tur} mesajı:`, m.slice(0, 300));
    const d = await oku();
    if (!d || !d.calisiyor) return;
    if (/okul no alan.*b[üu]y[üu]k olamaz/i.test(m) && ["ara", "bekle_ogrenci", "menu"].includes(d.step)) { // v2.3.32: alert biçimi de bir kez yeniden denenir
      const s = d.satirlar[d.idx];
      if (s && s.ara !== "no" && d.tcYenidenIdx !== d.idx) { await gecis(d.adimNo, (x) => { x.tcYenidenIdx = x.idx; x.step = "ara"; x.anahtarSay = 0; }); return; }
      await gecis(d.adimNo, (x) => tcHatali(x, m.slice(0, 120))); return;
    }
    { const s = d.satirlar[d.idx]; // v2.3.32: alert biçimindeki tekrar/çakışma uyarısı (alert ana_dunya.js'de kapanır)
      if (s && s.ara !== "no" && ["kaydet1", "kaydet2", "dogrula"].includes(d.step) && TEKRAR_RE.test(katla(m)) && !/kaydetme islemine devam/.test(katla(m))) { document.documentElement.removeAttribute("data-eokul-otokaydet"); await gecis(d.adimNo, zatenGirilmis); return; } }
    if (/nedeni se[çc]ilmeli|bo[şs] ge[çc]ilemez/i.test(m)) { // v2.3.33: form boş kaydedildi → bir kez yeniden doldur, sonra yalnız bu öğrenci HATA
      document.documentElement.removeAttribute("data-eokul-otokaydet");
      if (d.formYenidenIdx !== d.idx) { log("Form alanları boş görüldü; form yeniden doldurulacak (1 kez)"); await gecis(d.adimNo, (x) => { x.formYenidenIdx = x.idx; x.kaydetPending = null; x.step = "form"; x.denemeSay = 0; x.nedenSay = 0; }); return; }
      await gecis(d.adimNo, (x) => { x.kaydetPending = null; x.kurtar = true; bitir(x, "HATA", "e-Okul: form alanları boş kaldı (" + m.replace(/\s+/g, " ").slice(0, 90) + ")"); }); return;
    }
    const hataMi = /bulunamad|bulunmamakta|geçersiz|hatal|yapılamaz|zorunlu/i.test(m);
    if (hataMi && ["ara", "bekle_ogrenci", "menu"].includes(d.step)) {
      await gecis(d.adimNo, (x) => tcHatali(x, m.slice(0, 120)));
    } else if (hataMi && ["kaydet2", "dogrula"].includes(d.step)) {
      await gecis(d.adimNo, (x) => bitir(x, "HATA", "e-Okul uyarısı: " + m.slice(0, 150)));
    }
  });

  // ---- Adım bekçisi (yalnızca üst çerçevede) ----
  // v2.3.31: toplam çalışma süresi sınırı YOK. Yalnızca tek bir adım 45 sn ilerlemezse O ÖĞRENCİ atlanır, çalışma sıradakiyle sürer.
  // e-Okul gerçekten oturumu kapattıysa (giriş ekranı) çalışma temizce durur, satır HAZIR kalır.
  if (window === window.top) {
    const bekci = setInterval(async () => {
      if (!baglamVar()) { clearInterval(bekci); return; }
      const d = await oku();
      if (!d || !d.calisiyor || d.step === "onay_bekle" || Date.now() - d.stepTs < ADIM_ZAMAN_ASIMI_MS) return;
      if (oturumKapandi()) { await oturumDurdur(d.adimNo); return; }
      if (d.step === "kurtar") return; // ekrana dönüş kendi deneme sınırıyla yürür; öğrenci suçsuz, atlanmaz
      await gecis(d.adimNo, (x) => {
        x.kurtar = true; // sıradaki öğrenci için arama ekranına dön
        if (/^(kaydet1|kaydet2|dogrula)$/.test(x.step)) bitir(x, "HATA", `Yanıt gelmedi, kayıt doğrulanamadı — elle kontrol edin (adım: ${x.step})`);
        else { if (x.satirlar[x.idx]) x.satirlar[x.idx].sari = true; bitir(x, "ATLANDI", `Yanıt gelmedi — atlandı (adım: ${x.step})`); }
      });
    }, 3000);
  }
})();
