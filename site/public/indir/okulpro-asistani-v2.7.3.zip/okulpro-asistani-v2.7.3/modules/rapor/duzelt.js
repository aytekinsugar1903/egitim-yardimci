// v2.3.14: OCR rakam düzeltme (saf fonksiyonlar; tarayıcı + Node testleri).
// Sık OCR hatası: tek rakamın sonuna hücre çizgisi / kalem kuyruğu "0" (bazen "1") olarak eklenir: 1->10, 2->20, 1->11.
// Raporlar çoğunlukla 1-2 gündür; 5 günden uzun okunan değer tarihlerle tutmuyorsa tutan yorum alınır ve satır "kontrol edin" olur.
(function (kok) {
  const GUN_MS = 86400000;
  const takvimGun = (bas, bit) => Math.round((Date.UTC(bit.getFullYear(), bit.getMonth(), bit.getDate()) - Date.UTC(bas.getFullYear(), bas.getMonth(), bas.getDate())) / GUN_MS) + 1;
  // Bir sayının "fazladan rakam" almış olabileceği kısa adaylar (10->1, 20->2, 30->3, 11->1, 111->1, 12->2 değil)
  function kisaAdaylar(n) {
    const s = String(n), r = [];
    if (s.length >= 2 && /0$/.test(s)) r.push(+s.slice(0, -1));          // 10->1, 20->2
    if (/^1{2,}$/.test(s)) r.push(1);                                     // 11/111->1
    if (s.length >= 2 && s[0] === s[1]) r.push(+s.slice(1));              // 22->2, 11->1
    if (s.length === 3) r.push(+s.slice(0, 2), +s.slice(0, 1));
    return [...new Set(r)].filter((x) => x >= 1 && x !== n);
  }
  // Rapor gün sayısını tarihlerle tutarlar. Döner {gun, bas, bit, kontrol, not}
  function raporTutarla(gun, bas, bit) {
    const out = { gun, bas, bit, kontrol: false, not: "" };
    if (!gun && !(bas && bit)) return out;
    // Başlangıç bitişten sonraysa: başlangıç gününde fazladan rakam olabilir (10.10 yerine 1.10)
    if (bas && bit && bas > bit) {
      for (const g of kisaAdaylar(bas.getDate())) { const t = new Date(bas.getFullYear(), bas.getMonth(), g); if (t <= bit && (!gun || takvimGun(t, bit) === gun || kisaAdaylar(gun).includes(takvimGun(t, bit)))) { out.bas = t; out.kontrol = true; out.not = `Başlangıç günü ${bas.getDate()} okundu, ${g} alındı (kontrol edin)`; break; } }
      bas = out.bas;
    }
    if (bas && bit && bas <= bit) {
      const tk = takvimGun(bas, bit);
      if (gun && gun !== tk && kisaAdaylar(gun).includes(tk)) { out.gun = tk; out.kontrol = true; out.not = `Gün sayısı ${gun} okundu, tarihler ${tk} gün diyor: ${tk} alındı (kontrol edin)`; }
      else if (!gun && tk > 5 && tk <= 31) {
        // Bitiş tarihi gününde fazladan rakam (11.10 yerine 1.10 değil; 10.10 yerine 1.10 vb.)
        const a = kisaAdaylar(bit.getDate()).map((g) => new Date(bit.getFullYear(), bit.getMonth(), g)).find((t) => t >= bas && takvimGun(bas, t) <= 2);
        if (a) { out.kontrol = true; out.not = `${tk} günlük aralık şüpheli (bitiş ${bit.getDate()} yerine ${a.getDate()} olabilir), kontrol edin`; }
      }
      return out;
    }
    // Yalnızca gün sayısı var: 5'ten uzun ve kısa yorumu mümkünse kontrol işareti
    if (gun > 5 && kisaAdaylar(gun).some((x) => x <= 5)) { out.kontrol = true; out.not = `Gün sayısı ${gun} okundu; ${kisaAdaylar(gun).filter((x) => x <= 5).join(" veya ")} olabilir, kontrol edin`; }
    if (gun > 30) { out.kontrol = true; out.not = `Gün sayısı ${gun} geçersiz görünüyor, kontrol edin`; }
    return out;
  }
  // Veli izni: bir formdaki tarihler (birbirine yakın okul günleri). Kümeden uzak kalan gün, kısa adayı kümeye düşüyorsa düzeltilir.
  // girdi: [{gun, ay, yil}] -> [{gun, ay, yil, kontrol, not}]
  function veliTarihTutarla(liste, okulGunu = (t) => t.getDay() % 6 !== 0) {
    const tarih = (x, g) => new Date(x.yil, x.ay - 1, g ?? x.gun);
    return liste.map((x, i) => {
      const r = { ...x, kontrol: false, not: "" };
      const t = tarih(x), gecerli = t.getDate() === x.gun && x.gun >= 1;
      const digerleri = liste.filter((_, j) => j !== i).map((y) => tarih(y)).filter((d) => !isNaN(d));
      const uzak = (d) => (digerleri.length ? Math.min(...digerleri.map((o) => Math.abs(d - o) / GUN_MS)) : 0);
      const adaylar = kisaAdaylar(x.gun).filter((g) => tarih(x, g).getDate() === g);
      if (!gecerli && adaylar.length) { r.gun = adaylar[0]; r.kontrol = true; r.not = `Gün ${x.gun} geçersiz, ${adaylar[0]} alındı`; return r; }
      if (!adaylar.length || !digerleri.length) { if (gecerli && !okulGunu(t)) { r.kontrol = true; r.not = "Hafta sonu tarihi, kontrol edin"; } return r; }
      const u0 = uzak(t) + (okulGunu(t) ? 0 : 7);
      const en = adaylar.map((g) => ({ g, u: uzak(tarih(x, g)) + (okulGunu(tarih(x, g)) ? 0 : 7) })).sort((a, b) => a.u - b.u)[0];
      if (u0 > 10 && en.u <= 7) { r.gun = en.g; r.kontrol = true; r.not = `Gün ${x.gun} okundu, diğer tarihlere göre ${en.g} alındı (kontrol edin)`; }
      else if (!okulGunu(t)) { r.kontrol = true; r.not = "Hafta sonu tarihi, kontrol edin"; }
      return r;
    });
  }
  const api = { kisaAdaylar, raporTutarla, veliTarihTutarla, takvimGun };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  kok.OcrDuzelt = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
