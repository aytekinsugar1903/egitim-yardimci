// v2.3.4: "DEVAMSIZLIK VELİ İZİN DİLEKÇE FORMU" tarayıcı içi okuyucu (çevrimdışı Tesseract, en iyi çaba).
// Sayfa = bir öğrenci. Yön bulunur, basılı etiketler (Numarası, İzin Tarihi, /2026, Gün Sayısı) çapa olarak kullanılır,
// el yazısı yalnızca RENKLİ mürekkepten (mavi/mor) okunur. Tarih yanında / gün sayısında "y" veya "0,5" = yarım gün; "T" ya da işaretsiz = tam gün.
(() => {
  const N = (s) => String(s || "").toLocaleUpperCase("tr").replace(/İ/g, "I").replace(/Ş/g, "S").replace(/Ğ/g, "G").replace(/Ü/g, "U").replace(/Ö/g, "O").replace(/Ç/g, "C");
  const ANAHTAR = /IZIN|TARIH|NUMARAS|VELI|OGRENCI|DILEKCE|SAYISI|SINIFI|ADRES/;

  function dondur(src, aci, olcek = 1) {
    const w = Math.round(src.width * olcek), h = Math.round(src.height * olcek), yan = aci % 180 !== 0;
    const c = document.createElement("canvas"); c.width = yan ? h : w; c.height = yan ? w : h;
    const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height);
    x.translate(c.width / 2, c.height / 2); x.rotate((aci * Math.PI) / 180); x.drawImage(src, -w / 2, -h / 2, w, h);
    return c;
  }
  // Kırp + yalnızca renkli mürekkep (basılı siyah metin/nokta silinir). Döndürür {c, sayi}
  function murekkep(src, x0, y0, x1, y1, buyut = 2) {
    x0 = Math.max(0, Math.round(x0)); y0 = Math.max(0, Math.round(y0)); x1 = Math.min(src.width, Math.round(x1)); y1 = Math.min(src.height, Math.round(y1));
    const w = x1 - x0, h = y1 - y0; if (w < 4 || h < 4) return { c: null, sayi: 0 };
    const v = src.getContext("2d").getImageData(x0, y0, w, h), d = v.data; let sayi = 0;
    for (let i = 0; i < d.length; i += 4) {
      const mx = Math.max(d[i], d[i + 1], d[i + 2]), mn = Math.min(d[i], d[i + 1], d[i + 2]);
      const ink = mx - mn > 45 && mn < 200; if (ink) sayi++;
      d[i] = d[i + 1] = d[i + 2] = ink ? 0 : 255; d[i + 3] = 255;
    }
    const t = document.createElement("canvas"); t.width = w; t.height = h; t.getContext("2d").putImageData(v, 0, 0);
    const p = 20, c = document.createElement("canvas"); c.width = w * buyut + 2 * p; c.height = h * buyut + 2 * p;
    const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height); x.imageSmoothingEnabled = true; x.globalCompositeOperation = "darken"; // hafif kalınlaştırma (Tesseract ince kalemi kaçırıyor)
    for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) x.drawImage(t, p + dx * buyut, p + dy * buyut, w * buyut, h * buyut);
    if (globalThis.VELI_DEBUG) VELI_DEBUG.push(c.toDataURL());
    return { c, sayi };
  }
  function egikDuzelt(src, aci) { // v2.3.21: küçük açı, boyut aynı (dondur 90° katları içindir)
    const c = document.createElement("canvas"); c.width = src.width; c.height = src.height; const x = c.getContext("2d");
    x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height); x.translate(c.width / 2, c.height / 2); x.rotate((aci * Math.PI) / 180); x.drawImage(src, -src.width / 2, -src.height / 2); return c;
  }
  function kirpUrl(src, x0, y0, x1, y1) {
    x0 = Math.max(0, x0 | 0); y0 = Math.max(0, y0 | 0); x1 = Math.min(src.width, x1 | 0); y1 = Math.min(src.height, y1 | 0);
    if (x1 - x0 < 2 || y1 - y0 < 2) return "";
    const k = Math.min(1, 360 / (x1 - x0)), c = document.createElement("canvas"); c.width = (x1 - x0) * k; c.height = (y1 - y0) * k;
    c.getContext("2d").drawImage(src, x0, y0, x1 - x0, y1 - y0, 0, 0, c.width, c.height); return c.toDataURL("image/jpeg", 0.8);
  }
  async function oku(w, c, whitelist, psm) {
    await w.setParameters({ tessedit_char_whitelist: whitelist || "", tessedit_pageseg_mode: psm || "3" });
    try { return (await w.recognize(c)).data; } finally { await w.setParameters({ tessedit_char_whitelist: "", tessedit_pageseg_mode: "3" }); }
  }
  // v2.3.21: önce basılı tablo çizgilerinden yatay/dikey ailesi seçilir (formdaki uzun çizgiler yataydır); Tesseract yalnız 0/180 (ya da 90/270) arasında karar verir.
  function cizgiAilesi(canvas) {
    const k = Math.min(1, 800 / Math.max(canvas.width, canvas.height)), W = Math.round(canvas.width * k), H = Math.round(canvas.height * k);
    const c = document.createElement("canvas"); c.width = W; c.height = H; const x = c.getContext("2d", { willReadFrequently: true }); x.drawImage(canvas, 0, 0, W, H);
    const d = x.getImageData(0, 0, W, H).data, k2 = (i) => d[4 * i] < 160 && d[4 * i + 1] < 160 && d[4 * i + 2] < 160;
    // koyu piksellerin satır / sütun izdüşümü keskinliği (eğikliğe dayanıklı: -3..3°); yazı satırları ve tablo çizgileri yatay olan yön kazanır
    const P = []; for (let y = 0; y < H; y += 2) for (let xx = 0; xx < W; xx += 2) if (k2(y * W + xx)) P.push(xx, y);
    const n = P.length / 2; if (n < 200) return null;
    const keskin = (dikey) => { let en = 0; const B = dikey ? W : H;
      for (let a = -3; a <= 3; a += 0.5) { const t = Math.tan(a * Math.PI / 180), h = new Float64Array(2 * (W + H)); let q = 0;
        for (let i = 0; i < P.length; i += 2) { const u = dikey ? P[i] + P[i + 1] * t : P[i + 1] + P[i] * t; const bi = Math.round(u) + W + H; h[bi]++; }
        for (let i = 0; i < h.length; i++) q += h[i] * h[i]; en = Math.max(en, q * B / (n * n)); }
      return en; };
    const yat = keskin(false), dik = keskin(true);
    return yat === dik ? null : yat > dik ? [0, 180] : [90, 270];
  }
  let YON_PUAN = 0; const KIRP_YON = 1;
  async function yonBul(w, canvas) {
    const k = Math.min(1, 1300 / Math.max(canvas.width, canvas.height)); let en = { aci: 0, puan: -1 };
    const aile = cizgiAilesi(canvas), adaylar = aile ? [...aile, ...[90, 270, 0, 180].filter((a) => !aile.includes(a))] : [90, 270, 0, 180];
    for (const [i, aci] of adaylar.entries()) {
      const r = await oku(w, dondur(canvas, aci, k));
      const puan = (r.words || []).filter((x) => x.confidence > 55 && ANAHTAR.test(N(x.text))).length;
      if (puan > en.puan) en = { aci, puan };
      if (aile && i === 1 && en.puan >= 3) break; // çizgi ailesinin iki yönü yeterli
      if (!aile && puan >= 6) break;
    }
    YON_PUAN = en.puan; return en.aci;
  }
  const ust = (b) => b.bbox.y0, alt = (b) => b.bbox.y1, sol = (b) => b.bbox.x0, sag = (b) => b.bbox.x1, yuk = (b) => b.bbox.y1 - b.bbox.y0;

  // v2.3.21: iş parçacığı + sayfa başına süre sınırı
  let ISCI = null, ISCI_NO = 0; const ISCI_SURE = 25000;
  function isciCalistir(img, kel, bugun, tur) {
    if (!ISCI) ISCI = new Worker("veli_isci.js");
    const id = ++ISCI_NO, w = ISCI;
    return new Promise((coz) => {
      const zam = setTimeout(() => { w.terminate(); if (ISCI === w) ISCI = null; coz({ hata: "Sayfa süre sınırını aştı, tablo okunamadı" }); }, ISCI_SURE);
      w.onmessage = (e) => { if (e.data.id !== id) return; clearTimeout(zam); coz(e.data); };
      w.onerror = (e) => { clearTimeout(zam); w.terminate(); if (ISCI === w) ISCI = null; coz({ hata: "Okuyucu hatası: " + (e.message || "bilinmiyor") }); };
      w.postMessage({ id, tur, img, kel: kel.map((k) => ({ n: k.n, text: k.text, bbox: k.bbox })), bugun: bugun ? +bugun : undefined }, [img.data.buffer]);
    });
  }
  let IPTAL = false;
  const RAPOR_GIBI = "Bu sayfa veli izin formuna değil doktor raporuna benziyor — Tür'ü \"Rapor (doktor raporu)\" seçip yeniden okutun";
  // v2.4.2: Yerel Okuma Servisi (yalnız bu bilgisayar, 127.0.0.1) — Okul No şeridi iki modelle okunur; aynı ve ElRakam'la çelişmiyorsa emin,
  // farklıysa numara emin değil (KONTROL). Servis kapalı/hata → ElRakam sonucu aynen. Şerit görüntüleri sonuçtan silinir (kaydedilmez).
  async function yerelNo(f) {
    const hedef = f.ogrenciler && f.ogrenciler.length ? f.ogrenciler : [f], is = hedef.filter((o) => o.noGoruntu && o.no);
    try {
      const s = is.length ? await YerelOkuma.oku(is.map((o) => ({ tur: "no", png: YerelOkuma.png(o.noGoruntu) }))) : null;
      if (s) is.forEach((o, i) => { const b = YerelOkuma.rakamBirlestir(o.no, o.noGuven, s[i], true); if (!b) return;
        const eski = o.noUyari && !/^numara emin değil/.test(o.noUyari) ? o.noUyari : ""; o.no = b.deger; o.noGuven = b.guven;
        o.noUyari = b.emin ? eski : [eski, "numara " + b.not].filter(Boolean).join("; "); });
    } catch (e) { console.warn("yerel okuma servisi kullanılamadı", e && e.message); }
    finally { for (const o of hedef) delete o.noGoruntu; }
  }
  async function sayfaCoz(w, canvas, opt = {}) {
    const ER = globalThis.ElRakam; // v2.3.15: yerel el yazısı rakam modeli (yoksa yalnız Tesseract)
    if (ER && !ER.hazir() && globalThis.chrome && chrome.runtime && chrome.runtime.getURL) { try { ER.yukle(await (await fetch(chrome.runtime.getURL("modules/ortak/okuma/lib/rakam.bin"))).arrayBuffer()); } catch (e) { console.warn("rakam modeli yüklenemedi", e); } }
    const elRakam = ER && ER.hazir();
    const EH = globalThis.ElHarf; // v2.3.38: yerel el yazısı harf modeli (faaliyet adı)
    if (EH && !EH.hazir() && globalThis.chrome && chrome.runtime && chrome.runtime.getURL) { try { EH.yukle(await (await fetch(chrome.runtime.getURL("modules/ortak/okuma/lib/harf.bin"))).arrayBuffer()); } catch (e) { console.warn("harf modeli yüklenemedi", e); } }
    // v2.3.26 (+2.3.27: rakam modeli yüklendikten sonra): önce Evrak Asistanı makine okunur formu (köşe kareleri + dönem kodu); değilse eski okuyucu
    if (globalThis.VeliFormu) { try {
      const id = canvas.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, canvas.width, canvas.height), g = new Uint8Array(canvas.width * canvas.height);
      for (let i = 0, j = 0; i < g.length; i++, j += 4) g[i] = (id.data[j] * 299 + id.data[j + 1] * 587 + id.data[j + 2] * 114) / 1000;
      const yerel = !!(globalThis.YerelOkuma && (await YerelOkuma.hazir())); // v2.4.2: Yerel Okuma Servisi açık ve eşleşmişse numara şeritleri de çıkarılır
      globalThis.YEREL_KIRP = yerel; let f; try { f = VeliFormu.oku(g, canvas.width, canvas.height); } finally { globalThis.YEREL_KIRP = false; }
      if (f && yerel) await yerelNo(f);
      if (f && f.devamsizlik) return { aci: f.aci || 0, devamsizlik: true, ogrenciler: f.ogrenciler, tarihler: [], no: "", sinif: "", ad: "", guven: 95, uyari: [...f.uyari], noKirp: "", form: true }; // v2.5.8: aylık devamsızlık takip formu
      if (f && f.faaliyet && f.surum === 6) { // v2.3.38: toplu/bireysel faaliyet formu + okunan faaliyet adı ve ad bölgesinin görüntüsü
        let adResim = ""; try { const G = f.adGoruntu, c = document.createElement("canvas"); c.width = G.w; c.height = G.h; const cx = c.getContext("2d"), im = cx.createImageData(G.w, G.h);
          for (let i = 0; i < G.d.length; i++) { im.data[4 * i] = im.data[4 * i + 1] = im.data[4 * i + 2] = G.d[i]; im.data[4 * i + 3] = 255; } cx.putImageData(im, 0, 0); adResim = c.toDataURL("image/png"); } catch (e) { adResim = ""; }
        return { aci: f.aci || 0, faaliyet: true, bireysel: f.bireysel, ogrenciler: f.ogrenciler, tarihler: f.tarihler, faAd: f.ad, adResim, no: "", sinif: "", ad: "", guven: 95, uyari: [...f.uyari], noKirp: "", form: true }; }
      if (f && f.faaliyet) return { aci: f.aci || 0, faaliyet: true, ogrenciler: f.ogrenciler, tarihler: f.tarihler, no: "", sinif: "", ad: "", guven: 95, uyari: [...f.uyari], noKirp: "", form: true }; // v2.3.37
      if (f) {
        const uy = [...f.uyari]; if (f.noUyari) uy.push(f.noUyari);
        if (!f.tarihler.length) uy.push("Formda işaretli gün yok");
        return { aci: f.aci || 0, no: f.no, noOlas: f.noOlas, sinif: f.sinif || "", ad: "", tarihler: f.tarihler, guven: f.noGuven >= 0.8 ? 95 : 50, uyari: uy, noKirp: "", form: true };
      }
    } catch (e) { console.warn("makine okunur form okunamadı, eski okuyucu", e); } }
    const aci = await yonBul(w, canvas);
    const c = dondur(canvas, aci);
    const yonUyari = YON_PUAN < 3 ? "Form yazıları okunamadı (ayna görüntüsü, çok soluk ya da başka bir belge olabilir) — kontrol edin" : "";
    // v2.3.21: ızgara (iş parçacığı) Tesseract'ın tam sayfa okumasıyla aynı anda çalışır
    const izP = elRakam && globalThis.Worker ? isciCalistir(c.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, c.width, c.height), [], opt.bugun, "izgara") : null;
    const r = await oku(w, c); const kel = (r.words || []).map((x) => ({ ...x, n: N(x.text) }));
    SON_HAM = { kel: r.words || [] }; // v2.4.3: Liste ayır için bu sayfanın yazı satırları (yalnız bellekte)
    if (globalThis.FaaliyetListe && FaaliyetListe.belgeMi(r.text || "")) { try { // v2.4.3: taranmış faaliyet/izinli öğrenci listesi yazısı (çizgili NUMARA/SINIF/ADI-SOYADI tablosu)
      if (izP) await izP.catch(() => null);
      const id = c.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, c.width, c.height), g = new Uint8Array(c.width * c.height);
      for (let i = 0, j = 0; i < g.length; i++, j += 4) g[i] = (id.data[j] * 299 + id.data[j + 1] * 587 + id.data[j + 2] * 114) / 1000;
      const hucreOku = async (x0, y0, x1, y1, wl, psm) => { const k = y1 - y0 < 48 ? 2 : 1, cc = document.createElement("canvas"); cc.width = (x1 - x0) * k + 24; cc.height = (y1 - y0) * k + 24;
        const cx = cc.getContext("2d"); cx.fillStyle = "#fff"; cx.fillRect(0, 0, cc.width, cc.height); cx.imageSmoothingEnabled = true; cx.drawImage(c, x0, y0, x1 - x0, y1 - y0, 12, 12, (x1 - x0) * k, (y1 - y0) * k);
        const t = await oku(w, cc, wl, psm); return { text: t.text || "", confidence: t.confidence || 0 }; };
      const fl = await FaaliyetListe.oku({ g, w: c.width, h: c.height, kel: r.words || [], metin: r.text || "", ocr: hucreOku });
      if (fl && SON_HAM) SON_HAM.hucreler = fl.hucreler;
      if (fl && fl.ogrenciler.length) return { aci, faaliyet: true, liste: true, ogrenciler: fl.ogrenciler, tarihler: fl.tarihler, faAd: fl.faAd || null, no: "", sinif: "", ad: "", guven: 95, uyari: [...fl.uyari], noKirp: "", form: false };
    } catch (e) { console.warn("faaliyet listesi okunamadı, eski okuyucu", e); } }
    const uyari = yonUyari ? [yonUyari] : []; let guvenler = [];
    // v2.3.16: masaüstü okuyucunun hücre düzeni + yerel rakam modeli (başarısızsa eski yol)
    let L = null;
    // v2.3.21: hücre düzeni + ızgara + rakam modeli ayrı iş parçacığında (arayüz donmaz); süre sınırı aşılırsa eski yol + "kontrol edin"
    if (elRakam && globalThis.Worker) {
      const sonuc = await izP; let L0 = null;
      if (globalThis.VELI_AYIKLA) console.log("veli ayıkla", JSON.stringify({ aci, w: c.width, h: c.height, hata: sonuc.hata, tablo: sonuc.Z && sonuc.Z.tablo, egim: sonuc.Z && sonuc.Z.aci, n: sonuc.Z && sonuc.Z.tarihler.length }));
      if (!sonuc.hata && !(sonuc.Z && sonuc.Z.tablo)) { const s2 = await isciCalistir(c.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, c.width, c.height), kel, opt.bugun, "oku"); if (s2.hata) uyari.push(s2.hata + " — kontrol edin"); else L0 = s2.L; }
      if (sonuc.hata) uyari.push(sonuc.hata + " — kontrol edin");
      else { const { Z } = sonuc; L = L0;
        const say = (x) => (x && x.tarihler ? x.tarihler.filter((t) => t.tarih).length : 0);
        const tarihGeri = (x) => { if (x && x.tarihler) for (const t of x.tarihler) if (t.tarih && !(t.tarih instanceof Date)) t.tarih = new Date(t.tarih); };
        tarihGeri(Z); tarihGeri(L);
        if (Z && Z.tablo && (!L || !L.tablo || say(Z) >= say(L))) { const eski = L; L = { ...(eski || {}), tablo: true, tarihler: Z.tarihler, izgara: true, aci: Z.aci }; if (!eski || !eski.no || eski.noGuven < Z.noGuven) { L.no = Z.no; L.noGuven = Z.noGuven; L.noAday = Z.noAday; } }
        else if (L && Z && Z.no && (!L.no || L.noGuven < Z.noGuven)) { L.no = Z.no; L.noGuven = Z.noGuven; } }
    }
    // --- Sınıfı/Numarası ---
    let no = "", sinif = "", noKirp = "";
    const lab = kel.find((x) => /NUMARAS/.test(x.n));
    const raporGibi = !lab && kel.filter((x) => /RAPOR|HEKIM|HASTANE|TANI\b|KIMLIK/.test(x.n)).length >= 2; // v2.3.34: Tür yanlış seçildiyse (doktor raporu veli modunda) açık uyarı
    if (raporGibi) uyari.unshift(RAPOR_GIBI);
    if (lab) {
      const lh = Math.max(12, yuk(lab)), solx = Math.min(sol(lab), ...kel.filter((x) => /SINIF/.test(x.n) && Math.abs(ust(x) - ust(lab)) < lh).map(sol));
      const sagKom = kel.filter((x) => /IZIN|ISTEG/.test(x.n) && Math.abs(ust(x) - ust(lab)) < lh && sol(x) > sag(lab)).map(sol);
      const x1 = sagKom.length ? Math.min(...sagKom) - 4 : sag(lab) + 8 * lh;
      const m = murekkep(c, solx - lh, ust(lab) - 0.3 * lh, x1, alt(lab) + 3.2 * lh);
      noKirp = kirpUrl(c, solx - lh, ust(lab) - 0.3 * lh, x1, alt(lab) + 3.2 * lh);
      if (m.c && m.sayi > 30) {
        const t = await oku(w, m.c, "0123456789-/ABCDEFGHIJKLMNOPRSTUVYZ", "7");
        const s = N(t.text).replace(/\s+/g, " ").trim(); guvenler.push(t.confidence);
        const sm = s.match(/\b(9|1[0-2])\s*[-\/ ]?\s*([A-Z])\b/); if (sm) sinif = `${sm[1]}-${sm[2]}`;
        const nos = (s.replace(/\b(9|1[0-2])\s*[-\/ ]?\s*[A-Z]\b/, " ").match(/\d{3,5}/g) || []);
        no = nos.length ? nos[nos.length - 1] : "";
        if (L && L.no && (L.noGuven >= 0.5 || !no)) { if (L.noGuven < 0.6) uyari.push(`Numara emin değil (model ${L.no}${no && no !== L.no ? ", Tesseract " + no : ""})`); no = L.no; }
        if (!no) uyari.push(`Numara okunamadı ("${s}")`);
        else if (t.confidence < 70) uyari.push("Numara emin değil");
      } else uyari.push("Numara alanı boş görünüyor");
    } else if (L && L.no) { no = L.no; uyari.push(`Numara etiketi okunamadı, tablodan okundu (${L.no}) — kontrol edin`); } // v2.3.21
    else uyari.push("Form tanınamadı (Numarası etiketi yok)");
    // --- Ad soyad (en iyi çaba) ---
    let ad = "";
    const adl = kel.find((x) => /^ADI$/.test(x.n) || /SOYAD/.test(x.n));
    if (adl && lab) {
      const lh = Math.max(12, yuk(adl));
      const m = murekkep(c, sol(adl) - lh, alt(adl), sol(lab) - 4, alt(adl) + 3 * lh);
      if (m.c && m.sayi > 30) ad = (await oku(w, m.c, "", "7")).text.replace(/[^A-Za-zÇĞİÖŞÜçğıöşü ]/g, " ").replace(/\s+/g, " ").trim();
    }
    // --- İzin tarihleri ---
    const izinEt = kel.filter((x) => /IZIN/.test(x.n) && kel.some((y) => /TARIH/.test(y.n) && Math.abs(ust(y) - ust(x)) < yuk(x) && sol(y) > sol(x)));
    const tabloUst = izinEt.length ? Math.min(...izinEt.map(alt)) : (lab ? alt(lab) : 0);
    const gunEt = kel.filter((x) => /SAYISI|^GUN$/.test(x.n) && ust(x) >= tabloUst - 3 * yuk(x) && ust(x) <= tabloUst + yuk(x));
    // Sütunlar: her "İzin Tarihi" etiketi bir tarih sütunu; sağındaki ilk "Gün Sayısı" o satırın gün hücresi.
    const yilK = kel.find((x) => /20\d\d/.test(x.n) && ust(x) > tabloUst);
    const yil = yilK ? +yilK.n.match(/20\d\d/)[0] : (opt.yil || new Date().getFullYear());
    const tarihler = [];
    const sutunlar = izinEt.sort((a, b) => sol(a) - sol(b));
    const duzenOk = !!(L && L.tablo && L.tarihler.length);
    const kc = duzenOk && L.izgara && L.aci ? egikDuzelt(c, KIRP_YON * L.aci) : c; // v2.3.21: ızgara kutuları eğiklik düzeltilmiş görüntüde
    if (duzenOk) for (const hc of L.tarihler) {
      const k = hc.kutu, kirp = kirpUrl(kc, k.dx0, k.y0 - 6, k.gx1, k.y1 + 6);
      if (!hc.tarih) { tarihler.push({ tarih: "", yarim: false, guven: 0, ham: (hc.ham || "") + (hc.not ? " · " + hc.not : ""), kirp }); continue; }
      let isaret = "";
      if (hc.isaretVar) { const gm = murekkep(c, k.dx0 + (k.gx0 - k.dx0) * 0.6, k.y0, k.gx1, k.y1, 3); if (gm.c && gm.sayi > 25) isaret = (await oku(w, gm.c, "0123456789,.yYtT", "7")).text.trim(); }
      const yarimT = /y|0\s*[,.]\s*5|^\s*[,.]?5\s*$/i.test(isaret), yarim = hc.gunSay === 0.5 || (yarimT && (hc.gunSayGuven || 0) < 0.85); // model gün sayısını eminse Tesseract'ın tek harfi değiştirmez
      if (yarimT && hc.gunSay !== 0.5 && hc.supheli === false) { hc.supheli = undefined; hc.not = "gün sayısı (0,5 / 1) iki okumada farklı, kontrol edin"; } // v2.3.22
      const t = hc.tarih, g = Math.round(100 * hc.guven), gun = yarim ? 0.5 : (hc.gunSay || 1);
      tarihler.push({ tarih: `${String(t.getDate()).padStart(2, "0")}/${String(t.getMonth() + 1).padStart(2, "0")}/${t.getFullYear()}`, yarim, guven: g, kirp,
        gun, ham: `model ${hc.ham}${isaret ? " | " + isaret : ""} | gün sayısı ${hc.gunSayHam || "boş"}`, not: hc.supheli === false ? "" : (hc.not ? hc.not + (/kontrol edin/.test(hc.not) ? "" : " (kontrol edin)") : "rakam okuması emin değil (kontrol edin)"), supheli: hc.supheli !== false }); // v2.3.22
      guvenler.push(g);
    }
    if (!duzenOk) for (let si = 0; si < sutunlar.length; si++) {
      const e = sutunlar[si], h = Math.max(14, yuk(e));
      const gs = gunEt.filter((g) => sol(g) > sag(e)).sort((a, b) => sol(a) - sol(b))[0];
      const sonraki = sutunlar[si + 1];
      const dx0 = sol(e) - 0.6 * h, dx1 = gs ? sol(gs) - 0.2 * h : sag(e) + 3 * h;
      const gx1 = gs ? (sonraki ? Math.min(sol(sonraki) - 0.2 * h, sag(gs) + 1.5 * h) : sag(gs) + 1.5 * h) : dx1 + 3 * h;
      const y0 = alt(e) + 0.1 * h, y1 = Math.min(c.height, alt(e) + 14 * h);
      // satır bulma: tarih + gün bölgesindeki mürekkebin yatay izdüşümü
      const X0 = Math.max(0, Math.round(dx0)), X1 = Math.min(c.width, Math.round(gx1)), Y0 = Math.round(y0), Y1 = Math.round(y1);
      if (X1 - X0 < 5 || Y1 - Y0 < 5) continue;
      // satırlar: basılı yatay tablo çizgileri (koyu gri, sütun genişliğinin %45'inden uzun)
      const v = c.getContext("2d").getImageData(X0, Y0, X1 - X0, Y1 - Y0).data, W = X1 - X0, cizgi = [];
      for (let y = 0; y < Y1 - Y0; y++) { let k = 0; for (let x = 0; x < W; x++) { const i = (y * W + x) * 4, mx = Math.max(v[i], v[i + 1], v[i + 2]), mn = Math.min(v[i], v[i + 1], v[i + 2]); if (mx < 190 && mx - mn < 60) k++; } cizgi.push(k); }
      const pk = cizgi.map((k, y) => Math.max(k, cizgi[y - 1] || 0, cizgi[y + 1] || 0) + Math.min(k, Math.max(cizgi[y - 1] || 0, cizgi[y + 1] || 0))); // hafif eğik çizgi iki piksel satırına yayılır
      for (let y = 0; y < cizgi.length; y++) cizgi[y] = pk[y] > 0.3 * W;
      const ys = [0]; let bas = -1;
      for (let y = 0; y <= cizgi.length; y++) { if (y < cizgi.length && cizgi[y]) { if (bas < 0) bas = y; } else if (bas >= 0) { ys.push((bas + y) >> 1); bas = -1; } }
      const bantlar = [];
      for (let i = 1; i < ys.length; i++) if (ys[i] - ys[i - 1] > 0.8 * h) bantlar.push([ys[i - 1] - 0.25 * h, ys[i] + 0.15 * h]);
      if (ys.length < 3) uyari.push("Tablo çizgileri bulunamadı");
      for (const [b0, b1] of bantlar) {
        const ry0 = Y0 + b0, ry1 = Y0 + b1;
        if (b1 - b0 > 3.5 * h) break; // tablonun altı
        const dm = murekkep(c, dx0, ry0, dx1, ry1, 3);
        if (!dm.c || dm.sayi < 25) continue;
        const t = await oku(w, dm.c, "0123456789./yYtT", "7");
        const s = t.text.replace(/\s+/g, " ").trim();
        let sayi = s.match(/\d+/g) || [];
        if (sayi.length === 1 && sayi[0].length >= 3) sayi = [sayi[0].slice(0, sayi[0].length - 2), sayi[0].slice(-2)];
        let gun = +sayi[0], ay = +sayi[1];
        const kirp = kirpUrl(c, dx0, ry0, gx1, ry1);
        let er = null; // v2.3.15: el yazısı rakam modeli; güven düşükse Tesseract sonucu kalır
        if (elRakam) { const sh = ry1 - ry0, mk = ER.maskeAl(c, dx0, ry0 - sh, dx1, ry1 + sh), ofs = Math.round(ry0 - sh) < 0 ? Math.round(ry0) : Math.round(sh); er = mk && ER.tarihOku(mk, sh, { yil: opt.yil, bugun: opt.bugun, oy0: ofs, oy1: ofs + sh }); }
        const tessGecerli = gun >= 1 && gun <= 31 && ay >= 1 && ay <= 12;
        if (er && er.gun && (er.guven >= 35 || (!tessGecerli && er.guven >= 10) || (tessGecerli && er.guven > t.confidence / 4))) { gun = er.gun; ay = er.ay; } // Tesseract geçersizse düşük güvenli model sonucu (sarı satır) gösterilir
        if (!(gun >= 1 && gun <= 31 && ay >= 1 && ay <= 12)) { // okunamadı: sarı satır olarak göster (iptal/çizikse − ile çıkarın)
          if (sayi.length) tarihler.push({ tarih: "", yarim: false, guven: 0, ham: s, kirp });
          continue;
        }
        const gm = murekkep(c, dx1, ry0, gx1, ry1, 3);
        let isaret = /[yY]\s*$/.test(s) ? "y" : "";
        if (gm.c && gm.sayi > 25) { const gt = await oku(w, gm.c, "0123456789,.yYtT", "7"); isaret += " " + gt.text.trim(); }
        const yarim = /y|0\s*[,.]\s*5|^\s*[,.]?5\s*$/i.test(isaret.trim());
        tarihler.push({ tarih: `${String(gun).padStart(2, "0")}/${String(ay).padStart(2, "0")}/${er && er.gun === gun && er.ay === ay ? er.yil : yil}`, yarim, guven: Math.round(er && er.gun === gun && er.ay === ay ? Math.max(er.guven, t.confidence) : t.confidence), kirp, ham: (er && er.ham ? "model " + er.ham + " · tess " : "") + s + (isaret.trim() ? " | " + isaret.trim() : "") });
        guvenler.push(er && er.gun === gun && er.ay === ay ? Math.max(er.guven, t.confidence) : t.confidence);
      }
    }
    if (!tarihler.length) uyari.push("Tarih bulunamadı");
    // v2.3.14: 1->10 / 2->20 / 1->11 OCR hatası: tarihleri birbirine ve okul günlerine göre tutarla
    if (globalThis.OcrDuzelt) {
      const ok = tarihler.filter((t) => t.tarih), d = OcrDuzelt.veliTarihTutarla(ok.map((t) => { const [g, a, y] = t.tarih.split("/").map(Number); return { gun: g, ay: a, yil: y }; }));
      ok.forEach((t, i) => { if (d[i].kontrol) { t.tarih = `${String(d[i].gun).padStart(2, "0")}/${String(d[i].ay).padStart(2, "0")}/${d[i].yil}`; t.not = d[i].not + ` [ham: ${t.ham}]`; t.guven = Math.min(t.guven, 60); } });
    }
    const tek = [...new Map(tarihler.map((t, i) => [t.tarih || "?" + i, t])).values()].sort((a, b) => a.tarih.split("/").reverse().join().localeCompare(b.tarih.split("/").reverse().join()));
    // v2.3.20: gün sayısı (tarihten başlayarak N okul günü) sonraki yazılı tarihle çakışıyorsa tarihlerle tutarlı değer alınır
    const isg = (a, b) => { let n = 0; const d = new Date(a); while (d < b) { if (d.getDay() % 6) n++; d.setDate(d.getDate() + 1); } return n; };
    const tc = (s) => { const [g, a, y] = s.split("/").map(Number); return new Date(y, a - 1, g); };
    tek.forEach((t, i) => { if (!t.tarih || !(t.gun > 1)) return; const sonraki = tek.slice(i + 1).find((u) => u.tarih); if (!sonraki) return;
      const bos = isg(tc(t.tarih), tc(sonraki.tarih)); if (bos >= 1 && bos < t.gun) { t.not = [t.not, `gün sayısı ${t.gun} sonraki tarihle (${sonraki.tarih}) çakışıyor, ${bos} alındı — kontrol edin`].filter(Boolean).join(", "); t.gun = bos; t.guven = Math.min(t.guven, 60); } });
    const guven = guvenler.length ? Math.round(Math.min(...guvenler)) : 0;
    return { aci, no, sinif, ad, tarihler: tek, guven, uyari, noKirp };
  }

  // ---- Arayüz (tarama.html, Tür = Veli izni formu) ----
  let SAT = [], SON_HAM = null; const HAM = []; // v2.4.3: HAM = sayfa başına satır/sütun önerisi (Liste ayır)
  const $ = (s) => document.querySelector(s);
  // v2.4.9: bir satırdaki yanlış okul numarası düzeltilince AYNI (yanlış) numaralı diğer satırlar da değişir (aynı öğrencinin birçok formu aynı yanlış numarayla okunur); "Geri al" hepsini döndürür.
  // Faaliyet ve veli izni satırları ayrı tutulur; numara boşluklu yazılmış olsa da (55 83) eşleşir. Etkilenen satırlar yeşil çerçeveyle işaretlenir.
  let NO_GERI = null, NO_YAYILAN = new Set();
  function noNot(m, geri) {
    let n = $("#veliNoNotu"); const t = $("#veliTablo");
    if (!m) { if (n) n.remove(); return; }
    if (!n) { n = document.createElement("div"); n.id = "veliNoNotu"; n.style.cssText = "margin:6px 0;font-weight:bold;color:#166534"; t.parentNode.insertBefore(n, t); }
    n.textContent = m + " ";
    if (geri) { const b = document.createElement("button"); b.type = "button"; b.textContent = "Geri al"; b.onclick = () => { const g = NO_GERI; if (!g) return; const k = (v) => String(v || "").replace(/\D/g, ""); let say = 0;
      g.satirlar.forEach((x) => { if (SAT.includes(x) && k(x.no) === k(g.yeni)) { x.no = g.eski; say++; } }); NO_GERI = null; NO_YAYILAN = new Set(); ciz(); noNot(say + " satır geri alındı."); }; n.appendChild(b); }
  }
  function noYay(s, eskiHam) {
    const k = (v) => String(v || "").replace(/\D/g, ""), eski = k(eskiHam), yeni = k(s.no);
    if (eski === yeni) return; // gerçek değişiklik yok (ör. ikinci change olayı): önceki bilgi notu / Geri al durumu bozulmasın
    NO_YAYILAN = new Set(); NO_GERI = null;
    if (!eski || !yeni) { noNot(""); return; }
    const es = SAT.filter((x) => x !== s && k(x.no) === eski && !!x.faaliyet === !!s.faaliyet);
    es.forEach((x) => { x.no = s.no; x.noUyari = ""; NO_YAYILAN.add(x); });
    if (es.length) { NO_GERI = { eski: String(eskiHam).trim(), yeni: s.no, satirlar: [s, ...es] }; noNot(`${es.length + 1} satırda okul no ${String(eskiHam).trim()} → ${s.no} olarak değişti (aynı numaralı ${es.length} satır da güncellendi).`, true); }
    else noNot("");
  }
  // ---- v2.5.0: öğrenci listesiyle okul numarası doğrulama (liste yalnız bu cihazda; bkz. ogr_liste.js) ----
  const LISTE_AYAR = { delta: 1.5, marj: 0.7, kapi: 0.6 }, dg = (v) => String(v || "").replace(/\D/g, "");
  function listeDurum(s) { // null: liste yok / faaliyet satırı
    if (!globalThis.OgrListe || !OgrListe.hazirMi() || s.faaliyet || !dg(s.no)) return null;
    const k = OgrListe.bul(s.no); if (k) return { tur: s.listeDuzelti && dg(s.listeDuzelti.yeni) === dg(s.no) ? "duzeltildi" : "var", kayit: k };
    const ol = s.noOlas && s.noOkunan && dg(s.noOkunan) === dg(s.no) ? s.noOlas : null; return { tur: "yok", adaylar: OgrListe.adaylar(s.no, ol, {}) };
  }
  function listeNot() {
    const t = $("#veliTablo"); let n = $("#veliListeNotu"); const duz = SAT.filter((x) => x.listeDuzelti);
    if (!duz.length) { if (n) n.remove(); return; }
    if (!n) { n = document.createElement("div"); n.id = "veliListeNotu"; n.style.cssText = "margin:6px 0;font-weight:bold;color:#b45309"; t.parentNode.insertBefore(n, t); }
    n.textContent = `${duz.length} satırın okul numarası öğrenci listesine göre düzeltildi (turuncu bilgiler; formdaki el yazısıyla karşılaştırın). `;
    const b = document.createElement("button"); b.type = "button"; b.textContent = "Hepsini geri al"; b.onclick = () => { SAT.forEach((x) => { if (x.listeDuzelti) { x.no = x.listeDuzelti.eski; delete x.listeDuzelti; x.listeGeri = true; } }); ciz(); }; n.appendChild(b);
  }
  function listeUygula() { // tarama bitince / liste yüklenince: yalnız BELİRGİN hataları düzeltir (okuyucu o hanelerde zaten emin değildi); her düzeltme görünür ve geri alınabilir
    if (!globalThis.OgrListe || !OgrListe.hazirMi()) return 0; let say = 0;
    for (const s of SAT) { if (s.faaliyet || s.listeGeri || s.listeDuzelti || !s.noOlas || !s.noOkunan || dg(s.no) !== dg(s.noOkunan) || OgrListe.bul(s.no)) continue;
      const k = OgrListe.karar(s.no, s.noOlas, LISTE_AYAR); if (k) { s.listeDuzelti = { eski: s.no, yeni: k.no }; s.no = k.no; s.noUyari = ""; say++; } }
    return say;
  }
  function noListeBilgi(td, s) {
    const d = listeDurum(s); if (!d) return; const b = document.createElement("div"); b.style.cssText = "font-size:.82em;margin-top:3px;line-height:1.3";
    if (d.tur === "yok") { b.style.color = "#b91c1c"; b.append("⚠ Listede yok" + (d.adaylar.length ? " — önerilen: " : ""));
      d.adaylar.forEach((a) => { const c = document.createElement("button"); c.type = "button"; c.style.cssText = "margin:1px 3px 1px 0;padding:1px 6px;border:1px solid #b91c1c;border-radius:10px;background:#fff;cursor:pointer;font-size:.95em";
        c.textContent = `${a.no}${a.kayit.a ? " " + a.kayit.a : ""}${a.kayit.s ? " · " + a.kayit.s : ""}`; c.title = "Bu numarayı kullan (aynı yanlış numaralı satırlar da değişir)";
        c.onclick = () => { const eski = String(s.no || ""); s.no = a.no; s.noUyari = ""; delete s.listeDuzelti; s.listeGeri = true; noYay(s, eski); ciz(); }; b.append(c); }); }
    else { b.style.color = d.tur === "var" ? "#166534" : "#b45309"; b.append((d.tur === "duzeltildi" ? "↻ Listeye göre düzeltildi: " : "✓ ") + (d.kayit.a || "") + (d.kayit.s ? " · " + d.kayit.s : ""));
      if (d.tur === "duzeltildi") { const g = document.createElement("button"); g.type = "button"; g.style.cssText = "margin-left:6px;padding:0 6px;cursor:pointer"; g.textContent = "↶ " + s.listeDuzelti.eski; g.title = "Okunan numaraya dön"; g.onclick = () => { s.no = s.listeDuzelti.eski; delete s.listeDuzelti; s.listeGeri = true; ciz(); }; b.append(g); } }
    td.append(b);
  }
  function listeOzet() {
    const t = $("#veliTablo"); let n = $("#veliListeOzet"); if (!globalThis.OgrListe || !OgrListe.hazirMi() || !SAT.length) { if (n) n.remove(); return; }
    const yok = SAT.filter((x) => !x.faaliyet && x.no && !OgrListe.bul(x.no)).length; if (!n) { n = document.createElement("div"); n.id = "veliListeOzet"; n.style.cssText = "margin:4px 0;font-size:.92em"; t.parentNode.insertBefore(n, t); }
    n.textContent = yok ? `Öğrenci listesinde olmayan okul numarası: ${yok} satır (kırmızı).` : "Tüm okul numaraları öğrenci listesinde var."; n.style.color = yok ? "#b91c1c" : "#166534";
  }
  function ciz() {
    const t = $("#veliTablo"); t.innerHTML = ""; listeNot(); listeOzet();
    t.insertRow().innerHTML = "<th></th><th>Güven</th><th>Önizleme</th><th>Okunan alan</th><th>Okul No</th><th>Ad Soyad</th><th>Tarih</th><th>Gün</th><th>Nedeni</th><th>Açıklama</th><th>Uyarı</th><th>Sayfa</th>";
    SAT.forEach((s, i) => {
      const tr = t.insertRow(); if (NO_YAYILAN.has(s)) tr.style.outline = "2px solid #16a34a"; const zayif = !s.elle && (s.guven < 70 || s.uyari || !/^\d{3,5}$/.test(s.no) || !/^\d\d\/\d\d\/\d{4}$/.test(s.bas)); if (zayif) tr.className = "kontrol"; { const ld = listeDurum(s); if (ld && ld.tur === "yok") tr.className = "kontrol"; }
      const sil = document.createElement("button"); sil.className = "ico ico-del"; sil.textContent = "−"; sil.title = "Listeden çıkar";
      sil.onclick = () => { SAT.splice(i, 1); ciz(); }; tr.insertCell().append(sil);
      tr.insertCell().textContent = s.elle ? "elle" : "%" + (s.guven || 0);
      const ic = tr.insertCell(); if (s.jpeg) { const im = document.createElement("img"); im.src = s.jpeg; im.className = "onizle"; im.onclick = () => { $("#buyuk img").src = im.src; $("#buyuk").style.display = "flex"; }; ic.append(im); } else ic.textContent = "—";
      const kc = tr.insertCell(); for (const u of [s.noKirp, s.kirp]) if (u) { const im = document.createElement("img"); im.src = u; im.style.cssText = "display:block;max-width:240px;border:1px solid #ccc;margin:1px"; kc.append(im); }
      for (const k of ["no", "adsoyad", "bas"]) { const inp = document.createElement("input"); inp.value = s[k] || ""; inp.onchange = () => { const eskiNo = k === "no" ? String(s.no || "") : ""; s[k] = k === "bas" ? (globalThis.RaporYardim ? RaporYardim.tarihNormal(inp.value) : inp.value.trim()) : inp.value.trim(); s.elle = s.elle || false; s.uyari = ""; if (k === "no") { s.noUyari = ""; delete s.listeDuzelti; s.listeGeri = true; noYay(s, eskiNo); } ciz(); }; if (k === "no" && s.noUyari) { inp.style.cssText = "background:#ffe08a;border:2px solid #b45309"; inp.title = s.noUyari; } { const hc0 = tr.insertCell(); hc0.append(inp); if (k === "no") noListeBilgi(hc0, s); } } // v2.3.22: numara şüphesi yalnız numara kutusunda
      { // v2.3.20: gün sayısı +/− (0,5 = yarım gün; 1..9 = bu tarihten başlayarak gün)
        const gc = tr.insertCell(), adim = [0.5, 1, 2, 3, 4, 5, 6, 7, 8, 9], deg = () => (s.yarim ? 0.5 : s.gun || 1);
        const eks = document.createElement("button"), art = document.createElement("button"), sp = document.createElement("b");
        eks.textContent = "−"; art.textContent = "+"; eks.title = "Gün sayısını azalt"; art.title = "Gün sayısını artır"; sp.style.cssText = "display:inline-block;min-width:2.4em;text-align:center";
        const yaz = () => { const v = deg(); sp.textContent = v === 0.5 ? "0,5" : String(v); };
        const kay = (k) => { const i = Math.max(0, Math.min(adim.length - 1, adim.indexOf(deg()) + k)); s.gun = adim[i]; s.yarim = s.gun === 0.5; yaz(); };
        eks.onclick = () => kay(-1); art.onclick = () => kay(1); yaz(); gc.append(eks, sp, art); }
      for (const k of ["neden", "aciklama"]) { const inp = document.createElement("input"); inp.value = s[k] || ""; inp.onchange = () => { s[k] = inp.value.trim(); }; const hc = tr.insertCell(); hc.append(inp);
        if (k === "aciklama" && s.grup) { // v2.3.38: faaliyet adı — formdaki el yazısının görüntüsü yanında; düzeltme aynı formun tüm satırlarına geçer, KONTROL uyarısı kalkar
          if (s.grup.adKontrol) { inp.style.cssText = "background:#ffe680;border:2px solid #b45309;font-weight:bold"; inp.title = s.grup.adKontrol; }
          inp.onchange = () => { const yeni = inp.value.trim(); for (const x of SAT) if (x.grup === s.grup) x.aciklama = yeni; s.grup.adKontrol = ""; ciz(); };
          if (s.grup.adResim) { const im = document.createElement("img"); im.src = s.grup.adResim; im.alt = "Formdaki faaliyet adı"; im.style.cssText = "display:block;max-width:340px;border:1px solid #333;margin-top:2px"; hc.append(im); } } }
      tr.insertCell().textContent = [s.grup && s.grup.adKontrol, s.uyari, s.noUyari ? "Sayfa/numara: " + s.noUyari : ""].filter(Boolean).join(" | "); tr.insertCell().textContent = s.sayfa || "";
    });
  }
  async function varsayilan() { const a = (await chrome.storage.local.get("ayar")).ayar || {}; const o = { neden: a.veliNeden || "İzinli", aciklama: a.veliAciklama || "Veli izni" };
    Object.defineProperties(o, { faaliyetNeden: { value: a.faaliyetNeden || "Faaliyet" }, faaliyetAciklama: { value: a.faaliyetAciklama || "Faaliyet" } }); return o; } // v2.3.37: faaliyet varsayılanları (satırlara yayılmaz)
  async function tara({ dosyalar, isci, sayfalarUret, durum }) {
    const v = await varsayilan();
    try { const fa = (await chrome.storage.local.get("faaliyetAdlari")).faaliyetAdlari; globalThis.FAALIYET_ADLARI = [...(globalThis.ElHarf ? ElHarf.VARSAYILAN_ADLAR : []), ...(Array.isArray(fa) ? fa : [])]; } catch (e) { globalThis.FAALIYET_ADLARI = null; } SAT = []; let n = 0; IPTAL = false; // v2.3.38: yerel faaliyet adı listesi
    for (const f of dosyalar) { if (IPTAL) break;
      let sayfalar; try { sayfalar = await sayfalarUret(f); } catch (e) { console.warn("dosya açılamadı", f.name, e); SAT.push({ no: "", adsoyad: "", bas: "", yarim: false, ...v, guven: 0, uyari: `${(e && e.message) ? e.message : "Dosya açılamadı (bozuk ya da desteklenmeyen dosya)"}: ${f.name}`, sayfa: f.name }); n++; continue; } // v2.3.21: bozuk dosya tüm taramayı durdurmasın
      for (const s of sayfalar) {
        if (IPTAL) break;
        n++; const sayfa = `${s.dosya} s.${s.sayfaNo}`;
        if (s.hata) { SAT.push({ no: "", adsoyad: "", bas: "", yarim: false, ...v, guven: 0, uyari: s.hata, sayfa }); continue; }
        durum.textContent = `${n}. sayfa okunuyor: ${sayfa} (veli izni formu)... Durdurmak için İptal'e basın.`; ciz();
        const tt = /(20\d\d)(\d\d)(\d\d)\d{6}/.exec(s.dosya || ""), taramaT = tt && +tt[2] >= 1 && +tt[2] <= 12 ? new Date(+tt[1], +tt[2] - 1, +tt[3]) : undefined; // v2.3.22: tarayıcı dosya adındaki tarama tarihi (ör. doc...20261020103126)
        SON_HAM = null; let r; try { r = await RaporYardim.zamanAsimi(sayfaCoz(isci, s.canvas, taramaT ? { bugun: taramaT } : {}), 400000, "OCR"); } catch (e) { r = { no: "", ad: "", tarihler: [], guven: 0, uyari: ["OCR hatası: " + (e.message || e)] }; }
        const jpeg = (() => { const k = Math.min(1, 900 / Math.max(s.canvas.width, s.canvas.height)); return dondur(s.canvas, r.aci || 0, k).toDataURL("image/jpeg", 0.7); })();
        const uy = r.uyari.join(" | ");
        if (globalThis.ListeAyir) HAM.push({ sayfa, faaliyet: !!r.faaliyet, tarih: (r.liste && r.tarihler[0] && r.tarihler[0].tarih) || "", satirlar: SON_HAM ? (SON_HAM.hucreler || ListeAyir.satirlardan(SON_HAM.kel)) : [] }); SON_HAM = null;
        if (r.devamsizlik) { // v2.5.8: devamsızlık takip formu — her öğrenci × her gün bir satır; Aktar'da yoklama metnine dönüşür (e-Okul özürlü girişine gitmez)
          const dv = { ...v, neden: "Devamsızlık", aciklama: "Devamsızlık (yoklama metni)", devamsizlik: true };
          if (!r.ogrenciler.length || !r.ogrenciler.some((o) => (o.tarihler || []).length)) SAT.push({ no: "", adsoyad: "", bas: "", yarim: false, ...dv, guven: 0, uyari: uy || "Devamsızlık formu boş", sayfa, jpeg });
          for (const o of r.ogrenciler) for (const t of o.tarihler || []) SAT.push({ no: o.no, adsoyad: "", bas: t.tarih, yarim: t.yarim, gun: t.yarim ? 0.5 : 1, ...dv, guven: Math.min(t.guven, o.noGuven >= 0.8 ? 95 : 50), uyari: [t.not, uy].filter(Boolean).join(" | "), noUyari: o.noUyari, sayfa: sayfa + " satır " + o.satir, jpeg });
          delete s.canvas; continue;
        }
        if (r.faaliyet) { // v2.3.37: faaliyet formu — her öğrenci × her tarih bir satır; Tür Faaliyet
          const fv = { ...v, neden: (v.faaliyetNeden || "Faaliyet"), aciklama: (v.faaliyetAciklama || "Faaliyet"), faaliyet: true };
          if (r.faAd) { // v2.3.38: okunan faaliyet adı Açıklama'ya; aynı formun tüm satırlarında ortak (grup); emin değilse KONTROL
            const grup = { adResim: r.adResim, adKontrol: !r.faAd.metin ? "Faaliyet adı okunamadı — görüntüden yazın" : (!r.faAd.sozluk || r.faAd.guven < 0.75) ? `Faaliyet adı emin değil (okunan: ${r.faAd.ham || "?"}) — kontrol edip düzeltin` : "" };
            if (r.faAd.metin) fv.aciklama = r.faAd.metin; fv.grup = grup; }
          const tlist = (o) => (r.bireysel ? o.tarihler || [] : r.tarihler);
          if (!r.ogrenciler.length || !r.ogrenciler.some((o) => tlist(o).length)) SAT.push({ no: "", adsoyad: "", bas: "", yarim: false, ...fv, guven: 0, uyari: uy || "Faaliyet formu boş", sayfa, jpeg });
          for (const o of r.ogrenciler) for (const t of tlist(o)) SAT.push({ no: o.no, adsoyad: o.ad || "", sinif: o.sinif || "", /* v2.4.3: liste yazısında ad/sınıf da okunur */ bas: t.tarih, yarim: t.yarim, gun: t.yarim ? 0.5 : 1, ...fv, guven: Math.min(t.guven, o.noGuven >= 0.8 ? 95 : 50), uyari: [t.not, uy].filter(Boolean).join(" | "), noUyari: o.noUyari, sayfa: sayfa + " satır " + o.satir, jpeg });
          delete s.canvas; continue;
        }
        if (!r.tarihler.length) SAT.push({ no: r.no, noOlas: r.noOlas, noOkunan: r.no, adsoyad: r.ad, sinif: r.sinif, bas: "", yarim: false, ...v, guven: r.guven, uyari: uy || "Tarih yok", sayfa, jpeg, noKirp: r.noKirp });
        for (const t of r.tarihler) SAT.push({ no: r.no, noOlas: r.noOlas, noOkunan: r.no, adsoyad: r.ad, sinif: r.sinif, bas: t.tarih, yarim: t.yarim, gun: t.yarim ? 0.5 : t.gun || 1, ...v, guven: t.supheli === false ? t.guven : Math.min(r.guven, t.guven), uyari: t.tarih ? (t.supheli === false ? t.not : [t.not, uy].filter(Boolean).join(" | ")) : ("Tarih okunamadı, görüntüden yazın" + (uy ? " | " + uy : "")), noUyari: uy, /* v2.3.22: numara uyarısı ayrı sütunda; tarih/gün güveni satırın kendi güveni */ kirp: t.kirp, noKirp: r.noKirp, ham: t.ham, sayfa, jpeg });
        delete s.canvas;
      }
    }
    const raporSay = SAT.filter((x) => String(x.uyari || "").includes(RAPOR_GIBI)).length;
    durum.textContent = (IPTAL ? "İptal edildi. " : "") + (raporSay ? `UYARI: ${raporSay} satır doktor raporuna benziyor; Tür'ü "Rapor (doktor raporu)" yapıp yeniden okutun. ` : "") + `${n} sayfa okundu, ${SAT.length} satır (her tarih bir satır; Gün = o tarihten başlayarak gün sayısı). Sarı satırları kontrol edin.`;
    try { await listeUygula(); } catch (e) { console.warn("öğrenci listesi uygulanamadı", e); }
    ciz(); return SAT;
  }
  async function elleEkle() { SAT.push({ no: "", adsoyad: "", bas: "", yarim: false, ...(await varsayilan()), elle: true, guven: 0, uyari: "", sayfa: "(elle)" }); ciz(); }
  async function aktar(durumEl) {
    const d = (await chrome.storage.local.get("durum")).durum || { calisiyor: false, satirlar: [], idx: -1, step: "bos", adimNo: 0, stepTs: 0 };
    if (d.calisiyor) { alert("e-Okul girişi çalışırken aktarılamaz."); return; }
    if (globalThis.OgrListe && OgrListe.hazirMi()) { const yok = SAT.filter((x) => !x.faaliyet && x.no && !OgrListe.bul(x.no)).length; if (yok && !confirm(`${yok} satırın okul numarası öğrenci listesinde YOK (kırmızı bilgi satırları). Yine de kontrol listesine aktarılsın mı?`)) return; } // v2.5.0
    const ilkUzunluk = d.satirlar.length; // v2.3.43
    const devYeni = [], devAtla = []; // v2.5.8: devamsızlık formu satırları → yoklama ekranı Sesli/Yazılı metni (panelde "Devamsızlık'a ayrılan satırlar")
    for (const s of SAT) {
      if (s.devamsizlik) { const no = String(s.no || "").replace(/\D/g, ""), bas = globalThis.RaporYardim ? RaporYardim.tarihNormal(s.bas) : s.bas;
        if (/^\d{1,6}$/.test(no) && /^\d\d\/\d\d\/\d{4}$/.test(bas)) devYeni.push(`${bas.replace(/\//g, ".")} ${no} numara${s.yarim ? " yarım gün" : ""}`); else devAtla.push(s.sayfa || "?");
        continue; }
      const no = String(s.no || "").replace(/\D/g, ""), bas = globalThis.RaporYardim ? RaporYardim.tarihNormal(s.bas) : s.bas;
      const tamam = /^\d{1,6}$/.test(no) && /^\d\d\/\d\d\/\d{4}$/.test(bas);
      d.satirlar.push({ dosya: s.sayfa || "(veli izni)", ara: "no", no, tc: no, adsoyad: s.adsoyad || "", bas, bit: bas, tur: s.faaliyet ? "Faaliyet" : "İzinli", neden: s.neden || (s.faaliyet ? "Faaliyet" : "İzinli"), veli: true, faaliyet: !!s.faaliyet,
        sure: s.yarim ? "0,5" : String(s.gun || 1), yarim: !!s.yarim, /* v2.3.20: başlangıç tarihi + gün sayısı (e-Okul o tarihten itibaren günleri kendisi seçer) */ aciklama: s.aciklama || (s.faaliyet ? "Faaliyet" : "Veli izni"), elleKaydet: true, // v2.3.23: yorum aciklama/elleKaydet alanlarını yutuyordu
        uyari: (s.yarim ? "YARIM GÜN (0,5) — e-Okul'da Süre alanını kontrol edin. " : "") + ((s.gun || 1) > 5 ? `GÜN SAYISI ${s.gun} (5'ten fazla) — kontrol edin. ` : "") + (s.uyari || "") + (s.noUyari ? " Sayfa/numara: " + s.noUyari : "") + (s.grup && s.grup.adKontrol ? " " + s.grup.adKontrol : ""), durum: tamam && (s.elle || s.guven >= 70) && !s.uyari && !s.noUyari && !(s.grup && s.grup.adKontrol) && !((s.gun || 1) > 5) ? "HAZIR" : "KONTROL", sonuc: "" });
    }
    try { // v2.3.38: onaylanan yeni faaliyet adları yerel listeye eklenir (yalnız bu bilgisayarda)
      const yeni = [...new Set(SAT.filter((s) => s.grup && !s.grup.adKontrol && s.aciklama).map((s) => s.aciklama.toLocaleUpperCase("tr-TR")))];
      if (yeni.length) { const mev = (await chrome.storage.local.get("faaliyetAdlari")).faaliyetAdlari || []; const ek = yeni.filter((a) => !mev.includes(a) && !(globalThis.ElHarf && ElHarf.VARSAYILAN_ADLAR.includes(a))); if (ek.length) await chrome.storage.local.set({ faaliyetAdlari: [...mev, ...ek] }); } } catch (e) { console.warn("faaliyet adı listesi", e); }
    let birles = null; // v2.3.43: aynı öğrencinin ardışık günleri (aynı hafta, Pzt–Cum) tek kayıt: ilk tarih + toplam süre
    try { if (globalThis.VeliBirlestir) { const yeniler = new Set(d.satirlar.slice(ilkUzunluk)); birles = VeliBirlestir.otomatik(d.satirlar, (x) => yeniler.has(x)); } } catch (e) { console.warn("birleştirme", e); }
    await chrome.storage.local.set({ durum: d });
    if (devYeni.length) { const eski = (await chrome.storage.local.get("devamsizlikBekleyen")).devamsizlikBekleyen || []; await chrome.storage.local.set({ devamsizlikBekleyen: [...eski, ...devYeni] }); }
    const devN = devYeni.length + devAtla.length, veliN = SAT.length - devN; // v2.5.8
    const hazir = d.satirlar.filter((x) => x.veli && x.durum === "HAZIR").length, kontrol = birles && birles.kayit ? d.satirlar.slice(ilkUzunluk).filter((x) => x.durum === "KONTROL").length : veliN - Math.min(veliN, hazir); // v2.3.24: kendiliğinden başlamaz; ne yapılacağı açıkça yazılır
    const devNot = devN ? `Devamsızlık formu: ${devYeni.length} gün yoklama metnine eklendi (panelde "Devamsızlık'a ayrılan satırlar" — yoklama ekranındaki Sesli/Yazılı kutusuna yapıştırın)` + (devAtla.length ? `; ${devAtla.length} satır numara/tarih eksik olduğu için eklenmedi` : "") + ". " : "";
    durumEl.textContent = devNot + `${veliN} veli izni satırı kontrol listesine aktarıldı. Kendiliğinden BAŞLAMAZ: e-Okul sekmesinde eklenti panelinin ${SAT.some((x) => x.faaliyet) ? (SAT.every((x) => x.faaliyet) ? "Faaliyet" : "Veli İzni / Faaliyet") : "Veli İzni"} sekmesini açıp Başlat'a basın.` + (kontrol ? ` ${kontrol} satır KONTROL durumunda; tabloda HAZIR yapılmadan girilmez.` : "") + (birles && birles.kayit ? ` Ardışık günler birleştirildi: ${birles.once} satır → ${birles.sonra} e-Okul kaydı (panelde "Ardışık günler" bölümünde görünür).` : "") + (birles && birles.arife ? ` ${birles.arife} arife günü satırı yarım gün (0,5) yapıldı.` : "");
  }
  // v2.4.3: genel liste ayırma — kullanıcı sütunları seçer, satırları böler/birleştirir; Aktar o sayfanın satırlarını değiştirir (isteğe bağlı)
  async function listeAyir(kap) {
    const dolu = HAM.filter((h) => h.satirlar.length); kap.hidden = false; kap.innerHTML = "";
    if (!dolu.length) { kap.textContent = "Önce taranmış bir sayfa olmalı (yazı satırı bulunan). "; const k = document.createElement("button"); k.textContent = "Kapat"; k.onclick = () => { kap.hidden = true; }; kap.append(k); return; }
    const sec = document.createElement("select"); dolu.forEach((h, i) => sec.append(new Option(h.sayfa + ` (${h.satirlar.length} satır)`, i)));
    const fa = document.createElement("label"), fk = document.createElement("input"); fk.type = "checkbox"; fa.append(fk, " Faaliyet (değilse veli izni)");
    const ta = document.createElement("input"); ta.placeholder = "gg/aa/yyyy"; ta.size = 11; ta.title = "Tarih sütunu yoksa/boşsa kullanılacak tarih";
    const ust = document.createElement("p"); ust.append("Sayfa: ", sec, " ", fa, " · Tarih (sütun yoksa): ", ta); const ed = document.createElement("div"); kap.append(ust, ed);
    const ac = () => { const h = dolu[+sec.value]; fk.checked = h.faaliyet; ta.value = h.tarih || ""; const M = ListeAyir.Model(h.satirlar);
      if (M.satirlar.length && M.satirlar[0].filter((x) => ListeAyir.rolTahmin(x) && ListeAyir.rolTahmin(x) !== "diger").length >= 2) M.baslikSec(0), (M.gecmis.length = 0);
      ListeAyir.arayuz(ed, M, { baslik: "Liste ayır", kapat: () => { kap.hidden = true; }, aktar: async (kay) => {
        if (!confirm(`"${h.sayfa}" sayfasının taranan satırları ${kay.length} satırla değiştirilsin mi?`)) return;
        const v = await varsayilan(), fv = fk.checked ? { ...v, neden: v.faaliyetNeden || "Faaliyet", aciklama: v.faaliyetAciklama || "Faaliyet", faaliyet: true } : v;
        SAT = SAT.filter((x) => !(x.sayfa === h.sayfa || String(x.sayfa || "").startsWith(h.sayfa + " satır ")));
        for (const k of kay) { const no = String(k.no || "").replace(/\D/g, ""), bas = (globalThis.RaporYardim ? RaporYardim.tarihNormal(k.tarih || ta.value) : k.tarih || ta.value) || "";
          const g = Number(String(k.gun || "").replace(",", ".")), yarim = g === 0.5 || /yar/i.test(k.gun || ""), gun = yarim ? 0.5 : g >= 1 && g <= 30 ? g : 1;
          const tamam = /^\d{1,6}$/.test(no) && /^\d\d\/\d\d\/\d{4}$/.test(bas);
          SAT.push({ no, adsoyad: k.ad || "", sinif: k.sinif || "", bas, yarim, gun, ...fv, ...(k.aciklama ? { aciklama: k.aciklama } : {}), guven: tamam ? 95 : 0, uyari: tamam ? "" : "Liste ayır: numara/tarih eksik — tamamlayın", sayfa: h.sayfa + " satır " + k.satir }); }
        kap.hidden = true; ciz(); } }); };
    sec.onchange = ac; ac();
  }
  (async () => { try { if (globalThis.OgrListe) { await OgrListe.hazirla(); const kap = $("#ogrListeKap"); if (kap) OgrListe.arayuz(kap, () => { listeUygula(); ciz(); }); ciz(); } } catch (e) { console.warn("öğrenci listesi yüklenemedi", e); } })(); // v2.5.0
globalThis.VeliTarama = { listeUygula: () => listeUygula(), ciz: () => ciz(), iptal: () => { IPTAL = true; }, sayfaCoz, tara, elleEkle, aktar, listeAyir, satirlar: () => SAT, ham: () => HAM };
})();
