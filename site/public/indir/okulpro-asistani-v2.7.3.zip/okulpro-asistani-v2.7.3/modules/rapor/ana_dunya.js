// Sayfanın kendi JS dünyasında çalışır (world: MAIN).
// e-Okul'un alert/confirm pencereleri otomasyonu bloke etmesin diye
// alert'leri yakalar (confirm pencereleri artık kullanıcıya sorulur, otomatik onaylanmaz) ve mesajı eklenti betiğine iletir.
(() => {
  if (/OOK08001\.aspx/i.test(location.href)) return; // devamsızlık (yoklama) modülünün sayfası: karışma
  const ilet = (tur, mesaj) =>
    window.postMessage({ kaynak: "eokul-eklenti", tur, mesaj: String(mesaj ?? "") }, "*");
  window.alert = (m) => { ilet("alert", m); };
  const asil = window.confirm.bind(window);
  // v2.3.13: Eklenti Kaydet'e bastığında data-eokul-otokaydet = bitiş zaman damgası (15 sn) yazar.
  // Yalnızca bu süre içinde e-Okul'un onay penceresi otomatik kabul edilir; diğer zamanlarda kullanıcıya sorulur.
  const kaydetSuresi = () => { const v = document.documentElement.getAttribute("data-eokul-otokaydet"); return v === "1" || Number(v) > Date.now(); };
  window.confirm = (m) => {
    ilet("confirm", m);
    if (kaydetSuresi() && !/sil|silinecek/i.test(String(m))) return true;
    return asil(m);
  };

  // ASP.NET AJAX (UpdatePanel) postback sürüyorsa eklentiye bildir (DOM özelliği üzerinden).
  const isaretle = (v) => document.documentElement && document.documentElement.setAttribute("data-eokul-mesgul", v ? "1" : "0");
  setInterval(() => {
    try {
      const prm = window.Sys && Sys.WebForms && Sys.WebForms.PageRequestManager && Sys.WebForms.PageRequestManager.getInstance();
      const pf = window.PrimeFaces && PrimeFaces.ajax && PrimeFaces.ajax.Queue;
      const pfMesgul = !!(pf && ((pf.isEmpty && !pf.isEmpty()) || (pf.requests && pf.requests.length)));
      const jq = !!(window.jQuery && jQuery.active > 0);
      isaretle(!!(prm && prm.get_isInAsyncPostBack()) || pfMesgul || jq);
    } catch (e) { isaretle(false); }
  }, 200);
  window.addEventListener("beforeunload", () => isaretle(true));
  // v2.3.33: bootstrap-toggle (jQuery eklentisi) yalnızca sayfanın dünyasından çevrilebilir
  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data.kaynak !== "eokul-eklenti-komut") return;
    if (e.data.islem === "select-change") {
      const tok = e.data.token;
      const el = tok
        ? document.querySelector('[data-eoa-oyss-sel="' + String(tok).replace(/"/g, "") + '"]')
        : document.querySelector("[data-eoa-oyss-sel]");
      if (!el) return;
      el.removeAttribute("data-eoa-oyss-sel");
      if (e.data.deger != null) { try { el.value = e.data.deger; } catch (x) {} }
      const $ = window.jQuery || window.$;
      try { if ($ && $.fn) $(el).val(el.value).trigger("change"); } catch (x) {}
      try { if ($ && $.fn && $.fn.select2) $(el).trigger("change.select2"); } catch (x) {}
      try { if ($ && $(el).data && $(el).data("chosen")) $(el).trigger("chosen:updated").trigger("change"); } catch (x) {}
      return;
    }
    if (e.data.islem !== "toggle") return;
    const el = document.querySelector("[data-eoa-hedef]"); if (!el) return; el.removeAttribute("data-eoa-hedef");
    const cb = el.querySelector("input[type=checkbox]") || el; const $ = window.jQuery || window.$;
    try { if ($ && $.fn && $.fn.bootstrapToggle) $(cb).bootstrapToggle("toggle"); else if ($) $(el).trigger("click"); else el.click(); } catch (x) { try { el.click(); } catch (y) {} }
  });
})();
