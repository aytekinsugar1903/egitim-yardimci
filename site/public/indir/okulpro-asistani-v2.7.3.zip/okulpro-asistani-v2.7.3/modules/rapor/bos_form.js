"use strict";
// v2.5.8 (+v2.5.9: beş tür de tek ay, her ders yılı): Boş form indir — ay/yıl + form türü seç, PDF'i yerelde üret (pdf-lib + yerel yazı tipi). Ağ kullanılmaz.
// Başlık: okul ayarlarındaki okul adı (+ bu sayfada girilen kaymakamlık / kurum kodu, "bosFormBaslik" anahtarında saklanır). Takvim: Okul ayarlarındaki tatil/arife metni.
// Üretilen her tek aylık form için yıl ve takvim "bosFormKayit" anahtarına yazılır; tarama sayfası aynı formu okurken aynı düzeni kurar.
(async function () {
  const $ = (s) => document.querySelector(s), AF = globalThis.AylikForm, B = globalThis.VeliBirlestir;
  const AYLAR = [9, 10, 11, 12, 1, 2, 3, 4, 5, 6];
  const depo = async (k) => { try { return await chrome.storage.local.get(k); } catch (e) { return {}; } };
  const r = await depo(["okulProfili", "ayar", "bosFormBaslik", "bosFormKayit"]);
  const ayar = r.ayar || {}, prof = r.okulProfili || {}, bb = r.bosFormBaslik || {};
  const bugun = new Date(), q = new URLSearchParams(location.search), ilkTur = Math.min(5, Math.max(1, Number(q.get("tur")) || 1));
  // ay / yıl
  const buAy = bugun.getMonth() + 1, varsAy = AYLAR.includes(buAy) ? buAy : 9;
  $("#ay").innerHTML = AYLAR.map((a) => `<option value="${a}"${a === varsAy ? " selected" : ""}>${AF.AY[a].charAt(0) + AF.AY[a].slice(1).toLocaleLowerCase("tr")}</option>`).join("");
  const y0 = bugun.getFullYear(); $("#yil").innerHTML = [y0 - 1, y0, y0 + 1, y0 + 2].map((y) => `<option${y === AF.yilTahmin(varsAy, bugun) ? " selected" : ""}>${y}</option>`).join("");
  // türler
  $("#turlar").innerHTML = Object.entries(AF.TURLER).map(([t, ad]) => `<label><input type="radio" name="tur" value="${t}"${+t === ilkTur ? " checked" : ""}> ${ad}</label>`).join("");
  // başlık
  $("#okul").value = bb.okul != null && bb.okul !== "" ? bb.okul : prof.okulAdi || ""; $("#kaymakamlik").value = bb.kaymakamlik || ""; $("#kurumKodu").value = bb.kurumKodu || ""; $("#genel").checked = !!bb.genel;
  const tm = typeof ayar.tatilMetni === "string" ? ayar.tatilMetni : undefined, am = typeof ayar.arifeMetni === "string" ? ayar.arifeMetni : undefined;
  const takvim = AF.takvimKur(tm, am);
  $("#takvimNot").textContent = `Tatil ve arife günleri Okul ayarlarındaki takvimden alınır (${tm === undefined ? "varsayılan MEB 2026-2027 takvimi" : "okulunuzun takvimi"}: ${takvim.tatil.size} tatil günü, ${takvim.arife.size} arife). Tatil günleri formda gri ve işaretsizdir; bireysel ve devamsızlık formlarında hiç yer almaz.`;
  $("#ayarlarAc").onclick = () => chrome.runtime.sendMessage({ tip: "okulAyarlariAc" });
  const sec = () => ({ t: +document.querySelector("input[name=tur]:checked").value, ay: +$("#ay").value, yil: +$("#yil").value });
  const durum = (m, cls) => { $("#durum").textContent = m; $("#durum").className = cls || ""; };
  function bilgi() { const { t, ay, yil } = sec(), ogr = AF.dersYiliBas(ay, yil);
    $("#dersYili").textContent = `Ders yılı: ${ogr}-${ogr + 1}`;
    $("#turNot").textContent = "Tek aylık form: yalnız seçilen ayın okul günleri. Ders yılı formun üzerine kodlanır."; // v2.5.9: tür 5 de tek ay
    $("#indir").disabled = $("#yazdir").disabled = false; }
  document.addEventListener("change", bilgi); bilgi();
  let FONT = null;
  async function fontlar() { if (FONT) return FONT; const al = async (a) => (await fetch(chrome.runtime.getURL("fonts/form/" + a))).arrayBuffer();
    FONT = { fontR: await al("LiberationSans-Regular.ttf"), fontB: await al("LiberationSans-Bold.ttf") }; return FONT; }
  async function baslikKaydet() { const b = { kaymakamlik: $("#kaymakamlik").value.trim(), okul: $("#okul").value.trim(), kurumKodu: $("#kurumKodu").value.trim(), genel: $("#genel").checked };
    try { await chrome.storage.local.set({ bosFormBaslik: b }); } catch (e) {} return b.genel ? {} : b; }
  async function kayitYaz(sayfalar) { // okuyucu aynı düzeni kursun: tür+ay → yıl → kullanılan takvim metni
    try { const k = (await depo("bosFormKayit")).bosFormKayit || {};
      for (const s of sayfalar) { const a = `${s.t}-${s.ay}`; k[a] = k[a] || {}; k[a][s.yil] = { tatilMetni: tm === undefined ? (B ? B.VARSAYILAN_TATIL_METNI : "") : tm, arifeMetni: am === undefined ? (B ? B.VARSAYILAN_ARIFE_METNI : "") : am, tarih: new Date().toISOString().slice(0, 10) }; }
      await chrome.storage.local.set({ bosFormKayit: k }); } catch (e) { console.warn("form kaydı yazılamadı", e); } }
  async function uret(sayfalar) {
    const baslik = await baslikKaydet(), f = await fontlar();
    const { bayt } = await AF.pdfUret(sayfalar, { PDFLib: globalThis.PDFLib, fontkit: globalThis.fontkit, ...f, takvim, baslik });
    await kayitYaz(sayfalar); return new Blob([bayt], { type: "application/pdf" });
  }
  const indir = (blob, ad) => { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = ad; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 60000); };
  async function calis(fn) { durum("PDF hazırlanıyor…"); try { await fn(); } catch (e) { console.error(e); durum("PDF üretilemedi: " + (e.message || e), "hata"); } }
  $("#indir").onclick = () => calis(async () => { const s = sec(); const b = await uret([s]); const ad = AF.dosyaAdi(s.t, s.ay, s.yil); indir(b, ad); durum(`İndirildi: ${ad}`, "ok"); });
  $("#yazdir").onclick = () => calis(async () => { const b = await uret([sec()]); window.open(URL.createObjectURL(b)); durum("PDF yeni sekmede açıldı; yazdırmak için Ctrl+P. Ölçek: %100 (gerçek boyut).", "ok"); });
  $("#hepsi").onclick = () => calis(async () => { const { ay, yil } = sec(), s = [1, 2, 3, 4, 5].map((t) => ({ t, ay, yil }));
    const b = await uret(s), ad = `evrak-asistani-bos-formlar-${AF.dosyaAdi(1, ay, yil).replace("veli-izin-formu-", "")}`; indir(b, ad); durum(`İndirildi: ${ad} (${s.length} sayfa)`, "ok"); });
  globalThis.__BOS_FORM_HAZIR = true;
})();
