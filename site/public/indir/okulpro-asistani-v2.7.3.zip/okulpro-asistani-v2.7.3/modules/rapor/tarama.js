// Toplu taranmış PDF/görselleri sayfa sayfa OCR'lar, TC'ye göre öğrencilere ayırır, alanları çıkarır.
import * as pdfjsLib from "./lib/pdf.min.mjs";
pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL("modules/rapor/lib/pdf.worker.min.mjs");
const C = globalThis.RaporCikarim, Y = globalThis.RaporYardim;
const $ = (s) => document.querySelector(s);
const p2 = (n) => String(n).padStart(2, "0");
const tarihYaz = (t) => (t ? `${p2(t.getDate())}/${p2(t.getMonth() + 1)}/${t.getFullYear()}` : "");
const tarihCoz = (s) => { const m = String(s || "").match(/(\d{1,2})[./-](\d{1,2})[./-](\d{4})/); if (!m) return null; const t = new Date(+m[3], m[2] - 1, +m[1]); return t.getDate() === +m[1] ? t : null; };
function gunSay(bas, bit, hesap) {
  let n = 0;
  for (let t = new Date(bas); t <= bit; t.setDate(t.getDate() + 1)) if (hesap === "takvim" || (t.getDay() % 6 !== 0)) n++;
  return n;
}

let SATIRLAR = []; // {tc, adsoyad, bas, bit, belgeGun, sure, kurumTur, kurum, uyari, sayfalar:[{dosya, pdfBytes?, sayfaNo, jpeg}]}
let isci = null;
let KURUMLAR = C.KURUM_VARSAYILAN, SEVK_SURE = 1;
chrome.storage.local.get("ayar").then((r) => { if (r.ayar && r.ayar.kurumlar) KURUMLAR = C.kurumListesiCoz(r.ayar.kurumlar); if (r.ayar && r.ayar.sevkSure) SEVK_SURE = Number(r.ayar.sevkSure) || 1; });

async function ocrIsci() {
  if (isci) return isci;
  isci = await Tesseract.createWorker("tur", 1, {
    workerPath: chrome.runtime.getURL("modules/rapor/lib/worker.min.js"),
    corePath: chrome.runtime.getURL("modules/rapor/lib/tess-core/"),
    langPath: chrome.runtime.getURL("modules/rapor/lib/lang"),
    workerBlobURL: false, cacheMethod: "none",
    logger: (m) => { if (m.status === "recognizing text") $("#durum").dataset.yuzde = Math.round(m.progress * 100); },
  });
  await isci.setParameters({ preserve_interword_spaces: "1", debug_file: "/dev/null" }); // v2.4.3: Tesseract tanılama iletileri ("Estimating resolution as …") stderr → console.warn → Chrome uzantı hataları listesine düşmesin
  return isci;
}

// Görüntüyü gri tonlamalı ve kontrastlı hale getirir (tarama gürültüsünü azaltır)
function onIsle(c) {
  const x = c.getContext("2d"), v = x.getImageData(0, 0, c.width, c.height), d = v.data;
  for (let i = 0; i < d.length; i += 4) { const g = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; const k = g > 165 ? 255 : g < 90 ? 0 : (g - 90) * 3.4; d[i] = d[i + 1] = d[i + 2] = k; }
  x.putImageData(v, 0, 0); return c;
}

async function sayfalarUret(file) {
  const out = [];
  const bytes = new Uint8Array(await file.arrayBuffer());
  const tes = (globalThis.VeliJpeg && VeliJpeg.dosyaTeshis) ? VeliJpeg.dosyaTeshis(file.name, bytes) : { ok: true };
  if (tes && tes.ok === false) throw new Error(tes.uyari);
  if (file.type === "application/pdf" || /\.pdf$/i.test(file.name) || (tes && tes.tur === "pdf")) {
    let pdf;
    try { pdf = await pdfjsLib.getDocument({ data: bytes.slice() }).promise; }
    catch (e) { throw new Error((tes && tes.uyari) ? tes.uyari : ("PDF açılamadı: " + (e.message || e))); }
    for (let n = 1; n <= pdf.numPages; n++) {
      try { // bozuk sayfa tüm dosyayı durdurmasın
      const p = await Y.zamanAsimi(pdf.getPage(n), 30000, "Sayfa açma"), vp0 = p.getViewport({ scale: 1 });
      const vp = p.getViewport({ scale: Math.min(3, 2400 / Math.max(vp0.width, vp0.height)) });
      const c = document.createElement("canvas"); c.width = vp.width; c.height = vp.height;
      const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height);
      await Y.zamanAsimi(p.render({ canvasContext: x, viewport: vp }).promise, 60000, "Sayfa çizme");
      out.push({ dosya: file.name, sayfaNo: n, toplam: pdf.numPages, pdfBytes: bytes, canvas: c });
      } catch (e) { out.push({ dosya: file.name, sayfaNo: n, toplam: pdf.numPages, pdfBytes: bytes, hata: "Sayfa açılamadı: " + (e.message || e) }); }
    }
  } else {
    // v2.6.1: createImageBitmap eksik EOI / bozulmuş Brother JPEG'i reddeder; Image() ve SOI onarımı yedek
    // v2.6.2: boş/kesik/yanlış tür için açık hata; çözücüye bayt Blob verilir
    let bmp;
    const blob = new Blob([bytes], { type: file.type || (tes && tes.tur === "png" ? "image/png" : "image/jpeg") });
    try {
      bmp = await (globalThis.VeliJpeg && VeliJpeg.gorselCoz ? VeliJpeg.gorselCoz(blob) : createImageBitmap(blob, { imageOrientation: "from-image" }));
    } catch (e) {
      throw new Error((tes && tes.kesik) ? "JPEG kesik veya bozulmuş (bitiş işareti yok). Görüntü açılamadı." : ("Görüntü açılamadı: " + (e.message || e)));
    }
    const w = bmp.width || bmp.naturalWidth, h = bmp.height || bmp.naturalHeight;
    const k = Math.min(1.5, 2400 / Math.max(w, h));
    const c = document.createElement("canvas"); c.width = w * k; c.height = h * k;
    c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
    if (bmp.close) bmp.close();
    out.push({ dosya: file.name, sayfaNo: 1, toplam: 1, canvas: c });
  }
  return out;
}

// Kontrast germe (soluk taramalar için): en koyu/en açık %2'yi 0-255'e yayar
function kontrastGer(c) {
  const x = c.getContext("2d"), v = x.getImageData(0, 0, c.width, c.height), d = v.data, h = new Array(256).fill(0);
  for (let i = 0; i < d.length; i += 4) h[Math.round(0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2])]++;
  const n = d.length / 4; let a = 0, lo = 0, hi = 255;
  for (; lo < 255 && (a += h[lo]) < n * 0.02; lo++); a = 0; for (; hi > 0 && (a += h[hi]) < n * 0.02; hi--);
  if (hi - lo < 20) return c;
  for (let i = 0; i < d.length; i += 4) for (let j = 0; j < 3; j++) d[i + j] = Math.max(0, Math.min(255, (d[i + j] - lo) * 255 / (hi - lo)));
  x.putImageData(v, 0, 0); return c;
}
function dondur(c, der) {
  const r = document.createElement("canvas"), dik = der % 180 !== 0; r.width = dik ? c.height : c.width; r.height = dik ? c.width : c.height;
  const x = r.getContext("2d"); x.translate(r.width / 2, r.height / 2); x.rotate(der * Math.PI / 180); x.drawImage(c, -c.width / 2, -c.height / 2); return r;
}
const kopya = (c) => { const r = document.createElement("canvas"); r.width = c.width; r.height = c.height; r.getContext("2d").drawImage(c, 0, 0); return r; };
// Bir sayfayı OCR'lar: kontrast germe + ön işleme; güven düşükse 90/180/270 döndürerek yeniden dener, en iyisini alır.
async function sayfaOku(w, canvas) {
  const oku = async (c) => { const r = (await Y.zamanAsimi(w.recognize(onIsle(kontrastGer(kopya(c)))), 90000, "OCR")).data; return { metin: r.text || "", guven: r.confidence || 0, der: 0 }; };
  let en = await oku(canvas);
  const anlamli = (m) => C.tcBul(m).length || C.tarihler(m).length;
  if (en.guven < 55 || !anlamli(en.metin)) {
    for (const der of [180, 90, 270]) {
      const r = await oku(dondur(canvas, der)); r.der = der;
      if (r.guven > en.guven + 5 || (!anlamli(en.metin) && anlamli(r.metin))) en = r;
      if (en.guven >= 70 && anlamli(en.metin)) break;
    }
  }
  return en;
}

function satirKur(g, hesap) {
  if (g.okunamayan) {
    const s = { tc: "", adsoyad: "", bas: "", bit: "", belgeGun: "", sure: "", tur: "Raporlu", aciklama: "", kurum: "", sayfalar: g.sayfalar, metin: "", okunamayan: true,
      uyari: g.sayfalar.map((p) => `${p.dosya} s.${p.sayfaNo}: ${p.hata}`).join(" | ") + " — elle doldurun veya − ile çıkarın" };
    s.guven = 0; return s;
  }
  const metin = g.sayfalar.map((s) => s.metin).join("\n\n");
  const v = C.raporCikar(metin), uy = [...v.notlar];
  const tc = g.tc || v.tc;
  if (!C.tcGecerli(tc)) uy.push("TC bulunamadı/geçersiz");
  if (v.tcAdaylari.length > 1) uy.push("Birden çok TC: " + v.tcAdaylari.join(", "));
  let bas = v.baslangic, bit = v.bitis; let belgeGun = v.gun_sayisi;
  if (globalThis.OcrDuzelt) { const d = OcrDuzelt.raporTutarla(belgeGun, bas, bit); if (d.kontrol) { belgeGun = d.gun; bas = d.bas; bit = d.bit; uy.push(d.not); } } // v2.3.14: 1->10 / 2->20 OCR hatası
  if (!bas) uy.push("Başlangıç tarihi bulunamadı");
  const tur = v.tur;
  if (tur === "Sevkli") { const i = uy.indexOf("Başlangıç olarak rapor/ilk tarih alındı"); if (i >= 0) uy.splice(i, 1); }
  if (tur === "Raporlu" && !belgeGun && !bit) uy.push("Gün sayısı bulunamadı");
  if (bas && !bit && belgeGun) { bit = new Date(bas); bit.setDate(bit.getDate() + belgeGun - 1); }
  if (bas && bit && belgeGun) { const tk = gunSay(bas, bit, "takvim"); if (tk !== belgeGun && v.bitis) uy.push(`Belgede ${belgeGun} gün, tarih aralığı ${tk} gün`); }
  const sinif = C.kurumSinifla(metin, KURUMLAR);
  if (!sinif.ad) uy.push(sinif.belirsiz ? "Açıklama belirsiz: listeden seçin" : "Açıklama bulunamadı: listeden seçin");
  if (tur === "Sevkli" && bas) bit = bas;
  const sure = tur === "Sevkli" ? SEVK_SURE : !bas || !bit ? belgeGun || "" : hesap === "belge" && belgeGun ? belgeGun : gunSay(bas, bit, hesap === "takvim" ? "takvim" : "is_gunu");
  const sonuc = { tc, adsoyad: v.ad_soyad, bas: tarihYaz(bas), bit: tarihYaz(bit), belgeGun: belgeGun || "", sure, tur, aciklama: sinif.ad, kurum: v.kurum.ad,
    uyari: uy.join(" | "), sayfalar: g.sayfalar, metin };
  const og = g.sayfalar.map((p) => p.guven).filter((x) => typeof x === "number");
  const ocrG = og.length ? Math.min(...og) : undefined;
  if (ocrG !== undefined && ocrG < 50) uy.push(`OCR güveni düşük (%${Math.round(ocrG)})`);
  if (g.sayfalar.some((p) => p.der)) uy.push("Sayfa döndürülerek okundu");
  sonuc.uyari = uy.join(" | "); sonuc.guven = Y.guvenHesapla(sonuc, ocrG);
  return sonuc;
}

// v2.4.0: sürükle-bırak — bırakılan PDF / fotoğraflar dosya girdisine eklenir (klasör kabul edilmez)
const dosyaUygun = (f) => /\.(pdf|jpe?g|png|webp|bmp|tiff?)$/i.test(f.name || "") || /^application\/pdf$|^image\//i.test(f.type || "");
function dosyaSayCiz() {
  const e = $("#dosyaSay"); if (!e) return;
  const l = [...($("#dosyalar").files || [])];
  e.textContent = l.length ? `${l.length} dosya seçildi: ` + l.slice(0, 5).map((f) => f.name).join(", ") + (l.length > 5 ? ` … (+${l.length - 5})` : "") : "Dosya seçilmedi.";
}
function dosyaEkle(liste) {
  const inp = $("#dosyalar"), dt = new DataTransfer();
  [...(inp.files || [])].forEach((f) => dt.items.add(f));
  const varOlan = new Set([...dt.files].map((f) => f.name + "|" + f.size));
  let n = 0;
  [...(liste || [])].filter(dosyaUygun).forEach((f) => { const k = f.name + "|" + f.size; if (varOlan.has(k)) return; dt.items.add(f); varOlan.add(k); n++; });
  inp.files = dt.files; dosyaSayCiz(); return n;
}
{
  const birak = $("#birak");
  if (birak) {
    birak.addEventListener("dragover", (e) => { e.preventDefault(); birak.classList.add("uzerinde"); });
    birak.addEventListener("dragleave", () => birak.classList.remove("uzerinde"));
  }
  // sayfaya bırakılan dosyalar tarayıcıda açılmaz; doğrudan listeye eklenir
  window.addEventListener("dragover", (e) => e.preventDefault());
  window.addEventListener("drop", (e) => {
    e.preventDefault(); const fs = e.dataTransfer && e.dataTransfer.files; if (!fs || !fs.length) return;
    if (birak) birak.classList.remove("uzerinde");
    if ($("#tara").disabled) { $("#durum").textContent = "Tarama sürüyor; dosyaları tarama bitince bırakın."; return; } // v2.4.1: tarama sırasında ikinci tarama açılmaz
    const n = dosyaEkle(fs);
    $("#durum").textContent = n ? `${n} dosya eklendi. “Tara ve ayır” düğmesine basın.` : "Uygun dosya bulunamadı (PDF / JPG / PNG).";
  });
  $("#dosyalar").addEventListener("change", dosyaSayCiz);
  dosyaSayCiz();
}

$("#tara").onclick = async () => {
  dosyaSayCiz();  const dosyalar = [...$("#dosyalar").files].sort((a, b) => a.name.localeCompare(b.name, "tr", { numeric: true }));
  if (!dosyalar.length) { $("#durum").textContent = "Dosya seçilmedi."; return; }
  if (!(await chrome.storage.local.get("kvkkOnay")).kvkkOnay) { $("#durum").textContent = "Önce KVKK bilgilendirmesini onaylayın."; chrome.runtime.sendMessage({ tip: "kvkkAc" }); return; }
  $("#tara").disabled = true;
  if ($("#tarTur").value === "veli") { // v2.3.4: veli izni formu modu
    $("#veliIptal").style.display = ""; $("#veliIptal").disabled = false;
    try { $("#durum").textContent = "OCR motoru yükleniyor..."; await VeliTarama.tara({ dosyalar, isci: await ocrIsci(), sayfalarUret, durum: $("#durum") }); }
    catch (e) { $("#durum").textContent = "Hata: " + (e.message || e); console.error(e); }
    $("#tara").disabled = false; $("#veliIptal").style.display = "none"; return;
  }
  try {
    $("#durum").textContent = "OCR motoru yükleniyor...";
    const w = await ocrIsci();
    const sayfalar = [], bozuk = [];
    for (const f of dosyalar) {
      let liste;
      try { liste = await Y.tekrarDene(() => sayfalarUret(f), { deneme: 2, ms: 300000, ad: "Dosya açma" }); }
      catch (e) { bozuk.push({ dosya: f.name, sayfaNo: 1, hata: "Dosya açılamadı: " + (e.message || e) }); continue; }
      for (const s of liste) {
        if (s.hata) { bozuk.push(s); continue; }
        $("#durum").textContent = `${f.name} – sayfa ${s.sayfaNo}/${s.toplam} okunuyor...`;
        try {
          s.jpeg = s.canvas.toDataURL("image/jpeg", 0.85);
          const r = await Y.tekrarDene(() => sayfaOku(w, s.canvas), { deneme: 2, ms: 400000, ad: "OCR" });
          Object.assign(s, { metin: r.metin, guven: r.guven, der: r.der });
          if (!s.metin.trim()) { s.hata = "Metin okunamadı"; bozuk.push(s); } else sayfalar.push(s);
        } catch (e) { s.hata = "OCR hatası: " + (e.message || e); bozuk.push(s); } // sayfayı işaretle, partiye devam
        delete s.canvas;
      }
    }
    const hesap = $("#sureHesabi").value;
    SATIRLAR = C.sayfalariGrupla(sayfalar).map((g) => satirKur(g, hesap));
    for (const b of bozuk) SATIRLAR.push(satirKur({ okunamayan: true, sayfalar: [b] }, hesap));
    const tekrar = Y.tekrarIsaretle(SATIRLAR);
    $("#durum").textContent = `${sayfalar.length} sayfa okundu, ${SATIRLAR.length} satır` + (bozuk.length ? `, ${bozuk.length} sayfa okunamadı (işaretlendi)` : "") + (tekrar ? `, ${tekrar} olası tekrar` : "") + ".";
    ciz();
  } catch (e) { $("#durum").textContent = "Hata: " + (e.message || e); console.error(e); }
  $("#tara").disabled = false;
};

const KOLON = [["tc", "TC Kimlik No"], ["adsoyad", "Ad Soyad"], ["bas", "Başlangıç"], ["bit", "Bitiş"], ["belgeGun", "Belgedeki gün"], ["tur", "Tür"], ["sure", "e-Okul süre"], ["aciklama", "Açıklama (e-Okul)"], ["kurum", "Okunan kurum"]];
function ciz() {
  const t = $("#grup"); t.innerHTML = "";
  t.insertRow().innerHTML = "<th></th><th>Güven</th><th>Önizleme</th>" + KOLON.map((k) => `<th>${k[1]}</th>`).join("") + "<th>Uyarı</th><th>Sayfalar</th>";
  SATIRLAR.forEach((s, i) => {
    const tr = t.insertRow(); if (s.uyari || !C.tcGecerli(s.tc)) tr.className = "kontrol";
    const sil = document.createElement("button"); sil.className = "ico ico-del"; sil.textContent = "−"; sil.title = "Listeden çıkar";
    sil.onclick = () => { Y.satirSil(SATIRLAR, i); Y.tekrarIsaretle(SATIRLAR); ciz(); };
    tr.insertCell().append(sil);
    const g = s.guven ?? 0, gc = tr.insertCell(); gc.textContent = s.elle ? "elle" : "%" + g; gc.className = "guven " + (s.elle ? "orta" : g < 50 ? "dusuk" : g < 80 ? "orta" : "iyi");
    const ic = tr.insertCell();
    if (s.sayfalar[0] && s.sayfalar[0].jpeg) {
      const im = document.createElement("img"); im.src = s.sayfalar[0].jpeg; im.className = "onizle";
      im.onclick = () => { $("#buyuk img").src = im.src; $("#buyuk").style.display = "flex"; };
      ic.append(im);
    } else ic.textContent = s.elle ? "(elle)" : "—";
    for (const [k] of KOLON) {
      let inp;
      if (k === "tur") {
        inp = document.createElement("select");
        ["Raporlu", "Sevkli"].forEach((x) => inp.add(new Option(x, x, false, x === s.tur)));
        inp.onchange = () => { s.tur = inp.value; if (s.tur === "Sevkli") { s.sure = SEVK_SURE; s.bit = s.bas; } ciz(); };
      } else if (k === "aciklama") {
        inp = document.createElement("select"); inp.add(new Option("— seçin —", ""));
        KURUMLAR.forEach((x) => inp.add(new Option(x.ad, x.ad, false, x.ad === s.aciklama)));
        if (!s.aciklama) inp.style.background = "#ffd54f";
        inp.onchange = () => { s.aciklama = inp.value; inp.style.background = s.aciklama ? "" : "#ffd54f"; s.uyari = s.uyari.split(" | ").filter((u) => !/^Açıklama/.test(u)).join(" | "); };
      } else {
        inp = document.createElement("input"); inp.value = s[k] ?? "";
        inp.onchange = () => {
          s[k] = (k === "bas" || k === "bit") ? Y.tarihNormal(inp.value) : inp.value.trim();
          if (k === "tc") tr.className = C.tcGecerli(s.tc) ? "" : "kontrol";
          if (s.elle || s.okunamayan) { s.guven = Y.guvenHesapla({ ...s, okunamayan: false }); if (C.tcGecerli(s.tc) && Y.tarihCozGenis(s.bas)) s.uyari = ""; }
          if (k === "tc" || k === "bas") Y.tekrarIsaretle(SATIRLAR);
          ciz();
        };
      }
      tr.insertCell().append(inp);
    }
    tr.insertCell().textContent = s.uyari;
    tr.insertCell().textContent = s.sayfalar.map((p) => `${p.dosya} s.${p.sayfaNo}`).join(", ");
  });
}
$("#tarTur").onchange = () => { const v = $("#tarTur").value === "veli"; $("#veliBolum").hidden = !v; $("#raporBolum").hidden = v; };
$("#veliIptal").onclick = () => { VeliTarama.iptal(); $("#veliIptal").disabled = true; $("#durum").textContent += " — iptal ediliyor, bu sayfa bitince durur."; };
$("#veliEkle").onclick = () => VeliTarama.elleEkle();
if ($("#veliListeAyir")) $("#veliListeAyir").onclick = () => VeliTarama.listeAyir($("#listeAyirKap")); // v2.4.3
$("#veliAktar").onclick = () => VeliTarama.aktar($("#durum"));
if (new URLSearchParams(location.search).get("tur") === "veli") { $("#tarTur").value = "veli"; $("#tarTur").onchange(); } // v2.3.25: Veli İzni sekmesinden açıldı
if (new URLSearchParams(location.search).get("tur") === "veli") { $("#tarTur").value = "veli"; $("#tarTur").onchange(); } // v2.3.25: Veli İzni sekmesinden açıldı
$("#ekle").onclick = () => { Y.satirEkle(SATIRLAR); ciz(); };
$("#buyuk").onclick = () => { $("#buyuk").style.display = "none"; };

function indir(blob, ad) { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = ad; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000); }
const BASLIK = ["TC", "AdSoyad", "Baslangic", "Bitis", "BelgedekiGun", "Tur", "Sure", "Aciklama", "OkunanKurum", "Uyari", "Sayfalar"];
const tcMaske = (v) => (globalThis.EOAKasa ? EOAKasa.maske(v) : String(v ?? "").replace(/^(\d{3})\d{6}(\d{2})$/, "$1******$2")); // v2.4.1: dışa aktarımda T.C. maskeli
const satirDizi = (s) => [tcMaske(s.tc), s.adsoyad, s.bas, s.bit, s.belgeGun, s.tur, s.sure, s.aciklama, s.kurum, s.uyari, s.sayfalar.map((p) => `${p.dosya} s.${p.sayfaNo}`).join(", ")];
$("#csv").onclick = () => {
  const kac = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const l = [BASLIK.join(";"), ...SATIRLAR.map((s) => satirDizi(s).map(kac).join(";"))];
  indir(new Blob(["\ufeff" + l.join("\r\n")], { type: "text/csv;charset=utf-8" }), "raporlar.csv");
};
$("#xls").onclick = () => {
  const e = (v) => String(v ?? "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[c]);
  const html = `<html><head><meta charset="utf-8"></head><body><table><tr>${BASLIK.map((b) => `<th>${b}</th>`).join("")}</tr>` +
    SATIRLAR.map((s) => "<tr>" + satirDizi(s).map((v, i) => `<td${i === 0 ? ' style="mso-number-format:\\@"' : ""}>${e(v)}</td>`).join("") + "</tr>").join("") + "</table></body></html>";
  indir(new Blob([html], { type: "application/vnd.ms-excel" }), "raporlar.xls");
};
$("#pdfler").onclick = async () => {
  const { PDFDocument } = PDFLib; const kaynak = new Map(); const sayac = {};
  for (const s of SATIRLAR) {
    const yeni = await PDFDocument.create();
    for (const p of s.sayfalar) {
      if (!p.pdfBytes && !p.jpeg) continue;
      if (p.pdfBytes) {
        if (!kaynak.has(p.pdfBytes)) kaynak.set(p.pdfBytes, await PDFDocument.load(p.pdfBytes, { ignoreEncryption: true }));
        const [k] = await yeni.copyPages(kaynak.get(p.pdfBytes), [p.sayfaNo - 1]); yeni.addPage(k);
      } else {
        const img = await yeni.embedJpg(p.jpeg); const sy = yeni.addPage([595, 842]);
        const o = Math.min(595 / img.width, 842 / img.height); sy.drawImage(img, { x: 0, y: 842 - img.height * o, width: img.width * o, height: img.height * o });
      }
    }
    let ad = `${C.tcGecerli(s.tc) ? tcMaske(s.tc).replace(/\*/g, "x") : "TC_YOK"}_${(s.bas || "tarihsiz").replace(/\//g, "-")}`;
    sayac[ad] = (sayac[ad] || 0) + 1; if (sayac[ad] > 1) ad += `_${sayac[ad]}`;
    if (!yeni.getPageCount()) continue; // elle eklenen satırın sayfası yok
    indir(new Blob([await yeni.save()], { type: "application/pdf" }), ad + ".pdf");
    await new Promise((r) => setTimeout(r, 300));
  }
};
$("#aktar").onclick = async () => {
  const d = (await chrome.storage.local.get("durum")).durum || { calisiyor: false, satirlar: [], idx: -1, step: "bos", adimNo: 0, stepTs: 0 };
  if (d.calisiyor) { alert("e-Okul girişi çalışırken aktarılamaz."); return; }
  // v2.4.1 (KVKK): T.C. içeren satırlar yalnız T.C. kasası açıkken aktarılır (depoda şifreli saklanır)
  if (SATIRLAR.some((s) => /^\d{11}$/.test(String(s.tc || ""))) && !(globalThis.EOAKasa && await EOAKasa.acikMi())) {
    $("#durum").textContent = "T.C. kasası kilitli ya da kurulmamış. Açılan sayfada kasayı açın/oluşturun, sonra yeniden “Aktar”a basın.";
    chrome.runtime.sendMessage({ tip: "kasaAc" }); return;
  }
  for (const s of SATIRLAR) {
    const aciklama = s.aciklama || "";
    s.bas = Y.tarihNormal(s.bas); s.bit = Y.tarihNormal(s.bit);
    const tamam = C.tcGecerli(s.tc) && tarihCoz(s.bas) && s.sure && aciklama && !s.tekrar;
    d.satirlar.push({ dosya: s.sayfalar.map((p) => `${p.dosya} s.${p.sayfaNo}`).join(", "), tc: s.tc, adsoyad: s.adsoyad, bas: s.bas, bit: s.bit, sure: s.sure, tur: s.tur || "Raporlu",
      aciklama, uyari: s.uyari, guven: s.guven, elle: !!s.elle, durum: tamam && !s.uyari ? "HAZIR" : "KONTROL", sonuc: "" });
  }
  await chrome.storage.local.set({ durum: d });
  $("#durum").textContent = `${SATIRLAR.length} satır kontrol listesine aktarıldı. e-Okul sekmesindeki paneli açın.`;
};
chrome.storage.local.get("ayar").then((r) => { if (r.ayar && r.ayar.sureHesabi) $("#sureHesabi").value = r.ayar.sureHesabi; });
