// v2.3.40: Sesli / yazılı devamsızlık girişi (yoklama ekranı). Web Speech API (tr-TR) ya da yazarak.
// Ön izleme listesi (+/− ile düzenle/sil) → "Forma doldur" yalnız ekrandaki kutuları işaretler.
// Kaydet/Gönder/onaya ASLA basmaz; Güvenlik Kodu'na dokunmaz. Veri bu bilgisayarda kalır (tarayıcının ses tanıması Chrome'un kendi hizmetini kullanır).
(function () {
  "use strict";
  if (!/OOK08001\.aspx/i.test(location.href) || window.__eaSesli) return; window.__eaSesli = true;
  const A = window.__eaSesliAyrac; if (!A) return;
  let satirlar = [];
  const ikiH = (n) => String(n).padStart(2, "0"), tr = (iso) => iso.split("-").reverse().join(".");
  function ekranTarihi() { // e-Okul'daki tarih kutusu (yoksa bugün)
    const k = [...document.querySelectorAll("input[type='text'],input[type='date'],input:not([type])")].find((el) => /tarih/i.test((el.id || "") + " " + (el.name || "")) && !el.closest("#tm-devamsizlik-paneli,#ea-sesli"));
    const v = k && k.value || ""; let m;
    if ((m = v.match(/^(\d{4})-(\d{2})-(\d{2})/))) return m[0];
    if ((m = v.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})/))) return `${m[3]}-${ikiH(m[2])}-${ikiH(m[1])}`;
    return A.iso(new Date());
  }
  function noSutunu(table) { for (const row of table.rows) { const i = [...row.cells].findIndex((c) => /^(okul|öğrenci|ogrenci)\s*no/i.test(c.textContent.trim())); if (i >= 0) return i; } return 1; }
  function ekrandakiler() { const m = new Map();
    for (const table of document.querySelectorAll("table")) { if (table.closest("#tm-devamsizlik-paneli,#ea-sesli,#ea-surekli")) continue; const ni = noSutunu(table);
      for (const r of table.rows) { const c = r.cells; if (c.length < 9 || !/^\d+$/.test(c[0].textContent.trim())) continue;
        const kb = r.querySelectorAll("input[type='checkbox']"); const no = (c[ni] && c[ni].textContent.trim()) || ""; if (kb.length >= 5 && no) m.set(no, kb); } }
    return m; }
  function isaretle(kb) { if (kb.checked) return; kb.click(); if (!kb.checked) { kb.checked = true; kb.dispatchEvent(new Event("change", { bubbles: true })); } }
  function doldur() { // yalnız ekrandaki tarihe ait satırlar; Kaydet yok
    const E = ekrandakiler(), gun = ekranTarihi(); let n = 0, yok = 0, baska = 0;
    for (const s of satirlar) { if (s.tarih !== gun) { baska++; continue; } const kb = E.get(s.no); if (!kb) { yok++; continue; }
      isaretle(s.tur === "yarim" ? kb[1] : kb[0]); n++; }
    return { n, yok, baska, gun };
  }
  const BTN = "padding:6px 9px;border:2px solid #fff;border-radius:6px;font-weight:bold;cursor:pointer;color:#fff;font:bold 13px Segoe UI,Arial,sans-serif";
  function kur() {
    if (document.getElementById("ea-sesli") || !document.body) return;
    const k = document.createElement("div"); k.id = "ea-sesli";
    k.style.cssText = "position:fixed;right:316px;bottom:8px;z-index:2147483646;width:340px;max-height:70vh;overflow:auto;background:#0f172a;color:#fff;border:2px solid #fde047;border-radius:10px;padding:10px;font:13px Segoe UI,Arial,sans-serif;display:flex;flex-direction:column;gap:6px;cursor:default";
    k.innerHTML = `<b style="color:#fde047">🎤 Sesli / yazılı devamsızlık</b>
      <div style="color:#cbd5e1;font-size:12px">Örnek: "123 numara 3 gün", "45 ve 67 numara yarım gün", "dün 12 numara", "18 kasım 7 numara"</div>
      <textarea id="ea-sesli-metin" rows="2" placeholder="Söyleyin ya da yazın" style="font-size:15px;background:#fff;color:#000;border:2px solid #fff;border-radius:6px"></textarea>
      <div style="display:flex;gap:6px"><button type="button" id="ea-sesli-mik" style="${BTN};background:#b91c1c;flex:1">🎤 Konuş</button>
      <button type="button" id="ea-sesli-ekle" style="${BTN};background:#1e3a8a;flex:1">+ Listeye ekle</button></div>
      <div id="ea-sesli-liste" style="display:flex;flex-direction:column;gap:3px"></div>
      <div style="display:flex;gap:6px"><button type="button" id="ea-sesli-doldur" style="${BTN};background:#14532d;flex:1.4">Forma doldur (Kaydet'e basmaz)</button>
      <button type="button" id="ea-sesli-temizle" style="${BTN};background:#334155;flex:1">Listeyi temizle</button></div>
      <div id="ea-sesli-durum" style="color:#fde047;font-weight:bold;min-height:16px"></div>`;
    document.body.append(k);
    const $ = (s) => k.querySelector(s), metin = $("#ea-sesli-metin"), durum = $("#ea-sesli-durum"), liste = $("#ea-sesli-liste"), mik = $("#ea-sesli-mik");
    function ciz() { const E = ekrandakiler(); liste.innerHTML = "";
      satirlar.forEach((s, i) => { const var_ = E.size === 0 || E.has(s.no); const r = document.createElement("div");
        r.style.cssText = `display:flex;align-items:center;gap:4px;padding:3px 5px;border-radius:6px;border:2px solid ${var_ ? "#475569" : "#fff"};background:${var_ ? "#1e293b" : "#b91c1c"}`;
        const b = (t, f, ttl) => { const x = document.createElement("button"); x.type = "button"; x.textContent = t; x.title = ttl; x.style.cssText = BTN + ";background:#000;padding:2px 8px"; x.onclick = f; return x; };
        const no = document.createElement("span"); no.textContent = s.no + " no"; no.style.cssText = "font-weight:bold;min-width:58px;font-size:15px";
        const tur = document.createElement("span"); tur.textContent = s.tur === "yarim" ? "Yarım gün" : "Tam gün"; tur.style.minWidth = "66px";
        const tar = document.createElement("span"); tar.textContent = tr(s.tarih); tar.style.minWidth = "74px";
        r.append(b("−", () => { s.no = String(Math.max(1, +s.no - 1)); ciz(); }, "Numarayı azalt"), no, b("+", () => { s.no = String(+s.no + 1); ciz(); }, "Numarayı artır"),
          b("⇄", () => { s.tur = s.tur === "yarim" ? "tam" : "yarim"; ciz(); }, "Tam/Yarım değiştir"), tur, tar, b("✕", () => { satirlar.splice(i, 1); ciz(); }, "Satırı sil"));
        if (!var_) { const u = document.createElement("span"); u.textContent = "LİSTEDE YOK"; u.style.cssText = "font-weight:bold;color:#fff"; r.append(u); }
        liste.append(r); }); }
    function ekle() { const r = A.ayristir(metin.value); satirlar.push(...r.satirlar); ciz();
      durum.textContent = `${r.satirlar.length} satır eklendi` + (r.hatalar.length ? `. Anlaşılmadı: ${r.hatalar.join(" | ")}` : "") + "."; if (r.satirlar.length) metin.value = ""; }
    $("#ea-sesli-ekle").onclick = ekle;
    metin.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ekle(); } });
    $("#ea-sesli-temizle").onclick = () => { satirlar = []; ciz(); durum.textContent = "Liste temizlendi."; };
    $("#ea-sesli-doldur").onclick = () => { const r = doldur(); ciz();
      durum.textContent = `${r.n} öğrenci işaretlendi (${tr(r.gun)})` + (r.yok ? `, ${r.yok} numara bu şubede yok (kırmızı)` : "") + (r.baska ? `, ${r.baska} satır başka tarihli (o tarihi seçip tekrar doldurun)` : "") + ". Kontrol edip Kaydet'e siz basın."; };
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { mik.disabled = true; mik.style.cursor = "default"; mik.style.opacity = ".5"; mik.textContent = "🎤 Bu tarayıcıda yok"; return; }
    let tan = null;
    mik.onclick = () => { if (tan) { tan.stop(); return; }
      tan = new SR(); tan.lang = "tr-TR"; tan.interimResults = false; tan.continuous = false;
      tan.onresult = (e) => { const t = [...e.results].map((x) => x[0].transcript).join(" "); metin.value = (metin.value ? metin.value + " " : "") + t; ekle(); };
      tan.onerror = (e) => { durum.textContent = "Ses anlaşılmadı (" + e.error + "). Yazarak da girebilirsiniz."; };
      tan.onend = () => { tan = null; mik.textContent = "🎤 Konuş"; mik.style.background = "#b91c1c"; };
      mik.textContent = "⏹ Dinliyor… durdur"; mik.style.background = "#7f1d1d"; durum.textContent = "Dinliyorum…"; tan.start(); };
    new MutationObserver(() => { if (satirlar.length) { clearTimeout(kur.t); kur.t = setTimeout(ciz, 400); } }).observe(document.body, { childList: true, subtree: true });
  }
  window.__eaSesliTest = { doldur, ekrandakiler, set: (s) => { satirlar = s; } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", kur); else kur();
})();
