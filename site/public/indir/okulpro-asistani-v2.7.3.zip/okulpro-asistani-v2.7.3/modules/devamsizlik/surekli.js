// v2.3.37: Sürekli devamsızlar — yerel liste (chrome.storage) + ayrı düğme: listedeki öğrencileri ekrandaki yoklamada "Tam gün" işaretler.
// Devamsızlık modülünün kodu değişmez; bu dosya yalnız ekler. Kaydet'e basmaz; kullanıcı kontrol edip kaydeder ya da otomasyonu çalıştırır.
(function () {
  "use strict";
  if (!/OOK08001\.aspx/i.test(location.href) || window.__eaSurekli) return; window.__eaSurekli = true;
  const ANAHTAR = "surekliDevamsizlar";
  const liste = async () => ((await chrome.storage.local.get(ANAHTAR))[ANAHTAR] || []).map(String);
  function noSutunu(table) { for (const row of table.rows) { const i = [...row.cells].findIndex((c) => /^(okul|öğrenci|ogrenci)\s*no/i.test(c.textContent.trim())); if (i >= 0) return i; } return 1; }
  async function isaretle() {
    const L = new Set(await liste()); let n = 0, zaten = 0; const bulunan = new Set();
    for (const table of document.querySelectorAll("table")) { if (table.closest("#tm-devamsizlik-paneli,#ea-surekli")) continue; const ni = noSutunu(table);
      for (const tr of table.rows) { const c = tr.cells; if (c.length < 9 || !/^\d+$/.test(c[0].textContent.trim())) continue;
        const no = (c[ni] && c[ni].textContent.trim()) || ""; if (!L.has(no)) continue; const kb = tr.querySelectorAll("input[type='checkbox']"); if (kb.length < 5) continue;
        bulunan.add(no); if (kb[0].checked) { zaten++; continue; } kb[0].click(); if (!kb[0].checked) { kb[0].checked = true; kb[0].dispatchEvent(new Event("change", { bubbles: true })); } n++; } }
    const yok = [...L].filter((x) => !bulunan.has(x));
    return { n, zaten, yok };
  }
  function kur() {
    if (document.getElementById("ea-surekli")) return;
    const k = document.createElement("div"); k.id = "ea-surekli";
    k.style.cssText = "position:fixed;right:8px;bottom:8px;z-index:2147483646;width:300px;background:#0f172a;color:#fff;border:2px solid #fde047;border-radius:10px;padding:10px;font:13px Segoe UI,Arial,sans-serif;display:flex;flex-direction:column;gap:6px";
    k.innerHTML = `<b style="color:#fde047">Sürekli devamsızlar</b>
      <textarea id="ea-surekli-liste" rows="2" placeholder="Okul numaraları (boşluk/virgül)" style="font-size:15px;background:#fff;color:#000;border:2px solid #fff;border-radius:6px"></textarea>
      <div style="display:flex;gap:6px"><button type="button" id="ea-surekli-kaydet" style="flex:1;padding:7px;background:#1e3a8a;color:#fff;border:2px solid #fff;border-radius:6px;font-weight:bold;cursor:pointer">Listeyi kaydet</button>
      <button type="button" id="ea-surekli-isaretle" style="flex:1.4;padding:7px;background:#b91c1c;color:#fff;border:2px solid #fff;border-radius:6px;font-weight:bold;cursor:pointer">Yoklamada işaretle</button></div>
      <div id="ea-surekli-durum" style="color:#fde047;font-weight:bold;min-height:16px"></div>`;
    document.body.append(k);
    const ta = k.querySelector("#ea-surekli-liste"), durum = k.querySelector("#ea-surekli-durum");
    liste().then((l) => { ta.value = l.join(" "); });
    k.querySelector("#ea-surekli-kaydet").onclick = async () => { const l = [...new Set(ta.value.split(/[^0-9]+/).filter(Boolean))]; await chrome.storage.local.set({ [ANAHTAR]: l }); ta.value = l.join(" "); durum.textContent = `${l.length} öğrenci kaydedildi (yalnız bu bilgisayarda).`; };
    k.querySelector("#ea-surekli-isaretle").onclick = async () => { const r = await isaretle();
      durum.textContent = `${r.n} öğrenci Tam gün işaretlendi` + (r.zaten ? `, ${r.zaten} zaten işaretliydi` : "") + (r.yok.length ? `. Bu şubede yok: ${r.yok.join(", ")}` : "") + ". Kontrol edip kaydedin."; };
  }
  window.__eaSurekliTest = { isaretle };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", kur); else kur();
})();
