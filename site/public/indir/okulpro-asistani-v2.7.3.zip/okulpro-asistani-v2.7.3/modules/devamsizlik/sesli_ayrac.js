// v2.3.40: Sesli/yazılı devamsızlık komutu ayrıştırıcı (saf işlev, ağ yok, veri yerel).
// "123 numara 3 gün", "45 ve 67 numara yarım gün", "dün 12 numara", "18 kasım 7 numara", "yüz yirmi üç numara iki gün"
(function (kok) {
  "use strict";
  const BIR = { sıfır: 0, bir: 1, iki: 2, üç: 3, dört: 4, beş: 5, altı: 6, yedi: 7, sekiz: 8, dokuz: 9 };
  const ON = { on: 10, yirmi: 20, otuz: 30, kırk: 40, elli: 50, altmış: 60, yetmiş: 70, seksen: 80, doksan: 90 };
  const AY = { ocak: 1, şubat: 2, mart: 3, nisan: 4, mayıs: 5, haziran: 6, temmuz: 7, ağustos: 8, eylül: 9, ekim: 10, kasım: 11, aralık: 12 };
  const kucuk = (s) => String(s).replace(/I/g, "ı").replace(/İ/g, "i").toLowerCase();
  // sözcükle sayıları rakama çevir: "yüz yirmi üç" → 123, "bin iki yüz" → 1200
  function sayilar(metin) {
    const t = kucuk(metin).replace(/[.,;:!?]+(?=\s|$)/g, " ").replace(/(\d)\.(?=\s|$)/g, "$1").split(/\s+/).filter(Boolean);
    const cik = []; let top = 0, ara = 0, var_ = false;
    const bitir = () => { if (var_) cik.push(String(top + ara)); top = 0; ara = 0; var_ = false; };
    for (const w of t) {
      if (w in BIR) { ara += BIR[w]; var_ = true; }
      else if (w in ON) { ara += ON[w]; var_ = true; }
      else if (w === "yüz") { ara = (ara || 1) * 100; var_ = true; }
      else if (w === "bin") { top += (ara || 1) * 1000; ara = 0; var_ = true; }
      else { bitir(); cik.push(w); }
    }
    bitir(); return cik;
  }
  const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  function gunEkle(d, n) { const x = new Date(d); x.setDate(x.getDate() + n); return x; }
  function isGunu(d, n, yon) { // n okul günü (hafta sonu atlanır)
    const c = []; let x = new Date(d); while (c.length < n) { if (x.getDay() % 6) c.push(iso(x)); x = gunEkle(x, yon); } return c; }
  // ana işlev: komut → [{no, tur:"tam"|"yarim", tarih:"YYYY-MM-DD"}]
  function ayristir(metin, bugun) {
    bugun = bugun ? new Date(bugun) : new Date(); bugun.setHours(12, 0, 0, 0);
    const satirlar = [], hatalar = [];
    const parcalar = kucuk(metin).split(/\s*(?:\n|;|\bsonra\b|\bayrıca\b)\s*/).map((x) => sayilar(x).join(" ")).filter((s) => s.trim());
    let tarihOrtak = null;
    for (const p of parcalar) {
      let s = " " + p + " ", tarih = null, m;
      if (/\bevvelsi gün\b|\bönceki gün\b/.test(s)) { tarih = gunEkle(bugun, -2); s = s.replace(/\b(evvelsi|önceki) gün\b/, " "); }
      else if (/\bdün\b/.test(s)) { tarih = gunEkle(bugun, -1); s = s.replace(/\bdün\b/, " "); }
      else if (/\bbugün\b/.test(s)) { tarih = bugun; s = s.replace(/\bbugün\b/, " "); }
      if ((m = s.match(/\b(\d{1,2})[./](\d{1,2})(?:[./](\d{2,4}))?\b/))) { const y = m[3] ? (+m[3] < 100 ? 2000 + +m[3] : +m[3]) : bugun.getFullYear(); tarih = new Date(y, +m[2] - 1, +m[1], 12); s = s.replace(m[0], " "); }
      else { const ayRe = new RegExp(`\\b(\\d{1,2})\\s+(${Object.keys(AY).join("|")})(?:'?[a-zçğıöşü]*)?(?:\\s+(\\d{4}))?\\b`);
        if ((m = s.match(ayRe))) { let y = m[3] ? +m[3] : bugun.getFullYear(); const d0 = new Date(y, AY[m[2]] - 1, +m[1], 12); if (!m[3] && d0 - bugun > 7 * 864e5) d0.setFullYear(y - 1); tarih = d0; s = s.replace(m[0], " "); } }
      if (tarih) tarihOrtak = tarih; else tarih = tarihOrtak || bugun;
      const yarim = /\byarım\b/.test(s); s = s.replace(/\byarım\b/g, " ").replace(/\btam\b/g, " ");
      let gun = 1; if ((m = s.match(/\b(\d{1,2})\s*gün\b/))) { gun = +m[1]; s = s.replace(m[0], " "); } s = s.replace(/\bgün(lük)?\b/g, " ");
      const nolar = (s.match(/\b\d{1,5}\b/g) || []).filter((x) => +x > 0);
      if (!nolar.length) { if (p.trim()) hatalar.push(p.trim()); continue; }
      if (gun < 1 || gun > 30) { hatalar.push(p.trim()); continue; }
      if (tarih.getDay() % 6 === 0) { hatalar.push(p.trim() + " (hafta sonu)"); continue; }
      for (const no of nolar) for (const t of isGunu(tarih, gun, 1)) satirlar.push({ no, tur: yarim ? "yarim" : "tam", tarih: t });
    }
    return { satirlar, hatalar };
  }
  const api = { ayristir, sayilar, iso };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else kok.__eaSesliAyrac = api;
})(typeof window !== "undefined" ? window : globalThis);
