// Devamsızlık (yoklama) modülünü başlatıcıya sekme olarak kaydeder.
// Asıl yoklama paneli MAIN dünyasında (content.js) çalışır; bu sekme onu açar/kapatır.
EOA.modulKaydet({
  id: "devamsizlik", ad: "Devamsızlık", simge: "⏱", sira: 9, // v2.3.43: sekme sırası Devamsızlık · Rapor · Veli İzni · Faaliyet
  kur(alan) {
    alan.innerHTML = `<div class="panelkok">
      <h2>Günlük yoklama işaretleme</h2>
      <p class="not">Okul ayarlarındaki şube listesini sırayla açar, ders yoklamalarına göre Tam gün / Sabah / Öğle / Geç kutularını mevzuata göre işaretler ve kaydeder.</p>
      <p><b id="dvSube">…</b> şube tanımlı.</p>
      <button class="ana" id="dvAc">Yoklama panelini aç / kapat</button>
      <button id="dvAyar">Şube listesini düzenle</button>
      <p class="not">Yoklama paneli sayfanın sağ kenarında açılır. Rapor otomasyonu çalışırken başlatılamaz.</p></div>`;
    alan.querySelector("#dvAc").onclick = () => window.postMessage({ kaynak: "tm-kopru", tip: "panelDegistir" }, "*");
    alan.querySelector("#dvAyar").onclick = () => chrome.runtime.sendMessage({ tip: "okulAyarlariAc" });
    const say = async () => { const p = await OkulProfil.profilOku(); alan.querySelector("#dvSube").textContent = p.siniflar.length; };
    say(); chrome.storage.onChanged.addListener((c) => { if (c.okulProfili) say(); });
  },
});
