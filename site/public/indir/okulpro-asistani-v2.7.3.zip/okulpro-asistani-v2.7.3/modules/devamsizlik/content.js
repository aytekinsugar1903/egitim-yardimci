(function () {
  'use strict';

  // v2.6.0: okula özgü varsayılan şube listesi yok — şubeler Okul Ayarları’ndan gelir
  const DEFAULT_TARGET_CLASSES = [];

  function getActiveTargetClasses() {
    const custom = localStorage.getItem("tm_custom_target_classes");
    if (custom) {
      try {
        const parsed = JSON.parse(custom);
        if (Array.isArray(parsed)) return parsed; // [PAKET] boş liste de geçerli (okul profili)
      } catch (e) {}
    }
    return DEFAULT_TARGET_CLASSES;
  }

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function isGirisPage() {
    return window.location.href.toLowerCase().includes("giris.aspx");
  }

  function isAttendancePage() {
    return window.location.href.includes("OOK08001.aspx");
  }

  function getElements() {
    const classSelect = document.getElementById("Us_SinifSube1_ddlSinifSube")
      || document.querySelector("select[name*='ddlSinifSube']");
    const listeleBtn = document.querySelector("input[value='Listele'], button[id*='Listele'], input[id*='btnListele'], #btnListele");

    const saveImg = Array.from(document.querySelectorAll("img, a, input, button")).find((el) => {
      const oc = el.getAttribute("onclick") || "";
      const src = el.getAttribute("src") || "";
      return oc.includes("AlanKontrolveKayit") || src.toLowerCase().includes("kaydet");
    });

    return { classSelect, listeleBtn, saveImg };
  }

  // =============================================================
  // 1. ARAYÜZ (GÖSTERGE & ŞUBE DÜZENLEME PANELİ)
  // =============================================================
  if (document.getElementById("tm-devamsizlik-paneli")) return;

  const panel = document.createElement("div");
  panel.id = "tm-devamsizlik-paneli";
  panel.style.cssText = `
    position: fixed !important; top: 10% !important; right: 0 !important;
    z-index: 2147483647 !important; display: flex !important; align-items: flex-start !important;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
  `;

  const tabBtn = document.createElement("div");
  tabBtn.innerHTML = `<span>⚡</span> <span>YOKLAMA ASİSTANI</span>`;
  tabBtn.style.cssText = `
    background: linear-gradient(180deg, #1e40af, #2563eb) !important;
    color: #fff !important; padding: 14px 10px !important;
    writing-mode: vertical-rl !important; text-orientation: mixed !important;
    font-weight: 700 !important; font-size: 13px !important; letter-spacing: 1px !important;
    cursor: pointer !important; border-radius: 10px 0 0 10px !important;
    box-shadow: -4px 4px 14px rgba(0,0,0,0.3) !important; user-select: none !important;
    display: flex !important; align-items: center !important; gap: 6px !important;
  `;

  const box = document.createElement("div");
  box.style.cssText = `
    width: 340px !important; background: #fff !important; border: 1px solid #e2e8f0 !important;
    border-right: none !important; border-radius: 0 0 0 14px !important; padding: 16px !important;
    box-shadow: -8px 8px 24px rgba(15, 23, 42, 0.15) !important; display: none;
    flex-direction: column !important; gap: 10px !important;
  `;

  const activeClasses = getActiveTargetClasses();

  box.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom: 1px solid #f1f5f9; padding-bottom: 6px;">
      <span style="font-weight:700; font-size:14px; color:#0f172a;">Devamsızlık Otomasyonu</span>
      <span id="tm-badge-count" style="font-size:11px; font-weight:600; background:#e0e7ff; color:#3730a3; padding:2px 8px; border-radius:12px;">${activeClasses.length} Şube</span>
    </div>

    <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:10px;">
      <div style="display:flex; justify-content:space-between; font-size:11px; color:#64748b; font-weight:600; margin-bottom:4px;">
        <span>ŞU ANKİ ŞUBE:</span>
        <span id="tm-progress-text">0 / ${activeClasses.length}</span>
      </div>
      <div id="tm-active-class" style="font-size:12px; font-weight:700; color:#1e293b; min-height:18px; word-break:break-word;">
        İşlem bekleniyor...
      </div>
      <div id="tm-active-status" style="font-size:11px; color:#0284c7; margin-top:3px; font-weight:600;">
        Hazır
      </div>
      <div style="width:100%; height:6px; background:#e2e8f0; border-radius:3px; margin-top:8px; overflow:hidden;">
        <div id="tm-progress-bar" style="width:0%; height:100%; background:#2563eb; transition:width 0.3s ease;"></div>
      </div>
    </div>

    <div style="display:flex; justify-content:space-between; align-items:center;">
      <label style="font-size:12px; color:#475569; font-weight:600;">Günlük Ders Saati:</label>
      <input type="number" id="tm-daily-hours" value="10" min="6" max="14" style="width:55px; padding:4px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px; text-align:center; font-weight:bold;" />
    </div>

    <div id="tm-tarih-satir" style="display:flex; justify-content:space-between; align-items:center; background:#0f172a; border-radius:8px; padding:6px 8px;">
      <label style="font-size:12px; color:#fff; font-weight:700;">Yoklama Tarihi:</label>
      <span style="display:flex; align-items:center;">
        <button type="button" id="tm-tarih-geri" title="Bir gün geri" style="min-width:30px;height:30px;margin:0 3px;font-size:18px;font-weight:bold;background:#9b1c1c;color:#fff;border:0;border-radius:6px;cursor:pointer">−</button>
        <span id="tm-tarih-yazi" style="min-width:138px; text-align:center; font-size:13px; font-weight:800; color:#fde047;"></span>
        <button type="button" id="tm-tarih-ileri" title="Bir gün ileri (en çok bugün)" style="min-width:30px;height:30px;margin:0 3px;font-size:18px;font-weight:bold;background:#1b7f3b;color:#fff;border:0;border-radius:6px;cursor:pointer">+</button>
      </span>
    </div>

    <button id="tm-btn-start" style="padding:10px; background:#2563eb; color:#fff; border:none; border-radius:8px; font-weight:700; cursor:pointer; font-size:13px;">
      Otomasyonu Başlat
    </button>

    <button id="tm-btn-open-settings" style="padding:6px; background:#f1f5f9; color:#334155; border:1px solid #cbd5e1; border-radius:6px; font-weight:600; cursor:pointer; font-size:11px;">
      ⚙️ Okul Ayarları (Şube Listesi)
    </button>

    <button id="tm-btn-velikapi" style="padding:8px; background:#059669; color:#fff; border:none; border-radius:8px; font-weight:700; cursor:pointer; font-size:12px;">
      📨 Veli Asistanı'na gönder
    </button>

    <button id="tm-btn-stop" style="padding:7px; background:#ef4444; color:#fff; border:none; border-radius:8px; font-weight:700; cursor:pointer; font-size:12px; display:none;">
      İşlemi Durdur
    </button>

    <div style="font-size:11px; font-weight:700; color:#475569;">İşlem Akış Günlüğü:</div>
    <div id="tm-log-list" style="font-size:11px; color:#334155; background:#0f172a; padding:10px; border-radius:8px; height:120px; overflow-y:auto; font-family:Consolas, monospace; line-height:1.4;">
      <div style="color:#94a3b8;">> Sistem hazır. Başlat butonuna basabilirsiniz.</div>
    </div>
  `;

  tabBtn.style.setProperty("display", "none", "important"); // [PAKET] tek başlatıcı: panel, başlatıcının Devamsızlık sekmesinden açılır
  panel.appendChild(tabBtn);
  panel.appendChild(box);
  document.body.appendChild(panel);

  let isOpen = false;
  tabBtn.onclick = () => {
    isOpen = !isOpen;
    box.style.display = isOpen ? "flex" : "none";
  };

  const logList = box.querySelector("#tm-log-list");
  const stopBtn = box.querySelector("#tm-btn-stop");
  const activeClassEl = box.querySelector("#tm-active-class");
  const activeStatusEl = box.querySelector("#tm-active-status");
  const progressTextEl = box.querySelector("#tm-progress-text");
  const progressBarEl = box.querySelector("#tm-progress-bar");
  const badgeCountEl = box.querySelector("#tm-badge-count");

  // v2.3.35: Yoklama tarihi seçimi (Bugün … 5 gün önce). Varsayılan bugün → eski davranış aynen.
  const TM_GUN_MAX = 5;
  function tmGunOfset() { const n = parseInt(sessionStorage.getItem("tm_gun_ofset") || "0", 10); return n >= 0 && n <= TM_GUN_MAX ? n : 0; }
  function tmSecilenGun() { const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() - tmGunOfset()); return d; }
  const tmIki = (n) => String(n).padStart(2, "0");
  function tmIso(d) { return `${d.getFullYear()}-${tmIki(d.getMonth() + 1)}-${tmIki(d.getDate())}`; }
  function tmTr(d) { return `${tmIki(d.getDate())}.${tmIki(d.getMonth() + 1)}.${d.getFullYear()}`; }
  function tmTarihYaz() {
    const o = tmGunOfset(), ad = o === 0 ? "Bugün" : o === 1 ? "Dün" : `${o} gün önce`;
    const y = box.querySelector("#tm-tarih-yazi"); if (y) y.textContent = `${ad} (${tmTr(tmSecilenGun())})`;
    const g = box.querySelector("#tm-tarih-geri"), i = box.querySelector("#tm-tarih-ileri");
    if (g) { g.disabled = o >= TM_GUN_MAX; g.style.opacity = g.disabled ? "0.4" : "1"; }
    if (i) { i.disabled = o <= 0; i.style.opacity = i.disabled ? "0.4" : "1"; }
  }
  function tmOfsetDegis(d) {
    if (sessionStorage.getItem("tm_running") === "true") return; // çalışırken tarih değişmez
    const n = Math.min(TM_GUN_MAX, Math.max(0, tmGunOfset() + d));
    sessionStorage.setItem("tm_gun_ofset", String(n)); tmTarihYaz();
  }
  box.querySelector("#tm-tarih-geri").onclick = () => tmOfsetDegis(1);
  box.querySelector("#tm-tarih-ileri").onclick = () => tmOfsetDegis(-1);
  tmTarihYaz();
  // e-Okul yoklama ekranındaki tarih kutusu: kullanıcı gibi yazılır (değer + input/change/blur olayları)
  function tmTarihKutusu() {
    const adaylar = Array.from(document.querySelectorAll("input[type='text'], input[type='date'], input:not([type])"))
      .filter((el) => /tarih/i.test((el.id || "") + " " + (el.name || "")) && !el.closest("#tm-devamsizlik-paneli"));
    return adaylar[0] || null;
  }
  function tmTarihUygula() {
    const k = tmTarihKutusu(), d = tmSecilenGun();
    if (!k) { if (tmGunOfset() > 0) log("⚠️ e-Okul tarih kutusu bulunamadı; tarihi ekranda elle seçin.", { color: "#f87171" }); return false; }
    const hedef = k.type === "date" ? tmIso(d) : tmTr(d).replace(/\./g, "/");
    if (k.value === hedef) return true;
    k.focus(); k.value = hedef;
    ["input", "change", "blur"].forEach((t) => k.dispatchEvent(new Event(t, { bubbles: true })));
    log(`📅 e-Okul tarihi ${tmTr(d)} yapıldı.`, { color: "#fde047" });
    return true;
  }

  // [PAKET] Şube listesi artık "Okul ayarları" sayfasında (+/− ile) düzenlenir; köprü (kopru.js) chrome.storage <-> localStorage eşitler.
  const openSettingsBtn = box.querySelector("#tm-btn-open-settings");
  const kopruGonder = (tip, veri) => window.postMessage({ kaynak: "tm-ana", tip, veri }, "*");
  openSettingsBtn.onclick = () => kopruGonder("ayarlarAc");
  const kopruBekleyen = {};
  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data.kaynak !== "tm-kopru") return;
    if (e.data.tip === "panelDegistir") tabBtn.onclick(); // [PAKET] başlatıcıdaki Devamsızlık sekmesinden aç/kapat
    if (e.data.tip === "siniflarGuncel") badgeCountEl.innerText = `${getActiveTargetClasses().length} Şube`;
    if (e.data.tip === "kilitYanit" && kopruBekleyen.kilit) { kopruBekleyen.kilit(e.data.veri); delete kopruBekleyen.kilit; }
  });
  function kilitIste() {
    return new Promise((coz) => {
      kopruBekleyen.kilit = coz;
      kopruGonder("kilitIste");
      setTimeout(() => { if (kopruBekleyen.kilit) { delete kopruBekleyen.kilit; coz({ ok: false, mesaj: "Eklenti köprüsü yanıt vermedi; sayfayı yenileyin (F5)." }); } }, 3000);
    });
  }
  // Çalışırken kilidi tazele (sayfa geçişlerinde de)
  setInterval(() => { if (sessionStorage.getItem("tm_running") === "true") kopruGonder("kilitTazele"); }, 5000);

  function log(text, opts = {}) {
    const item = document.createElement("div");
    item.style.color = opts.color || "#38bdf8";
    item.innerText = `> ${text}`;
    logList.appendChild(item);
    logList.scrollTop = logList.scrollHeight;

    if (opts.targetName) activeClassEl.innerText = opts.targetName;
    if (opts.statusText) {
      activeStatusEl.innerText = opts.statusText;
      activeStatusEl.style.color = opts.color || "#0284c7";
    }
    if (opts.current !== undefined && opts.total) {
      progressTextEl.innerText = `${opts.current} / ${opts.total}`;
      progressBarEl.style.width = `${Math.round((opts.current / opts.total) * 100)}%`;
    }
  }

  // =============================================================
  // 2. GİRİŞ SAYFASI BUTONU TETİKLEMESİ (#mdlOOK)
  // =============================================================
  async function handleGirisClick() {
    log("Kurum İşlemleri (mdlOOK) açılıyor...", { color: "#38bdf8" });
    await sleep(400);

    const mdlOOK = document.getElementById("mdlOOK");
    if (mdlOOK) {
      log("Kurum İşlemleri tıklandı...", { color: "#22c55e" });
      mdlOOK.click();
    } else {
      window.location.href = `${window.location.origin}/OrtaOgretim/OKL/OOK00001.aspx`;
    }
  }

  // =============================================================
  // 3. BAŞLAT / DURDUR & ÇALIŞTIRICI MOTOR
  // =============================================================
  box.querySelector("#tm-btn-start").onclick = async () => {
    // [PAKET] Aynı anda tek otomasyon: rapor otomasyonu çalışıyorsa başlatma
    const k = await kilitIste();
    if (!k.ok) { log(k.mesaj, { color: "#ef4444", statusText: "Başlatılamadı" }); return; }
    const dailyHours = parseInt(box.querySelector("#tm-daily-hours").value, 10) || 10;
    sessionStorage.setItem("tm_daily_hours", dailyHours);
    sessionStorage.setItem("tm_running", "true");

    stopBtn.style.display = "block";
    logList.innerHTML = "";

    if (isGirisPage()) {
      handleGirisClick();
      return;
    }

    if (!isAttendancePage()) {
      log("Devamsızlık giriş sayfasına yönlendiriliyor...", { color: "#38bdf8" });
      window.location.href = `${window.location.origin}/OrtaOgretim/OKL/OOK08001.aspx`;
      return;
    }

    startQueue();
  };

  function startQueue() {
    const { classSelect } = getElements();
    if (!classSelect) {
      log("Sınıf seçim kutusu bekleniyor...", { color: "#fbbf24" });
      setTimeout(startQueue, 1000);
      return;
    }

    const targetList = getActiveTargetClasses();
    if (targetList.length === 0) { // [PAKET]
      log("Şube listesi boş! Okul Ayarları'ndan şube ekleyin.", { color: "#ef4444" });
      sessionStorage.removeItem("tm_running"); stopBtn.style.display = "none"; kopruGonder("kilitBirak");
      return;
    }
    const available = Array.from(classSelect.options);
    const queue = [];

    for (let t of targetList) {
      const cleanT = t.replace(/\s+/g, " ").trim().toUpperCase();
      const found = available.find((o) => o.text.replace(/\s+/g, " ").trim().toUpperCase().includes(cleanT));
      if (found && found.value !== "") {
        queue.push({ value: found.value, text: t });
      }
    }

    if (queue.length === 0) {
      log("Girilen şubeler sayfadaki seçeneklerle eşleşmedi!", { color: "#ef4444" });
      sessionStorage.removeItem("tm_running"); stopBtn.style.display = "none"; kopruGonder("kilitBirak"); // [PAKET]
      return;
    }

    sessionStorage.setItem("tm_queue", JSON.stringify(queue));
    sessionStorage.setItem("tm_index", "0");
    sessionStorage.setItem("tm_phase", "SELECT");

    log(`Toplam ${queue.length} şube sıraya alındı. Başlanıyor...`, {
      color: "#22c55e",
      statusText: "Sıra hazır",
      current: 0,
      total: queue.length
    });

    runNextStep();
  }

  stopBtn.onclick = () => {
    sessionStorage.removeItem("tm_running");
    sessionStorage.removeItem("tm_queue");
    sessionStorage.removeItem("tm_index");
    sessionStorage.removeItem("tm_phase");
    stopBtn.style.display = "none";
    kopruGonder("kilitBirak"); // [PAKET]
    log("İşlem durduruldu.", { color: "#ef4444", statusText: "Durduruldu" });
  };

  if (sessionStorage.getItem("tm_running") === "true") {
    box.style.display = "flex";
    isOpen = true;
    stopBtn.style.display = "block";

    if (isGirisPage()) {
      setTimeout(handleGirisClick, 1000);
    } else if (!isAttendancePage()) {
      setTimeout(() => {
        window.location.href = `${window.location.origin}/OrtaOgretim/OKL/OOK08001.aspx`;
      }, 1000);
    } else {
      if (!sessionStorage.getItem("tm_queue")) {
        setTimeout(startQueue, 1500);
      } else {
        setTimeout(runNextStep, 1500);
      }
    }
  }

  async function runNextStep() {
    if (sessionStorage.getItem("tm_running") !== "true") return;

    const rawQueue = sessionStorage.getItem("tm_queue");
    if (!rawQueue) return;

    const queue = JSON.parse(rawQueue);
    let index = parseInt(sessionStorage.getItem("tm_index") || "0", 10);

    if (index >= queue.length) {
      sessionStorage.removeItem("tm_running");
      sessionStorage.removeItem("tm_queue");
      sessionStorage.removeItem("tm_index");
      sessionStorage.removeItem("tm_phase");
      kopruGonder("kilitBirak"); // [PAKET]

      log("🎉 TÜM ŞUBELER BAŞARIYLA İŞLENDİ VE ONAYLANDI!", {
        color: "#22c55e",
        targetName: "TAMAMLANDI",
        statusText: "Tüm şubeler bitti ✅",
        current: queue.length,
        total: queue.length
      });
      return;
    }

    const current = queue[index];
    let phase = sessionStorage.getItem("tm_phase") || "SELECT";
    const { classSelect, listeleBtn, saveImg } = getElements();

    if (phase === "SELECT") {
      log(`[${index + 1}/${queue.length}] Seçiliyor: ${current.text}`, {
        targetName: current.text,
        statusText: "Şube seçiliyor & Listeleniyor...",
        current: index + 1,
        total: queue.length,
        color: "#38bdf8"
      });

      if (classSelect) {
        classSelect.value = current.value;
      }
      if (tmGunOfset() > 0) tmTarihUygula(); // v2.3.35: bugün seçiliyse e-Okul tarih kutusuna dokunulmaz

      await sleep(800);

      if (listeleBtn) {
        sessionStorage.setItem("tm_phase", "PROCESS_AND_SAVE");
        listeleBtn.click();
      } else {
        log("Listele butonu bulunamadı!", { color: "#ef4444" });
      }
      return;
    }

    if (phase === "PROCESS_AND_SAVE") {
      const dailyHours = parseInt(sessionStorage.getItem("tm_daily_hours"), 10) || 10;

      log(`Tablo taranıyor: ${current.text}`, {
        targetName: current.text,
        statusText: "Yoklamalar taranıyor...",
        current: index + 1,
        total: queue.length,
        color: "#fbbf24"
      });

      await sleep(2000);

      const count = applyRegulationAttendance(dailyHours);
      try { vkSayfayiTara(); } catch (e) {} // [VELİDUY] salt okunur, taramadan bağımsız

      log(`-> ${count} öğrenci devamsızlığı işaretlendi.`, {
        targetName: current.text,
        statusText: `${count} öğrenci işlendi, kaydediliyor...`,
        current: index + 1,
        total: queue.length,
        color: "#a78bfa"
      });

      await sleep(1500);

      window.confirm = () => true;
      window.alert = () => true;

      sessionStorage.setItem("tm_index", index + 1);
      sessionStorage.setItem("tm_phase", "SELECT");

      log(`💾 Kaydediliyor: ${current.text}`, {
        targetName: current.text,
        statusText: "Kayıt fonksiyonu çalıştırılıyor...",
        current: index + 1,
        total: queue.length,
        color: "#4ade80"
      });

      await sleep(500);

      if (typeof window.AlanKontrolveKayit === "function") {
        window.AlanKontrolveKayit();
      } else if (saveImg) {
        saveImg.click();
      } else if (typeof window.__doPostBack === "function") {
        window.__doPostBack('btnKaydet', '');
      }
    }
  }


  // =============================================================
  // [VELİDUY] Bugünkü devamsız listesini Veli Asistanı'na gönderme
  // Yalnızca okul no + şube + tür + tarih gönderilir; ad/TC gönderilmez.
  // Asla otomatik gönderilmez: yalnızca "Veli Asistanı'na gönder" tıklamasıyla.
  // =============================================================
  const vkOnay = window.confirm.bind(window); // otomasyon window.confirm'u ezdiği için asıl onay kutusu saklanır
  function vkBugun() { return tmIso(tmSecilenGun()); } // v2.3.35: seçilen yoklama tarihi (varsayılan bugün)
  function vkTurBul(missedHours, halfDayLimit) {
    if (missedHours.length > halfDayLimit) return "gelmedi";
    const sabah = missedHours.filter((h) => h <= halfDayLimit).length, ogle = missedHours.length - sabah;
    if (sabah && !ogle) return missedHours.length === 1 && missedHours[0] === 1 ? "geç kaldı" : "sabah";
    if (ogle && !sabah) return "öğleden sonra";
    return "sabah";
  }
  const vkNoCache = new WeakMap();
  function vkNoSutunu(tr) { // tablo başına bir kez; textContent (reflow yok)
    const table = tr.closest("table");
    if (!table) return -1;
    if (vkNoCache.has(table)) return vkNoCache.get(table);
    let idx = -1;
    for (const row of table.rows) {
      const hs = Array.from(row.cells).map((c) => c.textContent.trim().toLocaleLowerCase("tr-TR"));
      const i = hs.findIndex((t) => /^(okul|öğrenci|ogrenci)\s*no/.test(t));
      if (i >= 0) { idx = i; break; }
    }
    vkNoCache.set(table, idx);
    return idx;
  }
  function vkOgrenciNo(tr, cells) {
    const i = vkNoSutunu(tr);
    if (i >= 0 && cells[i] && /^\d+$/.test(cells[i].textContent.trim())) return cells[i].textContent.trim();
    if (cells[1] && /^\d{1,8}$/.test(cells[1].textContent.trim())) return cells[1].textContent.trim();
    return cells[0].textContent.trim();
  }
  function vkSubeAdi() {
    const sel = document.getElementById("Us_SinifSube1_ddlSinifSube") || document.querySelector("select[name*='ddlSinifSube']");
    return sel && sel.selectedIndex >= 0 ? sel.options[sel.selectedIndex].text.trim() : "";
  }
  function vkListeOku() {
    try { const l = JSON.parse(sessionStorage.getItem("tm_vk_liste") || "null"); if (l && l.date === vkBugun()) return l; } catch (e) {}
    return { date: vkBugun(), entries: {} };
  }
  function vkKaydet(tr, cells, _tur, missedHours, halfDayLimit) {
    try {
      const no = vkOgrenciNo(tr, cells);
      if (!/^\d+$/.test(no)) return;
      const l = vkListeOku();
      const sinif = vkSubeAdi();
      l.entries[`${sinif}|${no}`] = { ogrenciNo: no, sinif, tur: vkTurBul(missedHours, halfDayLimit) };
      sessionStorage.setItem("tm_vk_liste", JSON.stringify(l));
    } catch (e) {}
  }
  function vkSayfayiTara() { // otomasyon çalıştırılmadan, ekranda listelenen şubeyi de ekle (kutulara dokunmaz)
    if (!isAttendancePage()) return;
    const dailyHours = parseInt((box.querySelector("#tm-daily-hours") || {}).value, 10) || 10;
    const half = Math.floor(dailyHours / 2);
    document.querySelectorAll("table tr").forEach((tr) => {
      const cells = tr.querySelectorAll("td");
      if (cells.length < 9 || !/^\d+$/.test(cells[0].textContent.trim())) return;
      const t = cells[cells.length - 1].textContent.trim();
      const hours = (t.match(/(\d+)\.Ders/gi) || []).map((m) => parseInt(m.replace(/\D/g, ""), 10)).filter((n) => n > 0 && n <= dailyHours);
      if (hours.length) vkKaydet(tr, cells, null, hours, half);
    });
  }
  const vkBtn = box.querySelector("#tm-btn-velikapi");
  if (vkBtn) vkBtn.onclick = () => {
    vkSayfayiTara();
    const l = vkListeOku();
    const entries = Object.values(l.entries);
    if (!entries.length) { log("Veli Asistanı: seçilen tarih için devamsız listesi yok. Önce otomasyonu çalıştırın veya şubeyi listeleyin.", { color: "#f87171" }); return; }
    const subeSay = new Set(entries.map((e) => e.sinif)).size;
    if (!vkOnay(`${l.date} tarihli ${entries.length} öğrenci (${subeSay} şube) Veli Asistanı'na gönderilsin mi?\n\nGönderilen: yalnızca okul no, şube, devamsızlık türü ve tarih.\nEşleşen öğrencilerin velilerine bildirim gider.`)) return;
    vkBtn.disabled = true; vkBtn.textContent = "Gönderiliyor…";
    kopruGonder("vkGonder", { date: l.date, entries });
  };
  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data.kaynak !== "tm-kopru" || e.data.tip !== "vkSonuc") return;
    if (!vkBtn) return;
    vkBtn.disabled = false; vkBtn.textContent = "📨 Veli Asistanı'na gönder";
    const r = e.data.veri || {};
    if (!r.ok) { log(`Veli Asistanı hatası: ${r.hata || "bilinmeyen"}`, { color: "#f87171" }); return; }
    const d = r.sonuc;
    log(`✅ Veli Asistanı: ${d.created} yeni devamsızlık, ${d.notifiedParents} veliye bildirim gitti. ${d.alreadyRecorded} zaten kayıtlıydı, ${d.unmatched} eşleşmedi.`, { color: "#22c55e" });
    if (d.unmatched) log(`Eşleşmeyen okul no: ${d.unmatchedList.map((u) => u.ogrenciNo).join(", ")}`, { color: "#fbbf24" });
  });

  // =============================================================
  // 4. MEVZUAT VE KUTUCUK İŞARETLEME MOTORU
  // =============================================================
  // v2.4.8: Hangi kutu işaretlenir? (saf işlev; test/devamsizlik_kural.test.js ile sınanır)
  //  - Kaçırılan ders sayısı günün yarısından fazlaysa  -> "tam"  (Tam gün)
  //  - Gün içinde YALNIZ 1 ders kaçırılmışsa (hangi ders olursa olsun) -> "gec"  (Geç); sabah / öğleden sonra yarım gün DEĞİL
  //  - Birden çok ders: yalnız ilk yarıda -> "sabah"; yalnız ikinci yarıda -> "ogle"; iki yarıya da dağılmışsa -> "sabah"
  function devamsizlikKutusu(missedHours, halfDayLimit) {
    const n = missedHours.length;
    if (n > halfDayLimit) return "tam";
    if (n === 1) return "gec";
    const sabah = missedHours.filter((h) => h <= halfDayLimit).length;
    const ogle = n - sabah;
    if (ogle > 0 && sabah === 0) return "ogle";
    return "sabah";
  }

  function applyRegulationAttendance(dailyHours) {
    const halfDayLimit = Math.floor(dailyHours / 2);
    const rows = document.querySelectorAll("table tr");
    let changed = 0;

    rows.forEach((tr) => {
      const cells = tr.querySelectorAll("td");
      if (cells.length < 9) return;

      const firstCell = cells[0].innerText.trim();
      if (!/^\d+$/.test(firstCell)) return;

      const teacherCell = cells[cells.length - 1];
      const teacherText = teacherCell ? teacherCell.innerText.trim() : "";

      if (!teacherText || teacherText === "" || !teacherText.includes("Ders")) {
        return;
      }

      const matches = teacherText.match(/(\d+)\.Ders/gi);
      if (!matches || matches.length === 0) {
        return;
      }

      const missedHours = matches
        .map((m) => parseInt(m.replace(/\D/g, ""), 10))
        .filter((n) => !isNaN(n) && n > 0 && n <= dailyHours);

      const totalMissed = missedHours.length;
      if (totalMissed === 0) return;

      const checkboxes = tr.querySelectorAll("input[type='checkbox']");
      if (checkboxes.length < 5) return;

      const chkTamGun = checkboxes[0];
      const chkSabah  = checkboxes[1];
      const chkOgle   = checkboxes[2];
      const chkGec    = checkboxes[4];

      checkboxes.forEach((c) => {
        if (c.checked) {
          c.checked = false;
          c.dispatchEvent(new Event("change", { bubbles: true }));
        }
      });

      function setChecked(box) {
        if (!box) return;
        box.checked = true;
        box.dispatchEvent(new Event("click", { bubbles: true }));
        box.dispatchEvent(new Event("change", { bubbles: true }));
      }

      const secim = devamsizlikKutusu(missedHours, halfDayLimit);
      if (secim === "tam") setChecked(chkTamGun);
      else if (secim === "gec" && chkGec) setChecked(chkGec);
      else if (secim === "ogle") setChecked(chkOgle);
      else if (secim === "gec") setChecked(missedHours[0] <= halfDayLimit ? chkSabah : chkOgle); // Geç kutusu yoksa eski davranış
      else setChecked(chkSabah);
      changed++;
    });

    return changed;
  }
})();