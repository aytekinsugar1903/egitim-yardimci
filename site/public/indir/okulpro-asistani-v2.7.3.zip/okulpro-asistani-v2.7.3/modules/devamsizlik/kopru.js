// ISOLATED dünya köprüsü: MAIN dünyadaki devamsızlık betiği (content.js) chrome.* kullanamaz.
// - Okul profilindeki şube listesini localStorage "tm_custom_target_classes"e yansıtır
// - Ortak kilidi (aynı anda tek otomasyon) yönetir
// - "Okul ayarları" sayfasını açtırır
(() => {
  if (window !== window.top) return;
  const P = globalThis.OkulProfil;
  const gonder = (tip, veri) => window.postMessage({ kaynak: "tm-kopru", tip, veri }, "*");
  const baglam = () => { try { return !!chrome.runtime?.id; } catch (e) { return false; } };

  async function siniflariYansit() {
    if (!baglam()) return;
    const r = await chrome.storage.local.get("okulProfili");
    let p = r.okulProfili;
    if (!p || !Array.isArray(p.siniflar)) {
      // İlk kurulum: eski eklentinin localStorage listesi varsa onu al, yoksa varsayılan
      let eski = null;
      try { eski = JSON.parse(localStorage.getItem("tm_custom_target_classes")); } catch (e) {}
      p = { okulAdi: (p && p.okulAdi) || "", siniflar: Array.isArray(eski) && eski.length ? eski : P.VARSAYILAN_SINIFLAR.slice() };
      await chrome.storage.local.set({ okulProfili: p });
    }
    localStorage.setItem("tm_custom_target_classes", JSON.stringify(p.siniflar));
    gonder("siniflarGuncel", p.siniflar.length);
  }
  siniflariYansit();
  chrome.storage.onChanged.addListener((ch) => {
    if (!ch.okulProfili) return;
    if (!ch.okulProfili.newValue) localStorage.removeItem("tm_custom_target_classes"); // "Tüm verileri sil"
    siniflariYansit();
  });

  window.addEventListener("message", async (e) => {
    if (e.source !== window || !e.data || e.data.kaynak !== "tm-ana") return;
    if (!baglam()) { if (e.data.tip === "kilitIste") gonder("kilitYanit", { ok: false, mesaj: "Eklenti güncellendi; sayfayı yenileyin (F5)." }); return; }
    const tip = e.data.tip;
    if (tip === "vkGonder") { // [VELİDUY] yalnızca kullanıcı tıklamasıyla gelir
      chrome.runtime.sendMessage({ tip: "vkGonder", veri: e.data.veri }, (r) => gonder("vkSonuc", r || { ok: false, hata: "Eklentiden yanıt yok; sayfayı yenileyin." }));
      return;
    }
    if (tip === "ayarlarAc") chrome.runtime.sendMessage({ tip: "okulAyarlariAc" });
    if (tip === "kilitIste") {
      if (!(await P.kvkkOnayli())) { gonder("kilitYanit", { ok: false, mesaj: "Önce KVKK bilgilendirmesini onaylayın (başlatıcı > Hakkında)." }); return; }
      const k = await P.kilitDurumu();
      if (k && k.modul !== "devamsizlik") { gonder("kilitYanit", { ok: false, mesaj: `${P.MODUL_ADI[k.modul] || k.modul} çalışıyor. Önce onu bitirin veya durdurun.` }); return; }
      await siniflariYansit();
      await chrome.storage.local.set({ kilit: { modul: "devamsizlik", ts: Date.now() } });
      gonder("kilitYanit", { ok: true });
    }
    if (tip === "kilitTazele") {
      const k = await P.kilitDurumu();
      if (!k || k.modul === "devamsizlik") await chrome.storage.local.set({ kilit: { modul: "devamsizlik", ts: Date.now() } });
    }
    if (tip === "kilitBirak") {
      const r = await chrome.storage.local.get("kilit");
      if (r.kilit && r.kilit.modul === "devamsizlik") await chrome.storage.local.remove("kilit");
    }
  });
})();
