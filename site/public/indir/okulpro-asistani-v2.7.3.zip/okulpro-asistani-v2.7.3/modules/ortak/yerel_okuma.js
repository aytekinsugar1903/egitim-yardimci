"use strict";
// Yerel Okuma Servisi istemcisi (e-Okul Pro + Not Girişi ortak). Yalnız http://127.0.0.1:<port> ile konuşur.
// Servis kapalı / eşleşmemiş / hata → null döner; çağıran kendi yerel okuyucusuyla (ElRakam) devam eder.
// Görüntüler yalnız bu bilgisayardaki servise gider; hiçbir yere kaydedilmez. Hiçbir alanı kaydetmez, Kaydet'e basmaz.
(function (kok) {
  const ANAHTAR = "yerel_okuma", VARSAYILAN_PORT = 47613, PARCA = 32;
  let depo = () => kok.chrome && kok.chrome.storage && kok.chrome.storage.local, getir = (...a) => kok.fetch(...a);
  let durumOnbellek = { t: 0, v: null };
  async function ayarAl() { try { const o = await depo().get(ANAHTAR); const a = o && o[ANAHTAR]; return { acik: !!(a && a.acik), port: (a && +a.port) || VARSAYILAN_PORT, belirtec: (a && a.belirtec) || "" }; } catch (e) { return { acik: false, port: VARSAYILAN_PORT, belirtec: "" }; } }
  async function ayarYaz(a) { durumOnbellek = { t: 0, v: null }; await depo().set({ [ANAHTAR]: { acik: !!a.acik, port: +a.port || VARSAYILAN_PORT, belirtec: a.belirtec || "" } }); }
  const adres = (a, yol) => `http://127.0.0.1:${a.port}${yol}`;
  async function istek(url, secenek, ms) {
    const ac = typeof AbortController !== "undefined" ? new AbortController() : null; const z = ac ? setTimeout(() => ac.abort(), ms) : null;
    try { const r = await getir(url, { ...secenek, cache: "no-store", credentials: "omit", ...(ac ? { signal: ac.signal } : {}) }); let j = null; try { j = await r.json(); } catch (e) { j = null; } return { ok: r.ok, kod: r.status, j }; }
    catch (e) { return { ok: false, kod: 0, j: null }; } finally { if (z) clearTimeout(z); }
  }
  async function durum(ms = 1500) {
    const a = await ayarAl(); const r = await istek(adres(a, "/durum"), { method: "GET" }, ms);
    return r.ok && r.j ? { ...r.j, port: a.port, acik: a.acik, belirtecVar: !!a.belirtec } : { durum: "kapali", port: a.port, acik: a.acik, belirtecVar: !!a.belirtec };
  }
  async function eslestir(port) {
    const a = await ayarAl(); if (port) a.port = +port;
    const r = await istek(adres(a, "/eslestir"), { method: "POST" }, 4000);
    if (!r.ok || !r.j || !r.j.belirtec) return { ok: false, hata: (r.j && r.j.hata) || (r.kod ? "HTTP " + r.kod : "Servise ulaşılamadı (kurulu ve açık mı?)") };
    await ayarYaz({ acik: true, port: a.port, belirtec: r.j.belirtec }); return { ok: true, surum: r.j.surum };
  }
  async function kapat() { const a = await ayarAl(); await ayarYaz({ ...a, acik: false }); }
  async function hazir() { // 20 sn önbellek: her sayfada /durum sorulmaz
    if (Date.now() - durumOnbellek.t < 20000) return durumOnbellek.v;
    const a = await ayarAl(); let v = false;
    if (a.acik && a.belirtec) { const d = await durum(1200); v = d.durum === "hazir" && d.eslesmis === true; }
    durumOnbellek = { t: Date.now(), v }; return v;
  }
  // alanlar: [{tur:'no'|'puan'|'ad'|'isaret', png:<base64>, adaylar?:[{anahtar, ad}]}] → sonuçlar dizisi (aynı sıra) veya null
  async function oku(alanlar) {
    if (!alanlar || !alanlar.length) return [];
    if (!(await hazir())) return null;
    const a = await ayarAl(), out = [];
    for (let i = 0; i < alanlar.length; i += PARCA) {
      const p = alanlar.slice(i, i + PARCA);
      const r = await istek(adres(a, "/oku"), { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + a.belirtec }, body: JSON.stringify({ alanlar: p }) }, 15000 + 4000 * p.length);
      if (!r.ok || !r.j || !Array.isArray(r.j.sonuclar) || r.j.sonuclar.length !== p.length) { durumOnbellek = { t: 0, v: null }; return null; }
      out.push(...r.j.sonuclar);
    }
    return out;
  }
  // {w,h,d} gri (0-255) / {w,h,g} gri / {w,h,d} ikili (0/1, ikili:true) / canvas → base64 PNG (önek yok); yalnız bellekte
  function png(G, ikili) {
    let c = G;
    if (!(G && typeof G.toDataURL === "function")) {
      const d = G.d || G.g; c = document.createElement("canvas"); c.width = G.w; c.height = G.h; const cx = c.getContext("2d"), im = cx.createImageData(G.w, G.h);
      for (let i = 0; i < G.w * G.h; i++) { const v = ikili ? (d[i] ? 0 : 255) : d[i]; im.data[4 * i] = im.data[4 * i + 1] = im.data[4 * i + 2] = v; im.data[4 * i + 3] = 255; }
      cx.putImageData(im, 0, 0);
    }
    return c.toDataURL("image/png").replace(/^data:image\/png;base64,/, "");
  }
  // Yerel okuyucu (ElRakam) sonucu + servis sonucu → {deger, guven(0-1), emin, not}. Servis yoksa (null) yerel sonuç aynen kalır.
  // Kural: iki model aynı (yeşil) ve yerel okuyucu emin olup farklı bir şey söylemiyorsa → emin; aksi hâlde SARI (kontrol).
  // uclu=true (e-Okul Pro formları): emin için ElRakam da aynı değeri okumalı (üç okuyucu uzlaşması)
  function rakamBirlestir(yerel, yerelGuven, s, uclu) {
    if (!s || !s.durum) return null;
    const n = (v) => String(v == null ? "" : v).trim().replace(",", ".").replace(/^0+(?=\d)/, "").replace(/\.0+$/, "");
    const m = s.motorlar || {}, ayrinti = `yerel servis: ${m.qwen || "–"} / ${m.trocr || "–"}${yerel ? ", ElRakam: " + yerel : ""}`;
    if (s.durum === "yesil" && s.deger) {
      if (yerel && (yerelGuven >= 0.8 || uclu) && n(yerel) !== n(s.deger)) return { deger: yerel, guven: Math.min(yerelGuven, 0.5), emin: false, not: `okuyucular farklı (${ayrinti}) — kontrol edin` };
      return { deger: s.deger, guven: 0.99, emin: true, not: "" };
    }
    return { deger: yerel || s.deger || (m.qwen || ""), guven: Math.min(yerelGuven || 0, 0.5), emin: false, not: `${s.neden || "emin değil"} (${ayrinti}) — kontrol edin` };
  }
  const api = { ANAHTAR, rakamBirlestir, ayarAl, ayarYaz, durum, eslestir, kapat, hazir, oku, png, _test: { depo: (f) => { depo = f; }, getir: (f) => { getir = f; }, sifirla: () => { durumOnbellek = { t: 0, v: null }; } } };
  kok.YerelOkuma = api;
  if (typeof module !== "undefined") module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
