// v2.5.2: Sağ kenara gizle — e-Okul sayfasına enjekte edilen yüzen paneller.
// Gizle düğmesi paneli sağ kenara kaydırır; eklenti simgeli küçük sekme kalır.
// Sekme (ve açık panelin başlığı) dikey sürüklenir; tık / sürükleme eşiği ~5 px.
// Gizli hali ve dikey konum panel başına chrome.storage.local (yoksa localStorage) ile yenilemede korunur.
// Otomasyon, Kaydet davranışı, hızlar ve Güvenlik Kodu mantığına dokunmaz.
(function () {
  "use strict";
  if (window.__eaCekmece || window !== window.top) return;
  window.__eaCekmece = true;

  const DEPO = "eaPanelCekmece";
  const SEKME_PX = 40;
  const ESİK = 5;
  const Z = "2147483646";
  const PANELER = ["tm-devamsizlik-paneli", "ea-sesli", "ea-surekli"];
  const durum = {};
  const bagli = new Map();

  function simgeUrl() {
    try { return chrome.runtime.getURL("icons/icon48.png"); } catch (e) { return "icons/icon48.png"; }
  }
  function yereldenOku() {
    try { return JSON.parse(localStorage.getItem(DEPO) || "{}") || {}; } catch (e) { return {}; }
  }
  function depoOku() {
    return new Promise((coz) => {
      const bitir = (r) => coz((r && r[DEPO]) || yereldenOku());
      try {
        if (!chrome || !chrome.storage || !chrome.storage.local) { coz(yereldenOku()); return; }
        const ret = chrome.storage.local.get(DEPO, (r) => {
          if (chrome.runtime && chrome.runtime.lastError) { coz(yereldenOku()); return; }
          bitir(r);
        });
        if (ret && typeof ret.then === "function") ret.then(bitir, () => coz(yereldenOku()));
      } catch (e) { coz(yereldenOku()); }
    });
  }
  function depoYaz() {
    const yazilacak = {};
    for (const id of PANELER) {
      if (durum[id] && (typeof durum[id].top === "number" || durum[id].hidden)) {
        yazilacak[id] = { hidden: !!durum[id].hidden, top: Math.round(durum[id].top) };
      }
    }
    try { localStorage.setItem(DEPO, JSON.stringify(yazilacak)); } catch (e) {}
    try { if (chrome && chrome.storage && chrome.storage.local) chrome.storage.local.set({ [DEPO]: yazilacak }); } catch (e) {}
  }
  let yazTimer;
  function depoGecikmeli() { clearTimeout(yazTimer); yazTimer = setTimeout(depoYaz, 200); }

  function govde(el) {
    if (!el) return null;
    if (el.id === "tm-devamsizlik-paneli") {
      const b = el.querySelector("#tm-btn-start");
      return b ? b.parentElement : null;
    }
    return el;
  }
  function govdeAcik(el) {
    if (el.id !== "tm-devamsizlik-paneli") return el.style.display !== "none";
    const g = govde(el);
    return !!(g && g.style.display && g.style.display !== "none");
  }
  function govdeAc(el) {
    if (el.id !== "tm-devamsizlik-paneli") return;
    const g = govde(el);
    if (!g || (g.style.display && g.style.display !== "none")) return;
    const tab = el.querySelector(":scope > div");
    if (tab && typeof tab.onclick === "function") tab.onclick();
    else g.style.display = "flex";
  }
  function baslikEl(el) {
    if (el.id === "tm-devamsizlik-paneli") {
      const rozet = el.querySelector("#tm-badge-count");
      return rozet ? rozet.parentElement : null;
    }
    return el.querySelector(":scope > .ea-cekmece-baslik") || el.querySelector(":scope > b");
  }
  function baslikHazirla(el) {
    let h = baslikEl(el);
    if (!h) return null;
    if (h.dataset.eaCekmeceBaslik) return h;
    if (h.tagName === "B") {
      const satir = document.createElement("div");
      satir.className = "ea-cekmece-baslik";
      satir.style.cssText = "display:flex;align-items:center;justify-content:space-between;gap:6px;cursor:ns-resize";
      h.parentNode.insertBefore(satir, h);
      satir.appendChild(h);
      h = satir;
    } else {
      h.style.cursor = h.style.cursor || "ns-resize";
    }
    h.dataset.eaCekmeceBaslik = "1";
    return h;
  }
  function varsayilanTop(el) {
    const r = el.getBoundingClientRect();
    if (r.height > 0) return Math.max(8, Math.round(r.top));
    if (el.id === "tm-devamsizlik-paneli") return Math.round(window.innerHeight * 0.10);
    if (el.id === "ea-sesli") return Math.max(8, window.innerHeight - 420);
    return Math.max(8, window.innerHeight - 220);
  }
  function sinirTop(t, yukseklik) {
    const h = yukseklik || SEKME_PX;
    const max = Math.max(8, window.innerHeight - h - 8);
    return Math.max(8, Math.min(Math.round(t), max));
  }
  function topKur(el, t) {
    const y = sinirTop(t, el.offsetHeight || 120);
    el.style.setProperty("top", y + "px", "important");
    el.style.setProperty("bottom", "auto", "important");
    return y;
  }

  function sekmeYap(id) {
    const s = document.createElement("button");
    s.type = "button";
    s.id = "ea-cekmece-sekme-" + id;
    s.className = "ea-cekmece-sekme";
    s.title = "Paneli aç";
    s.setAttribute("aria-label", "Paneli aç");
    s.style.cssText = [
      "all:initial",
      "box-sizing:border-box",
      "position:fixed",
      "right:0",
      "width:" + SEKME_PX + "px",
      "height:" + SEKME_PX + "px",
      "padding:4px",
      "margin:0",
      "border:0",
      "border-radius:8px 0 0 8px",
      "background:#1a73e8",
      "box-shadow:-2px 2px 8px rgba(0,0,0,.35)",
      "cursor:pointer",
      "z-index:" + Z,
      "display:none",
      "align-items:center",
      "justify-content:center",
      "user-select:none",
      "touch-action:none",
      "line-height:0"
    ].join(";");
    const img = document.createElement("img");
    img.src = simgeUrl();
    img.alt = "";
    img.width = 28;
    img.height = 28;
    img.draggable = false;
    img.style.cssText = "width:28px;height:28px;display:block;pointer-events:none";
    s.appendChild(img);
    document.documentElement.appendChild(s);
    return s;
  }
  function gizleDugme() {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "ea-cekmece-gizle";
    b.title = "Sağ kenara gizle";
    b.setAttribute("aria-label", "Sağ kenara gizle");
    b.textContent = "▶";
    b.style.cssText = "flex:none;margin:0 0 0 6px;padding:0;width:24px;height:24px;border:1px solid #94a3b8;border-radius:6px;background:#f8fafc;color:#1e293b;font:700 12px/1 Segoe UI,Arial,sans-serif;cursor:pointer";
    return b;
  }

  function uygula(id) {
    const rec = bagli.get(id);
    if (!rec) return;
    rec._uygulaniyor = true;
    try {
    const st = durum[id] || (durum[id] = { hidden: false, top: varsayilanTop(rec.el) });
    if (typeof st.top !== "number") st.top = varsayilanTop(rec.el);

    if (rec.el.id === "tm-devamsizlik-paneli") {
      rec.el.style.setProperty("display", st.hidden ? "none" : "flex", "important");
    } else {
      rec.el.style.display = st.hidden ? "none" : "";
    }
    if (!st.hidden) st.top = topKur(rec.el, st.top);
    rec.sekme.style.display = st.hidden ? "flex" : "none";
    rec.sekme.style.top = sinirTop(st.top, SEKME_PX) + "px";
    rec.el.dataset.eaCekmeceDurum = st.hidden ? "gizli" : "acik";
    rec.sekme.dataset.eaCekmeceDurum = st.hidden ? "gizli" : "acik";
    } finally { rec._uygulaniyor = false; }
  }

  function dikeySurukle(hedef, baslangicTop, ev, birakinca) {
    if (ev.button != null && ev.button !== 0) return;
    ev.preventDefault();
    const y0 = ev.clientY;
    let oynadi = false;
    const tasi = (m) => {
      if (Math.abs(m.clientY - y0) > ESİK) oynadi = true;
      if (!oynadi) return;
      const id = hedef.__eaCekmeceId;
      const rec = id && bagli.get(id);
      const t = sinirTop(baslangicTop + (m.clientY - y0), (rec && rec.el === hedef ? rec.el.offsetHeight : SEKME_PX) || SEKME_PX);
      if (id) durum[id].top = t;
      if (rec) {
        rec.sekme.style.top = sinirTop(t, SEKME_PX) + "px";
        if (!durum[id].hidden) topKur(rec.el, t);
        else rec.sekme.style.top = t + "px";
      } else {
        hedef.style.setProperty("top", t + "px", "important");
      }
    };
    const bitir = (m) => {
      window.removeEventListener("pointermove", tasi, true);
      window.removeEventListener("pointerup", bitir, true);
      window.removeEventListener("pointercancel", bitir, true);
      depoGecikmeli();
      if (birakinca) birakinca(oynadi, m);
    };
    window.addEventListener("pointermove", tasi, true);
    window.addEventListener("pointerup", bitir, true);
    window.addEventListener("pointercancel", bitir, true);
  }

  function bagla(el) {
    if (!el || !el.id || bagli.has(el.id) || el.classList.contains("ea-cekmece-sekme")) return;
    if (PANELER.indexOf(el.id) < 0) return;
    const id = el.id;
    const h = baslikHazirla(el);
    const gizle = gizleDugme();
    if (el.id !== "tm-devamsizlik-paneli") {
      gizle.style.background = "#1e3a8a";
      gizle.style.color = "#fff";
      gizle.style.borderColor = "#fff";
    }
    if (h && !h.querySelector(".ea-cekmece-gizle")) h.appendChild(gizle);
    else if (!h) el.insertBefore(gizle, el.firstChild);

    if (!durum[id] || typeof durum[id].top !== "number") {
      durum[id] = { hidden: !!(durum[id] && durum[id].hidden), top: varsayilanTop(el) };
    }

    const sekme = sekmeYap(id);
    sekme.__eaCekmeceId = id;
    el.__eaCekmeceId = id;
    bagli.set(id, { el, sekme, gizle });

    gizle.addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      const r = el.getBoundingClientRect();
      if (r.height) durum[id].top = sinirTop(r.top, SEKME_PX);
      durum[id].hidden = true;
      uygula(id);
      depoGecikmeli();
    });

    sekme.addEventListener("pointerdown", (e) => {
      dikeySurukle(sekme, durum[id].top, e, (oynadi) => {
        if (oynadi) {
          durum[id].top = sinirTop(parseFloat(sekme.style.top) || durum[id].top, SEKME_PX);
          depoGecikmeli();
          return;
        }
        durum[id].hidden = false;
        govdeAc(el);
        uygula(id);
        depoGecikmeli();
      });
    });

    if (h) {
      h.addEventListener("pointerdown", (e) => {
        if (e.target.closest("button,input,select,textarea,a,label")) return;
        const r = el.getBoundingClientRect();
        const t0 = r.height ? r.top : durum[id].top;
        dikeySurukle(el, t0, e, (oynadi) => {
          if (!oynadi) return;
          durum[id].top = sinirTop(el.getBoundingClientRect().top || durum[id].top, el.offsetHeight);
          uygula(id);
          depoGecikmeli();
        });
      });
    }

    // Launcher "aç/kapat" yalnızca gövde kutusunun inline display'ini değiştirir; gizle düğmesi kutuya dokunmaz.
    const kutu = govde(el);
    if (el.id === "tm-devamsizlik-paneli" && kutu) {
      new MutationObserver(() => {
        if (rec._uygulaniyor) return;
        const acik = !!(kutu.style.display && kutu.style.display !== "none");
        if (!acik && durum[id].hidden) { durum[id].hidden = false; uygula(id); depoGecikmeli(); }
        else if (acik && durum[id].hidden) { durum[id].hidden = false; uygula(id); depoGecikmeli(); }
        else if (acik && !durum[id].hidden) topKur(el, durum[id].top);
      }).observe(kutu, { attributes: true, attributeFilter: ["style"] });
    }

    uygula(id);
  }

  function tara() {
    for (const id of PANELER) {
      const el = document.getElementById(id);
      if (el) bagla(el);
    }
  }

  window.addEventListener("resize", () => {
    for (const id of bagli.keys()) {
      if (typeof (durum[id] && durum[id].top) === "number") durum[id].top = sinirTop(durum[id].top, SEKME_PX);
      uygula(id);
    }
  });

  window.__eaCekmeceTest = { DEPO, PANELER, durum, bagli, uygula, tara, depoYaz, depoOku };

  depoOku().then((kayit) => {
    for (const id of PANELER) {
      const k = kayit && kayit[id];
      if (k && typeof k === "object") durum[id] = { hidden: !!k.hidden, top: typeof k.top === "number" ? k.top : undefined };
    }
    const basla = () => { tara(); new MutationObserver(tara).observe(document.documentElement, { childList: true, subtree: true }); };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", basla);
    else basla();
  });
})();
