// v2.4.3: Genel liste ayırma — taranan sayfanın satır/sütunlarını kullanıcı düzenler (her tür liste: öğrenci, sınıf, görev, eşya...).
// Model saf JS (test edilebilir); arayüz isteğe bağlı açılır, açılmazsa tarayıcının davranışı değişmez. Veri yalnız bellekte durur.
(function (kok) {
  const kopya = (o) => JSON.parse(JSON.stringify(o));
  const kelimeler = (s) => String(s || "").trim().split(/\s+/).filter(Boolean);
  const ROLLER = [["", "— (kullanma)"], ["no", "Numara"], ["ad", "Ad Soyad"], ["sinif", "Sınıf"], ["tarih", "Tarih"], ["gun", "Gün / süre"], ["aciklama", "Açıklama / konu"], ["diger", "Diğer"]];
  const N = (s) => String(s || "").toLocaleUpperCase("tr").replace(/\u0130/g, "I").replace(/\u015e/g, "S").replace(/\u011e/g, "G").replace(/\u00dc/g, "U").replace(/\u00d6/g, "O").replace(/\u00c7/g, "C");
  function rolTahmin(b) { const t = N(b).replace(/[^A-Z]/g, ""); if (!t) return ""; if (/SOYAD|ADI|ISIM|ADSOYAD/.test(t)) return "ad"; if (/SINIF|SUBE/.test(t)) return "sinif"; if (/TARIH/.test(t)) return "tarih"; if (/GUN|SURE/.test(t)) return "gun"; if (/ACIKLAMA|KONU|GOREV|FAALIYET/.test(t)) return "aciklama"; if (/^SIRA|^SNO$/.test(t)) return ""; if (/NUMARA|^NO$|OKULNO/.test(t)) return "no"; return "diger"; }
  function Model(satirlar, opt = {}) {
    const M = { satirlar: kopya(satirlar || []).map((r) => r.map((x) => String(x ?? ""))), roller: [], baslik: -1, gecmis: [], ileri: [] };
    const gen = () => Math.max(0, ...M.satirlar.map((r) => r.length)); const duzle = () => { const k = gen(); M.satirlar.forEach((r) => { while (r.length < k) r.push(""); }); while (M.roller.length < k) M.roller.push(""); M.roller.length = k; };
    duzle(); if (opt.roller) opt.roller.forEach((r, j) => { if (j < M.roller.length) M.roller[j] = r; });
    const an = () => JSON.stringify({ s: M.satirlar, r: M.roller, b: M.baslik }), yukle = (j) => { const o = JSON.parse(j); M.satirlar = o.s; M.roller = o.r; M.baslik = o.b; };
    const islem = (f) => (...a) => { const once = an(); const ok = f(...a); if (ok === false) return false; duzle(); if (an() !== once) { M.gecmis.push(once); if (M.gecmis.length > 200) M.gecmis.shift(); M.ileri = []; } return true; };
    const icinde = (i) => i >= 0 && i < M.satirlar.length;
    Object.assign(M, {
      satirEkle: islem((i) => { M.satirlar.splice(i + 1, 0, new Array(gen()).fill("")); if (M.baslik > i) M.baslik++; }),
      satirSil: islem((i) => { if (!icinde(i)) return false; M.satirlar.splice(i, 1); if (M.baslik === i) M.baslik = -1; else if (M.baslik > i) M.baslik--; }),
      birlestir: islem((i) => { if (!icinde(i) || !icinde(i + 1)) return false; const a = M.satirlar[i], b = M.satirlar[i + 1]; M.satirlar[i] = a.map((x, j) => [x, b[j]].filter((v) => v && v.trim()).join(" ")); M.satirlar.splice(i + 1, 1); if (M.baslik > i) M.baslik--; }),
      // böl: j. hücrenin k. kelimesinden itibaren (ve sağındaki hücreler) yeni satıra iner
      bol: islem((i, j, k) => { if (!icinde(i)) return false; const r = M.satirlar[i], w = kelimeler(r[j]); if (k == null) k = Math.ceil(w.length / 2); const yeni = r.map((x, t) => (t < j ? "" : t === j ? w.slice(k).join(" ") : x)); M.satirlar[i] = r.map((x, t) => (t < j ? x : t === j ? w.slice(0, k).join(" ") : "")); M.satirlar.splice(i + 1, 0, yeni); if (M.baslik > i) M.baslik++; }),
      yukari: islem((i) => { if (!icinde(i) || i === 0) return false; const s = M.satirlar; [s[i - 1], s[i]] = [s[i], s[i - 1]]; if (M.baslik === i) M.baslik--; else if (M.baslik === i - 1) M.baslik++; }),
      asagi: islem((i) => { if (!icinde(i + 1)) return false; const s = M.satirlar; [s[i + 1], s[i]] = [s[i], s[i + 1]]; if (M.baslik === i) M.baslik++; else if (M.baslik === i + 1) M.baslik--; }),
      sutunEkle: islem((j) => { M.satirlar.forEach((r) => r.splice(j + 1, 0, "")); M.roller.splice(j + 1, 0, ""); }),
      sutunSil: islem((j) => { if (gen() <= 1) return false; M.satirlar.forEach((r) => r.splice(j, 1)); M.roller.splice(j, 1); }),
      sutunBirlestir: islem((j) => { if (j + 1 >= gen()) return false; M.satirlar.forEach((r) => { r[j] = [r[j], r[j + 1]].filter((v) => v && v.trim()).join(" "); r.splice(j + 1, 1); }); if (!M.roller[j]) M.roller[j] = M.roller[j + 1]; M.roller.splice(j + 1, 1); }),
      // sütun böl: her satırda j. hücrenin ilk k kelimesi solda kalır, kalanı yeni sütuna
      sutunBol: islem((j, k = 1) => { M.satirlar.forEach((r) => { const w = kelimeler(r[j]); r.splice(j, 1, w.slice(0, k).join(" "), w.slice(k).join(" ")); }); M.roller.splice(j + 1, 0, ""); }),
      rolAta: islem((j, rol) => { M.roller[j] = rol; }),
      baslikSec: islem((i) => { M.baslik = M.baslik === i ? -1 : i; if (M.baslik >= 0) M.satirlar[i].forEach((b, j) => { const r = rolTahmin(b); if (r && !M.roller[j]) M.roller[j] = r; }); }),
      hucre: islem((i, j, v) => { if (!icinde(i)) return false; M.satirlar[i][j] = String(v ?? ""); }),
      geriAl() { if (!M.gecmis.length) return false; M.ileri.push(an()); yukle(M.gecmis.pop()); return true; },
      yinele() { if (!M.ileri.length) return false; M.gecmis.push(an()); yukle(M.ileri.pop()); return true; },
      kayitlar() { const o = []; M.satirlar.forEach((r, i) => { if (i === M.baslik || !r.some((x) => x.trim())) return; const k = { satir: i + 1 }; r.forEach((x, j) => { const rol = M.roller[j]; if (!rol) return; k[rol] = k[rol] ? k[rol] + " " + x.trim() : x.trim(); }); o.push(k); }); return o; },
    });
    return M;
  }
  // Tesseract kelimelerinden satır/sütun önerisi: aynı yükseklikteki kelimeler bir satır, geniş boşluk yeni sütun
  function satirlardan(kel) {
    const w = (kel || []).filter((x) => x && x.bbox && String(x.text || "").trim()); if (!w.length) return [];
    const yk = w.map((x) => x.bbox.y1 - x.bbox.y0).sort((a, b) => a - b), h = Math.max(4, yk[Math.floor(yk.length / 2)]);
    const s = [...w].sort((a, b) => (a.bbox.y0 + a.bbox.y1) - (b.bbox.y0 + b.bbox.y1)), sat = [];
    for (const x of s) { const yc = (x.bbox.y0 + x.bbox.y1) / 2, son = sat[sat.length - 1]; if (son && Math.abs(yc - son.yc) < 0.6 * h) son.k.push(x); else sat.push({ yc, k: [x] }); }
    return sat.map(({ k }) => { k.sort((a, b) => a.bbox.x0 - b.bbox.x0); const h2 = []; let cur = [], sag = null;
      for (const x of k) { if (sag != null && x.bbox.x0 - sag > 2 * h) { h2.push(cur.join(" ")); cur = []; } cur.push(String(x.text).trim()); sag = x.bbox.x1; }
      h2.push(cur.join(" ")); return h2; });
  }
  // Arayüz: kap içine düzenleyici çizer; aktar(kayitlar, M) kullanıcı "Aktar"a basınca çağrılır
  function arayuz(kap, M, { aktar, kapat, baslik = "Liste ayır" } = {}) {
    const el = (t, a = {}, ...c) => { const e = document.createElement(t); for (const [k, v] of Object.entries(a)) if (k === "on") for (const [ev, f] of Object.entries(v)) e.addEventListener(ev, f); else if (k in e) e[k] = v; else e.setAttribute(k, v); e.append(...c); return e; };
    let odak = null; // {i, j, k}
    const yap = (f) => { f(); ciz(); };
    function ciz() {
      kap.innerHTML = "";
      const ust = el("div", { className: "la-ust" }, el("b", {}, baslik + " "),
        el("button", { textContent: "↶ Geri al", disabled: !M.gecmis.length, title: "Geri al (Ctrl+Z)", on: { click: () => yap(M.geriAl) } }), " ",
        el("button", { textContent: "↷ Yinele", disabled: !M.ileri.length, title: "Yinele (Ctrl+Y)", on: { click: () => yap(M.yinele) } }), " ",
        el("span", { className: "la-ipucu", textContent: "Sütun başlıklarından ne olduğunu seçin · B: başlık satırı · + satır ekle · − sil · ⊕ alttakiyle birleştir · ✂ imleçten böl · ↑↓ taşı" }));
      const t = el("table", { className: "la-tablo" }), th = el("tr");
      th.append(el("th", {}, ""));
      M.roller.forEach((r, j) => { const s = el("select", { title: "Bu sütun nedir?", on: { change: (e) => yap(() => M.rolAta(j, e.target.value)) } }); for (const [v, ad] of ROLLER) s.append(el("option", { value: v, textContent: ad, selected: v === r })); 
        th.append(el("th", {}, s, el("br"), el("button", { textContent: "+", title: "Sağına boş sütun ekle", on: { click: () => yap(() => M.sutunEkle(j)) } }), el("button", { textContent: "−", title: "Sütunu sil", on: { click: () => yap(() => M.sutunSil(j)) } }), el("button", { textContent: "⊕", title: "Sağdaki sütunla birleştir", on: { click: () => yap(() => M.sutunBirlestir(j)) } }), el("button", { textContent: "✂", title: "Sütunu ilk kelimeden böl", on: { click: () => yap(() => M.sutunBol(j, 1)) } }))); });
      t.append(th);
      M.satirlar.forEach((r, i) => { const tr = el("tr", { className: i === M.baslik ? "la-baslik" : "" });
        const btn = (x, ttl, f) => el("button", { textContent: x, title: ttl, on: { click: () => yap(f) } });
        tr.append(el("td", { className: "la-dug" }, btn("B", "Başlık satırı yap / kaldır", () => M.baslikSec(i)), btn("+", "Altına boş satır ekle", () => M.satirEkle(i)), btn("−", "Satırı sil", () => M.satirSil(i)), btn("⊕", "Alttaki satırla birleştir", () => M.birlestir(i)),
          btn("✂", "İmlecin olduğu yerden iki satıra böl", () => { const o = odak && odak.i === i ? odak : { j: 0, k: null }; M.bol(i, o.j, o.k); }), btn("↑", "Yukarı taşı", () => M.yukari(i)), btn("↓", "Aşağı taşı", () => M.asagi(i))));
        r.forEach((x, j) => { const inp = el("input", { value: x, on: { change: (e) => yap(() => M.hucre(i, j, e.target.value)), keyup: (e) => { odak = { i, j, k: kelimeler(e.target.value.slice(0, e.target.selectionStart)).length }; }, click: (e) => { odak = { i, j, k: kelimeler(e.target.value.slice(0, e.target.selectionStart)).length }; } } }); tr.append(el("td", {}, inp)); });
        t.append(tr); });
      const n = M.kayitlar().length;
      kap.append(ust, el("div", { className: "la-kap" }, t), el("p", {}, el("button", { className: "ana", textContent: `Aktar (${n} kayıt)`, disabled: !n || !M.roller.some(Boolean), on: { click: () => aktar && aktar(M.kayitlar(), M) } }), " ", el("button", { textContent: "Kapat", on: { click: () => kapat && kapat() } })));
    }
    kap.addEventListener("keydown", (e) => { if (!(e.ctrlKey || e.metaKey) || e.target.tagName === "INPUT") return; if (e.key === "z") { e.preventDefault(); yap(M.geriAl); } else if (e.key === "y") { e.preventDefault(); yap(M.yinele); } });
    ciz(); return { ciz };
  }
  kok.ListeAyir = { Model, satirlardan, arayuz, rolTahmin, ROLLER };
})(typeof globalThis !== "undefined" ? globalThis : this);
