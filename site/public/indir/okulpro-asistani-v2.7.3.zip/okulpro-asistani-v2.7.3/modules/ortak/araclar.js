// v2.3.37: e-Okul araçları — (1) oturum açık tutma (hafif, periyodik; açılıp kapatılabilir, varsayılan AÇIK)
// (2) ekrandaki tabloyu tek tıkla Excel'e kopyala (yalnızca o an görünen tablo, kullanıcı tıklayınca; toplu veri çekme yok)
// Evrak Asistanı tarzı: yüksek karşıtlık, açılır pencere yok. Veri yerel kalır.
(function () {
  "use strict";
  if (window.__eaAraclar) return; window.__eaAraclar = true;
  const ARALIK_MS = 4 * 60 * 1000, ANAHTAR = "oturumAcik";
  const gorunur = (el) => !!(el && el.getClientRects().length && getComputedStyle(el).visibility !== "hidden");
  const girisSayfasi = () => /giris\.aspx/i.test(location.pathname) || !!document.querySelector("input[type=password]");
  // ---- tablo → TSV
  function tabloSec() {
    const t = [...document.querySelectorAll("table")].filter((x) => gorunur(x) && !x.closest("#ea-araclar,#tm-devamsizlik-paneli") && !x.querySelector("table"))
      .map((x) => ({ x, n: x.rows.length * Math.max(1, ...[...x.rows].slice(0, 5).map((r) => r.cells.length)) })).filter((o) => o.x.rows.length >= 2).sort((a, b) => b.n - a.n)[0];
    return t ? t.x : null;
  }
  const hucre = (c) => { const g = c.querySelector("input:not([type=hidden]),select,textarea"); let s = g ? (g.type === "checkbox" || g.type === "radio" ? (g.checked ? "X" : "") : g.tagName === "SELECT" ? (g.selectedOptions[0] ? g.selectedOptions[0].text : "") : g.value) : c.textContent;
    s = String(s).replace(/\s+/g, " ").trim(); return /^0\d+$/.test(s) || /^\d{11,}$/.test(s) ? "'" + s : s; }; // baştaki sıfır / uzun numara Excel'de bozulmasın
  function tsv(t) { return [...t.rows].filter(gorunur).map((r) => [...r.cells].map(hucre).join("\t")).join("\r\n"); }
  // ---- arayüz
  function kur() {
    if (window !== window.top && !tabloSec()) return; // çerçevede yalnız tablo varsa
    if (document.getElementById("ea-araclar") || !document.body) return;
    const k = document.createElement("div"); k.id = "ea-araclar";
    k.style.cssText = "position:fixed;left:0;bottom:8px;z-index:2147483646;display:flex;align-items:center;gap:0;font:bold 13px Segoe UI,Arial,sans-serif";
    const dugme = (metin, renk) => { const b = document.createElement("button"); b.type = "button"; b.textContent = metin; b.style.cssText = `padding:7px 10px;border:2px solid #000;border-radius:6px;background:${renk};color:#fff;cursor:pointer;font:inherit`; return b; };
    const kopya = dugme("📋 Tabloyu Excel'e kopyala", "#1e3a8a"), oturum = dugme("", "#14532d"), bilgi = document.createElement("span");
    bilgi.style.cssText = "align-self:center;background:#000;color:#fde047;padding:4px 8px;border-radius:6px;display:none";
    const goster = (m) => { bilgi.textContent = m; bilgi.style.display = ""; clearTimeout(goster.t); goster.t = setTimeout(() => { bilgi.style.display = "none"; }, 4000); };
    kopya.onclick = async () => { const t = tabloSec(); if (!t) { goster("Ekranda tablo yok"); return; }
      const v = tsv(t), satir = v.split("\r\n").length;
      try { await navigator.clipboard.writeText(v); } catch (e) { const ta = document.createElement("textarea"); ta.value = v; document.body.append(ta); ta.select(); document.execCommand("copy"); ta.remove(); }
      goster(`${satir} satır kopyalandı — Excel'de Ctrl+V`); };
    const ciz = (acik) => { oturum.textContent = acik ? "⏱ Oturum açık tutma: AÇIK" : "⏱ Oturum açık tutma: KAPALI"; oturum.style.background = acik ? "#14532d" : "#7f1d1d"; };
    oturum.onclick = async () => { const a = (await chrome.storage.local.get(ANAHTAR))[ANAHTAR] !== false; await chrome.storage.local.set({ [ANAHTAR]: !a }); ciz(!a); goster(!a ? "Oturum açık tutulacak" : "Oturum açık tutma kapatıldı"); };
    if (window === window.top) { k.append(oturum); chrome.storage.local.get(ANAHTAR).then((o) => ciz(o[ANAHTAR] !== false)); }
    // v2.3.41: sol kenarda çekmece — varsayılan kapalı, sekmeye tık aç/kapa (hatırlanır); sekme sol kenarda yukarı/aşağı sürüklenir (hatırlanır, ekrana sığar)
    const ic = document.createElement("div"); ic.style.cssText = "display:flex;gap:6px;padding:4px 6px;background:#000;border:2px solid #fff;border-left:0;border-radius:0 8px 8px 0;transition:max-width .25s,opacity .25s;overflow:hidden;white-space:nowrap";
    const tut = document.createElement("button"); tut.type = "button"; tut.textContent = "⠿📋"; tut.title = "Tık: araçları aç/kapat — yukarı/aşağı sürükle";
    tut.style.cssText = "writing-mode:vertical-rl;padding:8px 3px;border:2px solid #fff;border-left:0;border-radius:0 8px 8px 0;background:#1e3a8a;color:#fff;cursor:pointer;font:inherit;user-select:none;touch-action:none";
    const ACIK = "eaAraclarAcik", KONUM = "eaAraclarAlt", sinir = (b) => Math.max(0, Math.min(b, window.innerHeight - k.offsetHeight));
    const yerlestir = (b) => { k.style.bottom = sinir(b) + "px"; };
    const ac = (v) => { ic.style.maxWidth = v ? "100vw" : "0"; ic.style.opacity = v ? "1" : "0"; ic.style.padding = v ? "4px 6px" : "0"; ic.style.borderWidth = v ? "2px" : "0"; k.dataset.acik = v ? "1" : ""; };
    ac(false);
    chrome.storage.local.get([ACIK, KONUM]).then((o) => { ac(o[ACIK] === true); if (typeof o[KONUM] === "number") yerlestir(o[KONUM]); });
    tut.onpointerdown = (e) => { tut.setPointerCapture(e.pointerId); const y0 = e.clientY, b0 = parseFloat(k.style.bottom) || 8; let oynadi = false;
      tut.onpointermove = (m) => { if (Math.abs(m.clientY - y0) > 4) oynadi = true; if (oynadi) yerlestir(b0 + y0 - m.clientY); };
      tut.onpointerup = () => { tut.onpointermove = tut.onpointerup = null;
        if (oynadi) chrome.storage.local.set({ [KONUM]: parseFloat(k.style.bottom) || 0 }); else { const v = !k.dataset.acik; ac(v); chrome.storage.local.set({ [ACIK]: v }); } }; };
    window.addEventListener("resize", () => yerlestir(parseFloat(k.style.bottom) || 8));
    [...k.childNodes].forEach((n) => ic.append(n)); ic.append(kopya, bilgi); k.append(ic, tut); document.body.append(k);
    if (!tabloSec()) kopya.style.display = "none";
    new MutationObserver(() => { try { kopya.style.display = tabloSec() ? "" : "none"; } catch (e) {} }).observe(document.body, { childList: true, subtree: true });
  }
  // ---- oturum açık tutma: yalnız üst pencerede, giriş ekranında değilken, mevcut sayfayı arka planda GET ile ister (sayfa değişmez)
  // v2.3.40 (Not Girişi 1.6.17'den): 2 saat tuş/tıklama yoksa durur; çerçevelerdeki işlem de sayılır; oturum düşerse işaretler (veri silinmez)
  const BOSTA_MS = 2 * 60 * 60 * 1000; window.__eaSonIslem = Date.now();
  const dokun = () => { try { window.top.__eaSonIslem = Date.now(); } catch (e) { window.__eaSonIslem = Date.now(); } };
  ["keydown", "pointerdown", "input"].forEach((t) => window.addEventListener(t, dokun, true));
  async function nabiz() {
    if (window !== window.top || girisSayfasi()) return;
    if ((await chrome.storage.local.get(ANAHTAR))[ANAHTAR] === false) return;
    if (Date.now() - (window.__eaSonIslem || 0) > BOSTA_MS) return;
    try { const r = await fetch(location.href, { method: "GET", credentials: "same-origin", cache: "no-store" }); window.__eaSonNabiz = Date.now();
      const t = await r.text(); const dus = /giris\.aspx|login/i.test(r.url || "") || /type=["']?password/i.test(t);
      chrome.storage.local.set({ oturumDurum: { dustu: dus, zaman: Date.now() } }); } catch (e) {}
  }
  window.__eaAraclarTest = { tabloSec, tsv, nabiz, ARALIK_MS, BOSTA_MS };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", kur); else kur();
  if (window === window.top) setInterval(nabiz, ARALIK_MS);
})();
