// v2.3.29: sayısal ayarlara − / + düğmeleri (Evrak Asistanı tarzı; açılır pencere yok)
(function () {
  function ekle(k) {
    document.querySelectorAll('input[type="number"]:not([data-ae])').forEach((g) => {
      g.dataset.ae = "1";
      const yap = (m, y) => { const b = document.createElement("button"); b.type = "button"; b.textContent = m; b.title = y > 0 ? "Artır" : "Azalt";
        b.style.cssText = "min-width:30px;height:30px;margin:0 3px;font-size:18px;font-weight:bold;background:" + (y > 0 ? "#1b7f3b" : "#9b1c1c") + ";color:#fff;border:0;border-radius:6px;cursor:pointer";
        b.onclick = () => { if (g.disabled) return; if (g.value === "") g.value = g.min || "0"; else y > 0 ? g.stepUp() : g.stepDown(); g.dispatchEvent(new Event("input", { bubbles: true })); g.dispatchEvent(new Event("change", { bubbles: true })); };
        return b; };
      g.before(yap("−", -1)); g.after(yap("+", 1));
    });
  }
  ekle();
})();
