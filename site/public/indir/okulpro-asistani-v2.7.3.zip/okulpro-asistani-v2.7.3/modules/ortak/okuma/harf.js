// v2.3.38: El yazısı BÜYÜK HARF tanıyıcı (tamamen yerel; rakam modeliyle aynı küçük CNN, 29 Türkçe harf; ağırlıklar lib/harf.bin).
// Eğitim: EMNIST harfleri + Türkçe işaretli harfler (Ç Ğ İ Ö Ş Ü) sentetik. Ön işleme ElRakam.mnist ile aynıdır. Hiçbir veri dışarı gönderilmez.
// Faaliyet adı sözlük düzeltmesi: kullanıcının yerel listesiyle ağırlıklı düzenleme uzaklığı.
(function (kok) {
  "use strict";
  const ABC = "ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ", K = ABC.length;
  let W = null; const BOY = [288, 32, 9216, 32, 18432, 64, 36864, 64, 401408, 128, 128 * K, K];
  function yukle(buf) { const f = new Float32Array(buf); let o = 0; W = BOY.map((n) => { const a = f.subarray(o, o + n); o += n; return a; }); return true; }
  const hazir = () => !!W;
  function conv(x, C, H, w, b, KK) { const P = H + 2, xp = new Float32Array(C * P * P);
    for (let c = 0; c < C; c++) for (let y = 0; y < H; y++) xp.set(x.subarray(c * H * H + y * H, c * H * H + y * H + H), c * P * P + (y + 1) * P + 1);
    const o = new Float32Array(KK * H * H);
    for (let k = 0; k < KK; k++) { const ob = k * H * H; o.fill(b[k], ob, ob + H * H);
      for (let c = 0; c < C; c++) { const wb = (k * C + c) * 9, xb = c * P * P;
        for (let y = 0; y < H; y++) { const r0 = xb + y * P, r1 = r0 + P, r2 = r1 + P, oo = ob + y * H;
          for (let xx = 0; xx < H; xx++) o[oo + xx] += w[wb] * xp[r0 + xx] + w[wb + 1] * xp[r0 + xx + 1] + w[wb + 2] * xp[r0 + xx + 2] + w[wb + 3] * xp[r1 + xx] + w[wb + 4] * xp[r1 + xx + 1] + w[wb + 5] * xp[r1 + xx + 2] + w[wb + 6] * xp[r2 + xx] + w[wb + 7] * xp[r2 + xx + 1] + w[wb + 8] * xp[r2 + xx + 2]; } } }
    for (let i = 0; i < o.length; i++) if (o[i] < 0) o[i] = 0; return o; }
  function havuz(x, C, H) { const h = H >> 1, o = new Float32Array(C * h * h);
    for (let c = 0; c < C; c++) for (let y = 0; y < h; y++) for (let xx = 0; xx < h; xx++) { const b = c * H * H + 2 * y * H + 2 * xx; o[c * h * h + y * h + xx] = Math.max(x[b], x[b + 1], x[b + H], x[b + H + 1]); } return o; }
  function siniflandir(img28) {
    let x = conv(img28, 1, 28, W[0], W[1], 32); x = havuz(conv(x, 32, 28, W[2], W[3], 32), 32, 28);
    x = conv(x, 32, 14, W[4], W[5], 64); x = havuz(conv(x, 64, 14, W[6], W[7], 64), 64, 14);
    const h = new Float32Array(128); for (let j = 0; j < 128; j++) { let s = W[9][j]; const r = j * 3136; for (let i = 0; i < 3136; i++) s += W[8][r + i] * x[i]; h[j] = s > 0 ? s : 0; }
    const z = new Float32Array(K); let mx = -1e9; for (let j = 0; j < K; j++) { let s = W[11][j]; for (let i = 0; i < 128; i++) s += W[10][j * 128 + i] * h[i]; z[j] = s; mx = Math.max(mx, s); }
    let t = 0; for (let j = 0; j < K; j++) { z[j] = Math.exp(z[j] - mx); t += z[j]; } for (let j = 0; j < K; j++) z[j] /= t; return z; }
  // maske {w,h,d} -> {harf, p, z}
  function harfOku(mk) { const t = kok.ElRakam && kok.ElRakam.mnist(mk); if (!t || !W) return null; const z = siniflandir(t); let b = 0; for (let i = 1; i < K; i++) if (z[i] > z[b]) b = i; return { harf: ABC[b], p: z[b], z }; }
  const VARSAYILAN_ADLAR = ["GEZİ", "YARIŞMA", "TURNUVA", "İLÇE TURNUVASI", "İL TURNUVASI", "BÖLGE TURNUVASI", "SPORTİF FAALİYET", "SPOR MÜSABAKASI", "ŞENLİK", "TEKNOFEST", "BİLİM FUARI", "TÜBİTAK", "KÜLTÜR GEZİSİ", "SOSYAL ETKİNLİK", "SEMİNER", "KONFERANS", "TİYATRO", "KONSER", "FUTBOL TURNUVASI", "VOLEYBOL TURNUVASI", "BASKETBOL TURNUVASI", "SATRANÇ TURNUVASI", "MASA TENİSİ", "ATLETİZM", "HALK OYUNLARI", "MÜNAZARA", "BİLGİ YARIŞMASI", "RESİM YARIŞMASI", "ŞİİR YARIŞMASI", "KOMPOZİSYON YARIŞMASI", "ROBOT YARIŞMASI", "STAJ", "MESLEKİ EĞİTİM", "TÖREN", "ANMA TÖRENİ", "ZİYARET"];
  // harfler: [{harf, z}|null(boş kutu)] -> sözlükten en iyi aday (ağırlıklı düzenleme uzaklığı; yer değiştirme maliyeti 1 - p(aday harf))
  function sozlukDuzelt(harfler, adlar) {
    const ham = harfler.map((h) => (h ? h.harf : " ")).join("").replace(/\s+/g, " ").trim();
    const dizi = []; let bosluk = false; for (const h of harfler) { if (!h) { bosluk = true; continue; } if (bosluk && dizi.length) dizi.push(null); bosluk = false; dizi.push(h); }
    let en = null;
    for (const ad0 of adlar) { const ad = String(ad0).toLocaleUpperCase("tr-TR").replace(/\s+/g, " ").trim(); if (!ad) continue;
      const n = dizi.length, m = ad.length, D = Array.from({ length: n + 1 }, () => new Float64Array(m + 1));
      for (let i = 0; i <= n; i++) D[i][0] = i; for (let j = 0; j <= m; j++) D[0][j] = j;
      for (let i = 1; i <= n; i++) for (let j = 1; j <= m; j++) { const h = dizi[i - 1], c = ad[j - 1];
        const sub = h === null ? (c === " " ? 0 : 1) : c === " " ? 1 : 1 - (ABC.indexOf(c) >= 0 ? h.z[ABC.indexOf(c)] : 0);
        D[i][j] = Math.min(D[i - 1][j - 1] + sub, D[i - 1][j] + 1, D[i][j - 1] + 1); }
      const u = D[n][m] / Math.max(n, m, 1); if (!en || u < en.u) en = { ad, u }; }
    const hamGuven = harfler.filter(Boolean).reduce((a, h) => Math.min(a, h.p), 1);
    if (en && en.u <= 0.34) return { metin: en.ad, ham, guven: Math.max(0, 1 - en.u * 2), sozluk: true };
    return { metin: ham, ham, guven: ham ? hamGuven : 0, sozluk: false };
  }
  kok.ElHarf = { yukle, hazir, harfOku, sozlukDuzelt, ABC, VARSAYILAN_ADLAR };
  if (typeof module !== "undefined") module.exports = kok.ElHarf;
})(typeof globalThis !== "undefined" ? globalThis : this);
