// v2.3.26 (+v2.5.8 aylık sürüm 7 formlar, +v2.5.9 tek aylık tam/yarım + ders yılı kodu): Evrak Asistanı makine okunur veli izin formu okuyucu (köşe kareleri + konuma göre işaret okuma).
// Girdi: gri görüntü (Uint8Array, w, h). El yazısı OCR gerekmez. Form değilse null döner (eski okuyucuya düşülür).
(function (kok) {
  "use strict";
  let DUZEN = kok.VELI_FORM_DUZEN || null;
  function kucult(g, w, h, hedef) { // kutu ortalamasıyla küçült (uzun kenar ~hedef)
    const f = Math.max(1, Math.floor(Math.max(w, h) / hedef)); if (f === 1) return { g, w, h, f };
    const W = Math.floor(w / f), H = Math.floor(h / f), o = new Uint8Array(W * H);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { let s = 0; for (let j = 0; j < f; j++) { const r = (y * f + j) * w + x * f; for (let i = 0; i < f; i++) s += g[r + i]; } o[y * W + x] = s / (f * f); }
    return { g: o, w: W, h: H, f };
  }
  function integral(g, w, h) { const I = new Float64Array((w + 1) * (h + 1)); for (let y = 0; y < h; y++) { let s = 0; for (let x = 0; x < w; x++) { s += g[y * w + x]; I[(y + 1) * (w + 1) + x + 1] = I[y * (w + 1) + x + 1] + s; } } return I; }
  const kutuOrt = (I, w, h, x0, y0, x1, y1) => { x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(w, x1); y1 = Math.min(h, y1); const W = w + 1; const a = (x1 - x0) * (y1 - y0); return a > 0 ? (I[y1 * W + x1] - I[y0 * W + x1] - I[y1 * W + x0] + I[y0 * W + x0]) / a : 255; };
  function koyuHarita(g, w, h, R) { // yerel arka plana göre: m = koyu (0/1), k = koyuluk (0..255, sürekli)
    const I = integral(g, w, h), m = new Uint8Array(w * h), k = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = y * w + x, b = Math.max(40, kutuOrt(I, w, h, x - R, y - R, x + R + 1, y + R + 1)), p = g[i];
      m[i] = p < Math.min(b * 0.72, b - 30) ? 1 : 0; const d = (b * 0.92 - p) / (b * 0.35); k[i] = d <= 0 ? 0 : d >= 1 ? 255 : Math.round(d * 255); }
    return { m, k };
  }
  function bilesenler(m, w, h) {
    const lab = new Int32Array(w * h), out = [], st = [];
    for (let i = 0; i < w * h; i++) {
      if (!m[i] || lab[i]) continue; const id = out.length + 1; lab[i] = id; st.push(i);
      let n = 0, x0 = w, y0 = h, x1 = 0, y1 = 0, sx = 0, sy = 0;
      while (st.length) { const p = st.pop(), x = p % w, y = (p / w) | 0; n++; sx += x; sy += y; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
        for (const q of [p - 1, p + 1, p - w, p + w]) { if (q < 0 || q >= w * h || !m[q] || lab[q]) continue; if ((q === p - 1 && x === 0) || (q === p + 1 && x === w - 1)) continue; lab[q] = id; st.push(q); } }
      out.push({ n, x0, y0, x1, y1, cx: sx / n, cy: sy / n });
    }
    return out;
  }
  function homografi(src, dst) { // src (mm) -> dst (px), 4 nokta
    const A = [], b = [];
    for (let i = 0; i < 4; i++) { const [x, y] = src[i], [u, v] = dst[i];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u); A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v); }
    const n = 8; for (let c = 0; c < n; c++) { let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r; [A[c], A[p]] = [A[p], A[c]]; [b[c], b[p]] = [b[p], b[c]];
      for (let r = 0; r < n; r++) { if (r === c) continue; const f = A[r][c] / A[c][c]; for (let k = c; k < n; k++) A[r][k] -= f * A[c][k]; b[r] -= f * b[c]; } }
    const h = b.map((v, i) => v / A[i][i]);
    return (x, y) => { const d = h[6] * x + h[7] * y + 1; return [(h[0] * x + h[1] * y + h[2]) / d, (h[3] * x + h[4] * y + h[5]) / d]; };
  }
  function koseBul(m, w, h) {
    const bl = bilesenler(m, w, h), kenar = Math.min(w, h);
    const ad = bl.filter((c) => { const bw = c.x1 - c.x0 + 1, bh = c.y1 - c.y0 + 1; return bw > kenar / 70 && bw < kenar / 8 && bh / bw > 0.7 && bh / bw < 1.43 && c.n / (bw * bh) > 0.75; });
    const kose = [[0, 0], [w, 0], [0, h], [w, h]];
    return kose.map(([kx, ky]) => { let en = null, ed = Infinity; for (const c of ad) { const d = Math.hypot(c.cx - kx, c.cy - ky); if (d < ed && d < Math.hypot(w, h) * 0.3) { ed = d; en = c; } } return en; });
  }
  // örnekleme: mm merkezli kare/daire içinde koyu oranı
  function puan(m, w, h, H, x, y, yaricap, daire) {
    let k = 0, n = 0; const S = 9;
    for (let j = 0; j < S; j++) for (let i = 0; i < S; i++) { const dx = ((i + 0.5) / S * 2 - 1) * yaricap, dy = ((j + 0.5) / S * 2 - 1) * yaricap;
      if (daire && dx * dx + dy * dy > yaricap * yaricap) continue; const [u, v] = H(x + dx, y + dy); const ui = Math.round(u), vi = Math.round(v); if (ui < 0 || vi < 0 || ui >= w || vi >= h) continue; n++; k += m[vi * w + ui] / (m.olcek || 1); }
    return n ? k / n : 0;
  }
  // v2.4.7: işaret eşiği aynı sayfanın en boş kutularına göre — boş kutu (çerçeve/gürültü) işaretli sayılmasın; arada kalan KONTROL
  function esikHesap(hep) {
    const a = hep.slice().sort((x, y) => x - y), alt = a.slice(0, Math.max(1, Math.ceil(a.length * 0.4))), med = alt[Math.floor(alt.length / 2)] || 0;
    const sapma = alt.map((x) => Math.abs(x - med)).sort((x, y) => x - y)[Math.floor(alt.length / 2)] || 0;
    return { taban: med, kesin: Math.max(kok.ISARET_KESIN || 0.07, 5 * sapma), bel: Math.max(0.025, 2.5 * sapma) };
  }
  const IC_KIRP = 0.8; // kutu içinin dış %20'si (çerçeve, kayma) sayılmaz
  const ALT7 = [0, 1, 2, 3, 4, 5, 6, 7].map((i) => [58 + 12 * i, 283]); // v2.5.8: aylık formun alt kod sırası (mm)
  const YIL7A = [154, 164, 174, 184].map((x) => [x, 283]), YIL7U = [26, 36, 46, 56].map((x) => [x, 14]), YIL7_TABAN = 2025; // v2.5.9: ders yılı kodu (alt sağ 4 bit, üst sol tümleyen); yoksa/bozuksa eski yol
  function oku(gri, W0, H0) {
    if (!DUZEN) return null;
    const K = kucult(gri, W0, H0, 1600), { g, w, h } = K;
    const pxmm = Math.min(w, h) / 210; // kaba ölçek
    const KH = koyuHarita(g, w, h, Math.max(8, Math.round(pxmm * 12))), m = KH.m, k = KH.k;
    const f = koseBul(m, w, h); if (f.some((x) => !x)) return null;
    const ilk = DUZEN[Object.keys(DUZEN)[0]];
    const Hm = homografi(ilk.fid, f.map((c) => [c.cx, c.cy]));
    // ölçek tutarlılığı: köşe kare boyutu beklenene yakın mı
    const [ax] = Hm(0, 0), [bx] = Hm(ilk.fidA, 0); const bek = Math.abs(bx - ax), gercek = f.reduce((s, c) => s + (c.x1 - c.x0 + 1), 0) / 4; if (gercek < bek * 0.5 || gercek > bek * 1.8) return null;
    const bit = ilk.kodKutu.map(([x, y]) => puan(m, w, h, Hm, x, y, ilk.kodA * 0.3, false) > 0.5 ? 1 : 0);
    const v4 = bit[0] === 0 && bit[7] === 1; // v2.3.36: sürüm 4 formu (ilk bit 0, son bit 1)
    const fa = bit[0] === 0 && bit[7] === 0; // v2.3.37: faaliyet formu (ilk ve son bit 0)
    const v5 = v4 && [1, 2, 3].every((i) => bit[i] === bit[i + 3]); // v2.3.39: sürüm 5 formu (bit1-3 == bit4-6; ek 2 kutu: 4. bit + denetim)
    const v7 = fa && [1, 2, 3].every((i) => bit[i] === bit[i + 3]); // v2.5.8: aylık form (sürüm 7): ilk/son bit 0, bit1-3 == bit4-6 = tür; ek kutular [1,0]; alt sıra = ay (4 bit + tümleyen)
    let ek = [0, 0], D7 = null;
    if (v5 || v7) { ek = [[158, 14], [170, 14]].map(([x, y]) => puan(m, w, h, Hm, x, y, ilk.kodA * 0.3, false) > 0.5 ? 1 : 0); if (v7 ? !(ek[0] === 1 && ek[1] === 0) : ek[0] === ek[1]) return null; }
    if (v7) { const ab = ALT7.map(([x, y]) => puan(m, w, h, Hm, x, y, ilk.kodA * 0.3, false) > 0.5 ? 1 : 0); if ([0, 1, 2, 3].some((i) => ab[i] === ab[i + 4])) return null;
      const t7 = bit[1] * 4 + bit[2] * 2 + bit[3], ay7 = ab[0] * 8 + ab[1] * 4 + ab[2] * 2 + ab[3]; // düzen: aylik_form.js (üretim kaydı / okul takvimi) — basılan formla aynı işlev
      const ya = YIL7A.map(([x, y]) => puan(m, w, h, Hm, x, y, ilk.kodA * 0.3, false) > 0.5 ? 1 : 0), yu = YIL7U.map(([x, y]) => puan(m, w, h, Hm, x, y, ilk.kodA * 0.3, false) > 0.5 ? 1 : 0);
      const bas7 = ya.every((b, i) => b !== yu[i]) ? YIL7_TABAN + ya[0] * 8 + ya[1] * 4 + ya[2] * 2 + ya[3] : null; // v2.5.9: eski (2.5.8) formda kutular boş → tümleyen tutmaz → null
      D7 = kok.AylikForm && kok.AylikForm.duzenBul ? kok.AylikForm.duzenBul(t7, ay7, bas7) : null; if (!D7) return null; }
    if (!v7 && ((bit[0] !== 1 && !v4 && !fa) || (!v5 && [1, 2, 3].some((i) => bit[i] === bit[i + 3])))) return null;
    const kod = v7 ? D7.t : ek[0] * 8 + bit[1] * 4 + bit[2] * 2 + bit[3], D = D7 || DUZEN[String(v5 ? kod + 40 : fa ? kod + 30 : v4 ? kod + 20 : bit[7] ? kod : kod + 10)]; if (!D) return null; // v2.3.30: son bit 0 = Tam/Yarım kutulu form (anahtar kod+10)
    const uyari = [];
    // v2 (2.3.27): el yazısı alanlar — düzeltilmiş kırpıntı (8 px/mm), mürekkep = sürekli koyuluk > 0.5
    const ER = kok.ElRakam && kok.ElRakam.hazir() ? kok.ElRakam : null;
    // v2.4.9: kutu çerçevesi temizliği — tarama ölçeği/kayması yüzünden kesite giren kutu çizgileri (kenara yapışık uzun yatay/dikey koşular) silinir; rakamın kendisi (kenardan içeride) korunur.
    const CERCEVE_BANT = 0.09, CERCEVE_UZUN = 0.30;
    function cerceveTemizle(mk) { const { w: W, h: H, d } = mk, bx = Math.max(2, Math.round(W * CERCEVE_BANT)), by = Math.max(2, Math.round(H * CERCEVE_BANT));
      for (let y = 0; y < H; y++) { if (!(y < by || y >= H - by)) continue; let x = 0; while (x < W) { if (!d[y * W + x]) { x++; continue; } const s = x; while (x < W && d[y * W + x]) x++; if (x - s >= W * CERCEVE_UZUN) for (let i = s; i < x; i++) d[y * W + i] = 0; } }
      for (let x = 0; x < W; x++) { if (!(x < bx || x >= W - bx)) continue; let y = 0; while (y < H) { if (!d[y * W + x]) { y++; continue; } const s = y; while (y < H && d[y * W + x]) y++; if (y - s >= H * CERCEVE_UZUN) for (let j = s; j < y; j++) d[j * W + x] = 0; } }
      // eğik taranmış sayfada çizgi tek bir sütunda uzun koşu vermez: pikselinin çoğu kenar bandında olan her parça (köşe "L", kesik çizgi) çerçeve sayılır
      const lab = new Int32Array(W * H), bx2 = Math.max(3, Math.round(W * 0.12)), by2 = Math.max(3, Math.round(H * 0.12));
      for (let i = 0; i < W * H; i++) { if (!d[i] || lab[i]) continue; const st = [i], px = []; lab[i] = 1; let kenarda = 0;
        while (st.length) { const q = st.pop(), x = q % W, y = (q / W) | 0; px.push(q); if (x < bx2 || x >= W - bx2 || y < by2 || y >= H - by2) kenarda++;
          for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue; const r = yy * W + xx; if (d[r] && !lab[r]) { lab[r] = 1; st.push(r); } } }
        if (kenarda >= px.length * 0.65) px.forEach((q) => { d[q] = 0; }); }
      return mk; }
    function kirpHam(x0, y0, ww, hh, ic) { const R = kok.KR || 6, W = Math.round((ww - 2 * ic) * R), H = Math.round((hh - 2 * ic) * R), d = new Uint8Array(W * H);
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const [u, v] = Hm(x0 + ic + (x + 0.5) / R, y0 + ic + (y + 0.5) / R); const ui = Math.round(u), vi = Math.round(v); if (ui >= 0 && vi >= 0 && ui < w && vi < h) d[y * W + x] = k[vi * w + ui] > (kok.KE || 40) ? 1 : 0; }
      return { w: W, h: H, d }; }
    const kirp = kirpHam; // genel kesit: eski davranış (faaliyet/süre vb. akışlar değişmez)

    // v2.4.9: kutuya hizalı kesit. Tarama ölçeği/kayması yüzünden nominal kutu konumu gerçek baskıdan ~1–2 mm sapabilir; bu yüzden kutunun çevresinde
    // biraz GENİŞ bir pencere alınır, en uzun dikey/yatay çizgiler (kutu çerçevesi) bulunur ve kesit çerçevenin İÇİNDEN yapılır. Bulunamazsa nominal kesit kullanılır.
    function kirpKutu(x0, y0, ww, hh, ic) {
      const R = kok.KR || 6, GEN = 2.4, E = kirpHam(x0, y0, ww, hh, -GEN), W = E.w, H = E.h, d = E.d, nom = cerceveTemizle(kirpHam(x0, y0, ww, hh, ic));
      const cc = new Int32Array(W), rr = new Int32Array(H); for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (d[y * W + x]) { cc[x]++; rr[y]++; }
      // çizgi adayları: profilde eşik üstü, yerel tepe noktaları (yan yana pikseller tek çizgi sayılır)
      const tepeler = (pr, esik) => { const o = []; for (let i = 0; i < pr.length;) { if (pr[i] < esik) { i++; continue; } let a = i, bi = i; while (i < pr.length && pr[i] >= esik) { if (pr[i] > pr[bi]) bi = i; i++; } o.push({ l: a, r: i - 1, c: (a + i - 1) / 2, v: pr[bi] }); } return o; };
      // kutunun bilinen boyuna (ww/hh mm) uyan ve nominal konuma en yakın çizgi çifti
      const cift = (pr, esik, boy, nomA, nomB) => { const T = tepeler(pr, esik); let en = null, ep = 1e9; for (let a = 0; a < T.length; a++) for (let b = a + 1; b < T.length; b++) { const sp = T[b].c - T[a].c; if (Math.abs(sp - boy) > boy * 0.14) continue; const ort = (T[a].c + T[b].c) / 2, puan = Math.abs(sp - boy) + Math.abs(ort - (nomA + nomB) / 2) * 0.7 - (T[a].v + T[b].v) * 0.01; if (puan < ep) { ep = puan; en = [T[a], T[b]]; } } return en; };
      const mg = Math.max(2, Math.round(0.5 * R)), nomL = Math.round(GEN * R), nomR = W - nomL, nomT = nomL, nomB = H - nomL;
      const cv = cift(cc, H * 0.4, ww * R, nomL, nomR), ch = cift(rr, W * 0.4, hh * R, nomT, nomB);
      let L = nomL, Rr = nomR, T = nomT, B = nomB;
      const ok = []; if (cv) { L = cv[0].r + 1 + mg; Rr = cv[1].l - mg; ok.push("x"); } if (ch) { T = ch[0].r + 1 + mg; B = ch[1].l - mg; ok.push("y"); }
      const gw = Rr - L, gh = B - T; if (!ok.length || gw < (nomR - nomL) * 0.6 || gh < (nomB - nomT) * 0.6 || gw > (nomR - nomL) * 1.25 || gh > (nomB - nomT) * 1.25) return nom;
      const o = new Uint8Array(gw * gh); for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) o[y * gw + x] = d[(T + y) * W + (L + x)];
      return cerceveTemizle({ w: gw, h: gh, d: o });
    }
    // v2.4.2: Yerel Okuma Servisi için numara kutularının gri şeridi — yalnız kok.YEREL_KIRP açıkken; kutu çizgileri dışarıda, kutular arası beyaz boşluk
    function griSerit(kutular, ic) { if (!kok.YEREL_KIRP || !kutular || !kutular.length) return null; const R = 6, B = 6, i2 = ic + 0.2;
      const P = kutular.map((b) => ({ b, W: Math.max(1, Math.round((b.w - 2 * i2) * R)), H: Math.max(1, Math.round((b.h - 2 * i2) * R)) }));
      const SH = Math.max(...P.map((p) => p.H)) + 2 * B, SW = P.reduce((t, p) => t + p.W + B, B), d = new Uint8Array(SW * SH).fill(255); let ox = B;
      for (const p of P) { for (let y = 0; y < p.H; y++) for (let x = 0; x < p.W; x++) { const [u, v] = Hm(p.b.x + i2 + (x + 0.5) / R, p.b.y + i2 + (y + 0.5) / R); const ui = Math.round(u), vi = Math.round(v); if (ui >= 0 && vi >= 0 && ui < w && vi < h) d[(B + y) * SW + ox + x] = g[vi * w + ui]; } ox += p.W + B; }
      return { w: SW, h: SH, d }; }
    const yerelEk = (kutular, ic) => (kok.YEREL_KIRP ? { noGoruntu: griSerit(kutular, ic) } : {});
    function parcala(mk, gevsek) { // 8-komşu bileşenler, küçük lekeler atılır
      const lab = new Int32Array(mk.w * mk.h), out = []; const { w: W, h: H, d } = mk;
      for (let i = 0; i < W * H; i++) { if (!d[i] || lab[i]) continue; const st = [i]; lab[i] = out.length + 1; const c = { n: 0, x0: W, y0: H, x1: 0, y1: 0, p: [] };
        while (st.length) { const q = st.pop(), x = q % W, y = (q / W) | 0; c.n++; c.p.push(q); if (x < c.x0) c.x0 = x; if (x > c.x1) c.x1 = x; if (y < c.y0) c.y0 = y; if (y > c.y1) c.y1 = y;
          for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue; const r = yy * W + xx; if (d[r] && !lab[r]) { lab[r] = lab[i]; st.push(r); } } }
        out.push(c); }
      const ana = out.filter((c) => c.n > W * H * 0.006 && Math.max(c.x1 - c.x0, c.y1 - c.y0) > Math.min(W, H) * 0.12);
      return gevsek && ana.length ? out.filter((c) => c.n > W * H * 0.0015) : ana; // gevşek: kopuk rakam parçaları da alınır
    }
    const maske = (mk, cs) => { const d = new Uint8Array(mk.w * mk.h); cs.forEach((c) => c.p.forEach((q) => { d[q] = 1; })); return { w: mk.w, h: mk.h, d }; };
    const rakam = (mk, cs) => { if (!ER) return null; const t = ER.mnist(maske(mk, cs)); if (kok.DOKUM) kok.DOKUM(maske(mk, cs), t); if (!t) return null; const z = ER.siniflandir(t); let b = 0; for (let i = 1; i < 10; i++) if (z[i] > z[b]) b = i; return { d: b, p: z[b], z }; };
    // v2.3.36: kutu çizgisi (kenara yapışık ince şerit) rakam sayılmaz — hayalet hane olmasın; boş kutu atlanır
    const kenarCizgisi = (c, mk) => { const cw = c.x1 - c.x0 + 1, ch = c.y1 - c.y0 + 1;
      return (cw <= mk.w * 0.16 && (c.x0 <= 1 || c.x1 >= mk.w - 2)) || (ch <= mk.h * 0.12 && (c.y0 <= 1 || c.y1 >= mk.h - 2)); };
    if (D.tip === "faaliyet") return faaliyetOku();
    if (D.tip === "faaliyet2" || (D.formSurum === 7 && D.t !== 1 && D.t !== 5)) return faaliyet2Oku(); // v2.5.9: tür 5 (tek aylık tam/yarım) veli izni yolunda // v2.5.8: aylık toplu / bireysel faaliyet ve devamsızlık takip formu aynı okuyucuyla (gün hücresinde tarih hazır) // // v2.3.38: toplu (2 aylık ortak takvim) / bireysel (öğrenci başına 1–31) + harf kutulu faaliyet adı
    function faaliyet2Oku() {
      k.olcek = 255; const uyari = [], ic = D.kutuA / 2 - 0.9, ayl = D.formSurum === 7, bireysel = ayl ? D.t !== 2 : !!D.bireysel;
      const ayOku = (kut) => { const r = kutularOku(kut, 0.8); const M = +r.s; return r.s ? (M >= 1 && M <= 12 ? { M, g: r.g, s: r.s } : { M: 0, s: r.s, hata: true }) : null; };
      const aylar = ayl ? [] : D.aylar.map(ayOku);
      const hucreler = bireysel ? D.satirlar.flatMap((sr) => sr.gunler.map((q) => ({ ...q, sr: sr.s }))) : D.takvim.map((q) => ({ ...q, sr: -1 }));
      const fa = hucreler.map((q) => puan(k, w, h, Hm, q.x, q.y, ic * IC_KIRP, false)), fy = hucreler.map((q) => puan(k, w, h, Hm, q.yx, q.yy, ic * IC_KIRP, false));
      const E = esikHesap([...fa, ...fy]), taban = E.taban;
      const isaretler = []; let belirsiz = 0;
      hucreler.forEach((q, i) => { const a = fa[i] - taban, b = fy[i] - taban, buyuk = Math.max(a, b), kucuk = Math.min(a, b);
        if (buyuk > E.kesin) { const cift = kucuk > E.kesin * 0.6 && kucuk > 0.35 * buyuk, sup = !cift && kucuk > E.bel && kucuk > 0.2 * buyuk; isaretler.push({ q, yarim: b > a && !cift, cift, sup }); }
        else if (buyuk > E.bel) belirsiz++; });
      if (belirsiz) uyari.push(`${belirsiz} gün kutusunda belirsiz işaret — kontrol edin`);
      const tarihYap = (m) => { const notlar = [];
        if (m.q.t) { if (m.cift) notlar.push("Tam ve Yarım ikisi de işaretli — kontrol edin"); else if (m.sup) notlar.push("Tam/Yarım işareti belirsiz — kontrol edin"); // v2.5.8: aylık form — tarih formda basılı
          return { tarih: m.q.t, gun: m.yarim ? 0.5 : 1, yarim: m.yarim, guven: notlar.length ? 40 : 95, supheli: false, not: notlar.join("; "), sureHam: m.cift ? "ikisi" : m.yarim ? "Yarım" : "Tam" }; }
        const A = aylar[m.q.ay];
        if (!A) return { tarih: "", gun: 1, yarim: false, guven: 0, supheli: false, not: `${m.q.ay + 1}. ay kutusu boş — ayı yazın`, sureHam: "" };
        if (A.hata) return { tarih: "", gun: 1, yarim: false, guven: 0, supheli: false, not: `${m.q.ay + 1}. ay okunamadı (${A.s})`, sureHam: "" };
        const Y = A.M >= 9 ? D.yil : D.yil + 1, dt = new Date(Y, A.M - 1, m.q.g);
        if (dt.getMonth() !== A.M - 1) return { tarih: "", gun: 1, yarim: false, guven: 0, supheli: false, not: `${m.q.g}.${A.M} geçersiz gün`, sureHam: "" };
        if (dt.getDay() % 6 === 0) notlar.push("hafta sonu işaretli — kontrol edin");
        if (A.M === 7 || A.M === 8) notlar.push("yaz tatili ayı — kontrol edin");
        if (m.cift) notlar.push("Tam ve Yarım ikisi de işaretli — kontrol edin"); else if (m.sup) notlar.push("Tam/Yarım işareti belirsiz — kontrol edin");
        if (A.g < 0.8) notlar.push(`ay emin değil (${A.s})`);
        return { tarih: `${String(m.q.g).padStart(2, "0")}/${String(A.M).padStart(2, "0")}/${Y}`, gun: m.yarim ? 0.5 : 1, yarim: m.yarim, guven: notlar.length ? 40 : 95, supheli: false, not: notlar.join("; "), sureHam: m.cift ? "ikisi" : m.yarim ? "Yarım" : "Tam" }; };
      const ogrenciler = [];
      for (const sr of D.satirlar) { const r = kutularOku(sr.no, 1.0); const kendi = bireysel ? isaretler.filter((m) => m.q.sr === sr.s).map(tarihYap) : null;
        if (!r.s) { if (kendi && kendi.length) uyari.push(`${sr.s + 1}. öğrencinin numarası yok ama günü işaretli`); continue; }
        ogrenciler.push({ satir: sr.s + 1, no: r.s, noGuven: r.g, noUyari: r.bosluk ? "numara kutuları arasında boşluk var" : r.g < 0.8 ? `numara emin değil (${r.s})` : "", tarihler: kendi, ...yerelEk(sr.no, 1.0) }); }
      const tarihler = bireysel ? [] : isaretler.map(tarihYap);
      if (ayl && D.t === 4) { if (!ogrenciler.length) uyari.push("Formda okul numarası yok"); if (!ogrenciler.some((o) => o.tarihler.length)) uyari.push("Formda işaretli gün yok");
        return { form: true, devamsizlik: true, surum: 7, ay: D.ay, yil: D.yil, kod, no: "", noGuven: 1, noUyari: "", tarihler: [], ogrenciler, uyari, olcek: K.f }; } // v2.5.8: devamsızlık takip formu
      // faaliyet adı: harf kutuları → yerel harf modeli → sözlük düzeltmesi
      const EH = kok.ElHarf && kok.ElHarf.hazir() ? kok.ElHarf : null; let ad = { metin: "", ham: "", guven: 0, sozluk: false };
      if (EH && D.harf.length) { const harfler = D.harf.map((b) => { const mk = kirp(b.x, b.y, b.w, b.h, 0.7); let cs = parcala(mk, true).filter((c) => !kenarCizgisi(c, mk));
          if (cs.length && !cs.some((c) => Math.max(c.x1 - c.x0, c.y1 - c.y0) > Math.min(mk.w, mk.h) * 0.25)) cs = []; return cs.length ? EH.harfOku(maske(mk, cs)) : null; });
        while (harfler.length && !harfler[harfler.length - 1]) harfler.pop();
        ad = EH.sozlukDuzelt(harfler, kok.FAALIYET_ADLARI && kok.FAALIYET_ADLARI.length ? kok.FAALIYET_ADLARI : EH.VARSAYILAN_ADLAR); }
      else if (D.harf.length) uyari.push("harf modeli yüklenmedi — faaliyet adını elle yazın");
      // ad bölgesinin (harf kutuları + açık yazı satırı) küçük gri görüntüsü — onay için ekranda gösterilir, yerel kalır
      const R = 4, [GX, GY, GW, GH] = D.adBolge || [20, 50, 170, 20], gw = GW * R, gh = GH * R, gd = new Uint8Array(gw * gh);
      for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) { const [u, v] = Hm(GX + (x + 0.5) / R, GY + (y + 0.5) / R); const ui = Math.round(u), vi = Math.round(v); gd[y * gw + x] = ui >= 0 && vi >= 0 && ui < w && vi < h ? g[vi * w + ui] : 255; }
      if (!ogrenciler.length) uyari.push("Formda okul numarası yok");
      if (!(bireysel ? ogrenciler.some((o) => o.tarihler.length) : tarihler.length)) uyari.push("Formda işaretli gün yok");
      return { form: true, faaliyet: true, surum: 6, bireysel, ...(ayl ? { aylik: true, ay: D.ay, yil: D.yil } : {}), kod, no: "", noGuven: 1, noUyari: "", tarihler, ogrenciler, ad, adGoruntu: { w: gw, h: gh, d: gd }, uyari, olcek: K.f };
    }
    // v2.3.37: faaliyet formu — 14 öğrenci satırı (4 kutulu okul no) + 4 tarih yuvası (gün/ay rakamları + Tam/Yarım)
    function kutularOku(kutular, ic) {
      let s = "", g = 1, bos = 0, ara = false;
      for (const b of kutular) { const mk = kirp(b.x, b.y, b.w, b.h, ic); let cs = parcala(mk, true).filter((c) => !kenarCizgisi(c, mk));
        if (cs.length && !cs.some((c) => Math.max(c.x1 - c.x0, c.y1 - c.y0) > Math.min(mk.w, mk.h) * 0.25)) cs = [];
        if (!cs.length) { bos++; if (s) ara = true; continue; }
        const r = rakam(mk, cs); if (!r) return { s: "", g: 0, hata: "rakam modeli yok" };
        if (ara) ara = "bosluk"; s += r.d; g = Math.min(g, r.p); }
      return { s, g, bosluk: ara === "bosluk" };
    }
    function faaliyetOku() {
      k.olcek = 255; const uyari = [], tarihler = [], ogrenciler = [];
      for (const t of D.tarihler) {
        const gu = kutularOku(t.gun, 0.8), ay = kutularOku(t.ay, 0.8);
        const a = puan(k, w, h, Hm, t.x, t.y, (D.kutuA / 2 - 1.0) * IC_KIRP, false), b = puan(k, w, h, Hm, t.yx, t.yy, (D.kutuA / 2 - 1.0) * IC_KIRP, false);
        if (!gu.s && !ay.s) { if (Math.max(a, b) > 0.06) uyari.push(`${t.s + 1}. gün: işaret var ama tarih yazılmamış`); continue; }
        const G = +gu.s, A = +ay.s, Y = A >= 9 ? D.yil : D.yil + 1, dt = new Date(Y, A - 1, G);
        const gecerli = gu.s && ay.s && A >= 1 && A <= 12 && dt.getDate() === G && dt.getMonth() === A - 1;
        const tarih = gecerli ? `${String(G).padStart(2, "0")}/${String(A).padStart(2, "0")}/${Y}` : "";
        const buyuk = Math.max(a, b), kucuk = Math.min(a, b), isaretli = buyuk > 0.06, cift = isaretli && kucuk > 0.06 && kucuk > 0.35 * buyuk, yarim = isaretli && b > a && !cift;
        const notlar = [];
        if (!gecerli) notlar.push(`${t.s + 1}. gün tarihi okunamadı (${gu.s || "?"}/${ay.s || "?"})`);
        if (gecerli && (A === 7 || A === 8)) notlar.push("yaz tatili tarihi — kontrol edin");
        if (!isaretli) notlar.push("Tam/Yarım işaretlenmemiş — tam gün varsayıldı");
        if (cift) notlar.push("Tam ve Yarım ikisi de işaretli — kontrol edin");
        const guven = Math.round(100 * Math.min(gu.g || 0, ay.g || 0));
        tarihler.push({ tarih, gun: yarim ? 0.5 : 1, yarim, guven: notlar.length || guven < 80 ? Math.min(guven, 60) : 95, supheli: false, not: notlar.join("; ") || (guven < 80 ? `tarih emin değil (${gu.s}/${ay.s})` : ""), sureHam: cift ? "ikisi" : yarim ? "Yarım" : "Tam" });
      }
      for (const sr of D.satirlar) { const r = kutularOku(sr.no, D.surum >= 4 ? 1.0 : 0.9); if (!r.s) continue;
        ogrenciler.push({ satir: sr.s + 1, no: r.s, noGuven: r.g, noUyari: r.bosluk ? "numara kutuları arasında boşluk var" : r.g < 0.8 ? `numara emin değil (${r.s})` : "", ...yerelEk(sr.no, D.surum >= 4 ? 1.0 : 0.9) }); }
      if (!ogrenciler.length) uyari.push("Formda okul numarası yok");
      if (!tarihler.length) uyari.push("Formda tarih yok");
      return { form: true, faaliyet: true, surum: 5, kod, no: "", noGuven: 1, noUyari: "", tarihler, ogrenciler, uyari, olcek: K.f };
    }
    // okul no
    let no = "", noGuven = 1, noUy = "", bosOrta = false; const noOlas = []; // v2.5.0: her hanenin 10 sınıf olasılığı (öğrenci listesiyle eşleştirme için)
    for (const b of D.no) { const mk = kirpKutu(b.x, b.y, b.w, b.h, D.surum === 4 ? (kok.NO_IC || 1.1) : 0.9); let cs = parcala(mk, true).filter((c) => !kenarCizgisi(c, mk));
      if (cs.length && !cs.some((c) => Math.max(c.x1 - c.x0, c.y1 - c.y0) > Math.min(mk.w, mk.h) * 0.25)) cs = []; // yalnız kırıntı: boş kutu
      if (!cs.length) { if (no) bosOrta = true; continue; }
      const r = rakam(mk, cs); if (!r) { noUy = "okul numarası okunamadı (rakam modeli yok)"; noGuven = 0; break; }
      if (bosOrta) noUy = "numara kutuları arasında boşluk var";
      no += r.d; noOlas.push(Array.from(r.z, (v) => +v.toFixed(4))); noGuven = Math.min(noGuven, r.p); }
    if (!no && !noUy) noUy = "okul numarası yazılmamış"; else if (no && noGuven < 0.8) noUy = noUy || `numara emin değil (${no})`;
    // günler: işaret kutusu + süre
    k.olcek = 255; const ic = D.surum === 4 ? (kok.IC_T || 1.0) : 0.9; // v2.3.36: sürüm 4'te örnekleme kutu içinde, kenardan 1 mm içeride
    const kp = D.gunler.map((q) => puan(k, w, h, Hm, q.x, q.y, (D.kutuA / 2 - ic) * IC_KIRP, false));
    if (D.surum >= 3) { // v2.3.30: her günde Tam / Yarım kutusu; ikisi birden ya da belirsizse KONTROL
      const ky = D.gunler.map((q) => puan(k, w, h, Hm, q.yx, q.yy, (D.kutuA / 2 - ic) * IC_KIRP, false)), E = esikHesap([...kp, ...ky]);
      const taban = E.taban, tarihler = []; let belirsiz = 0;
      // v2.3.36: komşu günler (gün k Yarım | gün k+1 Tam) arasında taşma — işaret tek kutuya: dolgusu büyük olan kazanır
      if (D.surum === 4) D.gunler.forEach((q, i) => { const n = D.gunler[i + 1]; if (!n || Math.abs(n.y - q.y) > 1 || !(n.x - q.x > 0 && n.x - q.x < 20)) return;
        const a = ky[i] - taban, b = kp[i + 1] - taban; if (a <= 0.012 || b <= 0.012) return;
        const B = kok.BLEED_T || 0.15; if (a < B * b) ky[i] = taban; else if (b < B * a) kp[i + 1] = taban; });
      D.gunler.forEach((q, i) => { const a = kp[i] - taban, b = ky[i] - taban, buyuk = Math.max(a, b), kucuk = Math.min(a, b);
        if (buyuk > E.kesin) { const yarim = b > a, cift = kucuk > E.kesin * 0.6 && kucuk > 0.35 * buyuk, sup = !cift && kucuk > E.bel && kucuk > 0.2 * buyuk;
          tarihler.push({ tarih: q.t, gun: yarim ? 0.5 : 1, yarim, guven: cift || sup ? 40 : 95, supheli: false, not: cift ? "Tam ve Yarım ikisi de işaretli — kontrol edin" : sup ? "Tam/Yarım işareti belirsiz — kontrol edin" : "", sureHam: cift ? "ikisi" : yarim ? "Yarım" : "Tam", isaret: +(buyuk + taban).toFixed(2) }); }
        else if (buyuk > E.bel) belirsiz++; });
      if (belirsiz) uyari.push(`${belirsiz} gün kutusunda belirsiz işaret — kontrol edin`);
      return { form: true, surum: 3, kod, donem: D.aylar, ...(D.formSurum === 7 ? { aylik: true, ay: D.ay, yil: D.yil } : {}), no, noOlas, noGuven, noUyari: noUy, sinif: "", tarihler, uyari, olcek: K.f, ...(no ? yerelEk(D.no, D.surum === 4 ? (kok.NO_IC || 1.1) : 0.9) : {}) };
    }
    if (kok.HATA_AYIKLA) console.log("gün", [...kp].sort((a, b) => b - a).slice(0, 10).map((x) => x.toFixed(3)).join(" "));
    const E1 = esikHesap(kp), taban = E1.taban, esik = taban + E1.kesin; // v2.4.7
    const tarihler = []; let belirsiz = 0;
    D.gunler.forEach((q, i) => { const p = kp[i];
      if (p > esik) { const s = sureOku(kirp(q.sx, q.sy, q.sw, q.sh, 0.7)); tarihler.push({ tarih: q.t, gun: s.sure, yarim: s.sure === 0.5, guven: s.guven, supheli: false, not: s.not, sureHam: s.ham, isaret: +p.toFixed(2) }); }
      else if (p > taban + E1.bel) belirsiz++; });
    if (belirsiz) uyari.push(`${belirsiz} gün kutusunda belirsiz işaret — kontrol edin`);
    function sureOku(mk) {
      const cs = parcala(mk); if (!cs.length) return { sure: 1, guven: 50, ham: "", not: "Süre yazılmamış; tam gün (1) varsayıldı — kontrol edin" };
      const x0 = Math.min(...cs.map((c) => c.x0)), x1 = Math.max(...cs.map((c) => c.x1)), y0 = Math.min(...cs.map((c) => c.y0)), y1 = Math.max(...cs.map((c) => c.y1));
      const bw = x1 - x0 + 1, bh = y1 - y0 + 1, buyuk = cs.filter((c) => (c.y1 - c.y0) > bh * 0.45);
      if (buyuk.length >= 2 || bw / bh > 1.05) { // 0,5 / 0.5: iki rakam (+ virgül)
        const sir = [...(buyuk.length >= 2 ? buyuk : cs)].sort((a, b) => a.x0 - b.x0), r0 = rakam(mk, [sir[0]]), r1 = rakam(mk, [sir[sir.length - 1]]);
        const p = r0 && r1 ? Math.min(r0.z[0] + r0.z[6] * 0.5, r1.z[5] + r1.z[3] * 0.3 + r1.z[6] * 0.3) : 0.6;
        return { sure: 0.5, guven: p > 0.5 ? 95 : 75, ham: "0,5", not: p > 0.5 ? "" : "" };
      }
      const c = buyuk.length ? buyuk.sort((a, b) => b.n - a.n)[0] : cs[0], W = mk.w, cw = c.x1 - c.x0 + 1, ch = c.y1 - c.y0 + 1;
      if (cw / ch > 1.25 && cs.length >= 2) return { sure: 0.5, guven: 80, ham: "0,5?", not: "" };
      // tek parça: 1 / T / Y
      const pk = new Set(c.p), kosu = (y) => { let n = 0, on = false, gen = 0, ilk = -1, son = -1; for (let x = c.x0; x <= c.x1; x++) { const v = pk.has(y * W + x); if (v && !on) n++; if (v) { if (ilk < 0) ilk = x; son = x; } on = v; } return { n, gen: ilk < 0 ? 0 : son - ilk + 1 }; };
      const ust = [], alt = []; for (let y = c.y0; y <= c.y1; y++) { const r = (y - c.y0) / ch; if (r < 0.3) ust.push(kosu(y)); else if (r > 0.6) alt.push(kosu(y)); }
      const med = (a) => [...a].sort((x, y) => x - y)[a.length >> 1] || 0;
      const ustN = med(ust.map((u) => u.n)), ustGen = Math.max(...ust.map((u) => u.gen), 0), altGen = med(alt.map((u) => u.gen));
      const r = rakam(mk, [c]); const p1 = r ? r.z[1] : 0;
      if (cw / ch < 0.38 || (p1 > 0.6 && cw / ch < 0.7 && ustN < 2)) return { sure: 1, guven: 95, ham: "1", not: "" };
      if (ustN >= 2 && altGen < cw * 0.45) return { sure: 0.5, guven: 90, ham: "Y", not: "" };
      if (ustN <= 1 && ustGen > cw * 0.7 && altGen < cw * 0.45) return { sure: 1, guven: 90, ham: "T", not: "" };
      if (r && ustN < 2 && (r.d === 1 || r.z[1] + r.z[7] > 0.5)) return { sure: 1, guven: 85, ham: "1", not: "" };
      return { sure: 1, guven: 50, ham: "?", not: "Süre okunamadı; tam gün (1) varsayıldı — kontrol edin" };
    }
    return { form: true, surum: D.surum || 1, kod, donem: D.aylar, no, noOlas, noGuven, noUyari: noUy, sinif: "", tarihler, uyari, olcek: K.f, ...(no ? yerelEk(D.no, D.surum === 4 ? (kok.NO_IC || 1.1) : 0.9) : {}) };
  }
  function dondur90(g, w, h, saat) { const o = new Uint8Array(w * h); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const nx = saat ? h - 1 - y : y, ny = saat ? x : w - 1 - x; o[ny * h + nx] = g[y * w + x]; } return o; }
  function okuHerYon(g, w, h) { // dik/ters/yan taranmış sayfa: dönem kodu satırı üstte olana kadar dener
    const ters = (a) => { const o = new Uint8Array(a.length); for (let i = 0; i < a.length; i++) o[i] = a[a.length - 1 - i]; return o; };
    const adaylar = w > h ? [[dondur90(g, w, h, true), h, w, 90], [dondur90(g, w, h, false), h, w, 270]] : [[g, w, h, 0], [null, w, h, 180]];
    for (const [a, W, H, aci] of adaylar) { const r = oku(a || ters(g), W, H); if (r) { r.aci = aci; return r; } }
    if (w > h) return null;
    return null;
  }
  kok.VeliFormu = { oku: okuHerYon, okuDik: oku, duzenAyarla: (d) => { DUZEN = d; }, _esik: esikHesap };
  if (typeof module !== "undefined") module.exports = kok.VeliFormu;
})(typeof globalThis !== "undefined" ? globalThis : this);
