# Ortak okuma modülü (v2.3.23)
El yazısı rakam/tarih okuma; tamamen yerel (KVKK). Şu an yalnız veli izni akışı kullanıyor; Not Girişi ve diğer modüller aynı dosyaları yükleyecek.
- `rakam.js` → `ElRakam`: yukle(buf), bilesenler, grupOku, tarihOku, numaraOku, maskeAl. Ağırlıklar `lib/rakam.bin` (467 818 float).
- `duzen.js` → `VeliDuzen`: izgara(img, {bugun}), oku(img, kel, opt), egimBul. Satır sonucu: tarih, guven, supheli, gunSay, gunSayGuven, not.
- Web Worker'dan: `importScripts("../ortak/okuma/rakam.js", "../ortak/okuma/duzen.js")`; sayfadan `<script src="../ortak/okuma/...">`.
- Ağır iş Worker'da yapılmalı (arayüz donmasın). Yeni form türü eklerken izgara/hücre kurallarını ayrı dosyada tutun, rakam.js'e dokunmayın.
