// v2.3.16: Standart veli izni formu hücre düzeni (masaüstü Python okuyucusundan aktarıldı).
// Basılı başlıklar (İzin Tarihi / Gün Sayısı / Sınıfı-Numarası) Tesseract kelime kutularından; satırlar basılı yatay
// tablo çizgilerinden (düzenli aralığa oturtulur, 5 satır); her hücrede renkli mürekkep -> bileşenler -> ElRakam.
(function (kok) {
  const R = () => kok.ElRakam;
  const ORAN_AYRAC = 0.355, ORAN_YIL = 0.6, SATIR = 5;
  function maskeler(img) { // img: {width,height,data}
    const W = img.width, H = img.height, d = img.data, ink = new Uint8Array(W * H), koyu = new Uint8Array(W * H), gri = new Uint8Array(W * H);
    for (let i = 0; i < W * H; i++) { const r = d[4 * i], g = d[4 * i + 1], b = d[4 * i + 2], mx = Math.max(r, g, b), mn = Math.min(r, g, b);
      ink[i] = mx - mn > 45 && mn < 200 ? 1 : 0; koyu[i] = mx < 150 ? 1 : 0; gri[i] = mx < 170 && mx - mn < 45 ? 1 : 0; }
    // kalemin basılı nokta/çizgi üstünden geçtiği yer siyah görünür: mürekkebe komşu koyu pikseli geri ekle (25 px'ten uzun yatay çizgiler hariç)
    const yat = new Uint8Array(W * H);
    for (let y = 0; y < H; y++) { let s = -1; for (let x = 0; x <= W; x++) { const v = x < W && koyu[y * W + x]; if (v && s < 0) s = x; else if (!v && s >= 0) { if (x - s >= 25) for (let k = s; k < x; k++) yat[y * W + k] = 1; s = -1; } } }
    const out = new Uint8Array(ink);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const i = y * W + x; if (ink[i] || !koyu[i] || yat[i]) continue;
      let yakin = 0; for (let dy = -2; dy <= 2 && !yakin; dy++) for (let dx = -2; dx <= 2; dx++) { const yy = y + dy, xx = x + dx; if (yy >= 0 && yy < H && xx >= 0 && xx < W && ink[yy * W + xx]) { yakin = 1; break; } }
      if (yakin) out[i] = 1; }
    return { W, H, ink: out, gri };
  }
  function kes(M, x0, y0, x1, y1, kaynak) { x0 = Math.max(0, x0 | 0); y0 = Math.max(0, y0 | 0); x1 = Math.min(M.W, x1 | 0); y1 = Math.min(M.H, y1 | 0);
    const w = Math.max(0, x1 - x0), h = Math.max(0, y1 - y0), d = new Uint8Array(w * h), s = kaynak || M.ink;
    for (let y = 0; y < h; y++) d.set(s.subarray((y + y0) * M.W + x0, (y + y0) * M.W + x0 + w), y * w); return { w, h, d, x0, y0 }; }
  function satirCizgileri(M, x0, x1, y0, y1) {
    const m = kes(M, x0, y0, x1, y1, M.gri), L = Math.max(8, Math.floor(m.w / 12)), prof = new Array(m.h).fill(0);
    for (let y = 0; y < m.h; y++) { let s = -1; for (let x = 0; x <= m.w; x++) { const v = x < m.w && m.d[y * m.w + x]; if (v && s < 0) s = x; else if (!v && s >= 0) { if (x - s >= L) prof[y] += x - s; s = -1; } } }
    const ys = []; let bas = -1; const esik = m.w * 0.13;
    for (let i = 0; i <= m.h; i++) { const v = i < m.h ? prof[i] : 0; if (v > esik && bas < 0) bas = i; else if (v <= esik && bas >= 0) { ys.push(y0 + ((bas + i) >> 1)); bas = -1; } }
    return ys;
  }
  function satirDuzenle(ys, hh) {
    ys = [...ys].sort((a, b) => a - b); const bir = [];
    for (const y of ys) { if (bir.length && y - bir[bir.length - 1][bir[bir.length - 1].length - 1] < hh * 0.4) bir[bir.length - 1].push(y); else bir.push([y]); }
    ys = bir.map((b) => Math.round(b.reduce((s, v) => s + v, 0) / b.length)); if (ys.length < 2) return ys;
    const d = ys.slice(1).map((y, i) => y - ys[i]).filter((g) => g > hh * 0.7).sort((a, b) => a - b); if (!d.length) return ys;
    const med = d.length % 2 ? d[(d.length - 1) / 2] : (d[d.length / 2 - 1] + d[d.length / 2]) / 2, out = [ys[0]];
    for (const y of ys.slice(1)) { const g = y - out[out.length - 1]; if (g < med * 0.6) continue; const n = Math.round(g / med); for (let k = 1; k < n; k++) out.push(Math.round(out[out.length - 1] + g / n)); out.push(y); }
    while (out.length < SATIR + 1) out.push(Math.round(out[out.length - 1] + med));
    return out.slice(0, SATIR + 1);
  }
  function cizgiMi(c, lab, w, rh, boyYok) { // çapraz iptal çizgisi
    if (c.h > 1.6 * rh && !boyYok) return true;
    let n = 0, sx = 0, sy = 0, sxx = 0, syy = 0, sxy = 0;
    for (let y = c.y; y < c.y + c.h; y++) for (let x = c.x; x < c.x + c.w; x++) if (lab[y * w + x] === c.i) { n++; sx += x; sy += y; sxx += x * x; syy += y * y; sxy += x * y; }
    if (n < 8) return false;
    const mx = sx / n, my = sy / n, a = sxx / n - mx * mx, b = sxy / n - mx * my, d = syy / n - my * my, tr = a + d, det = a * d - b * b, q = Math.sqrt(Math.max(0, tr * tr / 4 - det));
    const e1 = tr / 2 + q, e0 = Math.max(1e-3, tr / 2 - q), uzama = Math.sqrt(e1 / e0), boy = 4 * Math.sqrt(e1);
    let aci = Math.abs(Math.atan2(e1 - a, b || 1e-9) * 180 / Math.PI) % 180; aci = Math.min(aci, 180 - aci);
    return uzama > 6 && boy > 0.8 * rh && aci > 20 && aci < 72;
  }
  function sayiAday(m, lab, comps, uzunluk, oncel) { // {metin: oy}
    const oy = {}; if (!comps.length) return oy;
    for (const h of R().grupOku(m, lab, comps)) { const n = h.rak.length; if (!uzunluk.includes(n)) continue; let w = h.w * (oncel ? oncel[n] ?? 0.2 : 1);
      let L = [{ s: "", p: w }];
      for (const r of h.rak) { const top = [...r.olas].map((p, d) => ({ d, p })).sort((a, b) => b.p - a.p).slice(0, 4); L = L.flatMap((x) => top.map((t) => ({ s: x.s + t.d, p: x.p * t.p }))).filter((x) => x.p > 0.0005 / 3); }
      for (const x of L) oy[x.s] = Math.max(oy[x.s] || 0, x.p * 3); }
    return oy;
  }
  // v2.3.20: tarih satırının "Gün Sayısı" hücresi. Boş = 1 gün; "0,5" = yarım gün; tek rakam (1-9) = o tarihten başlayarak gün sayısı.
  function gunSayisi(m, lab, cs, rh) {
    if (!cs.length) return null;
    const buyuk = cs.filter((c) => c.h > rh * 0.45).sort((a, b) => a.x - b.x), kucuk = cs.filter((c) => c.h <= rh * 0.45);
    if (!buyuk.length) return null;
    if (buyuk.length === 1 && buyuk[0].w < buyuk[0].h * 0.45) return { deger: 1, guven: 0.9, ham: "çizgi/1" }; // ince dikey "1"
    // v2.3.22: "0,5" geniş yazılır (iki rakam + virgül/kesir izi); "1" ince, tek rakamlar (2-9) yaklaşık satır yüksekliği kadar
    const x0 = Math.min(...buyuk.map((c) => c.x)), x1 = Math.max(...buyuk.map((c) => c.x + c.w)), gen = x1 - x0, virgul = kucuk.some((c) => c.x > x0 && c.x < x1);
    if (buyuk.length >= 2 && (virgul || gen > 1.0 * rh)) return { deger: 0.5, guven: gen > 1.5 * rh || virgul ? 0.9 : 0.7, ham: "0,5 (genişlik)" };
    if (buyuk.length === 1 && gen > 1.3 * rh) return { deger: 0.5, guven: 0.55, ham: "0,5? (bitişik geniş yazı)" };
    const hip = R().grupOku(m, lab, buyuk), en = (n) => hip.filter((h) => h.rak.length === n).map((h) => ({ h, p: h.w * h.rak.reduce((t, r) => t * Math.max(...r.olas), 1) })).sort((a, b) => b.p - a.p)[0];
    const iki = en(2), bir = en(1);
    if (iki && (!bir || iki.p > bir.p * 0.5 || kucuk.length)) { const [r0, r1] = iki.h.rak; const p = r0.olas[0] * r1.olas[5];
      if (p > 0.02 || (kucuk.length && r1.olas[5] > 0.2)) return { deger: 0.5, guven: Math.min(1, Math.sqrt(r0.olas[0] * r1.olas[5]) / 0.7), ham: "0,5" }; }
    if (bir) { const o = bir.h.rak[0].olas; let d = 1, pm = -1; for (let k = 1; k <= 9; k++) if (o[k] > pm) { pm = o[k]; d = k; }
      if (o[0] > pm && kucuk.length) return { deger: 0.5, guven: 0.4, ham: "0? (yarım?)" };
      if (d === 5 && (kucuk.length || o[0] > 0.05)) return { deger: 0.5, guven: 0.5, ham: "5 (0,5?)" };
      return { deger: d, guven: Math.min(1, pm / 0.7), ham: String(d) }; }
    return { deger: 1, guven: 0.2, ham: "okunamadı" };
  }
  function hucre(M, dx0, dx1, gx0, gx1, y0, y1, opt, sik) {
    const rh = y1 - y0, pay = sik ? 0.15 * rh : 3 * rh, Y0 = Math.max(0, Math.round(y0 - pay)), Y1 = Math.min(M.H, Math.round(y1 + pay)), m = kes(M, dx0, Y0, gx1, Y1), { cs, lab } = R().bilesenler(m, true);
    const oy0 = y0 - Y0, oy1 = y1 - Y0, mx = (c) => c.x + c.w / 2;
    // v2.3.22: rakam komşu satıra taşan bir çizgiye/rakama değiyorsa (uzun bileşen ama çapraz iptal çizgisi değil) satır bandında yeniden kes
    if (!sik && cs.some((c) => c.h > 1.6 * rh && c.y < oy1 && c.y + c.h > oy0 && c.x + c.w / 2 < (gx0 - dx0) * 0.6 && !cizgiMi(c, lab, m.w, rh, true))) { const r2 = hucre(M, dx0, dx1, gx0, gx1, y0, y1, opt, true); if (r2 && r2.tarih) return r2; }
    const ic = cs.filter((c) => oy0 - 3 <= c.y + c.h / 2 && c.y + c.h / 2 <= oy1 + 3 && c.h > rh * 0.18 && !(c.y < oy1 && c.y + c.h > oy0 && cizgiMi(c, lab, m.w, rh)));
    if (globalThis.HUCRE_DEBUG) HUCRE_DEBUG.push({ rh, cs: cs.filter((c) => oy0 - 3 <= c.y + c.h / 2 && c.y + c.h / 2 <= oy1 + 3).map((c) => ({ x: c.x, y: c.y - oy0, w: c.w, h: c.h, a: c.a, cz: cizgiMi(c, lab, m.w, rh) })) });
    if (opt.izgara) { // v2.3.20: boş hücreyi kapatan eğik/yatık çizgi parçaları (düşük doluluk, uzun) ve küçük kırıntılar atılır
      const dol = (c) => c.a / (c.w * c.h);
      for (let k = ic.length - 1; k >= 0; k--) { const c = ic[k];
        if ((dol(c) < 0.14 && Math.max(c.w, c.h) > 0.9 * rh) || (c.w >= 1.3 * c.h && c.h < 0.8 * rh && dol(c) < 0.2) || (c.h < 0.45 * rh && c.w < 0.45 * rh)) ic.splice(k, 1); }
      if (ic.length === 1 && ic[0].a < 150) return null;
    }
    if (!ic.length) return null;
    const gw = gx0 - dx0, ayr = gw * (opt.oranAyrac || ORAN_AYRAC), yx = gw * (opt.oranYil || ORAN_YIL);
    const tarih = ic.filter((c) => mx(c) < yx), isaret = ic.filter((c) => mx(c) >= yx), gunHucre = isaret.filter((c) => c.x >= gx0 - dx0 - 4);
    const yan = isaret.filter((c) => !gunHucre.includes(c)), notlar = [];
    if (!tarih.length) return yan.length || gunHucre.some((c) => !(c.w < c.h * 0.6)) ? { tarih: null, guven: 0, not: "tarih yok ama hücrede yazı var" } : null;
    for (const c of tarih) { let a = 0; for (let y = c.y; y < c.y + c.h; y++) for (let x = c.x; x < c.x + c.w; x++) if (lab[y * m.w + x] === c.i) a++;
      if (c.w > 1.8 * rh && a / (c.w * c.h) > 0.22 && (c.w > 2.6 * rh || a / (c.w * c.h) > 0.4)) return { tarih: null, guven: 0, not: "karalanmış/iptal edilmiş hücre, kontrol edin", iptal: true }; }
    let g1 = tarih.filter((c) => mx(c) < ayr), g2 = tarih.filter((c) => mx(c) >= ayr);
    if (!g1.length || !g2.length) { const s = [...tarih].sort((a, b) => a.x - b.x); if (s.length < 2) return { tarih: null, guven: 0, not: "tarih eksik yazılmış, kontrol edin" };
      let bi = 0, bg = -1e9; for (let i = 0; i < s.length - 1; i++) { const g = s[i + 1].x - (s[i].x + s[i].w); if (g > bg) { bg = g; bi = i; } } g1 = s.slice(0, bi + 1); g2 = s.slice(bi + 1); notlar.push("gün/ay ayrımı belirsiz"); }
    g1 = g1.filter((c) => c.h > rh * 0.25).length ? g1.filter((c) => c.h > rh * 0.25) : g1; g2 = g2.filter((c) => c.h > rh * 0.25).length ? g2.filter((c) => c.h > rh * 0.25) : g2;
    const gun = sayiAday(m, lab, g1, [1, 2]), ay = sayiAday(m, lab, g2, [1, 2]);
    if (globalThis.HUCRE_TOPLA) HUCRE_TOPLA.push({ y0, dx0, gun: R().grupOku(m, lab, g1), ay: R().grupOku(m, lab, g2) });
    { const b0 = opt.bugun || new Date(); /* v2.3.22: ay rakamı eksik/bozuk okunursa izin penceresindeki ayları zayıf aday olarak dene (sonuç düşük güvenle işaretlenir) */
      for (let k = -75; k <= 10; k += 5) { const a = new Date(+b0 + k * 864e5).getMonth() + 1; if (!(a in ay) || ay[a] < 0.03) ay[a] = Math.max(ay[a] || 0, 0.03); } }
    const bugun = opt.bugun || new Date(), o0 = new Date(bugun.getMonth() >= 7 ? bugun.getFullYear() : bugun.getFullYear() - 1, 8, 1), o1 = new Date(o0.getFullYear() + 1, 5, 30), aday = [];
    for (const [gk, gv] of Object.entries(gun)) for (const [ak, av] of Object.entries(ay)) { const G = +gk, A = +ak; if (!(G >= 1 && A >= 1 && A <= 12)) continue;
      const t = new Date(A >= 8 ? o0.getFullYear() : o0.getFullYear() + 1, A - 1, G); if (t.getDate() !== G) continue;
      let p = gv * av; if (t < o0 || t > o1) p *= 0.2; if (t.getDay() % 6 === 0) p *= 0.04; if (t > new Date(+(opt.bugun || new Date()) + 864e5)) p *= 0.2; /* v2.3.22: hafta sonu neredeyse imkânsız; tarama (bugün) tarihinden sonrası az olası */ if (t > new Date(+bugun + 10 * 864e5) || t < new Date(+bugun - 75 * 864e5)) p *= 0.01; aday.push({ p, t }); }
    const ham = `gün ${Object.keys(gun).slice(0, 3).join("/")} ay ${Object.keys(ay).slice(0, 3).join("/")}`;
    if (!aday.length) return { tarih: null, guven: 0, not: "rakamlar okunamadı, elle girin", ham };
    aday.sort((a, b) => b.p - a.p); const top = aday.reduce((s, x) => s + x.p, 0), { p, t } = aday[0];
    const gp = Math.max(0, ...Object.entries(gun).filter(([k]) => +k === t.getDate()).map(([, v]) => v)) / 3, ap = Math.max(0, ...Object.entries(ay).filter(([k]) => +k === t.getMonth() + 1).map(([, v]) => v)) / 3;
    const guven0 = Math.min(1, p / top) * Math.min(1, Math.sqrt(gp * ap) / 0.7);
    const disari = t > new Date(+bugun + 10 * 864e5) || t < new Date(+bugun - 75 * 864e5); // v2.3.21: okunan tarih bugünden çok uzaksa güvenme
    const guven = disari ? Math.min(0.3, guven0) : guven0; if (disari) notlar.push("tarih bugünden çok uzak, kontrol edin");
    if (guven < 0.6) notlar.push("rakam okuması şüpheli"); if (aday.length > 1 && aday[1].p > 0.25 * p) notlar.push("diğer aday: " + String(aday[1].t.getDate()).padStart(2, "0") + "." + String(aday[1].t.getMonth() + 1).padStart(2, "0"));
    if (t.getDay() % 6 === 0) notlar.push("hafta sonu");
    const gs = gunSayisi(m, lab, isaret.filter((c) => c.h > rh * 0.2 && !(c.w > (gunHucre.includes(c) ? 4 : 2.5) * rh)), rh); // v2.3.22: bitişik yazılmış "0,5" gün hücresinde atılmasın
    if (gs && gs.deger > 5) notlar.push(`gün sayısı ${gs.deger} (5'ten fazla), kontrol edin`); else if (gs && gs.guven < 0.5) notlar.push("gün sayısı şüpheli, kontrol edin");
    const supheli = guven < 0.85 || (gs && gs.guven < 0.6) || /diğer aday|kontrol|şüpheli|hafta sonu|belirsiz/.test(notlar.join(" ")); // v2.3.22: "kontrol edin" yalnız şüpheli satırda
    return { tarih: t, guven, supheli, gunSay: gs ? gs.deger : 1, gunSayGuven: gs ? gs.guven : 1, gunSayHam: gs ? gs.ham : "boş", not: notlar.join(", "), ham, isaretVar: yan.length > 0 || gunHucre.some((c) => !(c.w < c.h * 0.6)) };
  }

  // ---- v2.3.20: basılı tablo çizgilerinden ızgara (Tesseract başlıkları bulamazsa / eğik taramada) ----
  function egimBul(img) { // derece; koyu piksellerin satır izdüşümünü en keskinleştiren açı
    const W = img.width, H = img.height, d = img.data, P = [];
    for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) { const i = 4 * (y * W + x); if (Math.max(d[i], d[i + 1], d[i + 2]) < 160) P.push(x - W / 2, y); }
    let en = { a: 0, s: -1 };
    for (let a = -3; a <= 3.001; a += 0.1) { const t = Math.tan(a * Math.PI / 180), h = new Float64Array(H + W); let s = 0;
      for (let k = 0; k < P.length; k += 2) { const b = Math.round(P[k + 1] + P[k] * t + W / 2); if (b >= 0 && b < h.length) h[b]++; }
      for (let i = 0; i < h.length; i++) s += h[i] * h[i]; if (s > en.s) en = { a, s }; }
    return Math.round(en.a * 10) / 10;
  }
  function duzelt(img, a) { // a derece; en yakın komşu döndürme (merkez etrafında), boşluk beyaz
    if (Math.abs(a) < 0.15) return img;
    const W = img.width, H = img.height, s = img.data, o = new Uint8ClampedArray(W * H * 4).fill(255), r = -a * Math.PI / 180, c = Math.cos(r), n = Math.sin(r), cx = W / 2, cy = H / 2;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const sx = Math.round(c * (x - cx) - n * (y - cy) + cx), sy = Math.round(n * (x - cx) + c * (y - cy) + cy);
      if (sx >= 0 && sy >= 0 && sx < W && sy < H) { const i = 4 * (y * W + x), j = 4 * (sy * W + sx); o[i] = s[j]; o[i + 1] = s[j + 1]; o[i + 2] = s[j + 2]; } }
    return { width: W, height: H, data: o };
  }
  function cizgiMaske(img) { const W = img.width, H = img.height, d = img.data, o = new Uint8Array(W * H);
    for (let i = 0; i < W * H; i++) { const r = d[4 * i], g = d[4 * i + 1], b = d[4 * i + 2], mx = Math.max(r, g, b); o[i] = mx < 200 && mx - Math.min(r, g, b) < 45 ? 1 : 0; } return o; }
  function yatayCizgiler(M, oran) { const out = [], G = M.cz;
    for (let y = 1; y < M.H - 1; y++) { let t = 0, s = -1; for (let x = 0; x <= M.W; x++) { const i = y * M.W + x, v = x < M.W && (G[i] || G[i - M.W] || G[i + M.W]); if (v && s < 0) s = x; else if (!v && s >= 0) { if (x - s >= 30) t += x - s; s = -1; } } if (t > M.W * oran) out.push(y); }
    const g = []; for (const y of out) { if (g.length && y - g[g.length - 1][1] <= 6) g[g.length - 1][1] = y; else g.push([y, y]); } return g.map(([a, b]) => (a + b) >> 1); }
  function dikeyCizgiler(M, y0, y1, x0 = 0, x1 = M.W) { const out = [], h = y1 - y0;
    for (let x = x0; x < x1; x++) { let n = 0; for (let y = y0; y < y1; y++) { const i = y * M.W; if (M.cz[i + x] || (x > 0 && M.cz[i + x - 1]) || (x + 1 < M.W && M.cz[i + x + 1])) n++; } if (n > h * 0.8) out.push(x); }
    const g = []; for (const x of out) { if (g.length && x - g[g.length - 1][1] <= 5) g[g.length - 1][1] = x; else g.push([x, x]); } return g.map(([a, b]) => (a + b) >> 1); }
  function izgara(img0, opt) {
    const aci = egimBul(img0), img = duzelt(img0, aci), M = maskeler(img); M.cz = cizgiMaske(img); const out = { aci, tablo: false, tarihler: [], no: "", noGuven: 0, noAday: [] };
    const ys = yatayCizgiler(M, 0.3);
    // izin tablosu: alttan aranan, aralığı düzenli 6 satır çizgisi (5 satır) + üstte başlık çizgisi
    let T = null;
    for (let i = ys.length - 6; i >= 1 && !T; i--) { const L = ys.slice(i, i + 6), g = L.slice(1).map((y, k) => y - L[k]), md = [...g].sort((a, b) => a - b)[2];
      if (md >= 25 && md <= 110 && g.every((v) => Math.abs(v - md) < md * 0.25) && L[0] - ys[i - 1] >= md * 0.6 && L[0] - ys[i - 1] <= md * 2.2) T = { ust: ys[i - 1], L }; }
    if (!T) return out;
    let vs = dikeyCizgiler(M, T.L[0] + 3, T.L[5] - 3);
    if (vs.length > 7) { // fazlalık (iptal çizgisi vb.): sınırlar arası en düzenli 7'li
      const a = vs[0], b = vs[vs.length - 1]; vs = [a, ...vs.filter((x) => x > a + 20 && x < b - 20).slice(0, 5), b]; }
    if (vs.length !== 7) return out;
    out.tablo = true;
    for (let j = 0; j < 3; j++) { const dx0 = vs[2 * j] + 4, dx1 = vs[2 * j + 1] - 4, gx0 = vs[2 * j + 1] + 4, gx1 = vs[2 * j + 2] - 4;
      for (let r = 0; r < 5; r++) { const y0 = T.L[r] + 5, y1 = T.L[r + 1] - 4;
        const hc = hucre(M, dx0, dx1, gx0, gx1, y0, y1, { ...opt, ...IZGARA_ORAN, izgara: true }); if (hc) out.tarihler.push({ ...hc, yer: `${j + 1}. sütun ${r + 1}. satır`, kutu: { dx0, dx1, gx0, gx1, y0, y1 } }); } }
    // öğrenci tablosu: izin tablosunun üstünde, iki satırlı (3 çizgi, dar aralık) ilk tablo; orta hücrenin 2. satırı = "Sınıfı/Numarası"
    const ust = ys.filter((y) => y < T.ust - 10);
    for (let i = 0; i + 2 < ust.length; i++) { const a = ust[i + 1] - ust[i], b = ust[i + 2] - ust[i + 1];
      if (!(a >= 20 && a <= 80 && b >= 20 && b <= 80)) continue;
      const v = dikeyCizgiler(M, ust[i] + 3, ust[i + 2] - 3); if (v.length < 4) continue;
      const x0 = v[1] + 5, x1 = v[2] - 5, y0 = ust[i + 1] + 3, y1 = ust[i + 2] - 3, h = y1 - y0;
      const m = kes(M, x0, y0 - Math.round(h * 0.6), x1, y1 + Math.round(h * 0.4)), { cs, lab } = R().bilesenler(m), c2 = cs.filter((c) => c.h > h * 0.3 && !cizgiMi(c, lab, m.w, h * 1.4)).sort((p, q) => p.x - q.x);
      out.noKutu = { x0, y0, x1, y1 };
      if (!c2.length) { out.noUyari = "öğrenci no yazılmamış"; break; }
      let gr = [[c2[0]]]; for (const c of c2.slice(1)) { const son = Math.max(...gr[gr.length - 1].map((g) => g.x + g.w)); if (c.x - son > h * 0.9) gr.push([c]); else gr[gr.length - 1].push(c); }
      const aday = gr.length > 1 ? gr.slice(1) : gr; let en = null;
      if (globalThis.NO_TOPLA) NO_TOPLA.push(aday.map((g) => R().grupOku(m, lab, g)));
      for (const g of aday) { const oy = sayiAday(m, lab, g, [3, 4, 5, 6], opt.noOncel || { 4: 1, 3: 0.6, 5: 0.3, 6: 0.2 }), k = Object.keys(oy).sort((p, q) => oy[q] - oy[p]);
        if (k.length && (!en || oy[k[0]] > en.oy[en.k[0]])) en = { oy, k }; }
      if (en) { const top = en.k.reduce((t, x) => t + en.oy[x], 0); out.no = en.k[0]; out.noGuven = en.oy[en.k[0]] / top; out.noAday = en.k.slice(0, 5); }
      else if (gr.length === 1) out.noUyari = "öğrenci no yazılmamış (yalnız sınıf var)";
      break; }
    out.img = img; return out;
  }
  const IZGARA_ORAN = {};
  const B = (k) => ({ x0: k.bbox.x0, y0: k.bbox.y0, x1: k.bbox.x1, y1: k.bbox.y1 });
  // kel: Tesseract kelimeleri [{n (normalize), bbox}] ; img: döndürülmüş sayfanın ImageData'sı
  function oku(img, kel, opt = {}) {
    const M = maskeler(img), out = { tablo: false, tarihler: [], no: "", noGuven: 0, noAday: [] };
    // ---- Sınıfı / Numarası ----
    const nk = kel.find((k) => /NUMARAS/.test(k.n)), et = nk ? kel.filter((k) => /SINIF|NUMARAS/.test(k.n) && Math.abs(k.bbox.y0 - nk.bbox.y0) < nk.bbox.y1 - nk.bbox.y0 && Math.abs(k.bbox.x0 - nk.bbox.x0) < 15 * (nk.bbox.y1 - nk.bbox.y0)).map(B) : [], seb = kel.filter((k) => /ISTEG|SEBEB/.test(k.n)).map(B);
    if (et.length) {
      const e = { x0: Math.min(...et.map((b) => b.x0)), y0: Math.min(...et.map((b) => b.y0)), x1: Math.max(...et.map((b) => b.x1)), y1: Math.max(...et.map((b) => b.y1)) }, h = e.y1 - e.y0;
      const sb = seb.filter((s) => s.x0 > e.x1 && Math.abs(s.y0 - e.y0) < 2 * h), xs = Math.max(0, e.x0 - h * 0.5), xe = sb.length ? Math.min(...sb.map((s) => s.x0)) - 5 : e.x1 + 6 * h;
      const m = kes(M, xs, e.y1 - h * 0.2, xe, e.y1 + h * 2.8), { cs, lab } = R().bilesenler(m), c2 = cs.filter((c) => !cizgiMi(c, lab, m.w, h * 1.4) && c.h > h * 0.3).sort((a, b) => a.x - b.x);
      if (c2.length) {
        let gr = [[c2[0]]]; for (const c of c2.slice(1)) { const son = Math.max(...gr[gr.length - 1].map((g) => g.x + g.w)); if (c.x - son > h * 1.1) gr.push([c]); else gr[gr.length - 1].push(c); }
        // sağdaki hücreye taşan el yazısı (ör. "Veli isteği") da bir grup olabilir: sınıftan sonraki gruplardan en iyi sayı okunanı seç
        if (gr.length > 1) { let en = null;
          for (const g of gr.slice(1)) { const oy = sayiAday(m, lab, g, [3, 4, 5, 6], opt.noOncel || { 4: 1, 3: 0.6, 5: 0.3, 6: 0.2 }), k = Object.keys(oy).sort((a, b) => oy[b] - oy[a]);
            if (k.length && (!en || oy[k[0]] > en.oy[en.k[0]])) en = { oy, k }; }
          if (globalThis.VELI_NO_DEBUG) VELI_NO_DEBUG.push({ m, gr: gr.map((g) => g.map((c) => [c.x, c.w, c.h])) });
          if (en) { const top = en.k.reduce((t, x) => t + en.oy[x], 0); out.no = en.k[0]; out.noGuven = en.oy[en.k[0]] / top; out.noAday = en.k.slice(0, 5); } }
        else out.noUyari = "öğrenci no yazılmamış (yalnız sınıf var)";
      }
    }
    // ---- İzin tablosu ----
    const izin = kel.filter((k) => /IZIN/.test(k.n) && kel.some((t) => /TARIH/.test(t.n) && Math.abs(t.bbox.y0 - k.bbox.y0) < k.bbox.y1 - k.bbox.y0 && t.bbox.x0 > k.bbox.x0 && t.bbox.x0 - k.bbox.x1 < 3 * (k.bbox.y1 - k.bbox.y0)))
      .map((k) => { const t = kel.filter((q) => /TARIH/.test(q.n) && q.bbox.x0 > k.bbox.x0 && Math.abs(q.bbox.y0 - k.bbox.y0) < k.bbox.y1 - k.bbox.y0).sort((a, b) => a.bbox.x0 - b.bbox.x0)[0]; return { x0: k.bbox.x0, y0: Math.min(k.bbox.y0, t.bbox.y0), x1: t.bbox.x1, y1: Math.max(k.bbox.y1, t.bbox.y1) }; })
      .filter((b) => !et.length || b.y0 > Math.max(...et.map((e) => e.y1))).sort((a, b) => a.x0 - b.x0);
    const gs = kel.filter((k) => /SAYISI/.test(k.n)).map((k) => { const g = kel.filter((q) => /^GUN/.test(q.n) && q.bbox.x1 <= k.bbox.x0 + 5 && k.bbox.x0 - q.bbox.x1 < 3 * (k.bbox.y1 - k.bbox.y0) && Math.abs(q.bbox.y0 - k.bbox.y0) < k.bbox.y1 - k.bbox.y0)[0]; return g ? { x0: g.bbox.x0, x1: k.bbox.x1 } : { x0: k.bbox.x0, x1: k.bbox.x1 }; });
    if (!izin.length) return out;
    out.tablo = true;
    const dfs = izin.slice(1).map((b, i) => b.x0 - izin[i].x0).sort((a, b) => a - b), colw = dfs.length ? dfs[dfs.length >> 1] : (izin[0].x1 - izin[0].x0) * 3.2;
    izin.forEach((Hd, j) => {
      const G = gs.find((g) => Hd.x0 + colw * 0.45 < g.x0 && g.x0 < Hd.x0 + colw * 0.8) || { x0: Hd.x0 + colw * 0.615, x1: Hd.x0 + colw * 0.9 };
      const nx = j + 1 < izin.length ? izin[j + 1].x0 : G.x1 + (G.x0 - Hd.x0) * 0.45, hh = Hd.y1 - Hd.y0;
      const dx0 = Math.max(0, Math.round(Hd.x0 - hh * 0.4)), dx1 = Math.round(G.x0 - 6), gx0 = dx1 + 8, gx1 = Math.round(nx - 10);
      const ys = satirDuzenle(satirCizgileri(M, dx0, dx1, Math.round(Hd.y1 - hh * 0.2), Math.round(Hd.y1 + hh * 9)).filter((y) => y > Hd.y1 - 4), hh);
      if (ys.length < 2) { out.uyari = (out.uyari || []).concat(`${j + 1}. sütun satır çizgileri bulunamadı`); return; }
      for (let r = 0; r < ys.length - 1; r++) { const y0 = ys[r] + 6, y1 = ys[r + 1] - 5; if (y1 - y0 < hh * 0.6) continue;
        const hc = hucre(M, dx0, dx1, gx0, gx1, y0, y1, opt); if (hc) out.tarihler.push({ ...hc, yer: `${j + 1}. sütun ${r + 1}. satır`, kutu: { dx0, dx1, gx0, gx1, y0, y1 } }); }
    });
    return out;
  }
  const api = { oku, satirDuzenle, maskeler, izgara, egimBul };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  kok.VeliDuzen = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
