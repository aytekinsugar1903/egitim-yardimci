// v2.5.8 (+v2.5.9 tek aylık tam/yarım, ders yılı kodu): Aylık (sürüm 7) makine okunur formlar — düzen + çizim TEK kaynak (üretici gen7.py'nin bire bir JS karşılığı).
// Aynı işlev hem "Boş form indir" sayfasında PDF çizer hem de okuyucuya (form.js) o formun düzenini verir; böylece basılan form ile okunan düzen hep aynıdır.
// Türler: 1 veli izin dilekçesi, 2 faaliyet toplu, 3 faaliyet bireysel, 4 devamsızlık takip · 5 tam/yarım gün veli izni (v2.5.9: hepsi TEK AY, her ders yılı). Eski 2 aylık v5 formlar okuyucuda form_duzen.js 41–49 ile okunmaya devam eder.
// v2.5.9: ders yılı kodu — alt sağda 4 kutu (başlangıç yılı − 2025, 4 bit) + üst solda tümleyeni; eski formlarda bu kutular yok (okuyucu eski yola düşer).
// Düzen birimi mm, sol-üst köken. Tamamen yerel; ağ kullanmaz.
(function (kok) {
  "use strict";
  const W = 210, H = 297;
  const AY = ["", "OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN", "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK"];
  const GUN = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma"];
  const FID = [[14, 14], [196, 14], [14, 283], [196, 283]], FID_A = 8;
  const KOD_X = [0, 1, 2, 3, 4, 5, 6, 7].map((k) => 62 + 12 * k), EK_X = [158, 170], KOD_Y = 14, KOD_A = 5;
  const ALT_X = [0, 1, 2, 3, 4, 5, 6, 7].map((k) => 58 + 12 * k), ALT_Y = 283;
  const YIL_ALT_X = [154, 164, 174, 184], YIL_UST_X = [26, 36, 46, 56], YIL_TABAN = 2025; // v2.5.9: ders yılı kodu (form.js aynı sabitleri kullanır)
  const BASLIK = { 1: "DEVAMSIZLIK VELİ İZİN DİLEKÇE FORMU", 2: "FAALİYET (İZİNLİ SAYILMA) ÖĞRENCİ LİSTESİ", 3: "FAALİYET (İZİNLİ SAYILMA) BİREYSEL LİSTE", 4: "DEVAMSIZLIK (ÖZÜRSÜZ) TAKİP FORMU", 5: "DEVAMSIZLIK VELİ İZİN DİLEKÇE FORMU" };
  const YAYIN = { 1: "FRM-01", 2: "FRM-03", 3: "FRM-04", 4: "FRM-05", 5: "FRM-01" };
  const ADLAR = { 1: "veli-izin-formu", 2: "faaliyet-formu-toplu", 3: "faaliyet-formu-bireysel", 4: "devamsizlik-takip-formu", 5: "veli-izin-formu-tam-yarim" };
  const TURLER = { 1: "Veli izin dilekçesi (tek ay)", 2: "Faaliyet — toplu liste (tek ay)", 3: "Faaliyet — bireysel liste (tek ay)", 4: "Devamsızlık takip formu (tek ay)", 5: "Tam/yarım gün veli izni (tek ay)" };
  const p2 = (n) => String(n).padStart(2, "0");
  const gk = (y, a, g) => `${y}-${p2(a)}-${p2(g)}`; // gün anahtarı
  const ayGun = (y, a) => new Date(y, a, 0).getDate();
  const haftaGunu = (y, a, g) => (new Date(y, a - 1, g, 12).getDay() + 6) % 7; // 0 = Pazartesi
  const tstr = (y, a, g) => `${p2(g)}/${p2(a)}/${y}`;
  const asc = (s) => s.toLocaleLowerCase("tr").replace(/ı/g, "i").replace(/ş/g, "s").replace(/ü/g, "u").replace(/ö/g, "o").replace(/ç/g, "c").replace(/ğ/g, "g");
  const dersYiliBas = (ay, yil) => (ay >= 9 ? yil : yil - 1);
  // Python calendar.Calendar(0).monthdayscalendar karşılığı: haftalar (Pzt..Paz), ay dışı = 0
  function haftalar(y, a) {
    const n = ayGun(y, a), ilk = haftaGunu(y, a, 1), out = []; let w = new Array(7).fill(0), k = ilk;
    for (let g = 1; g <= n; g++) { w[k] = g; k++; if (k === 7) { out.push(w); w = new Array(7).fill(0); k = 0; } }
    if (w.some(Boolean)) out.push(w); return out;
  }
  // ---- takvim: Okul ayarlarındaki tatil/arife metni (birlestir.js ile aynı biçim) + ders yılı başı/sonu ----
  const DESEN = /\d{4}-\d{1,2}-\d{1,2}|\d{1,2}[./-]\d{1,2}[./-]\d{4}/g;
  function tekTarih(s) { let r = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/), y, a, g; if (r) [, y, a, g] = r; else { r = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/); if (!r) return null; [, g, a, y] = r; }
    const t = new Date(+y, +a - 1, +g, 12); return t.getFullYear() === +y && t.getMonth() === +a - 1 && t.getDate() === +g ? t : null; }
  function metinCoz(metin) { const out = []; // [{b: Date, e: Date, ad}]
    String(metin == null ? "" : metin).split(/\r?\n/).forEach((satir) => { const ad = (satir.match(/#\s*(.*)$/) || [])[1] || ""; const t = [...satir.replace(/#.*$/, "").matchAll(DESEN)].map((m) => tekTarih(m[0])).filter(Boolean);
      if (!t.length) return; const [b, e] = t.length > 1 ? (t[0] <= t[1] ? [t[0], t[1]] : [t[1], t[0]]) : [t[0], t[0]]; out.push({ b, e, ad: ad.trim() }); });
    return out; }
  function kisaAd(ad) { let s = String(ad || "tatil").replace(/Bayramı/gi, "B.").replace(/Ulusal Egemenlik ve Çocuk B\./i, "23 Nisan").replace(/Emek ve Dayanışma Günü/i, "1 Mayıs").replace(/\s*arifesi/i, "");
    s = s.charAt(0).toLocaleLowerCase("tr") === s.charAt(0) ? s : (/^(Ara|Yarıyıl)\b/.test(s) ? s.charAt(0).toLocaleLowerCase("tr") + s.slice(1) : s); return s.length > 18 ? s.slice(0, 17) + "." : s; }
  // MEB takvimine göre ders yılı başı (Eylül'ün 8'inden sonraki ilk Pazartesi) ve sonu (26 Haziran'dan önceki son Cuma). 2026-2027: 14.09.2026 – 25.06.2027.
  function dersYiliSinir(bas) { const b = new Date(bas, 8, 8, 12); while (b.getDay() !== 1) b.setDate(b.getDate() + 1); const e = new Date(bas + 1, 5, 26, 12); while (e.getDay() !== 5) e.setDate(e.getDate() - 1); return { b, e }; }
  // takvim = { tatil: Map(anahtar -> kısa ad), arife: Set(anahtar), tatilMetni, arifeMetni }
  function takvimKur(tatilMetni, arifeMetni) {
    const B = kok.VeliBirlestir; if (typeof tatilMetni !== "string") tatilMetni = B ? B.VARSAYILAN_TATIL_METNI : ""; if (typeof arifeMetni !== "string") arifeMetni = B ? B.VARSAYILAN_ARIFE_METNI : "";
    const tatil = new Map(), arife = new Set();
    metinCoz(tatilMetni).forEach(({ b, e, ad }) => { for (const t = new Date(b); t <= e; t.setDate(t.getDate() + 1)) tatil.set(gk(t.getFullYear(), t.getMonth() + 1, t.getDate()), kisaAd(ad)); });
    metinCoz(arifeMetni).forEach(({ b }) => arife.add(gk(b.getFullYear(), b.getMonth() + 1, b.getDate())));
    return { tatil, arife, tatilMetni, arifeMetni };
  }
  // hafta içi günler: [{g, kap}] (kap = tatil adı | "ders yok" | null)
  function gunler(ay, yil, tk) { const s = dersYiliSinir(dersYiliBas(ay, yil)), out = [];
    for (let g = 1; g <= ayGun(yil, ay); g++) { if (haftaGunu(yil, ay, g) >= 5) continue; const d = new Date(yil, ay - 1, g, 12);
      out.push({ g, kap: tk.tatil.get(gk(yil, ay, g)) || (d < s.b || d > s.e ? "ders yok" : null) }); }
    return out; }
  const kodUst = (t) => { const b = [(t >> 2) & 1, (t >> 1) & 1, t & 1]; return [[0, ...b, ...b, 0], [1, 0]]; };
  const kodAlt = (m) => { const b = [(m >> 3) & 1, (m >> 2) & 1, (m >> 1) & 1, m & 1]; return [...b, ...b.map((x) => 1 - x)]; };
  const kodYil = (bas) => { const v = Math.max(0, Math.min(15, bas - YIL_TABAN)), b = [(v >> 3) & 1, (v >> 2) & 1, (v >> 1) & 1, v & 1]; return [b, b.map((x) => 1 - x)]; }; // [alt sağ, üst sol]
  const kodV5 = (k) => { const b = [(k >> 2) & 1, (k >> 1) & 1, k & 1], b3 = (k >> 3) & 1; return [[0, ...b, ...b, 1], [b3, 1 - b3]]; };
  const BOS = { rect() {}, txt() {}, dash() {}, line() {}, arma() {}, para() { return 2; } };
  // Başlık: { kaymakamlik, okul, kurumKodu } (boşsa noktalı genel başlık)
  function baslikCiz(c, t, ay, yil, b, ek) {
    b = b || {}; c.rect(20, 22, 170, 26, 0, 0.8); c.line(48, 22, 48, 48, 0.8); c.line(140, 22, 140, 48, 0.8); c.line(48, 38, 140, 38, 0.8); c.arma(34, 34.75, 10.5);
    const kay = String(b.kaymakamlik || "").trim(), okul = String(b.okul || "").trim(), kod = String(b.kurumKodu || "").trim();
    c.txt(94, 27, "T.C.", 9, "FB", "c");
    c.txt(94, 31.5, kay ? kay.toLocaleUpperCase("tr") + (/(KAYMAKAMLIĞI|VALİLİĞİ)$/.test(kay.toLocaleUpperCase("tr")) ? "" : " KAYMAKAMLIĞI") : "…………………………… KAYMAKAMLIĞI", 9, "FB", "c");
    c.txt(94, 36, okul ? okul + (/müdürlüğü$/i.test(okul) ? "" : " Müdürlüğü") : "…………………………………………… Müdürlüğü", okul.length > 48 ? 7.5 : 8.5, "FB", "c");
    c.txt(94, 44.5, BASLIK[t], t === 1 ? 10 : t === 5 ? 10.5 : 10.5 - (t !== 4 ? 0.5 : 0), "FB", "c");
    const ogr = dersYiliBas(ay, yil);
    (ek || [`Yayın No: ${YAYIN[t]}`, "Revizyon Sayısı: 01", "Sayfa No: 1/1", `Kurum/Birim Kodu: ${kod || "…………"}`, `Öğretim yılı: ${ogr}-${ogr + 1}`, `Form: aylık · ${AY[ay]} ${yil}`]).forEach((s, i) => c.txt(142, 26 + i * 4, s, 7));
  }
  // ---- sürüm 7 (tek ay): gen7.py uret() ile aynı geometri ----
  function ciz7(c, t, ay, yil, tk, baslik) {
    const D = { surum: t === 1 || t === 5 ? 4 : 7, formSurum: 7, tip: ["", "aylik-veli", "aylik-toplu", "aylik-bireysel", "aylik-devamsizlik", "aylik-tamyarim"][t], t, kod: t, ay, yil, aylar: [ay],
      fid: FID, fidA: FID_A, kodKutu: KOD_X.map((x) => [x, KOD_Y]), kodKutu5: EK_X.map((x) => [x, KOD_Y]), altKod: ALT_X.map((x) => [x, ALT_Y]), kodA: KOD_A };
    FID.forEach(([x, y]) => c.rect(x - FID_A / 2, y - FID_A / 2, FID_A, FID_A, 1, 0));
    const [u8, u2] = kodUst(t); [...KOD_X, ...EK_X].forEach((x, i) => c.rect(x - KOD_A / 2, KOD_Y - KOD_A / 2, KOD_A, KOD_A, [...u8, ...u2][i], 0.8));
    kodAlt(ay).forEach((b, i) => c.rect(ALT_X[i] - KOD_A / 2, ALT_Y - KOD_A / 2, KOD_A, KOD_A, b, 0.8));
    const [ya, yu] = kodYil(dersYiliBas(ay, yil)); YIL_ALT_X.forEach((x, i) => c.rect(x - KOD_A / 2, ALT_Y - KOD_A / 2, KOD_A, KOD_A, ya[i], 0.8)); YIL_UST_X.forEach((x, i) => c.rect(x - KOD_A / 2, KOD_Y - KOD_A / 2, KOD_A, KOD_A, yu[i], 0.8));
    const ogr0 = dersYiliBas(ay, yil);
    baslikCiz(c, t, ay, yil, baslik, t === 5 ? ["Yayın No: FRM-01", "Yayın Tarihi: .../.../20..", "Revizyon Sayısı: 00", `Kurum/Birim Kodu: ${String((baslik || {}).kurumKodu || "").trim() || "…………"}`, `Öğretim yılı: ${ogr0}-${ogr0 + 1}`, `Form: tam/yarım gün · ${AY[ay]} ${yil}`] : undefined);
    c.rect(20, 50, 62, 7.5, 1, 0); c.txt(51, 55.6, `AY: ${AY[ay]} ${yil}`, 12, "FB", "c", 1);
    const noKutulari = (x0, y0, bw, bh, ara) => [0, 1, 2, 3].map((j) => { const x = x0 + j * (bw + ara); c.rect(x, y0, bw, bh, 0, 1.1); return { s: j, x, y: y0, w: bw, h: bh }; });
    const okul = gunler(ay, yil, tk), acik = okul.filter((o) => !o.kap).map((o) => o.g), kap = new Map(okul.map((o) => [o.g, o.kap]));
    const hafta = haftalar(yil, ay).filter((w) => w.slice(0, 5).some(Boolean));
    if (t === 1 || t === 5) { // v2.5.9: tam/yarım gün veli izni artık tek ay — veli izin dilekçesiyle aynı (okuma testinden geçmiş) büyük ızgara
      c.txt(190, 55.5, "Tarih: ….. / ….. / 20….", 9.5, "F", "r");
      c.para(20, 62, 4.2, "Aşağıda bilgileri verilmiş olan okulunuz öğrencisinin, 28.06.2016 tarihli ve 29871 sayılı Resmî Gazete'de yayımlanan Millî Eğitim Bakanlığı Ortaöğretim Kurumları Yönetmeliği'nin 36. maddesi doğrultusunda aşağıda işaretlediğim günlerde izinli sayılmasını istiyorum. Gereğini bilgilerinize arz ederim.", 9.3, 170);
      c.rect(20, 74, 170, 36, 0, 0.8);
      c.txt(23, 82, "Öğrencinin Adı Soyadı:", 9, "FB"); c.dash(23, 99, 89); c.txt(23, 96, "Sınıfı / Şubesi:", 9, "FB"); c.dash(50, 99, 96.5); c.txt(23, 105, "İzin isteği sebebi:", 9, "FB"); c.dash(54, 99, 105.5);
      c.txt(146, 78.6, "OKUL NUMARASI (4 hane)", 8.5, "FB", "c"); D.no = noKutulari(105, 80.5, 17, 24, 4.5); D.noBuyuk = true;
      c.txt(146, 108.3, "Her kutuya bir rakam; numara 4 haneden kısaysa sağa yaslayın", 6.5, "F", "c");
      c.txt(105, 115, "İzinli sayılacağı günde: TAM gün ise TAM kutusuna, YARIM gün ise YARIM kutusuna X koyun (yalnız birine).", 8, "FB", "c");
      const y0 = 117.5; c.rect(20, y0, 170, 6, 1, 0); c.txt(105, y0 + 4.4, `${AY[ay]} ${yil} — okul günleri`, 9.5, "FB", "c", 1);
      const cw = 34, rh = 21.5, KA = 6.5; GUN.forEach((gn, k) => c.txt(20 + cw * k + cw / 2, y0 + 10, gn, 8, "FB", "c"));
      D.gunler = [];
      hafta.forEach((w, r) => w.slice(0, 5).forEach((gun, k) => { if (!gun) return; const cx = 20 + cw * k, cy = y0 + 11.5 + r * rh, kp = kap.get(gun);
        c.rect(cx + 0.8, cy + 0.8, cw - 1.6, rh - 1.6, kp ? 1 : 0, 0.45, kp ? 0.85 : null); c.txt(cx + 2.2, cy + 5.2, String(gun), 10, "FB");
        if (kp) { c.txt(cx + cw / 2, cy + 13, kp, 7.5, "F", "c"); return; }
        if (tk.arife.has(gk(yil, ay, gun))) c.txt(cx + cw - 2, cy + 4.6, "arife", 6, "F", "r");
        const bx = cx + 10, yx = cx + 24, by = cy + 11.5; c.rect(bx - KA / 2, by - KA / 2, KA, KA, 0, 1.0); c.rect(yx - KA / 2, by - KA / 2, KA, KA, 0, 1.0);
        c.txt(bx, by + 6.6, "TAM", 6, "FB", "c"); c.txt(yx, by + 6.6, "YARIM", 6, "FB", "c");
        D.gunler.push({ t: tstr(yil, ay, gun), x: bx, y: by, yx, yy: by }); }));
      D.kutuA = KA;
      const yb = 239; c.rect(20, yb, 170, 33, 0, 0.8); c.line(80, yb, 80, yb + 33, 0.8); c.line(130, yb, 130, yb + 33, 0.8);
      c.txt(22, yb + 5, "Velisinin Adresi:", 8.5, "FB"); c.txt(82, yb + 5, "Telefon:", 8.5, "FB"); c.txt(132, yb + 5, "Velisinin Adı Soyadı / İmza:", 8.5, "FB");
    } else {
      D.harf = []; D.takvim = []; D.satirlar = [];
      if (t === 2 || t === 3) {
        c.txt(20, 60.8, "FAALİYET ADI — her kutuya BÜYÜK HARFLE bir harf (Ç Ğ İ Ö Ş Ü kullanılabilir), kelime arasına bir boş kutu:", 7.5, "FB");
        for (let i = 0; i < 24; i++) { const x = 20 + i * 7.1; c.rect(x, 62, 6.4, 8.4, 0, 0.9); D.harf.push({ x, y: 62, w: 6.4, h: 8.4 }); }
        c.txt(20, 75.5, "(Açık yazı):", 7.5, "FB"); c.dash(38, 190, 76); D.serbest = [20, 71.5, 170, 6]; D.adBolge = [20, 59, 170, 20];
        c.txt(190, 55.5, "Sorumlu öğretmen: ………………………  İmza: ………", 8, "F", "r");
      } else {
        c.txt(190, 55.5, "Sınıfı / Şubesi: ……………", 9.5, "FB", "r"); c.txt(20, 63, "Sınıf rehber öğretmeni: ……………………………………   İmza: ………………", 8.5, "F");
        c.txt(20, 69.5, "Devamsız öğrencinin Okul No'sunu büyük kutulara yazın; devamsız olduğu günün T (tam gün) ya da Y (yarım gün) kutusuna X koyun.", 7.2, "FB");
        c.txt(20, 73.8, "Okunan satırlar e-Okul'a kendiliğinden girilmez; yoklama ekranındaki Sesli/Yazılı kutusuna yapıştırılacak metne dönüşür. Tatil günleri formda yoktur.", 6.8, "F");
      }
      if (t === 2) {
        c.txt(105, 82, "Faaliyet günleri listedeki tüm öğrenciler için ortaktır. Tam gün: T kutusuna, yarım gün: Y kutusuna X.", 7.5, "FB", "c");
        const y0 = 84; c.rect(20, y0, 170, 5.5, 1, 0); c.txt(105, y0 + 4, `${AY[ay]} ${yil} — okul günleri`, 9, "FB", "c", 1);
        const cw = 34, rh = 13, KA = 5.5; GUN.forEach((gn, k) => c.txt(20 + cw * k + cw / 2, y0 + 9, gn, 7.5, "FB", "c"));
        hafta.forEach((w, r) => w.slice(0, 5).forEach((gun, k) => { if (!gun) return; const cx = 20 + cw * k, cy = y0 + 10.5 + r * rh, kp = kap.get(gun);
          c.rect(cx + 0.6, cy + 0.6, cw - 1.2, rh - 1.2, kp ? 1 : 0, 0.4, kp ? 0.85 : null); c.txt(cx + 2, cy + 5.6, String(gun), 9, "FB");
          if (kp) { c.txt(cx + cw / 2 + 3, cy + 8, kp, 7, "F", "c"); return; }
          const tx = cx + 15, yx = cx + 27, by = cy + 6.5; c.rect(tx - KA / 2, by - KA / 2, KA, KA, 0, 0.9); c.rect(yx - KA / 2, by - KA / 2, KA, KA, 0, 0.9);
          c.txt(tx - KA / 2 - 1.1, by + 1.2, "T", 6.5, "FB", "r"); c.txt(yx - KA / 2 - 1.1, by + 1.2, "Y", 6.5, "FB", "r");
          D.takvim.push({ t: tstr(yil, ay, gun), x: tx, y: by, yx, yy: by }); }));
        const ys = y0 + 10.5 + 5 * rh + 4;
        c.txt(22, ys, "Sıra", 7.5, "FB"); c.txt(58, ys, "OKUL NO (4 hane, sağa yaslı)", 7.5, "FB", "c"); c.txt(96, ys, "Adı Soyadı", 7.5, "FB"); c.txt(158, ys, "Sınıfı / Şubesi", 7.5, "FB");
        const rh2 = 15.5;
        for (let r = 0; r < 7; r++) { const y = ys + 2 + r * rh2; c.rect(20, y, 170, rh2, 0, 0.4); c.txt(24.5, y + 9.5, String(r + 1), 9, "FB", "c");
          const kut = noKutulari(30.5, y + 1.5, 12, 12.5, 3); c.dash(96, 152, y + 11); c.dash(158, 187, y + 11); D.satirlar.push({ s: r, no: kut, gunler: null }); }
        D.kutuA = KA;
      } else {
        const KA = 4.6, ust = t === 3 ? 80 : 77.5, bh = 38.6;
        if (t === 3) c.txt(105, ust - 1.2, "Her öğrencinin kendi günleri: gün numarasının yanındaki T (tam) ya da Y (yarım) kutusuna X. Tatil günleri formda yoktur.", 7, "FB", "c");
        for (let r = 0; r < 5; r++) { const y = ust + r * bh; c.rect(20, y, 170, bh - 1, 0, 0.6); c.txt(23, y + 9, `${r + 1}.`, 10, "FB");
          c.txt(30, y + 9, "Okul No:", 7.5, "FB"); const kut = noKutulari(43, y + 1.4, 12, 12.5, 3);
          c.txt(103, y + 6.5, "Adı Soyadı / Sınıf:", 7.5, "FB"); c.dash(103, 187, y + 12.5);
          const gun = [], cw = 170 / 8, ch = 7.4;
          acik.forEach((g, i) => { const rr = Math.floor(i / 8), k = i % 8, cx = 20 + k * cw, cy = y + 15 + rr * ch;
            c.rect(cx + 0.5, cy + 0.3, cw - 1.0, ch - 0.6, 0, 0.35); c.txt(cx + 1.6, cy + 5.1, String(g), 8.5, "FB");
            const tx = cx + 10.0, yx = cx + 17.2, by = cy + ch / 2; c.rect(tx - KA / 2, by - KA / 2, KA, KA, 0, 0.9); c.rect(yx - KA / 2, by - KA / 2, KA, KA, 0, 0.9);
            gun.push({ t: tstr(yil, ay, g), x: tx, y: by, yx, yy: by }); });
          D.satirlar.push({ s: r, no: kut, gunler: gun }); }
        D.kutuA = KA;
        c.txt(105, 275.2, "Her gün hücresinde: gün · sol kutu T (tam gün) · sağ kutu Y (yarım gün).", 7, "FB", "c");
      }
    }
    c.txt(105, 279.3, `Evrak Asistanı aylık form · ${AY[ay]} ${yil} · tür ${t} · sürüm 7 · işaretleri ve köşe karelerini kapatmayın, katlamayın`, 6.3, "F", "c");
    return D;
  }
  // ---- v5 (2 aylık tam/yarım veli izni): gen5.py çizimi; kutu konumları okuyucunun kendi düzeninden (form_duzen.js 41–49) alınır ----
  const v5Kod = (ay1) => ((ay1 - 9 + 12) % 12) + 1; // Eylül=1 … Mayıs=9 (Haziran-Temmuz yok)
  function v5Duzen(ay1, yil) { const kod = v5Kod(ay1), D = kok.VELI_FORM_DUZEN && kok.VELI_FORM_DUZEN[String(40 + kod)];
    return kod >= 1 && kod <= 9 && D && D.aylar[0] === ay1 && D.yil === yil ? D : null; }
  function ciz5(c, ay1, yil, tk, baslik) { // v2.5.9: artık üretimde kullanılmaz (geri dönüş için duruyor)
    const D = v5Duzen(ay1, yil); if (!D) throw new Error("Tam/yarım gün veli izni (2 aylık) yalnız 2026-2027 ders yılında Eylül–Mayıs başlangıçlı dönemler için üretilebilir. Diğer aylar için tek aylık veli izin dilekçesini seçin.");
    const kod = v5Kod(ay1), ay2 = ay1 % 12 + 1, yil2 = yil + (ay2 < ay1 ? 1 : 0), AYL = [[ay1, yil], [ay2, yil2]], TX = 4.15, YX = 12.45, KA = 4.4;
    FID.forEach(([x, y]) => c.rect(x - FID_A / 2, y - FID_A / 2, FID_A, FID_A, 1, 0));
    const [b8, b2] = kodV5(kod); [...KOD_X, ...EK_X].forEach((x, i) => c.rect(x - KOD_A / 2, KOD_Y - KOD_A / 2, KOD_A, KOD_A, [...b8, ...b2][i], 0.8));
    const ogr = dersYiliBas(ay1, yil);
    baslikCiz(c, 5, ay1, yil, baslik, ["Yayın No: FRM-01", "Yayın Tarihi: .../.../20..", "Revizyon Tarihi: .../.../20..", "Revizyon Sayısı: 00", "Sayfa No: 1/1", `Kurum/Birim Kodu: ${String((baslik || {}).kurumKodu || "").trim() || "…………"}`]);
    c.txt(190, 53, "Tarih: ….. / ….. / 20….", 9.5, "F", "r");
    c.txt(20, 53, yil === yil2 ? `Dönem: ${AY[ay1]} – ${AY[ay2]} ${yil}` : `Dönem: ${AY[ay1]} ${yil} – ${AY[ay2]} ${yil2}`, 10, "FB");
    c.para(20, 59, 4.3, "Aşağıda bilgileri verilmiş olan okulunuz öğrencisinin, 28.06.2016 tarihli ve 29871 sayılı Resmî Gazete'de yayımlanan Millî Eğitim Bakanlığı Ortaöğretim Kurumları Yönetmeliği'nin 36. maddesi doğrultusunda aşağıda işaretlediğim günlerde izinli sayılmasını istiyorum. Gereğini bilgilerinize arz ederim.", 9.5, 170);
    c.rect(20, 70, 170, 34, 0, 0.8);
    c.txt(23, 77, "Öğrencinin Adı Soyadı:", 9, "FB"); c.dash(60, 120, 77.5); c.txt(23, 86, "Sınıfı / Şubesi:", 9, "FB"); c.dash(50, 80, 86.5); c.txt(23, 95, "İzin isteği sebebi:", 9, "FB"); c.dash(55, 120, 95.5);
    c.txt(157, 77, "Okul Numarası", 9, "FB", "c"); c.txt(157, 101, "Rakamı kutunun içine yazın (sağa yaslı)", 7.5, "FB", "c");
    D.no.forEach((b) => c.rect(b.x, b.y, b.w, b.h, 0, 1.0));
    const kutulu = new Set(D.gunler.map((q) => q.t)), gy = 109;
    c.txt(105, gy, "İzinli sayılacağı günde, tam gün ise TAM kutusuna, yarım gün ise YARIM kutusuna X koyun (yalnız birine).", 8, "FB", "c");
    AYL.forEach(([ay, yl], m) => { const x0 = 20 + m * 87, y0 = gy + 3, cw = 83 / 5, rh = 16.5;
      c.rect(x0, y0, 83, 6, 1, 0.6); c.txt(x0 + 41.5, y0 + 4.4, `${AY[ay]} ${yl}`, 9.5, "FB", "c", 1);
      GUN.forEach((g, k) => { c.txt(x0 + cw * k + cw / 2, y0 + 10, g, 7, "FB", "c"); c.txt(x0 + cw * k + TX, y0 + 14, "Tam", 6, "FB", "c"); c.txt(x0 + cw * k + YX, y0 + 14, "Yarım", 6, "FB", "c"); });
      const ds = dersYiliSinir(ogr);
      haftalar(yl, ay).filter((w) => w.slice(0, 5).some(Boolean)).forEach((w, r) => w.slice(0, 5).forEach((gun, k) => { if (!gun) return; const cx = x0 + cw * k, cy = y0 + 15.5 + r * rh, d = new Date(yl, ay - 1, gun, 12);
        const okunur = kutulu.has(tstr(yl, ay, gun)), kp = tk.tatil.get(gk(yl, ay, gun)) || (!okunur ? "tatil" : (d < ds.b || d > ds.e ? "ders yok" : null));
        // okuyucunun kutu aradığı (düzende kutulu) bir gün okul takviminde kapalıysa: çok açık gri + yazı kutu bölgesinin altında (koyu dolgu işaret sanılmasın)
        c.rect(cx + 0.6, cy + 0.6, cw - 1.2, rh - 1.2, kp ? 1 : 0, 0.4, kp ? (okunur ? 0.94 : 0.82) : null); c.txt(cx + 1.6, cy + 3.9, String(gun), 7.5, "FB");
        if (kp) { c.txt(cx + cw / 2, okunur ? cy + 14.6 : cy + 10, kp.length > 11 ? kp.slice(0, 10) + "." : kp, 6.5, "F", "c"); return; }
        if (tk.arife.has(gk(yl, ay, gun))) c.txt(cx + cw - 1, cy + 3.9, "arife", 5, "F", "r");
        const bx = cx + TX, yx = cx + YX, by = cy + 9.8; c.rect(bx - KA / 2, by - KA / 2, KA, KA, 0, 0.9); c.rect(yx - KA / 2, by - KA / 2, KA, KA, 0, 0.9);
        c.txt(bx, by + 5.1, "tam", 4.8, "F", "c"); c.txt(yx, by + 5.1, "yarım", 4.8, "F", "c"); })); });
    const yb = 229; c.rect(20, yb, 170, 40, 0, 0.8); c.line(80, yb, 80, yb + 40, 0.8); c.line(130, yb, 130, yb + 40, 0.8);
    c.txt(22, yb + 5, "Velisinin Adresi:", 8.5, "FB"); c.txt(82, yb + 5, "Telefon:", 8.5, "FB"); c.txt(132, yb + 5, "Velisinin Adı Soyadı / İmza:", 8.5, "FB");
    c.txt(105, 276, `Evrak Asistanı veli izin formu · kod ${kod} · sürüm 5 · işaretleri ve köşe karelerini kapatmayın, katlamayın`, 6.5, "F", "c");
    return D;
  }
  function duzen(t, ay, yil, tk) { return ciz7(BOS, t, ay, yil, tk || takvimKur()); } // v2.5.9: tür 5 de tek ay (eski 2 aylık düzen: v5Duzen)

  // ---- okuyucu için düzen seçimi: formda yalnız TÜR ve AY kodludur; yıl ve takvim üretim kaydından (bu tarayıcıda indirildiyse) ya da okul ayarlarından ----
  const BAG = { ayar: null, kayit: {}, bugun: null }; const ONBELLEK = new Map();
  // kayıt yoksa: içinde bulunulan ders yılı (Temmuz–Ağustos'ta gelecek ders yılı) — Eylül–Aralık bu yılın başı, Ocak–Ağustos sonraki yıl
  function yilTahmin(ay, bugun) { const b = bugun || BAG.bugun || new Date(), bas = b.getMonth() + 1 >= 7 ? b.getFullYear() : b.getFullYear() - 1; return ay >= 9 ? bas : bas + 1; }
  // v2.5.9: bas = formdaki ders yılı kodu (yoksa null → eski yol: üretim kaydı / içinde bulunulan ders yılı)
  function duzenBul(t, ay, bas) {
    if (!(t >= 1 && t <= 5) || !(ay >= 1 && ay <= 12)) return null;
    const kay = BAG.kayit && BAG.kayit[`${t}-${ay}`]; let yil, tm, am;
    if (bas >= 2000 && bas < 2100) { yil = ay >= 9 ? bas : bas + 1; const k = kay && typeof kay === "object" ? kay[yil] : null; if (k) { tm = k.tatilMetni; am = k.arifeMetni; } else { const a = BAG.ayar || {}; tm = a.tatilMetni; am = a.arifeMetni; } }
    else if (kay && typeof kay === "object" && Object.keys(kay).length) { const b = BAG.bugun || new Date(); yil = +Object.keys(kay).sort((a, c) => Math.abs(new Date(+a, ay - 1, 15) - b) - Math.abs(new Date(+c, ay - 1, 15) - b))[0]; tm = kay[yil].tatilMetni; am = kay[yil].arifeMetni; }
    else { yil = yilTahmin(ay); const a = BAG.ayar || {}; tm = a.tatilMetni; am = a.arifeMetni; }
    const an = JSON.stringify([t, ay, yil, tm, am]); if (!ONBELLEK.has(an)) ONBELLEK.set(an, ciz7(BOS, t, ay, yil, takvimKur(tm, am))); return ONBELLEK.get(an);
  }
  function baglamYaz(b) { Object.assign(BAG, b || {}); }
  try { if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(["ayar", "bosFormKayit"]).then((r) => baglamYaz({ ayar: (r && r.ayar) || {}, kayit: (r && r.bosFormKayit) || {} })).catch(() => {});
    chrome.storage.onChanged.addListener((c, alan) => { if (alan !== "local") return; if (c.ayar) BAG.ayar = c.ayar.newValue || {}; if (c.bosFormKayit) BAG.kayit = c.bosFormKayit.newValue || {}; }); } } catch (e) {}

  // ---- PDF (pdf-lib + fontkit, yerel yazı tipi) ----
  async function pdfUret(sayfalar, o) { // sayfalar: [{t, ay, yil}], o: { PDFLib, fontkit, fontR, fontB (ArrayBuffer), takvim, baslik }
    const { PDFDocument, rgb } = o.PDFLib, doc = await PDFDocument.create(); doc.registerFontkit(o.fontkit);
    const F = { F: await doc.embedFont(o.fontR, { subset: true }), FB: await doc.embedFont(o.fontB, { subset: true }) }, MM = 72 / 25.4;
    doc.setAuthor("Evrak Asistanı — Eyüp ŞEKER"); doc.setCreator("Okul Pro Devamsızlık Rapor Asistanı — Boş form indir (yerel)"); doc.setProducer("Evrak Asistanı");
    const duzenler = [];
    for (const s of sayfalar) {
      const p = doc.addPage([W * MM, H * MM]), Y = (y) => (H - y) * MM, gri = (g) => rgb(g, g, g);
      const c = {
        rect(x, y, w, h, fill, lw, gray) { p.drawRectangle({ x: x * MM, y: Y(y + h), width: w * MM, height: h * MM, ...(fill ? { color: gri(gray == null ? 0 : gray) } : {}), ...(lw ? { borderWidth: lw, borderColor: gri(0) } : { borderWidth: 0 }) }); },
        txt(x, y, s, size = 9, font = "F", hiza = "l", gray = 0) { const f = F[font], wd = f.widthOfTextAtSize(s, size); p.drawText(s, { x: x * MM - (hiza === "c" ? wd / 2 : hiza === "r" ? wd : 0), y: Y(y), size, font: f, color: gri(gray) }); },
        dash(x0, x1, y) { p.drawLine({ start: { x: x0 * MM, y: Y(y) }, end: { x: x1 * MM, y: Y(y) }, thickness: 0.5, dashArray: [1, 2], color: gri(0) }); },
        line(x0, y0, x1, y1, lw) { p.drawLine({ start: { x: x0 * MM, y: Y(y0) }, end: { x: x1 * MM, y: Y(y1) }, thickness: lw || 0.6, color: gri(0) }); },
        arma(cx, cy, r) { p.drawCircle({ x: cx * MM, y: Y(cy), size: r * MM, borderWidth: 0.6, borderColor: gri(0.6) }); c.txt(cx, cy + 1, "Okul arması", 6.5, "F", "c", 0.55); },
        para(x, y, ara, metin, size, gen) { const f = F.F, sat = []; let l = ""; for (const k of metin.split(" ")) { const d = l ? l + " " + k : k; if (f.widthOfTextAtSize(d, size) > gen * MM && l) { sat.push(l); l = k; } else l = d; } if (l) sat.push(l);
          sat.forEach((s, i) => c.txt(x, y + i * ara, s, size)); return sat.length; },
      };
      const tk = o.takvim || takvimKur();
      duzenler.push(ciz7(c, s.t, s.ay, s.yil, tk, o.baslik)); // v2.5.9: beş tür de tek ay (ciz5 = eski 2 aylık çizim, artık üretilmez)
    }
    const ilk = sayfalar[0]; doc.setTitle(sayfalar.length === 1 ? `${BASLIK[ilk.t]} — ${AY[ilk.ay]} ${ilk.yil}` : `Evrak Asistanı boş formlar — ${AY[ilk.ay]} ${ilk.yil}`);
    return { bayt: await doc.save(), duzenler };
  }
  const dosyaAdi = (t, ay, yil) => `${ADLAR[t]}-${asc(AY[ay])}-${yil}.pdf`;
  kok.AylikForm = { AY, TURLER, ADLAR, duzen, duzenBul, baglamYaz, yilTahmin, takvimKur, gunler, dersYiliSinir, dersYiliBas, v5Duzen, v5Kod, pdfUret, dosyaAdi, _ciz7: ciz7, YIL_ALT_X, YIL_UST_X, YIL_TABAN };
  if (typeof module !== "undefined") module.exports = kok.AylikForm;
})(typeof globalThis !== "undefined" ? globalThis : this);
