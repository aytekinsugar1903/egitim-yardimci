// v2.3.25: Veli İzni sekmesi — Rapor ile aynı panel ve motor, yalnızca veli izni satırları (Tür İzinli).
EOA.modulKaydet({
  id: "veli", ad: "Veli İzni", simge: "📝", sira: 11,
  async kur(alan) {
    const [html, css] = await Promise.all([
      fetch(chrome.runtime.getURL("modules/rapor/panel.html")).then((r) => r.text()),
      fetch(chrome.runtime.getURL("modules/rapor/panel.css")).then((r) => r.text()),
    ]);
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.querySelectorAll("script,link,title").forEach((e) => e.remove());
    const st = document.createElement("style"); st.textContent = css;
    const k = document.createElement("div"); k.className = "panelkok"; k.innerHTML = doc.body.innerHTML;
    alan.append(st, k);
    panelKur(k, "veli");
  },
});
