// Not Girişi akışları (Not Girişi Asistanı 1.0.0). Saf DOM; dış ağ yok, veri yerelde kalır.
(function (root) {
  'use strict';
  const norm = s => (s || '').toLocaleLowerCase('tr-TR').replace(/\s+/g, ' ').trim()
    .replace(/[ıi̇]/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c')
    .replace(/[âä]/g, 'a').replace(/[îï]/g, 'i').replace(/[ûù]/g, 'u').replace(/[êë]/g, 'e').replace(/[ôò]/g, 'o'); // 1.6.36 şapkalı harfler (İNKILÂP, AHLÂK)
  // 1.9.24 Tek paylaşılan iptal (Dur): AbortController; bütün beklemeler ve yazma döngüleri buna bakar. Yeni iş başlarken yeni() çağrılır.
  const IPTAL = root.NGAIptal || (root.NGAIptal = (() => { let ac = new AbortController(); const dinle = new Set();
    return { get sinyal() { return ac.signal; }, mi() { return ac.signal.aborted; }, iptal(neden) { if (!ac.signal.aborted) { ac.abort(neden || 'dur'); dinle.forEach(f => { try { f(neden); } catch (e) {} }); } },
      yeni() { if (ac.signal.aborted) ac = new AbortController(); return ac.signal; }, dinle(f) { dinle.add(f); return () => dinle.delete(f); } }; })());
  const bekle = (ms, sig) => new Promise(r => { const s0 = sig || IPTAL.sinyal; if (s0.aborted) return r(false); const t = setTimeout(() => { s0.removeEventListener('abort', ab); r(true); }, ms), ab = () => { clearTimeout(t); r(false); }; s0.addEventListener('abort', ab, { once: true }); });
  async function kosulBekle(fn, ms = 15000, adim = 150) {
    const t = Date.now(), sig = IPTAL.sinyal;
    while (Date.now() - t < ms) { if (sig.aborted) return null; const v = fn(); if (v) return v; await bekle(adim, sig); }
    return null;
  }
  // Görünür etikete göre select bul: select'in hemen önündeki metin (aynı hücre, önceki hücre ya da üstteki satır)
  function oncekiMetin(s) {
    let t = '', n = s.previousSibling;
    while (n) { t = (n.textContent || '') + t; n = n.previousSibling; }
    if (norm(t)) return t;
    const hucre = s.closest('td,th,div,span');
    if (hucre) {
      let p = hucre.previousElementSibling;
      while (p && !norm(p.textContent)) p = p.previousElementSibling;
      if (p) return p.textContent;
      const tr = hucre.closest('tr'), ust = tr && tr.previousElementSibling;
      if (ust) return ust.textContent;
    }
    return '';
  }
  function etiketliSelect(doc, etiket) {
    const e = norm(etiket).replace(/[:\s]+$/, '');
    for (const s of doc.querySelectorAll('select')) {
      const m = norm(oncekiMetin(s)).replace(/[:\s]+$/, '');
      if (m === e || m.endsWith(e) && (m.length === e.length || /[\s/]/.test(m[m.length - e.length - 1]))) return s;
    }
    return null;
  }
  function secenekSec(sel, hedef) {
    const h = norm(hedef);
    const op = [...sel.options].find(o => norm(o.textContent) === h) || [...sel.options].find(o => norm(o.textContent).includes(h));
    if (!op) return false;
    sel.value = op.value;
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }
  function sinifSecenegi(sel, sinif, sube) { // "9", "A"
    const sb = norm(sube).replace(/[^a-z0-9]/g, ''), re = new RegExp('\\b' + sinif + '\\.?\\s*(sinif\\s*[/-]?\\s*' + sb + '\\s+subesi|[/-]\\s*' + sb + '\\b)');
    return [...sel.options].find(o => re.test(norm(o.textContent)));
  }
  function sinavKutulari(doc) { // "k. Sınav" başlıklı kutular, sırayla
    const tablo = [...doc.querySelectorAll('table')].find(t => norm(t.textContent).includes('sinav puanlari') && t.querySelectorAll('input[type=checkbox]').length);
    if (!tablo) return [];
    return [...tablo.querySelectorAll('input[type=checkbox]')].slice(0, 6);
  }
  // 1.6.10 gerçek OOK07003 kimlikleri
  const SINIF_ID = 'Us_SinifSube1_ddlSinifSube', DERS_ID = 'ddlDersler', LISTELE_ID = 'btnListele';
  // 1.9.24 Kimlik farklıysa etiket metniyle ("Sınıfı / Şubesi", "Sınıf/Şube", "Ders", "Dersler"), o da yoksa seçeneklerin biçimiyle bulunur
  const etiketRe = (doc, re, haric) => [...doc.querySelectorAll('select')].find(s => !(haric || []).includes(s) && re.test(norm(oncekiMetin(s)).replace(/[:\s]+$/, '')));
  const subeBicimli = (doc, haric) => [...doc.querySelectorAll('select')].find(s => !(haric || []).includes(s) && [...s.options].filter(o => /s[ıi]n[ıi]f[ıi]?\s*\/\s*[A-ZÇĞİÖŞÜa-zçğıöşü0-9]+\s+[şs]ube/i.test(o.textContent)).length >= 1);
  const sinifSelect = doc => doc.getElementById(SINIF_ID) || etiketliSelect(doc, 'Sınıf / Şubesi') || etiketRe(doc, /(^|\s)s[ıi]n[ıi]f[ıi]?\s*\/?\s*[şs]ube(si|ler)?$/) || subeBicimli(doc);
  const dersSelect = doc => doc.getElementById(DERS_ID) || etiketliSelect(doc, 'Ders') || etiketRe(doc, /(^|\s)ders(i|ler|leri)?$/, [doc.getElementById(SINIF_ID)].filter(Boolean));
  // 1.6.28 Sayfadaki şube listesi: [{sinif:'11', sube:'F', metin}] (sınıf listelerini kendiliğinden öğrenmek için)
  function sinifSecenekleri(doc) { const x = sinifSelect(doc); if (!x) return []; const out = [];
    [...x.options].forEach(o => { if (!o.value) return; const m = String(o.textContent).match(/(\d{1,2})\s*\.?\s*S[ıiİI]n[ıiİI]f\s*[\/-]\s*([A-ZÇĞİÖŞÜa-zçğıöşü0-9]+)\s+[ŞSşs]ube/i); if (m) out.push({ sinif: String(+m[1]), sube: m[2].toLocaleUpperCase('tr-TR'), metin: o.textContent.trim() }); });
    return out; }
  function idKutulari(doc) { return [1,2,3,4,5,6].map(i => doc.getElementById('chkS' + i)).concat([1,2,3,4,5,6].map(i => doc.getElementById('chkSZL' + i)), [doc.getElementById('chkTPU')]).filter(Boolean); }
  function tumKutular(doc) {
    const ik = idKutulari(doc); if (ik.length) return ik;
    const kok = [...doc.querySelectorAll('*')].find(n => norm(n.textContent).startsWith('not girisi yapilacak alanlar') && n.children.length === 0);
    let alan = kok; while (alan && alan.querySelectorAll('input[type=checkbox]').length < 6) alan = alan.parentElement;
    return alan ? [...alan.querySelectorAll('input[type=checkbox]')] : [];
  }
  function dugme(doc, metin) {
    const m = norm(metin);
    return [...doc.querySelectorAll('input[type=submit],input[type=button],button,a')]
      .find(b => norm(b.value || b.textContent) === m);
  }

  // 1.6.11 Ders eşleme: kâğıttaki ders adı (ör. "Yabancı Dil", "İngilizce", "Türk Dili ve Edebiyatı") e-Okul seçeneğine puanlanır.
  // Emin değilse (puan düşük ya da iki seçenek yakın) null döner; asla sessizce tahmin edilmez.
  const ESANLAM = [[/ingilizce|english|listening|almanca|german|fransizca|yabanci dil/, 'yabanci dil'], [/turk dili|edebiyat/, 'turk dili ve edebiyati'], [/matematik|math/, 'matematik'], [/fizik|physics/, 'fizik'], [/kimya|chemistry/, 'kimya'], [/biyoloji|biology/, 'biyoloji'], [/tarih|history/, 'tarih'], [/cografya|geography/, 'cografya'], [/din kulturu/, 'din kulturu ve ahlak bilgisi'], [/beden egitimi/, 'beden egitimi ve spor']];
  function dersPuan(oku, sec) { const a = norm(oku).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(), b = norm(sec).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(); if (!a || !b) return 0;
    if (a === b || a.replace(/^t c /, 'tc ') === b.replace(/^t c /, 'tc ')) return 1;
    // 1.6.17 ayırt edici sözcükler (seçmeli, ikinci, inkılap, temel, ileri) iki adda farklıysa aynı ders sayılmaz
    const MOD = ['secmeli', 'ikinci', 'inkilap', 'temel', 'ileri'], fark = MOD.some(m => a.includes(m) !== b.includes(m));
    const es = ESANLAM.find(e => e[0].test(a)); if (es && b.startsWith(es[1]) && !fark) return 0.95; if (fark) return 0.3;
    const ta = a.split(' ').filter(w => w.length > 2 && w !== 'dersi' && w !== 've'), tb = b.split(' ').filter(w => w.length > 2 && w !== 've'); if (!ta.length || !tb.length) return 0;
    const lev = (x, y) => { let p = [...Array(y.length + 1).keys()]; for (let i = 1; i <= x.length; i++) { const c = [i]; for (let j = 1; j <= y.length; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1)); p = c; } return p[y.length]; };
    const ort = ta.filter(w => tb.some(v => v === w || (w.length > 4 && v.length > 4 && (v.startsWith(w.slice(0, 5)) || w.startsWith(v.slice(0, 5)))) || (w.length > 3 && lev(w, v) <= Math.floor(Math.max(w.length, v.length) / 5)))).length; // 1.6.13 OCR harf hatasına tolerans
    return 0.9 * ort / Math.max(ta.length, tb.length); }
  function dersKanon(d) { const n = norm(d).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(); if (!n) return ''; const es = ESANLAM.find((e) => e[0].test(n)); return es ? es[1] : n; }
  function dersEsle(sel, ad) { const s = [...sel.options].filter(o => o.value).map(o => [o, dersPuan(ad, o.textContent)]).sort((x, y) => y[1] - x[1]);
    if (!s.length || s[0][1] < 0.6 || (s[1] && s[0][1] < 1 && s[0][1] - s[1][1] < 0.15)) {
      // 1.6.36 Anahtar sözcük tek seçenekte geçiyorsa o seçenek (kâğıtta "Tarih", e-Okul'da yalnız "T.C. İNKILÂP TARİHİ VE ATATÜRKÇÜLÜK" tarih içeriyor): asla birden çok adaydan tahmin edilmez
      const kn = norm(ad).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(), es = ESANLAM.find((e) => e[0].test(kn));
      if (es) { const kelime = es[1].split(' ')[0], tum = [...sel.options].filter((o) => o.value && norm(o.textContent).replace(/[^a-z0-9 ]/g, ' ').split(' ').some((w) => w === kelime || (kelime.length > 4 && w.startsWith(kelime.slice(0, 5))))); if (tum.length === 1) return { op: tum[0], puan: 0.8, tekAday: true }; }
      return { op: null, adaylar: s.slice(0, 3).map(x => x[0].textContent.trim()) }; }
    return { op: s[0][0], puan: s[0][1] }; }
  const IDARE_SAYFA = /OOK07003\.aspx/i;
  const OYSS_SAYFA = /OOK10020\.aspx/i;
  // Görünen metni tam tutan menü öğesi (a/button; yoksa li/span/div içindeki yaprak metin)
  function menuOgesi(doc, metin) {
    const m = norm(metin), es = x => norm(x.textContent).replace(/[›>»\s]+$/, '') === m;
    const a = [...doc.querySelectorAll('a,button')].find(es); if (a) return a;
    const y = [...doc.querySelectorAll('li,span,div,td')].find(x => es(x) && ![...x.children].some(es));
    return y ? (y.closest('a,button,li') || y) : null;
  }
  // İdare akışı: hedef = {sinif:'9', sube:'A', ders:'...', sinav:1, donem?:'2026-2027 I. Dönem'}
  // 1.6.17 Sayfada seçili şube ("10-M") ve ders; yazmadan önce panelin grubuyla karşılaştırılır (yanlış şubeye not yazılmasın)
  function sayfaSinifi(doc) { const x = sinifSelect(doc), o = x && x.options[x.selectedIndex]; if (!o || !o.value) return null;
    { const a = subeAyristir(o.textContent); if (a.std) return a.anahtar; } // 1.9.24 program/alan dahil
    const m = String(o.textContent).match(/(\d{1,2})\s*\.?\s*S[ıiİI]n[ıiİI]f\s*[\/-]\s*([A-ZÇĞİÖŞÜa-zçğıöşü0-9]+)\s+[ŞSşs]ube/i);
    return m ? String(+m[1]) + '-' + m[2].toLocaleUpperCase('tr-TR') : null; }
  function sayfaDersi(doc) { const x = dersSelect(doc), o = x && x.options[x.selectedIndex]; return o && o.value ? String(o.textContent).trim() : ''; }
  const sinifAnahtar = v => norm(String(v || '')).replace(/[^a-z0-9]/g, '');
  // 1.6.12 Adım günlüğü: her adım (sayfa yüklemeleri arasında) sessionStorage'da tutulur, Tanı raporunda görünür. Ad/TC yazılmaz.
  function adimLog(doc, m) { try { const w = doc.defaultView, s = w.sessionStorage, l = JSON.parse(s.getItem('ngaAdimLog') || '[]');
    l.push(new Date().toTimeString().slice(0, 8) + ' ' + (w.location.pathname || '') + ' ' + m); s.setItem('ngaAdimLog', JSON.stringify(l.slice(-40))); } catch (e) {} }
  async function idareListele(doc, hedef, durum0 = () => {}, opt = {}) {
    const durum = (k, t, m) => { adimLog(doc, k + ':' + t + ' ' + m); durum0(k, t, m); };
    const loc = opt.konum || (doc.defaultView && doc.defaultView.location.href) || '';
    if (OYSS_SAYFA.test(loc)) {
      durum('sayfa', 'hata', "OYSS (OOK10020) sayfasında ders notu akışı başlatılmaz; OOK07003'e geçilmez.");
      return { ok: false, adim: 'oyss' };
    }
    adimLog(doc, 'başla hedef=' + (hedef.sinif || '?') + '/' + (hedef.sube || '') + ' ders=' + (hedef.ders || '?'));
    if (!IDARE_SAYFA.test(loc)) {
      durum('sayfa', 'bekle', 'Not İşlemleri > Ders Notu Girişi açılıyor');
      // 1.6.13 e-Okul Pro'nun çalışan yöntemi birebir: giris.aspx'te #mdlOOK tıklanır (yoksa OOK00001); diğer her sayfada doğrudan OOK07003'e gidilir
      const w = doc.defaultView, kok = (loc.match(/^https?:\/\/[^/]+/) || [''])[0], git = opt.git || (u => { w.location.href = u; });
      adimLog(doc, 'sayfa=' + loc + ' cerceve=' + (w && w !== w.top ? 'alt' : 'ust')); if (/giris\.aspx/i.test(loc)) adimLog(doc, 'başlangıç: ana sayfa (giris)');
      opt.kaydet && opt.kaydet(hedef); adimLog(doc, 'devam bilgisi kaydedildi');
      if (/giris\.aspx/i.test(loc)) { const mdl = doc.getElementById('mdlOOK');
        if (mdl) { durum('sayfa', 'bekle', 'Ana sayfa: Kurum İşlemleri (mdlOOK) tıklandı'); mdl.click(); return { ok: true, adim: 'gecis' }; }
        adimLog(doc, 'mdlOOK yok, OOK00001 açılıyor'); durum('sayfa', 'bekle', 'Ortaöğretim Kurum İşlemleri açılıyor'); git(kok + '/OrtaOgretim/OKL/OOK00001.aspx'); return { ok: true, adim: 'gecis' }; }
      if (!kok) { durum('sayfa', 'hata', 'Sayfa adresi okunamadı. Ders Notu Girişi\'ni elle açın.'); return { ok: false, adim: 'sayfa' }; }
      adimLog(doc, 'doğrudan OOK07003 açılıyor'); durum('sayfa', 'bekle', 'Ders Notu Girişi açılıyor'); git(kok + '/OrtaOgretim/OKL/OOK07003.aspx'); return { ok: true, adim: 'gecis' };
    }
    durum('sayfa', 'tamam', 'Hızlı Not Girişi sayfası');
    if (hedef.donem) {
      const d = etiketliSelect(doc, 'Eğitim Öğretim Dönemi');
      const sec = d && d.options[d.selectedIndex];
      if (d && sec && !norm(sec.textContent).includes(norm(hedef.donem))) { durum('donem', 'hata', 'Seçili dönem farklı: ' + sec.textContent.trim() + '. Dönemi siz değiştirin.'); return { ok: false, adim: 'donem' }; }
      durum('donem', 'tamam', 'Dönem doğru');
    }
    const sinif = sinifSelect(doc);
    const ders0 = dersSelect(doc);
    if (!sinif || !ders0) { durum('sube', 'hata', 'Şube/Ders seçimi bulunamadı'); return { ok: false, adim: 'sube' }; }
    { const a0 = anahtarAyir(hedef.anahtar || hedef.sinif); if (a0) hedef = Object.assign({}, hedef, { sinif: a0.sinif, sube: a0.sube, program: hedef.program || a0.program, anahtar: hedef.anahtar || (a0.program || a0.alan ? anahtarKur(a0) : '') }); }
    let bu = hedef.deger && !hedef.anahtar ? { op: [...sinif.options].find(o => o.value === hedef.deger) } : subeSecenegiBul(sinif, hedef); // 1.9.23 öğrenirken seçenek değeriyle (Akademik Destek vb.)
    // 1.9.24 şube bu programda yoksa sayfadaki Program listesinden hedefin programı seçilir (postback; sayfa yenilenirse kalınan yerden sürer)
    if (!bu.op && !bu.cok && hedef.program && programSelect(doc)) { const ps = programSelect(doc), po = [...ps.options].find(o => o.value && (o.textContent.trim() === hedef.programAd || kisalt(o.textContent) === hedef.program));
      if (po && ps.value !== po.value && (hedef._prog || 0) < 2) { hedef = Object.assign({}, hedef, { _prog: (hedef._prog || 0) + 1 }); opt.kaydet && opt.kaydet(hedef); durum('program', 'bekle', 'Program seçiliyor: ' + po.textContent.trim() + ' (sayfa yükleniyor, en çok 45 sn)');
        ps.value = po.value; ps.dispatchEvent(new Event('change', { bubbles: true }));
        const y = await kosulBekle(() => { const s2 = sinifSelect(doc); const r = s2 && subeSecenegiBul(s2, hedef); return r && (r.op || r.cok) ? r : null; }, 45000);
        if (IPTAL.mi()) { durum('dur', 'hata', 'Durduruldu.'); return { ok: false, adim: 'durdu' }; }
        if (!y) { durum('program', 'hata', po.textContent.trim() + ' programında ' + (hedef.anahtar || hedef.sinif + '-' + hedef.sube) + ' şubesi 45 sn içinde gelmedi. Program listesini kontrol edip yeniden deneyin.'); return { ok: false, adim: 'program' }; }
        bu = y; durum('program', 'tamam', po.textContent.trim()); } }
    if (bu.cok) { durum('sube', 'hata', (hedef.sinif + '-' + hedef.sube) + ' birden çok programda/alanda var (' + bu.cok.slice(0, 4).join(' | ') + '). Paneldeki şube listesinden tam şubeyi seçin.'); return { ok: false, adim: 'sube', cok: bu.cok }; }
    const sinifG = sinifSelect(doc), op = bu.op && (sinifG.contains(bu.op) ? bu.op : [...sinifG.options].find(o => o.value === bu.op.value));
    if (!op) { durum('sube', 'hata', (hedef.anahtar || hedef.sinif + '/' + hedef.sube) + ' şubesi sayfadaki listede yok. ' + (programSelect(doc) ? 'Program seçimini kontrol edin ya da ' : '') + 'şubeyi panelde yeniden seçin.'); return { ok: false, adim: 'sube' }; }
    let eskiDers = null;
    if (sinifG.value !== op.value) { opt.kaydet && opt.kaydet(hedef); // postback sayfayı yeniler; dönünce kalınan yerden devam
      eskiDers = [...(dersSelect(doc) || ders0).options].map(o => o.value + o.textContent).join('|');
      sinifG.value = op.value; sinifG.dispatchEvent(new Event('change', { bubbles: true })); }
    durum('sube', 'tamam', op.textContent.trim());
    durum('ders', 'bekle', 'Ders listesi bekleniyor');
    if (eskiDers !== null) await kosulBekle(() => { const d = dersSelect(doc); return d && [...d.options].map(o => o.value + o.textContent).join('|') !== eskiDers; }, 4000); // 1.6.11 eski şubenin ders listesi kullanılmasın
    const ders = await kosulBekle(() => { const d = dersSelect(doc); return d && d.options.length > 1 ? d : null; }, opt.zaman || 45000);
    if (IPTAL.mi()) { durum('dur', 'hata', 'Durduruldu.'); return { ok: false, adim: 'durdu' }; }
    if (!ders) { durum('ders', 'hata', 'Ders listesi 45 sn içinde dolmadı (sayfa yavaş). Yeniden deneyin.'); return { ok: false, adim: 'ders' }; }
    if (hedef.herhangi && !String(hedef.ders || '').trim()) { // 1.6.28 sınıf listesini öğrenirken: Türk Dili varsa o, yoksa ilk ders (liste yalnız öğrenci numaraları için)
      const tr = (hedef.tercih || []).map(norm).filter(Boolean); // 1.9.23 öğrenirken öğretmenin seçtiği ders(ler) önce
      const o = (tr.length && [...ders.options].find(x => x.value && tr.includes(norm(x.textContent)))) || [...ders.options].find(x => x.value && /turk dili|edebiyat/.test(norm(x.textContent))) || [...ders.options].find(x => x.value);
      if (!o) { durum('ders', 'hata', 'Ders listesi boş'); return { ok: false, adim: 'ders' }; }
      hedef = Object.assign({}, hedef, { ders: o.textContent.trim() }); }
    if (!String(hedef.ders || '').trim()) { durum('ders', 'hata', 'Ders bilinmiyor: kâğıt başlığı okunamadı. Paneldeki Ders listesinden seçip yeniden başlatın.'); return { ok: false, adim: 'ders', emin: false }; }
    const tam = [...ders.options].find(o => o.value && norm(o.textContent) === norm(hedef.ders)), e = tam ? { op: tam } : dersEsle(ders, hedef.ders || '');
    if (!e.op) { durum('ders', 'hata', '"' + (hedef.ders || '?') + '" için ders emin değil. Paneldeki Ders listesinden seçip yeniden başlatın.'); return { ok: false, adim: 'ders', emin: false, adaylar: e.adaylar }; }
    if (ders.value !== e.op.value) { opt.kaydet && opt.kaydet(hedef); ders.value = e.op.value; ders.dispatchEvent(new Event('change', { bubbles: true })); }
    durum('ders', 'tamam', e.op.textContent.trim() + ' (aranan: ' + hedef.ders + ')');
    const tur = hedef.tur || 'sinav', n = hedef.sinav || 1;
    const k = kolonKutusu(doc, tur, n);
    if (!k) { durum('sinav', 'hata', kolonAdi(tur, n) + ' kutusu yok'); return { ok: false, adim: 'sinav' }; }
    tumKutular(doc).forEach(c => { if (c !== k && c.checked) c.click(); });
    if (!k.checked) k.click();
    durum('sinav', 'tamam', kolonAdi(tur, n) + ' seçildi');
    // 1.6.5: Listele'ye asistan basmaz (Güvenlik Kodu var). Kodu siz yazıp Listele'ye siz basarsınız.
    durum('listele', 'bekle', 'Listele\'ye basılıyor; Güvenlik Kodu\'nu Kaydet\'ten önce siz yazın');
    return { ok: true, adim: 'listele' };
  }

  // 1.6.10 Gerçek OOK07003: chkS1-6 Sınav, chkSZL1-6 Performans, chkTPU Proje
  // 1.6.11 Gerçek ekran: chkSZL1-3 = 1-3. Perf., chkSZL4-6 = 1-3. Uyg. (ekran görüntüsündeki sıra)
  const TUR = { sinav: [0, 6, 'Sınav'], perf: [6, 3, 'Perf.'], uyg: [9, 3, 'Uyg.'], proje: [12, 1, 'Proje'] };
  const kolonAdi = (tur, n) => tur === 'proje' ? 'Proje' : n + '. ' + TUR[tur][2];
  function kolonKutusu(doc, tur, n) {
    const t = TUR[tur]; if (!t || n < 1 || n > t[1]) return null;
    const id = tur === 'sinav' ? 'chkS' + n : tur === 'perf' ? 'chkSZL' + n : tur === 'uyg' ? 'chkSZL' + (n + 3) : 'chkTPU', x = doc.getElementById(id); if (x) return x;
    const hep = tumKutular(doc);
    if (hep.length >= 13) return hep[t[0] + n - 1];
    if (tur === 'sinav') return sinavKutulari(doc)[n - 1] || hep[n - 1] || null;
    return null;
  }
  const basKey = s => norm(s).replace(/[\s.]/g, '').replace(/puani?$/, '');
  const hedefKey = (tur, n) => tur === 'proje' ? 'proje' : n + (tur === 'sinav' ? 'sinav' : tur === 'perf' ? 'perf' : 'uyg');
  // Öğrenci tablosu: başlığında "Okul No" ve "Adı Soyadı" olan, satırlarında input olan tablo
  function ogrenciTablosu(doc) {
    const adaylar = [...doc.querySelectorAll('table')].filter(t => { const tx = norm(t.textContent).replace(/\s/g, ''); return tx.includes('okulno') && tx.includes('adisoyadi'); });
    adaylar.sort((a, b) => a.querySelectorAll('table').length - b.querySelectorAll('table').length); // en içteki
    for (const t of adaylar) {
      const satirlar = [...t.rows];
      const bi = satirlar.findIndex(r => { const c = [...r.cells].map(x => basKey(x.textContent)); return c.includes('okulno') || c.some(x => x.startsWith('okulno')); });
      if (bi < 0) continue;
      const bas = [...satirlar[bi].cells].map(x => basKey(x.textContent));
      return { tablo: t, bas, satirlar: satirlar.slice(bi + 1).filter(r => r.cells.length >= 3 && /\d/.test(r.cells[0].textContent)) };
    }
    return null;
  }
  function hucreGirdisi(tr, bas, tur, n, alan) {
    const key = hedefKey(tur, n), i = bas.findIndex(b => b === key || b.startsWith(key));
    const ok = x => x && !x.disabled && !x.readOnly && x.offsetParent !== null || (x && !x.disabled && typeof window === 'undefined');
    const metin = 'input[type=text],input:not([type])';
    // 1.6.17 Dinleme/Konuşma: Yabancı Dil'de not Yazılı yerine Dinleme ya da Konuşma kutusuna yazılacaksa (alan 'D' / 'K').
    // Kutu bulunamazsa başka kutuya YAZILMAZ (null döner).
    if (tur === 'sinav' && (alan === 'D' || alan === 'K')) {
      const ad = alan === 'D' ? 'dinleme' : 'konusma', re = new RegExp('txtdetay' + ad + n + '(\\D|$)', 'i');
      const hepsi = [...tr.querySelectorAll(metin)], g = hepsi.find(x => re.test(norm((x.id || '') + ' ' + (x.name || ''))));
      if (g) return g;
      const c = i >= 0 && tr.cells.length === bas.length ? [...tr.cells[i].querySelectorAll(metin)] : [];
      if (c.length >= 3) return c[alan === 'D' ? 1 : 2];
      if (hepsi.some(x => /txtdetay/i.test(x.id || x.name || ''))) return null;
    }
    // 1.6.14 gerçek tablo: Yabancı Dil hücresinde Yazılı/Dinleme/Konuşma; puan Yazılı'ya (txtDetayYazili{n})
    if (tur === 'sinav') { const y = tr.querySelector('input[id*="txtDetayYazili' + n + '_"],input[name$="txtDetayYazili' + n + '"]'); if (y) return y; }
    if (i >= 0 && tr.cells.length === bas.length) { const c = [...tr.cells[i].querySelectorAll(metin)], y = c.find(x => /yazili/i.test((x.id || '') + (x.name || ''))); if (y || c[0]) return y || c[0]; }
    // yedek: name/id içinde sınav adı (ör. txtSinav1, Perf2, Uyg3, Proje)
    const re = tur === 'proje' ? /proje/i : new RegExp((tur === 'sinav' ? 's[iı]nav' : tur === 'perf' ? 'perf' : 'uyg') + '\\D{0,6}0?' + n + '(?!\\d)', 'i');
    const g = [...tr.querySelectorAll(metin)].filter(x => re.test((x.name || '') + ' ' + (x.id || '')));
    if (g.length === 1) return g[0];
    const hepsi = [...tr.querySelectorAll(metin)];
    return hepsi.length === 1 ? hepsi[0] : null; // yalnız işaretli sütun açıksa tek kutu olur
  }
  // 1.6.15 Okul No yakın eşleştirme: e-Okul listesindeki numaralar kapalı sözlük. Listede olmayan okuma, listede okunmamış TEK bir numaraya
  // 1 hane farkla (değişen/eksik/fazla hane) yakınsa ona bağlanır ama SARI kalır (asla yeşil değil). Birden çok aday varsa bağlanmaz.
  // 1.6.17 El yazısı rakam karışıklığına göre ağırlıklı mesafe: sık karışan çiftler (1-7, 0-6, 3-8, 5-6, 4-9, 2-7, 0-8, 3-5, 1-4, 6-9, 5-7, 1-3) 0.5,
  // diğer değişim 1, eksik/fazla hane 1 ("1" rakamı sık düşer/eklenir: 0.6). Yine kapalı sözlük (e-Okul listesi) ve yine hiçbir zaman yeşil olmaz.
  const KAR = new Set(); ['17', '06', '38', '56', '49', '27', '08', '35', '14', '69', '57', '13'].forEach(p => { KAR.add(p); KAR.add(p[1] + p[0]); });
  const indel = c => c === '1' ? 0.6 : 1;
  function noMesafe(x, y) { const n = x.length, m = y.length, d = [];
    for (let i = 0; i <= n; i++) d[i] = [i ? d[i - 1][0] + indel(x[i - 1]) : 0];
    for (let j = 1; j <= m; j++) d[0][j] = d[0][j - 1] + indel(y[j - 1]);
    for (let i = 1; i <= n; i++) for (let j = 1; j <= m; j++) d[i][j] = Math.min(d[i - 1][j] + indel(x[i - 1]), d[i][j - 1] + indel(y[j - 1]), d[i - 1][j - 1] + (x[i - 1] === y[j - 1] ? 0 : KAR.has(x[i - 1] + y[j - 1]) ? 0.5 : 1));
    return d[n][m]; }
  function noAdaylar(k, nolar, azami = 1.5, say = 3) { return [...new Set(nolar)].filter(n => n !== k).map(n => [n, noMesafe(String(k), n)]).filter(a => a[1] <= azami).sort((a, b) => a[1] - b[1]).slice(0, say); }
  function noYakinla(doc, harita, listeNo) { const L = new Set(listeNo), bos = listeNo.filter(n => !harita.has(n) || harita.get(n).eksik), yeni = new Map();
    let tam = 0, yakin = 0, yok = 0; const okunan = [...harita.keys()].filter(k => !harita.get(k).eksik && !L.has(k));
    for (const [k, s] of harita) { if (s.eksik) continue; if (L.has(k)) { tam++; continue; }
      const ad = noAdaylar(k, bos, 1.0, 2), net = ad.length === 1 || (ad.length === 2 && ad[1][1] - ad[0][1] >= 0.4);
      if (ad.length && net && !yeni.has(ad[0][0]) && !okunan.some(o => o !== k && noMesafe(o, ad[0][0]) <= 1.0)) { yeni.set(ad[0][0], Object.assign({}, s, { no: ad[0][0], kesin: false, yakin: k })); yakin++; } else yok++; }
    yeni.forEach((s, n) => { harita.delete(s.yakin); harita.set(n, s); });
    adimLog(doc, 'okulno: listede ' + listeNo.length + ', tam eşleşen ' + tam + ', yakın (sarı) ' + yakin + ', eşleşmeyen okuma ' + yok + ', kâğıdı olmayan ' + listeNo.filter(n => !harita.has(n) || harita.get(n).eksik).length);
    return { tam, yakin, yok }; }
  const satirNo = tr => (tr.cells[0] ? tr.cells[0].textContent : '').replace(/\D/g, '');
  const SARI = '#ffeb3b', YESIL = '#c8f7c5';
  // sonuclar: [{no:'4272', puan:'85'|'G', kesin:bool}] — Kaydet'e basılmaz
  function puanYaz(doc, tur, n, sonuclar) {
    const T = ogrenciTablosu(doc);
    if (!T) return { ok: false, neden: 'Sınıf Listesi tablosu bulunamadı. Listele\'ye bastınız mı? Olmazsa "Tanı raporu" gönderin.' };
    const harita = new Map(); const cift = new Set();
    sonuclar.forEach(s => { const k = String(s.no || '').replace(/\D/g, ''); if (!k) return; if (harita.has(k)) cift.add(k); harita.set(k, s); });
    noYakinla(doc, harita, T.satirlar.map(satirNo).filter(Boolean));
    let yazilan = 0, sari = 0, kutusuz = 0; const kullanilan = new Set();
    for (const tr of T.satirlar) {
      const no = tr.cells[0].textContent.replace(/\D/g, '');
      const x = hucreGirdisi(tr, T.bas, tur, n);
      const s = harita.get(no);
      tr.style.outline = '';
      if (muafMi(tr, T.bas)) { if (s) kullanilan.add(no); continue; } // 1.9.23 Muaf
      if (!x) { if (s) kutusuz++; continue; }
      if (!s) { x.style.background = SARI; tr.style.background = SARI; sari++; continue; }
      kullanilan.add(no);
      x.value = String(s.puan); x.dispatchEvent(new Event('input', { bubbles: true })); x.dispatchEvent(new Event('change', { bubbles: true }));
      const kesin = s.kesin === true && !cift.has(no) && s.puan !== '' && s.puan != null;
      x.style.background = kesin ? YESIL : SARI; tr.style.background = kesin ? '' : SARI;
      yazilan++; if (!kesin) sari++;
    }
    const eslesmeyen = [...harita.keys()].filter(k => !kullanilan.has(k));
    return { ok: true, yazilan, sari, kutusuz, eslesmeyen, satir: T.satirlar.length };
  }
  // 1.6.11 Daktilo gibi yazma: her satırda kutuya odaklanır, rakamları tek tek küçük rastgele aralıkla yazar, input/change/blur gönderir, satırlar arasında kısa ara verir.
  // Güvenlik Kodu'na ve Kaydet'e dokunmaz.
  async function puanYazYavas(doc, tur, n, sonuclar, opt = {}) {
    const T = ogrenciTablosu(doc);
    if (!T) return { ok: false, neden: 'Sınıf Listesi tablosu bulunamadı. Listele\'ye bastınız mı? Olmazsa "Tanı raporu" gönderin.' };
    const W = doc.defaultView, rs = (a, b) => (opt.hiz === 0 ? 0 : a + Math.random() * (b - a)) * (opt.hiz || 1), ev = (x, t) => x.dispatchEvent(new W.Event(t, { bubbles: true }));
    const tus = (x, t, k) => { try { x.dispatchEvent(new W.KeyboardEvent(t, { key: k, bubbles: true })); } catch (e) {} };
    const harita = new Map(), cift = new Set();
    sonuclar.forEach(s => { const k = String(s.no || '').replace(/\D/g, ''); if (!k) return; if (harita.has(k)) cift.add(k); harita.set(k, s); });
    if (!opt.yakinYok) noYakinla(doc, harita, T.satirlar.map(satirNo).filter(Boolean)); // 1.9.0 Excel'den gelen numara kesindir: en yakın numaraya UYDURULMAZ (listede yoksa yazılmaz, bildirilir)
    let yazilan = 0, sari = 0, kutusuz = 0, ustune = 0, muaf = 0; const kullanilan = new Set();
    const alanlar = tur === 'sinav' && [...harita.values()].some(s => s.alt) ? (opt.alanlar || detayAlanlari(doc)) : [];
    const kutuYaz = async (x, v) => { x.focus && x.focus({ preventScroll: true }); x.value = ''; ev(x, 'input');
      for (const ch of v) { tus(x, 'keydown', ch); x.value += ch; tus(x, 'keypress', ch); ev(x, 'input'); tus(x, 'keyup', ch); await bekle(rs(20, 50)); }
      ev(x, 'change'); x.blur && x.blur(); ev(x, 'blur'); };
    const sig = IPTAL.sinyal, islenen = [], atla = new Set((opt.atla || []).map(String)); let durdu = false;
    for (const tr of T.satirlar) {
      const no = tr.cells[0].textContent.replace(/\D/g, ''), x = hucreGirdisi(tr, T.bas, tur, n, opt.alan), s = harita.get(no);
      if (sig.aborted) { durdu = true; break; } // 1.9.24 Dur: bulunulan hücre bitti, sonrakine geçilmez
      if (no && atla.has(no)) { if (s) kullanilan.add(no); islenen.push(no); continue; } // Devam: önceden yazılanlar atlanır
      islenen.push(no);
      tr.style.outline = '';
      if (muafMi(tr, T.bas)) { if (s) { muaf++; kullanilan.add(no); } continue; } // 1.9.23 Muaf: dokunulmaz
      if (s && s.alt && alanlar.length) { // 1.9.23 detaylı: her alt alan kendi kutusuna; Ort. yazılmaz
        kullanilan.add(no); let n0 = 0, eksikKutu = 0;
        for (const a of alanlar) { const v = String(s.alt[a.harf] == null ? '' : s.alt[a.harf]).trim().toUpperCase(); if (!v) continue; const y = altGirdisi(tr, T.bas, n, alanlar, a.harf); if (!y) { eksikKutu++; continue; }
          if (String(y.value || '').trim() && String(y.value).trim() !== v) ustune++; await kutuYaz(y, v); y.style.background = s.kesin === true && !cift.has(no) ? YESIL : SARI; n0++; }
        if (!n0) { kutusuz++; continue; } if (eksikKutu) { kutusuz++; tr.style.background = SARI; sari++; }
        yazilan++; opt.ilerle && opt.ilerle(yazilan); await bekle(rs(100, 250)); continue; }
      if (!x) { if (s) kutusuz++; continue; }
      if (!s) { x.style.background = SARI; tr.style.background = SARI; sari++; continue; }
      if (s.eksik && String(x.value || '').trim()) { kullanilan.add(no); continue; } // kâğıdı olmayan öğrencide e-Okul'da değer varsa dokunulmaz
      kullanilan.add(no); const v = String(s.puan === '' || s.puan == null ? 'G' : s.puan); if (String(x.value || '').trim() && String(x.value).trim() !== v) ustune++;
      x.focus && x.focus({ preventScroll: true }); x.value = ''; ev(x, 'input');
      for (const ch of v) { tus(x, 'keydown', ch); x.value += ch; tus(x, 'keypress', ch); ev(x, 'input'); tus(x, 'keyup', ch); await bekle(rs(20, 50)); }
      ev(x, 'change'); x.blur && x.blur(); ev(x, 'blur');
      const kesin = s.kesin === true && !s.eksik && !cift.has(no) && s.puan !== '' && s.puan != null;
      x.style.background = kesin ? YESIL : SARI; tr.style.background = kesin ? '' : SARI;
      yazilan++; if (!kesin) sari++; opt.ilerle && opt.ilerle(yazilan);
      await bekle(rs(100, 250));
    }
    const eslesmeyen = durdu ? [] : [...harita.keys()].filter(k => !kullanilan.has(k));
    return { ok: true, durdu, islenen, yazilan, sari, kutusuz, ustune, muaf, alanlar: alanlar.map(a => a.harf), eslesmeyen, satir: T.satirlar.length };
  }
  // Tanı raporu: ad/TC yok; harfler x, rakamlar 9 ile maskelenir (başlıklar ve etiketler açık)
  function taniRaporu(doc) {
    const mask = s => (s || '').replace(/\s+/g, ' ').trim().replace(/\d/g, '9').replace(/[A-Za-zÇĞİÖŞÜçğıöşü]/g, 'x');
    const kisa = (s, k = 60) => (s || '').replace(/\s+/g, ' ').trim().slice(0, k);
    const el = x => x.tagName.toLowerCase() + (x.type ? '[' + x.type + ']' : '') + (x.id ? '#' + x.id : '') + (x.name ? ' name=' + x.name : '');
    const kimlik = (() => {
      try {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) {
          const mf = chrome.runtime.getManifest();
          if (mf && mf.version) return ((mf.short_name || mf.name || 'Not Girişi Asistanı') + ' ' + mf.version).trim();
        }
      } catch (e) {}
      return 'Not Girişi Asistanı (sürüm okunamadı)';
    })();
    const L = [kimlik + ' tanı raporu', 'Sürüm (getManifest): ' + kimlik, 'URL: ' + ((doc.defaultView && doc.defaultView.location.pathname) || ''), 'Çerçeve: ' + doc.querySelectorAll('iframe,frame').length];
    try { L.push('-- ADIM GÜNLÜĞÜ'); JSON.parse(doc.defaultView.sessionStorage.getItem('ngaAdimLog') || '[]').forEach(x => L.push(x)); } catch (e) {}
    L.push('-- SELECT'); doc.querySelectorAll('select').forEach(s => L.push(el(s) + ' etiket="' + kisa(oncekiMetin(s), 40) + '" secenek=' + s.options.length));
    const secili = x => x ? ((x.options[x.selectedIndex] || {}).textContent || '').trim() + ' (secenek=' + x.options.length + ')' : 'YOK';
    L.push('-- SEÇİLİ Sınıf/Şube: ' + secili(sinifSelect(doc)) + ' | Ders: ' + secili(dersSelect(doc)));
    { const d = dersSelect(doc); if (d) L.push('-- DERS SEÇENEKLERİ: ' + [...d.options].map(o => kisa(o.textContent, 50)).join(' | ')); } // 1.6.24
    L.push('-- CHECKBOX'); tumKutular(doc).forEach((c, i) => L.push(i + ': ' + el(c) + (c.checked ? ' [x]' : '')));
    L.push('-- BUTON'); doc.querySelectorAll('input[type=submit],input[type=button],input[type=image],button').forEach(b => L.push(el(b) + ' "' + kisa(b.value || b.textContent || b.alt || b.title, 30) + '"'));
    L.push('-- GÜVENLİK KODU kutusu var: ' + /guvenlik kodu/.test(norm(doc.body ? doc.body.textContent : ''))); doc.querySelectorAll('input[type=text],input:not([type])').forEach(g => { if (!/dgListem|^nga/.test(g.id || '')) L.push('  metin kutusu: ' + el(g)); });
    const T = ogrenciTablosu(doc);
    if (!T) L.push('-- ÖĞRENCİ TABLOSU YOK. Tablolar: ' + [...doc.querySelectorAll('table')].map(t => t.rows.length + 'x' + (t.rows[0] ? t.rows[0].cells.length : 0)).join(' '));
    else { L.push('-- ÖĞRENCİ TABLOSU başlık: ' + T.bas.join(' | ') + ' / satır=' + T.satirlar.length);
      T.satirlar.slice(0, 3).forEach((tr, i) => L.push('satır' + (i + 1) + ': ' + [...tr.cells].map(c => { const g = [...c.querySelectorAll('input,select')].map(el).join(','); return g || mask(c.textContent).slice(0, 12); }).join(' | '))); }
    return L.join('\n');
  }

  // Öğretmen akışı: ekranlar gelince doldurulacak
  async function ogretmenListele(doc, hedef, durum = () => {}) {
    durum('ogretmen', 'hata', 'Öğretmen ekranı henüz hazır değil');
    return { ok: false, adim: 'ogretmen', hazirDegil: true };
  }

  // 1.9.23 Sınıf/Şube seçeneği ayrıştırma. Örn. "ATP - 9. Sınıf / A Şubesi (BİLİŞİM TEKNOLOJİLERİ ALANI)",
  // "ATP - 12. Akademik Destek (Eşit Ağırlık) / A Şubesi (KİMYA TEKNOLOJİSİ ALANI)". Bilinmeyen biçim atlanmaz: ham metinle döner.
  function subeAyristir(metin) {
    const t = String(metin || '').replace(/\s+/g, ' ').trim();
    const m = t.match(/^(?:([A-ZÇĞİÖŞÜ0-9]{2,8})\s*-\s*)?(.+?)\s*\/\s*([A-ZÇĞİÖŞÜa-zçğıöşü0-9]+)\s+[ŞSşs]ube(?:si)?\s*(?:\((.*)\))?\s*$/);
    if (!m) return { ham: true, std: false, metin: t, program: '', seviye: '', seviyeAd: '', sube: '', alan: '', anahtar: t };
    const sev = m[2].trim(), sm = sev.match(/^(\d{1,2})\s*\.?\s*S[ıiİI]n[ıiİI]f[ıi]?$/i), dm = sev.match(/^(\d{1,2})\s*\./);
    const hz = /^(haz[ıi]rl[ıi]k|hazirlik)(\s*s[ıi]n[ıi]f[ıi]?)?$/i.test(sev) ? 'HAZ' : /^(anas[ıi]n[ıi]f[ıi]?|anaokulu)$/i.test(sev) ? 'ANA' : ''; // 1.9.24 hazırlık / anasınıfı
    const sube = m[3].toLocaleUpperCase('tr-TR'), seviye = hz || (sm ? String(+sm[1]) : dm ? String(+dm[1]) : '');
    const alanVar = m[4] !== undefined, alan0 = (m[4] || '').trim(), alanBos = !/[A-Za-zÇĞİÖŞÜçğıöşü0-9]/.test(alan0), alanAd = alanVar ? (alanBos ? ALANSIZ : alan0) : '';
    const anahtar = (sm || hz) ? (m[1] ? m[1] + ' ' : '') + seviye + '-' + sube + (alanVar ? ' · ' + alanAd : '') : t; // 1.9.24 aynı şube harfi birden çok alanla/programla tekrar edebilir
    return { ham: false, std: !!(sm || hz), metin: t, program: m[1] || '', seviye, seviyeAd: sev, sube, alan: alanBos ? '' : alan0, alanAd, anahtar };
  }
  const ALANSIZ = '(alansız)';
  // 1.9.24 "AMP 9-A · TESİSAT …", "9-A", "ATP 9-B · (alansız)" → parçalar
  function anahtarAyir(k) { const m = String(k || '').replace(/\s+/g, ' ').trim().match(/^(?:([A-ZÇĞİÖŞÜ0-9]{2,8}) )?(\d{1,2}|ANA|HAZ)\s*[-/. ]?\s*([A-Za-zÇĞİÖŞÜçğıöşü]+)(?:\s*·\s*(.+))?$/);
    return m ? { program: m[1] || '', sinif: m[2], sube: m[3].toLocaleUpperCase('tr-TR'), alan: (m[4] || '').trim() } : null; }
  const anahtarKur = a => (a.program ? a.program + ' ' : '') + a.sinif + '-' + a.sube + (a.alan ? ' · ' + a.alan : '');
  // 1.9.24 Program adı → kısaltma ("Anadolu Teknik Programı" → ATP); option öneki ile eşleştirmek için
  const kisalt = ad => String(ad || '').replace(/\(.*?\)/g, ' ').trim().split(/\s+/).filter(Boolean).map(w => w[0]).join('').toLocaleUpperCase('tr-TR');
  // Hedef şube seçeneği: önce saklanan option value (metni de tutuyorsa), sonra tam anahtar; düz "9-A" birden çok seçeneğe uyuyorsa belirsiz
  function subeSecenegiBul(sel, h) { const op = [...sel.options].filter(o => o.value), ak = h.anahtar ? sinifAnahtar(h.anahtar) : '';
    if (h.deger) { const o = op.find(x => x.value === h.deger); if (o && (!ak || sinifAnahtar(subeAyristir(o.textContent).anahtar) === ak)) return { op: o }; }
    if (ak) { const o = op.find(x => sinifAnahtar(subeAyristir(x.textContent).anahtar) === ak); if (o) return { op: o }; }
    const a = h.anahtar ? anahtarAyir(h.anahtar) : null; if (a && (a.program || a.alan)) return { op: null };
    const sin = (a && a.sinif) || h.sinif, sub = (a && a.sube) || h.sube; const ad = op.filter(o => { const x = subeAyristir(o.textContent); return x.std && x.seviye === String(+sin) && x.sube === String(sub || '').toLocaleUpperCase('tr-TR'); });
    if (ad.length > 1) return { op: null, cok: ad.map(o => subeAyristir(o.textContent).anahtar) };
    return { op: ad[0] || sinifSecenegi(sel, sin, sub) || null }; }
  function subeSecenekleri(doc) { const x = sinifSelect(doc); if (!x) return []; return [...x.options].filter(o => o.value).map(o => Object.assign(subeAyristir(o.textContent), { deger: o.value })); }
  function seciliSube(doc) { const x = sinifSelect(doc), o = x && x.options[x.selectedIndex]; return o && o.value ? Object.assign(subeAyristir(o.textContent), { deger: o.value }) : null; }
  // Program açılır listesi (Anadolu Meslek Programı, Anadolu Teknik Programı …): sabit değil, sayfadan
  function programSelect(doc) { const sx = sinifSelect(doc), dx = dersSelect(doc), ok = s => s && s !== sx && s !== dx;
    const id = [...doc.querySelectorAll('select')].find(s => ok(s) && /program|okultur|kurumtur/i.test((s.id || '') + ' ' + (s.name || '')));
    if (id) return id; const e = etiketliSelect(doc, 'Program'); return ok(e) ? e : null; }
  function programSecenekleri(doc) { const x = programSelect(doc); if (!x) return []; return [...x.options].filter(o => o.value && !/^(0|-1)$/.test(o.value) && !/^se[cç]iniz/i.test(o.textContent.trim())).map(o => ({ deger: o.value, ad: o.textContent.trim() })); }
  function seciliProgram(doc) { const x = programSelect(doc), o = x && x.options[x.selectedIndex]; return o && o.value && !/^se[cç]iniz/i.test(o.textContent.trim()) ? o.textContent.trim() : ''; }
  // 1.9.23 Detaylı not girişi (Türk Dili Y/D/K, yabancı diller vb.): alt alanlar ve yüzdeler sayfadaki bilgi notundan,
  // yoksa hücredeki input kimliklerinden (txtDetayYazili1, txtDetayDinleme1 …) dinamik okunur. Ort. e-Okul'undur, yazılmaz.
  function detayAlanlari(doc) {
    const out = [], tx = doc.body ? String(doc.body.innerText || doc.body.textContent || '') : '';
    if (/detayl[ıi]\s+not\s+giri[şs]i/i.test(tx)) { const re = /(?:^|[\s,;(.])([A-ZÇĞİÖŞÜ])\s*:\s*([A-Za-zÇĞİÖŞÜçğıöşü]+)\s*\(\s*%\s*(\d{1,3})\s*\)/g; let m;
      while ((m = re.exec(tx))) if (!out.some(a => a.harf === m[1])) out.push({ harf: m[1], ad: m[2], yuzde: +m[3] }); }
    if (!out.length) { const g = new Set(); doc.querySelectorAll('input').forEach(x => { const mm = String((x.id || '') + ' ' + (x.name || '')).match(/txtDetay([A-Za-zÇĞİÖŞÜçğıöşü]+?)\d/i);
      if (mm && !/^ort/i.test(mm[1]) && !g.has(mm[1].toLowerCase())) { g.add(mm[1].toLowerCase()); out.push({ harf: mm[1][0].toLocaleUpperCase('tr-TR'), ad: mm[1], yuzde: null }); } }); }
    return out;
  }
  function altGirdisi(tr, bas, n, alanlar, harf) {
    const a = (alanlar || []).find(x => x.harf === harf); if (!a) return null;
    const metin = 'input[type=text],input:not([type])', ad = norm(a.ad).replace(/[^a-z]/g, ''), hepsi = [...tr.querySelectorAll(metin)];
    const g = hepsi.find(x => new RegExp('txtdetay' + ad + n + '(\\D|$)').test(norm((x.id || '') + ' ' + (x.name || ''))));
    if (g) return g;
    const key = hedefKey('sinav', n), i = bas.findIndex(b => b === key || b.startsWith(key));
    if (i >= 0 && tr.cells.length === bas.length) { const c = [...tr.cells[i].querySelectorAll(metin)].filter(x => !x.readOnly && !x.disabled && !/ort/i.test((x.id || '') + (x.name || '')));
      if (c.length >= alanlar.length) return c[alanlar.indexOf(a)]; }
    return null;
  }
  // 1.9.23 Muaf işaretli öğrenci atlanır
  function muafMi(tr, bas) { const c = [...tr.querySelectorAll('input[type=checkbox]')].find(x => /muaf/i.test((x.id || '') + ' ' + (x.name || '')));
    if (c) return !!c.checked; const i = (bas || []).findIndex(b => /^muaf/.test(b)); if (i >= 0 && tr.cells[i]) { const k = tr.cells[i].querySelector('input[type=checkbox]'); return !!(k && k.checked); } return false; }
  const api = { IPTAL, ALANSIZ, anahtarAyir, anahtarKur, kisalt, subeSecenegiBul, kosulBekle, bekle, subeAyristir, subeSecenekleri, seciliSube, programSelect, programSecenekleri, seciliProgram, detayAlanlari, altGirdisi, muafMi, dersKanon, sinifSecenekleri, sayfaSinifi, sayfaDersi, sinifAnahtar, noMesafe, noAdaylar, hucreGirdisi, adimLog, puanYazYavas, dersEsle, dersPuan, sinifSelect, dersSelect, idareListele, ogretmenListele, etiketliSelect, sinifSecenegi, sinavKutulari, kolonKutusu, kolonAdi, menuOgesi, ogrenciTablosu, puanYaz, taniRaporu, norm, IDARE_SAYFA, OYSS_SAYFA };
  if (typeof module !== 'undefined') module.exports = api; else root.NGAAkis = api;
})(typeof window !== 'undefined' ? window : globalThis);
