// v2.7.3: Ders Notu sekmesi — Not Girişi Asistanı 1.9.24 ders notu girişi (OOK07003): sınıf/ders/şube kutucukları,
// tek adım Excel şablonu, Excel'den sınıf sınıf yazma, Türkçe sesli giriş + önizleme, okulun gerçek dersleri.
// Kaydet ve Güvenlik Kodu öğretmendedir (eklenti basmaz/yazmaz). OYSS kendi sekmesindedir.
EOA.modulKaydet({
  id: "dersnotu", ad: "Ders Notu", simge: "✏", sira: 14,
  kur(alan) {
    alan.innerHTML = `<div class="panelkok"><h2 style="margin:4px 0 8px">Ders notu girişi (OOK07003)</h2>
      <p class="not">Not Girişi Asistanı 1.9.22 özellikleri: sınıf, şube ve ders kutucukları, tek adımda Excel not şablonu,
      Excel'den sınıf sınıf yazma, Türkçe sesli giriş ve önizleme, okulunuzun e-Okul'daki gerçek dersleri.</p>
      <button class="ana" data-is="panel">Ders notu panelini aç</button>
      <button data-is="ice">Excel'den not girişi sayfası</button>
      <p class="not">Kısayol: Alt+G. Panel Ders Notu Girişi sayfasında sağ kenarda da görünür.
      Kaydet ve Güvenlik Kodu sizdedir; eklenti bunlara dokunmaz. Veriler yalnız bu bilgisayarda işlenir.</p>
      <p class="not" data-durum></p></div>`;
    const durum = alan.querySelector("[data-durum]");
    alan.querySelector('[data-is="panel"]').onclick = () => {
      try {
        // Okul Pro paneli balona döner ki ders notu paneli örtülmesin
        const gizle = () => { try { const g = alan.getRootNode().querySelector(".gizle"); if (g) g.click(); } catch (e) {} };
        if (window.__NGA && typeof window.__NGA.ac === "function") { window.__NGA.ac(false); durum.textContent = "Panel açıldı (sağ kenar)."; gizle(); return; }
        chrome.runtime.sendMessage({ tip: "nga-ac-ilet" }, () => { void chrome.runtime.lastError; });
        durum.textContent = "Panel açılıyor… Görünmezse sayfayı yenileyin (F5).";
        gizle();
      } catch (e) { durum.textContent = "Eklenti güncellendi; sayfayı yenileyin (F5)."; }
    };
    alan.querySelector('[data-is="ice"]').onclick = () => {
      try { chrome.runtime.sendMessage({ tip: "sekme-ac", hedef: "ice" }); } catch (e) { durum.textContent = "Eklenti güncellendi; sayfayı yenileyin (F5)."; }
    };
  },
});
