// v2.7.3: Okul Pro içinde Not Girişi 1.9.24 ders notu paneli (OOK07003). Bu bayrak paneli Okul Pro düzenine alır:
// OYSS kendi sekmesinde kalır; çekmece yalnız Ders Notu Girişi sayfasında veya Okul Pro "Ders Notu" sekmesinden açılınca görünür.
self.NGA_EOP = true;
