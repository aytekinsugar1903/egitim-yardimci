# 2.7.3
- **Ders Notu (Not Girişi 1.9.24):** **Excel indir** işi kendisi yapar: liste yoksa Ders Notu Girişi sayfasında Program (varsa), Sınıfı/Şubesi ve Ders seçilir, sütun kutusu işaretlenir, Listele'ye basılır (en çok 45 sn), öğrenciler ve detaylı alanlar (Y/D/K, yabancı dil alanları) okunur, Excel hemen iner. "Ders Notu Girişi'ni aç ve hazırla" seçili hedefe aynı yoldan gider. Sayfa başka yerdeyse ya da hedef bulunamazsa Türkçe yönlendirme.
- Şube anahtarı program + seviye + şube + alan ("AMP 9-A · METAL TEKNOLOJİSİ ALANI"); aynı şube harfinin birçok alanla tekrarlandığı okullarda karışma yok; seçenek değeri saklanır. "(- )" → "(alansız)" (alan süzgecinde de). Excel dosya adı ve içe aktarma alanı içerir. Eski karışık önbellek yükseltmede bir kez temizlenir.
- Seviye işaretlenince şube/alan listesi sayfadan kendiliğinden okunur (seçili programın şubeleri); sabit 5-12 + sayfada bulunan seviyeler (Hazırlık vb.), okulda olmayanlar soluk/pasif; ortaokul "5. Sınıf / A Şubesi" biçimi.
- **Dur / Devam:** öğrenme, yazma, Excel indir ve sesli döngüler ortak iptal bayrağıyla (AbortController) o adımdan sonra durur; ilerleme saklanır, Devam kaldığı yerden (sayfa yenilense de) sürer.
- Düzeltme: Türk Dili gibi detaylı derslerde Excel tek sütunla iniyordu; artık her seferinde güncel liste açılıp "1. Sınav Y / D / K" sütunları ve yüzdeler okunur; okunamazsa uyarı.
- Dokunulmayan: devamsızlık, rapor, veli izni, faaliyet, OYSS (otomatik Kaydet istisnası dahil), kâğıt OCR, Şube sınav durumu, Kapat, Güvenlik Kodu, lisans kodu `eokul`, uzantı kimliği.

# 2.7.2
- **Ders Notu (Not Girişi 1.9.23):** kutucuklar OYSS gibi katmanlı: Program → Sınıf → (Alan) → Şube → Ders; programlar ve şubeler e-Okul sayfasından (programı olmayan okulda katman gizli). "ATP - 9. Sınıf / A Şubesi (… ALANI)" ayrıştırılır; "12. Akademik Destek (…)" gibi biçimler ham metinle gösterilir. "Sınıf listelerini öğren" yalnız seçili program + sınıf/şube + ders kombinasyonlarını gezer; program değişince sayfanın yüklenmesini bekler ve kaldığı yerden sürer. Seçimler hatırlanır.
- "Şu anki hedef" satırında **Excel indir** (tek sınıf·şube·ders şablonu, `Not Girisi/Ders Notu/<tarih>/`); sütun seçimi e-Okul'daki gibi (Sınav 1-6, Performans 1-3, Uygulama 1-3, Proje).
- **Detaylı not girişi** (Türk Dili Y/D/K, yabancı dillerde farklı alanlar): alanlar ve yüzdeler sayfadan; Excel'de her alan ayrı sütun; sesle alanlar sırayla; Ort. yazılmaz. Muaf öğrenci atlanır.
- Ders notu panelinde sesli not artık bağlanır (yükleme sırası düzeltmesi). Aynı şube zaten listeliyken takılma düzeltildi. Düğmeler 3D görünüm (yalnız panel içi CSS).
- Dokunulmayan: devamsızlık, rapor, veli izni, faaliyet, OYSS (otomatik Kaydet istisnası dahil), kâğıt OCR, Şube sınav durumu, Kapat, Güvenlik Kodu, lisans kodu `eokul`, uzantı kimliği.

# 2.7.1
- **Ders Notu sekmesi (yeni):** Not Girişi Asistanı 1.9.22'nin ders notu girişi (OOK07003) Okul Pro'ya alındı: sınıf, şube ve ders kutucukları, okulun e-Okul'daki gerçek dersleri, tek adımda Excel not şablonu, Excel'den sınıf sınıf yazma sayfası (`ice/ice.html`), Türkçe sesli giriş ve önizleme, tanı raporu. Panel Ders Notu Girişi sayfasında sağ kenarda görünür; diğer sayfalarda Okul Pro panelindeki **Ders Notu** sekmesinden veya Alt+G ile açılır. OYSS kendi sekmesinde kalır (ders notu panelinde tekrarlanmaz).
- Ders notu girişinde Kaydet ve Güvenlik Kodu öğretmendedir; eklenti basmaz/yazmaz. Veriler bu bilgisayarda işlenir.
- Dokunulmayan: devamsızlık, rapor, veli izni, faaliyet, OYSS (otomatik Kaydet istisnası dahil), kâğıt OCR, Şube sınav durumu, Kapat, lisans kodu `eokul`, uzantı kimliği.

# 2.7.0
- **Ürün adı:** «Okul İşleri Asistanı (e-Okul için)» / «e-Okul Pro» yerine **Okul Pro Devamsızlık Rapor Asistanı** (kısa ad: Okul Pro). Manifest `name` / `short_name`, panel başlığı, lisans görünen adı ve belgeler buna göre. Lisans ürün kodu `eokul` ve depo anahtarı aynı; mevcut anahtarlar ve 48 saatlik deneme çalışır. e-Okul yalnızca işlevsel metinlerde (sayfa adı, «e-Okul'a yaz») geçer.
- **OYSS / not girişi:** Not Girişi Asistanı 1.9.22 özellikleri bu eklentinin OYSS sekmesine alındı: sınıf (5-6-7, 9-10-11), ders ve şube kutucukları, Tümünü seç, Hepsini seç ve indir, tek adımda liste okuyup Excel'i `Not Girisi/OYSS/<tarih>/` altına indirme, indirilen dosya listesi, eksik şube/ders/sınavda hemen geçme, soru sayısı ve azami puanın Excel'e yazılması, PratiNot tarzı sesli giriş (görünür ses-ac penceresi, iframe yönlendirme, ikili okul no, yapışkan bağlam, katılım komutları), Excel önizlemede ses ve «e-Okul'a yaz» düğmesi (bu düğmede Kaydet'e basılmaz). «e-Okul'a yaz ve Kaydet» kapıları geçilirse Kaydet'e basmaya devam eder (onaylı istisna).
- Dokunulmayan: rapor / veli izni / faaliyet / devamsızlık, kâğıt OCR, Şube sınav durumu, Kapat, Güvenlik Kodu, lisans/deneme akışı. Mağazaya yükleme yok (2.6.0 incelemede).

# 2.6.2
- **Boş, kesik veya yanlış türdeki tarama dosyaları için açık uyarı.** Veli izni / rapor taramasında artık genel "Dosya açılamadı (bozuk ya da desteklenmeyen dosya)" yerine neden belirtilir: boş dosya, çok küçük dosya, JPEG/PDF başı yok, kesik PDF (%%EOF yok). 2.6.1'deki Brother JPEG açma yedeği aynı. PDF/PNG sağlıklı dosyalar, OCR, lisans/deneme ve Kaydet kuralları değişmedi.

# 2.6.1
- **Veli izni / rapor taramasında Brother JPG açılma düzeltmesi.** Bazı tarayıcı JPEG'leri (eksik bitiş işareti, bozulmuş işaret, dosya başında çöp bayt) `createImageBitmap` ile "Dosya açılamadı (bozuk ya da desteklenmeyen dosya)" veriyordu. Artık `Image()` yedeği ve gerektiğinde SOI'den kesip EOI ekleyen onarım kullanılıyor. PDF ve PNG yolu, OCR (çevrimdışı), lisans/deneme ve Kaydet kuralları aynı.
- Dokunulmayan: OYSS, Şube sınav durumu, Kapat, Güvenlik Kodu, otomatik Kaydet kapıları, rapor çıkarımı.

# 2.6.0
- Lisans ve 48 saatlik deneme (Evrak Asistanı ortak lisans sistemi; kurum kodu + kurulum kimliği, Ed25519 imzalı jeton, 7 gün çevrimdışı, bireysel 2 / kurum 7 bilgisayar). İlk açılışta lisans ekranı ve KVKK onayı. e-Okul Pro anahtarı Not Girişi Asistanı’nı da açar.
- Okula özgü varsayılanlar kaldırıldı: şube listesi boş (Okul Ayarları’ndan girilir), rapor kurum listesi genel.
- OCR kütüphanesindeki varsayılan CDN adresleri yerel yollarla değiştirildi (uzaktan kod yok).
- “Tüm verileri sil” lisans kaydını korur.

## 2.5.9 (17.11.2026)
- **Tam/yarım gün veli izni artık TEK AY.** Kural: her form tek ay, iki ay yan yana yok. Boş form indir sayfasında diğer dört form gibi her ay (Eylül–Haziran) ve her ders yılı için üretilir; "Bu ayın tüm formları" artık 5 sayfa. Izgara, okuma testinden geçmiş tek aylık veli izin dilekçesiyle aynı (büyük gün hücresi, TAM/YARIM kutusu); başlık bilgisi FRM-01 tam/yarım biçiminde. Kod: sürüm 7, tür 5.
- **Ders yılı formun üzerinde kodlu.** Alt sağda 4 küçük kare (başlangıç yılı − 2025) ve üst solda tümleyeni. Okuyucu bu kodu görürse yılı formdan alır (başka yılın formu başka bilgisayarda da doğru tarih). Kod yoksa (2.5.8 formları) eski yol aynen: indirme kaydı / içinde bulunulan ders yılı.
- Geriye uyum: eski 2 aylık v5 tam/yarım formları, 2.5.8 aylık formları ve eski faaliyet formları önceki gibi okunur (aynı sentetik sayfalarda 2.5.8 ile aynı çıktı).
- Dokunulmayan: izinler, Kaydet kapıları/otomatik Kaydet, Güvenlik Kodu, OYSS (yalnız SURUM metni), Şube sınav durumu, Kapat, rapor akışı.

## 2.5.8 (17.11.2026)
- **Boş form indir (yeni).** Veli İzni / Faaliyet sekmesindeki **Boş form indir (PDF)** düğmesi yeni bir sayfa açar: ay ve yıl, form türü (veli izin dilekçesi, faaliyet toplu, faaliyet bireysel, devamsızlık takip — tek ay; tam/yarım gün veli izni — 2 aylık, yalnız 2026-2027) seçilir; PDF **tamamen bu bilgisayarda** üretilir (pdf-lib + yerel yazı tipi; ağ yok). "Bu ayın tüm formları" tek PDF'te hepsini verir.
- Başlık: Okul ayarlarındaki okul adı; kaymakamlık ve kurum kodu bu sayfada yazılabilir (yalnız bu bilgisayarda saklanır). Boş bırakılan alanlar noktalı genel başlık olarak kalır; "Genel (boş) başlık" seçeneği vardır.
- Tatil ve arife günleri Okul ayarlarındaki takvimden işaretlenir (tatil gri ve işaretsiz; bireysel / devamsızlık formlarında tatil günü yok). Ders yılı başı/sonu dışındaki günler "ders yok".
- Form yerleşimi 2.4.8 aylık form üreticisiyle (gen7) birebir aynı: işaret kareleri, tür/ay kodu, kutu konumları. Tam/yarım gün formu okuyucunun mevcut v5 düzeninden çizilir.
- **Okuyucu: aylık (sürüm 7) formlar artık tanınıyor.** 2.5.x okuyucusu sitedeki tek aylık formları ("form tanınamadı") okuyamıyordu; 2.4.8'deki aylık form okuma 2.5.8'e taşındı (2.4.9 numara kutusu düzeltmesi ve öğrenci listesi eşleşmesi korunarak). Devamsızlık takip formu okunduğunda satırlar e-Okul özürlü girişine GİTMEZ; paneldeki "Devamsızlık'a ayrılan satırlar" metnine eklenir (yoklama ekranındaki Sesli/Yazılı kutusuna yapıştırılır).
- Okuyucu formun yılını ve takvimini, formu bu bilgisayarda indirirken tutulan kayıttan alır (yoksa içinde bulunulan ders yılı + Okul ayarlarındaki takvim).
- Değişmeyenler: eski formlar (v2–v5 veli izni, faaliyet v2) aynı sonuçla okunur (sentetik testte 2.5.7 ile birebir aynı çıktı); Kaydet akışı ve otomatik Kaydet, Güvenlik Kodu doldurulmaz/çözülmez, OYSS, Şube sınav durumu, Kapat, rapor girişi, izinler (yeni izin yok).

## 2.5.7 (16.11.2026)
- Mağaza görünür adı **Okul İşleri Asistanı (e-Okul için)** olarak değişti (`name`, `short_name`, araç çubuğu başlığı, panel başlığı). Marka: Evrak Asistanı.
- Açıklamada kapsam sayılır: devamsızlık, sağlık raporu, faaliyet formu, veli izni, not girişi/OYSS. «Resmî bir MEB ürünü değildir» notu eklendi.
- Resmî e-Okul logosu veya MEB renk taklidi yoktu (mevcut simge genel pano; panel rengi Google mavisi / Evrak Asistanı laciverti); bu yüzden görsel değişmedi.
- Lisans / ürün kimliği yoktu ve dokunulmadı. Rapor, veli, faaliyet, yoklama, OYSS akışı, Kaydet kapıları, Güvenlik Kodu, Şube sınav durumu ve Kapat değişmedi.

## 2.5.6 (13.11.2026)
- **OYSS canlı sayfa düzeltmesi (OOK10020).** Eklenti paneli içindeki seçiciler (`nga-ders`, `nga-*`, `eoa-*`) sayfa tespitinden çıkarılır. Şube seçiminden sonra ders seçenekleri (modern JS/fetch, MutationObserver, en çok 15 sn) beklenir; **Sınavları Getir** sonrası **OYSS Yazılı Sınav (Asıl)** seçilir; **Öğrenci Listesi Yükle** ile Okul No / Soru tablosu beklenir. Aynı şube metni, parantezdeki alan ile ayırt edilir ve dosya adına yazılır. Adım hata verirse durum satırında şube/ders/sınav/liste belirtilir; toplanan listeler yine indirilir. İndirme `chrome.downloads` ile yapılır. **Şube sınav durumu** ve **Kapat** düğmesine dokunulmaz.
- OYSS sekmesi kendi akışıdır: şube onay kutuları (varsayılan tümü), ders (seçili veya tüm dersler), Excel'e aktar (seçilen / bu şube), Excel yükle, yaz ve Kaydet, Tanı raporu.
- Rapor/veli/faaliyet/yoklama ve Kaydet kapıları değişmedi.

## 2.5.5 (13.11.2026)
- **OYSS canlı sayfa (OOK10020): Tüm şubeleri çek "Şube listesi bulunamadı" düzeltmesi.** `SINIF / ŞUBE`, `DERS`, `SINAV` etiketleri (büyük harf, ikon, eğik çizgi), gizli select2/bootstrap-select/chosen sarmalayıcıları, `id`/`name` içinde Sube/Sinif/Ders/Sinav ve seçenek metni (`9. Sınıf / A Şubesi`) ile tanınır. Türkçe I/İ katla (`toLocaleLowerCase('tr')`) kullanılır. Değer alttaki `<select>`e yazılır; sayfa dünyasında jQuery `trigger('change')` (varsa select2/chosen) çalışır. UpdatePanel/__doPostBack sonrası bir sonraki listenin seçeneklerinin dolması beklenir. **Sınavları Getir** / **Öğrenci Listesi Yükle** `input` `value` metinleriyle de bulunur.
- **Tanı raporu** düğmesi: öğrenci verisi olmadan select id/name, seçenek sayısı, ilk 3 seçenek, etiket ve düğme metinlerini panoya kopyalar (bulunamazsa panelde gösterir).
- Kaydet kapıları, Güvenlik Kodu ve "… Kapat" kuralı, rapor/veli/faaliyet/yoklama kodu değişmedi.

## 2.5.4 (13.11.2026)
- **OYSS Soru Bazlı Not Girişi.** Yeni **📋 OYSS** sekmesi: e-Okul'da *Kurum işlemleri → Not İşlemleri → OYSS Not Girişi* ekranında çalışır. Soru sütunları başlık metninden tanınır (`1. Soru (15 puan)` … en çok 10 soru). Satırlar Okul No ile eşlenir.
- **Tüm şubeleri çek (öncelik):** seçili ders ve sınav için şube listesindeki her şubeyi dolaşır, Öğrenci Listesi Yükle ile tabloyu alır. Çıktı seçilir: **ayrı dosyalar** (`Şube_Ders.xlsx`, zip) veya **tek çalışma kitabı** (şube-ders başına sayfa, `AYAR_01` + liste). İsteğe bağlı "Tüm dersleri de dolaş". **Bu şubeyi aktar** yalnız açık listeyi indirir. 60'tan fazla öğrenci varsa şablon satırları uzatılır. Dosya bu bilgisayarda kalır.
- **Excel yükle:** bir veya birden çok `.xlsx`, şube zip'i veya tek kitabı kabul eder. Açık şube/ders ile eşleşen grup kullanılır.
- **Katılım:** şablonda O sütunu formüldür (puan varsa *Sınava Girdi*, yoksa *Sınava Girmedi*); öğretmen Kopya/Muaf yazabilir. İçe aktarırken önbellekli değer okunur; yoksa aynı kural hesaplanır. Puansız satır hata değildir, sayfada *Sınava Girmedi* seçilir.
- **e-Okul'a yaz ve Kaydet:** puan kutularına `input`/`change`/`blur` ile yazar, Katılım'ı seçenek metnine göre seçer. **Kaydet istisnası:** notlar girildikten sonra sayfadaki Kaydet'e basılır (kullanıcı onayı; "… Kapat" düğmesine basılmaz). **Güvenlik Koduna asla dokunulmaz.**
- **Güvenlik kapıları (Kaydet'ten önce):** eşleşmeyen Okul No, soru sayısı veya soru puanı uyuşmazlığı, sayı olmayan / azami puanı aşan değer, *Sınava Girdi* iken eksik puan. Bu durumda Kaydet'e basılmaz, panelde rapor görünür.
- Çalışma hızı mevcut `ayar.hiz` ile ortaktır. Başlatıcı paneli (sağ kenara gizleme / taşıma) değişmedi. Rapor, veli izni, faaliyet ve yoklama koduna dokunulmadı. Canlı e-Okul seçicileri sentetik fixture ile sınandı; gerçek sayfada doğrulanmadı.

## 2.5.3 (13.11.2026)
- **Rapor CSV / Excel yükleme: maskeli T.C. artık silinmez ve öğrenci listesiyle eşlenir.** Tarama sayfasının `raporlar.csv` çıktısı (başlık: TC, AdSoyad, Baslangic, Bitiş, BelgedekiGun, Tur, Sure, Aciklama, OkunanKurum, Uyari, Sayfalar; T.C. `149******52` biçiminde maskeli) kontrol listesine yüklenince T.C. sütunu boşalmıyordu sanılıp "HAZIR yapılamadı: TC geçersiz" ve Başlat'ta hepsi ATLANDI oluyordu. Neden: maskeli değer mevcut listede tam T.C. bulunamayınca siliniyordu. Artık maske görünür kalır. Rapor sekmesindeki **Öğrenci listesi (T.C. eşleme)** ile e-Okul'dan alınan liste (T.C. Kimlik No, Ad Soyad, Okul No) yüklenirse ilk 3 + son 2 haneye göre eşlenir; ad varsa birden fazla adayı ayırır. Tam bir eşleşme → gerçek T.C. ve ad doldurulur, satır HAZIR olabilir. Eşleşme yoksa "Maskeli TC: öğrenci listesiyle eşleşmedi", birden fazlaysa "Maskeli TC: birden fazla öğrenci eşleşti, seçin". Liste yalnız bu tarayıcıda durur, hiçbir yere (yapay zekâ dahil) gönderilmez, *Eşleme listesini sil* ile kaldırılır. Veli İzni öğrenci listesi değişmedi (T.C. hâlâ saklanmaz). Tam 11 haneli geçerli T.C. satırları eski gibi çalışır.
- CSV / Excel yükleme başlık **adına** göre eşler (büyük/küçük ve Türkçe karakter duyarsız; TC / TC Kimlik / Okul No, AdSoyad / Ad Soyad, Baslangic / Başlangıç, Bitis / Bitiş, Tur / Tür, Sure / Süre, Aciklama / Açıklama takma adları). Başlık yoksa eski sütun sırası kullanılır. Tanınmayan sütunlar (BelgedekiGun, OkunanKurum…) yoksayılır veya nota alınır; Sayfalar Dosya olur.
- **Hepsini HAZIR yap** (ve seçilenleri HAZIR yap) kaç satırın HAZIR olduğunu ve kalanların neden KONTROL kaldığını tek mesajda bildirir. HAZIR denemesi sırasında maskeli satırlar yeniden eşlenir (liste sonradan yüklendiyse).
- Güvenlik Kodu, Kaydet/Gönder ve e-Okul otomasyon adımlarına dokunulmadı.

## 2.5.2 (12.11.2026)
- **Yüzen panelleri sağ kenara gizleme.** Devamsızlık Otomasyonu sağ paneli, Sesli / yazılı devamsızlık kutusu ve Sürekli devamsızlar kutusuna "Sağ kenara gizle" (▶) düğmesi eklendi. Gizlenince panel sağ kenara kayar; eklenti simgeli küçük bir sekme (~40 px) kalır. Sekmeye tıklayınca panel geri gelir. Sekme (ve açık panelin başlığı) fareyle yukarı/aşağı sürüklenir; tık ile sürükleme birkaç piksellik eşikle ayrılır. Gizli hali ve dikey konum panel başına `chrome.storage.local` içinde (`eaPanelCekmece`) sayfa yenilemesinde hatırlanır. Başlatıcı (sol alt balon) zaten taşıma/gizleme düğmelerine sahipti, değişmedi. Otomasyon, Kaydet davranışı, hızlar ve Güvenlik Kodu mantığına dokunulmadı.

## 2.5.1 (09.11.2026)
- **Hız: e-Okul'a giriş artık çok daha hızlı.** Yavaşlığın nedeni: her işlemden sonra sabit 3–4 sn "insan gibi" bekleme, tarihin harf harf (80–200 ms/harf) yazılması, her sayfa yüklenişinde yeniden başlayan 3,5 sn ilk bekleme ve 0,7 sn'lik tur aralığı. Yeni **Çalışma hızı** (panelde Başlat'ın yanında, çalışırken de değiştirilebilir): **Normal** (eskisi gibi, ayardaki bekleme), **Hızlı** (varsayılan), **Çok hızlı**. Güvenlik denetimi her profilde aynıdır: sayfa yüklendi mi ve e-Okul UpdatePanel/postback sürüyor mu (`data-eokul-mesgul`) denetlenmeden işlem yapılmaz; yalnız bekleme ve yazma hızı kısalır. Tarih alanı postback tetikleyebildiği için ona ara bir bekleme verilir. Sahte e-Okul formunda ölçüm (Nedeni + Başlangıç + Süre + Açıklama doldurma): eski 22,4 sn → Hızlı 4,7 sn → Çok hızlı 3,0 sn; Normal eskisiyle aynı (22,4 sn). Gerçek e-Okul'da kazanç ağ/sayfa hızına göre değişir; sorun görürseniz Normal'e dönün.
- **Kontrol listesi: "✔ Hepsini HAZIR yap".** Tek tıkla görünen (süzgeçli) satırlardan OK olmayanların hepsini (KONTROL / ATLANDI / HATA) HAZIR yapar; eksik alanlı satır (ör. Açıklama boş) KONTROL kalır ve sarıyla işaretlenir; OK (girilmiş) satırlara ve başka sekmelerin satırlarına dokunulmaz. ATLANDI/HATA varsa önce dökümüyle onay sorar; yalnız KONTROL satırlar varken sormaz. Önceki iki adımlı yol (Tümünü seç → HAZIR yap) durur.
- Profil dışa/içe aktarımına `hiz` ayarı eklendi. Bekleme (ms) ayarı yalnız Normal hızda kullanılır.

## 2.5.0 (09.11.2026)
- **Veli İzni: öğrenci listesiyle okul numarası doğrulama (isteğe bağlı).** Tarama sayfasının Veli İzni bölümüne "Öğrenci listesi" alanı eklendi: Excel (.xlsx), CSV ya da e-Okul sınıf listesinden kopyala-yapıştır ile yüklenir; başlıklar ("Okul No", "Adı Soyadı", "Sınıf"…) otomatik tanınır, **T.C. ve diğer sütunlar saklanmaz**. Liste varken:
  - Okunan numara listedeyse satırda yeşil "✓ Ad Soyad · Sınıf" görünür (formdaki el yazısı adla karşılaştırabilirsiniz).
  - Listede yoksa satır kırmızı olur ve en yakın liste numaraları **tek tıkla seçilebilir öneri** olarak sunulur (seçince aynı yanlış numaralı satırlar da değişir).
  - Okuyucunun zaten emin olmadığı hanelerde ve listede tek belirgin aday varsa numara kendiliğinden düzeltilir; bu satırlar turuncu "↻ Listeye göre düzeltildi" bilgisi + "↶ eski numara" düğmesi taşır, üstte **"Hepsini geri al"** vardır. Sessiz düzeltme yoktur.
  - Listede olmayan numaralı satır varsa "Kontrol listesine aktar" öncesi onay istenir.
  - Okuyucu artık her hanenin sınıf olasılıklarını da verir (`noOlas`). Kural benzetimle ayarlandı (11 form + 700 sahte öğrenci): kalan okuma hatalarının ~%82'si düzeldi, doğru okunmuş numara bozulmadı; öğrenci listede yoksa yanlış düzeltme riski ~%1,5 (bu yüzden her düzeltme görünür ve geri alınabilir).
  - Liste yalnız bu tarayıcıda (chrome.storage.local) durur, istenince silinir; "Adları kaydet" kapalıysa yalnız baş harfler saklanır. KVKK.md güncellendi.
- Not: liste olmadan eklenti eskisi gibi çalışır.

## 2.4.9 (09.11.2026)
- **Veli izni okul numarası okuma düzeltildi.** Gerçek taramalarda (11 form) numaraların yalnız 5'i, rakamların 32/44'ü doğru okunuyordu (ör. 4778 → 6058, 4495 → 6595). Nedeni: kutu çerçevesinin kesite girmesi. Tarama ölçeği/kayması yüzünden kutuların gerçek konumu yerleşimden ~1–1,5 mm sapıyor; kesitte komşu/kendi kutu çizgisi kalıyor ve rakam tanıma ağı "|5", "|0", "⌈4" gibi görüp 6 ya da 1'e kaydırıyordu. Artık her kutunun çevresinde geniş bir pencere alınır, kutunun bilinen genişliğine uyan çerçeve çizgisi çifti bulunur ve kesit çerçevenin İÇİNDEN yapılır (`kirpKutu`); kalan çerçeve parçaları da silinir. Sonuç aynı 11 formda 11/11 numara, 44/44 rakam; eğim, kayma, bulanıklık, gürültü, düşük çözünürlük, JPEG ve soluk kontrast ile bozulmuş 121 sayfada eski kod %50 numara / %71 rakam, yeni kod %98 / %99. Yalnız okul numarası kutuları değişti; faaliyet ve diğer akışlar eski davranışta.
- **Tarama sayfasında (Veli İzni tablosu) numara toplu düzeltme.** Bir satırda okul no düzeltilince aynı (yanlış) numaralı diğer satırlar da değişir; boşluklu yazılmış numaralar (55 83) de eşleşir, faaliyet ve veli izni satırları ayrı tutulur. Etkilenen satırlar yeşil çerçeveyle işaretlenir, tablonun üstünde "N satır güncellendi" notu ve **Geri al** çıkar. Önceden bu yalnız kontrol listesinde (panel) vardı; tarama sayfasında her satır tek tek düzeltiliyordu.
- Not: iyileştirme 11 farklı el yazısı üzerinde doğrulandı; yeni öğrencilerin yazısına genelleme için daha çok örnekle ölçüm önerilir. Rakam tanıma modeli (MNIST tabanlı) değişmedi.

## 2.4.8 (09.11.2026)
- Devamsızlık girişi: gün içinde YALNIZ 1 ders kaçırılmışsa (hangi ders olursa olsun) **Geç** kutusu işaretlenir; sabah / öğleden sonra yarım gün işaretlenmez. Önceden yalnız 1. ders kaçırılınca Geç işaretleniyordu (3. ders → Sabah, 5. ders → Öğleden sonra oluyordu). Birden çok ders için kurallar aynı: günün yarısından fazlası → Tam gün; yalnız ilk yarı → Sabah; yalnız ikinci yarı → Öğleden sonra; iki yarıya dağılmışsa → Sabah. Karar mantığı `devamsizlikKutusu()` işlevine ayrıldı ve `test/devamsizlik_kural.test.js` ile sınanır.
- Kapsam: yalnız Devamsızlık modülünün yoklama işaretleme motoru. Veli Asistanı'na gönderilen liste (vkTurBul), Rapor, Veli İzni ve Faaliyet modülleri değişmedi.

## 2.4.7 (04.11.2026)
- Aynı numara düzeltmesi gerçekten çalışıyor: tabloda bir satırda numara değişince (ör. 6058 → 4778) aynı numaralı tüm satırlar (boşluklu yazılmışlar dahil) değişir, tablo hemen yeniden çizilir, "N satır güncellendi" + Geri al. Neden: 2.4.5 kodu panelKur dışına eklenmişti (sayfa içi panelde not/Geri al çalışmıyordu), tablo odaktayken yeniden çizilmiyordu, numaralar boşluk farkıyla eşleşmiyordu.
- İşaret kutuları: boş kutu işaretli sayılmıyor. Eşik artık sayfanın en boş kutularına göre (taban + en az 0,07, gürültüye göre büyür), kutu içinin dış %20'si sayılmaz; arada kalanlar "belirsiz — kontrol edin". Önceki eşik taban + 0,02 idi; çerçeve gölgesi / tarama gürültüsü işaret sanılıyordu.
- El yazısı numara: veli izni / devamsızlık formları 2.4.3'ün faaliyet listesi okuyucusuna yanlışlıkla gidiyordu (ElRakam el yazısı rakam modeli atlanıp Tesseract kullanılıyordu). Liste okuyucu artık dilekçe / veli izin formu / 'velisi' geçen sayfalarda devreye girmez.
- Gün tanılama: tanılama günlüğü indir düğmesi sayfa içi panelde de çalışır.

## 2.4.6 (04.11.2026)
- Faaliyet (ve tümü) otomatik Kaydet: kayıt listede görülmedikçe Kaydet ~1 sn arayla 3 kez basılır (önceden 2. basış yalnız E01-OOG02013 uyarısı çıkınca yapılıyordu; Faaliyet'te bu uyarı çıkmadığı için tek basışta kalıyordu). Yeni satır listede doğrulanmadan sıradaki öğrenciye geçilmez; 3 basış + 12 sn sonra hâlâ yoksa sarı ATLANDI ve ayrıntılı neden.
- Faaliyet listesi PDF'inde Açıklama = yazıdaki etkinlik adı (ör. Kros, Futbol, Masa Tenisi; sözlük + ayarlardaki faaliyet adları, yoksa "… müsabaka/turnuva/yarışma" öncesi kelime, emin değilse KONTROL). Bulunamazsa "Faaliyet". Panelde düzenlenebilir, toplu düzenleme uygulanır.

## 2.4.5 (04.11.2026)
- Numara düzeltme: tabloda bir satırın numarası değiştirilince aynı (eski) numaralı diğer satırlar da (aynı sekme, kaydedilmemiş) değişir; "N satır güncellendi" notu ve Geri al (hepsini eski numaraya döndürür).
- Tümünü seç (başlıktaki kutu) Rapor / Veli İzni / Faaliyet sekmelerinde görünen satırları seçer (değişiklik yok, doğrulandı).

## 2.3.47 (04.11.2026)
- DÜZELTME: 2.3.45/2.3.46 yanlışlıkla 2.3.44 tabanından yapılmıştı; 2.4.0–2.4.3'teki PDF/tarama okuyucuları (faaliyet/izinli öğrenci listesi tablo okuyucu, Liste ayır, yerel okuma, kasa) düşmüştü. 2.3.47 = 2.4.3 tabanı + 2.3.45/46 düzeltmeleri (Kaydet doğrulama, alan sıfırlanınca yeniden doldurma, Faaliyet liste eşleşmesi, tanılama günlüğü indir, bitiş özeti + e-Okul listesi sütunu). Otomatik Kaydet kullanıcı onayıyla açık.

## 2.3.46 / 2.3.45 (04.11.2026)
- Bitiş özeti (KAYDEDİLDİ/ATLANDI, öğrenci öğrenci neden, e-Okul listesi karşılaştırması); Kaydet doğrulaması ve tanılama günlüğü.

## 2.4.3 (03.11.2026)
- **Faaliyet / izinli öğrenci listesi yazısı okunuyor:** taranmış resmî yazı (üstte tarih + açıklama, altta çizgili NUMARA / SINIF / ADI-SOYADI tablosu) Veli izni taramasında kendiliğinden tanınır. Neden: tam sayfa Tesseract çizgili tablodaki küçük yazıyı okuyamıyordu ve bu biçim için okuyucu yoktu ("Form tanınamadı"). Artık tablo çizgileri piksellerden bulunur, her hücre ayrı okunur; numara iki kez okunur, farklıysa KONTROL. Tarih tablonun üstündeki yazıdan (imza tarihi alınmaz), "yarım gün" ve "05-06/11" aralığı desteklenir. Satırlar Faaliyet türünde, ad/sınıf ile gelir.
- **Liste ayır (genel, isteğe bağlı):** Veli izni taramasında "Liste ayır…" düğmesi taranan sayfanın satır/sütunlarını açar: sütun türünü seçme (Numara, Ad Soyad, Sınıf, Tarih, Gün, Açıklama…), başlık satırı (B), satır + / − / ⊕ birleştir / ✂ imleçten böl / ↑↓, sütun + / − / ⊕ / ✂, Geri al / Yinele (Ctrl+Z/Y). Her tür listede çalışır; "Aktar" yalnız o sayfanın satırlarını değiştirir. Kullanılmazsa davranış 2.4.2 ile aynı. Veri yalnız bellekte.
- **Chrome uzantı hatası giderildi:** `tesseract-core-simd-lstm.wasm.js:31 (Yg)` — Tesseract'ın "Estimating resolution as …" tanılama iletisi stderr → console.warn ile uzantı hata listesine düşüyordu (okumayı bozmaz). Tanılama çıktısı `debug_file=/dev/null` ile kapatıldı.
- Değişmeyenler: devamsızlık (2.3.44 ile bayt-aynı), Kaydet otomatik değil, Güvenlik Kodu çözülmez, izinler yalnız storage.

## 2.4.2 (03.11.2026)
- **Yerel Okuma Servisi bağlantısı (isteğe bağlı):** bu bilgisayara kurulan servis (yalnız 127.0.0.1, erişim belirteci + eşleşmiş eklenti kimliği) taranan veli izni / faaliyet formlarındaki Okul No kutularını iki el yazısı modeliyle (Qwen2-VL-2B, TrOCR-large) de okur. Numara yalnız iki model ve yerel okuyucu (ElRakam) üçü aynı değeri okursa emin sayılır (PC ölçümünde sentetik formlarda ElRakam tek başına çok iyi olduğu için servis yalnız doğrulayıcıdır); aksi hâlde satır KONTROL ("numara … — kontrol edin", iki modelin okuması yazılır). Boş kutular servise gönderilmez.
- Servis kapalı, kurulu değil, eşleşmemiş ya da hata verirse eklenti 2.4.1'deki gibi yalnız ElRakam ile çalışır (bayrak kapalıyken okuyucu çıktısı 2.4.1 ile bayt-aynı; 350 sentetik form sayfasında doğrulandı).
- Görüntüler yalnız bellekte, gri numara şeridi olarak servise gider; sonuçtan silinir, depoya/diske yazılmaz. İnternete bir şey gönderilmez; yeni izin yok.
- *Okul ayarları → Yerel Okuma Servisi*: durum (GPU/CPU), "Yerel okuma servisine bağlan", "Kullanma".
- Değişmeyenler: devamsızlık (yoklama) modülü (2.3.44 ile bayt-aynı), Kaydet akışı (otomatik kayıt yok), Güvenlik Kodu (çözülmez), T.C. kasası, izinler.

## 2.4.1 (03.11.2026)
- **T.C. kasası (KVKK):** öğrenci T.C. kimlik numaraları `chrome.storage.local`'da artık düz metin tutulmaz. Kasa parolasından PBKDF2-SHA256 (210.000 tur) ile türetilen AES-GCM 256 anahtarla şifrelenir; anahtar yalnız tarayıcı belleğinde (`chrome.storage.session`) durur, tarayıcı kapanınca kasa kilitlenir; parola hiçbir yere yazılmaz. *Okul ayarları → Gizlilik → T.C. kasası* ya da paneldeki 🔒 düğmesi: oluştur / aç / kilitle / parola değiştir / sıfırla.
- Eski sürümden kalan düz T.C.'ler kasanın ilk açılışında şifrelenir, düz hâli silinir (güncellemeden sonra kasa sayfası kendiliğinden açılır). Kasa kilitliyken T.C. görünmez ve Başlat T.C. araması yapmaz; tarama "Aktar", CSV/Excel yükleme ve elle T.C. girişi kasa açık değilse kasa sayfasını açar.
- Dışa aktarımda düz T.C. yok: tarama CSV/Excel/PDF adları, liste CSV/Excel, giriş sonucu CSV/yazdırma ve A4 listesinde T.C. maskeli (123******45). Maskeli dosya geri yüklenince T.C. mevcut listedeki satırla (maske + tarih) eşlenir; eşleşmezse satır KONTROL.
- Günlükte ve hata satırında 11 haneli numaralar maskelenir.
- Düzeltmeler: Okul ayarlarında kaydedilen tatil/arife takvimi açık e-Okul sekmelerinde sayfa yenilemeden geçerli olur; tarama sürerken dosya bırakılınca ikinci tarama açılmaz; toplu seçim arama/süzgeç değişince korunur; Ctrl+Shift+E yalnız e-Okul sekmesinde çalışır; A4 listesinde Okul No boşsa T.C. maskeli; test adı düzeltildi (31 tatil günü); dağıtım zip'inde `test/` yok.
- Değişmeyenler: devamsızlık (yoklama) modülü, e-Okul form doldurma/kaydetme akışı, rapor/veli izni/faaliyet okuyucuları.

## 2.4.0 (02.11.2026)
- **Kontrol tablosunda arama:** okul no, TC, ad soyad, tarih, süre, tür, Açıklama, uyarı, durum ve dosya adı içinde arar; birden çok kelime birlikte aranır (ör. `123 hazır`). `Esc` aramayı temizler, `Enter` hemen süzer. Yanındaki **durum süzgeci**: Tümü / HAZIR / KONTROL / OK / ATLANDI / HATA / Uyarılı (sarı). Liste yalnız süzülen satırları gösterir; sayaç "12/48 satır · 3 seçili" biçiminde.
- **Toplu işlem:** satır başına onay kutusu ve başlıkta "görünenlerin tümünü seç". Seçilenlere tek tıkla **HAZIR yap** (eksik/geçersiz alan varsa satır sarı KONTROL kalır ve nedeni Uyarı sütununa yazılır), **KONTROL yap**, **Tür değiştir** (Devamsızlık / Raporlu / Sevkli / Veli İzni / Faaliyet — satır o sekmeye geçer), **Seçilenleri sil**. Otomasyon çalışırken toplu işlemler kapalıdır.
- **A4 teslim/imza listesi:** ekranda görünen (süzgeçli) satırlar A4 sayfaya yazdırılır: sıra, Okul No / TC (TC gizlenir), Ad Soyad, Tarih, Süre, Tür, Açıklama ve imza kolonu; başlıkta okul adı, tarih, toplam satır ve toplam süre. Yazdır ya da "PDF olarak kaydet".
- **Tatil ve arife takvimi okul ayarlarından düzenlenir:** *Okul ayarları → Ardışık gün birleştirme* bölümünde iki metin kutusu (her satır `gg.aa.yyyy` ya da `gg.aa.yyyy - gg.aa.yyyy`, sağına `# açıklama`). Varsayılan 2026–2027 takvimi hazır gelir, "Varsayılana dön" ile geri yüklenir; özet satırı kaç gün tatil/arife olduğunu ve tanınmayan satırları yazar. Takvim okul profiliyle birlikte dışa/içe aktarılır. Kayıt boş bırakılırsa hiçbir gün tatil sayılmaz (onay istenir).
- **Klavye kısayolu:** e-Okul sekmesinde `Ctrl+Shift+E` paneli açar/kapatır (Chrome'da `chrome://extensions/shortcuts` üzerinden değiştirilebilir).
- **Tarama sayfasına sürükle-bırak:** PDF/fotoğraflar sayfaya bırakılınca dosya listesine eklenir (klasör yok sayılır, aynı dosya iki kez eklenmez); seçilen dosya sayısı ve adları gösterilir.
- Devamsızlık modülü, e-Okul form doldurma/kaydetme akışı, rapor/veli izni okuyucuları değişmedi.

## 2.3.44 (28.10.2026)
- Arife günleri e-Okul'da yarım gün: 28 Ekim 2026, Ramazan arifesi 8 Mart 2027, Kurban arifesi 15 Mayıs 2027. Arifeye düşen tam günlük veli izni / faaliyet satırı kendiliğinden Süre 0,5 olur (Uyarı: "ARİFE (yarım gün)"); tabloda Süre + en çok 0,5; arife yalnız birleşik kaydın son günü olur (ör. 26–28 Ekim → 26.10, Süre 2,5).
- Kontrol tablosunda Günler sütunu ve planda "arife yarım" yazar. Başka değişiklik yok.

## 2.3.43 (28.10.2026)
- Ardışık günler tek kayıt (Veli İzni ve Faaliyet): taramadan aktarınca aynı öğrencinin art arda günleri kendiliğinden birleşir — ilk tarih + toplam süre (ör. 19.10 tam + 20.10 yarım → 19.10, Süre 1,5; Pzt–Cum tam → Pzt, Süre 5).
- Kurallar: yalnız aynı hafta içinde art arda takvim günleri (Cuma + Pazartesi ayrı kayıt); 2026-2027 tatilleri (29 Ekim, 16–20 Kasım, 1 Ocak, yarıyıl, 8–12 Mart, 23 Nisan, 1 Mayıs, 15–19 Mayıs) birleşmez; yarım gün yalnız son gün olabilir; yalnız HAZIR ve tek günlük (1 / 0,5) satırlar; aynı Okul No + Tür + Nedeni + Açıklama.
- Panelde "Ardışık günler → tek kayıt" bölümü: plan (ör. "No 123 · 19.10 → 1,5 gün (19.10–20.10)"), − son günü ayırır, + ertesi günü katar, "Ardışık günleri birleştir" düğmesi (JSON/Excel/elle eklenen ya da sonradan HAZIR yapılan satırlar için).
- Faaliyet ayrı sekme: Devamsızlık · Rapor · Veli İzni · Faaliyet yan yana (aynı panel). Toplu faaliyet bölümü Faaliyet sekmesinde. Her sekme yalnız kendi satırlarını girer.
- Kontrol tablosu (her satırda): − sil / + altına satır ekle; Süre − / + (veli izni ve faaliyette 0,5 adım, en az 0,5 en çok 5; raporda 1 gün); Günler sütunu − son günü ayır / + ertesi günü kat; Tür seçici Devamsızlık / Rapor / Veli İzni / Faaliyet — seçilen türe göre satır o sekmeye KONTROL olarak geçer. Devamsızlık seçilirse satır listeden çıkar ve yoklama ekranındaki Sesli/Yazılı kutusuna yapıştırılacak metne dönüşür ("20.10.2026 123 numara yarım gün"; Metni kopyala düğmesi). Açılır pencere yok.
- Excel dönüşünde 1,5 … 4,5 süreler kabul edilir.
- Kaydet akışı (en çok 3 deneme, olmazsa sarı atla), e-Okul form doldurma, devamsızlık (yoklama) ve rapor modülleri değişmedi.

## 2.3.42 (27.10.2026)
- Sesli / yazılı devamsızlık girişi (yoklama ekranı, ayrı kutu): 🎤 Konuş (Chrome ses tanıma, tr-TR) ya da yazarak. "123 numara 3 gün", "45 ve 67 numara yarım gün", "bugün/dün/evvelsi gün", "18 kasım", "18.11", sözcükle sayılar ("yüz yirmi üç"). Çok günlü girişte hafta sonu atlanır; hafta sonu tarihi reddedilir.
- Ön izleme listesi: her satırda − / + (numara), ⇄ (Tam/Yarım), ✕ (sil). Ekrandaki şube listesinde olmayan numara KIRMIZI + "LİSTEDE YOK".
- "Forma doldur" yalnız e-Okul'da seçili tarihe ait satırları işaretler (Tam gün / Yarım gün sabah). Kaydet'e, Gönder'e ya da onaya basmaz; Güvenlik Kodu'na dokunmaz.
- Oturum açık tutma (2.3.37'den beri var, varsayılan AÇIK): Not Girişi 1.6.17 iyileştirmeleri eklendi — 2 saat işlem yoksa durur, çerçevelerdeki tuş/tıklama da sayılır, oturum düşerse yerelde işaretlenir.
- 2.3.41 değişiklikleri korundu (sol kenar araç çekmecesi, e-Okul tarihi gg/aa/yyyy). Devamsızlık otomasyonu, veli izni ve rapor modülleri değişmedi.

## 2.3.41 (26.10.2026)
- Sol alttaki araçlar (oturum açık tutma, tabloyu kopyala) sol kenarda çekmece: varsayılan kapalı, sekmeye tıkla aç/kapa, yukarı/aşağı sürüklenir (hatırlanır).
- Devamsızlık: geçmiş gün seçilince e-Okul tarih kutusuna gg/aa/yyyy yazılır.

## 2.3.39 (26.10.2026)
- Veli izin formu sürüm 5: dönemler ay ay kayar (9 form): Eylül–Ekim, Ekim–Kasım, Kasım–Aralık, Aralık–Ocak, Ocak–Şubat, Şubat–Mart, Mart–Nisan, Nisan–Mayıs, Mayıs–Haziran. Düzen, 4 kutulu Okul No ve Tam/Yarım kutuları sürüm 4 ile aynı.
- Dönem kodu 10 kutuya çıktı (sağ üstte 2 ek kare); okuyucu yeni formları kendiliğinden tanır. Daha önce basılmış sürüm 4 formları (5 dönemlik) okunmaya devam eder.
- Devamsızlık modülü değişmedi.

## 2.3.38 (23.10.2026)
- Faaliyet formu 2 çeşit (otomatik tanınır): TOPLU (ortak takvim: 2 ay, her ay 1–31 gün ızgarası, her günde geniş aralıklı T/Y kutuları; 9 öğrenci satırı) ve BİREYSEL (1 ay; 5 öğrenci, her öğrencinin kendi 1–31 gün şeridi — çok faaliyetli öğrenci için). Eski faaliyet formu (2.3.37) da okunmaya devam eder.
- El yazısı faaliyet adı okunur: 24 harf kutusu (BÜYÜK HARF, Ç Ğ I İ Ö Ş Ü dahil), tamamen yerel küçük harf modeli (lib/harf.bin) + yerel faaliyet adı sözlüğü (yaygın adlar hazır; Ayarlar'da okulun kendi adları eklenebilir; onaylanan yeni adlar bu bilgisayarda listeye eklenir).
- Tarama listesinde okunan ad Açıklama kutusunda, formdaki el yazısının görüntüsü hemen altında; düzeltme aynı formun tüm satırlarına geçer. Ad sözlükte yoksa ya da emin değilse sarı + KONTROL.
- Takvimde: geçersiz gün, hafta sonu, Temmuz/Ağustos, iki kutu birden işaretli ya da ay okunamadıysa satır KONTROL.
- Devamsızlık modülü ve veli izni okuyucusu değişmedi.

## 2.3.37 (23.10.2026)
- Faaliyet formu (yeni, yazdırılabilir A4): Faaliyet adı, 4 tarih yuvası (gün/ay rakam kutuları + Tam/Yarım), 14 öğrenci satırı (4 kutulu Okul No, Ad Soyad, Sınıf). Tarama sayfasında Veli izni türüyle okutulur, kendiliğinden tanınır; her öğrenci × her tarih bir satır olur.
- Faaliyet satırları Veli İzni listesinde: Tür = Faaliyet, Okul No ile aranır, e-Okul'da Nedeni "Faaliyet" (Ayarlar'dan değiştirilebilir), Açıklama = faaliyet adı. Kaydet en çok 3 kez, olmazsa sarı atla + özet.
- Toplu faaliyet: Veli İzni sekmesinde numara listesi + tarih + Tam/Yarım + gün sayısı (hafta sonu atlanır) ya da Excel (Okul No, isteğe bağlı Tarih / Süre / Açıklama).
- Oturum açık tutma: e-Okul açıkken 4 dakikada bir mevcut sayfa arka planda istenir (sayfa değişmez); sol alttaki düğmeyle AÇIK/KAPALI (varsayılan AÇIK); giriş ekranında çalışmaz.
- Tabloyu Excel'e kopyala: sol alttaki düğme ekranda görünen en büyük tabloyu panoya kopyalar (Excel'de Ctrl+V); yalnızca tıklayınca, yalnızca o tablo.
- Sürekli devamsızlar: yoklama ekranında sağ altta ayrı kutu; numaralar yalnız bu bilgisayarda saklanır; "Yoklamada işaretle" listedekileri Tam gün işaretler (Kaydet'e basmaz). Devamsızlık modülünün kodu değişmedi (ayrı dosya: modules/devamsizlik/surekli.js).

## 2.3.36 (23.10.2026)
- Yeni veli izin formu (sürüm 4): Okul No 4 kutu (11×16 mm, 3 mm ara); boş kutular atlanır, sağa ya da sola yaslı yazılabilir; kutu çizgisi rakam sayılmaz (hayalet hane yok). Eski formlar (sürüm 2/3) aynen okunur.
- Takvim: Tam/Yarım kutuları 4,4 mm, gün içinde ve günler arasında 3,9 mm boşluk, günler arası 1,2 mm ayrık; okuyucu kutu içini kenardan 1 mm içeriden örnekler; komşu günde (Yarım | ertesi gün Tam) taşan işaret tek kutuya verilir.
- Veli İzni / Rapor e-Okul girişi: Kaydet en çok 3 kez denenir; kayıt görülmezse satır sarı "Kaydedilemedi — elle girin", sıradakine geçilir; satır 90 sn'den uzun Kaydet aşamasında kalamaz. Sonuç özetinde kaydedilemeyenler listelenir.
- Devamsızlık modülü değişmedi.

## 2.3.35 (23.10.2026)
- Devamsızlık: "Yoklama Tarihi" satırı (− / +): Bugün, Dün, 2–5 gün önce; gerçek tarih yazılı. Geçmiş gün seçilince otomasyon her şubede Listele'den önce e-Okul'un tarih kutusuna o tarihi yazar; Veli Asistanı bildirimi de seçilen tarihle gider. Varsayılan Bugün (eski davranış aynen). Başka değişiklik yok.

## 2.3.34
- Veli İzni tarama: Tür "Veli izni formu" seçiliyken doktor raporu okutulursa satırda ve durum satırında açık uyarı ("Tür'ü Rapor yapıp yeniden okutun"); satır KONTROL kalır. Başka değişiklik yok.

## 2.3.33
- Rapor: e-Okul "Devamsızlık Kaydı Bulunamamıştır (E01-OOG02013)" tablo bilgi satırı artık uyarı sayılmıyor (boş forma Kaydet basılmıyordu).
- Rapor: "Nedeni Seçilmelidir / Süre Boş" uyarısında form 1 kez yeniden doldurulur, sonra yalnız o öğrenci HATA.
- Rapor: Hızlı Öğrenci Arama anahtarı 4 farklı yolla (sayfa jQuery dahil) çevrilir; olmazsa Özürlü Devamsızlık ekranındaki T.C.Kimlik No araması kullanılır; tür seçici yapısı günlüğe bir kez (rakamsız) yazılır.
- Rapor: ekranda başka öğrencinin TC si varsa giriş yapılmaz, atlanır.

## 2.3.31 (22.10.2026)
- Veli izni / rapor girişi: toplam çalışma süresi sınırı yoktur. Bir adım 45 sn ilerlemezse yalnızca o öğrenci "Yanıt gelmedi — atlandı" (sarı) olur, çalışma sıradakiyle sürer (önceden "Zaman aşımı" HATA).
- Hatalı ya da e-Okul'da olmayan numara: "Bulunamadı — atlandı" (sarı), sıradaki numaraya otomatik geçilir. Başlat'ta geçersiz numaralı/eksik satır artık tüm çalışmayı engellemez, o satır atlanır.
- e-Okul oturumu gerçekten kapanırsa (giriş ekranı) çalışma temizce durur, açık mesaj verir; yeniden girip Başlat'a basınca kalan öğrencilerden devam edilir.

## 2.3.30 (22.10.2026)
- Yeni veli izin formu (sürüm 3): her günün yanında Tam / Yarım kutuları. Okuyucu: Tam = 1, Yarım = 0,5; ikisi birden ya da belirsiz işaret = KONTROL. Eski formlar (süre yazılı ve el yazısı) aynen okunur.

## 2.3.29 (21.10.2026)
- Veli İzni Excel yükle: Süre 2–9 (taramadan gelen çok günlü satır) artık reddedilmiyor.
- Rapor Excel yükle: Tür yalnız Raporlu/Sevkli; başka değer (ör. İzinli) KONTROL + neden (önce sessizce Raporlu giriliyordu).
- Sayısal ayarlara − / + düğmeleri (panel ve Okul Ayarları).

## 2.3.28 (21.10.2026)
- Rapor (sağlık raporu) sekmesine Excel (.xlsx) indir/yükle: TC / Okul No, Ad Soyad, Başlangıç, Bitiş, Süre, Tür, Açıklama, Durum, Not / Neden; dosya saglik_raporu_*.xlsx. Rapor yüklemesi veli satırlarına, veli yüklemesi rapor satırlarına dokunmaz.
- Veli izni formunda Okul No kutularının altına "Rakamı kutunun içine yazın (sağa yaslı)".

## 2.3.27 (21.10.2026)
- Veli izni formu sadeleşti (el yazısı Okul No, süre kutusu, Pzt–Cum takvim).
- Veli İzni sekmesine .xlsx dışa/içe aktarma.

## 2.3.26 (21.10.2026)
- Makine okunur veli izin formu okuyucu (modules/ortak/okuma/form.js + form_duzen.js): köşe kareleri ile eğim/perspektif düzeltme, dönem kodu kareleri ile dönem tanıma, takvim kutuları, okul no kabarcık ızgarası, sınıf/şube kabarcıkları konumdan okunur; ters/yan sayfa denenir. Form değilse eski okuyucu çalışır.
- Tarama sayfasına iki betik eklendi; veli_tarama.js sayfaCoz önce bu formu dener.

## 2.3.25 (21.10.2026)
- Yeni 'Veli İzni' sekmesi (Rapor'un yanında): tarama/JSON yükleme, kendi kontrol listesi (Tür İzinli), Başlat, CSV, temizle. Rapor sekmesi yalnız sağlık raporu. Aynı motor; listeler sekmeye göre ayrı, Başlat yalnız kendi sekmesinin satırlarını girer.
- Başlat sonrası OOG00002 'okul türü yada sınıf/şube bulunmamaktadır' hatası düzeltildi: adres yazarak gitme (OOG01001) ve 'Öğrenci İşlemleri'/OGR bağlantılarına tıklama kaldırıldı. Özürlü Devamsızlık ekranı açıksa yerinde, sol Hızlı Öğrenci Arama (Okul No/TC + Ara) ile çalışır.
- Bilgilendirme sayfası algılanır: kırmızı mesajla durur ('Okul türünü seçip Özürlü Devamsızlık ekranını açın, sonra Başlat').

## 2.3.24 (21.10.2026)
- Başlat reddedilirse neden panelde kırmızı/kalın ve Günlük'te görünür (KONTROL satır sayısı dahil).
- Veli izni aktarımı kendiliğinden başlamadığını ve Başlat'a basılması gerektiğini açıkça yazar.
- Çalışırken sayfa 10 sn hazır olmazsa Günlük + sayfa üstü şerit ile bildirilir.
- Veli izni satırlarında Tür her yerde İzinli (tablo, CSV, sonuç raporu, yazdırma); sağlık raporu Raporlu kalır.
- Nedeni metinle (İzinli) seçilir, 3 denemede tutmazsa HATA; Kaydet'ten önce seçim doğrulanır.
- Tablo başlığı 'TC / Okul No'.

## v2.3.23 (20.10.2026)
- Veli izni aktarımında hata düzeltildi: satır içi yorum Açıklama ve elleKaydet alanlarını siliyordu; veli izni satırları e-Okul'da "Açıklama seçilmemiş" hatasıyla duruyordu. Artık her veli izni satırında Nedeni "İzinli", Açıklama "Veli izni".
- Rakam/tarih okuma kodu ortak modüle taşındı: modules/ortak/okuma (rakam.js, duzen.js, lib/rakam.bin). Okuma davranışı 2.3.22 ile aynı.

## v2.3.22 (20.10.2026) — veli izni okuma doğruluğu
- Rakam modeli gerçek veli izni rakamlarıyla yeniden ince ayarlandı (3 sayfa doğrulamaya ayrıldı, augmentation; MNIST %99,4).
- Komşu satıra taşan rakamlar artık kaybolmuyor (satır bandında yeniden kesme); bitişik yazılmış "30" gibi sayılar karalama sanılmıyor.
- Gün sayısı: "0,5" genişlik ve virgül izinden tanınıyor; bitişik "0,5" artık atılmıyor. Model emin olduğunda Tesseract'ın tek harfi gün sayısını değiştirmiyor.
- Tarih kuralları: hafta sonu ve tarama tarihinden (dosya adından) sonraki tarihler zayıf aday; ay rakamı bozuksa izin penceresindeki aylar denenir.
- Güven satırın kendi tarih/gün güvenidir; "kontrol edin" yalnız şüpheli satırlarda. Numara/sayfa uyarıları ayrı gösterilir (numara kutusu turuncu); e-Okul'a aktarımda bu satırlar yine KONTROL kalır.

## v2.3.21
- Veli izni taraması artık ekranı dondurmuyor: tablo bulma, eğiklik düzeltme ve el yazısı rakam modeli ayrı bir iş parçacığında (Web Worker) çalışıyor ve Tesseract'la aynı anda ilerliyor. Sayfa başına 25 sn sınırı var; aşılırsa sayfa "kontrol edin" diye işaretleniyor.
- Tarama sırasında sayfa sayacı ve İptal düğmesi gösteriliyor (pencere açılmaz); iptal, o anki sayfa bitince taramayı durduruyor.
- Rakam modeli yaklaşık 3 kat hızlandı; sonuçlar aynı.
- Düz (yatay) taranmış sayfalarda yön yanlış bulunuyordu ve tarih okunmuyordu. Yön artık önce tablo çizgileri ve yazı satırlarından bulunuyor.
- Bozuk ya da boş dosya artık bütün taramayı durdurmuyor; o dosya için bir satır ekleniyor ve diğer dosyalar okunmaya devam ediyor. Ayna görüntüsü gibi yazısı okunamayan sayfalar "kontrol edin" diye işaretleniyor.
- "Numarası" etiketi okunamasa da öğrenci no tablodan alınıp işaretleniyor. Eğik sayfalarda hücre önizlemesi doğru yeri gösteriyor. Bugünden çok uzak okunan tarihler (ör. 01/01/2027) güvenilmez sayılıyor.

## v2.3.20
- Veli izni formu: tablo artık basılı çizgilerden bulunuyor. Eğik taramalar (2°'ye kadar) önce düzeltiliyor. Tesseract "İzin Tarihi / Gün Sayısı" başlıklarını okuyamasa da tarihler okunuyor.
- El yazısı rakam modeli okulun gerçek veli izni formlarındaki rakamlarla yeniden ayarlandı (yalnız bilgisayarda, veri dışarı gitmez).
- Gün Sayısı: tarih yanındaki sayı, o tarihten başlayarak kaç gün izin alındığını gösterir (boş = 1, 0,5 = yarım gün). e-Okul'a tek satır girilir: başlangıç tarihi + Süre = gün sayısı.
- Listede Gün sütunu +/− ile değiştirilebilir (0,5, 1, 2 … 9). 5'ten fazla gün "kontrol edin" diye işaretlenir. Gün sayısı sonraki yazılı tarihle çakışırsa tarihlerle tutarlı değer alınır ve satır işaretlenir.
- Boş hücreleri kapatan eğik çizgiler tarih sanılmıyor.

## v2.3.17
- Sağlık raporu: e-Nabız "İSTİRAHAT RAPORU" dipnotundaki "bir defada en çok on gün rapor verilebilir / en çok on gün daha" yazısı artık gün sayısı sanılmıyor. 1-2 günlük raporların 10 gün okunmasının asıl nedeni buydu.
- "1 (BİR) gün istirahat" metninde rakam okunamasa da "(BİR) gün" yazısından 1 gün alınır.
- OCR'ın ay ile yıl arasındaki noktayı düşürdüğü tarihler ("15.102026") okunur.
- "Ayakta Başlama Tarihi" başlangıç tarihi olarak tanınır.

## v2.3.16
- Veli izni formu: masaüstü okuyucunun hücre düzeni eklentiye aktarıldı (duzen.js). Satırlar basılı yatay tablo çizgilerinden bulunur ve düzenli aralığa oturtulur (sütun başına 5 satır); gün/ay ayrımı formun basılı "/" konumundan yapılır; kalemin basılı nokta üstünden geçtiği yerler mürekkebe geri eklenir; çapraz iptal çizgileri ve karalanmış hücreler ayıklanır. Düzen bulunamazsa eski yol çalışır.
- Öğrenci numarası "Sınıfı/Numarası" hücresinden yerel rakam modeliyle okunur (bitişik yazılmış 2-3 rakam bölünür, yandaki hücreye taşan yazı elenir); model emin değilse Tesseract sonucu kalır ve satır kontrole düşer.
- Güven: model güveni düşük ya da ikinci aday yakınsa satır sarı/KONTROL olur; yalnızca güveni %70 ve üzeri, uyarısız satırlar HAZIR aktarılır.

## v2.3.15
- Veli izni formu: tarih hücreleri için yerel el yazısı rakam tanıyıcı eklendi (küçük CNN modeli, lib/rakam.bin; veri bilgisayardan çıkmaz). Renkli mürekkepten rakamlar ayrılır (bağlı bileşenler, tablo çizgisinin kestiği kalem izi birleştirilir, bitişik rakamlar bölünür), her rakam sınıflandırılır, gün/ay adayları okul takvimine (Eylül–Haziran, son 75 gün) ve hafta içine göre puanlanır. Model emin değilse Tesseract sonucu kullanılır.
- Boş hücreyi iptal eden eğik çizgi rakam olarak okunmaz.
- Okunan alan sütununda model ve Tesseract ham okuması birlikte gösterilir; güveni düşük satırlar sarıdır, kontrol edin.
- Öğrenci numarası okuma değişmedi (model bu alanda daha iyi sonuç vermedi).

## v2.3.14
- Rapor ve veli izni taramasında OCR'ın tek rakamın sonuna fazladan "0" (bazen "1") eklemesi düzeltildi (1→10, 2→20, 1→11).
- Rapor: gün sayısı tarih aralığıyla tutmuyorsa ve kısa yorum (ör. 10→1) tutuyorsa tarihlerle tutan değer alınır; satır sarı "kontrol edin" olur. Tarihlerle tutan gerçek 10 günlük rapor olduğu gibi kalır. "10 (BİR) GÜN" gibi yazıyla yazılan sayı rakamın önüne geçer. Yalnızca gün sayısı varsa ve 5'ten uzunsa satır kontrole düşer.
- Veli izni: diğer tarihlerden çok uzak düşen gün (ör. 10/10 yerine 1/10), kısa yorumu diğer tarihlerle ve okul günleriyle tutuyorsa düzeltilir; ham okuma Uyarı sütununda gösterilir, satır sarı olur. Hafta sonuna düşen tarih kontrole düşer. Yarım gün (y / 0,5) ve tam gün (T / işaretsiz) kuralları değişmedi.

## v2.3.13
- Otomatik Kaydet: 1. Kaydet'ten sonra e-Okul uyarısı (E01-OOG02013, "Devam etmek için Kaydet") beklenir; uyarı görününce 1 sn sonra Kaydet'e 2. kez basılır, İptal'e asla basılmaz. Uyarı 12 sn içinde çıkmazsa körlemesine basılmaz, kaydın tutup tutmadığı kontrol edilip Günlük'e yazılır. "Kaydet arası bekleme" artık sabit 1 sn.
- 1. basıştan sonra sayfa/çerçeve yenilense de durum depodan okunur; postback bitip Kaydet düğmesi yeniden görününce düğme baştan bulunur ve 2. kez basılır.
- e-Okul onay penceresi (confirm) yalnızca kaydetme sırasında (15 sn) otomatik onaylanır; silme onayları her zaman size sorulur.
- Başarı: e-Okul "kaydedildi/başarıyla" mesajı ya da satırın listede görülmesi; sonuç Günlük'e yazılır. 1. basışta kayıt listede görünürse çift kayıt olmasın diye 2. basış yapılmaz.

## v2.3.11
- Adım A: giris.aspx'te kuyruk çalışıyorsa doğrudan /OrtaOgretim/OGR/OOG01001.aspx'e gidilir (hazır-beklemeden önce); 2 denemeden sonra metinle (içeren, Türkçe duyarsız) bağlantı tıklanır. Her sayfa yüklenişinde 'Sayfa: <yol>' günlüğe yazılır.

## v2.3.10
- Adım B: Okul No/TC anahtarının durumu placeholder, görünen metin ve aria-label ile belirlenir; zaten Okul No ise tıklanmaz, TC ise en çok 2 kez çevrilip yeniden doğrulanır, belirsizse tıklanmaz.

## v2.3.9
- Kaydet: her tıklamadan önce bekleyen-kaydet durumu depoya yazılır; her turda önce e-Okul onay uyarısı (E01-OOG02013 / 'Devam etmek için Kaydet') kontrol edilir, açıksa ayarlı bekleme sonrası Kaydet'e yeniden basılır (toplam 3); uyarı açıkken arama yazılmaz.
- Başarı: uyarı yok + 'Geç' olmayan, iç tablo/form alanı içermeyen satırda tarih ve Nedeni görülmeli.

## v2.3.8
- Başlangıç akışı: A) ana sayfada 'Ortaöğretim Öğrenci İşlemleri' → B) yeni arayüz kenar çubuğu Hızlı Öğrenci Arama (Okul No anahtarı, numara, Ara) → C) öğrenci sayfasında 'Öğrenci Dosya Bilgileri' gerekirse açılır, 'Özürlü Devamsızlık' tıklanır. Sonraki öğrenciler OGRMenu1 ile.

## v2.3.7
- Bulunamayan öğrencinin bekleyen tüm satırları HATA olur, tekrar aranmaz.
- Özürlü Devamsızlık menüsü: form 4 sn içinde açılmazsa td / içteki a / üst tr ile tam fare olaylarıyla en çok 3 kez yeniden tıklanır.
- Ana sayfadan başlama: önce 'Hızlı Öğrenci Bilgisi' / 'Öğrenci Arama' bağlantısı (title veya metin).
- Kaydet: en çok 3 tık; her tık sonrası bekleme, e-Okul onay uyarısı (E01-…, 'devam … Kaydet … İptal') görünüyorsa Kaydet yeniden bulunup tekrar basılır; uyarı yok + kayıt listede = başarı.

## v2.3.6
- Ana sayfadan başlama: Öğrenci İşlemleri (OGRMenu1 hızlı arama) bağlantısı href/metinle (OGR, Öğrenci İşlemleri, Ogrenci) tüm çerçevelerde aranır; denemeler 3 sn arayla; ilk 30 bağlantı Günlük'e bir kez yazılır.
- Bulunamayan öğrenci: 'Öğrenci bulunamadı: NO' ile HATA, sıradaki satıra geçilir.

## v2.3.5
- İki Kaydet tıklaması arasında bekleme (varsayılan 5 sn, Ayarlar: 'Kaydet arası bekleme (sn)').

## v2.3.4
- Tarama sayfası: Tür seçimi (Rapor / Veli izni formu). Veli izni modu sayfa başına öğrenci, Sınıfı/Numarası ve İzin Tarihi tablosunu okur (yalnız renkli mürekkep, tablo çizgileriyle satır bulma); her tarih bir satır; okunan alanın görüntüsü satırda gösterilir; Tam/Yarım seçimi, −/+ ve Kontrol listesine aktar.
- Okul ayarları: Açıklama listesi +/− ile düzenlenir. Veli izni Nedeni/Açıklama okul profiline dahil.
- Veli izni satırları da otomatik kaydedilir (Kaydet'e 2 tık; Otomatik kaydet ayarına uyar).
- Ana sayfadan başlama: menüler alt çerçevelerde (iframe/frame) de aranır, üst menü grupları (Öğrenci İşlemleri, Devamsızlık…) sırayla açılır, ilk 30 menü adayı Günlük'e yazılır; 8 deneme.

## v2.3.3
- Veli izni: Nedeni varsayılan "İzinli", Açıklama "Veli izni" (Ayarlar'dan değiştirilebilir); seçenek eşleşmesi Türkçe/harf duyarsız.
- Gezinme: Özürlü Devamsızlık menüsü Türkçe duyarsız/içeren metinle bulunur; bulunamazsa günlükte ne beklendiği yazılır, elle açılınca otomatik devam eder.

## v2.3.2
- Panel: sol ve sağ kenarda turuncu tutamaklarla sağa sola çekerek genişlik ayarı (300px – ekran genişliği); başlıkta ◀ ▶ ile sola/sağa yaslama. Genişlik ve taraf hatırlanır.

## v2.3.1
- Panel: varsayılan 420px sağa yaslı, en fazla ekranın %80'i yükseklik (içerik kayar); − ile başlığa küçülür/büyür (çift tık da); ⟲ konum/boyut sıfırlama; × balona döner. Taşı/boyutlandır ve küçük durumu hatırlanır. Başka değişiklik yok.

# Sürüm Geçmişi — e-Okul Asistanı Pro (Eyüp Şeker)

## 2.3.0 — 2026-10-16
- Veli izni JSON: yarım gün desteği (`yarim_gun`/`gun_turu: "YARIM"`/`sure: 0.5`). Süre alanına "0,5" yazılır, panelde ve afişte YARIM GÜN uyarısı. Veli izni satırları yine Kaydet'e elle basılarak kaydedilir.
- Süre alanı Türkçe ondalıkla (virgül) yazılır.

## 2.0.0 — 2026-10-14
- Rapor ve Devamsızlık eklentileri tek pakette birleştirildi; modüler yapı (`core/`, `modules/`).
- Tek başlatıcı, modül sekmeleri, simge seti, Hakkında sekmesi.
- Okul ayarları sayfası: şube listesi editörü (+/−/↑/↓, varsayılan, boşalt, .txt içe/dışa), okul profili JSON içe/dışa aktarma.
- Ortak kilit: aynı anda tek otomasyon.
- KVKK: ilk kullanım onayı, TC maskeleme, başarılı girişten sonra otomatik silme, kapanışta silme, Tüm verileri sil; KVKK.md ve şablonlar.
- Devamsızlık modülü davranışı özgünle aynı (yalnızca şube listesi kaynağı, kilit ve panel açma değişti).

## Rapor modülü (öncesi)
- 1.6.0 Sevk desteği (Tür: Raporlu/Sevkli, sevk süresi).
- 1.5.0 Açıklama için sabit kurum listesi + bulanık sınıflama.
- 1.4.0 İnsan hızında doldurma (3–4 sn), harf harf yazma, otomatik çift Kaydet.
- 1.3.0 Güvenli mod, form tanılama, bağlam kopması koruması.
- 1.2.0 Postback bekleme, hata_yakala algılama.
- 1.1.0 Gerçek e-Okul ekranlarına uyarlama, günlük.
- 1.0.0 Yerel OCR (tesseract.js), TC'ye göre ayırma, CSV/Excel/PDF.

## 2.1.3
- Rapor listesi (tarama ve panel): Evrak Asistanı tarzı koyu kart, 22px yeşil + (elle ekle) / koyu kırmızı − (çıkar); alanlar satır içinde düzenlenir, yalnızca listede kalan HAZIR satırlar e-Okul'a girilir.
- Tarama dayanıklılığı: sayfa başına zaman aşımı + yeniden deneme, bozuk/okunamayan sayfa işaretlenip partiye devam, kontrast germe, düşük güvende 90/180/270 döndürerek OCR, "15 Ekim 2026" / 15/10/26 tarihleri, tekrar (aynı TC+tarih) uyarısı, satır başına güven yüzdesi.
- Kaydet: sayfa hazır (UpdatePanel/PrimeFaces/jQuery AJAX/overlay yok) beklenir, 1. tık, ~1 sn, hazır bekle, 2. tık, listede kayıt doğrulanır.
- Yanlış TC ile ana sayfaya düşülürse satır "TC hatalı/bulunamadı" işaretlenir, menüden Özürlü Devamsızlık ekranına dönülür (en çok 5 deneme), sıradakine geçilir. Çalışma ana sayfadan da başlatılabilir.
- Çalışma sonunda sonuç raporu (özet + satırlar), CSV (UTF-8 BOM) ve yazdır/PDF; bir sonraki başlatmaya kadar saklanır.
