# KVKK Bilgilendirmesi — Okul Pro Devamsızlık Rapor Asistanı
*Geliştiren: Eyüp Şeker · Bu belge bilgilendirme amaçlıdır, hukuki görüş değildir.*

## 1. Veriler nerede işlenir?
- **Tamamen yerel:** Tüm işlemler kullanıcının bilgisayarındaki tarayıcıda yapılır. OCR (tesseract.js), PDF işleme (pdf.js, pdf-lib) eklentinin içindedir.
- **Öğrenci verisi dışarı çıkmaz:** Eklenti öğrenci, rapor, not veya devamsızlık verisini hiçbir sunucuya, buluta, yapay zekâ servisine veya geliştiriciye göndermez; telemetri ve istatistik yoktur.
- **Lisans doğrulaması (v2.6.0):** Lisans doğrulaması: eklenti ilk açılışta kurum kodu, lisans sözleşmesi ve KVKK onayı ister; 48 saatlik deneme veya lisans anahtarı api.otonomevrak.com üzerinden doğrulanır. Bu doğrulamada yalnızca lisans anahtarı, kurum kodu, rastgele kurulum kimliği, ürün kodu ve sürüm gönderilir; öğrenci, rapor, not veya devamsızlık verisi asla gönderilmez. İmzalı lisans jetonu 7 gün çevrimdışı çalışır.
- Manifest izinleri: `storage`, `downloads`, `alarms`, `scripting` (içerik betiklerini lisans geçerliyken kaydetmek için); alan adları: e-Okul ve api.otonomevrak.com (yalnız lisans).

## 2. Hangi veriler işlenir?
| Veri | Kaynak | Niteliği |
|---|---|---|
| T.C. kimlik no, ad soyad | taranan rapor | kişisel veri |
| Rapor/sevk tarihi, gün sayısı, raporu veren kurum, Raporlu/Sevkli | taranan rapor | **sağlık verisi = özel nitelikli kişisel veri (KVKK md. 6)** |
| Rapor görüntüleri | tarayıcı/PDF | özel nitelikli (sağlık) |
| Şube adları, ders yoklama işaretleri | e-Okul sayfası | kişisel veri (devamsızlık) |

### Öğrenci listesi (isteğe bağlı, v2.5.0)
Veli İzni okul numarasını doğrulamak için isterseniz okulun öğrenci listesini yükleyebilirsiniz. Listeden **yalnızca Okul No, Ad Soyad ve Sınıf** alınır; T.C. kimlik no ve diğer sütunlar okunmaz/saklanmaz. Liste yalnız bu tarayıcının yerel depolamasında (`chrome.storage.local`) durur, hiçbir sunucuya gönderilmez ve *Listeyi sil* düğmesiyle silinir. "Adları kaydet" kapatılırsa yalnız baş harfler (ör. A.Ş.) saklanır. Listeyi yüklemek ve kullanmak okulun/müdürün sorumluluğundadır; kullanım taahhütnamesine eklemeniz önerilir.

### Rapor T.C. eşleme listesi (isteğe bağlı, v2.5.3)
Sağlık raporu taramasından inen CSV'de T.C. maskelidir. Maskeli değeri çözmek için Rapor sekmesinde ayrı, isteğe bağlı bir **öğrenci listesi (T.C. eşleme)** yükleyebilirsiniz. Bu listeden T.C. kimlik no, ad soyad ve varsa okul no alınır; yalnız bu tarayıcının yerel depolamasında (`chrome.storage.local`, `raporOgrTcListe`) durur, hiçbir sunucuya, buluta veya yapay zekâ servisine gönderilmez ve *Eşleme listesini sil* ile kaldırılır. Yüklemek zorunlu değildir; liste yoksa maskeli satırlar KONTROL kalır, T.C. elle yazılır. Veli İzni listesi bu depodan ayrıdır ve T.C. saklamaz.


### OYSS not listesi (v2.5.4)
OYSS sekmesi, e-Okul sayfasındaki Okul No / ad soyad ve sizin yüklediğiniz Excel'deki puanları **yalnız bu bilgisayarda** işler. Dosya okunur veya indirilir; `chrome.storage`'a öğrenci listesi yazılmaz, sunucuya, buluta veya yapay zekâya gönderilmez. İndirdiğiniz Excel'in saklanması ve imhası okulun sorumluluğundadır.

## 3. Nerede, ne kadar saklanır?
| Veri | Yer | Süre |
|---|---|---|
| Rapor görüntüleri, OCR metni | tarama sekmesinin belleği | Sekme kapanınca silinir; diske yazılmaz (kullanıcı CSV/PDF indirmedikçe) |
| Kontrol listesi (TC, tarih, süre, açıklama) | `chrome.storage.local` (bu bilgisayar, bu Chrome profili) | e-Okul'a **başarıyla girilen satır otomatik silinir** (yalnızca maskeli TC + tarih özeti kalır; ayar, varsayılan açık). Diğerleri kullanıcı silene kadar. |
| İşlem günlüğü | `chrome.storage.local` | Son 60 satır; **TC'ler maskeli** (123******01) |
| Okul profili, ayarlar | `chrome.storage.local` | Kullanıcı silene kadar (kişisel veri içermez) |
| Şube listesi kopyası, yoklama durumu | e-Okul sayfasının localStorage/sessionStorage'ı | Özgün devamsızlık eklentisiyle aynı |

**Silme seçenekleri (Okul ayarları → Gizlilik):** başarılı girişten sonra otomatik silme · tarayıcı kapanıp açılınca rapor listesi ve günlüğü silme · **Tüm verileri sil** (tüm eklenti deposu). Eklentiyi kaldırmak da tüm eklenti deposunu siler.

**Dikkat:** Kullanıcının indirdiği CSV/Excel/PDF dosyaları ve taranan PDF'ler bilgisayarda kalır; bunların saklanması ve imhası okulun sorumluluğundadır.

## 4. Kullanım koşulları (öneri)
- Yalnızca e-Okul'a veri girmekle görevli personel, kurum bilgisayarında kullanmalıdır.
- İlk açılışta KVKK bilgilendirmesi onaylanmadan otomasyonlar çalışmaz.
- **Yerel Okuma Servisi (v2.4.2, isteğe bağlı):** açıksa taranan formlardaki Okul No kutularının gri görüntüsü yalnız bu bilgisayardaki servise (127.0.0.1) gönderilir; internete çıkmaz, diske/depoya yazılmaz. Servis kapalıysa hiçbir görüntü gönderilmez.
- **T.C. kasası (v2.4.1):** T.C. kimlik numaraları depoda yalnız şifreli (AES-GCM 256, PBKDF2-SHA256 210.000 tur) saklanır; anahtar yalnız tarayıcı belleğinde, parola kaydedilmez. Dışa aktarımlarda T.C. maskelidir.
- Günlük paylaşılırken (destek için) yalnızca maskeli günlük gönderilmelidir; rapor görüntüsü paylaşılmamalıdır.

## 5. Şablonlar (`docs/sablonlar/`)
> **ÖNEMLİ:** Aşağıdakiler **şablondur**, hukuki görüş değildir. Okulunuzun KVKK irtibat kişisi / hukuk birimi tarafından gözden geçirilip kurumunuza uyarlanmalıdır.

- `aydinlatma_metni_veli.md` — Velilere yönelik aydınlatma metni örneği
- `veri_isleme_envanteri_ornek.md` — VERBİS / envanter satırı örneği
- `kullanim_taahhutnamesi.md` — Personel kullanım taahhütnamesi örneği
