# Okul Pro Devamsızlık Rapor Asistanı — Kullanım Kılavuzu
*Geliştiren: Eyüp Şeker*

## 1. Başlatıcı
e-Okul sayfalarında sol altta mavi pano simgesi vardır. Tıklayınca taşınabilir/boyutlanabilir panel açılır; üstte sekmeler bulunur:
**⏱ Devamsızlık · 📄 Rapor · 📝 Veli İzni · 🏅 Faaliyet · 📋 OYSS · ✏ Ders Notu · 🏫 Okul ayarları · ℹ Hakkında**. Sarı KVKK şeridi görünüyorsa önce bilgilendirmeyi onaylayın. `Ctrl+Shift+E` de paneli açıp kapatır.

> **Aynı anda tek otomasyon:** Rapor girişi çalışırken yoklama başlatılamaz (ve tersi); panel bunu yazar.

## 2. Okul ayarları (ilk kurulumda bir kez)
Başlatıcı → *Okul ayarları* → **Okul ayarlarını aç**.
- **Şube listesi:** `+ Şube ekle`, satır sonundaki **+** (altına ekle), **−** (sil), **↑ ↓** (sırala), *Varsayılana dön*, *Listeyi boşalt*, *Dışa/İçe aktar (.txt)*. Şube adını e-Okul açılır listesindeki gibi (veya bir parçasını) yazın.
- **Rapor Açıklama listesi:** her satır `Ad | anahtar1, anahtar2` (ör. `Devlet Hastanesi | devlet hastanesi`).
- **Zamanlama ve sevk:** adımlar arası bekleme (varsayılan 3000–4000 ms), sevk süresi (varsayılan 1 gün).
- **Ardışık gün birleştirme – Tatil ve arife takvimi:** her satır `gg.aa.yyyy` ya da `gg.aa.yyyy - gg.aa.yyyy`; sağına `# açıklama` yazabilirsiniz. 2026–2027 takvimi hazır gelir; yeni eğitim yılında yalnız bu listeyi güncelleyin (*Varsayılana dön* eski listeyi geri getirir). Arife günleri ayrı kutudadır: o güne düşen tam günlük satır kendiliğinden **0,5** olur.
- **Gizlilik (KVKK):** başarılı girişten sonra otomatik silme (önerilir, açık), tarayıcı kapanınca silme, **Tüm verileri sil**.
- **Kaydet**'e basın. **Okul profilini dışa aktar** ile yedek alın (takvim de profile dahildir).

## 3. Kontrol tablosu (Rapor · Veli İzni · Faaliyet)
1. Tablonun üstündeki **arama** kutusuna okul no, TC, ad, tarih, açıklama ya da durum yazın (`123 hazır`, `20.10 kontrol` gibi birlikte aranabilir). `Esc` temizler, `Enter` hemen süzer.
2. **Durum süzgeci** ile yalnız HAZIR / KONTROL / OK / ATLANDI / HATA / uyarılı (sarı) satırları gösterin.
3. **Toplu işlem:** satır başındaki onay kutularını (ya da başlıktaki kutuyu = görünenlerin tümü) işaretleyin; sonra **HAZIR yap**, **KONTROL yap**, **Tür değiştir** (satır seçilen sekmeye geçer) veya **Seçilenleri sil**. Eksik alanı olan satır HAZIR olmaz, sarı kalır ve nedeni Uyarı sütununa yazılır.
4. **A4 listesi yazdır:** ekranda görünen (süzgeçli) satırları okul adı, tarih, toplam süre ve imza kolonuyla A4 sayfaya basar; TC'ler gizlenir. "PDF olarak kaydet" ile arşivleyin.

## 4. Rapor modülü
1. Raporları tarayıcıda **tek PDF** olarak tarayın (her raporun ilk sayfasında öğrencinin TC'si görünmeli; TC'siz ek sayfalar öncekine eklenir).
2. Rapor sekmesi → **Tarama sayfasını aç** → dosyaları **sürükleyip bırakın** (ya da *dosya seçin*) → **Tara ve ayır**. Birden çok PDF/fotoğraf bırakılabilir; aynı dosya iki kez eklenmez.
3. Tabloyu önizlemelerle karşılaştırın. Sarı satırları düzeltin: TC, tarihler, **Tür** (Raporlu/Sevkli), **Açıklama** (listeden seçin; boşsa satır işlenmez).
4. İsterseniz CSV / Excel / öğrenci başına PDF indirin. **Kontrol listesine aktar**.
5. e-Okul'da bir öğrencinin **Özürlü Devamsızlık** ekranını açın; Rapor sekmesinde listeye son kez bakın → **Başlat**.
6. Eklenti her öğrenci için: TC ile arar → Nedeni (Raporlu/Sevkli) → tarih → süre → açıklama (harf harf, adımlar arası 3–4 sn) → Kaydet'e iki kez basar → kaydın listede görünmesini bekler → sıradakine geçer.
7. Hata olursa panelde kırmızı *Son hata* ve **Günlük** görünür (*Kopyala* ile gönderin; TC'ler maskelidir). e-Okul hata sayfasına (`hata_yakala.htm`) düşülürse otomasyon kendiliğinden durur.

Ayarlar (Rapor sekmesi içinde): Raporlu için Nedeni metni, süre hesabı (belge/iş günü/takvim), otomatik kaydet, güvenli mod (yalnızca Nedeni+Süre doldurur, kaydetmez), e-Okul ekran metinleri.

## 5. Veli İzni ve Faaliyet modülleri
1. **Veli İzni** sekmesi → *Tarama sayfasını aç* → Tür: **Veli izni formu** → formları bırakıp **Tara ve ayır**. Her tarih bir satır olur (Tam = 1, Yarım = 0,5); sarı satırları düzeltip **Kontrol listesine aktar**.    **Öğrenci listesi (isteğe bağlı, önerilir):** Tarama sayfasında Veli İzni bölümünün üstündeki *Öğrenci listesi* alanına okulun listesini yükleyin (Excel/CSV ya da e-Okul'dan kopyalayıp yapıştırın; ilk satırda *Okul No*, *Adı Soyadı*, *Sınıf* başlıkları olsun). Bundan sonra her satırın okul numarası listeyle denetlenir: listedeyse öğrencinin adı ve sınıfı yeşil görünür; yoksa satır kırmızı olur ve en yakın numaralar düğme olarak önerilir. Okuyucunun emin olmadığı belirgin hatalar turuncu işaretle kendiliğinden düzeltilir (*↶* ya da *Hepsini geri al* ile geri alınır). Listede olmayan numara varken aktarma onay ister. Liste yalnız bu bilgisayarda saklanır; *Listeyi sil* ile kaldırılır.
   **Yanlış okunan okul numarasını** bir satırda düzeltince aynı (yanlış) numaralı diğer satırlar da kendiliğinden değişir; etkilenen satırlar yeşil çerçeveli olur ve tablonun üstündeki **Geri al** ile hepsi eski numaraya döner.
2. **Ardışık günler → tek kayıt:** aynı öğrencinin aynı hafta içindeki art arda günleri tek e-Okul kaydında birleşir (ilk tarih + toplam süre). Hafta sonu ve tatil birleştirilmez, yarım gün yalnız son gün olabilir. Plan bölümünde **−** son günü ayırır, **+** ertesi günü katar; *Ardışık günleri birleştir* elle eklenen/Excel'den gelen satırları da birleştirir.
3. **Faaliyet** sekmesi: formu taratın ya da **Toplu faaliyet** bölümünde numaraları (boşluk/virgül/satır), tarihi, süreyi ve faaliyet adını yazıp listeye ekleyin; Excel (.xlsx) de yüklenebilir.
4. **Boş form indir (v2.5.8, v2.5.9):** Veli İzni ya da Faaliyet sekmesinde **Boş form indir (PDF)** → ay, yıl ve form türünü seçin (veli izin dilekçesi, faaliyet toplu / bireysel, devamsızlık takip, tam/yarım gün veli izni — beşi de tek ay, her ders yılı) → **PDF indir** ya da **Bu ayın tüm formları**. PDF bu bilgisayarda üretilir, internet gerekmez. Başlıkta Okul ayarlarındaki okul adı; kaymakamlık ve kurum kodunu bu sayfada yazabilirsiniz, boş kalanlar noktalı kalır. Tatil/arife günleri Okul ayarlarındaki takvimden gelir. Doldurulan formlar tarama sayfasında (Tür: Veli izni formu) kendiliğinden tanınır; devamsızlık takip formu satırları e-Okul'a girilmez, "Devamsızlık'a ayrılan satırlar" metnine eklenir. v2.5.9'dan itibaren formda ders yılı da kodludur (alt sağ ve üst sol küçük kareler); başka yılın formu da doğru tarihle okunur. 2.5.8 ile indirilmiş formlarda yıl kodu yoktur; onları indirdiğiniz bilgisayarda okutun (yıl indirme kaydından okunur). Okul takvimi (tatil günleri) farklıysa bireysel/devamsızlık formlarını aynı bilgisayardan indirip okutun. Eski 2 aylık tam/yarım formlar okunmaya devam eder. Yazdırırken ölçek %100 olmalı, köşe karelerini ve üst/alt kod karelerini kapatmayın.
5. e-Okul'da **Özürlü Devamsızlık** ekranını açıp ilgili sekmede **Başlat**'a basın. Kaydet en çok 3 kez denenir; kaydolmayan satır sarı "Kaydedilemedi — elle girin" olur ve sonuç raporunda listelenir.

## 6. Devamsızlık modülü
1. Başlatıcı → *Devamsızlık* → **Yoklama panelini aç / kapat** (panel sağ kenarda açılır).
2. **Günlük Ders Saati**'ni girin → **Otomasyonu Başlat**. Eklenti devamsızlık giriş sayfasına gider, şubeleri sırayla seçer, listeler, işaretler ve kaydeder.
3. İşaretleme kuralı (v2.4.8): günde **yalnız 1 ders** kaçırılmışsa hangi ders olursa olsun *Geç*; **2 ve üzeri ders** kaçırılmışsa yarım gün: eksik ders sayısı günün yarısından fazlaysa *Tam gün*; hepsi ilk yarıdaysa *Sabah*; hepsi ikinci yarıdaysa *Öğle*; iki yarıya dağılmışsa *Sabah*.
4. **İşlemi Durdur** ile istediğiniz an durdurun.


## 8. OYSS Soru Bazlı Not Girişi (v2.5.7)
1. e-Okul'da **Kurum işlemleri → Not İşlemleri → OYSS Not Girişi** sayfasını açın; dersi ve sınavı seçin (**Sınavları Getir**).
2. Başlatıcı → **OYSS** (bu sekme ders notu girişinden ayrıdır). **Şube listesi** sayfadan okunur (varsayılan: tümü işaretli). Ders: sayfadaki seçili ders veya **Tüm dersler**. **Excel'e aktar (seçilen şubeler)** her şube için Sınavları Getir → OYSS Yazılı Sınav (Asıl) → Öğrenci Listesi Yükle yapar. **Excel'e aktar (bu şube)** yalnız açık tabloyu indirir. Çıktı: zip veya tek kitap. **Şube sınav durumu** ve **Kapat** düğmesine dokunulmaz.
3. Excel'de puanları yazın. **Katılım** kendiliğinden dolar (puan varsa Sınava Girdi, yoksa Sınava Girmedi); gerekirse Kopya/Muaf seçin.
4. Doldurulmuş dosyaları (tek, birden çok, zip veya kitap) **Excel yükle** ile geri getirin. İlgili şubeyi e-Okul'da açıp **e-Okul'a yaz ve Kaydet**: Okul No ile eşler, kutuları doldurur, kapılar geçilirse Kaydet'e basar (onaylı istisna). Güvenlik Kodunu siz girersiniz; eklenti o alana dokunmaz.
5. Eşleşmeyen Okul No, puan aşımı, soru sayısı uyuşmazlığı veya *Sınava Girdi* iken eksik puan varsa Kaydet'e basılmaz ve panelde rapor görünür. Puansız satır *Sınava Girmedi* olur, hata değildir.
6. **Tüm şubeleri çek** şube listesini bulamazsa **Tanı raporu**na basın (öğrenci verisi kopyalanmaz) ve metni iletin.

Hız kutusu Rapor sekmesindeki ile aynı ayarı kullanır.


## 9. Ders Notu Girişi (v2.7.3, Not Girişi 1.9.24)

**2.7.3 yenilikleri:** **Excel indir** sayfada Program/Sınıfı-Şubesi/Ders/sütunu kendisi seçer, Listele'ye basar, listeyi ve Y/D/K alanlarını okuyup Excel'i indirir. Şubeler tam adıyla ("AMP 9-A · METAL TEKNOLOJİSİ ALANI", "(alansız)"); aynı 9-A birden çok alandaysa "Şu anki hedef" altındaki listeden tam şubeyi seçin. Seviye işaretlenince şubeler sayfadan okunur; okulda olmayan seviyeler soluk. **⏹ Dur / ▶ Devam / Bırak** her uzun işte. Kaydet ve Güvenlik Kodu yine sizde.


**2.7.2 yenilikleri:** Program → Sınıf → (Alan) → Şube → Ders kutucukları (sayfadan); "Seçili sınıfların listelerini öğren" yalnız işaretlileri gezer. "Şu anki hedef" yanında **Excel indir**. Detaylı derslerde (Y/D/K, yabancı dil alanları) Excel'de her alan ayrı sütun, sesle "12 55 60 70". Ort. e-Okul'undur; Muaf öğrenci atlanır. Güvenlik Kodu ve Kaydet sizde.
1. e-Okul'da **Ders Notu Girişi** (OOK07003) sayfasını açın; panel sağ kenarda görünür. Başka sayfadayken Okul Pro panelinde **✏ Ders Notu → Ders notu panelini aç** veya **Alt+G**.
2. Sınıf listelerini öğrenin, sınıf/şube/ders kutucuklarını işaretleyin (okulun e-Okul'daki gerçek dersleri listelenir), **Not şablonunu indir (Excel)** ile tek adımda şablonu alın.
3. Excel'i doldurup **Excel'den not girişi** sayfasında açın, önizleyin, **Çalıştır**: notlar sınıf sınıf yazılır. Ya da **🎤 Sesli not** ile Türkçe söyleyin; önizlemeden kontrol edin.
4. Her sınıfta Güvenlik Kodunu siz yazar, **Kaydet**'e siz basarsınız. Eklenti Kaydet'e basmaz, Güvenlik Koduna dokunmaz.
## 7. Sorun giderme
- OYSS tablosu bulunamadı: Öğrenci Listesi Yükle'ye basıldı mı? Sayfayı F5 ile yenileyip şube/ders/sınavı yeniden seçin.
- OYSS "Şube listesi bulunamadı": OOK10020 (OYSS Not Girişi) sayfasında olduğunuzdan emin olun; **Tanı raporu**nu panoya kopyalayıp iletin.
- Panel/balon görünmüyor: adres `e-okul.meb.gov.tr` mi? Eklentiyi güncellediyseniz sayfayı **F5** ile yenileyin. `Ctrl+Shift+E` kısayolu `chrome://extensions/shortcuts` sayfasından değiştirilebilir.
- "Eklenti güncellendi, sayfayı yenileyin": F5.
- Bir form alanı bulunamıyor: Rapor sekmesi → Ayarlar → *e-Okul ekran metinleri*ni gerçek ekrandaki yazıya göre düzeltin.
- Toplu işlem düğmeleri basılamıyor: otomasyon çalışıyor olabilir (önce **Durdur**), ya da hiç satır seçilmemiş. Seçim, liste değiştiğinde (kayıt/düzenleme) sıfırlanır.
- A4 yazdırma penceresi açılmıyor: tarayıcının bu sayfa için açılır pencere iznini kontrol edin.

### Hız ve toplu HAZIR (v2.5.1)
- **Çalışma hızı:** Panelde *Başlat*'ın yanındaki **Hız** kutusu: *Normal* (yavaş, en temkinli), *Hızlı* (önerilen), *Çok hızlı*. Giriş çalışırken de değiştirebilirsiniz. e-Okul'da hata/uyarı sayısı artarsa Normal'e dönün.
- **Hepsini HAZIR yap:** Kontrol listesinde satırları kontrol ettikten sonra araç çubuğundaki **✔ Hepsini HAZIR yap** düğmesine basın: görünen satırlardan OK olmayanların hepsi HAZIR olur (eksik alanlı satır KONTROL kalır, sarı). Yalnız bazılarını yapmak için önce *Durum* süzgecini (ör. yalnız KONTROL) seçin.

### Maskeli T.C. ve öğrenci listesi (v2.5.3)
Tarama sayfasından indirdiğiniz `raporlar.csv` / Excel'de T.C. KVKK gereği maskelidir (`149******52`). Kontrol listesine yüklerken bu değer silinmez. Rapor sekmesinde **Öğrenci listesi (T.C. eşleme)** ile e-Okul sınıf/okul listesini (ilk satırda *T.C. Kimlik No* veya *TC*, ayrıca Ad Soyad / Okul No) yükleyin; maskeli T.C. ilk 3 ve son 2 haneyle eşlenir, ad varsa karışıklığı çözer. Tek eşleşme olursa gerçek T.C. ve ad doldurulur. Eşleşme yoksa veya birden fazlaysa satır KONTROL kalır ve Durum/Uyarı'da neden yazılır. Liste yalnız bu bilgisayarda kalır; *Eşleme listesini sil* ile kaldırılır. Yapay zekâya hiçbir şey gönderilmez.

**Hepsini HAZIR yap** kaç satırın HAZIR olduğunu ve kalanların neden KONTROL kaldığını bildirir. Öğrenci listesini CSV'den sonra yüklediyseniz bu düğmeye yeniden basın.

### Panelleri sağ kenara gizleme (v2.5.2)
- Yoklama ekranındaki **Devamsızlık Otomasyonu**, **Sesli / yazılı devamsızlık** ve **Sürekli devamsızlar** panellerinin başlığındaki **▶** düğmesi paneli sağ kenara gizler. Kenarda eklenti simgeli küçük sekme kalır; tıklayınca panel açılır.
- Sekmeyi (veya açık panelin başlığını) fareyle yukarı/aşağı sürükleyerek konumunu değiştirin. Konum ve gizli hali sayfa yenilenince hatırlanır. Sekme e-Okul düğmesinin üstüne gelirse yukarı/aşağı kaydırın.
- Sol alttaki mavi başlatıcı balonu eskisi gibi çalışır (taşıma, sağa/sola yaslama, kapatınca balona dönüş).

