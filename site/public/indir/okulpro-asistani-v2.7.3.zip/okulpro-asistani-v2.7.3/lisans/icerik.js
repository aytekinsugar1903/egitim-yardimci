/* manifest içerik betikleri — yalnız lisans/deneme geçerliyken kaydedilir */
self.EA_ICERIK = [
  {
    "id": "ea-ic-1",
    "matches": [
      "https://e-okul.meb.gov.tr/*",
      "https://*.e-okul.meb.gov.tr/*",
      "https://eokul.meb.gov.tr/*"
    ],
    "js": [
      "modules/rapor/ana_dunya.js"
    ],
    "persistAcrossSessions": true,
    "allFrames": true,
    "runAt": "document_start",
    "world": "MAIN"
  },
  {
    "id": "ea-ic-2",
    "matches": [
      "https://e-okul.meb.gov.tr/*",
      "https://*.e-okul.meb.gov.tr/*",
      "https://eokul.meb.gov.tr/*"
    ],
    "js": [
      "core/kasa.js",
      "modules/rapor/yardim.js",
      "modules/rapor/eokul.js"
    ],
    "persistAcrossSessions": true,
    "allFrames": true,
    "runAt": "document_idle"
  },
  {
    "id": "ea-ic-3",
    "matches": [
      "https://e-okul.meb.gov.tr/*"
    ],
    "js": [
      "core/profil.js",
      "modules/devamsizlik/kopru.js"
    ],
    "persistAcrossSessions": true,
    "runAt": "document_start"
  },
  {
    "id": "ea-ic-4",
    "matches": [
      "*://e-okul.meb.gov.tr/*"
    ],
    "js": [
      "modules/devamsizlik/content.js"
    ],
    "persistAcrossSessions": true,
    "runAt": "document_end",
    "world": "MAIN"
  },
  {
    "id": "ea-ic-5",
    "matches": [
      "https://e-okul.meb.gov.tr/*",
      "https://*.e-okul.meb.gov.tr/*",
      "https://eokul.meb.gov.tr/*"
    ],
    "js": [
      "core/kasa.js",
      "core/moduller.js",
      "core/profil.js",
      "modules/rapor/yardim.js",
      "modules/ortak/xlsx.js",
      "modules/rapor/tablo_sutun.js",
      "modules/rapor/birlestir.js",
      "modules/rapor/panel.js",
      "modules/rapor/kayit.js",
      "modules/veli/kayit.js",
      "modules/faaliyet/kayit.js",
      "modules/devamsizlik/kayit.js",
      "modules/oyss/oyss.js",
      "modules/oyss/bagla.js",
      "modules/oyss/ses.js",
      "ses/hap.js",
      "modules/oyss/kayit.js",
      "modules/dersnotu/kayit.js",
      "core/launcher.js"
    ],
    "persistAcrossSessions": true,
    "runAt": "document_idle"
  },
  {
    "id": "ea-ic-6",
    "matches": [
      "https://e-okul.meb.gov.tr/*",
      "https://*.e-okul.meb.gov.tr/*",
      "https://eokul.meb.gov.tr/*"
    ],
    "js": [
      "modules/ortak/araclar.js"
    ],
    "persistAcrossSessions": true,
    "allFrames": true,
    "runAt": "document_idle"
  },
  {
    "id": "ea-ic-7",
    "matches": [
      "https://e-okul.meb.gov.tr/*"
    ],
    "js": [
      "modules/devamsizlik/surekli.js",
      "modules/devamsizlik/sesli_ayrac.js",
      "modules/devamsizlik/sesli.js"
    ],
    "persistAcrossSessions": true,
    "runAt": "document_idle"
  },
  {
    "id": "ea-ic-8",
    "matches": [
      "https://e-okul.meb.gov.tr/*",
      "https://*.e-okul.meb.gov.tr/*",
      "https://eokul.meb.gov.tr/*"
    ],
    "js": [
      "modules/ortak/panel_cekmece.js"
    ],
    "persistAcrossSessions": true,
    "runAt": "document_idle"
  }  ,
  {
    "id": "ea-ic-9",
    "matches": [
      "https://e-okul.meb.gov.tr/*",
      "https://*.e-okul.meb.gov.tr/*",
      "https://eokul.meb.gov.tr/*"
    ],
    "js": [
      "modules/ortak/xlsx.js",
      "modules/oyss/oyss.js",
      "modules/oyss/ses.js",
      "ses/hap.js"
    ],
    "persistAcrossSessions": true,
    "allFrames": true,
    "runAt": "document_idle"
  },
  {
    "id": "ea-ic-10",
    "matches": [
      "https://e-okul.meb.gov.tr/*",
      "https://*.e-okul.meb.gov.tr/*",
      "https://eokul.meb.gov.tr/*"
    ],
    "js": [
      "modules/dersnotu/eop.js",
      "modules/dersnotu/akis.js",
      "ice/excel.js",
      "ice/cozumle.js",
      "modules/dersnotu/panel.js"
    ],
    "persistAcrossSessions": true,
    "allFrames": true,
    "runAt": "document_idle"
  }
];
