/* Ürün lisans ayarı — Evrak Asistanı / Eyüp ŞEKER */
self.EA_LISANS_AYAR = {
  "urun": "eokul",
  "kabul": [
    "eokul"
  ],
  "ad": "Okul Pro Devamsızlık Rapor Asistanı",
  "surum": "2.7.3",
  "depo": "ea_lisans_eokul_v1",
  "hazirMetin": "e-Okul sekmesini yenileyin; panel açılır."
};
