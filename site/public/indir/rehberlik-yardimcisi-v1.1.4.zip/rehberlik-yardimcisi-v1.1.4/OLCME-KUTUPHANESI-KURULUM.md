# Sınıf İçi Ölçme ve Değerlendirme Kütüphanesi – v1.0.0

Bu modül Rehberlik Yardımcısı uygulamasına eklenmiştir. Mevcut belge/şablon akışını değiştirmez.

## Uygulamada nerede?
Sol menüde **Ölçme ve Değerlendirme → Sınıf İçi Ölçme ve Değerlendirme Kütüphanesi**.

## İlk kullanım
1. Uygulamayı yeni sürüm dosyalarıyla yayımlayın.
2. Tarayıcıda uygulamayı yenileyin. Eski servis çalışanı önbelleği varsa bir kez çevrimiçi açıp yenilemek gerekebilir.
3. Kütüphaneye girin ve her PDF için sınıf, ders ve kitap adını seçerek PDF’yi aktarın.
4. Aktarım bittikten sonra **Kaynaklarda Ara** sekmesinden kitap içindeki metni ve sayfa numarasını arayın.
5. **Etkinlik / Ölçme Aracı** sekmesinde sınıf, ders ve konu bilgisiyle öğretmen taslağı hazırlayın.

## Veri ve gizlilik
- PDF metinleri tarayıcının IndexedDB alanında saklanır; modül PDF dosyasını sunucuya yüklemez.
- Harici veya ücretli yapay zekâ API’si çağrılmaz.
- Veriler aynı tarayıcı/profilde kalır. Tarayıcı verileri temizlenirse silinebilir. Bu nedenle cihaz değişimi öncesinde ayrıca yedekleme stratejisi gerekir.
- Kitap silme işlemi ilgili kitabın sayfa indeksini de siler.

## Bilinen sınırlamalar
- 36 ODSGM kılavuzunun sayfa metinleri hazır yüklenir (ham PDF pakete konmaz). Elle ek PDF yüklemek isteğe bağlıdır.
- Metin katmanı olmayan taranmış PDF sayfaları otomatik OCR edilmez; bu sayfalar indeks dışında kalabilir. Arayüz bunu “metin çıkarılamadı / tarama olabilir” olarak işaretler.
- Etkinlik/ölçme aracı oluşturucu şimdilik kılavuzla eşleşen sayfaları kaynak gösteren düzenlenebilir bir taslak üretir; otomatik üretken yapay zekâ değildir. Kaynakta eşleşme yoksa genel taslak olduğunu açıkça belirtir.
- 558 öğrenme çıktısı ve 488 etkinlik gibi sayısal kataloglar bu sürümde elle uydurulmamıştır. PDF’ler yüklendikten sonra kaynaklardan yapılandırılmış katalog çıkarma ikinci aşamadır.

## Teknik not
- Yeni dosya: `olcme-kutuphanesi.js`
- Entegrasyon: `index.html` sonuna script etiketi eklendi.
- Çevrimdışı önbellek: `sw.js` sürümü yükseltildi ve modül dosyası önbellek listesine eklendi.
- Yerel veri deposu: IndexedDB `oy_olcme_kutuphanesi_v1` (stores: `books`, `pages`).

## v1.0.1 düzeltmeleri (ÖY 1.12.2)
- `sw.js` önbellek listesine `olcme-kutuphanesi.js` ve eksik kalan modül dosyaları (liste-aktar, egzersiz-sec, sablon-ek, gundem-veri, kurul-ayrinti, arayuz) eklendi; önbellek adı `oy-1.12.2-1124b`.
- Sürüm etiketi her yerde 1.12.2 yapıldı (başlık, ekler.js, planlar.js, bep-havuz.js, planlar-ui.js).
- Etkinlik / Ölçme Aracı: 7 içerik türünün her biri artık kendi taslak gövdesini üretiyor (önceden hepsi aynı metni veriyordu).
- Kaynak eşleştirme tam ifade yerine anahtar kelimeyle yapılıyor ("ışık gölge" artık "Işık ve gölge" sayfasını buluyor).
- Sınıf seçimi 1–12 olarak genişletildi.
- Toplu aktarımda bozuk/şifreli bir PDF artık diğer dosyaları durdurmuyor; aktarılamayanlar mesajda listeleniyor.


## v1.0.2 — hazır ODSGM kılavuzları (ÖY 1.12.3 / MYP 1.12.5 / Rehberlik 1.1.4 / Sınıf Rehberlik 1.1.3)

- Resmî kaynak: https://odsgm.meb.gov.tr/www/sinif-ici-olcme-ve-degerlendirme-etkinlikleri-kilavuz-kitaplari/icerik/1771
- 36 kılavuz PDF’sinin sayfa metinleri `olcme-kitaplar.json.gz` içinde gelir (ham PDF pakete konmaz). İlk açılışta IndexedDB’ye bir kez işlenir (sürüm: odsgm-2026-11-v1).
- 5252 sayfa, 5204 metin sayfası. Taranmış/görüntü-yalnız kitap yok. Arama ve etkinlik taslağı çevrimdışı bu indeksle çalışır.
- Kitaplıkta kitabı açınca **Özet** kartı: etkinlik adı, tema/ünite, öğrenme çıktısı ve sayfa — kitabın kendi metninden çıkarılmıştır; üretilmiş içerik değildir. 483 etkinlik özeti derlenmiştir.
- “PDF’yi aç” resmi EBA/ODSGM adresini yeni sekmede açar. Elle PDF yükleme isteğe bağlı olarak durur.
- “X / 36 kitap” sayacı resmi 36 kılavuzu esas alır.
